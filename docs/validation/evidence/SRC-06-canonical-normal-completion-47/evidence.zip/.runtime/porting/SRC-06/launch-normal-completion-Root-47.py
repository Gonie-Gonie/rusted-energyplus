"""Root-only seven normal-feature CLI commands; never invokes Native or tests."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
spec=importlib.util.spec_from_file_location('normal_completion_guards',D/'normal-completion-command-guards-Audit-47.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def main(a):
 assert a.execute,'Root explicit --execute required';qr,q,m,plan=g.authority(a.plan);ar,application=g.application(a.application,plan);assert g.ref(Path(__file__))==q['launch_Source']
 case=next(v for v in q['cases']if v['case']==a.case)
 for old in g.CASES[:g.CASES.index(a.case)]:
  p=D/f'canonical-source-normal-completion-{old}-command-Root-47/receipt.json';r=g.read(p);assert r['exit_code']==0 and r['launch_error']is None and r['source_bytes_match_before_and_after']
  snapshot=g.read(g.checked(r['source_snapshot']));rows={x['historical_path']:x for x in snapshot['files']};assert set(rows)==g.inventory()
  for v in plan['entries']:assert rows[v['path']]['archive']['sha256']==v['final_sha256']and rows[v['path']]['size_bytes']==v['final_bytes']
 for k in('input','metadata','weather'):g.checked(case[k])
 meta=g.read(g.checked(case['metadata']));assert(meta['id'],meta['scope'])==(a.case,a.case[0])and meta['input']['sha256']==case['input']['sha256']and meta['weather']['sha256']==case['weather']['sha256']
 assert subprocess.check_output(['git','show',g.BASE+':'+case['input']['path']],cwd=R)==g.checked(case['input']).read_bytes()
 base=g.read(g.checked(case['actual43_command_parent']));assert base['exit_code']==0 and base['launch_error']is None and base['source_bytes_match_before_and_after'];cmd=list(base['command'])
 assert cmd[:2]==['cargo','run']and cmd[cmd.index('--bin')+1]=='eplus-rs'and cmd[cmd.index('--porting-scope')+1]==a.case[0]
 assert '--features'not in cmd[:cmd.index('--')]and not{'test','--all-targets','--oracle-baseline','--compare-oracle','--hours'}&set(cmd)
 at=[i for i,v in enumerate(cmd)if v.lower().endswith('.idf')];assert len(at)==1;cmd[at[0]]=g.checked(case['input']).as_posix();cmd[cmd.index('--weather')+1]=g.checked(case['weather']).as_posix()
 output=D/f'canonical-source-normal-completion-{a.case}-Root-47/output';receipt=D/f'canonical-source-normal-completion-{a.case}-command-Root-47';assert not output.parent.exists()and not receipt.exists();cmd[cmd.index('--output-dir')+1]=output.as_posix()
 print('Root47 '+a.case+': normal featureNone, canonical target55, incremental0; no Native/oracle comparison or test body.',flush=True)
 code=subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',receipt.relative_to(R).as_posix(),'--',*cmd],cwd=R,env=g.environment())
 g.whole_current(plan);run=g.read(receipt/'receipt.json');assert run['exit_code']==code and run['launch_error']is None and run['source_bytes_match_before_and_after'];return code
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case',choices=g.CASES);p.add_argument('--plan',required=True);p.add_argument('--application',required=True);p.add_argument('--execute',action='store_true');raise SystemExit(main(p.parse_args()))

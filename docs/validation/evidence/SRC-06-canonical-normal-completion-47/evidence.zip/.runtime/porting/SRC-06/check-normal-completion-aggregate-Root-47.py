"""Root-only aggregation of seven already executed CLIs and read-only readers."""
from pathlib import Path
import argparse, ast, copy, importlib.util, json
R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
spec = importlib.util.spec_from_file_location('normal47', D / 'normal-completion-command-guards-Audit-47.py')
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
PLAN = '.runtime/porting/SRC-06/normal-completion-commands-ready-Audit-47/plan.json#f42b07ce82b5541021976de7d16187646503bcd89890a4d2517cb72db4143ccb'
APP = '.runtime/porting/SRC-06/Root-normal-completion-application-47/receipt.json#d5f0823be751c22188edac5268e03e2554e7c7bdafe19ac6a85352b2fb58f6e5'


def main(a):
    qr, q, m, plan = g.authority(PLAN); ar, app = g.application(APP, plan)
    readyp = D / 'normal-completion-readback-ready-Audit-47-02/plan.json'
    assert g.ref(readyp)['sha256'] == 'da8f2ab44a6f49b77321376023bd272941a6614d3f14fd88f7bde6d867c42128'
    ready = g.read(readyp); assert g.ref(g.checked(ready['case_checker_Source']))['sha256'] == '4f682346121e60ca70afb89c5a4b63bc66326fca67fa4255f3446ebefacfe18e'
    driverp = D / 'Root-normal-completion-remaining-six-driver-47/receipt.json'
    assert g.ref(driverp)['sha256'] == '1160a3c62cb6238a1af27068b91ecfd5572007c95d814ba35f4fe7d55c3581bf'
    driver = g.read(driverp); assert driver['accepted'] and not driver['findings'] and driver['application'] == ar and len(driver['actual_runs']) == 6
    checks, artifacts, snapshots, core_identity = [], [], [], None
    corep = D / 'check-source-compact-actual-Root-13.py'
    assert g.ref(corep)['sha256'] == 'e74ca3d9d2a85102f0dca30ed978ed25d7f8bee8e1fd72459b7b7ba131c2dea4'
    functions = [x for x in ast.parse(corep.read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name in ['same_path', 'core']]
    ns = dict(Path=Path, json=json, copy=copy, R=R, checked=lambda x: g.checked(x).read_bytes())
    exec(compile(ast.Module(body=functions, type_ignores=[]), '<unchanged accepted core identity reader>', 'exec'), ns)
    for index, item in enumerate(q['cases']):
        case = item['case']; p = D / ('Root-normal-completion-' + case + '-readback-47/review.json')
        v = g.read(p); receipt = g.read(g.checked(v['actual_receipt']))
        assert v['accepted'] and not v['findings'] and v['case'] == case and v['application'] == ar and v['producer'] == q['producer']
        assert v['all4523_archived_inputs_exact_plan'] and v['no_Oracle_run'] and v['false_three_family_diagnostics_absent']
        assert v['author_Source'] == ready['case_checker_Source'] and v['actual_snapshot'] == receipt['source_snapshot']
        assert receipt['exit_code'] == 0 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
        snapshots.append(receipt['source_snapshot']); core = ns['core'](receipt, index != 0)
        assert all(not x['features'] for x in core.values())
        assert core_identity is None or core == core_identity; core_identity = core
        if case.endswith('24H'):
            transfer = v['whole43_physical_and_export_transfer']; assert transfer['whole_JSON_equal_after_exactly_two_owned_path_bridges'] and transfer['whole_runtime_equal_after_exactly_two_owned_path_bridges']
        else:
            assert v['whole43_physical_and_export_transfer'] is None
        physical = v['ancillary']; assert physical['elapsed_time_not_normalized']
        checks.append(dict(case=case, actual_receipt=v['actual_receipt'], case_readback=g.ref(p), actual_hours=8760 if case.endswith('ANNUAL') else 72 if case.endswith('72H') else 24, raw_ancillary_unequal_rows=physical['unequal_rows'], unclassified_ancillary_rows=physical['unclassified_rows'], overall_physical_IO_PASS=physical['overall_physical_IO_PASS']))
        artifacts += [g.ref(p), v['actual_receipt'], receipt['stdout'], receipt['stderr'], v['summary'], v['diagnostics'], v['actual_ERR'], v['actual_END'], physical['all_uncapped_differences']]
        # Preserve small ancillary files, never annual ESO/CSV/JSON trees.
        for row in physical['comparisons']:
            if row['kind'] in ['err', 'end', 'mtd', 'audit', 'dbg', 'extra.ctf.err', 'extra.ctf.log']:
                artifacts += [row[k] for k in ['Source', 'Native'] if k in row]
        if case.endswith('24H'):
            t = v['whole43_physical_and_export_transfer']
            artifacts += [x['current'] for x in t['physical_streams'] + t['whole_CSV'] if 'current' in x] + [t['current_JSON']]
    assert all(x == snapshots[0] for x in snapshots)
    comparisons = dict(x.split('=', 1) for x in a.comparison); assert set(comparisons) == {'A-24H', 'A-72H', 'A-ANNUAL'} and len(a.comparison) == 3
    strict = []
    for case in ['A-24H', 'A-72H', 'A-ANNUAL']:
        cr = g.argument(comparisons[case]); c = g.read(g.checked(cr)); expected = next(x for x in ready['cases'] if x['case'] == case); current = next(x for x in checks if x['case'] == case)
        assert c['schema'] == 'src06-completed-finite-case-strict-reported-stream-comparison.v1' and c['accepted'] and c['case'] == case
        assert c['Source_receipt'] == current['actual_receipt'] and c['Native_receipt'] == expected['Native_authority']
        assert c['policy'] == ready['unchanged_tolerance_policy'] and c['author_Source'] == ready['public_unchanged_strict_comparer']
        assert (c['totals']['series'], c['totals']['samples']) == {'A-24H': (58, 5352), 'A-72H': (58, 16056), 'A-ANNUAL': (58, 1953480)}[case]
        assert c['totals']['tolerance_failures'] == c['totals']['rmse_failures'] == 0 and c['totals']['passed']
        strict.append(dict(case=case, comparison=cr, totals=c['totals'], Native_authority=c['Native_receipt']))
        artifacts += [cr, c['all_uncapped_tolerance_failures']]
    g.whole_current(plan)
    for row in driver['actual_runs']:
        artifacts += [row['stdout'], row['stderr']]
    artifacts += [g.ref(driverp), driver['author_Source'], qr, ar, q['producer'], q['complete_compiler_plan'], m['independent_full_semantic_peer'], q['parent_compiler_LF_bridge'], q['application_Source'], q['launch_Source'], q['guard_Source'], q['record_command_Source'], g.ref(readyp), ready['preserved_original_reader'], ready['preserved_original_plan'], ready['narrow_forward_diff'], ready['narrow_inverse_diff'], ready['case_checker_Source'], ready['author_Source'], g.ref(corep), ready['public_unchanged_strict_comparer'], ready['unchanged_tolerance_policy'], g.ref(Path(__file__))]
    result = dict(schema='src06-normal-completion-sevenCLI-and-reported-transfer47.v1', accepted=True, findings=[], application=ar, producer=q['producer'], independent_full_semantic_peer=m['independent_full_semantic_peer'], complete_compiler_plan=q['complete_compiler_plan'], parent_compiler_LF_bridge=q['parent_compiler_LF_bridge'], actual_snapshot=snapshots[0], same4523_archived_inputs_exact_final_plan_and_live=True, Rust_sources=4510, selected25_final_sources_exact=True, changed_existing_sources=19, new_sources=6, actual_production_CLI_invocations=7, actual_test_bodies_executed=0, new_test_bodies=0, all_normal_featureNone_core_artifacts_exact_first_false_rest_true=True, ordered_cases=checks, actual_remaining_six_driver=g.ref(driverp), five24_whole43_physical_and_export_transfers=True, current_A_strict_reported_comparisons=strict, A_current_reported_policy_pass=True, B24_reported_policy_proofs_inherited_only_through_exact_physical_and_export_transfer=True, accepted43_review=ready['accepted43_five_CLI_review'], accepted45_review=ready['accepted45_review'], accepted46_review=ready['accepted46_review'], annual_own_JSON_CSV_roundtrip_claim=False, ancillary_scope='Uncapped raw bytes/absences for all seven actual cases. Only actual first ProgramVersion payload is classified; real Source/Native elapsed and Source sidecar differences remain, so no blanket physical ancillary PASS.', preserved_reader01_failure=ready['original_failure'], incremental_environment_qualification=ready['incremental_environment_qualification'], publication_artifacts=list({x['path']: x for x in artifacts}.values()), limits=['Seven normal Source47 CLI successes are not a new scientific unit, gate promotion, full card completion, or final checkpoint.', 'Current A24/A72/annual strict reported comparisons use unchanged original tolerances and sequential RMSE, not raw internal-state identity.', 'Only five24 own-export whole equality is carried here. Annual own JSON/CSV streaming scalar verification remains a separate obligation.', 'Root46 has genuine separate B duration comparisons. Historical Source43/46 scientific and duration evidence is inherited with explicit source-version qualification, not reexecuted under47.', 'Positive unsupported completion child boundaries remain explicit; no arbitrary input scope expansion.'], author_Source=g.ref(Path(__file__)))
    output = D / 'Root-source-normal-completion-actual-review-47'; assert not output.exists(); output.mkdir()
    p = output / 'review.json'; p.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n'); print(json.dumps(g.ref(p)))


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--comparison', action='append', required=True); main(p.parse_args())

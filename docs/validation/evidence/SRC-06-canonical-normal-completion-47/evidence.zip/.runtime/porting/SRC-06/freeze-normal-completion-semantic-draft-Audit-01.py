"""Freeze a private semantic proposal. Never edits or executes canonical code."""
from pathlib import Path
import ast, hashlib, json, re, shutil, subprocess, sys

sys.stdout.reconfigure(encoding="utf-8")
R = Path.cwd()
D = R / ".runtime/porting/SRC-06"
N = R / ".reference/energyplus-src/26.1.0"
PIN = "6f2e40d10250a105b49966baa24d843711e61048"
O = D / "source-normal-completion-draft-Audit-01"
assert not O.exists(), "immutable destination already exists"
S = D / "source-normal-completion-author-Audit-01"
status = json.loads((S / "status.json").read_bytes())
plan_path = D / "normal-completion-owner-readonly-plan-Audit-01/plan.json"
plan = json.loads(plan_path.read_bytes())
anc_path = D / "source-ancillary-transport-admission-draft-Audit-02/draft.json"
anc = json.loads(anc_path.read_bytes())
peer_path = D / "Peer-ancillary-transport-admission-Source-review-Outer-02/review.json"
peer = json.loads(peer_path.read_bytes())

def digest(b): return hashlib.sha256(b).hexdigest()
def ref(p):
    p = Path(p)
    b = p.read_bytes()
    return {"path": p.relative_to(R).as_posix(), "sha256": digest(b), "bytes": len(b)}
def checked(v):
    p = R / v["path"]
    b = p.read_bytes()
    assert digest(b) == v["sha256"], v
    assert "bytes" not in v or len(b) == v["bytes"], v
    return b
def write_json(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(v, ensure_ascii=False, indent=2) + "\n").encode())
def copy_ref(v):
    checked(v)
    old = R / v["path"]
    relative = old.relative_to(S)
    p = O / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(old, p)
    return ref(p)

assert digest(plan_path.read_bytes()) == "d1921fb216f88e31279aed69f30a3ef78b43dcf50eab200e7ef7dfe66956960a"
assert digest(anc_path.read_bytes()) == "6caddde6aa05b7102ff65abcfdc651091e38b9726b8fe45f3968c2cd7c4a8903"
assert digest(peer_path.read_bytes()) == "45a40e83c1ef95f11a53200e7be1c9b33f7600f10f294bb2566102b3003ba999"
assert peer["accepted"] and not peer["findings"]
assert len(status["files"]) == 25 and status["Source_only_parses"] == 25
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=R).decode().strip()

# Reuse only the reviewed literal patch primitive, never its surrounding script.
primitive = (D / "seal-compact-annual-daygroup-helper-Peer-01.py").read_text()
fn = next(v for v in ast.parse(primitive).body if isinstance(v, ast.FunctionDef) and v.name == "apply_literal")
namespace = {"re": re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), "reviewed_literal_primitive", "exec"), namespace)
apply_literal = namespace["apply_literal"]

O.mkdir()
files = []
applications = []
for row in status["files"]:
    path = row["canonical_path"]
    before = b"" if row["before_absent"] else checked(row["before"])
    after = checked(row["proposed"])
    assert (not (R / path).exists()) if row["before_absent"] else (R / path).read_bytes() == before
    git = subprocess.run(["git", "show", f"{head}:{path}"], cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if row["before_absent"]:
        assert git.returncode != 0
    else:
        assert git.returncode == 0 and git.stdout == before, path
    assert apply_literal(before, checked(row["forward_diff"])) == after, path
    assert apply_literal(after, checked(row["inverse_diff"])) == before, path
    assert row["Source_only_parse"]["exit_code"] == 0
    new = {"canonical_path": path, "before_absent": row["before_absent"],
           "before": None if row["before_absent"] else copy_ref(row["before"]),
           "proposed": copy_ref(row["proposed"]),
           "forward_diff": copy_ref(row["forward_diff"]), "inverse_diff": copy_ref(row["inverse_diff"]),
           "Source_only_parse": {"exit_code": 0, "stdout": copy_ref(row["Source_only_parse"]["stdout"]),
                                 "stderr": copy_ref(row["Source_only_parse"]["stderr"])},
           "selected_before_Git_and_live_exact_or_absent": True}
    files.append(new)
    applications.append({"canonical_path": path, "forward_exact": True, "inverse_exact": True,
                         "before_sha256": digest(before), "proposed_sha256": digest(after)})

hb = "crates/ep_runtime/src/heat_balance/"
final = {x["canonical_path"]: checked(x["proposed"]) for x in files}
anc_rows = {x["canonical_path"]: x for x in anc["files"]}
anc_join = []
for path, row in anc_rows.items():
    old_proposal = checked(row["proposed"])
    anc_join.append({"canonical_path": path, "accepted_ancillary_proposal": row["proposed"],
                     "whole_carried": final[path] == old_proposal,
                     "successor_adds_only_normal_completion": final[path] != old_proposal})
assert sum(x["whole_carried"] for x in anc_join) == 5
assert sum(x["before_absent"] for x in files) == 6
for x in files:
    if x["before_absent"] and x["canonical_path"] not in anc_rows:
        b = checked(x["proposed"])
        assert b"\r" not in b and not b.startswith(str(O).encode())
added = "\n".join(line[1:] for row in files for line in checked(row["forward_diff"]).decode().splitlines()
                  if line.startswith("+") and not line.startswith("+++"))
assert not re.search(r"\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)!|\bunsafe\s*\{", added)
assert "#[test]" not in added

# Authenticate source, not a Native produced output or an expected-answer fixture.
authority = {}
for row in plan["Native_authorities"]:
    for e in row["extents"]: checked(e["source"])
    checked(row["whole"])
    authority[row["Native_path"]] = {"Native_path": row["Native_path"], "ranges": [(e["first"], e["last"]) for e in row["extents"]]}
extra = {
 "src/EnergyPlus/OutputProcessor.hh": [(953, 970)],
 "src/EnergyPlus/InputProcessing/InputProcessor.hh": [(78, 102), (298, 322)],
 "src/EnergyPlus/SolarShading.hh": [(405, 420), (570, 582)],
 "src/EnergyPlus/SolarShading.cc": [(2945, 2969), (3157, 3178), (4770, 4790), (4866, 4887), (11621, 11821)],
 "src/EnergyPlus/DataErrorTracking.hh": [(62, 236)],
 "src/EnergyPlus/IOFiles.hh": [(624, 650)],
}
for path, ranges in extra.items():
    authority.setdefault(path, {"Native_path": path, "ranges": []})["ranges"].extend(ranges)
native = []
for path, row in authority.items():
    p = N / path
    b = p.read_bytes()
    git = subprocess.check_output(["git", "show", f"{PIN}:{path}"], cwd=N)
    assert b == git, path
    lines = b.splitlines(keepends=True)
    extents = []
    for first, last in sorted(set(row["ranges"])):
        assert 1 <= first <= last <= len(lines)
        q = O / "Native-extents" / f"{path.replace('/', '__')}.{first}-{last}.txt"
        q.parent.mkdir(parents=True, exist_ok=True)
        q.write_bytes(b"".join(lines[first-1:last]))
        extents.append({"first": first, "last": last, "source": ref(q)})
    native.append({"Native_path": path, "pinned_Git": PIN, "whole": ref(p), "extents": extents})

# Strict independent re-extraction verifies every source constant in the tables.
native_hh = (N / "src/EnergyPlus/DataErrorTracking.hh").read_text()
quoted = lambda v: [json.loads(s) for s in re.findall(r'"(?:[^"\\]|\\.)*"', v)]
summaries = quoted(native_hh.split("constexpr Summaries({", 1)[1].split("});", 1)[0])[1:]
details = {int(n): "".join(quoted(chunk)) for n, chunk in re.findall(r"auto constexpr MoreDetails_(\d+)\((.*?)\);", native_hh, re.S)}
details[17] = details[16]
table = final[hb + "source_initialization/program_completion_tables.rs"].decode()
assert quoted(table.split("SUMMARIES", 1)[1].split("MORE_DETAILS", 1)[0]) == summaries
assert quoted(table.split("MORE_DETAILS", 1)[1]) == [details[i] for i in range(1, 21)]

context_paths = set(x["canonical_path"] for x in plan["Source_contexts"])
context_paths.update([
 hb + "error_backend/live_flags.rs", hb + "radiation/ordinary/solar_timestep/period.rs",
 hb + "selected_input_processor/input_statistics.rs", hb + "selected_project_data/environment.rs",
 hb + "ordinary_source_simulation/prelude_host.rs", hb + "ordinary_source_simulation/primary_host.rs",
 hb + "source_initialization/run_prefix.rs", hb + "ctf_reports/formatting.rs",
 hb + "ordinary_equipment/source_purchased_air/calculation.rs", hb + "ordinary_equipment/source_purchased_air/initialization.rs",
 hb + "ordinary_surface_initialization/inside_providers.rs", hb + "ordinary_air_heat_balance/predictor_corrector/component_report.rs",
 "crates/ep_runtime/src/weather_day/source_initialization.rs", "crates/ep_run/src/main.rs",
])
contexts = []
for path in sorted(context_paths):
    p = R / path
    if not p.exists():
        continue
    q = O / "Source-contexts" / path
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, q)
    contexts.append({"canonical_path": path, "whole": ref(q), "logical_current_parent": True,
                     "not_a_final_compiler_plan_claim": True})

# Bounded typed API/producer census over all crate Rust Sources, with line text.
patterns = [
 r"SourceInitializationFilePaths\s*\{", r"SourceResultsFrameworkOptions\s*\{", r"ProjectSystemVariables\s*\{",
 r"SelectedHeatBalanceGlobals\s*\{", r"SourceOutputRegistration\s*\{", r"prepare_source_environment",
 r"selected_project_data\s*=", r"project\.system\s*=", r"run_read_vars", r"running_via_api",
 r"source_recurring_errors", r"ShowRecurring", r"show_recurring", r"recurring(?: cooling| heating| warning|5667)",
 r"num_too_many_figures", r"num_too_many_vertices", r"num_base_sub_surround", r"native_text_bytes",
 r"complete_source_program", r"close_source_illuminance_maps", r"close_source_socket_at_success",
]
matcher = re.compile("|".join(f"(?:{x})" for x in patterns))
census = []
source_count = 0
for p in sorted((R / "crates").rglob("*.rs")):
    source_count += 1
    path = p.relative_to(R).as_posix()
    data = final.get(path, p.read_bytes())
    rows = [{"line": i, "text": text} for i, text in enumerate(data.decode().splitlines(), 1) if matcher.search(text)]
    if rows:
        census.append({"canonical_path": path, "sha256": digest(data), "bytes": len(data), "matches": rows,
                       "logical_proposal": path in final})
for path, data in final.items():
    if (R / path).exists(): continue
    rows = [{"line": i, "text": text} for i, text in enumerate(data.decode().splitlines(), 1) if matcher.search(text)]
    census.append({"canonical_path": path, "sha256": digest(data), "bytes": len(data), "matches": rows, "logical_proposal": True})
write_json(O / "concrete-API-and-producer-census.json", {"patterns": patterns, "existing_crate_Rust_sources_read": source_count,
           "logical_proposal_overlay": True, "matches": census, "no_final_compiler_snapshot_claim": True})

# Compile-policy evidence only: no compiler execution, environment copying or stats fallback.
compile_path = R / ".runtime/ep261-gcc13-o0/compile_commands.json"
registry = json.loads(compile_path.read_bytes())
psy_rows = [x for x in registry if x["file"].replace("\\", "/").endswith("/src/EnergyPlus/Psychrometrics.cc")]
assert len(psy_rows) == 1
psy_command = psy_rows[0].get("command", " ".join(psy_rows[0].get("arguments", [])))
assert "EP_psych_errors" in psy_command and "EP_psych_stats" not in psy_command
header_defs = []
for p in (N / "src/EnergyPlus").rglob("*"):
    if p.suffix not in (".h", ".hh", ".hpp"): continue
    if re.search(rb"^\s*#\s*define\s+EP_psych_stats\b", p.read_bytes(), re.M): header_defs.append(str(p))
assert not header_defs
write_json(O / "psychrometric-summary-compile-policy.json", {"configured_original_core_compile_registry": ref(compile_path),
 "actual_Psychrometrics_translation_unit": psy_rows[0], "EP_psych_stats_defined_in_command": False,
 "EP_psych_stats_definitions_in_EnergyPlus_headers": header_defs,
 "qualification": "Current pinned original-core configuration; not historical installed Native12 compiler-environment evidence. No property/cache call added."})

ledger = [
 {"group": "SystemVars runtimeTimer", "members": {"start": "system_clock time_point{} / UNIX_EPOCH", "end": "time_point{} / UNIX_EPOCH", "duration_milliseconds": "chrono::milliseconds{} / 0"},
  "Native": "Timer.hh56-86; Timer.cc57-110; DataSystemVariables.hh130-135", "producer": "tick before retained Source resolve_environment_operands; tock only after summaries/close; accumulated duration is not reset by tick", "reader": "same EndEnergyPlus elapsed formatting; never pipeline timings or Native output"},
 {"group": "DataGlobal API/ReadVars cells", "members": {"run_read_vars": False, "running_via_api": False}, "Native": "DataGlobals.hh86-99,164-177; CommandLineInterface.cc488-500; EnergyPlusPgm.cc476-494", "producer": "Real frontend has no corresponding option/API writer; retained positive guards stop at true runReadVarsESO/flushAll child", "reader": "normal wrapper/End"},
 {"group": "DataErrTracking disjoint partial members", "members": {"number": 0, "rows": "unallocated Array1D / None"}, "Native": "DataErrorTracking.hh205-236", "producer": "Admitted current Source diagnostic recording children are explicit unavailable boundaries before recurring record writes; census retained", "reader": "count then true positive ShowRecurringErrors boundary; no fabricated row/history"},
 {"group": "same ResultsFramework SimInfo", "members": {name: "std::string{} / empty" for name in ["program_version", "simulation_environment", "input_model_uri", "start_date_time_stamp", "run_time", "warnings_warmup", "severe_warmup", "warnings_sizing", "severe_sizing", "warnings", "severe"]}, "Native": "ResultsFramework.hh92-114; .cc121-143", "producer": "7 actual End setters use own elapsed plus 6 live counts", "qualification": "Earlier commonInitialize ProgramVersion/StartDateTime setters are not ported here. Positive ResultsFramework output writer stops before consuming these unported fields; finite output flags false."},
 {"group": "SolarShading error counters", "members": {"num_too_many_figures": 0, "num_too_many_vertices": 0, "num_base_sub_surround": 0}, "Native": "SolarShading.hh405-420; .cc3157-3178/4770-4790/4866-4887", "producer": "No admitted positive CHKSBS/MULTOL record writer: real Minimal and no-subsurface branch predicates precede typed Source boundaries", "reader": "same 3-counter signed sum; positive prefix then first actual SurfErrorReported allocation boundary"},
 {"group": "OutputProcessor audit latches", "members": {"ungenerated_report_warning": False, "opaque_surface_warning": False}, "Native": "OutputProcessor.hh953-970; .cc3746-3802", "producer": "True first reached unused-request diagnostics, in stored request order", "reader": "same audit loop, real used/key/name/frequency"},
 {"group": "File ownership", "members": {"end": "caller-owned physical path; local file opens only at End", "error": "caller-owned physical ERR path", "dfs": "same InputOutputFile constructor not open / None"}, "Native": "IOFiles.hh498-513/624-650", "producer": "real END open/write; ERR genuine backend logical bytes use existing Native C-text host; DFS retains unopened shape", "qualification": "ERR physical persistence is delayed until normal completion, unlike Native early fstream open. No abnormal-open/error lifecycle parity claim."},
]
write_json(O / "constructor-and-producer-ledger.json", ledger)
write_json(O / "literal-custody-proof.json", {"literal_applications": applications, "applications": 50,
 "accepted_ancillary02_join": anc_join, "selected_existing_Git_wholes": 19, "selected_new_Git_absences": 6,
 "new_program_sources_rustfmt_formatted_LF": 5, "summary_tables20_independently_reextracted_exact": True,
 "forbidden_added_calls": [], "new_tests": 0, "syntax_parses": 25})

contract = {
 "scope": "Finite existing A/B15 admitted ordinary Source lane only; no card/gate completion or universe expansion.",
 "normal_order": ["Simulation Error Summary", "requested variable audit", "configured empty psychrometric statistics summary", "IP orphan objects", "fluid orphans", "schedule/week/day orphans", "same SQL/IP pointer resets", "real ReadVars guard", "End SQL guard", "solar summary guard", "recurring summary guard", "full real match-count summaries", "map/DFS/debug close/delete", "six live counter strings", "own timer tock/F2 elapsed", "seven SimInfo setters", "warmup/sizing/success messages", "runtime display", "real END local host", "ResultsFramework writer guards", "console completion", "external socket guard", "progress callbacks", "API flush guard", "audit close"],
 "hook": "Only explicit Source branch, after actual ManageSimulation620 and requested-hour validation, before own report reader/outcome. Legacy/None execution and early summary path unchanged.",
 "timer_phase": "Same retained Source wrapper preparation before Source environment operands/IP; earlier Rust conversion and compilation outside timer. Tick once under true files first-entry; no project-system replacement in admitted call route. Real system-clock milliseconds, not pipeline Instant or Native elapsed.",
 "six_counters": plan["six_live_counters"],
 "diagnostic_flags": "Short shared borrows of same globals/project/live WeatherSession flags; no backend stale warmup copy for new warning/severe audits.",
 "error_ownership": "Successful Source physical ERR uses genuine backend only; skip CLI structured-summary overwrite only for Source outcome. Legacy, None and finish_early diagnostic paths unchanged.",
 "positive_boundaries": ["runReadVarsESO", "positive SQLite End update (wrapper normally reset pointer)", "positive surface-error actual allocation", "positive recurring first row", "positive illuminance-map first MapColSep", "createPerfLog first real call", "END output-control false null stream", "positive ResultsFramework outputs", "positive ExternalInterface BCVTB CloseSocket", "captured progressCallback", "running-via-API flushAll"],
 "qualifications": ["Semantic proposal and syntax only; no Cargo/test/Native/CLI run or observed corrected output claim.", "Final full compiler-plan/current-parent join waits Root post46 transport normalization bridge; this is not an immutable applied checkpoint.", "Normal completion only. Abort/early failure and ERR early-open/lifetime parity remain outside this unit.", "SimInfo commonInitialize ProgramVersion/StartDateTime setters remain unported and unconsumed on finite false output-writer branches.", "Positive recurring and surface tracker rows remain unavailable, with genuine constructors and actual positive producer boundaries preserved.", "Current configured Native psych_stats absence is not a historical Native12 compile-policy claim.", "END/ERR elapsed is independently produced runtime metadata and cannot byte-equal another engine's elapsed value.", "Source-only CTF error/log sidecars remain qualified; no overall ancillary or scientific Native PASS inferred."],
 "test_policy": "No new test functions, targets, dependencies or formula changes. Root decides focused CLI/readback verification after independent Source peer and final parent join.",
}
write_json(O / "integration-contract.json", contract)
draft = {"schema": "src06-prospective-normal-completion-and-ancillary-draft.v1",
 "status": "IMMUTABLE_SEMANTIC_DRAFT_NOT_APPLIED_NOT_TYPECHECKED_FINAL_PARENT_JOIN_PENDING",
 "base_HEAD_for_selected_Git_authentication": head, "files": files, "selected_Source_files": 25,
 "selected_existing_sources": 19, "selected_new_sources": 6, "new_test_bodies": 0,
 "original_readonly_plan": ref(plan_path), "accepted_ancillary02": ref(anc_path),
 "independent_ancillary02_peer": ref(peer_path), "Native_authorities": native,
 "concrete_same_owner_contexts": contexts, "constructor_and_producer_ledger": ref(O / "constructor-and-producer-ledger.json"),
 "concrete_API_and_producer_census": ref(O / "concrete-API-and-producer-census.json"),
 "literal_custody": ref(O / "literal-custody-proof.json"), "psychrometric_summary_compile_policy": ref(O / "psychrometric-summary-compile-policy.json"),
 "integration_contract": ref(O / "integration-contract.json"),
 "author_Source": ref(D / "author-normal-completion-Audit-01.py"),
 "author_completion_body": ref(D / "normal-completion-body-Audit-01.rs"), "freezer_Source": ref(Path(__file__).resolve()),
 "Source_only_parses": 25, "literal_applications": 50, "no_Cargo_Native_test_or_canonical_mutation": True,
 "final_complete_compiler_plan": None,
 "scope_qualification": "Selected 19 before wholes are current Git/live exact and 6 paths absent; unselected Root43/46 raw compiler inventory deliberately pending the agreed LF bridge. No clean-worktree or compiled final-plan assertion."}
write_json(O / "draft.json", draft)
print(json.dumps(ref(O / "draft.json"), ensure_ascii=False))
print("Native", len(native), "extents", sum(len(x["extents"]) for x in native), "contexts", len(contexts))

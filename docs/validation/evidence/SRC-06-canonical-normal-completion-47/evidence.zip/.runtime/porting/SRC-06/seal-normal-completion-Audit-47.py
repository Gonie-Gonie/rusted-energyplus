"""Final custody join only; keeps accepted25 proposal bodies byte-identical."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path.cwd();D=R/'.runtime/porting/SRC-06';O=D/'source-normal-completion-held-Audit-47';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256']and len(b)==v.get('bytes',len(b)),v;return b
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
draftref=ref(D/'source-normal-completion-draft-Audit-02/draft.json');assert draftref['sha256']=='b7460e07f4eae598b1b4e372a5a8ad28a06a1e955a233889de0121ad6d648f42';m=json.loads(checked(draftref))
peerref=ref(D/'Peer-normal-completion-Source-review-02/review.json');assert peerref['sha256']=='608177483db98f76a0cc80621184bdbe2d2762a02014877b0e4373d981a60881';peer=json.loads(checked(peerref));assert peer['accepted']and not peer['findings']and peer['reviewed_draft']==draftref
bridge_ref=ref(D/'Root-canonical-Git-LF-compiler-bridge-after46/receipt.json');assert bridge_ref['sha256']=='da16a6b898ee52ba4d41a0b3acf3c90dc00e8e85204c005d7c35bcd2173d3f0a';bridge=json.loads(checked(bridge_ref));assert bridge['accepted']and not bridge['findings']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==bridge['base_HEAD']=='feda66208a8f3b3ae52aa38d7da56e8653c34b75'and not subprocess.check_output(['git','status','--porcelain'],cwd=R)
priorref=bridge['complete_compiler_plan'];assert priorref['sha256']=='3540d59cfe0c896f7401bdf2e1c9947e3eca979f67da9736b4d9a11c8bad03ae';prior=json.loads(checked(priorref));parents={x['path']:x for x in prior['entries']};assert len(parents)==4517
inventory={p.relative_to(R).as_posix()for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix()for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert inventory==set(parents)
for n,v in parents.items():
 b=checked(v['source']);assert len(b)==v['final_bytes']and hashlib.sha256(b).hexdigest()==v['final_sha256']and(R/n).read_bytes()==b,n
primitive=(D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text();fn=next(x for x in ast.parse(primitive).body if isinstance(x,ast.FunctionDef)and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns);apply=ns['apply_literal']
peerrows={x['canonical_path']:x for x in peer['files']};selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];a=b''if f['before_absent']else checked(f['before']);b=checked(f['proposed']);assert peerrows[n]['proposed']==f['proposed'];assert apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
 if f['before_absent']:assert n not in parents and not(R/n).exists();new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['source'])==subprocess.check_output(['git','show',head+':'+n],cwd=R)
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert(len(selected),len(new),tests)==(25,6,0)
contexts=[];contextbridge=[]
for x in m['concrete_same_owner_contexts']:
 n=x['canonical_path'];old=checked(x['whole']);current=(R/n).read_bytes()
 if old==current:contexts.append(x)
 else:
  matched=next(v for v in bridge['source_changes']if v['path']==n);assert matched['before']['sha256']==x['whole']['sha256'];assert checked(matched['before'])==old and checked(matched['after'])==current==old.replace(b'\r\n',b'\n')
  contexts.append(dict(canonical_path=n,whole=matched['after'],canonical_LF_bridge=bridge_ref));contextbridge.append(dict(canonical_path=n,old_context=x['whole'],new_context=matched['after'],only_CRLF_to_LF=True))
assert len(contextbridge)==1
rows=[]
for n in sorted(inventory|new):
 s=selected[n]['proposed']if n in selected else parents[n]['source'];b=checked(s)
 rows.append(dict(path=n,final_sha256=hashlib.sha256(b).hexdigest(),final_bytes=len(b),source=s,origin='whole accepted End02 proposal'if n in selected else'whole exact canonical-LF4517 parent'))
assert(len(rows),sum(x['path'].endswith('.rs')for x in rows))==(4523,4510)
O.mkdir()
pr=write(O/'complete-final-compiler-Source-plan.json',dict(schema='src06-complete-final-compiler-Source-plan.v1',base_HEAD=head,prior_complete_compiler_Source_plan=priorref,actual_parent_snapshot=bridge_ref,inputs=4523,compiler_inputs=4523,Rust_sources=4510,selected_existing=19,selected_new=6,unchanged_parent_entries=4498,entries=rows,qualification='All4517 parent archived/live exact after authenticated four-file LF bridge.25 accepted Source wholes overlay, no body change or execution.'))
readback=write(O/'parent-and-final-readback.json',dict(all4517_parent_archived_live_exact=True,selected19_before_Git_exact=True,selected6_before_absent=True,all4523_final_entries_exact=True,literal_applications=50,selected25_peer_whole_exact=True,new_test_bodies=0,old_air_report_sizer_cohorts_unchanged=True,context_only_LF_bridge=contextbridge,no_Cargo_Native_or_canonical_mutation=True))
manifest=dict(schema='src06-normal-completion-held-Source47.v1',status='HELD_READY_ROOT_REVIEW_AND_APPLICATION_ONLY',base_HEAD=head,Native_commit='6f2e40d10250a105b49966baa24d843711e61048',original_draft=draftref,independent_full_semantic_peer=peerref,parent_compiler_LF_bridge=bridge_ref,parent_producer=ref(D/'source-hard-sized-purchased-air-cohort-combined-held-Peer-43/manifest.json'),accepted43_actual_review=ref(D/'Root-source-hard-sized-purchased-air-actual-review-43/review.json'),prior_complete_compiler_Source_plan=priorref,complete_final_compiler_Source_plan=pr,actual_parent_snapshot=bridge_ref,files=m['files'],selected_Source_files=25,selected_existing_sources=19,selected_new_sources=6,final_compiler_inputs=4523,final_Rust_sources=4510,new_test_bodies=0,literal_applications=50,Source_only_parses=25,Native_authorities=m['Native_authorities'],concrete_same_owner_contexts=contexts,integration_contract=m['integration_contract'],constructor_and_producer_ledger=m['constructor_and_producer_ledger'],concrete_API_and_producer_census=m['concrete_API_and_producer_census'],accepted_ancillary02=m['accepted_ancillary02'],independent_ancillary02_peer=m['independent_ancillary02_peer'],summary_table_correction_proof=m['correction_proof'],source_constant_extraction=m['source_constant_extraction'],psychrometric_summary_compile_policy=m['psychrometric_summary_compile_policy'],parent_and_final_readback=readback,original_draft_freezer=m['freezer_Source'],author_Source=ref(Path(__file__).resolve()),qualification='Current compiler-parent join replaces pending inventory only. All25 proposed Source bytes are accepted02 exactly; normal/error/open/positive boundaries remain exactly its integration contract. No new scientific/unit/CLI/gate PASS claimed.')
print(json.dumps(write(O/'manifest.json',manifest)))
print(json.dumps(pr))

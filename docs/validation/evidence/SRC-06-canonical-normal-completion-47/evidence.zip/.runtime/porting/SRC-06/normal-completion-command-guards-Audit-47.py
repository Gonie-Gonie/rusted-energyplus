"""Read-only guards for Root47; importing this module executes no action."""
from pathlib import Path
import ast,hashlib,json,os,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
BASE='feda66208a8f3b3ae52aa38d7da56e8653c34b75'
MANIFEST=D/'source-normal-completion-held-Audit-47/manifest.json'
MANIFEST_SHA='575f19cf5e918f9dc6cdf094dc26afdd864ee09ba4f4ac17e0c286305816cc7c'
APP=D/'Root-normal-completion-application-47/receipt.json'
TARGET=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
CASES=['B-NOLIMIT-24H','A-24H','B-FLOW-24H','B-CAPACITY-24H','B-BOTH-24H','A-72H','A-ANNUAL']
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);a=ref(p);assert a['sha256']==v['sha256']and a['bytes']==v.get('bytes',a['bytes']),(v,a);return p
def read(p):return json.loads(p.read_bytes())
def argument(v):
 name,sha=v.rsplit('#',1);return ref(checked(dict(path=name,sha256=sha)))
def inventory():return {p.relative_to(R).as_posix()for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix()for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
def authority(spec):
 qr=argument(spec);q=read(checked(qr));assert q['status']=='READY_ROOT_ONLY_NOT_EXECUTED'and q['base_HEAD']==BASE
 assert ref(Path(__file__))==q['guard_Source']and ref(MANIFEST)==q['producer']and q['producer']['sha256']==MANIFEST_SHA
 m=read(MANIFEST);assert m['base_HEAD']==BASE and m['complete_final_compiler_Source_plan']==q['complete_compiler_plan'];peer=read(checked(m['independent_full_semantic_peer']));assert peer['accepted']and not peer['findings']and peer['reviewed_draft']==m['original_draft']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
 checked(q['record_command_Source']);checked(q['application_Source']);checked(q['launch_Source'])
 plan=read(checked(q['complete_compiler_plan']));assert(plan['inputs'],plan['Rust_sources'],len(plan['entries']))==(4523,4510,4523)
 return qr,q,m,plan
def whole_current(plan):
 rows={v['path']:v for v in plan['entries']};assert inventory()==set(rows)
 for n,v in rows.items():
  p=R/n;a=ref(p);assert(a['sha256'],a['bytes'])==(v['final_sha256'],v['final_bytes']),n
 return rows
def application(spec,plan):
 ar=argument(spec);assert checked(ar)==APP.resolve();a=read(APP);assert a['accepted']and not a['findings']and a['base_HEAD']==BASE and a['producer']==ref(MANIFEST)
 assert a['complete_compiler_plan']==ref(D/'source-normal-completion-held-Audit-47/complete-final-compiler-Source-plan.json')and a['all4523_final_plan_inputs_exact']and a['actual_test_or_CLI_invocations']==0
 whole_current(plan);return ar,a
def literal():
 source=(D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text();fn=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef)and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<accepted-literal-primitive>','exec'),ns);return ns['apply_literal']
def environment():
 env=dict(os.environ);assert TARGET.is_dir();env['CARGO_TARGET_DIR']=str(TARGET);env['CARGO_INCREMENTAL']='0'
 for key in('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_HOME'):assert env.get(key)is None,key
 assert Path(env['CARGO_TARGET_DIR']).resolve()==TARGET and env['CARGO_INCREMENTAL']=='0';return env

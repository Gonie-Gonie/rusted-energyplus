"""Immutable successor for the quoted-terminator extraction finding only."""
from pathlib import Path
import ast, difflib, hashlib, json, re, shutil, subprocess
R=Path.cwd();D=R/'.runtime/porting/SRC-06'
OLD=D/'source-normal-completion-draft-Audit-01';O=D/'source-normal-completion-draft-Audit-02'
assert not O.exists()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
draft=json.loads((OLD/'draft.json').read_bytes())
assert ref(OLD/'draft.json')['sha256']=='39ed5ee5fc70d29b71bb0747a5bf00b0e6a465cad1a1d3dc44430e02e5b65bc0'
shutil.copytree(OLD,O)
oldprefix=OLD.relative_to(R).as_posix();newprefix=O.relative_to(R).as_posix()
def relocate(v):
 if isinstance(v,dict):return {k:relocate(z) for k,z in v.items()}
 if isinstance(v,list):return [relocate(z) for z in v]
 if isinstance(v,str) and v.startswith(oldprefix+'/'):return newprefix+v[len(oldprefix):]
 return v
draft=relocate(draft)

# Tokenize once with string/comment boundaries. C++ punctuation inside a quoted
# token cannot terminate a declarator, including MoreDetails_12's "object);".
source=(R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/DataErrorTracking.hh').read_text()
token=re.compile(r'(?P<space>\s+)|(?P<comment>//[^\n]*|/\*.*?\*/)|(?P<string>"(?:[^"\\]|\\.)*")|(?P<identifier>[A-Za-z_]\w*)|(?P<other>.)',re.S)
tokens=[(m.lastgroup,m.group(),m.start(),m.end()) for m in token.finditer(source) if m.lastgroup not in ('space','comment')]
def declaration(name):
 matches=[i for i,v in enumerate(tokens[:-1]) if v[:2]==('identifier',name) and tokens[i+1][1]=='(']
 assert len(matches)==1,(name,len(matches))
 i=matches[0]+1;assert tokens[i][1]=='('
 depth=0;strings=[];first=tokens[i][2]
 while i<len(tokens):
  kind,text,a,z=tokens[i]
  if kind=='string':strings.append(json.loads(text))
  elif text=='(':depth+=1
  elif text==')':
   depth-=1
   if depth==0:
    assert tokens[i+1][1]==';'
    return strings,source[first:tokens[i+1][3]]
  i+=1
 raise AssertionError(name)
summaries,_=declaration('Summaries');assert len(summaries)==21
details={}
segments={}
for i in range(1,21):
 if i==17:continue
 strings,segment=declaration(f'MoreDetails_{i}')
 details[i]=''.join(strings);segments[str(i)]=segment
details[17]=details[16]
assert 'object);' in details[12] and details[12].endswith('<CRE>')

# Independent end selection: after masking quoted strings/comments, the first
# actual ");" following each declaration is its terminator; compare payloads.
masked=list(source)
for m in token.finditer(source):
 if m.lastgroup in ('string','comment'):
  for j in range(m.start(),m.end()):masked[j]=' '
mask=''.join(masked)
for i in range(1,21):
 if i==17:continue
 match=re.search(r'\bMoreDetails_'+str(i)+r'\s*\(',mask);assert match
 end=mask.index(');',match.end())+2
 payload=''.join(json.loads(m.group()) for m in re.finditer(r'"(?:[^"\\]|\\.)*"',source[match.end():end]))
 assert payload==details[i]

path='crates/ep_runtime/src/heat_balance/source_initialization/program_completion_tables.rs'
row=next(x for x in draft['files'] if x['canonical_path']==path)
p=R/row['proposed']['path'];old=(OLD/'proposed'/path).read_bytes()
body='pub(super) const SUMMARIES:[&str;20]=['+','.join(json.dumps(s) for s in summaries[1:])+'];\n'
body+='pub(super) const MORE_DETAILS:[&str;20]=['+','.join(json.dumps(details[i]) for i in range(1,21))+'];\n'
p.write_bytes(body.encode())
r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','files',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,r.stderr
new=p.read_bytes();assert b'\r' not in new
for direction,a,b in [('forward',b'',new),('inverse',new,b'')]:
 q=R/row[direction+'_diff']['path'];q.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='before/'+path,tofile='proposed/'+path)).encode());row[direction+'_diff']=ref(q)
row['proposed']=ref(p)
# One direct correction pair authenticates exact original proposal recovery.
for direction,a,b in [('forward',old,new),('inverse',new,old)]:
 q=O/f'tables-correction.{direction}.diff';q.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='original01/'+path,tofile='corrected02/'+path)).encode())

primitive=(D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text();fn=next(v for v in ast.parse(primitive).body if isinstance(v,ast.FunctionDef) and v.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal', 'exec'),ns);apply=ns['apply_literal']
assert apply(old,(O/'tables-correction.forward.diff').read_bytes())==new
assert apply(new,(O/'tables-correction.inverse.diff').read_bytes())==old
equal=[]
for x in draft['files']:
 q=R/x['proposed']['path'];before=b'' if x['before_absent'] else (R/x['before']['path']).read_bytes()
 assert apply(before,(R/x['forward_diff']['path']).read_bytes())==q.read_bytes()
 assert apply(q.read_bytes(),(R/x['inverse_diff']['path']).read_bytes())==before
 run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(q)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert run.returncode==0,run.stderr
 out=R/x['Source_only_parse']['stdout']['path'];err=R/x['Source_only_parse']['stderr']['path'];out.write_bytes(run.stdout);err.write_bytes(run.stderr)
 x['Source_only_parse']={'exit_code':0,'stdout':ref(out),'stderr':ref(err)}
 original=(OLD/'proposed'/x['canonical_path']).read_bytes()
 equal.append({'canonical_path':x['canonical_path'],'whole_equal01':original==q.read_bytes()})
assert sum(x['whole_equal01'] for x in equal)==24
write(O/'tables-correction-proof.json',{'finding':'Native MoreDetails_12 quoted object); prematurely terminated original regex; missing diagnostic continuation',
 'rejected_original_draft':ref(OLD/'draft.json'),'original_proposal':ref(OLD/'proposed'/path),'corrected_proposal':ref(p),
 'forward':ref(O/'tables-correction.forward.diff'),'inverse':ref(O/'tables-correction.inverse.diff'),
 'all20_summaries_and_details_rederived_from_pinned_Native_source':True,'independent_masked_terminator_extraction_equal':True,
 'changed_detail_indices_one_based':[12],'corrected_detail12':details[12],'old_detail12':re.findall(r'"(?:[^"\\]|\\.)*"',old.decode().split('MORE_DETAILS',1)[1])[11],
 'whole_source_identity':equal,'24_other_proposed_wholes_equal':True,'fresh_syntax_parses':25,'canonical_literal_applications':50,'correction_literal_applications':2,
 'no_math_input_expected_threshold_test_or_canonical_mutation':True})
write(O/'source-constant-extraction.json',{'Native_DataErrorTracking':ref(R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/DataErrorTracking.hh'),
 'summaries20':summaries[1:],'more_details20':[details[i] for i in range(1,21)],'real_declaration_segments':segments,
 'comment':'Source constants only, never Native produced output/fixture answers; lexer honors C++ string/comment boundaries.'})
# Refresh copied reference-bearing artifacts only where their referred row changed.
custody=json.loads((O/'literal-custody-proof.json').read_bytes());custody=relocate(custody)
for v in custody['literal_applications']:
 if v['canonical_path']==path:v['proposed_sha256']=row['proposed']['sha256']
custody['summary_tables20_independently_reextracted_exact']=True;custody['supersedes_original_regex_selfcheck']=True;write(O/'literal-custody-proof.json',custody)
draft['literal_custody']=ref(O/'literal-custody-proof.json')
census=json.loads((O/'concrete-API-and-producer-census.json').read_bytes())
for v in census['matches']:
 if v['canonical_path']==path:v['sha256']=row['proposed']['sha256'];v['bytes']=row['proposed']['bytes']
write(O/'concrete-API-and-producer-census.json',census)
draft['concrete_API_and_producer_census']=ref(O/'concrete-API-and-producer-census.json')
draft['original_draft']=ref(OLD/'draft.json');draft['correction_proof']=ref(O/'tables-correction-proof.json');draft['source_constant_extraction']=ref(O/'source-constant-extraction.json')
draft['correction_author_Source']=ref(Path(__file__).resolve())
draft['original_regex_selfcheck_rejected']=True
write(O/'draft.json',draft)
print(json.dumps(ref(O/'draft.json')))

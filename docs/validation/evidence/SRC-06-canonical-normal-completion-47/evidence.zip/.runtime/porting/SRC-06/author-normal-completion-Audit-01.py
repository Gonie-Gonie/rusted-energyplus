"""Isolated prospective finite Source wrapUp/End continuation. Never writes canonical."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess
R=Path.cwd();D=R/'.runtime/porting/SRC-06';O=D/'source-normal-completion-author-Audit-01'
O.mkdir(exist_ok=True);P=O/'proposed';B=O/'before'
A=json.loads((D/'source-ancillary-transport-admission-draft-Audit-02/draft.json').read_bytes())
anc={x['canonical_path']:x for x in A['files']}
changes={}
def parent(p):
 q=R/anc[p]['proposed']['path'] if p in anc else R/p
 return q.read_bytes()
def put(p,b):
 if isinstance(b,str):b=b.encode()
 changes[p]=b;q=P/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
def edit(p,a,b,count=1):
 old=changes.get(p,parent(p)); a=a.encode();b=b.encode();assert old.count(a)==count,(p,old.count(a),a[:90]);put(p,old.replace(a,b))
def append(p,s):put(p,changes.get(p,parent(p))+s.encode())
HB='crates/ep_runtime/src/heat_balance/'
# Carry accepted ancillary proposals byte-whole, then make literal successors.
for p,v in anc.items():put(p,(R/v['proposed']['path']).read_bytes())

timer=r'''//! Native Timer system-clock lifetime and millisecond/F2 formatting.
use crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError as Error;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SourceRuntimeTimer {
    start: SystemTime,
    end: SystemTime,
    duration_milliseconds: i64,
}
impl Default for SourceRuntimeTimer {
    fn default() -> Self { Self { start: UNIX_EPOCH, end: UNIX_EPOCH, duration_milliseconds: 0 } }
}
impl SourceRuntimeTimer {
    // Timer.cc57-61: tick does not reset accumulated duration.
    pub(crate) fn tick(&mut self) { self.end=UNIX_EPOCH; self.start=SystemTime::now(); }
    pub(crate) fn tock(&mut self) -> Result<(),Error> {
        if self.start==UNIX_EPOCH { return Err(Error::Unavailable("actual Timer.tock before tick")); }
        self.end=SystemTime::now();
        let delta=match self.end.duration_since(self.start) {
            Ok(v)=>i64::try_from(v.as_millis()).map_err(|_|Error::Unavailable("actual Timer duration signed milliseconds"))?,
            Err(v)=>i64::try_from(v.duration().as_millis()).ok().and_then(i64::checked_neg).ok_or(Error::Unavailable("actual negative Timer duration signed milliseconds"))?,
        };
        self.duration_milliseconds=self.duration_milliseconds.checked_add(delta).ok_or(Error::Unavailable("actual Timer accumulated duration signed milliseconds"))?;
        Ok(())
    }
    pub(crate) fn format_as_hour_min_secs(&self) -> Result<String,Error> {
        if self.end==UNIX_EPOCH { return Err(Error::Unavailable("actual Timer duration before tock")); }
        let mut count=self.duration_milliseconds;
        let hours=count/3_600_000; count-=hours*3_600_000;
        let minutes=count/60_000; count-=minutes*60_000;
        let mut seconds=count as f64/1000.0;
        if seconds<0.0 { seconds=0.0; }
        let seconds=crate::heat_balance::ctf_reports::formatting::fixed(seconds,5,2);
        Ok(format!("{hours:02}hr {minutes:02}min {seconds}sec"))
    }
}
'''
put(HB+'source_initialization/runtime_timer.rs',timer)
edit(HB+'source_initialization.rs','mod output_reporting;','mod output_reporting;\nmod runtime_timer;\npub(crate) use runtime_timer::SourceRuntimeTimer;\nmod program_completion;')
edit(HB+'selected_project_data.rs','pub(crate) struct ProjectSystemVariables {','pub(crate) struct ProjectSystemVariables {\n    /// Same SystemVarsData.runtimeTimer; actual commonInitialize ticks before Source IP.\n    pub(crate) runtime_timer: super::source_initialization::SourceRuntimeTimer,')
edit(HB+'source_initialization.rs','        project.resolve_environment_operands(','        // Actual commonInitialize277 precedes processEnvironmentVariables.\n        // This is the retained Source wrapper start, before actual Source IP;\n        // Rust conversion/compilation earlier in the CLI is outside this timer.\n        project.system.runtime_timer.tick();\n        project.resolve_environment_operands(')
edit(HB+'selected_heat_balance_globals.rs','pub(crate) struct SelectedHeatBalanceGlobals {','pub(crate) struct SelectedHeatBalanceGlobals {\n    /// DataGlobals.hh88/172 ctorfalse; this frontend has no ReadVars/API setter.\n    pub(crate) run_read_vars: bool,\n    pub(crate) running_via_api: bool,')

# Actual unmodeled DataErrTracking members form one disjoint partial group;
# the existing six counters/match counts stay on their sole original backend owner.
state=r'''//! Remaining actual constructor cells consumed at normal program completion.
#![allow(dead_code)]
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct SourceRecurringErrorState {
    pub(crate) number: i32,
    pub(crate) rows: Option<Vec<std::convert::Infallible>>,
}
/// Native ResultsFramework::SimInfo's real string members, no reporting snapshots.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct SourceSimulationInformation {
    pub(crate) program_version: String,
    pub(crate) simulation_environment: String,
    pub(crate) input_model_uri: String,
    pub(crate) start_date_time_stamp: String,
    pub(crate) run_time: String,
    pub(crate) warnings_warmup: String,
    pub(crate) severe_warmup: String,
    pub(crate) warnings_sizing: String,
    pub(crate) severe_sizing: String,
    pub(crate) warnings: String,
    pub(crate) severe: String,
}
'''
put(HB+'source_initialization/program_state.rs',state)
edit(HB+'source_initialization.rs','mod program_completion;','mod program_completion;\nmod program_state;\npub(crate) use program_state::{SourceRecurringErrorState, SourceSimulationInformation};')
edit(HB+'ctf_initialization_context.rs','pub struct CtfInitializationReports {','pub struct CtfInitializationReports {\n    /// Sole previously unmodeled NumRecurringErrors/RecurringErrors cells from DataErrTracking.\n    /// Positive recording producers are still explicit diagnostic boundaries.\n    pub(crate) source_recurring_errors: super::source_initialization::SourceRecurringErrorState,')
edit(HB+'ordinary_output_control.rs','pub(crate) struct SourceResultsFrameworkOptions {','pub(crate) struct SourceResultsFrameworkOptions {\n    pub(crate) simulation_information: super::source_initialization::SourceSimulationInformation,')
edit(HB+'ordinary_output_control.rs','            meter_data_dictionary: Vec::new(),','            simulation_information: Default::default(),\n            meter_data_dictionary: Vec::new(),')
edit(HB+'source_output_registration.rs','    pub(crate) requested_variables: Vec<SourceRequestedVariable>,','    /// Actual GenOutputVariablesAuditReport once-message latches, ctorfalse.\n    pub(crate) ungenerated_report_warning: bool,\n    pub(crate) opaque_surface_warning: bool,\n    pub(crate) requested_variables: Vec<SourceRequestedVariable>,')
edit(HB+'source_output_registration.rs','            requested_variables: Vec::new(),','            ungenerated_report_warning: false,\n            opaque_surface_warning: false,\n            requested_variables: Vec::new(),')

# Genuine retained SolarShading counters: all actual positive producer paths in
# the current finite port stop before CHKSBS/MULTOL diagnostic tracking writes.
edit(HB+'radiation/ordinary/solar_timestep/state.rs','pub(crate) struct SourceSolarTimestepState {','pub(crate) struct SourceSolarTimestepState {\n    /// SolarShading.hh413-415 real constructors; no output-derived count.\n    pub(crate) num_too_many_figures: i32,\n    pub(crate) num_too_many_vertices: i32,\n    pub(crate) num_base_sub_surround: i32,')
edit(HB+'radiation/ordinary/solar_timestep/state.rs','            shading: SourceSolarShadingArrays::default(), heat_balance: SourceSolarHeatBalanceArrays::default(),','            num_too_many_figures: 0, num_too_many_vertices: 0, num_base_sub_surround: 0,\n            shading: SourceSolarShadingArrays::default(), heat_balance: SourceSolarHeatBalanceArrays::default(),')

append(HB+'selected_input_processor.rs',r'''
impl SelectedInputProcessor {
    /// Same ordered unusedInputs set after every actual getter/markObjectAsUsed.
    pub(crate) fn source_unused_objects(&self) -> impl Iterator<Item=(&str,&str)> {
        self.unused_inputs.iter().map(|(kind,name)|(kind.as_str(),name.as_str()))
    }
}
''')
append(HB+'ordinary_daylighting.rs',r'''
impl SourceDaylighting {
    pub(crate) fn close_source_illuminance_maps(&self) -> Result<(),Error> {
        if self.illuminance_maps.as_ref().is_some_and(|v|!v.is_empty()) {
            return Err(Error::Unavailable("actual CloseReportIllumMaps MapColSep9329"));
        }
        Ok(())
    }
}
''')
append(HB+'ordinary_external_interface.rs',r'''
impl SourceExternalInterface {
    pub(crate) fn close_source_socket_at_success(&self) -> Result<(),Error> {
        if self.number_external_interfaces>0 && self.have_bcvtb {
            return Err(Error::Unavailable("actual EndEnergyPlus ExternalInterface.CloseSocket592"));
        }
        Ok(())
    }
}
''')
append(HB+'source_initialization/output_reporting.rs',r'''
impl SourceSqliteState {
    pub(crate) fn reset_source_pointer(&mut self) { self.database=None; }
}
''')

# Real caller-owned output paths; no opening or normalization in a comparator.
edit(HB+'source_initialization/files.rs','    pub debug: PathBuf,','    pub debug: PathBuf,\n    /// Actual local END, native-style ERR, and retained DFS paths from this frontend.\n    pub end: PathBuf,\n    pub error: PathBuf,\n    pub dfs: PathBuf,')
edit(HB+'source_initialization/files.rs','    debug: SourceOutputStream,','    debug: SourceOutputStream,\n    end: PathBuf,\n    error: PathBuf,\n    dfs: SourceOutputStream,')
edit(HB+'source_initialization/files.rs','            debug: SourceOutputStream::new(paths.debug),','            debug: SourceOutputStream::new(paths.debug),\n            end: paths.end,\n            error: paths.error,\n            dfs: SourceOutputStream::new(paths.dfs),')
append(HB+'source_initialization/files.rs','\nmod program_end;\n')
edit(HB+'source_initialization/files/endrun.rs','    fn close_source_output(&mut self) {','    pub(super) fn close_source_output(&mut self) {')
edit(HB+'source_initialization/files/endrun.rs','    fn delete_source_output(&mut self) -> io::Result<()> {','    pub(super) fn delete_source_output(&mut self) -> io::Result<()> {')
edit('crates/ep_run/src/ctf_initialization_outputs.rs','                    debug: output_dir.join("eplusrs.dbg"),','                    debug: output_dir.join("eplusrs.dbg"),\n                    end: output_dir.join("eplusrs.end"),\n                    error: output_dir.join("eplusrs.err"),\n                    dfs: output_dir.join("eplusrs.dfs"),')

file_end=r'''//! Genuine local END open/write and CloseMiscOpenFiles retained handles.
use super::{SourceInitializationFiles,native_text_bytes};
use crate::heat_balance::ordinary_output_control::SourceOutputControl;
use crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError as Error;
use crate::heat_balance::error_backend::{SourceErrorBackend,SourceDiagnosticFlags};
use std::io::{Seek,Write};
impl SourceInitializationFiles {
    /// Persist the genuine backend's logical stream at its own physical ERR host.
    /// Structured CLI diagnostics have a separate artifact and are not input here.
    /// # Errors
    /// Propagates the actual filesystem write failure.
    pub fn persist_source_error(&self,logical:&[u8])->std::io::Result<()> {
        std::fs::write(&self.error,native_text_bytes(logical).as_ref())
    }
    pub(crate) fn close_source_misc_files(&mut self,debug_output:bool)->Result<(),Error> {
        // CloseDFSFile always resets the same optional os; a missing handle stays missing.
        self.dfs.close_source_output();
        let keep=if debug_output {true} else if self.debug.file.is_some()&&!self.debug.failed {
            self.debug.file.as_mut().ok_or(Error::Unavailable("actual same debug file"))?.stream_position()?>0
        } else {false};
        if keep {self.debug.close_source_output();} else {self.debug.delete_source_output()?;}
        Ok(())
    }
    pub(crate) fn write_source_program_end(&self,control:&SourceOutputControl,row:&str,backend:&mut SourceErrorBackend<'_>,flags:&SourceDiagnosticFlags<'_>)->Result<(),Error> {
        if !control.end {return Err(Error::Unavailable("actual END try_open disabled null-buffer stream574"));}
        let opened=std::fs::OpenOptions::new().read(true).write(true).create(true).truncate(true).open(&self.end);
        let mut file=match opened {Ok(v)=>v,Err(e)=>{
            backend.display_source_string(&format!("EndEnergyPlus: Could not open file {} for output (write).",self.end.display()),flags)?;
            return Err(e.into());
        }};
        let logical=format!("{row}\n");let bytes=native_text_bytes(logical.as_bytes());
        file.write_all(bytes.as_ref())?;file.flush()?;Ok(())
    }
    pub(crate) fn close_source_program_audit(&mut self) {self.audit.close_source_output();}
}
'''
put(HB+'source_initialization/files/program_end.rs',file_end)

# Native summary string tables are source constants, never output/test answers.
hh=(R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/DataErrorTracking.hh').read_text()
quoted=lambda s:[json.loads(x) for x in re.findall(r'"(?:[^"\\]|\\.)*"',s)]
summaries=quoted(hh.split('constexpr Summaries({',1)[1].split('});',1)[0]);assert len(summaries)==21
details={}
for n,chunk in re.findall(r'auto constexpr MoreDetails_(\d+)\((.*?)\);',hh,re.S):details[int(n)]=''.join(quoted(chunk))
assert set(details)==set(range(21))-{17};details[17]=details[16]
tables='pub(super) const SUMMARIES:[&str;20]=['+','.join(json.dumps(s) for s in summaries[1:])+'];\n'
tables+='pub(super) const MORE_DETAILS:[&str;20]=['+','.join(json.dumps(details[i]) for i in range(1,21))+'];\n'
put(HB+'source_initialization/program_completion_tables.rs',tables)

# The remaining completion body is kept in a separate author-owned text below;
# this script only composes a prospective isolated Source overlay.
completion=(D/'normal-completion-body-Audit-01.rs').read_bytes()
put(HB+'source_initialization/program_completion.rs',completion)

append('crates/ep_run/src/ctf_initialization_outputs.rs',r'''
impl CtfRunOutputs {
    pub(crate) fn complete_source_program(&mut self,weather:&ep_runtime::weather::day::ProductionWeatherTimestepSeries)->Result<(),String> {
        let files=self.initialization_files.as_mut().ok_or("actual files before normal program completion")?;
        {
        let mut backend=SourceErrorBackend{state:&mut self.state,error_stream:Some(&mut self.error),console:&mut self.console,out_unit1:None,out_unit2:None,f_message:None,message_callback:None,error_callback:None,sqlite:None};
        files.complete_source_program(&mut self.reports,&mut self.source_session,weather,&mut backend).map_err(|e|e.to_string())?;
        }
        files.persist_source_error(&self.error).map_err(|e|e.to_string())
    }
}
''')
# Source successful ERR is its actual backend only. Legacy persist stays exact.
edit('crates/ep_run/src/pipeline.rs','                let reports = ctf_outputs.read_completed_source_reports()?;','                ctf_outputs.complete_source_program(weather)?;\n                let reports = ctf_outputs.read_completed_source_reports()?;')
old='''    write_error_summary(
        &config.output_dir,
        &render_eplusrs_err(&diagnostics, exit_code),
    )
    .map_err(|error| RunError::new(RunExitCode::OutputExport, error))?;'''
new='''    if !matches!(rust_runtime_result,Some(RuntimeExecutionOutcome::Source(_))) {
        write_error_summary(
            &config.output_dir,
            &render_eplusrs_err(&diagnostics, exit_code),
        )
        .map_err(|error| RunError::new(RunExitCode::OutputExport, error))?;
    }'''
p='crates/ep_run/src/pipeline.rs';body=changes[p];marker=b'fn finish_successful_summary(';pos=body.index(marker)
assert body[pos:].count(old.encode())==1
put(p,body[:pos]+body[pos:].replace(old.encode(),new.encode()))
# Freeze mechanical evidence only when all draft files are coherent. This is
# still an unsealed author overlay; canonical parent/final plan comes later.
def ref(p):return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
for p,b in list(changes.items()):
 if not (R/p).exists() and p not in anc:
  run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','files',str(P/p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert run.returncode==0,(p,run.stderr)
  put(p,(P/p).read_bytes())
rows=[]
for i,(p,b) in enumerate(sorted(changes.items()),1):
 q=P/p; before=(R/p).read_bytes() if (R/p).exists() else b''
 if p in anc:
  expected=b'' if anc[p]['before_absent'] else (R/anc[p]['before']['path']).read_bytes()
  assert before==expected,(p,'canonical before differs from authenticated ancillary02 before')
 old=B/p;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(before)
 diff=O/'diffs';diff.mkdir(exist_ok=True)
 for name,a,z in [('forward',before,b),('inverse',b,before)]:
  v=diff/f'{i:02}.{name}.diff';v.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),z.decode().splitlines(keepends=True),fromfile='before/'+p,tofile='proposed/'+p)).encode())
 parse=O/'parse';parse.mkdir(exist_ok=True)
 run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(q)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (parse/f'{i:02}.stdout').write_bytes(run.stdout);(parse/f'{i:02}.stderr').write_bytes(run.stderr)
 assert run.returncode==0,(p,run.stderr)
 rows.append({'canonical_path':p,'before_absent':not bool(before),'before':ref(old) if before else None,'proposed':ref(q),'forward_diff':ref(diff/f'{i:02}.forward.diff'),'inverse_diff':ref(diff/f'{i:02}.inverse.diff'),'Source_only_parse':{'exit_code':run.returncode,'stdout':ref(parse/f'{i:02}.stdout'),'stderr':ref(parse/f'{i:02}.stderr')}})
(O/'status.json').write_text(json.dumps({'status':'UNSEALED_AUTHOR_OVERLAY_SYNTAX_ONLY_NOT_TYPECHECKED','files':rows,'Source_only_parses':len(rows),'new_Source_files_formatted_with_rustfmt_before_evidence':True,'logical_ancillary02':{'path':'.runtime/porting/SRC-06/source-ancillary-transport-admission-draft-Audit-02/draft.json','sha256':'6caddde6aa05b7102ff65abcfdc651091e38b9726b8fe45f3968c2cd7c4a8903'},'no_Cargo_Native_or_canonical_mutation':True},indent=2)+'\n')
print('isolated author files',len(rows))

"""Root-only sequential real CLI execution; stops on any actual failure."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
PLAN = '.runtime/porting/SRC-06/normal-completion-commands-ready-Audit-47/plan.json#f42b07ce82b5541021976de7d16187646503bcd89890a4d2517cb72db4143ccb'
APP = '.runtime/porting/SRC-06/Root-normal-completion-application-47/receipt.json#d5f0823be751c22188edac5268e03e2554e7c7bdafe19ac6a85352b2fb58f6e5'

def main():
    spec = importlib.util.spec_from_file_location('guards47', D / 'normal-completion-command-guards-Audit-47.py')
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    qr, q, m, plan = g.authority(PLAN)
    ar, application = g.application(APP, plan)
    out = D / 'Root-normal-completion-remaining-six-driver-47'
    assert not out.exists()
    first = R / q['cases'][0]['receipt']
    assert g.ref(first)['sha256'] == '80972645d3da545fd3a3322f229d2a44ae6af5bc14a49f370c8cb1244859bf81'
    assert g.read(first)['exit_code'] == 0
    out.mkdir()
    rows = []
    failure = None
    try:
        for case in q['cases'][1:]:
            name = case['case']
            print('START ' + name, flush=True)
            cmd = [sys.executable, str(g.checked(q['launch_Source'])), name, '--plan', PLAN, '--application', APP, '--execute']
            stdout = out / (name + '.stdout.log')
            stderr = out / (name + '.stderr.log')
            with stdout.open('wb') as so, stderr.open('wb') as se:
                actual = subprocess.run(cmd, cwd=R, env=g.environment(), stdout=so, stderr=se)
            row = dict(case=name, command=cmd, launcher_exit_code=actual.returncode, stdout=g.ref(stdout), stderr=g.ref(stderr))
            rows.append(row)
            assert actual.returncode == 0, row
            receipt = g.read(R / case['receipt'])
            row['receipt'] = g.ref(R / case['receipt'])
            assert receipt['exit_code'] == 0 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
            summary_path = R / case['output'] / 'run-summary.json'
            summary = g.read(summary_path)
            assert summary['exit_code'] == 0 and summary['comparison'] is None and summary['oracle'] is None
            assert summary['oracle_status'] == summary['compare_status'] == 'not-requested'
            cfg = summary['config']
            assert cfg['hours'] is None and cfg['oracle_baseline'] is False and cfg['compare_oracle'] is False and cfg['partial_policy'] == 'deny'
            runtime = summary['rust_runtime']
            assert runtime['execution'] == 'actual Source ManageSimulation successful through620'
            expected_hours = 8760 if name.endswith('ANNUAL') else (72 if name.endswith('72H') else 24)
            assert runtime['native_environment_hour_scope'] == expected_hours
            row['run_summary'] = g.ref(summary_path)
            row['actual_hours'] = expected_hours
            print('DONE ' + name + ' actual0 stable/noOracle through620', flush=True)
    except Exception as error:
        failure = dict(type=type(error).__name__, message=str(error))
    result = dict(schema='src06-normal-completion-remaining-six-driver47.v1', accepted=failure is None, findings=[] if failure is None else [failure], command_plan=qr, application=ar, first_B24_receipt=g.ref(first), actual_runs=rows, author_Source=g.ref(Path(__file__)), qualification='Only actual normal CLI execution sanity; no scientific/ancillary/own-export comparison PASS inferred.')
    rp = out / 'receipt.json'
    rp.write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(g.ref(rp)), flush=True)
    return 0 if failure is None else 1

if __name__ == '__main__':
    raise SystemExit(main())

"""Repair one private metadata string; no public or canonical file writes."""
from pathlib import Path
import hashlib, json
R = Path(__file__).resolve().parents[3]; D = R / '.runtime/porting/SRC-06'
O = D / 'normal-completion-publication-ready-Audit-47-03'


def ref(p):
    b = p.read_bytes(); return dict(path=p.relative_to(R).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))


def main():
    assert not O.exists()
    oldp = D / 'normal-completion-publication-ready-Audit-47-02/template.json'
    assert ref(oldp)['sha256'] == '6d06cad1411eaae95417bff4bf628a657fa060631a89f4e603fe1b03bcd66d88'
    originalp = D / 'normal-completion-publication-ready-Audit-47/template.json'
    assert ref(originalp)['sha256'] == '81a5171e19a6cd5cdbe39dd2e8a627008713ac69a5b36e4837c27d94f2d6c8d6'
    old = json.loads(oldp.read_bytes()); original = json.loads(originalp.read_bytes())
    broken = old['doc_appends']['cards/SRC-06.md']; assert '?' in broken
    good = original['doc_appends']['cards/SRC-06.md']
    before = '5\uac1c 24H \ubb3c\ub9ac\u00b7\uc790\uccb4 \ub0b4\ubcf4\ub0b4\uae30\ub294'
    after = '5\uac1c 24H\uc758 \uc120\ud0dd\ub41c 7\uc885 \ubb3c\ub9ac \ud30c\uc77c\uacfc \uc790\uccb4 \ub0b4\ubcf4\ub0b4\uae30\ub294'
    assert good.count(before) == 1
    good = good.replace(before, after, 1)
    assert '?' not in good and '\ufffd' not in good and good.encode('utf8').decode('utf8') == good
    publisher = D / 'publish-normal-completion-Root-47.py'
    assert ref(publisher)['sha256'] == 'd62493864fbbaeeb43caa6c93c6bc9107cb6c4025c70a6b13af1f0b09df152bc'
    label = '[Source47 \uc815\uc0c1 \uc644\ub8cc]'
    assert label in publisher.read_text(encoding='utf8')
    O.mkdir()
    proof = dict(schema='src06-normal47-card-metadata-encoding-repair.v1', rejected_private_template=ref(oldp), original_valid_UTF8_template=ref(originalp), JSON_pointer='/doc_appends/cards~1SRC-06.md', old_actual_broken_literal=broken, corrected_UTF8_literal=good, corrected_ASCII_unicode_escape=good.encode('unicode_escape').decode('ascii'), publisher_unchanged=ref(publisher), actual_publisher_label_unicode_escape=label.encode('unicode_escape').decode('ascii'), cause='Inline PowerShell pipe encoded the Korean metadata as literal question marks before Python consumed it; preserved02 never published.', canonical_or_public_writes=0, author_Source=ref(Path(__file__)))
    proofp = O / 'card-encoding-repair.json'; proofp.write_text(json.dumps(proof, ensure_ascii=True, indent=2) + '\n', encoding='ascii', newline='\n')
    new = json.loads(json.dumps(old)); new['doc_appends']['cards/SRC-06.md'] = good
    inverse = json.loads(json.dumps(new)); inverse['doc_appends']['cards/SRC-06.md'] = broken; assert inverse == old
    new['card_encoding_repair'] = ref(proofp)
    new['finite_archive_inputs'] += [ref(oldp), ref(proofp), ref(Path(__file__))]
    p = O / 'template.json'; p.write_text(json.dumps(new, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
    actual = json.loads(p.read_bytes())
    assert actual['doc_appends']['cards/SRC-06.md'] == good and all('?' not in x and '\ufffd' not in x for x in actual['doc_appends'].values())
    print(json.dumps(dict(template=ref(p), repair=ref(proofp), publisher=ref(publisher), card_unicode_escape=good.encode('unicode_escape').decode('ascii'), no_canonical_writes=True), ensure_ascii=True))


if __name__ == '__main__': main()

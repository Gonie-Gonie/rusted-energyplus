"""Root-only finite evidence publication; never launches any scientific run."""
from pathlib import Path
import argparse, hashlib, json, subprocess, zipfile
R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
PUBLIC = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-normal-completion-47'
BACK = D / 'normal-completion-publication-readback-Audit-47'


def ref(p):
    p = p.resolve()
    with p.open('rb') as f:
        h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(), sha256=h, bytes=p.stat().st_size)


def checked(row):
    p = (R / row['path']).resolve(); assert p.is_relative_to(R)
    value = ref(p); assert value['sha256'] == row['sha256'] and value['bytes'] == row.get('bytes', value['bytes'])
    return p


def read(p):
    return json.loads(p.read_bytes())


def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')


def main(a):
    assert a.publish and not PUBLIC.exists() and not BACK.exists()
    tp = (R / a.template).resolve(); t = read(tp)
    assert t['status'] == 'READY_FOR_ROOT_FULL_READ_AND_PUBLICATION' and t['publisher_Source'] == ref(Path(__file__))
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(); assert head == t['base_HEAD']
    actual = read(checked(t['actual_review'])); m = read(checked(t['producer'])); plan = read(checked(t['complete_compiler_plan']))
    assert actual['accepted'] and not actual['findings'] and actual['producer'] == t['producer'] and actual['application'] == t['application']
    assert actual['complete_compiler_plan'] == t['complete_compiler_plan'] and actual['same4523_archived_inputs_exact_final_plan_and_live'] and actual['selected25_final_sources_exact']
    assert actual['actual_production_CLI_invocations'] == 7 and actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0
    assert actual['all_normal_featureNone_core_artifacts_exact_first_false_rest_true'] and actual['five24_whole43_physical_and_export_transfers'] and actual['A_current_reported_policy_pass']
    assert actual['annual_own_JSON_CSV_roundtrip_claim'] is False and len(actual['current_A_strict_reported_comparisons']) == 3
    assert (plan['inputs'], plan['Rust_sources'], len(m['files'])) == (4523, 4510, 25) and sum(x['before_absent'] for x in m['files']) == 6
    peer = read(checked(m['independent_full_semantic_peer'])); assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft'] == m['original_draft']
    rows = {x['path']: x for x in plan['entries']}
    archived = {x['historical_path']: x for x in read(checked(actual['actual_snapshot']))['files']}
    assert len(rows) == len(archived) == 4523 and rows.keys() == archived.keys()
    for name, row in rows.items():
        v = ref(R / name); assert (v['sha256'], v['bytes']) == (row['final_sha256'], row['final_bytes']) == (archived[name]['archive']['sha256'], archived[name]['size_bytes'])
    for f in m['files']:
        assert (R / f['canonical_path']).read_bytes() == checked(f['proposed']).read_bytes()
    docs = {name: (R / 'energyplus_porting_plan' / name).read_bytes() for name in t['doc_appends']}
    pp = R / 'energyplus_porting_plan/plan.json'; before = pp.read_bytes(); before_value = json.loads(before)
    assert before == subprocess.check_output(['git', 'show', head + ':energyplus_porting_plan/plan.json'], cwd=R)
    for name, raw in docs.items():
        assert raw == checked(t['doc_before'][name]).read_bytes() == subprocess.check_output(['git', 'show', head + ':energyplus_porting_plan/' + name], cwd=R)
        assert '\ufffd' not in raw.decode('utf8', 'strict') and '\ufffd' not in t['doc_appends'][name]
    previous = read(checked(t['previous_checkpoint'])); assert (previous['A'], previous['B']) == ('14/54', '14/64')
    files = {}

    def add(row):
        p = checked(row); v = ref(p)
        assert p.suffix.lower() not in ['.zip', '.exe', '.obj', '.dll', '.a'] and v['bytes'] < 64 * 1024 * 1024
        assert v['path'] not in files or files[v['path']]['ref'] == v
        files[v['path']] = dict(path=p, ref=v)

    for row in t['finite_archive_inputs'] + actual['publication_artifacts']:
        add(row)
    for row in [ref(Path(__file__)), ref(tp), t['actual_review']]:
        add(row)
    assert sum(x['ref']['bytes'] for x in files.values()) < 64 * 1024 * 1024
    PUBLIC.mkdir(parents=True); BACK.mkdir()
    (BACK / 'plan-before.json').write_bytes(before)
    for name, raw in docs.items():
        p = BACK / 'docs-before' / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(raw)
    zp = PUBLIC / 'evidence.zip'
    with zipfile.ZipFile(zp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, row in sorted(files.items()):
            assert ref(row['path']) == row['ref']; z.write(row['path'], arcname=name)
    with zipfile.ZipFile(zp) as z:
        assert z.testzip() is None and set(z.namelist()) == set(files)
        for name, row in files.items():
            payload = z.read(name); assert len(payload) == row['ref']['bytes'] and hashlib.sha256(payload).hexdigest() == row['ref']['sha256']
    mp = PUBLIC / 'manifest.json'
    write(mp, dict(schema='src06-normal-completion47-finite-evidence.v1', archive=ref(zp), entries=[x['ref'] for _, x in sorted(files.items())], scope=t['finite_archive_scope']))
    summary = dict(t['summary_template'])
    summary.update(schema='src06-canonical-normal-completion47.v1', status='Normal Source completion owners and actual sevenCLI validation; ancillary differences retained', base_HEAD=head, producer=t['producer'], independent_full_semantic_peer=m['independent_full_semantic_peer'], application=t['application'], Root_actual_review=t['actual_review'], complete_compiler_plan=t['complete_compiler_plan'], parent_compiler_LF_bridge=actual['parent_compiler_LF_bridge'], actual_snapshot=actual['actual_snapshot'], actual_production_CLI_invocations=7, actual_test_bodies_executed=0, new_test_bodies=0, ordered_cases=actual['ordered_cases'], current_A_strict_reported_comparisons=actual['current_A_strict_reported_comparisons'], five24_whole43_physical_and_export_transfers=True, B24_policy_scope='Prior genuine43/45/46 reported proofs transfer only through current whole physical/CSV/JSON/runtime equality; no new Native run or internal-state inference.', annual_own_JSON_CSV_roundtrip_claim=False, overall_ancillary_IO_PASS=False, preserved_reader01_failure=actual['preserved_reader01_failure'], limitations=actual['limits'], archive=ref(zp), archive_manifest=ref(mp), archive_entries=len(files), publisher_Source=ref(Path(__file__)))
    sp = PUBLIC / 'summary.json'; write(sp, summary)
    relative = 'evidence/SRC-06-canonical-normal-completion-47/summary.json'
    doc_proofs = []
    for name, raw in docs.items():
        link = '../' + relative if name.startswith('cards/') else relative
        append = ('\n\n[Source47 정상 완료](' + link + '). ' + t['doc_appends'][name] + '\n').encode('utf8')
        p = R / 'energyplus_porting_plan' / name; assert p.read_bytes() == raw; p.write_bytes(raw + append)
        assert p.read_bytes()[:-len(append)] == raw
        doc_proofs.append(dict(path=p.relative_to(R).as_posix(), before=ref(BACK / 'docs-before' / name), after=ref(p), appended_UTF8_bytes=len(append), exact_append_inverse=True))
    after = json.loads(before); task = next(x for x in after['tasks'] if x['id'] == 'SRC-06'); key = 'canonical_normal_completion_47'; assert key not in task
    task[key] = dict(path=sp.relative_to(R).as_posix(), sha256=ref(sp)['sha256'], size_bytes=sp.stat().st_size)
    inverse = json.loads(json.dumps(after)); del next(x for x in inverse['tasks'] if x['id'] == 'SRC-06')[key]; assert inverse == before_value
    assert pp.read_bytes() == before; write(pp, after)
    rp = BACK / 'publication-readback.json'
    write(rp, dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_COMMIT', summary=ref(sp), archive=ref(zp), archive_manifest=ref(mp), archive_entries=len(files), docs=doc_proofs, plan_before=ref(BACK / 'plan-before.json'), plan_after=ref(pp), one_SRC06_key_inverse=True, base_HEAD=head, actual_Source_CLI_invocations=7, actual_test_bodies_executed=0, policy_changes=0, gate_changes=False, Cargo_Native_or_test_execution=False, author_Source=ref(Path(__file__))))
    print(json.dumps(ref(rp)))


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--template', required=True); p.add_argument('--publish', action='store_true'); main(p.parse_args())

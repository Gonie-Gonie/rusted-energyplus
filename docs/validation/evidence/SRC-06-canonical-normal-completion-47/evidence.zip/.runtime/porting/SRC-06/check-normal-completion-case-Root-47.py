"""Root-only, read-only case evidence after an actual normal Source47 CLI.

No CLI/engine/Cargo/test or comparison runs are launched by this reader.
Ancillary rows are retained raw; a different runtime is never a physical PASS.
"""
from pathlib import Path
import argparse, ast, base64, copy, hashlib, importlib.util, itertools, json, re

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
GUARDS = D / 'normal-completion-command-guards-Audit-47.py'
spec = importlib.util.spec_from_file_location('normal_completion_guards', GUARDS)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def ref(p):
    p = p.resolve()
    with p.open('rb') as f:
        h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(), sha256=h, bytes=p.stat().st_size)


def checked(row):
    p = (R / row['path']).resolve()
    assert p.is_relative_to(R)
    actual = ref(p)
    assert actual['sha256'] == row['sha256'] and actual['bytes'] == row.get('bytes', actual['bytes'])
    return p


def read(p):
    return json.loads(p.read_bytes())


def option(command, name):
    assert command.count(name) == 1
    return command[command.index(name) + 1]


def endings(raw):
    return dict(CRLF=raw.count(b'\r\n'), bare_LF=raw.count(b'\n') - raw.count(b'\r\n'), unterminated=bool(raw and not raw.endswith(b'\n')))


def exact_file(left, right):
    assert left.exists() == right.exists(), (left, right)
    if not left.exists():
        return dict(both_absent=True, current_path=left.relative_to(R).as_posix(), prior_path=right.relative_to(R).as_posix())
    a, b = ref(left), ref(right)
    assert (a['sha256'], a['bytes']) == (b['sha256'], b['bytes']), (left, right)
    return dict(current=a, accepted43=b, whole_bytes_equal=True)


def five24_transfer(source, prior):
    # These are true prior43 Source files, not injected Native output.
    streams = [exact_file(source / ('eplusrs.' + k), prior / ('eplusrs.' + k)) for k in ['eso', 'mtr', 'eio', 'rdd', 'mdd', 'shd', 'bnd']]
    exports = [exact_file(source / 'results' / ('source-' + k + '.csv'), prior / 'results' / ('source-' + k + '.csv')) for k in ['eso', 'mtr']]
    nowp, oldp = source / 'results/source-reported-results.json', prior / 'results/source-reported-results.json'
    now, old = nowp.read_bytes(), oldp.read_bytes()
    nv, ov = json.loads(now), json.loads(old)
    bridged = now
    for stream in ['eso', 'mtr']:
        assert Path(nv[stream]['path']).resolve() == (source / ('eplusrs.' + stream)).resolve()
        assert Path(ov[stream]['path']).resolve() == (prior / ('eplusrs.' + stream)).resolve()
        left, right = json.dumps(nv[stream]['path']).encode(), json.dumps(ov[stream]['path']).encode()
        assert bridged.count(left) == 1
        bridged = bridged.replace(left, right, 1)
    assert bridged == old, 'reported JSON changes beyond two actual owner paths'
    runtime = copy.deepcopy(read(source / 'run-summary.json')['rust_runtime'])
    previous = read(prior / 'run-summary.json')['rust_runtime']
    for a, b in zip(runtime['reported_streams'], previous['reported_streams'], strict=True):
        assert Path(a['owned_path']).resolve() == (source / Path(b['owned_path']).name).resolve()
        a['owned_path'] = b['owned_path']
    assert runtime == previous, 'runtime changes beyond two actual owner paths'
    return dict(physical_streams=streams, whole_CSV=exports, current_JSON=ref(nowp), accepted43_JSON=ref(oldp), whole_JSON_equal_after_exactly_two_owned_path_bridges=True, whole_runtime_equal_after_exactly_two_owned_path_bridges=True)


def ancillary(source, native, prefix, output):
    assert prefix in ['energyplusout', 'eplusout']
    pairs = [('eplusrs.' + k, prefix + '.' + k, k) for k in ['audit', 'bnd', 'eio', 'rdd', 'mdd', 'mtd', 'shd', 'err', 'end', 'dbg', 'edd']]
    pairs += [('eplustbl.' + k, prefix[:-3] + 'tbl.' + k, 'table.' + k) for k in ['csv', 'htm', 'tab', 'txt', 'xml']]
    known_s = {x[0] for x in pairs} | {'eplusrs.eso', 'eplusrs.mtr'}
    known_n = {x[1] for x in pairs} | {prefix + '.eso', prefix + '.mtr'}
    extras = {p.name[len('eplusrs.'):] for p in source.iterdir() if p.is_file() and p.name.startswith('eplusrs.') and p.name not in known_s}
    extras |= {p.name[len(prefix) + 1:] for p in native.iterdir() if p.is_file() and p.name.startswith(prefix + '.') and p.name not in known_n}
    pairs += [('eplusrs.' + k, prefix + '.' + k, 'extra.' + k) for k in sorted(extras)]
    ledger = output / 'all-ancillary-raw-differences.jsonl'
    rows, total, metadata = [], 0, 0
    with ledger.open('x', encoding='utf8', newline='\n') as out:
        for sn, nn, label in pairs:
            sp, np = source / sn, native / nn
            sb, nb = sp.read_bytes() if sp.exists() else b'', np.read_bytes() if np.exists() else b''
            row = dict(kind=label, Source_present=sp.exists(), Native_present=np.exists(), whole_bytes_equal=sp.exists() == np.exists() and sb == nb)
            if sp.exists():
                row.update(Source=ref(sp), Source_endings=endings(sb))
            if np.exists():
                row.update(Native=ref(np), Native_endings=endings(nb))
            unequal, headers = 0, 0
            for line, (a, b) in enumerate(itertools.zip_longest(sb.splitlines(keepends=True), nb.splitlines(keepends=True)), 1):
                if a == b:
                    continue
                unequal += 1
                cls = 'unclassified physical content/absence difference'
                if line == 1 and a is not None and b is not None and a.startswith(b'Program Version,') and b.startswith(b'Program Version,') and endings(a) == endings(b):
                    cls = 'actual first Program Version payload'; headers += 1
                out.write(json.dumps(dict(file=label, physical_line=line, classification=cls, Source_complete_raw_base64=base64.b64encode(a).decode() if a is not None else None, Native_complete_raw_base64=base64.b64encode(b).decode() if b is not None else None), separators=(',', ':')) + '\n')
            row.update(uncapped_unequal_rows=unequal, explicit_header_rows=headers, unclassified_rows=unequal - headers)
            total += unequal; metadata += headers; rows.append(row)
    return dict(comparisons=rows, all_uncapped_differences=ref(ledger), unequal_rows=total, first_header_rows=metadata, unclassified_rows=total - metadata, overall_physical_IO_PASS=total == metadata, elapsed_time_not_normalized=True, Source_full_top_level_inventory=[ref(p) for p in sorted(source.iterdir()) if p.is_file()], Native_full_top_level_inventory=[ref(p) for p in sorted(native.iterdir()) if p.is_file()])


def main(a):
    plan = read(checked(g.argument(a.plan)))
    assert plan['schema'] == 'src06-normal-completion-readback-ready47.v1'
    assert ref(Path(__file__)) == plan['case_checker_Source']
    qr, commands, producer, compiler = g.authority(plan['commands_plan']['path'] + '#' + plan['commands_plan']['sha256'])
    ar, app = g.application(a.application, compiler)
    assert ar == plan['application']
    item = next(x for x in plan['cases'] if x['case'] == a.case)
    rp = (R / item['receipt']).resolve(); rr = ref(rp)
    assert rr['sha256'] == a.receipt_sha256
    receipt = read(rp)
    assert receipt['exit_code'] == 0 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
    assert receipt['repository_before'] == receipt['repository_after'] and receipt['repository_before']['head'] == app['base_HEAD']
    assert Path(receipt['launch_environment_selected']['CARGO_TARGET_DIR']).resolve() == g.TARGET and receipt['launch_environment_selected']['CARGO_INCREMENTAL'] == '0'
    command_item = next(x for x in commands['cases'] if x['case'] == a.case)
    expected_command = list(read(checked(command_item['actual43_command_parent']))['command'])
    ids = [i for i, v in enumerate(expected_command) if v.lower().endswith('.idf')]
    assert len(ids) == 1
    expected_command[ids[0]] = checked(item['input']).as_posix()
    expected_command[expected_command.index('--weather') + 1] = checked(command_item['weather']).as_posix()
    expected_command[expected_command.index('--output-dir') + 1] = (R / item['output']).resolve().as_posix()
    assert receipt['command'] == expected_command
    assert not {'--features', '--compare-oracle', '--oracle-baseline', '--dry-run'} & set(receipt['command'])
    source = (R / item['output']).resolve()
    assert Path(option(receipt['command'], '--output-dir')).resolve() == source
    assert Path(option(receipt['command'], '--input')).resolve() == checked(item['input']) if '--input' in receipt['command'] else any(Path(x).resolve() == checked(item['input']) for x in receipt['command'] if x.lower().endswith('.idf'))
    summary, diagnostics = read(source / 'run-summary.json'), read(source / 'diagnostics.json')
    assert summary['status'] == 'success' and summary['exit_code'] == 0 and summary['oracle'] is None and summary['comparison'] is None
    assert summary['config']['compare_oracle'] is False and summary['config']['oracle_baseline'] is False and summary['config']['dry_run'] is False
    assert summary['rust_runtime']['execution'] == 'actual Source ManageSimulation successful through620'
    assert not any(x['severity'] == 'error' or x['blocking'] for x in diagnostics['diagnostics'])
    # Admission is an actual outcome assertion, not a warning filter. Keep every
    # other diagnostic and every raw ERR line for review.
    assert not any(x['code'] == 'UnsupportedObject' and any(f in x['message'] for f in ['HeatBalanceAlgorithm', 'SimulationControl', 'Output:Variable']) for x in diagnostics['diagnostics'])
    snap = read(checked(receipt['source_snapshot']))
    rows = {x['path']: x for x in compiler['entries']}
    actual = {x['historical_path']: x for x in snap['files']}
    assert rows.keys() == actual.keys() and len(rows) == 4523
    for name, row in rows.items():
        arc = ref(checked(actual[name]['archive']))
        assert (arc['sha256'], arc['bytes']) == (row['final_sha256'], row['final_bytes'])
    output = D / ('Root-normal-completion-' + a.case + '-readback-47')
    assert not output.exists(); output.mkdir()
    if 'accepted43_Source_receipt' in item:
        checked(item['accepted43_Source_receipt'])
    transfer = five24_transfer(source, (R / item['accepted43_output']).resolve()) if 'accepted43_Source_receipt' in item else None
    native = (R / item['Native_output']).resolve(); checked(item['Native_authority'])
    io = ancillary(source, native, item['Native_prefix'], output)
    end = source / 'eplusrs.end'; err = source / 'eplusrs.err'; assert end.is_file() and err.is_file()
    endb, errb = end.read_bytes(), err.read_bytes()
    assert endb.count(b'\r\n') == endb.count(b'\n') == 1 and re.fullmatch(rb'EnergyPlus Completed Successfully-- [0-9]+ Warning; [0-9]+ Severe Errors; Elapsed Time=[0-9]+hr [0-9]+min [ 0-9.]+sec\r\n', endb)
    assert errb.count(b'\r\n') == errb.count(b'\n') and b'EnergyPlus Completed Successfully' in errb
    result = dict(schema='src06-normal-completion-case-readback47.v1', accepted=True, findings=[], case=a.case, application=ar, producer=commands['producer'], actual_receipt=rr, actual_snapshot=receipt['source_snapshot'], all4523_archived_inputs_exact_plan=True, summary=ref(source / 'run-summary.json'), diagnostics=ref(source / 'diagnostics.json'), no_Oracle_run=True, false_three_family_diagnostics_absent=True, whole43_physical_and_export_transfer=transfer, ancillary=io, actual_END=ref(end), actual_ERR=ref(err), actual_elapsed_not_compared_to_Native=True, strict_duration_reported_comparison_pending=a.case in ['A-72H', 'A-ANNUAL'], no_new_native_or_test_execution=True, new_test_bodies=0, author_Source=ref(Path(__file__)))
    p = output / 'review.json'; p.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n'); print(json.dumps(ref(p)))


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--plan', required=True); p.add_argument('--application', required=True); p.add_argument('--case', required=True, choices=g.CASES); p.add_argument('--receipt-sha256', required=True); main(p.parse_args())

"""Root-only exact25 normal completion/ANC writes after full preflight."""
from pathlib import Path
import argparse,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
spec=importlib.util.spec_from_file_location('normal_completion_guards',D/'normal-completion-command-guards-Audit-47.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def main(a):
 assert a.apply,'Root explicit --apply required';qr,q,m,plan=g.authority(a.plan);assert g.ref(Path(__file__))==q['application_Source'];assert not g.APP.parent.exists()
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
 bridge=json.loads(g.checked(m['parent_compiler_LF_bridge']).read_bytes());assert bridge['accepted']and not bridge['findings']and bridge['all4517_final_live_and_archived_wholes_verified']
 prior=json.loads(g.checked(m['prior_complete_compiler_Source_plan']).read_bytes());parents={v['path']:v for v in prior['entries']};assert len(parents)==4517 and set(parents)==g.inventory()
 for n,v in parents.items():
  b=g.checked(v['source']).read_bytes();assert(R/n).read_bytes()==b and g.ref(R/n)['sha256']==v['final_sha256']and len(b)==v['final_bytes'],n
 peer=json.loads(g.checked(m['independent_full_semantic_peer']).read_bytes());peerfiles={v['canonical_path']:v for v in peer['files']};apply=g.literal();selected={};new=set();tests=0
 for f in m['files']:
  n=f['canonical_path'];p=(R/n).resolve();assert p.is_relative_to((R/'crates').resolve())and n not in selected
  before=b''if f['before_absent']else g.checked(f['before']).read_bytes();after=g.checked(f['proposed']).read_bytes();assert peerfiles[n]['proposed']==f['proposed']and apply(before,g.checked(f['forward_diff']).read_bytes())==after and apply(after,g.checked(f['inverse_diff']).read_bytes())==before
  if f['before_absent']:assert not p.exists()and n not in parents;new.add(n)
  else:assert p.read_bytes()==before==g.checked(parents[n]['source']).read_bytes()==subprocess.check_output(['git','show',g.BASE+':'+n],cwd=R)and p.stat().st_nlink==1 and not p.is_symlink(),n
  assert f['Source_only_parse']['exit_code']==0;g.checked(f['Source_only_parse']['stdout']);g.checked(f['Source_only_parse']['stderr']);tests+=after.count(b'#[test]')-before.count(b'#[test]');selected[n]=f
 assert(len(selected),len(new),tests)==(25,6,0)and set(peerfiles)==set(selected)
 for n,row in {v['path']:v for v in plan['entries']}.items():
  b=g.checked(row['source']).read_bytes();assert len(b)==row['final_bytes']and g.ref(g.checked(row['source']))['sha256']==row['final_sha256'];assert b==(g.checked(selected[n]['proposed']).read_bytes()if n in selected else(R/n).read_bytes())
 native=R/'.reference/energyplus-src/26.1.0';extents=0
 for v in m['Native_authorities']:
  b=g.checked(v['whole']).read_bytes();assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=native)
  for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==g.checked(e['source']).read_bytes();extents+=1
 assert(len(m['Native_authorities']),extents)==(22,43)
 for v in m['concrete_same_owner_contexts']:assert(R/v['canonical_path']).read_bytes()==g.checked(v['whole']).read_bytes()
 for k in('original_draft','integration_contract','constructor_and_producer_ledger','concrete_API_and_producer_census','accepted_ancillary02','independent_ancillary02_peer','summary_table_correction_proof','source_constant_extraction','psychrometric_summary_compile_policy','parent_and_final_readback'):g.checked(m[k])
 # No canonical mutation or receipt directory exists before every guard above.
 out=g.APP.parent;out.mkdir();written=[];failure=None
 try:
  for n,f in selected.items():
   p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(g.checked(f['proposed']).read_bytes());written.append(n)
  g.whole_current(plan)
 except Exception as error:failure=dict(type=type(error).__name__,message=str(error))
 result=dict(schema='src06-normal-completion-Source-application47.v1',accepted=failure is None,findings=[]if failure is None else[failure],base_HEAD=g.BASE,producer=q['producer'],independent_peer=m['independent_full_semantic_peer'],command_plan=qr,parent_compiler_LF_bridge=m['parent_compiler_LF_bridge'],prior_complete_compiler_plan=m['prior_complete_compiler_Source_plan'],complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected_files=m['files'],selected_existing=19,selected_new=6,selected_Rust=25,all4517_parent_archived_live_exact=True,selected19_Git_before_whole_exact=True,all4523_final_plan_inputs_exact=failure is None,written_paths=written,literal_applications=50,new_test_bodies=0,actual_test_or_CLI_invocations=0,accepted_ancillary_peer=m['independent_ancillary02_peer'],accepted_End_peer=m['independent_full_semantic_peer'],author_Source=g.ref(Path(__file__)),guard_Source=g.ref(D/'normal-completion-command-guards-Audit-47.py'),qualification='Same accepted25 bodies; new normal wrapUp/End remains unexecuted. Prior59/2336/471 scientific proofs retain their own snapshots with the authenticated four-file LF bridge, no rerun or new scientific PASS.')
 g.APP.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(g.ref(g.APP)));return 0 if failure is None else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--apply',action='store_true');raise SystemExit(main(p.parse_args()))

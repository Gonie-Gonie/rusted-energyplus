"""Metadata-only reader successor after recorder-selected-key preflight failure."""
from pathlib import Path
import ast, difflib, hashlib, json
R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'normal-completion-readback-ready-Audit-47-02'


def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))


def main():
    assert not O.exists()
    oldp = D / 'check-normal-completion-case-Root-47.py'
    assert ref(oldp)['sha256'] == 'e8655be94aa88a6db090872f139b0bf3a6fc6ee392be919978f1d11283ae41ff'
    old = oldp.read_bytes().decode()
    before = "    assert Path(receipt['launch_environment_selected']['CARGO_TARGET_DIR']).resolve() == g.TARGET and receipt['launch_environment_selected']['CARGO_INCREMENTAL'] == '0'\n"
    after = """    assert Path(receipt['launch_environment_selected']['CARGO_TARGET_DIR']).resolve() == g.TARGET
    # The recorder intentionally selects nine environment keys and omits this
    # one. Authenticate its selection and the actual launcher/guard producer;
    # never represent an unrecorded value as captured receipt evidence.
    recorder = ast.parse(checked(commands['record_command_Source']).read_bytes())
    selection = next(x for x in ast.walk(recorder) if isinstance(x, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'environment_keys' for t in x.targets))
    assert 'CARGO_INCREMENTAL' not in ast.literal_eval(selection.value)
    assert 'CARGO_INCREMENTAL' not in receipt['launch_environment_selected']
    guard_tree = ast.parse(checked(commands['guard_Source']).read_bytes())
    environment = next(x for x in guard_tree.body if isinstance(x, ast.FunctionDef) and x.name == 'environment')
    assert any(isinstance(x, ast.Assign) and isinstance(x.value, ast.Constant) and x.value.value == '0' and any(isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name) and t.value.id == 'env' and isinstance(t.slice, ast.Constant) and t.slice.value == 'CARGO_INCREMENTAL' for t in x.targets) for x in ast.walk(environment))
    checked(commands['launch_Source'])
"""
    assert old.count(before) == 1
    new = old.replace(before, after, 1)
    ast.parse(new)
    assert new.replace(after, before, 1) == old
    O.mkdir()
    p = D / 'check-normal-completion-case-Root-47-02.py'
    assert not p.exists(); p.write_bytes(new.encode())
    for name, a, b in [('forward.diff', old, new), ('inverse.diff', new, old)]:
        (O / name).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True), b.splitlines(keepends=True), fromfile='reader01' if name == 'forward.diff' else 'reader02', tofile='reader02' if name == 'forward.diff' else 'reader01')), encoding='utf8', newline='')
    oldplanp = D / 'normal-completion-readback-ready-Audit-47/plan.json'
    assert ref(oldplanp)['sha256'] == '4a474487e1ebc15d4c579d35e42770bf7f6e0f028ba3ef96e1c4bffbe4177939'
    plan = json.loads(oldplanp.read_bytes())
    plan.update(case_checker_Source=ref(p), preserved_original_reader=ref(oldp), preserved_original_plan=ref(oldplanp), original_failure='Root reader01 KeyError CARGO_INCREMENTAL before evidence output directory creation; recorded Source CLI success remains unchanged.', narrow_forward_diff=ref(O / 'forward.diff'), narrow_inverse_diff=ref(O / 'inverse.diff'), incremental_environment_qualification='CARGO_INCREMENTAL is not one of recorder-selected environment keys. Actual pinned launcher calls pinned guard environment() which sets it to0; receipt does not independently capture that value.', author_Source=ref(Path(__file__)))
    q = O / 'plan.json'; q.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
    print(json.dumps(dict(plan=ref(q), checker=ref(p), forward_diff=ref(O / 'forward.diff'), inverse_diff=ref(O / 'inverse.diff'), actual_checks_executed=0)))


if __name__ == '__main__':
    main()

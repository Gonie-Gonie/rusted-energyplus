from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'source-compact-schedules-draft-Outer-01';O=B/'source-compact-schedules-held-Outer-01'
assert not O.exists();HEAD='b82d16be8a96e854391636c615ddc07317a45d1f'
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(x):
 p=R/x['path'];a=ref(p);assert a['sha256']==x['sha256'] and a['bytes']==x.get('bytes',a['bytes']);return p
def load(p):return json.loads(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==HEAD
freeze=load(D/'freeze.json');snapshot=get(freeze['actual_parent_snapshot']);source_index={x['historical_path']:x for x in load(snapshot)['files']}
assert len(source_index)==4473
context=freeze['files']+load(D/'extra-parents.json')
for x in context:
 z=get(x['parent']).read_bytes();a=get(x['actual_archive']).read_bytes()
 assert z==a==subprocess.check_output(['git','show',HEAD+':'+x['canonical_path']],cwd=R)==(R/x['canonical_path']).read_bytes()
pins=[
 ('source-compact-schedule-owner-plan-Outer-01/plan.json','70407668d7e1d1453dccb3c4fa676c9e418d4256e50dc6c9a96ee7683f4fe85b'),
 ('source-compact-annual-daygroup-helper-held-Peer-01/manifest.json','5edf9530ffd2089991cd6bbcfb3acdbc625e8ccd9a16e032de4959be83e6bf17'),
 ('Audit-Compact-annual-daygroup-Source-review-01/review.json','92b96fa62e6a25e892bd8ed96fecc019a92ebe99c8c7f81df8a1d3b127ba970b'),
 ('Audit-Compact-No-minute-bounded-read-01/read-note.json','70db9fddc9c13c480fb5c9eb894587cf6dbe3671e915306477cf149e785e79f4'),
 ('source-compact-native-cohort-held-Audit-01/manifest.json','c51df39cefb11bf96157ad1ad2f0d1b5820dc64058ec6ae795a0ed7fd5d3edf2'),
 ('Native-B-compact-schedule-reference-Root-13/reference.json','999ecaaf89fb0484a74704075ad7455a713d3e63d2fb7e29bec9ec85cbc38fa5'),
 ('Native-B-compact-empty-HH-reference-Root-13/reference.json','99be7fa71e1f5a8fbcd4b55a02bfb10c8d1a102c60bc15f6072c5ab9ea3a7f37')]
bound=[]
for n,h in pins:
 p=B/n;assert ref(p)['sha256']==h;bound.append(ref(p))
helper=load(B/pins[1][0]);cohort=load(B/pins[4][0])
proposed={p.relative_to(D/'proposed').as_posix():p.read_bytes() for p in sorted((D/'proposed').rglob('*.rs'))}
assert len(proposed)==16
for x in helper['files']:assert proposed[x['canonical_path']]==get(x['proposed']).read_bytes()
for x in cohort['files']:assert proposed[x['path']]==get(x['proposed']).read_bytes()
S=(B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8');F=next(n for n in ast.parse(S).body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal');G={'re':re};exec(compile(ast.Module(body=[F],type_ignores=[]),'<whole-literal-applier>','exec'),G)
H='crates/ep_runtime/src/heat_balance/';manager=H+'selected_schedule_manager.rs';oldmanager=(D/'parent'/manager).read_text(encoding='utf8');newmanager=proposed[manager].decode()
def fn(text,name):
 start=text.index('fn '+name+'(');i=text.index('{',start);j=i+1;depth=1;quote=False;escape=False
 while depth:
  c=text[j]
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quote=False
  elif c=='"':quote=True
  elif c=='{':depth+=1
  elif c=='}':depth-=1
  j+=1
 return text[start:j]
default=fn(newmanager,'default').replace('            week_schedules: Vec::new(),\n','').replace('            week_schedule_map: BTreeMap::new(),\n','')
assert default==fn(oldmanager,'default')
constant=fn(newmanager,'add_constant').replace('SelectedSchedule {','SelectedConstantSchedule {').replace('            data: SelectedScheduleData::Constant { timestep_values: vec![value; slots] },','            timestep_values: vec![value; slots],')
assert constant==fn(oldmanager,'add_constant')
init=fn(newmanager,'init_constant_state').replace(' || !self.week_schedules.is_empty()','').replace('SelectedDaySchedule {','SelectedMissingDaySchedule {')
assert init==fn(oldmanager,'init_constant_state')
assert fn(newmanager,'always_on')==fn(oldmanager,'always_on')
assert '#[cfg(test)]\nmod compact_native_tests;' in newmanager
production={n:z for n,z in proposed.items() if not n.endswith('compact_native_tests.rs') and not n.endswith('fixtures/compact_native_b.rs')}
assert sum(z.count(b'#[test]') for z in proposed.values())==1
for n,z in production.items():
 assert b'NATIVE_COMPACT_COHORTS_JSON' not in z and b'INTERNAL GAIN SCHEDULE' not in z and b'CON-01 SYSTEM AVAILABILITY' not in z
 assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unreachable|unimplemented)!',z)
assert b'if hour.trim().is_empty() { 0.0 }' in proposed[H+'selected_schedule_manager/compact.rs']
N=R/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==PIN
plan=load(B/pins[0][0]);native=[]
for x in plan['Native_wholes']:
 p=get(x);z=p.read_bytes();assert subprocess.check_output(['git','-C',str(N),'show',PIN+':'+p.relative_to(N).as_posix()])==z;native.append(x)
for x in plan['Native_literal_extents']:
 z=get(x['whole_source']).read_bytes();assert b''.join(z.splitlines(True)[x['first_line']-1:x['last_line']])==get(x['literal_excerpt']).read_bytes()
extra_native=[]
for n in ['third_party/milo/dtoa.h','third_party/milo/itoa.h']:
 p=N/n;z=p.read_bytes();assert subprocess.check_output(['git','-C',str(N),'show',PIN+':'+n])==z;extra_native.append(ref(p))
O.mkdir()
def put(n,z):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);return ref(p)
def doc(n,v):return put(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
files=[];new_count=0
for i,(name,new) in enumerate(proposed.items(),1):
 q=subprocess.run(['git','show',HEAD+':'+name],cwd=R,capture_output=True)
 old=q.stdout;absent=q.returncode==128
 assert absent or q.returncode==0
 if absent:assert not old and not (R/name).exists();new_count+=1
 else:assert old==(D/'parent'/name).read_bytes()==(R/name).read_bytes()
 row=dict(canonical_path=name,before_absent=absent,before=put('before/'+name,old),proposed=put('proposed/'+name,new),literal_inverse=put('literal-inverse/'+name,old),Git_before_revision=HEAD)
 for key,a,b in [('forward_diff',old,new),('inverse_diff',new,old)]:
  diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='before/'+name,tofile='proposed/'+name,n=3)).encode()
  assert G['apply_literal'](a,diff)==b;row[key]=put(f'diffs/{i:02}-{key}.diff',diff)
 v=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R);assert v.returncode==0,(name,v.stderr)
 row['Source_only_parse']=dict(exit_code=0,stdout=put(f'parse/{i:02}.stdout',v.stdout),stderr=put(f'parse/{i:02}.stderr',v.stderr));files.append(row)
assert new_count==5
constant_projection=doc('Constant-and-A-representation-proof.json',dict(whole_default_inverse='Remove only two genuine new empty week vector/map constructor fields; entire original Default function recovers exactly.',whole_Constant_add_inverse='Restore row type spelling and unwrap only Constant enum storage; entire old add_constant recovers exactly, including24*max(1,actual constructor steps) vector values/slots.',whole_constant_state_inverse='Restore day-row spelling and remove only new empty-week consistency guard; entire old init_constant_state recovers exactly.',whole_always_on='Existing method whole equal.',storage='Native AddScheduleConstant241-257 sizes24*max(1,TimeStepsInHour). Built-ins at actual init clock0 start24; user Constants at clock4 start96. Native1999-2002 resizes built-in0/1 to24*actual steps,96, preserved exactly through same-row Constant payload.',explicit_A_correction='Old Source constant-only manager omitted unconditional Native1269 MissingDaySchedule0 resize. New Source performs that real write to96 zeros at actual steps4 even when Compact count0, before the empty Compact loop. Same missing-day owner/type/flags/sumTsVals0 are retained; this actual storage correction is not concealed by reported-output equality.',no_compact_success_path='Actual count0 yields zero prescan/getter/Compact producer iterations; no new schedule/day/week rows. Constant min/max and EMS/current/front-value operation order is retained via explicit kind dispatch. New week owner vectors/maps remain native-empty.',None_A_limits='The internal representation is changed and the stated MissingDay resize is a Native correction. No new None/legacy runtime execution is claimed by this Source proof. Root must perform required bounded runtime regression.',ordinary_schedule_input_unchanged=next(x for x in context if x['canonical_path']=='crates/ep_run/src/ordinary_schedule_input.rs')))
contract=doc('integration-contract.json',dict(scope='Genuine retained Constant/Compact processing for finite aligned No interpolation MM/DD Through and valid For directives; Full B still requires later positive equipment/NodeList/thermostat/IdealLoads producers.',owners='One original manager/IP/clock/environment and output Which common current_value fields. Real Day/Week/Detailed vectors/maps and constructor fields, no model ScheduleId/cache/constant stand-in/extra clock.',getters='Raw same-IP values and original object-name order, actual unused marking and two Compact getter passes. Shared exact Native Milo dtoa for numeric alpha; bounded signed-i64 conversion; actual UNTIL prescan count and numeric-local realloc before audit. No hardcoded fixture names/values/count5 in production.',native_order='Types before Detailed Compacts before user Constants; missing-day resize at1269, final built-in Constant resizes at2001/2002. Same full366 schedule pointers, per-Through For masks and generated week/day names, actual minute fill/overwrite and sequential tsVals/sumTsVals writes.',clock='Both actual UpdateScheduleVals call sites borrow live WeatherGlobalState/WeatherEnvironmentState. EMS precedes lookup; real DST/day/holiday/tomorrow and367→1 transitions; no inferred year or stale callback cache.',min_max='Actual input validation supplies real TimeStepsInHour and performs lazy ordered day/week/year reductions for limited Fraction Compacts. Cached getter/group readers use those real native caches. Uncached unlimited Detailed/day min/max without live clock explicitly Unavailable; vector length is not a proxy.',annual='Exact peered same-owner annual/weekly/day-group helper5edf; actual clock args at all3TAB calls, four distinct nominal group operands. No threshold correction, extra averaging, normalization or floating-point tolerance.',honest_boundaries=['Non-No interpolation, unsupported date/number/HHMM warning/severe branches remain typed unavailable at reached operation. Valid empty-HH0 is ported.','Missing day-type/year coverage/overlap and unknown/blank type warning paths are explicit unavailable, not successful Native diagnostics.','Positive EMS was rejected at preceding genuine CheckIfAnyEMS/raw admission; no fabricated actuator.','Generic getDayVals/hasVal/hasFractionalVal/other positive consumers remain their existing typed boundaries until genuine port; no constant fallback.'],test='Exactly one new cfg(test) cohort loops two independently recorded Native inputs: normal5×96 and empty-HH5×96 =960 f64-bit checks, real raw retained IP→ProcessScheduleInput→current actual consumed tuple operands. Fixture is an included Rust raw string captured in existing compiler snapshots; no private runtime dependency at test execution and no production reads.',required_next=['Independent full Source peer and Root preflight on this sealed16-file packet.','Root compiler checks and exactly selected paired-cohort test; no per-helper tests or full suite rerun inferred.','Fresh actual A24 and B run as needed. B success is not assumed; stop honestly at next genuine unported Native operation.'],main_application='Root only; this packet has no apply script and changes no canonical file.',Native_answer_production_inputs=False))
# Complete final compiler set binds the actual archived parent and all16 deltas.
by={x['canonical_path']:x for x in files};entries=[]
for name,row in sorted(source_index.items()):
 if name in by:
  final=by[name]['proposed'];origin='selected held proposal'
 else:final=dict(path=row['archive']['path'],sha256=row['archive']['sha256'],bytes=row['size_bytes']);origin='actual4473 archived parent'
 entries.append(dict(path=name,final_sha256=final['sha256'],final_bytes=final['bytes'],source=final,origin=origin))
for name,row in sorted(by.items()):
 if name not in source_index:
  final=row['proposed'];entries.append(dict(path=name,final_sha256=final['sha256'],final_bytes=final['bytes'],source=final,origin='new held Rust source'))
assert len(entries)==4478 and sum(x['path'].endswith('.rs') for x in entries)==4465
complete=doc('complete-final-compiler-Source-plan.json',dict(parent_actual_snapshot=ref(snapshot),base_HEAD=HEAD,entries=sorted(entries,key=lambda x:x['path']),inputs=4478,Rust_sources=4465,excluded=[],Root_independent_full_rehash_required=True))
manifest=doc('manifest.json',dict(schema='src06-held-genuine-Compact-Source-and-native-paired-cohort.v1',status='HELD Source only; no Cargo/test/actual execution or full B claim',base_HEAD=HEAD,actual_parent_B_receipt=freeze['actual_B_receipt'],actual_parent_snapshot=ref(snapshot),precise_b82_context_bridge=context,files=files,existing_Source_files=11,new_Source_files=5,literal_applications=32,Source_only_parses=16,complete_final_compiler_Source_plan=complete,Constant_and_A_representation_proof=constant_projection,integration_contract=contract,accepted_helper_and_test_authority=bound,Native_commit=PIN,Native_wholes=native+extra_native,Native_literal_extents=plan['Native_literal_extents'],exact_helper_whole_join=True,exact_cohort_whole_join=True,production_sources=14,new_test_bodies=1,Native_paired_cohorts=2,expected_exact_reported_scalar_checks=960,fixture_captured_by_existing_rs_snapshot=True,fixture_production_dependency=False,ordinary_schedule_input_projection_whole_preserved=True,main_mutations=0,Cargo_Native_or_tests_executed=False,B_completion_claim=False,gate_changes=False,author_Source=ref(B/'author-source-compact-schedules-Outer-01.py'),sealer_Source=ref(Path(__file__))))
print(json.dumps(manifest))

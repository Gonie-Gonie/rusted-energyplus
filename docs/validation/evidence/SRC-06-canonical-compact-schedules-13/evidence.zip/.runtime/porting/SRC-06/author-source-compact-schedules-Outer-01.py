from pathlib import Path
import hashlib,json
R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'source-compact-schedules-draft-Outer-01'
freeze=json.loads((O/'freeze.json').read_bytes());parents={x['canonical_path']:x for x in freeze['files']}
def parent(n):
 p=R/parents[n]['parent']['path'];z=p.read_bytes();assert hashlib.sha256(z).hexdigest()==parents[n]['parent']['sha256'];return z.decode()
def replace(s,a,b):assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b)
def put(n,s):
 p=O/'proposed'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode());return p
H='crates/ep_runtime/src/heat_balance/'
n=H+'selected_schedule_manager.rs';s=parent(n)
s=replace(s,'//! Actual constant-only ScheduleManager initialization, separate from derived caches.','//! Genuine Constant/Compact ScheduleManager with retained native day/week owners.')
s=replace(s,'mod accessors;\nmod annual;\nmod report;','mod accessors;\nmod annual;\nmod compact;\nmod detailed;\nmod day_group;\nmod report;\n#[cfg(test)]\nmod compact_native_tests;')
s=s.replace('SelectedConstantSchedule','SelectedSchedule').replace('SelectedMissingDaySchedule','SelectedDaySchedule')
s=replace(s,'    pub(crate) current_value: f64,\n    pub(crate) timestep_values: Vec<f64>,\n}', '''    pub(crate) current_value: f64,
    pub(crate) data: SelectedScheduleData,
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) enum SelectedScheduleData {
    Constant { timestep_values: Vec<f64> },
    Detailed(SelectedDetailedSchedule),
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SelectedDetailedSchedule {
    pub(crate) schedule_kind: i32,
    pub(crate) week_schedules: [Option<usize>; 367],
    pub(crate) max_min_by_day_type_set: [bool; 13],
    pub(crate) min_by_day_type: [f64; 13],
    pub(crate) max_by_day_type: [f64; 13],
    pub(crate) use_daylight_saving: bool,
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SelectedWeekSchedule {
    pub(crate) name: String,
    pub(crate) number: usize,
    pub(crate) is_used: bool,
    pub(crate) min_value: f64,
    pub(crate) max_value: f64,
    pub(crate) is_min_max_set: bool,
    pub(crate) day_schedules: [Option<usize>; 13],
}''')
s=replace(s,'    pub(crate) day_schedules: Vec<SelectedDaySchedule>,','    pub(crate) day_schedules: Vec<SelectedDaySchedule>,\n    pub(crate) week_schedules: Vec<SelectedWeekSchedule>,')
s=replace(s,'    pub(crate) day_schedule_map: BTreeMap<String, usize>,','    pub(crate) day_schedule_map: BTreeMap<String, usize>,\n    pub(crate) week_schedule_map: BTreeMap<String, usize>,')
s=replace(s,'            day_schedules: Vec::new(),','            day_schedules: Vec::new(),\n            week_schedules: Vec::new(),')
s=replace(s,'            day_schedule_map: BTreeMap::new(),','            day_schedule_map: BTreeMap::new(),\n            week_schedule_map: BTreeMap::new(),')
s=replace(s,'    Input(SelectedInputUnavailable),','    Input(SelectedInputUnavailable),\n    HeatBalance(Box<super::selected_heat_balance_input::HeatBalanceInputError>),')
s=replace(s,'impl From<std::io::Error> for SelectedScheduleError {','''impl From<super::selected_heat_balance_input::HeatBalanceInputError> for SelectedScheduleError {
    fn from(value: super::selected_heat_balance_input::HeatBalanceInputError) -> Self {
        Self::HeatBalance(Box::new(value))
    }
}
impl From<std::io::Error> for SelectedScheduleError {''')
s=replace(s,'            Self::Input(e) => std::fmt::Display::fmt(e, f),','            Self::Input(e) => std::fmt::Display::fmt(e, f),\n            Self::HeatBalance(e) => std::fmt::Display::fmt(e, f),')
s=replace(s,'            Self::Input(e) => Some(e),','            Self::Input(e) => Some(e),\n            Self::HeatBalance(e) => Some(e.as_ref()),')
s=replace(s,'            timestep_values: vec![value; slots],','            data: SelectedScheduleData::Constant { timestep_values: vec![value; slots] },')
s=replace(s,'if !self.schedules.is_empty() || !self.day_schedules.is_empty() {','if !self.schedules.is_empty() || !self.day_schedules.is_empty() || !self.week_schedules.is_empty() {')
s=replace(s,'if !matches!(family, "ScheduleTypeLimits" | "Schedule:Constant") {','if !matches!(family, "ScheduleTypeLimits" | "Schedule:Constant" | "Schedule:Compact") {')
s=replace(s,'        // Real getter-local arrays, distinct from dataIPShortCut and its false blanks.','        // Real getter-local arrays, distinct from dataIPShortCut and its false blanks.')
s=replace(s,'        let mut locals = (','        let mut locals: SourceScheduleGetterLocals = (')
s=replace(s,'        if input.get_num_objects_found("Schedule:File:Shading") > 0 {','''        // Native527-555: real Compact prescan, before audit or type getters.
        let mut max_compact_numbers = 0usize;
        for number in 0..input.get_num_objects_found("Schedule:Compact") {
            let alphas = Self::get_source_compact_object_item(input, number, &mut locals, false)?;
            for field in 2..alphas {
                if locals.0[field].starts_with("UNTIL") {
                    max_compact_numbers = max_compact_numbers.checked_add(1)
                        .ok_or(SelectedScheduleError::Unavailable("actual Compact Until count"))?;
                }
            }
        }
        if max_compact_numbers > max_numbers {
            max_numbers = max_compact_numbers;
            // Native deallocates cNumericFields, Numbers, lNumericBlanks first.
            locals.2 = Vec::new();
            locals.3 = Vec::new();
            locals.5 = Vec::new();
            locals.2 = vec![String::new(); max_numbers];
            locals.3 = vec![0.0; max_numbers];
            locals.5 = vec![true; max_numbers];
        }
        if input.get_num_objects_found("Schedule:File:Shading") > 0 {''')
s=replace(s,'        for row in &declarations.constants {\n            // getObjectItem resets all six getter-local arrays before unused erase.','''        // Native1269 resizes the same MissingDaySchedule before Compact input.
        self.day_schedules.get_mut(0).ok_or(SelectedScheduleError::Unavailable(
            "actual MissingDaySchedule0 before Compact",
        ))?.timestep_values = vec![0.0; slots];
        self.process_source_compacts(input, time_steps_in_hour, &mut locals)?;
        for row in &declarations.constants {
            // getObjectItem resets all six getter-local arrays before unused erase.''')
a='''        self.schedules[0].timestep_values = vec![0.0; slots];
        self.schedules[1].timestep_values = vec![1.0; slots];
        for schedule in &mut self.schedules {
            let Some(type_number) = schedule.schedule_type_number else {
                continue;
            };
            let limits = &self.schedule_types[type_number];
            if !limits.is_limited {
                continue;
            }
            // ScheduleConstant::setMinMaxVals: no reduction or epsilon substitute.
            schedule.min_value = schedule.current_value;
            schedule.max_value = schedule.current_value;
            schedule.is_min_max_set = true;
            // Original ScheduleBase::checkMinMaxVals, inclusive subtraction first.
            let min_ok = f64::from(f32::EPSILON) >= limits.min_value - schedule.min_value;
            let max_ok = schedule.max_value - limits.max_value <= f64::from(f32::EPSILON);'''
b='''        self.resize_source_constant(0, slots, 0.0)?;
        self.resize_source_constant(1, slots, 1.0)?;
        for index in 0..self.schedules.len() {
            let Some(type_number) = self.schedules[index].schedule_type_number else {
                continue;
            };
            let limits = &self.schedule_types[type_number];
            if !limits.is_limited {
                continue;
            }
            let (minimum, maximum) = (limits.min_value, limits.max_value);
            self.ensure_source_min_max_with_steps(SourceScheduleIndex(index), time_steps_in_hour)?;
            let schedule = &self.schedules[index];
            // Original ScheduleBase::checkMinMaxVals, inclusive subtraction first.
            let min_ok = f64::from(f32::EPSILON) >= minimum - schedule.min_value;
            let max_ok = schedule.max_value - maximum <= f64::from(f32::EPSILON);'''
s=replace(s,a,b)
s+='''
type SourceScheduleGetterLocals = (
    Vec<String>, Vec<String>, Vec<String>, Vec<f64>, Vec<bool>, Vec<bool>,
);
'''
put(n,s)
# Reuse the already accepted actual Milo producer for JSON number->alpha,
# matching the exact same third_party/milo caller used by Native IP829/831.
n=H+'source_output_registration.rs';s=parent(n)
s=replace(s,'mod milo_dtoa;','''mod milo_dtoa;
/// Same Native Milo dtoa used by InputProcessor numeric-to-alpha getters.
pub(crate) fn source_json_alpha_number(value: f64) -> Result<String, OrdinaryRadiationError> {
    milo_dtoa::source_dtoa(value)
}''');put(n,s)
# Existing input/report callers keep their same owners; only real arguments or
# Result propagation change. Freeze any additional exact actual parent first.
snapshot=json.loads((R/freeze['actual_parent_snapshot']['path']).read_bytes())
idx={x['historical_path']:x for x in snapshot['files']}
extras=[]
for n in [H+'ctf_initialization_context/internal_heat_gains_input/getter.rs', H+'ordinary_exterior_energy_use/getter.rs']:
 row=idx[n];z=(R/row['archive']['path']).read_bytes()
 assert hashlib.sha256(z).hexdigest()==row['archive']['sha256'] and (R/n).read_bytes()==z
 p=O/'parent'/n;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==z
 else:p.write_bytes(z)
 parents[n]=dict(parent=dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z)))
 extras.append(dict(canonical_path=n,actual_archive=row['archive'],parent=parents[n]['parent']))
for n,old,new in [
 (H+'ctf_initialization_context/internal_heat_gains_input/getter.rs','owners.schedules.get_source_schedule(&values.alphas[3]);','owners.schedules.get_source_schedule(&values.alphas[3])?;'),
 (H+'ordinary_exterior_energy_use/getter.rs','o.schedules.get_source_schedule(&o.shortcut.alpha_args[1]);','o.schedules.get_source_schedule(&o.shortcut.alpha_args[1])?;')]:put(n,replace(parent(n),old,new))
p=O/'extra-parents.json';value=(json.dumps(extras,indent=2)+'\n').encode()
if p.exists():assert p.read_bytes()==value
else:p.write_bytes(value)
n=H+'selected_schedule_manager/report.rs';s=parent(n)
s=replace(s,'use super::{SelectedScheduleManager, SourceScheduleIndex};','use super::{SelectedScheduleManager, SourceScheduleIndex};\nuse crate::weather::day::{WeatherGlobalState, WeatherEnvironmentState};')
s=replace(s,'        minutes_in_time_step: i32,','        minutes_in_time_step: i32,\n        clock: &WeatherGlobalState,\n        environment: &WeatherEnvironmentState,')
s=replace(s,'        self.update_source_schedule_values()','        self.update_source_schedule_values(clock, environment)')
start=s.index('    /// Actual UpdateScheduleVals2465');end=s.index('    /// Actual Schedule::getCurrentVal266',start)
s=s[:start]+'''    /// Actual UpdateScheduleVals2465 uses the same live global/environment.
    pub(crate) fn update_source_schedule_values(
        &mut self, clock: &WeatherGlobalState, environment: &WeatherEnvironmentState,
    ) -> Result<(), Error> {
        for index in 0..self.schedules.len() {
            let value = if self.schedules[index].ems_actuated_on {
                self.schedules[index].ems_value
            } else {
                self.source_hr_ts_value(SourceScheduleIndex(index), clock.hour_of_day,
                    clock.time_step, clock, environment)?
            };
            self.schedules[index].current_value = value;
        }
        Ok(())
    }
'''+s[end:];put(n,s)
n='crates/ep_runtime/src/weather_day/source_current_weather.rs';s=parent(n)
s=replace(s,'o.schedules.update_source_schedule_values()?;','o.schedules.update_source_schedule_values(&state.global, &state.environment)?;');put(n,s)
n=H+'ordinary_heat_balance_initialization/report.rs';s=parent(n)
s=replace(s,'                o.clock.minutes_in_time_step,\n                o.output_host,','                o.clock.minutes_in_time_step,\n                o.clock,\n                o.environment,\n                o.output_host,');put(n,s)
n=H+'ctf_initialization_context/internal_heat_gains_input/nominal.rs';s=parent(n)
s=replace(s,'owners.schedules.source_constant_day_min_max(schedule)?','owners.schedules.source_day_group_min_max(schedule, group)?');put(n,s)
n=H+'ordinary_tabular_reports/remaining.rs';s=parent(n)
for name,after in [('source_average_weekly_hours_full_load',''),('source_annual_hours_full_load',''),('source_annual_hours_greater_than_1_percent','                    o.clock.time_step_zone,\n')]:
 start=s.index('o.schedules.'+name+'(');end=s.index(')?;',start)
 fragment=s[start:end]
 fragment=replace(fragment,'o.environment.current_year_is_leap_year,','o.environment.current_year_is_leap_year,\n                    o.clock.time_steps_in_hour,\n'+after)
 s=s[:start]+fragment+s[end:]
put(n,s)
# Literal join of the sealed independently peered two-file consumer helper.
manifest=B/'source-compact-annual-daygroup-helper-held-Peer-01/manifest.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()=='5edf9530ffd2089991cd6bbcfb3acdbc625e8ccd9a16e032de4959be83e6bf17'
helper=json.loads(manifest.read_bytes())
for row in helper['files']:
 p=R/row['proposed']['path'];z=p.read_bytes();assert hashlib.sha256(z).hexdigest()==row['proposed']['sha256']
 put(row['canonical_path'],z.decode())
# One independently authored Native-paired cohort, two mathematical variants.
manifest=B/'source-compact-native-cohort-held-Audit-01/manifest.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()=='c51df39cefb11bf96157ad1ad2f0d1b5820dc64058ec6ae795a0ed7fd5d3edf2'
cohort=json.loads(manifest.read_bytes())
for row in cohort['files']:
 p=Path(row['proposed']['path']);z=p.read_bytes();assert hashlib.sha256(z).hexdigest()==row['proposed']['sha256']
 put(row['path'],z.decode())

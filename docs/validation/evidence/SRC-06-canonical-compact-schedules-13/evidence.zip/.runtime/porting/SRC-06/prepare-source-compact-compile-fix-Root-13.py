from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-compact-compile-fix-held-Root-13'
assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
pm=D/'source-compact-schedules-held-Outer-01/manifest.json';assert ref(pm)['sha256']=='43b11fd3ee2a2f71c9488d3dd4c4787b1b52e7139524272e1d4b93b36f03a755';parent=json.loads(pm.read_bytes());plan=json.loads(checked(parent['complete_final_compiler_Source_plan']))
failed=D/'canonical-source-compact-all-targets-Root-13/receipt.json';assert ref(failed)['sha256']=='98ddf16ec6f181fac0f21bd6bf7e1b6dabfc48f183ccf34972a083dda133ef59';receipt=json.loads(failed.read_bytes());assert receipt['exit_code']==101 and receipt['source_bytes_match_before_and_after']
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
edits={
'crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/remaining.rs':[(b"    pub(crate) environment: &'a WeatherEnvironmentState,",b"    pub(crate) environment: &'a WeatherEnvironmentState,\n    pub(crate) clock: &'a crate::weather::day::WeatherGlobalState,")],
'crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs':[(b'                    prescan: &reports.output_prescan,\n                    environment: &weather.state.environment,',b'                    prescan: &reports.output_prescan,\n                    environment: &weather.state.environment,\n                    clock: &weather.state.global,')],
'crates/ep_runtime/src/heat_balance/source_output_registration.rs':[(b'pub(crate) fn source_json_alpha_number(value: f64) -> Result<String, OrdinaryRadiationError> {',b'pub(crate) fn source_json_alpha_number(value: f64) -> Result<String, crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError> {')],
'crates/ep_runtime/src/heat_balance/selected_schedule_manager/compact.rs':[(b'                .map_err(crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError::Output)\n                .map_err(SelectedScheduleError::from)',b'                .map_err(SelectedScheduleError::from)')],
}
files=[]
for index,(n,changes) in enumerate(edits.items(),1):
 a=(R/n).read_bytes();b=a
 for before,after in changes:assert b.count(before)==1,n;b=b.replace(before,after,1)
 row=dict(canonical_path=n,before=put(O/'before'/n,a),proposed=put(O/'proposed'/n,b),literal_inverse=put(O/'literal-inverse'/n,a),exact_replacements=[dict(before=x.decode(),after=y.decode()) for x,y in changes])
 for key,x,y in [('forward_diff',a,b),('inverse_diff',b,a)]:
  diff=''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile='before/'+n,tofile='after/'+n)).encode();row[key]=put(O/'diffs'/f'{index:02d}-{key}.diff',diff)
 assert apply(a,checked(row['forward_diff']))==b and apply(b,checked(row['inverse_diff']))==a
 parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
 row['parse']=dict(exit_code=0,stdout=put(O/'parse'/f'{index:02d}.stdout',parse.stdout),stderr=put(O/'parse'/f'{index:02d}.stderr',parse.stderr));files.append(row)
selected={f['canonical_path']:f for f in files}
for v in plan['entries']:
 assert (R/v['path']).read_bytes()==checked(v['source'])
 if v['path'] in selected:
  v['source']=selected[v['path']]['proposed'];b=checked(v['source']);v['final_sha256']=hashlib.sha256(b).hexdigest();v['final_bytes']=len(b);v['origin']='Root narrow4Source compiler correction over43b11'
plan['compiler_correction_parent']=ref(pm)
planref=put(O/'complete-final-compiler-Source-plan.json',(json.dumps(plan,indent=2)+'\n').encode())
m=dict(schema='src06-compact-narrow-compiler-fix.v1',base_HEAD=parent['base_HEAD'],parent_manifest=ref(pm),parent_applied_receipt=ref(D/'Root-source-compact-application-13/receipt.json'),failed_check=ref(failed),files=files,complete_final_compiler_Source_plan=planref,scope='Add a borrow of the existing actual weather global to endrun remaining reports and preserve existing Milo HeatBalanceInputError type through the Compact adapter; no numeric formula/cache/value/policy changes.',Native_clock_authority='Same retained weather.state.global already used by actual UpdateScheduleVals; existing Native annual3790..3858 consumes live DataGlobal TimeStepsInHour/TimeStepZone.',literal_applications=8,parse_exits=[0]*4,main_mutations=0,Cargo_Native_or_tests_executed=False,author_Source=ref(Path(__file__).resolve()))
p=O/'manifest.json';put(p,(json.dumps(m,indent=2)+'\n').encode());print(json.dumps(ref(p)));print(json.dumps(planref))

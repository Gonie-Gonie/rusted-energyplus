from pathlib import Path
import ast, hashlib, json, sys
sys.stdout.reconfigure(encoding='utf-8')
R=Path.cwd()
D=Path('.runtime/porting/SRC-06')
READY=D/'compact-source-publication-prepared-Audit-13'
READY.mkdir(exist_ok=True)
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
inputs={}
def add(p):
 p=Path(p);r=ref(p);assert p.suffix.lower()!='.zip'
 inputs[r['path']]=r
def addref(r):
 actual=ref(r['path']);assert actual['sha256']==r['sha256']
 assert actual['bytes']==r.get('bytes',r.get('size_bytes',actual['bytes']))
 add(r['path'])
mp=D/'source-compact-schedules-held-Outer-01/manifest.json';m=json.loads(mp.read_bytes())
assert ref(mp)['sha256']=='43b11fd3ee2a2f71c9488d3dd4c4787b1b52e7139524272e1d4b93b36f03a755'
peer=D/'Audit-Compact-coherent-producer-Source-review-01/review.json'
assert ref(peer)['sha256']=='cbc39c0577c13cca931a104f804c10f66b6fa457727ee4ef9ee2873e04a9ab4f'
for p in [mp,peer,D/'Root-source-compact-preflight-13/review.json',D/'Root-source-compact-application-13/receipt.json',D/'Peer-Compact-Native-cohort-test-Source-review-01/review.json',D/'Peer-Native-Compact-two-case-reference-provenance-review-01/review.json']:
 add(p)
for key in ['Constant_and_A_representation_proof','integration_contract','author_Source','sealer_Source']:addref(m[key])
for f in m['files']:
 for key in ['before','proposed','forward_diff','inverse_diff']:addref(f[key])
for r in m['Native_wholes']:addref(r)
for r in m['Native_literal_extents']:addref(r['literal_excerpt'])
for row in m['precise_b82_context_bridge']:
 if row['canonical_path'].endswith(('/selected_input_processor.rs','/selected_input_processor/input_statistics.rs','/ordinary_schedule_input.rs','/source_output_registration/milo_dtoa.rs','/weather_day/context.rs')):addref(row['parent'])
test=D/'source-compact-native-cohort-held-Audit-01/manifest.json';td=json.loads(test.read_bytes());add(test)
for key in ['source_raw','finite_case_input','query_source_authority']:addref(td[key])
for r in td['order_source_authority']:addref(r)
for r in td['Native_references']:addref(r)
for row in td['physical_provenance']:
 for key in ['Native_receipt','Native_eso','unit_variant_input','parent_finite_case_input']:
  if key in row:addref(row[key])
 for key in ['Native_receipt']:
  receipt=json.loads(Path(row[key]['path']).read_bytes())
  for subkey in ['stdout','stderr']:addref(receipt[subkey])
publisher=D/'publish-compact-source-checkpoint-Audit-13-template.py'
ast.parse(publisher.read_text(encoding='utf-8'))
for p in [publisher,Path(__file__).relative_to(R),D/'review-compact-schedules-Source-Audit-01.py',D/'author-compact-native-cohort-Audit-01.py']:
 add(p)
previous=Path('energyplus_porting_plan/evidence/SRC-06-canonical-B-ingress-IO-reported-cases-12/summary.json')
add(previous)
fix_path=D/'source-compact-compile-fix-held-Root-13/manifest.json';fix=json.loads(fix_path.read_bytes())
assert ref(fix_path)['sha256']=='a41d1b8183ab5c8875b34511ff8d844f718870fdd691b428c8caa40abf1c1f2d'
add(fix_path);addref(fix['complete_final_compiler_Source_plan']);addref(fix['author_Source']);addref(fix['failed_check'])
failed=json.loads(Path(fix['failed_check']['path']).read_bytes());assert failed['exit_code']==101
for k in ['stdout','stderr','source_snapshot']:addref(failed[k])
for f in fix['files']:
 for key in ['before','proposed','forward_diff','inverse_diff']:addref(f[key])
fix_peer=D/'Peer-Compact-narrow-compiler-fix-Source-review-01/review.json'
assert ref(fix_peer)['sha256']=='0627b3a9813aa0a78f17cf2488ec0fde2c9e04311d99bf3670242f437a7cd287'
add(fix_peer);add(D/'Root-source-compact-compile-fix-application-13/receipt.json')
template=dict(schema='src06-held-canonical13-publication-template.v1',status='HELD_PENDING_ACTUAL_RECEIPTS',base_HEAD=m['base_HEAD'],producer=ref(mp),producer_peer=ref(peer),complete_plan=m['complete_final_compiler_Source_plan'],application=ref(D/'Root-source-compact-application-13/receipt.json'),previous_checkpoint=ref(previous),publisher_Source=ref(publisher),finite_archive_inputs=[r for n,r in sorted(inputs.items())],summary_template=dict(A='14/54',B='14/64',production_sources=14,changed_Rust_sources=16,new_test_functions=1,Native_paired_input_cohorts=2,ticks_per_cohort=96,schedules_per_tick=5,expected_reported_bit_checks=960,producer=ref(mp),producer_independent_peer=ref(peer),complete_compiler_plan=m['complete_final_compiler_Source_plan'],cohort_independent_peer=ref(D/'Peer-Compact-Native-cohort-test-Source-review-01/review.json'),Native_commit=m['Native_commit'],full_B_or_finite15_completion_claim=False,gate_changes=False,scope='Native aligned No interpolation Compact retained-owner math and current clock lookup. A receives genuine MissingDay0 resize correction; unsupported diagnostics/interpolations and later B equipment are explicitly incomplete.'),targets=['energyplus_porting_plan/evidence/SRC-06-canonical-compact-schedules-13/summary.json','energyplus_porting_plan/evidence/SRC-06-canonical-compact-schedules-13/manifest.json','energyplus_porting_plan/evidence/SRC-06-canonical-compact-schedules-13/evidence.zip'],append_existing_docs=['energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/cards/SRC-06.md'],plan_add_only='SRC-06.canonical_compact_schedules_13',finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(r['bytes'] for r in inputs.values()),actual_validation_contract=['Root_actual_review','check','test','B_CLI','A24_CLI','B_summary','B_diagnostics','A24_summary','A24_diagnostics'],publisher_executed=False,canonical_docs_mutations=False,Cargo_tests_Native_executed=False,gate_changes=False,application_note='Root apply guard01 rejected before any mutation on review-schema key mismatch; corrected source02 guarded application succeeded. No partial Source application is claimed.',author_Source=ref(Path(__file__).relative_to(R)))
template.update(compile_fix=ref(fix_path),compile_fix_peer=ref(fix_peer),complete_plan=fix['complete_final_compiler_Source_plan'],initial_failed_check=fix['failed_check'],compile_fix_application=ref(D/'Root-source-compact-compile-fix-application-13/receipt.json'),finite_archive_inputs=[r for n,r in sorted(inputs.items())],finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(r['bytes'] for r in inputs.values()))
template['summary_template'].update(production_sources=15,changed_Rust_sources=17,complete_compiler_plan=fix['complete_final_compiler_Source_plan'],compile_fix=ref(fix_path),compile_fix_independent_peer=ref(fix_peer),initial_failed_check=fix['failed_check'],initial_check_success_claim=False)
actual_path=D/'Root-source-compact-actual-review-13/review.json';actual=json.loads(actual_path.read_bytes())
assert ref(actual_path)['sha256']=='407afc658f551afd156b9c50b62f18c616a22436d6329d7a0468a64a36327fa0'
assert actual['accepted'] is True and not actual['findings']
add(actual_path);addref(actual['author_Source']);addref(actual['accepted12_full5352_proof']);addref(actual['unchanged_original_tolerance_policy'])
template.update(actual_review=ref(actual_path),finite_archive_inputs=[r for n,r in sorted(inputs.items())],finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(r['bytes'] for r in inputs.values()))
validation=dict(Root_actual_review=ref(actual_path),check=actual['actual_check'],test=actual['actual_native_cohort'],B_CLI=actual['actual_B'],A24_CLI=actual['actual_A24'])
for letter,run in [('B','canonical-source-compact-B-NOLIMIT-24H-Root-13'),('A24','canonical-source-compact-A-24H-Root-13')]:
 for suffix,name in [('summary','run-summary.json'),('diagnostics','diagnostics.json')]:
  target=D/run/'output'/name
  r=ref(target);assert r in actual['publication_artifacts']
  validation[letter+'_'+suffix]=r
(READY/'validation-refs.json').write_bytes((json.dumps(validation,indent=2)+'\n').encode())
p=READY/'publication-template.json';p.write_bytes((json.dumps(template,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(template=ref(p),publisher=ref(publisher),archive_inputs=len(inputs),raw_bytes=template['finite_archive_input_bytes']),indent=2))

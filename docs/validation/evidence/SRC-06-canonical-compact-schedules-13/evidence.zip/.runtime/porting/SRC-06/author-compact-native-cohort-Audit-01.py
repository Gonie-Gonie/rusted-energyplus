from pathlib import Path
import copy, difflib, hashlib, json, re, subprocess, sys

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path.cwd()
OUT = ROOT / '.runtime/porting/SRC-06/source-compact-native-cohort-held-Audit-01'
assert not OUT.exists(), 'immutable output already exists'
OUT.mkdir()
BASE = 'crates/ep_runtime/src/heat_balance/selected_schedule_manager/'
NATIVE_PIN = '6f2e40d10250a105b49966baa24d843711e61048'

def sha(b): return hashlib.sha256(b).hexdigest()
def ref(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': p.as_posix(), 'sha256': sha(b), 'bytes': len(b)}
def write(p, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
def json_bytes(v): return (json.dumps(v, ensure_ascii=False, indent=2) + '\n').encode()

raw_path = Path('.runtime/porting/SRC-06/canonical-source-B-raw-IO-B-NOLIMIT-24H-Root-12/output/input/converted.epJSON')
idf_path = Path('energyplus_porting_plan/cases/B-NOLIMIT-24H/input.idf')
raw = json.loads(raw_path.read_text(encoding='utf-8'))
idf = idf_path.read_text(encoding='utf-8')
families = ['ScheduleTypeLimits', 'Schedule:Compact', 'Schedule:Constant']

# Direct bounded translation of the current validated RawModel IDF scanner's
# comment/token rules, followed by the same name/count/case reconciliation.
# Declaration order is obtained from the real input, never a desired-name list.
def normalize(s): return s.lstrip(' \r\t\n').rstrip(' \t\0')
def scan(text):
    rows = []
    fields, field, saved = [], '', None
    comment = False
    for ch in text.lstrip('\ufeff'):
        if comment:
            if ch == '\n': comment = False
            continue
        if ch == '!':
            segment = normalize(field)
            if segment: saved = segment
            field, comment = '', True
        elif ch in ',;':
            segment = normalize(field)
            fields.append(segment if segment else (saved or ''))
            field, saved = '', None
            if ch == ';':
                if any(fields): rows.append(fields)
                fields = []
        else: field += ch
    assert not fields and not normalize(field)
    return rows

objects = scan(idf)
order = {}
selected_idf_fields = {}
for family in families:
    selected = [x for x in objects if x[0].lower() == family.lower()]
    selected_idf_fields[family] = selected
    names = [x[1] for x in selected]
    actual = raw[family]
    lookup = {k.upper(): k for k in actual}
    assert len(lookup) == len(actual) == len(names) == len(set(n.upper() for n in names))
    assert set(lookup) == set(n.upper() for n in names)
    order[family] = [lookup[n.upper()] for n in names]
assert all(any(f'object_type: "{family}"' in x for x in [Path('crates/ep_raw_model/src/idf_order.rs').read_text(encoding='utf-8')]) for family in families)

schema_source = Path('crates/ep_run/src/ordinary_input_processor/schema.rs').read_text(encoding='utf-8')
definitions = []
for family in families + ['Output:Schedules']:
    match = re.search(r'\("' + re.escape(family) + r'", (\d+), (\d+), (\d+), (\d+), (None|Some\("[^"]+"\))\)', schema_source)
    assert match, family
    extension = None if match[5] == 'None' else match[5][6:-2]
    definitions.append([family, *[int(match[i]) for i in range(1, 5)], extension])
assert 'Output:Schedules' not in raw
steps = next(iter(raw['Timestep'].values()))['number_of_timesteps_per_hour']
assert steps == 4

refs = [Path('.runtime/porting/SRC-06/Native-B-compact-schedule-reference-Root-13/reference.json'),
        Path('.runtime/porting/SRC-06/Native-B-compact-empty-HH-reference-Root-13/reference.json')]
expected_refs = ['999ecaaf89fb0484a74704075ad7455a713d3e63d2fb7e29bec9ec85cbc38fa5',
                 '99be7fa71e1f5a8fbcd4b55a02bfb10c8d1a102c60bc15f6072c5ab9ea3a7f37']
cohorts, provenance = [], []
for i, p in enumerate(refs):
    assert ref(p)['sha256'] == expected_refs[i]
    d = json.loads(p.read_text(encoding='utf-8'))
    assert d['Original_commit'] == NATIVE_PIN
    for k in ['Native_receipt', 'Native_eso']:
        assert ref(d[k]['path']) == d[k]
    receipt = json.loads(Path(d['Native_receipt']['path']).read_text(encoding='utf-8'))
    # Reference is independently pinned to a real successful Native process.
    assert '0' in str(receipt)
    declarations = list(d['declarations'].items())
    assert len(declarations) == 5 and len(d['rows']) == 96
    assert [n for _, n in declarations] == [n.upper() for f in ['Schedule:Compact', 'Schedule:Constant'] for n in order[f]]
    lines = Path(d['Native_eso']['path']).read_bytes().decode('utf-8').splitlines()
    physical = []
    for row in d['rows']:
        ts = row['native_timestamp_fields']
        assert lines[row['physical_timestamp_line']-1].split(',') == ['2', *ts]
        values = []
        for report_id, name in declarations:
            token = row['reported_decimal'][name]
            assert lines[row['physical_data_lines'][name]-1].split(',') == [report_id, token]
            values.append(token)
        assert len(ts) == 8 and ts[7] == 'Tuesday' and ts[3].strip() == '0'
        physical.append([ts, values])
    cohort_raw = {f: copy.deepcopy(raw[f]) for f in families}
    cohort_provenance = {'reference':ref(p), 'Native_receipt':d['Native_receipt'], 'Native_eso':d['Native_eso']}
    if i:
        variant = Path(d['unit_variant_input']['path'])
        assert ref(variant) == d['unit_variant_input']
        assert ref(idf_path) == d['parent_finite_case_input']
        before, after = d['unit_only_literal_change']['before'], d['unit_only_literal_change']['after']
        assert idf.count(before) == 1 and variant.read_bytes() == idf_path.read_bytes().replace(before.encode(),after.encode())
        changed = 0
        for obj in cohort_raw['Schedule:Compact'].values():
            for entry in obj['data']:
                if entry['field'] == before:
                    entry['field'] = after
                    changed += 1
        assert changed == 1
        assert scan(variant.read_text(encoding='utf-8')) == [[after if v == before else v for v in obj] for obj in objects]
        cohort_provenance.update({'unit_variant_input':d['unit_variant_input'], 'parent_finite_case_input':d['parent_finite_case_input'], 'unit_only_literal_change':d['unit_only_literal_change']})
    cohorts.append({'name': 'primary' if i == 0 else 'empty-HH', 'raw':cohort_raw,
                    'native_declarations':declarations, 'rows':physical})
    provenance.append(cohort_provenance)

fixture = {'schema':'src06-compact-native-two-cohort-test.v1',
    'scope':'TEST ONLY: two actual Native paired 96-tick cohorts, not production input or finite-case expansion. Native tuples omit civil year. Tuesday plus DST0 supplies the only consumed weekday/DST/holiday operands; no tomorrow branch is entered.',
    'Native_commit':NATIVE_PIN,'source_raw':ref(raw_path),'finite_case_input':ref(idf_path),
    'order_authority':[ref('crates/ep_raw_model/src/idf_order.rs'),ref('crates/ep_raw_model/src/lib.rs')],
    'query_authority':ref('crates/ep_run/src/ordinary_input_processor/schema.rs'),
    'provenance':provenance,'time_steps_in_hour':steps,'definitions':definitions,
    'object_order':order,'source_idf_schedule_fields':selected_idf_fields,'cohorts':cohorts}
fixture_json = json.dumps(fixture, ensure_ascii=False, separators=(',',':'))
assert '"#' not in fixture_json
fixture_bytes = ('// Test-only physical Native operands; provenance and exact extraction are retained in the JSON.\n'
                 'const NATIVE_COMPACT_COHORTS_JSON: &str = r#"' + fixture_json + '"#;\n').encode()
write(OUT/'proposed'/BASE/'fixtures/compact_native_b.rs',fixture_bytes)

test = r'''//! One Native-paired cohort test for the retained Compact producer and clock lookup.
//! Fixture bytes are Rust compiler inputs; production never reads this reference.
use super::{
    SelectedScheduleInput, SelectedScheduleManager, SourceConstantScheduleInput,
    SourceScheduleTypeInput,
};
use crate::heat_balance::selected_input_processor::{
    SelectedInputProcessor, SourceInputFamily, SourceInputStatisticsInput,
    SourceInputStatisticsValue, SourceObjectDefinition, SourceObjectShape,
};
use crate::heat_balance::source_initialization::ScheduleAuditFileHost;
use crate::weather::day::{WeatherEnvironmentState, WeatherGlobalState};
use ep_model::ScheduleUnitType;
use serde_json::Value;
use std::{collections::BTreeMap, error::Error, io, path::Path};

include!("fixtures/compact_native_b.rs");

type TestResult<T> = Result<T, Box<dyn Error>>;
fn invalid(message: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}
fn array(value: &Value) -> TestResult<&Vec<Value>> {
    Ok(value.as_array().ok_or_else(|| invalid("fixture array"))?)
}
fn object(value: &Value) -> TestResult<&serde_json::Map<String, Value>> {
    Ok(value.as_object().ok_or_else(|| invalid("fixture object"))?)
}
fn string(value: &Value) -> TestResult<&str> {
    Ok(value.as_str().ok_or_else(|| invalid("fixture string"))?)
}
fn member<'a>(value: &'a Value, name: &str) -> TestResult<&'a Value> {
    Ok(object(value)?.get(name).ok_or_else(|| invalid("fixture missing member"))?)
}
fn usize_value(value: &Value) -> TestResult<usize> {
    Ok(usize::try_from(value.as_u64().ok_or_else(|| invalid("fixture unsigned integer"))?)?)
}
fn raw_value(value: &Value) -> TestResult<SourceInputStatisticsValue> {
    Ok(match value {
        Value::Null => SourceInputStatisticsValue::Null,
        Value::Bool(v) => SourceInputStatisticsValue::Bool(*v),
        Value::Number(v) => SourceInputStatisticsValue::Number(v.to_string()),
        Value::String(v) => SourceInputStatisticsValue::String(v.clone()),
        Value::Array(v) => SourceInputStatisticsValue::Array(
            v.iter().map(raw_value).collect::<TestResult<Vec<_>>>()?,
        ),
        Value::Object(v) => SourceInputStatisticsValue::Object(
            v.iter().map(|(k, v)| Ok((k.clone(), raw_value(v)?)))
                .collect::<TestResult<BTreeMap<_, _>>>()?,
        ),
    })
}
fn json_size(value: &Value) -> usize {
    match value {
        Value::Null => 0,
        Value::Array(rows) => rows.len(),
        Value::Object(fields) => fields.len(),
        _ => 1,
    }
}
fn alpha(fields: &Value, name: &str) -> TestResult<Option<String>> {
    Ok(match object(fields)?.get(name) {
        None | Some(Value::Null) => None,
        Some(Value::String(v)) if v.is_empty() => None,
        Some(Value::String(v)) => Some(v.to_ascii_uppercase()),
        _ => return Err(invalid("actual schedule alpha field").into()),
    })
}
fn number(fields: &Value, name: &str) -> TestResult<Option<f64>> {
    Ok(match object(fields)?.get(name) {
        None | Some(Value::Null) => None,
        Some(Value::Number(v)) => Some(v.as_f64().ok_or_else(|| invalid("schedule number"))?),
        _ => return Err(invalid("actual schedule numeric field").into()),
    })
}
fn names(fixture: &Value, family: &str) -> TestResult<Vec<String>> {
    array(member(member(fixture, "object_order")?, family)?)?.iter()
        .map(|v| Ok(string(v)?.to_owned())).collect()
}
fn processor(fixture: &Value, raw: &Value) -> TestResult<SelectedInputProcessor> {
    let mut definitions = Vec::new();
    for row in array(member(fixture, "definitions")?)? {
        let row = array(row)?;
        if row.len() != 6 { return Err(invalid("query shape width").into()); }
        definitions.push(SourceObjectDefinition {
            object_type: string(&row[0])?.to_owned(),
            alpha_fields: usize_value(&row[1])?, numeric_fields: usize_value(&row[2])?,
            alpha_extensions: usize_value(&row[3])?, numeric_extensions: usize_value(&row[4])?,
            extension: if row[5].is_null() { None } else { Some(string(&row[5])?.to_owned()) },
        });
    }
    let mut families = BTreeMap::new();
    let mut statistics = SourceInputStatisticsInput::default();
    for (family, objects) in object(raw)? {
        let mut shapes = Vec::new();
        let mut retained = BTreeMap::new();
        for (name, fields) in object(objects)? {
            shapes.push(SourceObjectShape {
                object_name: name.clone(),
                field_sizes: object(fields)?.iter().map(|(k, v)| (k.clone(), json_size(v))).collect(),
            });
            retained.insert(name.clone(), object(fields)?.iter()
                .map(|(k, v)| Ok((k.clone(), raw_value(v)?)))
                .collect::<TestResult<BTreeMap<_, _>>>()?);
        }
        families.insert(family.clone(), SourceInputFamily::Objects(shapes));
        statistics.objects.insert(family.clone(), retained);
        statistics.object_order.insert(family.clone(), names(fixture, family)?);
    }
    let mut input = SelectedInputProcessor::from_admitted_input(definitions, families)?;
    input.retain_source_input_statistics(statistics)?;
    Ok(input)
}
fn declarations(fixture: &Value, raw: &Value) -> TestResult<SelectedScheduleInput> {
    let mut result = SelectedScheduleInput::default();
    for name in names(fixture, "ScheduleTypeLimits")? {
        let fields = member(member(raw, "ScheduleTypeLimits")?, &name)?;
        // All three actual declarations omit unit_type, retaining Native Invalid.
        if alpha(fields, "unit_type")?.is_some() {
            return Err(invalid("cohort type unit provenance changed").into());
        }
        result.types.push(SourceScheduleTypeInput {
            object_name: name.clone(), name: name.to_ascii_uppercase(),
            lower: number(fields, "lower_limit_value")?, upper: number(fields, "upper_limit_value")?,
            numeric_type: alpha(fields, "numeric_type")?, unit: ScheduleUnitType::Invalid,
        });
    }
    for name in names(fixture, "Schedule:Constant")? {
        let fields = member(member(raw, "Schedule:Constant")?, &name)?;
        result.constants.push(SourceConstantScheduleInput {
            object_name: name.clone(), name: name.to_ascii_uppercase(),
            type_name: alpha(fields, "schedule_type_limits_name")?,
            value: number(fields, "hourly_value")?.ok_or_else(|| invalid("actual constant value"))?,
        });
    }
    Ok(result)
}

#[derive(Default)]
struct MemoryAudit { bytes: Vec<u8> }
impl ScheduleAuditFileHost for MemoryAudit {
    fn audit_path(&self) -> &Path { Path::new("test-only-compact.audit") }
    fn ensure_audit_open(&mut self) -> io::Result<&mut dyn io::Write> { Ok(&mut self.bytes) }
}

#[test]
fn compact_primary_and_empty_hour_match_native_reported_timestep_bits() -> TestResult<()> {
    let fixture: Value = serde_json::from_str(NATIVE_COMPACT_COHORTS_JSON)?;
    let steps = usize_value(member(&fixture, "time_steps_in_hour")?)?;
    assert_eq!(steps, 4);
    let cohorts = array(member(&fixture, "cohorts")?)?;
    assert_eq!(cohorts.len(), 2);
    for cohort in cohorts {
        let cohort_name = string(member(cohort, "name")?)?;
        let raw = member(cohort, "raw")?;
        let mut input = processor(&fixture, raw)?;
        let declarations = declarations(&fixture, raw)?;
        let mut manager = SelectedScheduleManager::default();
        manager.init_constant_state(0)?;
        manager.process_schedule_input(&mut input, &declarations, steps, &mut MemoryAudit::default())?;
        let native_declarations = array(member(cohort, "native_declarations")?)?;
        let mut native_names = Vec::new();
        for declaration in native_declarations {
            let declaration = array(declaration)?;
            if declaration.len() != 2 { return Err(invalid("Native dictionary pair width").into()); }
            native_names.push(string(&declaration[1])?.to_owned());
        }
        assert_eq!(native_names.len(), 5);
        let actual_names = manager.schedules.iter().skip(2).map(|s| s.name.clone()).collect::<Vec<_>>();
        assert_eq!(actual_names, native_names, "{cohort_name}: actual declaration allocation order");
        let mut indices = Vec::new();
        for (ordinal, name) in native_names.iter().enumerate() {
            let index = manager.get_source_schedule(name)?.ok_or_else(|| invalid("actual schedule lookup"))?;
            assert_eq!(index.0, ordinal + 2, "{cohort_name}: real manager index");
            indices.push(index);
        }
        let rows = array(member(cohort, "rows")?)?;
        assert_eq!(rows.len(), 96);
        for (ordinal, row) in rows.iter().enumerate() {
            let row = array(row)?;
            if row.len() != 2 { return Err(invalid("Native cohort row width").into()); }
            let tuple = array(&row[0])?;
            let values = array(&row[1])?;
            assert_eq!(tuple.len(), 8);
            assert_eq!(values.len(), indices.len());
            // Consumed operands come from the actual Native ESO tuple. No year
            // exists in that tuple. Unconsumed weather/tomorrow fields remain
            // constructor state: DST0 cannot enter tomorrow's schedule branch.
            let integer = |i: usize| -> TestResult<i32> { Ok(string(&tuple[i])?.trim().parse()?) };
            let month = integer(1)?;
            let day = integer(2)?;
            let dst = integer(3)?;
            let hour = integer(4)?;
            assert_eq!(dst, 0);
            assert_eq!(string(&tuple[7])?, "Tuesday");
            let (end_minute, fraction) = string(&tuple[6])?.trim().split_once('.')
                .ok_or_else(|| invalid("Native end-minute token"))?;
            assert!(fraction.bytes().all(|c| c == b'0'));
            let end_minute: i32 = end_minute.parse()?;
            let minutes_per_step = 60 / i32::try_from(steps)?;
            assert_eq!(end_minute % minutes_per_step, 0);
            let clock = WeatherGlobalState {
                hour_of_day: hour, time_step: end_minute / minutes_per_step,
                time_steps_in_hour: i32::try_from(steps)?, ..WeatherGlobalState::default()
            };
            let environment = WeatherEnvironmentState {
                day_of_year_schedule: crate::weather::raw::source_ordinal_day(month, day, 1)?,
                day_of_week: 3, holiday_index: 0, dst_indicator: dst,
                ..WeatherEnvironmentState::default()
            };
            manager.update_source_schedule_values(&clock, &environment)?;
            for ((index, expected), name) in indices.iter().zip(values).zip(&native_names) {
                let expected: f64 = string(expected)?.parse()?;
                let actual = manager.source_current_schedule_value(*index)?;
                assert_eq!(actual.to_bits(), expected.to_bits(),
                    "{cohort_name}: {name}, Native tuple {ordinal}: {tuple:?}");
            }
        }
    }
    Ok(())
}
'''
test_bytes = test.encode()
write(OUT/'proposed'/BASE/'compact_native_tests.rs',test_bytes)
files=[]
for rel in [BASE+'compact_native_tests.rs',BASE+'fixtures/compact_native_b.rs']:
    p=OUT/'proposed'/rel
    assert not Path(rel).exists()
    after=p.read_bytes()
    fw=''.join(difflib.unified_diff([],after.decode().splitlines(keepends=True),fromfile='/dev/null',tofile=rel))
    inv=''.join(difflib.unified_diff(after.decode().splitlines(keepends=True),[],fromfile=rel,tofile='/dev/null'))
    short=Path(rel).name
    write(OUT/'diffs'/(short+'.forward.diff'),fw.encode())
    write(OUT/'diffs'/(short+'.inverse.diff'),inv.encode())
    parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True)
    write(OUT/'parse'/(short+'.stdout'),parsed.stdout)
    write(OUT/'parse'/(short+'.stderr'),parsed.stderr)
    assert parsed.returncode==0,(rel,parsed.stderr)
    files.append({'path':rel,'before_absent':True,'proposed':ref(p),'forward':ref(OUT/'diffs'/(short+'.forward.diff')),'inverse':ref(OUT/'diffs'/(short+'.inverse.diff')),'rustfmt_parse_exit':parsed.returncode})
context=[]
for f in ['selected_schedule_manager.rs','selected_schedule_manager/accessors.rs','selected_schedule_manager/report.rs','selected_schedule_manager/detailed.rs']:
    context.append(ref(Path('.runtime/porting/SRC-06/source-compact-schedules-draft-Outer-01/proposed/crates/ep_runtime/src/heat_balance')/f))
manifest={'schema':'src06-compact-native-one-cohort-test-held.v1','status':'HELD; no main mutation, Cargo, or test execution',
    'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'author':ref(Path('.runtime/porting/SRC-06/author-compact-native-cohort-Audit-01.py')),
    'files':files,'Native_commit':NATIVE_PIN,'Native_references':[ref(p) for p in refs],
    'physical_provenance':provenance,'fixture_json_sha256':sha(fixture_json.encode()),
    'source_raw':ref(raw_path),'finite_case_input':ref(idf_path),'order_source_authority':fixture['order_authority'],
    'query_source_authority':fixture['query_authority'],'producer_API_context_unsealed':context,
    'required_parent_hook':'Outer alone adds #[cfg(test)] mod compact_native_tests; to selected_schedule_manager.rs.',
    'test_contract':{'test_functions':1,'cohorts':2,'ticks_each':96,'actual_schedules_each':5,'bit_comparisons':960,
      'source_order':'actual IDF comment/token scan, case-insensitive exact name/count reconciliation to converted map, matching validated RawModel overlay; no hardcoded name order',
      'raw_owners':'full three actual family objects and field shapes; Number(String), Bool, nested fields and actual object_order retained on sole SelectedInputProcessor',
      'DTOs':'actual type and constant raw fields only; no Compact DTO and no TypedSchedule cache',
      'clock':'Native raw tuple only; month/day→same source_ordinal_day(...,1), actual ending hour/minute and actual4steps; tuple Tuesday/DST0 proves nonholiday and no tomorrow branch. No civil year fabricated.',
      'fixture_custody':'include! of separate *.rs constant captured by existing compiler source snapshot; test runs without private runtime artifacts',
      'unsupported_scope':'This meaningful selected math test does not claim full B primary/runtime completion or general interpolation coverage.'},
    'application_count':4,'parse_exits':[0,0],'no_main_Cargo_tests_executed':True}
write(OUT/'manifest.json',json_bytes(manifest))
print(json.dumps({'manifest':ref(OUT/'manifest.json'),'files':[(f['path'],f['proposed']['bytes']) for f in files],'order':order},indent=2))

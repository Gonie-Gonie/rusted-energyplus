"""Root-only checkpoint13 publisher. No Cargo, tests, Native or comparison run.

The accepted actual review and all four real command receipts are required.
No public/doc write occurs before all receipt/source/custody gates complete.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, zipfile
R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
READY=D/'compact-source-publication-prepared-Audit-13'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-compact-schedules-13'
BACK=D/'compact-source-publication-readback-Audit-13'

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R.resolve()).as_posix(),sha256=digest(p),bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();p.relative_to(R.resolve())
 assert digest(p)==v['sha256'] and p.stat().st_size==v.get('bytes',p.stat().st_size),v['path']
 return p
def load(p):return json.loads(p.read_bytes())
def accepted(p):
 v=load(p);assert (v.get('accepted') is True or v.get('status')=='accepted') and not v.get('findings',[]),p
 return v
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(args):
 assert args.publish and not PUBLIC.exists() and not BACK.exists()
 dp=READY/'publication-template.json';draft=load(dp)
 assert draft['status']=='HELD_PENDING_ACTUAL_RECEIPTS'
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 assert head==draft['base_HEAD']=='b82d16be8a96e854391636c615ddc07317a45d1f'
 mp=checked(draft['producer']);m=load(mp)
 assert ref(mp)['sha256']=='43b11fd3ee2a2f71c9488d3dd4c4787b1b52e7139524272e1d4b93b36f03a755'
 peer=accepted(checked(draft['producer_peer']));assert peer['packet']==ref(mp)
 fixp=checked(draft['compile_fix']);fix=load(fixp)
 assert ref(fixp)['sha256']=='a41d1b8183ab5c8875b34511ff8d844f718870fdd691b428c8caa40abf1c1f2d'
 assert fix['parent_manifest']==ref(mp) and len(fix['files'])==4
 accepted(checked(draft['compile_fix_peer']))
 cp=checked(draft['complete_plan']);plan=load(cp)
 assert plan['inputs']==4478 and plan['Rust_sources']==4465 and len(plan['entries'])==4478
 vp=(R/args.validation_refs).resolve();vp.relative_to(R.resolve());v=load(vp)
 assert set(v)=={'Root_actual_review','check','test','B_CLI','A24_CLI','B_summary','B_diagnostics','A24_summary','A24_diagnostics'}
 rp=checked(v['Root_actual_review']);root=accepted(rp)
 assert ref(rp)==draft['actual_review']
 assert root['same4478_archived_inputs_exact_final_plan'] and root['selected17_final_sources_exact']
 assert root['first_B_core_fresh_false'] and root['A24_same_core_reused_fresh_true']
 assert (root['Native_paired_exact_scalar_checks'],root['Native_paired_cohorts'],root['actual_test_bodies_executed'])==(960,2,1)
 assert root['original_tolerance_RMSE_5352_proof_transferred'] and root['policy_changes']==root['gate_changes']==0
 assert (root['transferred_reported_series'],root['transferred_JSON_CSV_scalar_roundtrips'],root['table_lines'],root['table_clock_metadata_changes'])==(58,5352,19312,30)
 assert root['whole_JSON_equal12_after_exactly_two_owned_path_field_bridges'] and root['full_runtime_equal12_after_two_owned_path_bridges']
 assert len(root['whole_physical_streams_equal12'])==7 and len(root['whole_CSV_equal12'])==2
 for r in [draft['producer'],draft['producer_peer'],draft['compile_fix'],draft['complete_plan']]+[v[k] for k in ['check','test','B_CLI','A24_CLI']]:assert contains(root,r),r['path']
 receipts=[load(checked(v[k])) for k in ['check','test','B_CLI','A24_CLI']]
 assert [x['exit_code'] for x in receipts]==[0,0,6,0]
 for x in receipts:assert x['launch_error'] is None and x['source_bytes_match_before_and_after'] and Path(x['cwd']).resolve()==R.resolve()
 assert all(x['source_snapshot']==receipts[0]['source_snapshot'] for x in receipts)
 assert '--all-targets' in receipts[0]['command'] and '--workspace' in receipts[0]['command']
 test_name='compact_primary_and_empty_hour_match_native_reported_timestep_bits'
 assert 'test' in receipts[1]['command'] and any(test_name in arg for arg in receipts[1]['command'])
 test_stdout=checked(receipts[1]['stdout']).read_text(encoding='utf-8')
 assert 'test result: ok. 1 passed; 0 failed;' in test_stdout
 for x,scope in zip(receipts[2:],['B','A']):
  command=x['command'];assert command[command.index('--porting-scope')+1]==scope
  assert not {'--oracle-baseline','--compare-oracle'}&set(command)
 bsum=load(checked(v['B_summary']));bd=load(checked(v['B_diagnostics']))
 assert bsum['exit_code']==6 and bsum['rust_runtime'] is None
 errors=[x['message'] for x in bd['diagnostics'] if x['code']=='RuntimeConvergenceFailure']
 assert errors==['GetHeatBalanceInput: positive nominal controlled Zone lookup']
 asum=load(checked(v['A24_summary']));ad=load(checked(v['A24_diagnostics']))
 assert asum['exit_code']==0 and asum['rust_runtime'] is not None
 assert not any(x['code']=='RuntimeConvergenceFailure' for x in ad['diagnostics'])
 idx={x['path']:x for x in plan['entries']}
 snapshot=load(checked(receipts[0]['source_snapshot']));observed={x['historical_path']:x for x in snapshot['files']}
 assert set(observed)==set(idx)
 selected={f['canonical_path']:f for f in m['files']}
 selected.update({f['canonical_path']:f for f in fix['files']})
 assert len(selected)==17 and sum(n.endswith('.rs') for n in selected)==17
 # Root owns complete4478 snapshot equality. This publisher reads only the17
 # selected final Sources against the final plan and same immutable snapshot.
 for n,f in selected.items():
  x=idx[n]
  p=R/n;assert digest(p)==x['final_sha256'] and p.stat().st_size==x['final_bytes']
  assert digest(checked(observed[n]['archive']))==x['final_sha256']
  assert p.read_bytes()==checked(f['proposed']).read_bytes()
 base=R/'energyplus_porting_plan';names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']
 docs={n:(base/n).read_bytes() for n in names};planfile=base/'plan.json';before=planfile.read_bytes();beforev=json.loads(before)
 for n,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R) and '\ufffd' not in b.decode('utf-8','strict')
 assert before==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
 previous=load(checked(draft['previous_checkpoint']));assert (previous['A'],previous['B'])==('14/54','14/64')
 files={}
 def add(p):
  p=p.resolve();r=ref(p);assert p.suffix.lower()!='.zip';n=r['path']
  assert n not in files or files[n]['ref']==r;files[n]=dict(path=p,ref=r)
 for r in draft['finite_archive_inputs']:add(checked(r))
 for p in [Path(__file__),dp,vp,rp]:add(p)
 for k,r in v.items():add(checked(r))
 for x in receipts:
  for k in ['stdout','stderr','source_snapshot']:add(checked(x[k]))
 # Actual A24 output custody is finite; no previous annual/72h dataset or
 # historical archive is loaded/copied. Root's accepted transfer remains the
 # authority for cross-run equality and full reported/table readback.
 for r in root.get('publication_artifacts',[]):add(checked(r))
 for n in selected:add(R/n)
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(before)
 for n,b in docs.items():p=BACK/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 zp=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,r in sorted(files.items()):assert ref(r['path'])==r['ref'];z.write(r['path'],arcname=n)
 with zipfile.ZipFile(zp) as z:
  assert z.testzip() is None and set(z.namelist())==set(files)
  for n,r in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==r['ref']['sha256']
 inventory=PUBLIC/'manifest.json';inventory.write_bytes((json.dumps(dict(schema='src06-canonical13-finite-evidence-archive.v1',archive=ref(zp),entries=[x['ref'] for n,x in sorted(files.items())],scope='One direct Compact proposal plus narrow compiler correction,17finalSources/peer/finalplan, exact Native-paired cohort custody and actual four receipts/Root accepted readback. Initial101check is retained without a success claim. No historical ZIP recursion, annual JSON/CSV or full transitive rebuild archive claim.',full_transitive_rebuild_archive_claim=False),indent=2)+'\n').encode())
 summary=dict(draft['summary_template']);summary.update(schema='src06-canonical-compact-schedules.v1',status='Genuine Compact retained-owner port, one Native-paired test passed, A24 completed; B remains incomplete at the recorded next operation',canonical_check=v['check'],canonical_test=v['test'],canonical_B_CLI=v['B_CLI'],canonical_A24_CLI=v['A24_CLI'],Root_actual_review=ref(rp),actual_B_incomplete_boundary=errors[0],actual_B_completed=False,canonical_A24_completed_Source_run=True,Native_paired_cohort_test_passed=True,reported_bit_checks=960,A24_original_tolerance_and_roundtrip_proof_transferred=dict(series=58,samples=5352,unchanged_policy=root['unchanged_original_tolerance_policy'],accepted12_proof=root['accepted12_full5352_proof'],physical_files_whole_equal12=7,CSV_files_whole_equal12=2,table_lines=19312,only30_clock_line_changes_versus12=True,scope='Reported results proof transfer from accepted12 through exact physical/CSV and exactly two owned-path JSON/runtime bridges; not a Native zero-ULP or internal-state equivalence claim.'),validation_refs=ref(vp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json';sp.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 texts={
 'CHECKLIST.md':'Compact 포팅의 Native 대조 단일 테스트와 A-24H 회귀를 통과했습니다. B는 제어 대상 Zone 조회에서 미완료이며 A14/54·B14/64 게이트는 유지합니다.',
 'STATE_CONTRACTS.md':'Compact는 동일 InputProcessor·Schedule·Week·Day 소유자와 실제 시계를 사용합니다. Native1269의 같은 MissingDay0 재할당을 보존하며, 실제 A/B의 시간당 4단계에서는 24→96개 값으로 바뀝니다. 후속 B 연산은 미완료입니다.',
 'cards/SRC-06.md':('무보간 Compact의 분별 값·타임스텝 합계·최솟값/최댓값·현재 시계 조회를 Native 순서로 연결했습니다. '
 '단일 테스트에서 기본 입력과 빈 시각(:15) 변형의 96×5×2개 스케줄 값이 Native와 비트 단위로 일치했고, A-24H 종료·내보내기와 기존 5,352개 보고값 검증도 유지했습니다. '
 'B는 Compact 처리를 마친 뒤 GetHeatBalanceInput의 제어 대상 Zone 조회에서 중단합니다. 추가 보간·진단 분기와 후속 B 장비 포팅은 남아 있으며 A14/54·B14/64 게이트는 유지합니다.')}
 rel='evidence/SRC-06-canonical-compact-schedules-13/summary.json'
 for n,b in docs.items():
  p=base/n;assert p.read_bytes()==b;link='../'+rel if n.startswith('cards/') else rel
  p.write_bytes(b+('\n\n[Source Compact 스케줄 검증]('+link+'). '+texts[n]+'\n').encode())
 after=json.loads(before);task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_compact_schedules_13';assert key not in task
 task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=digest(sp),size_bytes=sp.stat().st_size)
 inverse=json.loads(json.dumps(after));del next(x for x in inverse['tasks'] if x['id']=='SRC-06')[key]
 assert inverse==beforev and planfile.read_bytes()==before
 planfile.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),Git_mutated=False,Cargo_tests_Native_executed=False,gate_changes=False)
 p=BACK/'publication-readback.json';p.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--validation-refs',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

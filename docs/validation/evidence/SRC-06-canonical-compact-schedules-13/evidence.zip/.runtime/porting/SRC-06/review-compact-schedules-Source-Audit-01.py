from pathlib import Path
import ast, hashlib, json, re, subprocess, sys
sys.stdout.reconfigure(encoding='utf-8')
PACKET = Path('.runtime/porting/SRC-06/source-compact-schedules-held-Outer-01/manifest.json')
EXPECTED = '43b11fd3ee2a2f71c9488d3dd4c4787b1b52e7139524272e1d4b93b36f03a755'
OUT = Path('.runtime/porting/SRC-06/Audit-Compact-coherent-producer-Source-review-01')
assert not OUT.exists()
def sha(b): return hashlib.sha256(b).hexdigest()
def ref(p):
    p=Path(p);b=p.read_bytes()
    return {'path':p.as_posix(),'sha256':sha(b),'bytes':len(b)}
assert ref(PACKET)['sha256'] == EXPECTED
m=json.loads(PACKET.read_bytes())
BASE=m['base_HEAD']
assert BASE=='b82d16be8a96e854391636c615ddc07317a45d1f'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert m['existing_Source_files']==11 and m['new_Source_files']==5
assert len(m['files'])==16 and m['literal_applications']==32
assert m['production_sources']==14 and m['new_test_bodies']==1

# Every direct packet reference is independently rehashed, without running any
# author/sealer executable or inheriting its assertions.
refs={}
def check_refs(v):
    if isinstance(v,dict):
        if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
            p=Path(v['path']);b=p.read_bytes()
            assert sha(b)==v['sha256'],p
            if 'bytes' in v: assert len(b)==v['bytes'],p
            refs[p.as_posix()]=sha(b)
        for x in v.values():check_refs(x)
    elif isinstance(v,list):
        for x in v:check_refs(x)
check_refs(m)

# Known independent literal unified-diff applicator is loaded as one pure
# function. No prior author/reviewer script is executed.
app_src=Path('.runtime/porting/SRC-06/review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8')
app=next(n for n in ast.parse(app_src).body if isinstance(n,ast.FunctionDef) and n.name=='apply')
ns={'re':re};exec(compile(ast.Module(body=[app],type_ignores=[]),'literal_whole_apply','exec'),ns)
apply=ns['apply']

def git_wholes(repo,revision,paths):
    result=subprocess.run(['git','-C',str(repo),'cat-file','--batch'],
        input=b''.join((revision+':'+p+'\n').encode() for p in paths),capture_output=True,check=True)
    buf=result.stdout;offset=0;out={}
    for path in paths:
        end=buf.index(b'\n',offset);header=buf[offset:end].split();assert len(header)==3 and header[1]==b'blob',(path,header)
        size=int(header[2]);offset=end+1
        out[path]=buf[offset:offset+size];offset+=size
        assert buf[offset:offset+1]==b'\n';offset+=1
    assert offset==len(buf)
    return out

files={f['canonical_path']:f for f in m['files']}
sources={p:Path(f['proposed']['path']).read_bytes() for p,f in files.items()}
parents={p:Path(f['before']['path']).read_bytes() for p,f in files.items()}
old_git=git_wholes('.',BASE,[p for p,f in files.items() if not f['before_absent']])
parse_rows=[]
for p,f in files.items():
    before,after=parents[p],sources[p]
    if f['before_absent']:
        assert before==b'' and not Path(p).exists()
        assert subprocess.run(['git','cat-file','-e',BASE+':'+p],capture_output=True).returncode!=0
    else:assert before==old_git[p]==Path(p).read_bytes(),p
    assert apply(before,Path(f['forward_diff']['path']).read_bytes())==after,p
    assert apply(after,Path(f['inverse_diff']['path']).read_bytes())==before,p
    assert Path(f['literal_inverse']['path']).read_bytes()==before
    r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True)
    assert r.returncode==0 and not r.stderr,(p,r.stderr)
    assert r.stdout==Path(f['Source_only_parse']['stdout']['path']).read_bytes(),p
    parse_rows.append({'path':p,'before_sha256':sha(before),'after_sha256':sha(after),'parse_exit':0})

snapshot=json.loads(Path(m['actual_parent_snapshot']['path']).read_bytes())
parent_by_path={r['historical_path']:r for r in snapshot['files']}
assert len(parent_by_path)==4473
git_parent=git_wholes('.',BASE,list(parent_by_path))
actual_parent={}
parent_Git_line_end_bridges=[]
for p,r in parent_by_path.items():
    a=r['archive'];b=Path(a['path']).read_bytes()
    assert sha(b)==a['sha256'] and len(b)==r['size_bytes'],p
    assert b==Path(p).read_bytes(),p
    actual_parent[p]=b
    if b!=git_parent[p]:
        assert p=='crates/ep_runtime/src/ideal_loads/binding/scheduled_output.rs'
        assert b.count(b'\r\n')==1 and b.replace(b'\r\n',b'\n')==git_parent[p]
        assert b[48574:48576]==b'\r\n'
        parent_Git_line_end_bridges.append({'path':p,'actual_raw_sha256':sha(b),'Git_blob_sha256':sha(git_parent[p]),'raw_bytes':len(b),'Git_bytes':len(git_parent[p]),'scope':'One pre-existing CRLF comment terminator at byte48574; unchanged Compact parent/archive/live and final plan rawbytes are exact.'})
plan=json.loads(Path(m['complete_final_compiler_Source_plan']['path']).read_bytes())
assert plan['inputs']==4478 and plan['Rust_sources']==4465
entries={r['path']:r for r in plan['entries']}
assert len(entries)==4478 and sum(p.endswith('.rs') for p in entries)==4465
assert set(entries)==set(parent_by_path)|set(files)
for p,r in entries.items():
    expected=sources[p] if p in files else actual_parent[p]
    actual=Path(r['source']['path']).read_bytes()
    assert actual==expected and sha(actual)==r['final_sha256']==r['source']['sha256']
    assert len(actual)==r['final_bytes']==r['source']['bytes']
for row in m['precise_b82_context_bridge']:
    p=row['canonical_path'];b=Path(row['parent']['path']).read_bytes()
    assert b==Path(row['actual_archive']['path']).read_bytes()==git_parent[p]==Path(p).read_bytes(),p

native=Path('.reference/energyplus-src/26.1.0')
pin=m['Native_commit']
assert pin=='6f2e40d10250a105b49966baa24d843711e61048'
assert subprocess.check_output(['git','-C',str(native),'rev-parse','HEAD'],text=True).strip()==pin
npaths=[Path(r['path']).relative_to(native).as_posix() for r in m['Native_wholes']]
ngit=git_wholes(native,pin,npaths)
for r,np in zip(m['Native_wholes'],npaths):assert Path(r['path']).read_bytes()==ngit[np]
for extent in m['Native_literal_extents']:
    whole=Path(extent['whole_source']['path']).read_bytes().splitlines(True)
    excerpt=b''.join(whole[extent['first_line']-1:extent['last_line']])
    assert excerpt==Path(extent['literal_excerpt']['path']).read_bytes(),extent['purpose']

helper=json.loads(Path('.runtime/porting/SRC-06/source-compact-annual-daygroup-helper-held-Peer-01/manifest.json').read_bytes())
# Locate whole peer-author helper proposals by its own manifest, not desired hash.
helper_refs={}
def collect_proposed(v):
    if isinstance(v,dict):
        if 'proposed' in v and isinstance(v['proposed'],dict) and 'path' in v['proposed']:
            p=Path(v['proposed']['path']);helper_refs[p.name]=p.read_bytes()
        for x in v.values():collect_proposed(x)
    elif isinstance(v,list):
        for x in v:collect_proposed(x)
collect_proposed(helper)
for name in ['annual.rs','day_group.rs']:
    p='crates/ep_runtime/src/heat_balance/selected_schedule_manager/'+name
    assert sources[p]==helper_refs[name]
cohort=json.loads(Path('.runtime/porting/SRC-06/source-compact-native-cohort-held-Audit-01/manifest.json').read_bytes())
for row in cohort['files']:assert sources[row['path']]==Path(row['proposed']['path']).read_bytes()
cohort_peer=Path('.runtime/porting/SRC-06/Peer-Compact-Native-cohort-test-Source-review-01/review.json')
assert ref(cohort_peer)['sha256']=='3521583432e627b53cc4f02fd971b80a19804b95967d7cf33afd407efa384c58'

def function(text,name):
    start=text.index('fn '+name+'(');body=text.index('{',start);level=0
    for i in range(body,len(text)):
        if text[i]=='{':level+=1
        elif text[i]=='}':
            level-=1
            if level==0:return text[start:i+1]
    raise AssertionError(name)
manager='crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs'
new,old=sources[manager].decode(),parents[manager].decode()
assert function(new,'default').replace('            week_schedules: Vec::new(),\n','').replace('            week_schedule_map: BTreeMap::new(),\n','')==function(old,'default')
assert function(new,'add_constant').replace('SelectedSchedule {','SelectedConstantSchedule {').replace('data: SelectedScheduleData::Constant { timestep_values: vec![value; slots] },','timestep_values: vec![value; slots],')==function(old,'add_constant')
assert function(new,'init_constant_state').replace(' || !self.week_schedules.is_empty()','').replace('SelectedDaySchedule {','SelectedMissingDaySchedule {')==function(old,'init_constant_state')
assert function(new,'always_on')==function(old,'always_on')
assert new.count('#[cfg(test)]')==1 and new.count('mod compact_native_tests;')==1

union={p:b for p,b in actual_parent.items() if p.endswith('.rs')}
union.update(sources)
relevant_names=['get_source_schedule','report_source_schedule_values','update_source_schedule_values',
 'source_average_weekly_hours_full_load','source_annual_hours_full_load','source_annual_hours_greater_than_1_percent',
 'source_day_group_min_max','source_json_alpha_number']
census={name:[] for name in relevant_names}
for p,b in union.items():
    text=b.decode('utf-8')
    assert not re.search(r'\b(?:SelectedConstantSchedule|SelectedMissingDaySchedule|source_constant_day_min_max)\b',text),p
    for name in relevant_names:
        for n,line in enumerate(text.splitlines(),1):
            if re.search(r'\b'+name+r'\s*\(',line):census[name].append({'path':p,'line':n,'text':line.strip()})
for name in ['source_average_weekly_hours_full_load','source_annual_hours_full_load','source_annual_hours_greater_than_1_percent']:
    assert any(x['path'].endswith('/ordinary_tabular_reports/remaining.rs') for x in census[name]),name

for p,b in sources.items():
    if p.endswith('/compact_native_tests.rs') or '/fixtures/' in p:continue
    # New mathematical bodies contain no private fixture/case/hash gate or panic.
    if files[p]['before_absent']:
        assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)!',b),p
        assert b'.runtime/' not in b and b'Native-B-' not in b and b'NATIVE_COMPACT_COHORTS_JSON' not in b

review={
 'schema':'src06-compact-coherent-producer-independent-Source-review.v1',
 'status':'accepted','findings':[], 'packet':ref(PACKET),'base_HEAD':BASE,
 'scope':'Independent full coherent14-production-Source review and exact integration of separately independently accepted one-test/two-cohort packet. No Main/Cargo/Native/test execution.',
 'reviewer_Source':ref(Path('.runtime/porting/SRC-06/review-compact-schedules-Source-Audit-01.py')),
 'custody':{'direct_references_rehashed':len(refs),'whole_selected_sources':16,'literal_applications':32,'fresh_parse_exits':[0]*16,
   'exact_live_actual_archived_parent_inputs':4473,'selected_existing_b82_Git_wholeexact':11,
   'unchanged_parent_Git_line_end_bridges':parent_Git_line_end_bridges,
   'full_final_plan_inputs':4478,'full_final_plan_Rust_sources':4465,
   'Native_Git_wholes':len(npaths),'Native_literal_extents':len(m['Native_literal_extents']),
   'plan':m['complete_final_compiler_Source_plan'],'selected':parse_rows},
 'source_findings':{
  'owners':'One existing manager/IP and existing raw statistics owner; genuine native common/Constant/Detailed/day/week ctor fields, vectors and maps. No typed ScheduleId, mirrored cache, synthetic clock, precomputed schedule table or Native-result production dependency. Schedule output Which remains same current_value.',
  'raw_getter':'Two actual raw Compact getter passes use retained ordered original names/counts/fields, mark actual unused owner, clear actual local alpha/Numbers in prescan and all6 local arrays in full pass. Blank/unknown/diagnostic-name branches stop explicitly. Integer i64 and finite floating Milo alpha conversion reuse exact existing formatter; no new formatter or scientific arithmetic.',
  'prescan':'Native409-548 actual counts/maxarg order and Output:Schedules query retained; sentinel extra alpha retained, UNTIL count spans all Compact objects; cNumericFields/Numbers/lNumericBlanks are all dropped before each reallocation and before audit/type getters. No hardcoded count2/5 or selected name in producer.',
  'insertion':'Actual builtins init0 allocate24; types precede unconditional native1269 MissingDay0 resize, then all Compacts and user Constants, then both builtins resized24*actualsteps. Genuine native366 pointers, per-Through coverage and consecutive generated week/day identities, missingDay pointers, For masks and used flags are retained.',
  'compact_controls':'Fixed MM/DD Through uses same leap1 ordinal, all actual independent For substring predicates/day enums and duplicate/other-day writes checked against Native3075-3249. Finite No interpolation parses/repackages Until/value fields in actual order, including local alpha overwrite/sentinel. Unsupported diagnostic, alternative date, interpolation, HHMM warning and incomplete/overlap branches are typed boundaries, not fabricated success.',
  'minute_math':'Native2733-3073 minute0/setfalse initialization, valid emptyHH=0, aligned integer HHMM, exact minute0 end-hour convention and genuine inclusive minute60 first-hour overwrite followed by middle/final writes preserved. All1440 coverage checked. Day211-239 timestep-end samples and sequential sumTsVals+= update existing ctor0 accumulator without reset or reordered sum.',
  'minmax':'Native3251-3346 day first-value reduction with if/else-if, actual24*live steps bound, week/day and Detailed/week pointer-neighbor dedup, optional day366, immediate retained reductions/flags all matched. Input validation supplies genuine steps and preserves native inclusive subtraction+FLT_EPSILON. Uncached unlimited Detailed/day methods without clock stop explicitly; no storage-length proxy.',
  'clock':'Both actual update callers pass their same live weather global/environment. Update native2465 ordered EMS-before-getHrTsVal-before-current write; Detailed2490 DST shift, tomorrow weekday/holiday,367→1, realweek/day pointer and<=0 timestep fallback/subscript exact. Constant uses tsVals.front before any derived schedule logic, and separate EMS-aware getCurrentVal remains unchanged.',
  'helpers':'Both annual/daygroup Sources whole equal separately accepted helper5edf/92b96. Re-read full joined code: native365/366 sequential annual day.sumTs/actualsteps; literal>0 and actualTimeStepZone additions; weekly division; four exact day-group filters/caches, Num-based dedup and Objexx double equality operand order. All3 TAB sites now pass actual same-owner clock fields, nominal4distinct group operands.',
  'constant_A':'Whole Default/addConstant/init/alwaysOn inverses independently reconstructed. Existing constant mathematical operations persist through explicit payload dispatch. A receives truthful Native1269 MissingDay24→96 storage correction even atCompact0. No claim that every A storage byte is unchanged; fresh runtime A regression belongs to Root.',
  'integration':'All final4465Rust bodies scanned for affected function names and removed old constant-only type/method names. Both getSourceSchedule callers propagate typederrors; two update call sites borrow correct live owners; output Which binding and report registration unchanged except actualclock operands. No ordinary input DTO or Legacy/None routing changes.',
  'cohort':'Final2test Sources are whole exact c51df and independently accepted Coil352158; one cfg(test) hook, fixture*.rs include remains captured by existing snapshot. Required APIs/type fields agree with final producer. This reviewer authored that isolated test, so independent fixture/math-test Source acceptance is explicitly attributed to Coil, not self-review.'},
 'helper_peer':ref(Path('.runtime/porting/SRC-06/Audit-Compact-annual-daygroup-Source-review-01/review.json')),
 'cohort_independent_peer':ref(cohort_peer),'affected_function_census':census,
 'remaining':'Root must run independent application/preflight, required compile and one cohort test, fresh B actual frontier and bounded A24 regression. No completed B claim or case-gate advancement.'
}
OUT.mkdir()
out=OUT/'review.json';out.write_bytes((json.dumps(review,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(ref(out),indent=2))

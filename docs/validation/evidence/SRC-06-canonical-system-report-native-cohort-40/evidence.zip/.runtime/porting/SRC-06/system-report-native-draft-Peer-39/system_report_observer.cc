// Passive stored-member copies only. No Native getters, properties or updates.
#include "system_report_observer.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataLoopNode.hh>
#include <EnergyPlus/DataSizing.hh>
#include <EnergyPlus/DataZoneEnergyDemands.hh>
#include <EnergyPlus/DataZoneEquipment.hh>
#include <EnergyPlus/OutputReportPredefined.hh>
#include <EnergyPlus/PurchasedAirManager.hh>
#include <EnergyPlus/SystemReports.hh>
#include <EnergyPlus/ZoneTempPredictorCorrector.hh>
#include <nlohmann/json.hpp>
#include <cstring>
#include <exception>
#include <limits>

#if !defined(__MINGW32__) || !defined(_WIN64) || __GNUC__ != 13 || __GNUC_MINOR__ != 2
#error "This isolated reference uses the retained GCC13.2 Windows core ABI"
#endif
#if defined(_GLIBCXX_DEBUG) || defined(__FAST_MATH__) || defined(NDEBUG)
#error "Preserve core assertions, container ABI and floating-point options"
#endif
#if !defined(EP_psych_errors) || defined(EP_psych_stats)
#error "Preserve actual core psychrometric definitions"
#endif

namespace SystemReportObservation {
namespace {
using json = nlohmann::json;
thread_local Capture *active = nullptr;
thread_local Scope *current = nullptr;
char const *name(Method method) noexcept {
    switch(method) {
    case Method::Energy: return "ReportSystemEnergyUse";
    case Method::Ventilation: return "ReportVentilationLoads";
    default: return "invalid-observer-method";
    }
}
bool increment(std::uint64_t &counter) noexcept {
    if(counter == std::numeric_limits<std::uint64_t>::max()) {
        active->overflow=true; return false;
    }
    ++counter; return true;
}
json scalar(double value) {
    // Integer-only transport: neither JSON numeric formatting nor a floating
    // comparison is needed to preserve any binary64, including NaN payloads.
    std::uint64_t bits; std::memcpy(&bits, &value, sizeof(bits));
    char text[17]; char const *digits = "0123456789abcdef";
    for (unsigned i = 0; i < 16; ++i) text[i] = digits[(bits >> ((15 - i) * 4)) & 15];
    text[16] = '\0';
    return {{"value_bits", text}};
}
template<class A> bool contains(A const &a, int at) {
    if (!a.allocated()) return false;
    if constexpr (requires { a.contains(at); }) return a.contains(at);
    else return at >= 1 && at <= a.isize(); // actual EPVector 1-based operator()
}
template<class A> json shape(A const &a) {
    json out{{"allocated",a.allocated()},{"size",a.size()},
             {"owner_address",reinterpret_cast<std::uintptr_t>(&a)}};
    if constexpr (requires { a.l(); a.u(); }) {
        out["lower"] = a.allocated() ? json(a.l()) : json(nullptr);
        out["upper"] = a.allocated() ? json(a.u()) : json(nullptr);
    } else {
        out["index_domain"] = "EPVector one-based operator()";
    }
    return out;
}
template<class A> json int_slot(A const &a, int at) {
    auto out=shape(a); out["index"]=at;
    out["value"]=contains(a,at) ? json(static_cast<std::int64_t>(a(at))) : json(nullptr); return out;
}

json clock(EnergyPlus::EnergyPlusData const &s) {
    auto const &g=*s.dataGlobal; auto const &e=*s.dataEnvrn; auto const &h=*s.dataHVACGlobal;
    return {{"state_address",reinterpret_cast<std::uintptr_t>(&s)},
        {"environment_index",e.CurEnvirNum},{"environment_name",e.EnvironmentName},
        {"CalendarYear",g.CalendarYear},{"Month",e.Month},{"DayOfMonth",e.DayOfMonth},
        {"DayOfSim",g.DayOfSim},{"HourOfDay",g.HourOfDay},{"TimeStep",g.TimeStep},
        {"KindOfSim",static_cast<int>(g.KindOfSim)},{"CurrentTime",scalar(g.CurrentTime)},
        {"TimeStepZone",scalar(g.TimeStepZone)},{"TimeStepZoneSec",scalar(g.TimeStepZoneSec)},
        {"TimeStepSys",scalar(h.TimeStepSys)},{"TimeStepSysSec",scalar(h.TimeStepSysSec)},
        {"SysTimeElapsed",scalar(h.SysTimeElapsed)},{"FracTimeStepZone",scalar(h.FracTimeStepZone)},
        {"PreviousTimeStep",scalar(h.PreviousTimeStep)},{"NumOfSysTimeSteps",h.NumOfSysTimeSteps},
        {"NumOfSysTimeStepsLastZoneTimeStep",h.NumOfSysTimeStepsLastZoneTimeStep},
        {"FirstTimeStepSysFlag",h.FirstTimeStepSysFlag},{"ShortenTimeStepSys",h.ShortenTimeStepSys},
        {"UseZoneTimeStepHistory",h.UseZoneTimeStepHistory},{"WarmupFlag",g.WarmupFlag},
        {"DoingSizing",g.DoingSizing},{"KickOffSimulation",g.KickOffSimulation},
        {"BeginSimFlag",g.BeginSimFlag},{"BeginEnvrnFlag",g.BeginEnvrnFlag},
        {"BeginDayFlag",g.BeginDayFlag},{"BeginTimeStepFlag",g.BeginTimeStepFlag},
        {"OutBaroPress",scalar(e.OutBaroPress)},{"OutHumRat",scalar(e.OutHumRat)}};
}


template<class A> json integers(A const &array,int active_count) {
    auto result=shape(array);result["values"]=nullptr;
    if(array.allocated()) {
        result["values"]=json::array();
        for(int i=1;i<=active_count;++i)
            result["values"].push_back(contains(array,i) ? json(static_cast<std::int64_t>(array(i))) : json(nullptr));
    }
    return result;
}
template<class A> json distribution(A const &array,int active_count) {
    auto result=shape(array);result["values"]=nullptr;
    if(array.allocated()) {
        result["values"]=json::array();
        for(int i=1;i<=active_count;++i) {
            if(!contains(array,i)) {result["values"].push_back({{"index",i},{"value",nullptr}});continue;}
            auto const &v=array(i);
            // SupplyAirPathOutNodeIndex is deliberately NOT copied: Native
            // omits its primitive initialization, and reports do not read it.
            result["values"].push_back({{"index",i},{"address",reinterpret_cast<std::uintptr_t>(&v)},
                {"InNode",v.InNode},{"OutNode",v.OutNode},{"AirDistUnitIndex",v.AirDistUnitIndex}});
        }
    }
    return result;
}
json equipment_config(EnergyPlus::EnergyPlusData const &s,int zone,Method method) {
    auto const &array=s.dataZoneEquip->ZoneEquipConfig;
    auto out=shape(array);out["index"]=zone;out["value"]=nullptr;
    if(!contains(array,zone)) return out;
    auto const &v=array(zone);
    json fields{{"address",reinterpret_cast<std::uintptr_t>(&v)},{"IsControlled",v.IsControlled}};
    if(v.IsControlled) {
        fields["NumInletNodes"]=v.NumInletNodes;fields["InletNodeAirLoopNum"]=integers(v.InletNodeAirLoopNum,v.NumInletNodes);
        if(method==Method::Ventilation) {
            fields["EquipListIndex"]=v.EquipListIndex;
            fields["ZoneDesignSpecOAIndex"]=v.ZoneDesignSpecOAIndex;fields["ZoneAirDistributionIndex"]=v.ZoneAirDistributionIndex;
        }
        // These are consumed only by the positive primary-air route. Capture
        // only when an actual inlet points at that route, not from a case flag.
        bool primary=false;
        for(int i=1;i<=v.NumInletNodes;++i)
            if(contains(v.InletNodeAirLoopNum,i) && v.InletNodeAirLoopNum(i)!=0) primary=true;
        if(primary) {
            fields["EquipListIndex"]=v.EquipListIndex;
            fields["AirDistUnitCool"]=distribution(v.AirDistUnitCool,v.NumInletNodes);
            fields["AirDistUnitHeat"]=distribution(v.AirDistUnitHeat,v.NumInletNodes);
            fields["InletNodeADUNum"]=integers(v.InletNodeADUNum,v.NumInletNodes);
        }
    }
    out["value"]=fields;
    return out;
}
json node_operand(EnergyPlus::EnergyPlusData const &s,int index,bool supply) {
    auto const &array=s.dataLoopNodes->Node;auto out=shape(array);out["index"]=index;out["value"]=nullptr;
    if(contains(array,index)) {
        auto const &v=array(index);json fields{{"address",reinterpret_cast<std::uintptr_t>(&v)}};
        if(supply) fields["MassFlowRate"]=scalar(v.MassFlowRate);
        else {fields["Temp"]=scalar(v.Temp);fields["HumRat"]=scalar(v.HumRat);}
        out["value"]=fields;
    }
    return out;
}
json purchased_air(EnergyPlus::EnergyPlusData const &s,int index) {
    auto const &manager=*s.dataPurchasedAirMgr;auto out=shape(manager.PurchAir);out["index"]=index;out["value"]=nullptr;
    out["manager_address"]=reinterpret_cast<std::uintptr_t>(&manager);
    out["GetPurchAirInputFlag"]=manager.GetPurchAirInputFlag;out["NumPurchAir"]=manager.NumPurchAir;
    // When the true input flag is set the Native getter first calls GetInput;
    // no unconsumed/uninitialized unit row is read by this observer.
    if(!manager.GetPurchAirInputFlag && contains(manager.PurchAir,index)) {
        auto const &v=manager.PurchAir(index);
        out["value"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},
            {"OutdoorAirMassFlowRate",scalar(v.OutdoorAirMassFlowRate)},
            {"ZoneSupplyAirNodeNum",v.ZoneSupplyAirNodeNum},{"MixedAirTemp",scalar(v.MixedAirTemp)},
            {"MixedAirHumRat",scalar(v.MixedAirHumRat)},{"ZoneRecircAirNodeNum",v.ZoneRecircAirNodeNum}};
        if(v.ZoneSupplyAirNodeNum>0) out["supply_node"]=node_operand(s,v.ZoneSupplyAirNodeNum,true);
        // Temp/HumRat are constructor-defined potential operands of the real
        // subsequent flow>0 guard. No floating comparison is added here.
        if(v.ZoneRecircAirNodeNum>0) out["recirc_node"]=node_operand(s,v.ZoneRecircAirNodeNum,false);
    }
    return out;
}
json equipment_list(EnergyPlus::EnergyPlusData const &s,int index) {
    auto const &array=s.dataZoneEquip->ZoneEquipList;auto out=shape(array);out["index"]=index;out["value"]=nullptr;
    if(!contains(array,index)) return out;
    auto const &v=array(index);json values=json::array();
    for(int j=1;j<=v.NumOfEquipTypes;++j) {
        json equipment{{"index",j}};
        equipment["EquipType"]=contains(v.EquipType,j) ? json(static_cast<int>(v.EquipType(j))) : json(nullptr);
        equipment["EquipIndex"]=contains(v.EquipIndex,j) ? json(v.EquipIndex(j)) : json(nullptr);
        if(contains(v.EquipType,j) && contains(v.EquipIndex,j) &&
           v.EquipType(j)==EnergyPlus::DataZoneEquipment::ZoneEquipType::PurchasedAir)
            equipment["PurchasedAir"]=purchased_air(s,v.EquipIndex(j));
        values.push_back(equipment);
    }
    out["value"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},{"NumOfEquipTypes",v.NumOfEquipTypes},
        {"EquipType_shape",shape(v.EquipType)},{"EquipIndex_shape",shape(v.EquipIndex)},{"equipment",values}};
    return out;
}
json zone_predefined(EnergyPlus::EnergyPlusData const &s,int zone) {
    auto const &array=s.dataHeatBal->ZonePreDefRep;auto out=shape(array);out["index"]=zone;out["value"]=nullptr;
    if(contains(array,zone)) {
        auto const &v=array(zone);json fields{{"address",reinterpret_cast<std::uintptr_t>(&v)},{"isOccupied",v.isOccupied}};
        fields["AFNVentVolStdDen"]=scalar(v.AFNVentVolStdDen);
        fields["TotTimeOcc"]=scalar(v.TotTimeOcc);
        fields["MechVentVolTotalOcc"]=scalar(v.MechVentVolTotalOcc);
        fields["MechVentVolMin"]=scalar(v.MechVentVolMin);
        fields["MechVentVolTotalOccStdDen"]=scalar(v.MechVentVolTotalOccStdDen);
        fields["InfilVolTotalOcc"]=scalar(v.InfilVolTotalOcc);
        fields["InfilVolMin"]=scalar(v.InfilVolMin);
        fields["InfilVolTotalOccStdDen"]=scalar(v.InfilVolTotalOccStdDen);
        fields["SimpVentVolTotalOcc"]=scalar(v.SimpVentVolTotalOcc);
        fields["SimpVentVolMin"]=scalar(v.SimpVentVolMin);
        fields["SimpVentVolTotalOccStdDen"]=scalar(v.SimpVentVolTotalOccStdDen);
        fields["VozTargetTotalOcc"]=scalar(v.VozTargetTotalOcc);
        fields["VozTargetTimeBelowOcc"]=scalar(v.VozTargetTimeBelowOcc);
        fields["VozTargetTimeAtOcc"]=scalar(v.VozTargetTimeAtOcc);
        fields["VozTargetTimeAboveOcc"]=scalar(v.VozTargetTimeAboveOcc);
        fields["TotVentTimeNonZeroUnocc"]=scalar(v.TotVentTimeNonZeroUnocc);
        fields["MechVentVolTotalStdDen"]=scalar(v.MechVentVolTotalStdDen);
        fields["InfilVolTotalStdDen"]=scalar(v.InfilVolTotalStdDen);
        fields["SimpVentVolTotalStdDen"]=scalar(v.SimpVentVolTotalStdDen);
        fields["VozTargetTotal"]=scalar(v.VozTargetTotal);
        fields["VozTargetTimeBelow"]=scalar(v.VozTargetTimeBelow);
        fields["VozTargetTimeAt"]=scalar(v.VozTargetTimeAt);
        fields["VozTargetTimeAbove"]=scalar(v.VozTargetTimeAbove);
        out["value"]=fields;
    }
    return out;
}
json zone_report(EnergyPlus::EnergyPlusData const &s,int zone) {
    auto const &array=s.dataSysRpts->ZoneVentRepVars;auto out=shape(array);out["index"]=zone;out["value"]=nullptr;
    if(contains(array,zone)) {
        auto const &v=array(zone);json fields{{"address",reinterpret_cast<std::uintptr_t>(&v)}};
        fields["CoolingLoadMetByVent"]=scalar(v.CoolingLoadMetByVent);
        fields["CoolingLoadAddedByVent"]=scalar(v.CoolingLoadAddedByVent);
        fields["OvercoolingByVent"]=scalar(v.OvercoolingByVent);
        fields["HeatingLoadMetByVent"]=scalar(v.HeatingLoadMetByVent);
        fields["HeatingLoadAddedByVent"]=scalar(v.HeatingLoadAddedByVent);
        fields["OverheatingByVent"]=scalar(v.OverheatingByVent);
        fields["NoLoadHeatingByVent"]=scalar(v.NoLoadHeatingByVent);
        fields["NoLoadCoolingByVent"]=scalar(v.NoLoadCoolingByVent);
        fields["OAMassFlow"]=scalar(v.OAMassFlow);
        fields["OAMass"]=scalar(v.OAMass);
        fields["OAVolFlowStdRho"]=scalar(v.OAVolFlowStdRho);
        fields["OAVolStdRho"]=scalar(v.OAVolStdRho);
        fields["OAVolFlowCrntRho"]=scalar(v.OAVolFlowCrntRho);
        fields["OAVolCrntRho"]=scalar(v.OAVolCrntRho);
        fields["MechACH"]=scalar(v.MechACH);
        fields["TargetVentilationFlowVoz"]=scalar(v.TargetVentilationFlowVoz);
        fields["TimeBelowVozDyn"]=scalar(v.TimeBelowVozDyn);
        fields["TimeAtVozDyn"]=scalar(v.TimeAtVozDyn);
        fields["TimeAboveVozDyn"]=scalar(v.TimeAboveVozDyn);
        fields["TimeVentUnocc"]=scalar(v.TimeVentUnocc);
        out["value"]=fields;
    }
    return out;
}
json snapshot(EnergyPlus::EnergyPlusData const &s,Method method) {
    auto const &g=*s.dataGlobal;auto const &hvac=*s.dataHVACGlobal;auto const &environment=*s.dataEnvrn;
    auto const &reports=*s.dataSysRpts;
    json flags{{"AirLoopLoadsReportEnabled",reports.AirLoopLoadsReportEnabled},
        {"VentReportStructureCreated",reports.VentReportStructureCreated},{"VentLoadsReportEnabled",reports.VentLoadsReportEnabled},
        {"VentEnergyReportEnabled",reports.VentEnergyReportEnabled},{"NumOfZones",g.NumOfZones},
        {"NumPrimaryAirSys",hvac.NumPrimaryAirSys},{"NumPlantLoops",hvac.NumPlantLoops},{"NumCondLoops",hvac.NumCondLoops},
        {"DoOutputReporting",g.DoOutputReporting},{"ZoneSizingCalc",g.ZoneSizingCalc}};
    json result{{"flags",flags}};
    if(method==Method::Energy && !reports.AirLoopLoadsReportEnabled) return result;
    if(method==Method::Ventilation && (!reports.VentReportStructureCreated || !reports.VentLoadsReportEnabled)) return result;
    json facility=json::object(),facility_totals=json::object();
    if(method==Method::Ventilation) {
        auto const &predefined=*s.dataOutRptPredefined;
        facility["AnyZoneTimeBelowVozDyn"]=scalar(reports.AnyZoneTimeBelowVozDyn);
        facility["AllZonesTimeAtVozDyn"]=scalar(reports.AllZonesTimeAtVozDyn);
        facility["AnyZoneTimeAboveVozDyn"]=scalar(reports.AnyZoneTimeAboveVozDyn);
        facility["AnyZoneTimeVentUnocc"]=scalar(reports.AnyZoneTimeVentUnocc);
        facility["AnyZoneTimeBelowVozDynOcc"]=scalar(reports.AnyZoneTimeBelowVozDynOcc);
        facility["AllZonesTimeAtVozDynOcc"]=scalar(reports.AllZonesTimeAtVozDynOcc);
        facility["AnyZoneTimeAboveVozDynOcc"]=scalar(reports.AnyZoneTimeAboveVozDynOcc);
        facility_totals["TotalAnyZoneBelowVozDynForOA"]=scalar(predefined.TotalAnyZoneBelowVozDynForOA);
        facility_totals["TotalAllZonesAtVozDynForOA"]=scalar(predefined.TotalAllZonesAtVozDynForOA);
        facility_totals["TotalAnyZoneAboveVozDynForOA"]=scalar(predefined.TotalAnyZoneAboveVozDynForOA);
        facility_totals["TotalAnyZoneVentUnoccForOA"]=scalar(predefined.TotalAnyZoneVentUnoccForOA);
        facility_totals["TotalAnyZoneBelowVozDynOccForOA"]=scalar(predefined.TotalAnyZoneBelowVozDynOccForOA);
        facility_totals["TotalAllZonesAtVozDynOccForOA"]=scalar(predefined.TotalAllZonesAtVozDynOccForOA);
        facility_totals["TotalAnyZoneAboveVozDynOccForOA"]=scalar(predefined.TotalAnyZoneAboveVozDynOccForOA);
        result["facility_report"]=facility;result["facility_predefined_totals"]=facility_totals;
        result["StdRhoAir"]=scalar(environment.StdRhoAir);
        result["OARequirements_shape"]=shape(s.dataSize->OARequirements);
        result["ZoneAirDistribution_shape"]=shape(s.dataSize->ZoneAirDistribution);
        result["SysVentRepVars_shape"]=shape(reports.SysVentRepVars);
        result["SysPreDefRep_shape"]=shape(reports.SysPreDefRep);
    } else result["SysLoadRepVars_shape"]=shape(reports.SysLoadRepVars);
    json zones=json::array();
    for(int zone=1;zone<=g.NumOfZones;++zone) {
        json row{{"index",zone},{"Zone_shape",shape(s.dataHeatBal->Zone)},
            {"config",equipment_config(s,zone,method)}};
        if(method==Method::Ventilation) row["report"]=zone_report(s,zone);
        auto const &configs=s.dataZoneEquip->ZoneEquipConfig;
        if(!contains(configs,zone) || !configs(zone).IsControlled) {zones.push_back(row);continue;}
        row["DeadBandOrSetback"]=int_slot(s.dataZoneEnergyDemand->DeadBandOrSetback,zone);
        if(contains(s.dataZoneEnergyDemand->ZoneSysEnergyDemand,zone)) {
            auto const &v=s.dataZoneEnergyDemand->ZoneSysEnergyDemand(zone);
            row["demand"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},{"TotalOutputRequired",scalar(v.TotalOutputRequired)}};
        } else row["demand"]=nullptr;
        if(method==Method::Energy) {zones.push_back(row);continue;}
        row["predefined"]=zone_predefined(s,zone);
        row["equipment_list"]=equipment_list(s,configs(zone).EquipListIndex);
        if(contains(s.dataHeatBal->Zone,zone)) {
            auto const &z=s.dataHeatBal->Zone(zone);
            row["zone"]={{"address",reinterpret_cast<std::uintptr_t>(&z)},{"Name",z.Name},
                {"Multiplier",z.Multiplier},{"ListMultiplier",z.ListMultiplier},{"Volume",scalar(z.Volume)}};
        } else row["zone"]=nullptr;
        if(contains(s.dataZoneTempPredictorCorrector->zoneHeatBalance,zone)) {
            auto const &v=s.dataZoneTempPredictorCorrector->zoneHeatBalance(zone);
            row["air"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},{"MAT",scalar(v.MAT)},{"airHumRatAvg",scalar(v.airHumRatAvg)}};
        } else row["air"]=nullptr;
        if(contains(s.dataHeatBal->ZnAirRpt,zone)) {
            auto const &v=s.dataHeatBal->ZnAirRpt(zone);
            row["ZnAirRpt"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},
                {"InfilVolumeCurDensity",scalar(v.InfilVolumeCurDensity)},{"InfilVolumeStdDensity",scalar(v.InfilVolumeStdDensity)},
                {"VentilVolumeCurDensity",scalar(v.VentilVolumeCurDensity)},{"VentilVolumeStdDensity",scalar(v.VentilVolumeStdDensity)}};
        } else row["ZnAirRpt"]=nullptr;
        zones.push_back(row);
    }
    result["zones"]=zones;return result;
}
void record(Scope const &scope,char const *phase) noexcept {
    if(!active || !scope.selected || !increment(active->attempted)) return;
    try {
        json event{{"event_ordinal",active->attempted},{"method",name(scope.method)},
            {"invocation_ordinal",scope.invocation},{"phase",phase},
            {"parent_method",scope.parent ? json(name(scope.parent->method)) : json(nullptr)},
            {"parent_invocation_ordinal",scope.parent ? json(scope.parent->invocation) : json(nullptr)},
            {"clock",clock(scope.state)},{"state",snapshot(scope.state,scope.method)}};
        auto bytes=event.dump();if(!active->first) active->stream<<',';active->stream<<bytes;
        if(!active->stream) {active->stream_failed=true;return;}
        active->first=false;increment(active->retained);
    } catch(...) {increment(active->failures);}
}
} // anonymous
Binding::Binding(Capture &capture) noexcept : previous(active) {active=&capture;}
Binding::~Binding() noexcept {active=previous;}
Scope::Scope(EnergyPlus::EnergyPlusData const &state,Method method) noexcept
    :state(state),method(method),parent(current),exceptions(std::uncaught_exceptions()) {
    current=this;if(!active) return;
    auto index=static_cast<unsigned>(method);if(!increment(active->entered[index])) return;
    invocation=active->entered[index];selected=true;
    increment(active->selected[index]);record(*this,"entry");
}
Scope::~Scope() noexcept {
    if(active && selected) {
        bool const unwinding=std::uncaught_exceptions()>exceptions;
        increment(unwinding ? active->unwound[static_cast<unsigned>(method)] : active->normal[static_cast<unsigned>(method)]);
        record(*this,unwinding ? "unwind" : "normal_exit");
    }
    current=parent;
}
bool finish(Capture &capture,bool returned,int code,char const *exception) noexcept {
    try {
        json methods=json::array();
        for(unsigned i=0;i<static_cast<unsigned>(Method::Count);++i)
            methods.push_back({{"method",name(static_cast<Method>(i))},{"entered",capture.entered[i]},
                {"selected",capture.selected[i]},{"normal_exits",capture.normal[i]},{"unwinds",capture.unwound[i]}});
        json end{{"actual_engine_entry_returned",returned},{"actual_engine_exit_code",returned ? json(code):json(nullptr)},
            {"outer_caught_exception_class",exception ? json(exception):json(nullptr)},{"methods",methods},
            {"attempted_events",capture.attempted},{"retained_events",capture.retained},{"copy_failures",capture.failures},
            {"counter_overflow",capture.overflow},{"stream_failed",capture.stream_failed},
            {"selection","all actual entries to two complete report functions; no value/time/zone sampling"},
            {"numeric_equivalence_or_PASS_claimed",false}};
        capture.stream<<"],\"terminal_summary\":"<<end.dump()<<"}\n";capture.stream.flush();
        return bool(capture.stream)&&!capture.stream_failed&&!capture.overflow&&capture.failures==0&&capture.attempted==capture.retained;
    } catch(...) {return false;}
}
} // namespace SystemReportObservation

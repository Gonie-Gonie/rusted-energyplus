"""ROOT ONLY: apply seven reviewed test-only report cohort Sources after full guards."""
from pathlib import Path
import ast,hashlib,json,re,subprocess,sys,tomllib
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-system-report-cohort-application-40'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert len(sys.argv)==2 and not O.exists()
mr=ref(D/'source-system-report-cohort-held-Audit-40/manifest.json');assert mr['sha256']==sys.argv[1]=='1a14003b55fccf5381cc0ded3e2fa23a55fd8a8eb6f809828803202d7955a220';m=json.loads(checked(mr))
pr=m['independent_full_semantic_peer'];p=json.loads(checked(pr));assert p['accepted'] and not p['findings'] and p['reviewed_draft']==m['original_draft'];peerfiles={f['canonical_path']:f for f in p['files']};assert len(peerfiles)==7
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip()==m['base_HEAD']=='e47c117f313281428d6c928c4007e580b557a4fa' and not git('status','--porcelain','--untracked-files=normal').strip()
production=json.loads(checked(m['accepted41_production_actual_review']));assert production['accepted'] and not production['findings'] and production['original_tolerance_RMSE_5352_proof_transferred']
oldplan=json.loads(checked(m['prior_complete_compiler_Source_plan']));oldrows={r['path']:r for r in oldplan['entries']};archives={f['historical_path']:f for f in json.loads(checked(m['actual_parent_snapshot']))['files']};assert len(oldrows)==4508 and sum(n.endswith('.rs') for n in oldrows)==4495 and set(oldrows)==set(archives)
inventory={p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert inventory==set(oldrows)
for n,row in oldrows.items():
 b=checked(row['source']);assert b==(R/n).read_bytes()==checked(archives[n]['archive']) and len(b)==row['final_bytes']==archives[n]['size_bytes'] and hashlib.sha256(b).hexdigest()==row['final_sha256'],n
tree=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=[];old=[]
for f in m['files']:
 n=f['canonical_path'];a=checked(f['before']);b=checked(f['proposed']);target=(R/n).resolve();assert target.is_relative_to(R) and n not in selected
 if f['before_absent']:
  assert not a and n not in oldrows and not target.exists() and subprocess.run(['git','cat-file','-e',head+':'+n],cwd=R,capture_output=True).returncode!=0;new.append(n)
 else:
  assert n in oldrows and a==target.read_bytes()==checked(oldrows[n]['source'])==git('show',head+':'+n) and target.stat().st_nlink==1;old.append(n)
 assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
 assert b==checked(f['reviewed_draft_whole'])==checked(peerfiles[n]['proposed']) and f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stderr'])
 assert a.count(b'#[test]')==b.count(b'#[test]');selected[n]=f
assert len(old)==5 and len(new)==2 and len(selected)==7
F='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/'
assert checked(selected[F+'native_cohort.rs']['proposed']).startswith(checked(selected[F+'native_cohort.rs']['before']))
checked(m['old_air_fixture_whole_unchanged']);cargo=tomllib.loads(checked(m['unchanged_Cargo_target_feature']['manifest']).decode());assert cargo['features']['native-controlled-air-cohort']==[] and {'name':'native_controlled_air_cohort','path':'src/lib.rs','harness':False,'required-features':['native-controlled-air-cohort']} in cargo['test']
lib=selected['crates/ep_runtime/src/lib.rs'];gate=b'#[cfg(all(test, feature = "native-controlled-air-cohort"))]';assert checked(lib['before']).split(gate,1)[0]==checked(lib['proposed']).split(gate,1)[0]
eq=selected['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'];assert checked(eq['proposed']).startswith(checked(eq['before']))
hub=selected['crates/ep_runtime/src/heat_balance/ordinary_system_reports.rs'];a=checked(hub['before']);b=checked(hub['proposed']).split(b'// Captured entry restoration',1)[0];assert a.split(b'\n',1)[1].rstrip(b'\n')==b.split(b'\n',1)[1].rstrip(b'\n')
state=selected['crates/ep_runtime/src/heat_balance/ordinary_system_reports/state.rs'];assert checked(state['before']).split(b'\n',1)[1]==checked(state['proposed']).split(b'\n',1)[1]
for f in m['actual41_two_unselected_production_Source_carry']:assert (R/f['canonical_path']).read_bytes()==checked(f['actual41_proposed'])
run=json.loads(checked(m['actual_Native_unit_run']));assert run['accepted'] and not run['findings'] and run['exit_code']==0 and run['actual_three_GNU_DLL_binding_proved'];assert checked(m['finite_Native_unit_full_output'])==Path(run['full_unit_output']['path']).read_bytes();checked(m['finite_Native_engine_observation']);checked(m['strict_fixture_projection_proof']);checked(m['Source_fixture_projector']);checked(m['whole4497_Rust_API_census']);checked(m['full4508_parent_readback'])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert len(rows)==4510 and sum(n.endswith('.rs') for n in rows)==4497 and set(rows)==inventory|set(new)
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 target=R/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result={'schema':'src06-system-report-cohort-application40.v1','accepted':True,'findings':[],'base_HEAD':head,'producer':mr,'independent_peer':pr,'complete_compiler_plan':m['complete_final_compiler_Source_plan'],'selected':selected,'selected_Source_files':7,'existing_Source_files':5,'new_Source_files':2,'literal_applications':14,'all4508_parent_archive_live_plan_exact':True,'selected5_before_Git_exact':True,'all4510_final_plan_live_equal':True,'original_Air_cohort_prefix_fixture_whole_exact':True,'production_numerical_bodies_unchanged_after_cfg_exclusion':True,'same_Cargo_target_feature_unchanged':True,'new_test_bodies':0,'existing_cohort_body_extended':1,'inherited_production_integration':m['accepted41_production_actual_review'],'actual_Native_unit_run':m['actual_Native_unit_run'],'command':m['command'],'validation_policy':m['validation_policy'],'Root_focused_test_status':'PENDING one existing safe process-main target --report-only; no CLI/Native/Air rerun','Cargo_tests_or_Native_executed':False,'literal_helper_Source':ref(D/'review-meter-final-predefined-Root-01.py'),'author_Source':ref(Path(__file__))}
p=O/'receipt.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

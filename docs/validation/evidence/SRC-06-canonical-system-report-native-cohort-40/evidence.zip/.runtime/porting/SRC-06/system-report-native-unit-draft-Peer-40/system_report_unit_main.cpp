// Private Native full-function replay unit. No engine entry or scientific formula copies.
// The unchanged accepted observer implementation supplies only stored-member snapshots.
#include "../system-report-native-draft-Peer-39/system_report_observer.cc"
#include <fstream>
#include <filesystem>
#include <iostream>
#include <map>
#include <memory>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>

namespace ReportUnit {
using json = nlohmann::json;
using EnergyPlus::EnergyPlusData;
using Method = SystemReportObservation::Method;
void require(bool ok, std::string const &why) { if (!ok) throw std::runtime_error(why); }
double real(json const &v) {
    auto const text=v.at("value_bits").get<std::string>();
    require(v.size()==1 && text.size()==16,"raw16hex scalar required");
    std::uint64_t bits=0;
    for(char c:text) { require((c>='0'&&c<='9')||(c>='a'&&c<='f'),"lowercase raw16hex"); bits=(bits<<4)|static_cast<unsigned>(c<='9'?c-'0':c-'a'+10); }
    double value; std::memcpy(&value,&bits,sizeof(value));
    require(std::isfinite(value),"finite actual input required"); return value;
}
std::uint64_t bits(double value) { std::uint64_t out; std::memcpy(&out,&value,sizeof(out)); return out; }
double from_bits(std::uint64_t value) { double out; std::memcpy(&out,&value,sizeof(out)); return out; }
json strip_addresses(json v) {
    if(v.is_object()) {
        for(char const *key:{"address","owner_address","manager_address","state_address"}) v.erase(key);
        for(auto &child:v.items()) child.value()=strip_addresses(std::move(child.value()));
    } else if(v.is_array()) for(auto &child:v) child=strip_addresses(std::move(child));
    return v;
}
template<class A> void allocate_like(A &array,json const &shape) {
    require(!array.allocated(),"fresh genuine container required");
    if(!shape.at("allocated").get<bool>()) return;
    int n=shape.at("size").get<int>(); require(n>=0,"nonnegative actual extent");
    if constexpr(requires {array.l();array.u();}) {
        require(shape.at("lower")==1 && shape.at("upper")==n,"finite actual one-based container required");
    }
    array.allocate(n);
}
void restore_clock(EnergyPlusData &s,json const &c) {
    auto &g=*s.dataGlobal; auto &h=*s.dataHVACGlobal; auto &e=*s.dataEnvrn;
    g.CalendarYear=c.at("CalendarYear").get<int>();
    g.DayOfSim=c.at("DayOfSim").get<int>();
    g.HourOfDay=c.at("HourOfDay").get<int>();
    g.TimeStep=c.at("TimeStep").get<int>();
    e.Month=c.at("Month").get<int>();
    e.DayOfMonth=c.at("DayOfMonth").get<int>();
    h.NumOfSysTimeSteps=c.at("NumOfSysTimeSteps").get<int>();
    h.NumOfSysTimeStepsLastZoneTimeStep=c.at("NumOfSysTimeStepsLastZoneTimeStep").get<int>();
    g.CurrentTime=real(c.at("CurrentTime"));
    g.TimeStepZone=real(c.at("TimeStepZone"));
    g.TimeStepZoneSec=real(c.at("TimeStepZoneSec"));
    h.TimeStepSys=real(c.at("TimeStepSys"));
    h.TimeStepSysSec=real(c.at("TimeStepSysSec"));
    h.SysTimeElapsed=real(c.at("SysTimeElapsed"));
    h.FracTimeStepZone=real(c.at("FracTimeStepZone"));
    h.PreviousTimeStep=real(c.at("PreviousTimeStep"));
    e.OutBaroPress=real(c.at("OutBaroPress"));
    e.OutHumRat=real(c.at("OutHumRat"));
    g.WarmupFlag=c.at("WarmupFlag").get<bool>();
    g.DoingSizing=c.at("DoingSizing").get<bool>();
    g.KickOffSimulation=c.at("KickOffSimulation").get<bool>();
    g.BeginSimFlag=c.at("BeginSimFlag").get<bool>();
    g.BeginEnvrnFlag=c.at("BeginEnvrnFlag").get<bool>();
    g.BeginDayFlag=c.at("BeginDayFlag").get<bool>();
    g.BeginTimeStepFlag=c.at("BeginTimeStepFlag").get<bool>();
    h.FirstTimeStepSysFlag=c.at("FirstTimeStepSysFlag").get<bool>();
    h.ShortenTimeStepSys=c.at("ShortenTimeStepSys").get<bool>();
    h.UseZoneTimeStepHistory=c.at("UseZoneTimeStepHistory").get<bool>();
    e.CurEnvirNum=c.at("environment_index").get<int>();
    e.EnvironmentName=c.at("environment_name").get<std::string>();
    g.KindOfSim=static_cast<decltype(g.KindOfSim)>(c.at("KindOfSim").get<int>());
}
std::unique_ptr<EnergyPlusData> restore(json const &event) {
    auto state=std::make_unique<EnergyPlusData>(); auto &s=*state;
    // No init_state/process_idf/engine call: original constructors plus exact observed consumed fields.
    auto const &v=event.at("state"); auto const &flags=v.at("flags"); auto &r=*s.dataSysRpts;
    restore_clock(s,event.at("clock"));
    r.AirLoopLoadsReportEnabled=flags.at("AirLoopLoadsReportEnabled").get<bool>();
    r.VentReportStructureCreated=flags.at("VentReportStructureCreated").get<bool>();
    r.VentLoadsReportEnabled=flags.at("VentLoadsReportEnabled").get<bool>();
    r.VentEnergyReportEnabled=flags.at("VentEnergyReportEnabled").get<bool>();
    s.dataGlobal->NumOfZones=flags.at("NumOfZones").get<int>();
    s.dataGlobal->DoOutputReporting=flags.at("DoOutputReporting").get<bool>();
    s.dataGlobal->ZoneSizingCalc=flags.at("ZoneSizingCalc").get<bool>();
    s.dataHVACGlobal->NumPrimaryAirSys=flags.at("NumPrimaryAirSys").get<int>();
    s.dataHVACGlobal->NumPlantLoops=flags.at("NumPlantLoops").get<int>();
    s.dataHVACGlobal->NumCondLoops=flags.at("NumCondLoops").get<int>();
    require(s.dataHVACGlobal->NumPrimaryAirSys==0 && s.dataHVACGlobal->NumPlantLoops==0 && s.dataHVACGlobal->NumCondLoops==0,"captured finite no-primary/no-plant domain");
    auto const method=event.at("method").get<std::string>();
    bool const vent=method=="ReportVentilationLoads";
    require(vent || method=="ReportSystemEnergyUse","exact genuine method");
    bool const enabled=vent ? r.VentReportStructureCreated&&r.VentLoadsReportEnabled : r.AirLoopLoadsReportEnabled;
    if(!enabled) return state;
    auto const &zones=v.at("zones"); require(static_cast<int>(zones.size())==s.dataGlobal->NumOfZones,"actual zone extent");
    require(!zones.empty(),"actual base capture has zones");
    allocate_like(s.dataHeatBal->Zone,zones.at(0).at("Zone_shape"));
    allocate_like(s.dataZoneEquip->ZoneEquipConfig,zones.at(0).at("config"));
    s.dataZoneEnergyDemand->ZoneSysEnergyDemand.allocate(s.dataGlobal->NumOfZones);
    allocate_like(s.dataZoneEnergyDemand->DeadBandOrSetback,zones.at(0).at("DeadBandOrSetback"));
    if(vent) {
        s.dataEnvrn->StdRhoAir=real(v.at("StdRhoAir"));
        allocate_like(s.dataSize->OARequirements,v.at("OARequirements_shape"));
        allocate_like(s.dataSize->ZoneAirDistribution,v.at("ZoneAirDistribution_shape"));
        allocate_like(r.SysVentRepVars,v.at("SysVentRepVars_shape"));
        allocate_like(r.SysPreDefRep,v.at("SysPreDefRep_shape"));
        allocate_like(r.ZoneVentRepVars,zones.at(0).at("report"));
        allocate_like(s.dataHeatBal->ZonePreDefRep,zones.at(0).at("predefined"));
        allocate_like(s.dataZoneEquip->ZoneEquipList,zones.at(0).at("equipment_list"));
        s.dataZoneTempPredictorCorrector->zoneHeatBalance.allocate(s.dataGlobal->NumOfZones);
        s.dataHeatBal->ZnAirRpt.allocate(s.dataGlobal->NumOfZones);
        r.AnyZoneTimeBelowVozDyn=real(v.at("facility_report").at("AnyZoneTimeBelowVozDyn"));
        r.AllZonesTimeAtVozDyn=real(v.at("facility_report").at("AllZonesTimeAtVozDyn"));
        r.AnyZoneTimeAboveVozDyn=real(v.at("facility_report").at("AnyZoneTimeAboveVozDyn"));
        r.AnyZoneTimeVentUnocc=real(v.at("facility_report").at("AnyZoneTimeVentUnocc"));
        r.AnyZoneTimeBelowVozDynOcc=real(v.at("facility_report").at("AnyZoneTimeBelowVozDynOcc"));
        r.AllZonesTimeAtVozDynOcc=real(v.at("facility_report").at("AllZonesTimeAtVozDynOcc"));
        r.AnyZoneTimeAboveVozDynOcc=real(v.at("facility_report").at("AnyZoneTimeAboveVozDynOcc"));
        s.dataOutRptPredefined->TotalAnyZoneBelowVozDynForOA=real(v.at("facility_predefined_totals").at("TotalAnyZoneBelowVozDynForOA"));
        s.dataOutRptPredefined->TotalAllZonesAtVozDynForOA=real(v.at("facility_predefined_totals").at("TotalAllZonesAtVozDynForOA"));
        s.dataOutRptPredefined->TotalAnyZoneAboveVozDynForOA=real(v.at("facility_predefined_totals").at("TotalAnyZoneAboveVozDynForOA"));
        s.dataOutRptPredefined->TotalAnyZoneVentUnoccForOA=real(v.at("facility_predefined_totals").at("TotalAnyZoneVentUnoccForOA"));
        s.dataOutRptPredefined->TotalAnyZoneBelowVozDynOccForOA=real(v.at("facility_predefined_totals").at("TotalAnyZoneBelowVozDynOccForOA"));
        s.dataOutRptPredefined->TotalAllZonesAtVozDynOccForOA=real(v.at("facility_predefined_totals").at("TotalAllZonesAtVozDynOccForOA"));
        s.dataOutRptPredefined->TotalAnyZoneAboveVozDynOccForOA=real(v.at("facility_predefined_totals").at("TotalAnyZoneAboveVozDynOccForOA"));
    } else allocate_like(r.SysLoadRepVars,v.at("SysLoadRepVars_shape"));
    for(auto const &row:zones) {
        int z=row.at("index").get<int>(); auto const &config=row.at("config").at("value");
        auto &cfg=s.dataZoneEquip->ZoneEquipConfig(z); cfg.IsControlled=config.at("IsControlled").get<bool>();
        require(cfg.IsControlled,"actual153 base cohorts controlled; no inferred uncontrolled data");
        cfg.NumInletNodes=config.at("NumInletNodes").get<int>();
        allocate_like(cfg.InletNodeAirLoopNum,config.at("InletNodeAirLoopNum"));
        for(int i=1;i<=cfg.NumInletNodes;++i) {
            cfg.InletNodeAirLoopNum(i)=config.at("InletNodeAirLoopNum").at("values").at(i-1).get<int>();
            require(cfg.InletNodeAirLoopNum(i)==0,"finite actual no-primary inlet route");
        }
        s.dataZoneEnergyDemand->ZoneSysEnergyDemand(z).TotalOutputRequired=real(row.at("demand").at("TotalOutputRequired"));
        s.dataZoneEnergyDemand->DeadBandOrSetback(z)=row.at("DeadBandOrSetback").at("value").get<int>()!=0;
        if(!vent) continue;
        cfg.EquipListIndex=config.at("EquipListIndex").get<int>();
        cfg.ZoneDesignSpecOAIndex=config.at("ZoneDesignSpecOAIndex").get<int>();
        cfg.ZoneAirDistributionIndex=config.at("ZoneAirDistributionIndex").get<int>();
        require(cfg.ZoneDesignSpecOAIndex==0 && cfg.ZoneAirDistributionIndex==0,"captured finite DSOA/distribution0");
        auto const &zone=row.at("zone"); auto &native_zone=s.dataHeatBal->Zone(z);
        native_zone.Name=zone.at("Name").get<std::string>(); native_zone.Multiplier=zone.at("Multiplier").get<int>();
        native_zone.ListMultiplier=zone.at("ListMultiplier").get<int>(); native_zone.Volume=real(zone.at("Volume"));
        auto &air=s.dataZoneTempPredictorCorrector->zoneHeatBalance(z);
        air.MAT=real(row.at("air").at("MAT")); air.airHumRatAvg=real(row.at("air").at("airHumRatAvg"));
        auto &air_report=s.dataHeatBal->ZnAirRpt(z); auto const &air_values=row.at("ZnAirRpt");
        air_report.InfilVolumeCurDensity=real(air_values.at("InfilVolumeCurDensity"));
        air_report.InfilVolumeStdDensity=real(air_values.at("InfilVolumeStdDensity"));
        air_report.VentilVolumeCurDensity=real(air_values.at("VentilVolumeCurDensity"));
        air_report.VentilVolumeStdDensity=real(air_values.at("VentilVolumeStdDensity"));
        auto &pre=s.dataHeatBal->ZonePreDefRep(z); auto const &pre_values=row.at("predefined").at("value");
        pre.isOccupied=pre_values.at("isOccupied").get<bool>();
        pre.AFNVentVolStdDen=real(pre_values.at("AFNVentVolStdDen"));
        pre.TotTimeOcc=real(pre_values.at("TotTimeOcc"));
        pre.MechVentVolTotalOcc=real(pre_values.at("MechVentVolTotalOcc"));
        pre.MechVentVolMin=real(pre_values.at("MechVentVolMin"));
        pre.MechVentVolTotalOccStdDen=real(pre_values.at("MechVentVolTotalOccStdDen"));
        pre.InfilVolTotalOcc=real(pre_values.at("InfilVolTotalOcc"));
        pre.InfilVolMin=real(pre_values.at("InfilVolMin"));
        pre.InfilVolTotalOccStdDen=real(pre_values.at("InfilVolTotalOccStdDen"));
        pre.SimpVentVolTotalOcc=real(pre_values.at("SimpVentVolTotalOcc"));
        pre.SimpVentVolMin=real(pre_values.at("SimpVentVolMin"));
        pre.SimpVentVolTotalOccStdDen=real(pre_values.at("SimpVentVolTotalOccStdDen"));
        pre.VozTargetTotalOcc=real(pre_values.at("VozTargetTotalOcc"));
        pre.VozTargetTimeBelowOcc=real(pre_values.at("VozTargetTimeBelowOcc"));
        pre.VozTargetTimeAtOcc=real(pre_values.at("VozTargetTimeAtOcc"));
        pre.VozTargetTimeAboveOcc=real(pre_values.at("VozTargetTimeAboveOcc"));
        pre.TotVentTimeNonZeroUnocc=real(pre_values.at("TotVentTimeNonZeroUnocc"));
        pre.MechVentVolTotalStdDen=real(pre_values.at("MechVentVolTotalStdDen"));
        pre.InfilVolTotalStdDen=real(pre_values.at("InfilVolTotalStdDen"));
        pre.SimpVentVolTotalStdDen=real(pre_values.at("SimpVentVolTotalStdDen"));
        pre.VozTargetTotal=real(pre_values.at("VozTargetTotal"));
        pre.VozTargetTimeBelow=real(pre_values.at("VozTargetTimeBelow"));
        pre.VozTargetTimeAt=real(pre_values.at("VozTargetTimeAt"));
        pre.VozTargetTimeAbove=real(pre_values.at("VozTargetTimeAbove"));
        auto &report=r.ZoneVentRepVars(z); auto const &report_values=row.at("report").at("value");
        report.CoolingLoadMetByVent=real(report_values.at("CoolingLoadMetByVent"));
        report.CoolingLoadAddedByVent=real(report_values.at("CoolingLoadAddedByVent"));
        report.OvercoolingByVent=real(report_values.at("OvercoolingByVent"));
        report.HeatingLoadMetByVent=real(report_values.at("HeatingLoadMetByVent"));
        report.HeatingLoadAddedByVent=real(report_values.at("HeatingLoadAddedByVent"));
        report.OverheatingByVent=real(report_values.at("OverheatingByVent"));
        report.NoLoadHeatingByVent=real(report_values.at("NoLoadHeatingByVent"));
        report.NoLoadCoolingByVent=real(report_values.at("NoLoadCoolingByVent"));
        report.OAMassFlow=real(report_values.at("OAMassFlow"));
        report.OAMass=real(report_values.at("OAMass"));
        report.OAVolFlowStdRho=real(report_values.at("OAVolFlowStdRho"));
        report.OAVolStdRho=real(report_values.at("OAVolStdRho"));
        report.OAVolFlowCrntRho=real(report_values.at("OAVolFlowCrntRho"));
        report.OAVolCrntRho=real(report_values.at("OAVolCrntRho"));
        report.MechACH=real(report_values.at("MechACH"));
        report.TargetVentilationFlowVoz=real(report_values.at("TargetVentilationFlowVoz"));
        report.TimeBelowVozDyn=real(report_values.at("TimeBelowVozDyn"));
        report.TimeAtVozDyn=real(report_values.at("TimeAtVozDyn"));
        report.TimeAboveVozDyn=real(report_values.at("TimeAboveVozDyn"));
        report.TimeVentUnocc=real(report_values.at("TimeVentUnocc"));
        auto const &list=row.at("equipment_list").at("value"); auto &eq=s.dataZoneEquip->ZoneEquipList(cfg.EquipListIndex);
        eq.NumOfEquipTypes=list.at("NumOfEquipTypes").get<int>();
        allocate_like(eq.EquipType,list.at("EquipType_shape")); allocate_like(eq.EquipIndex,list.at("EquipIndex_shape"));
        require(eq.NumOfEquipTypes==static_cast<int>(list.at("equipment").size()),"actual equipment active extent");
        for(auto const &item:list.at("equipment")) {
            int j=item.at("index").get<int>(); eq.EquipType(j)=static_cast<EnergyPlus::DataZoneEquipment::ZoneEquipType>(item.at("EquipType").get<int>());
            eq.EquipIndex(j)=item.at("EquipIndex").get<int>();
            require(eq.EquipType(j)==EnergyPlus::DataZoneEquipment::ZoneEquipType::PurchasedAir && eq.EquipIndex(j)>0,"genuine PurchasedAir finite route");
            auto const &purchase=item.at("PurchasedAir"); auto &manager=*s.dataPurchasedAirMgr;
            manager.GetPurchAirInputFlag=purchase.at("GetPurchAirInputFlag").get<bool>(); require(!manager.GetPurchAirInputFlag,"actual GetInput already returned");
            manager.NumPurchAir=purchase.at("NumPurchAir").get<int>();
            if(!manager.PurchAir.allocated()) allocate_like(manager.PurchAir,purchase);
            int index=purchase.at("index").get<int>(); require(index==eq.EquipIndex(j),"actual unit ordinal");
            auto &unit=manager.PurchAir(index); auto const &unit_values=purchase.at("value");
            unit.OutdoorAirMassFlowRate=real(unit_values.at("OutdoorAirMassFlowRate")); unit.ZoneSupplyAirNodeNum=unit_values.at("ZoneSupplyAirNodeNum").get<int>();
            unit.MixedAirTemp=real(unit_values.at("MixedAirTemp")); unit.MixedAirHumRat=real(unit_values.at("MixedAirHumRat")); unit.ZoneRecircAirNodeNum=unit_values.at("ZoneRecircAirNodeNum").get<int>();
            require(unit.ZoneSupplyAirNodeNum>0 && unit.ZoneRecircAirNodeNum>0,"actual captured positive Node refs");
            if(!s.dataLoopNodes->Node.allocated()) allocate_like(s.dataLoopNodes->Node,purchase.at("supply_node"));
            auto &supply=s.dataLoopNodes->Node(unit.ZoneSupplyAirNodeNum); supply.MassFlowRate=real(purchase.at("supply_node").at("value").at("MassFlowRate"));
            auto &recirc=s.dataLoopNodes->Node(unit.ZoneRecircAirNodeNum); recirc.Temp=real(purchase.at("recirc_node").at("value").at("Temp")); recirc.HumRat=real(purchase.at("recirc_node").at("value").at("HumRat"));
        }
    }
    return state;
}
Method method_of(json const &e) { return e.at("method")=="ReportSystemEnergyUse"?Method::Energy:Method::Ventilation; }
void call(EnergyPlusData &s,Method m) {
    if(m==Method::Energy) EnergyPlus::SystemReports::ReportSystemEnergyUse(s);
    else EnergyPlus::SystemReports::ReportVentilationLoads(s);
}
json event_of(EnergyPlusData const &s,Method m,std::uint64_t ordinal,std::uint64_t invocation,char const *phase) {
    return {{"method",SystemReportObservation::name(m)},{"event_ordinal",ordinal},{"invocation_ordinal",invocation},{"phase",phase},
        {"parent_method",nullptr},{"parent_invocation_ordinal",nullptr},{"clock",SystemReportObservation::clock(s)},{"state",SystemReportObservation::snapshot(s,m)}};
}
void assert_event(json const &actual,json const &expected,std::string const &where) {
    require(strip_addresses(actual.at("state"))==strip_addresses(expected.at("state")),where+" exact entire observed state/raw bits");
    require(strip_addresses(actual.at("clock"))==strip_addresses(expected.at("clock")),where+" exact whole clock/raw bits");
}
struct Runner {
    json cases=json::array(); std::uint64_t events=0; std::array<std::uint64_t,2> invocations{};
    json run(json const &base,json const &origin,json const &overrides,json const *expected=nullptr) {
        auto input=base;
        for(auto const &change:overrides.items()) input[json::json_pointer(change.key())]=change.value();
        auto state=restore(input); Method m=method_of(input); auto invocation=++invocations[static_cast<unsigned>(m)];
        auto entry=event_of(*state,m,++events,invocation,"entry"); assert_event(entry,input,"input restoration");
        call(*state,m); auto exit=event_of(*state,m,++events,invocation,"normal_exit");
        if(expected) assert_event(exit,*expected,"captured baseline function replay");
        json row{{"origin",origin},{"input_overrides",overrides},{"entry",entry},{"expected_exit",exit},{"actual_captured_exit_bit_asserted",expected!=nullptr}};
        cases.push_back(std::move(row)); return exit;
    }
};
json scalar(double v) {return SystemReportObservation::scalar(v);}
std::string unit_path(json const &base) {
    auto const &rows=base.at("state").at("zones"); require(rows.size()==1,"named variants extend actual one-zone base only");
    auto const &items=rows.at(0).at("equipment_list").at("value").at("equipment"); require(items.size()==1,"one genuine base equipment");
    return "/state/zones/0/equipment_list/value/equipment/0/PurchasedAir";
}
json variant_overrides(json const &base,double mixed_delta,double supply,double oa,double demand,bool occupied) {
    auto p=unit_path(base); auto const &purchase=base.at("state").at("zones").at(0).at("equipment_list").at("value").at("equipment").at(0).at("PurchasedAir");
    // These are deliberately named UNIT INPUTS, never inferred simulation state.
    return {{p+"/value/MixedAirTemp",scalar(real(purchase.at("recirc_node").at("value").at("Temp"))+mixed_delta)},
        {p+"/supply_node/value/MassFlowRate",scalar(supply)},{p+"/value/OutdoorAirMassFlowRate",scalar(oa)},
        {"/state/zones/0/demand/TotalOutputRequired",scalar(demand)},
        {"/state/zones/0/DeadBandOrSetback/value",0},{"/state/zones/0/predefined/value/isOccupied",occupied}};
}
void variants(Runner &r,json const &base,json &searches) {
    auto origin=[&](std::string const &name){return json{{"kind","explicit_Native_full_function_unit_input"},{"name",name},{"base_actual_method",base.at("method")},{"base_actual_invocation",base.at("invocation_ordinal")}};};
    for(double delta:{-5.0,5.0}) for(double demand:{-1.0e9,-1.0,0.0,1.0,1.0e9}) {
        std::string name=std::string(delta<0?"mixed_cool":"mixed_heat")+"_demand_"+std::to_string(demand);
        r.run(base,origin(name),variant_overrides(base,delta,0.2,0.03,demand,true));
    }
    for(double mass:{-0.2,0.0,0.2}) for(bool occupied:{false,true}) {
        auto overrides=variant_overrides(base,1.0,mass,0.0,0.0,occupied);
        overrides["/state/zones/0/ZnAirRpt/InfilVolumeCurDensity"]=scalar(2.0);
        overrides["/state/zones/0/ZnAirRpt/InfilVolumeStdDensity"]=scalar(3.0);
        overrides["/state/zones/0/ZnAirRpt/VentilVolumeCurDensity"]=scalar(4.0);
        overrides["/state/zones/0/ZnAirRpt/VentilVolumeStdDensity"]=scalar(5.0);
        overrides["/state/zones/0/predefined/value/AFNVentVolStdDen"]=scalar(6.0);
        r.run(base,origin("natural_volumes_supply_"+std::to_string(mass)+(occupied?"_occupied":"_unoccupied")),overrides);
    }
    for(double demand:{-std::nextafter(0.1,1.0),-0.1,-std::nextafter(0.1,0.0),0.0,std::nextafter(0.1,0.0),0.1,std::nextafter(0.1,1.0)})
        for(double delta:{-1.0,1.0}) r.run(base,origin("demand_threshold_bits_"+scalar(demand).at("value_bits").get<std::string>()+(delta<0?"_cool":"_heat")),variant_overrides(base,delta,0.2,0.01,demand,false));
    {auto p=unit_path(base); auto overrides=variant_overrides(base,0.0,0.2,0.01,0.0,true);
     overrides[p+"/value/MixedAirHumRat"]=scalar(0.012);
     r.run(base,origin("mixed_humidity_is_distinct_unit_input"),overrides);}
    {auto overrides=variant_overrides(base,1.0,0.2,0.01,0.0,true); overrides["/state/zones/0/zone/Volume"]=scalar(0.0);
     r.run(base,origin("zero_zone_volume_skips_ACH_assignment"),overrides);}
    {auto overrides=variant_overrides(base,1.0,0.2,0.01,1.0e9,true); overrides["/state/zones/0/DeadBandOrSetback/value"]=1;
     r.run(base,origin("true_deadband_overrides_positive_demand"),overrides);}
    for(double delta:{-1.0,1.0}) {
        std::uint64_t low=bits(0.0),high=bits(0.2); unsigned probes=0;
        auto active=[&](std::uint64_t mass_bits){
            auto output=r.run(base,origin(std::string("vent_abs_0p1_native_branch_probe_")+(delta<0?"cool_":"heat_")+std::to_string(probes++)),
                variant_overrides(base,delta,from_bits(mass_bits),0.0,0.0,true));
            return real(output.at("state").at("zones").at(0).at("report").at("value").at(delta<0?"NoLoadCoolingByVent":"NoLoadHeatingByVent"))!=0.0;
        };
        require(!active(low) && active(high),"full Native branch brackets threshold");
        while(high-low>1) { auto mid=low+(high-low)/2; if(active(mid)) high=mid; else low=mid; }
        require(!active(low)&&active(high)&&high==low+1,"adjacent positive binary64 branch input pair");
        searches.push_back({{"kind","full_Native_function_branch_oracle_only"},{"mixed_temperature_delta_unit_input",scalar(delta)},
            {"zero_classification_mass_bits",scalar(from_bits(low))},{"nonzero_classification_mass_bits",scalar(from_bits(high))},
            {"positive_binary64_bit_distance",high-low},{"full_function_probe_count",probes},
            {"no_load_H_Rho_or_report_value_reconstructed_or_injected",true}});
    }
}
} // namespace ReportUnit
int main(int argc,char **argv) {
    using namespace ReportUnit;
    try {
        require(argc==5 && std::string(argv[1])=="--capture" && std::string(argv[3])=="--output","--capture AUTHENTIC.json --output FRESH.json");
        std::filesystem::path output=std::filesystem::absolute(argv[4]); require(!std::filesystem::exists(output),"fresh unit output");
        std::ifstream input(argv[2],std::ios::binary); require(bool(input),"actual capture input opens"); json capture=json::parse(input);
        require(capture.at("schema")=="src06-system-report-native-observation.v1","genuine engine capture schema");
        auto const &terminal=capture.at("terminal_summary"); require(terminal.at("actual_engine_exit_code")==0 && terminal.at("copy_failures")==0,"actual engine0 complete capture");
        std::map<std::pair<std::string,std::uint64_t>,json> exits;
        for(auto const &event:capture.at("events")) if(event.at("phase")=="normal_exit")
            require(exits.emplace(std::make_pair(event.at("method").get<std::string>(),event.at("invocation_ordinal").get<std::uint64_t>()),event).second,"unique actual exit");
        Runner runner; json base_vent; std::array<std::uint64_t,2> base_counts{};
        for(auto const &event:capture.at("events")) if(event.at("phase")=="entry") {
            auto key=std::make_pair(event.at("method").get<std::string>(),event.at("invocation_ordinal").get<std::uint64_t>());
            auto at=exits.find(key); require(at!=exits.end(),"all actual entries have exits");
            runner.run(event,{{"kind","actual_engine_entry_replay"},{"method",key.first},{"actual_invocation",key.second}},json::object(),&at->second);
            ++base_counts[static_cast<unsigned>(method_of(event))];
            if(base_vent.is_null() && method_of(event)==Method::Ventilation) base_vent=event;
        }
        for(unsigned i=0;i<2;++i) require(base_counts[i]==terminal.at("methods").at(i).at("entered").get<std::uint64_t>() && base_counts[i]>0,"every genuine base entry replayed");
        require(runner.cases.size()==exits.size(),"all original E/V exits exactly asserted before variants");
        json searches=json::array(); variants(runner,base_vent,searches);
        json result{{"schema","src06-system-report-full-Native-unit.v1"},{"accepted",true},{"findings",json::array()},
            {"producer","genuine original core SystemReports full functions; no engine or extracted formula"},
            {"actual_engine_base_counts",base_counts},{"all_actual_base_exit_bits_asserted_before_variants",true},
            {"address_only_comparison_qualification","remove address/owner_address/manager_address/state_address only; all observed fields, allocation extents, values and clocks exact"},
            {"named_variant_count",runner.cases.size()-exits.size()},{"near_threshold_input_searches",searches},{"cases",runner.cases},
            {"positive_primary_DSOA_distribution_or_Source_scientific_PASS_claimed",false}};
        std::ofstream out(output,std::ios::binary); require(bool(out),"fresh output opens"); out<<result.dump()<<'\n'; out.flush(); require(bool(out),"complete unit output flush");
        std::cout<<"Native full report functions: every actual base bit-asserted; named unit inputs emitted\n"; return 0;
    } catch(std::exception const &error) {std::cerr<<error.what()<<'\n'; return 1;}
}

"""Root-only: one direct frozen-argv C++ compile and one original-core link; no unit run."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,re,subprocess,time
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';B=R/'.runtime/ep261-gcc13-o0'
P=D/'system-report-native-unit-build-prepared-Peer-40-02/manifest.json'
M=D/'system-report-native-unit-build-Root-40'
def ref(p):
 p=p.resolve()
 with p.open('rb') as s:h=hashlib.file_digest(s,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(row):
 p=(R/row['path']).resolve(); a=ref(p); assert a['sha256']==row['sha256'] and a['bytes']==row.get('bytes',a['bytes']),row['path'];return p
def read(p):return json.loads(p.read_bytes())
def write(name,obj):
 p=M/name
 with p.open('xb') as f:f.write((json.dumps(obj,indent=2)+'\n').encode())
 return ref(p)
def norm(v):return str(v).replace('\\','/').casefold()
def record(command,label,environment):
 start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();code=None;error=None
 with (M/(label+'.stdout')).open('xb') as out,(M/(label+'.stderr')).open('xb') as err:
  try:code=subprocess.run(command,cwd=B,env=environment,stdout=out,stderr=err).returncode
  except OSError as e:error={'type':type(e).__name__,'message':str(e)}
 return dict(command=command,cwd=B.as_posix(),exit_code=code,launch_error=error,started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,stdout=ref(M/(label+'.stdout')),stderr=ref(M/(label+'.stderr')))
def main(args):
 assert args.build_only and not M.exists()
 prep=read(P);assert checked(prep['launcher_Source'])==Path(__file__).resolve()
 dp=checked(prep['draft']);p=read(dp);assert p['status']=='PREPARED_NO_BUILD_OR_UNIT_EXECUTED'
 peerpath,digest=args.peer.rsplit('#',1);peerpath=(R/peerpath).resolve();assert ref(peerpath)['sha256']==digest
 peer=read(peerpath);assert peer['accepted'] and not peer['findings']
 assert peer.get('reviewed_draft',peer.get('reviewed_packet'))==ref(dp)
 frozen=read(checked(p['frozen_environment']));assert frozen['accepted'] and frozen['provider_set_complete_for_this_build'];env=frozen['environment']
 assert len(env)==len({k.casefold() for k in env}); assert all(isinstance(k,str) and isinstance(v,str) for k,v in env.items())
 parent=read(checked(p['actual_accepted_build39']));harness=read(checked(parent['accepted_harness']))
 observer_header=next(row for row in harness['payload'] if Path(row['path']).name=='system_report_observer.hh');checked(observer_header)
 compiler=checked(frozen['compiler']);assert norm(p['one_compile_argv'][0])==norm(compiler) and norm(p['one_link_argv'][0])==norm(compiler)
 assert '-ffp-contract=off' in p['one_compile_argv'] and '-UNDEBUG' in p['one_compile_argv']
 assert '-ffp-contract=off' in p['one_link_argv'] and not any('fast-math' in v for v in p['one_link_argv'])
 u=Path(p['fresh_unit_directory']);assert u.resolve()==Path('D:/CodexBuild/rusted-energyplus/SRC-06/system-report-native-unit-Root-40').resolve() and not u.exists()
 assert all(Path(p[k]).resolve().is_relative_to(u.resolve()) for k in ('object','binary','map','implib'))
 def custody():
  print('Native40 custody: unchanged core/ordered archives/providers/registry and selected Sources.',flush=True)
  rows=[prep['draft'],prep['launcher_Source'],prep['author_Source'],ref(P),ref(peerpath),p['main_Source'],p['template_Source'],p['author_Source'],
        p['accepted_observer_included_whole_unchanged'],observer_header,p['observer_parent_peer'],p['observer_field_ledger'],p['actual_accepted_build39'],p['actual_engine_capture39'],p['actual_capture_raw'],
        p['live_cache'],p['live_compile_registry'],*p['retained_actual_API_CLI_objects'],*p['actual_providers'],*p['retained_ordered_archives'],*p['pinned_runtime_DLLs'],p['frozen_environment'],*[r['whole'] for r in p['Native_authorities']]]
  rows=list({r['path']:r for r in rows}.values());actual=[ref(checked(r)) for r in rows]
  assert len(read(checked(p['live_compile_registry'])))==p['registry_count']==800
  assert norm(next(v for k,v in env.items() if k.casefold()=='path').split(';')[0])==norm(compiler.parent)
  systemroot=Path(next(v for k,v in env.items() if k.casefold()=='systemroot'))
  shadows=[u,R,systemroot/'System32',systemroot/'System',systemroot]
  assert all(not (folder/Path(row['path']).name).exists() for folder in shadows for row in p['pinned_runtime_DLLs'])
  return dict(protected_files=actual,full_explicit_environment=env,earlier_DLL_shadows_absent=True)
 before=custody();M.mkdir();u.mkdir();before_ref=write('Native-before.json',before)
 compile_receipt=record(p['one_compile_argv'],'compile',env);cr=write('compile-receipt.json',compile_receipt)
 link_receipt=None;lr=None
 if compile_receipt['exit_code']==0 and compile_receipt['launch_error'] is None:
  assert Path(p['object']).is_file();link_receipt=record(p['one_link_argv'],'link',env);lr=write('link-receipt.json',link_receipt)
 after=None;after_error=None
 try:after=custody();assert after==before
 except (AssertionError,OSError) as e:after_error={'type':type(e).__name__,'message':str(e)}
 ar=write('Native-after.json',{'custody':after,'error':after_error})
 witnesses=[];original_count=0;bad=[];map_lines=0
 success=compile_receipt['exit_code']==0 and link_receipt is not None and link_receipt['exit_code']==0 and not after_error
 if success:
  with Path(p['map']).open('r',encoding='utf8',errors='strict') as stream:
   for number,line in enumerate(stream,1):
    map_lines=number
    if re.search(r'libenergypluslib\.a\(SystemReports\.cc\.obj\)',line):
     original_count+=1
     if len(witnesses)<10:witnesses.append({'line':number,'literal':line.rstrip('\r\n')})
    if 'SystemReports.reporting.cc.obj' in line or 'system_report_observer.cc.obj' in line:bad.append({'line':number,'literal':line.rstrip('\r\n')})
  assert original_count>0 and not bad,'Original core SystemReports required; derived objects forbidden'
  assert Path(p['binary']).is_file() and Path(p['object']).is_file()
 findings=[]
 if not success:findings.append('Direct compile/link/custody did not complete with zero')
 result=dict(schema='src06-system-report-full-Native-unit-build.v1',accepted=success,findings=findings,
  reviewed_draft=ref(dp),independent_Source_peer=ref(peerpath),actual_parent_build=p['actual_accepted_build39'],
  compile=cr,link=lr,Native_before=before_ref,Native_after=ar,Native_bytes_match_before_and_after=after==before and not after_error,
  object=ref(Path(p['object'])) if Path(p['object']).exists() else None,binary=ref(Path(p['binary'])) if Path(p['binary']).exists() else None,
  map=ref(Path(p['map'])) if Path(p['map']).exists() else None,original_core_SystemReports_member_count=original_count,original_core_SystemReports_first10_witnesses=witnesses,
  forbidden_derived_object_witnesses=bad,map_lines_streamed=map_lines,actual_only_one_compile_one_link=True,
  no_CMake_cache_registry_or_Native_source_mutation=True,engine_Cargo_tests_or_unit_executed=False,launcher_Source=ref(Path(__file__)))
 print(json.dumps(write('native-build.json',result)));return 0 if success else 1
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--build-only',action='store_true');parser.add_argument('--peer',required=True)
 raise SystemExit(main(parser.parse_args()))

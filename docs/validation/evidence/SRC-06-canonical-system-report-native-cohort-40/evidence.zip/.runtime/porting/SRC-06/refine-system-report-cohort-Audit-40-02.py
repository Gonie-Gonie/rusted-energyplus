from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OLD=D/'source-system-report-cohort-draft-Audit-40';O=D/'source-system-report-cohort-draft-Audit-40-02';assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'];return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,x):return save(n,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
oldp=OLD/'draft.json';assert ref(oldp)['sha256']=='d243004be4b2b5e9214c23b3f74c118b5dad3bc2cc85231554aabd568daf40f2';old=json.loads(oldp.read_bytes())
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];changes=[]
for i,row in enumerate(old['files'],1):
 name=row['canonical_path'];before=auth(row['before']).read_bytes() if 'before' in row else b'';previous=auth(row['proposed']).read_bytes();proposed=previous
 if name.endswith('/native_cohort/report_cohort.rs'):
  s=previous.decode()
  a='''        let p=member(entry,"PurchasedAir")?;let size=allocated(p)?;let number=integer(member(p,"NumPurchAir")?)?;'''
  b='''        let p=member(entry,"PurchasedAir")?;assert_eq!(integer(member(p,"index")?)?,unit_index);let size=allocated(p)?;let number=integer(member(p,"NumPurchAir")?)?;'''
  assert s.count(a)==1;s=s.replace(a,b,1)
  a='''                let source=equipment.source_zone_equipment_config(number)?;assert_eq!(*source.is_controlled(),boolean(member(config,"IsControlled")?)?);'''
  b=a+'''
                if *source.is_controlled() {
                    assert_eq!(*source.number_inlet_nodes(),count(member(config,"NumInletNodes")?)?);
                    if is_vent {
                        assert_eq!(*source.equipment_list_index(),usize::try_from(integer(member(config,"EquipListIndex")?)?)?);
                        assert_eq!(*source.zone_design_specification_outdoor_air_index(),integer(member(config,"ZoneDesignSpecOAIndex")?)?);
                        assert_eq!(*source.zone_air_distribution_index(),integer(member(config,"ZoneAirDistributionIndex")?)?);
                    }
                }'''
  assert s.count(a)==1;s=s.replace(a,b,1)
  a='''                let predef=zones.zone_predefined.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("same predef after"))?;let raw=row_value(member(z,"predefined")?)?;'''
  b='''                let actual_zone=zones.zones.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("same Zone after"))?;let raw_zone=member(z,"zone")?;
                assert_eq!(actual_zone.name,text(member(raw_zone,"Name")?)?);
                assert_eq!(actual_zone.multiplier,integer(member(raw_zone,"Multiplier")?)?);assert_eq!(actual_zone.list_multiplier,integer(member(raw_zone,"ListMultiplier")?)?);
                assert_real(actual_zone.volume,member(raw_zone,"Volume")?,&context,"Zone volume unchanged")?;
                let actual_air_report=controller.reports.zones.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("same ZnAirRpt after"))?;
                check_reals!(actual_air_report,member(z,"ZnAirRpt")?,&context,{"InfilVolumeCurDensity"=>infil_volume_cur_density,"InfilVolumeStdDensity"=>infil_volume_std_density,"VentilVolumeCurDensity"=>ventil_volume_cur_density,"VentilVolumeStdDensity"=>ventil_volume_std_density});
'''+a
  assert s.count(a)==1;s=s.replace(a,b,1)
  a='''        let out=member(expected,"state")?;
        if enabled {'''
  b='''        let out=member(expected,"state")?;let out_flags=member(out,"flags")?;let out_clock=member(expected,"clock")?;
        assert_eq!(globals.num_of_zones,integer(member(out_flags,"NumOfZones")?)?);
        assert_eq!(hvac.number_of_primary_air_systems,integer(member(out_flags,"NumPrimaryAirSys")?)?);
        assert_real(hvac.time_step_sys,member(out_clock,"TimeStepSys")?,&context,"system step unchanged")?;
        assert_real(hvac.time_step_sys_seconds,member(out_clock,"TimeStepSysSec")?,&context,"system seconds unchanged")?;
        assert_eq!(reports.air_loop_loads_report_enabled,boolean(member(out_flags,"AirLoopLoadsReportEnabled")?)?);
        assert_eq!(reports.vent_report_structure_created,boolean(member(out_flags,"VentReportStructureCreated")?)?);
        assert_eq!(reports.vent_loads_report_enabled,boolean(member(out_flags,"VentLoadsReportEnabled")?)?);
        assert_eq!(reports.vent_energy_report_enabled,boolean(member(out_flags,"VentEnergyReportEnabled")?)?);
        if enabled && is_vent {
            assert_real(environment.std_rho_air,member(out,"StdRhoAir")?,&context,"standard rho unchanged")?;
            assert_real(environment.current_weather.out_baro_press,member(out_clock,"OutBaroPress")?,&context,"actual barometric pressure unchanged")?;
        }
        if enabled {'''
  assert s.count(a)==1;s=s.replace(a,b,1)
  proposed=s.encode();changes.append(name)
 forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name));inverse=''.join(difflib.unified_diff(proposed.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 assert ns['diff_apply'](before,forward)==proposed and ns['diff_apply'](proposed,inverse)==before
 whole=save('proposed/'+name,proposed);p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',whole['path']],capture_output=True);assert p.returncode==0,(name,p.stderr)
 files.append({'canonical_path':name,'before_absent':row['before_absent'],'before':save('before/'+name,before),'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}.forward.diff',forward.encode()),'inverse_diff':save(f'diffs/{i:02}.inverse.diff',inverse.encode()),'literal_forward_inverse_exact':True,'Source_only_parse':{'exit_code':0,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':save(f'parse/{i:02}.stderr',p.stderr)}})
 assert proposed.count(b'#[test]')==before.count(b'#[test]')
assert len(changes)==1
F='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/'
frozen={row['canonical_path']:auth(row['proposed']).read_bytes() for row in files}
assert frozen[F+'native_cohort.rs'].startswith((R/F/'native_cohort.rs').read_bytes())
assert auth(next(x for x in files if x['canonical_path'].endswith('fixtures/native_system_report_b.rs'))['proposed']).read_bytes()==auth(next(x for x in old['files'] if x['canonical_path'].endswith('fixtures/native_system_report_b.rs'))['proposed']).read_bytes()
out=dict(old);out.update({'schema':'src06-system-report-cohort40-engine-origin-scaffold02.v1','author_Source':ref(Path(__file__)),'previous_scaffold':ref(oldp),'files':files,'selected_sources':7,'existing_sources':5,'new_sources':2,'literal_applications':14,'fresh_syntax_parses':7,'whole_original_air_cohort_prefix_exact':True,'consumed_readonly_exit_checks_added':['same Config inlet/count/List/DSOA/distribution','same Zone name/multiplier/listmultiplier/volume','same ZnAirRpt four volumes','same system step/seconds/primary/global counts and report flags','same standardrho/barometric pressure'],'status':'FROZEN ENGINE-ORIGIN SCAFFOLD02 for contextual self-review; real Native unit variant outputs and final fixture/API/privacy peer/canonical parent plan are pending. NO Cargo/main/test/Native execution or Source numerical PASS.'})
print(json.dumps(dump('draft.json',out)))

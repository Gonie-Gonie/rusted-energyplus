"""Private corrected checker/publisher successors; never execute them here."""
from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'system-report-cohort-publication-prepared-Audit-40-02';assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def checked(v):
 p=R/v['path'];assert ref(p)['sha256']==v['sha256'];return p
def dump(n,v):return save(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def replacement(s,a,b):assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
oldcheck=D/'check-system-report-cohort-actual-Root-40.py';check=D/'check-system-report-cohort-actual-Root-40-02.py';s=oldcheck.read_text(encoding='utf-8')
for a,b in [('/Root-source-system-report-cohort-actual-review-40\'','/Root-source-system-report-cohort-actual-review-40-02\''),('source-system-report-cohort-held-Audit-40/manifest.json','source-system-report-cohort-held-Audit-40-02/manifest.json'),('1a14003b55fccf5381cc0ded3e2fa23a55fd8a8eb6f809828803202d7955a220','970cc54e3b740597a62d2ac7207ab6a7e3c718c9609a6cfdad80fec709fb1460'),('Root-system-report-cohort-application-40/receipt.json','Root-system-report-cohort-application-40-02/receipt.json'),('canonical-source-system-report-cohort-Root-40/receipt.json','canonical-source-system-report-cohort-Root-40-02/receipt.json')]:
 if a.startswith('/Root-'):continue
 s=replacement(s,a,b)
s=replacement(s,"O=D/'Root-source-system-report-cohort-actual-review-40'","O=D/'Root-source-system-report-cohort-actual-review-40-02'")
anchor="production=json.loads(checked(m['accepted41_production_actual_review']));"
prefix='''correction_peer=json.loads(checked(m['independent_correction_peer']));assert correction_peer['accepted'] and not correction_peer['findings'] and correction_peer['reviewed_draft']==m['raw_deadband_correction']
assert a['independent_correction_peer']==m['independent_correction_peer'] and a['actual_rewrites']==1 and a['other6_whole_exact_not_rewritten']
failed_refs=m['preserved_failed_focused_executions'];assert len(failed_refs)==1
for row in failed_refs:
 failed=json.loads(checked(row));assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after'] and b'"same DeadBand"' in checked(failed['stderr'])
 checked(failed['stdout']);checked(failed['source_snapshot'])
'''
s=replacement(s,anchor,prefix+anchor)
s=replacement(s,"'schema':'src06-system-report-Native-paired-actual-cohort40.v1'","'schema':'src06-system-report-Native-paired-actual-cohort40-02.v1'")
s=replacement(s,"'actual_executed_test_bodies':1,","'actual_executed_test_bodies':2,'failed_focused_execution_count':1,'preserved_failed_focused_executions':failed_refs,'total_source_focused_invocations':2,'original_application':m['original_application'],'original_producer':m['original_producer'],'raw_deadband_correction':m['raw_deadband_correction'],'independent_correction_peer':m['independent_correction_peer'],")
s=replacement(s,"'test_result':'PASS: one existing safe process-main target", "'test_result':'PASS after correcting one test-entry allocation omission: preserve first failed invocation and one successful invocation. The same existing safe process-main target")
ast.parse(s);check.write_text(s,encoding='utf-8',newline='');checker_delta=save('checker-forward.diff',''.join(difflib.unified_diff(oldcheck.read_text(encoding='utf-8').splitlines(keepends=True),s.splitlines(keepends=True),fromfile='original-checker40',tofile='corrected-checker40-02')).encode())
oldpub=D/'publish-system-report-cohort-checkpoint-Audit-40.py';pub=D/'publish-system-report-cohort-checkpoint-Audit-40-02.py';p=oldpub.read_text(encoding='utf-8')
p=replacement(p,"system-report-cohort-publication-readback-Audit-40'","system-report-cohort-publication-readback-Audit-40-02'")
p=replacement(p,"t['status']=='HELD_READY_FOR_ROOT_REPORT_COHORT40_AND_FULL_READ'","t['status']=='HELD_READY_FOR_ROOT_REPORT_COHORT40_02_AND_FULL_READ'")
p=replacement(p," assert actual['actual_executed_test_bodies']==actual['successful_main_report_cohort_executions']==1 and actual['new_test_bodies']==0"," assert actual['actual_executed_test_bodies']==actual['total_source_focused_invocations']==2 and actual['successful_main_report_cohort_executions']==actual['failed_focused_execution_count']==1 and actual['new_test_bodies']==0\n assert actual['preserved_failed_focused_executions']==producer['preserved_failed_focused_executions'] and contains(actual,producer['independent_correction_peer'])")
p=replacement(p," for r in t['finite_archive_inputs']:add(checked(r))",''' for r in t['finite_archive_inputs']:add(checked(r))
 # The first real report-only body failed during captured input preparation.
 # Preserve it separately; only the second invocation proves report outputs.
 for row in producer['preserved_failed_focused_executions']:
  failed=load(checked(row));assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after']
  add(checked(row))
  for key in ['stdout','stderr','source_snapshot']:add(checked(failed[key]))
  if 'executed_launcher' in failed:add(checked(failed['executed_launcher']['archive']))
  snap=load(checked(failed['source_snapshot']));oldhelper=next(v for v in snap['files'] if v['historical_path'].endswith('/native_cohort/report_cohort.rs'));add(checked(oldhelper['archive']))''')
p=replacement(p,"actual_test_bodies_executed=1,new_test_bodies=0","actual_test_bodies_executed=2,successful_report_only_invocations=1,failed_report_only_invocations=1,preserved_failed_focused_executions=producer['preserved_failed_focused_executions'],original_application=producer['original_application'],raw_deadband_correction=producer['raw_deadband_correction'],independent_correction_peer=producer['independent_correction_peer'],new_test_bodies=0")
p=replacement(p,"actual_test_bodies_executed_by40=1,new_test_bodies=0","actual_test_bodies_executed_by40=2,successful_report_only_invocations=1,failed_report_only_invocations=1,new_test_bodies=0")
ast.parse(p);pub.write_text(p,encoding='utf-8',newline='');pub_delta=save('publisher-forward.diff',''.join(difflib.unified_diff(oldpub.read_text(encoding='utf-8').splitlines(keepends=True),p.splitlines(keepends=True),fromfile='original-publisher40',tofile='corrected-publisher40-02')).encode());pub_inverse=save('publisher-inverse.diff',''.join(difflib.unified_diff(p.splitlines(keepends=True),oldpub.read_text(encoding='utf-8').splitlines(keepends=True),fromfile='corrected-publisher40-02',tofile='original-publisher40')).encode())
t=json.loads((D/'system-report-cohort-publication-prepared-Audit-40/publication-template.json').read_bytes());mp=D/'source-system-report-cohort-held-Audit-40-02/manifest.json';m=json.loads(mp.read_bytes());assert ref(mp)['sha256']=='970cc54e3b740597a62d2ac7207ab6a7e3c718c9609a6cfdad80fec709fb1460'
t.update(status='WAITING_FOR_ROOT_CORRECTED_REPORT_ONLY_EXECUTION_AND_ACCEPTED_REVIEW',publisher_Source=ref(pub),producer=ref(mp),complete_plan=m['complete_final_compiler_Source_plan'],expected_actual_review_path='.runtime/porting/SRC-06/Root-source-system-report-cohort-actual-review-40-02/review.json',launcher_Source=ref(D/'launch-system-report-cohort-Root-40-02.py'))
finite={v['path']:v for v in t['finite_archive_inputs']}
def add(v):
 x=ref(checked(v));finite[x['path']]=x
for v in [ref(mp),m['complete_final_compiler_Source_plan'],m['original_producer'],m['original_application'],m['raw_deadband_correction'],m['independent_correction_peer'],m['author_Source'],ref(Path(__file__)),ref(check),ref(pub),ref(D/'apply-system-report-cohort-Root-40-02.py'),ref(D/'launch-system-report-cohort-Root-40-02.py'),ref(oldpub),checker_delta,pub_delta,pub_inverse]:add(v)
correction=json.loads(checked(m['raw_deadband_correction']).read_bytes());add(correction['author_Source']);add(correction['actual_Source_initialization_context'])
for f in m['files']:
 for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(f[key])
 add(f['Source_only_parse']['stderr'])
for f in correction['files']:
 for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(f[key])
for row in correction['Native_authorities']:
 add(row['whole'])
 for e in row['extents']:add(e['source'])
t['finite_archive_inputs']=list(finite.values());t['summary_template'].update(actual_focused_invocations=2,successful_report_only_invocations=1,failed_report_only_invocations=1,new_test_bodies=0,correction='Only observed DeadBand array allocation/extent was missing in the first test-entry loader. Native2390 dimension(false) then actual incoming0/1 restored on same existing owner; formulas/assertions/fixture unchanged.')
t['doc_appends']['cards/SRC-06.md']+=' 관측 입력 배열 복원 누락으로 실패한 첫 실행과 수정 후 성공 실행을 함께 보존합니다.'
print(json.dumps({'checker':ref(check),'publisher':ref(pub),'template':dump('publication-template.json',t),'finite_inputs':len(finite),'status':t['status']}))

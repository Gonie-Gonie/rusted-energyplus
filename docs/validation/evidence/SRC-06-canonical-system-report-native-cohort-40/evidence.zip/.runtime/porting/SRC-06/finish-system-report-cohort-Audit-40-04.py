"""Strict Source fixture projection from executed genuine Native full functions."""
from pathlib import Path
from collections import Counter
import ast,difflib,hashlib,json,math,re,struct,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OLD=D/'source-system-report-cohort-draft-Audit-40-03';O=D/'source-system-report-cohort-draft-Audit-40-04'
assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];assert ref(p)['sha256']==x['sha256'] and ref(p)['bytes']==x['bytes'];return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,x):return save(n,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def replace(s,a,b):assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
def fixture(p):
 m=re.search(r'r(#+)"(.*)"\1;',p.read_text(encoding='utf-8'),re.S);assert m;return json.loads(m[2])
def strip(v):
 if isinstance(v,dict):return {k:strip(x) for k,x in v.items() if k not in ('address','owner_address','manager_address','state_address')}
 if isinstance(v,list):return [strip(x) for x in v]
 return v
raw_scalars=0
def normalize(v):
 global raw_scalars
 if isinstance(v,dict):
  if set(v)=={'value_bits'}:
   h=v['value_bits'];assert re.fullmatch('[0-9a-f]{16}',h) and math.isfinite(struct.unpack('>d',bytes.fromhex(h))[0]);raw_scalars+=1;return h
  return {k:normalize(x) for k,x in v.items()}
 if isinstance(v,list):return [normalize(x) for x in v]
 assert not isinstance(v,float);return v
def real(v):
 h=v['value_bits'] if isinstance(v,dict) else v;assert re.fullmatch('[0-9a-f]{16}',h);return struct.unpack('>d',bytes.fromhex(h))[0]
def override(v,pointer,value):
 assert pointer.startswith('/state/');tokens=[t.replace('~1','/').replace('~0','~') for t in pointer.split('/')[1:]];at=v
 for token in tokens[:-1]:at=at[int(token)] if isinstance(at,list) else at[token]
 key=int(tokens[-1]) if isinstance(at,list) else tokens[-1];assert not isinstance(at,dict) or key in at;at[key]=value
oldp=OLD/'draft.json';assert ref(oldp)['sha256']=='5773c8e67dd6ae4542774ef6ed60d3c3140e6d980588936303fbaa248167d6ee';old=json.loads(oldp.read_bytes())
rp=D/'system-report-native-unit-run-Root-40/receipt.json';assert ref(rp)['sha256']=='635f9c1037e5073a9e415b707518342d36847d2deed44469a3ae717a60d723ea';run=json.loads(rp.read_bytes())
assert run['accepted'] and not run['findings'] and run['exit_code']==0 and run['launch_error'] is None and run['Native_bytes_match_before_and_after'] and run['actual_three_GNU_DLL_binding_proved']
up=auth(run['full_unit_output']);assert ref(up)['sha256']=='79476768b5c24f47b2ef8a5a39c87464567309189cbc83766e2dc55ecf673848';unit=json.loads(up.read_bytes())
assert unit['schema']=='src06-system-report-full-Native-unit.v1' and unit['accepted'] and not unit['findings'] and unit['all_actual_base_exit_bits_asserted_before_variants']
assert unit['actual_engine_base_counts']==[153,153] and unit['named_variant_count']==165
capture=json.loads(auth(run['original_engine_raw']).read_bytes());events=capture['events'];assert len(events)==612
entries={(e['method'],e['invocation_ordinal']):e for e in events if e['phase']=='entry'};exits={(e['method'],e['invocation_ordinal']):e for e in events if e['phase']=='normal_exit'};assert len(entries)==len(exits)==306
allowed_suffixes={'/value/MixedAirTemp','/value/MixedAirHumRat','/value/OutdoorAirMassFlowRate','/supply_node/value/MassFlowRate'}
allowed_other={'/state/zones/0/demand/TotalOutputRequired','/state/zones/0/DeadBandOrSetback/value','/state/zones/0/predefined/value/isOccupied','/state/zones/0/predefined/value/AFNVentVolStdDen','/state/zones/0/zone/Volume',*[f'/state/zones/0/ZnAirRpt/{n}' for n in ['InfilVolumeCurDensity','InfilVolumeStdDensity','VentilVolumeCurDensity','VentilVolumeStdDensity']]}
unit_prefix='/state/zones/0/equipment_list/value/equipment/0/PurchasedAir'
bases=set();variants=[];names=set();counts=Counter();nonzero=Counter();conditions=Counter();ordinal=0;method_ordinals=Counter()
for case in unit['cases']:
 origin=case['origin'];entry=case['entry'];exit_=case['expected_exit'];method=entry['method'];method_ordinals[method]+=1
 assert method in ['ReportSystemEnergyUse','ReportVentilationLoads'] and exit_['method']==method and entry['phase']=='entry' and exit_['phase']=='normal_exit'
 assert entry['invocation_ordinal']==exit_['invocation_ordinal']==method_ordinals[method] and entry['event_ordinal']==ordinal+1 and exit_['event_ordinal']==ordinal+2;ordinal+=2
 if origin['kind']=='actual_engine_entry_replay':
  assert not variants and not case['input_overrides'] and case['actual_captured_exit_bit_asserted'];key=(origin['method'],origin['actual_invocation']);assert key in entries and key not in bases;bases.add(key)
  for field in ['state','clock']:assert strip(entry[field])==strip(entries[key][field]) and strip(exit_[field])==strip(exits[key][field])
 else:
  assert origin['kind']=='explicit_Native_full_function_unit_input' and not case['actual_captured_exit_bit_asserted'] and method=='ReportVentilationLoads'
  name=origin['name'];assert name not in names;names.add(name);key=(origin['base_actual_method'],origin['base_actual_invocation']);assert key in entries
  restored=json.loads(json.dumps(entries[key]))
  for p,v in case['input_overrides'].items():
   assert p in allowed_other or (p.startswith(unit_prefix) and p[len(unit_prefix):] in allowed_suffixes),(name,p)
   override(restored,p,v)
  assert strip(entry['state'])==strip(restored['state']) and strip(entry['clock'])==strip(restored['clock'])
  z=exit_['state']['zones'][0];report=z['report']['value'];pre=z['predefined']['value']
  for k,v in report.items():
   if k!='address' and real(v)!=0:nonzero[k]+=1
  for k,v in [('occupied',pre['isOccupied']),('unoccupied',not pre['isOccupied']),('OA_mass_positive',real(report['OAMassFlow'])>0),('std_density_volume_positive',real(report['OAVolStdRho'])>0),('current_density_volume_positive',real(report['OAVolCrntRho'])>0),('mechanical_ACH_positive',real(report['MechACH'])>0),('minima_actual_bits_changed',any(entry['state']['zones'][0]['predefined']['value'][n]!=pre[n] for n in ['MechVentVolMin','InfilVolMin','SimpVentVolMin']))]:conditions[k]+=v
  variants.append({'origin':{'kind':'native-unit-variant','name':name,'Native_origin':origin,'input_overrides':normalize(case['input_overrides']),'fresh_owner_lifetime':{'method':method,'invocation':entry['invocation_ordinal']}},'method':method,'entry':normalize(entry),'expected_exit':normalize(exit_)})
assert bases==set(entries) and len(variants)==165 and len(unit['cases'])==471
coverage=run['admission_and_nonzero_coverage'];assert coverage['all_original_actual_engine_base_exits_independently_bit_asserted'] and coverage['no_expected_formula_property_or_load_reconstruction']
assert dict(conditions)=={k:v for k,v in coverage['conditions'].items() if k!='explicit_variants'}
assert all(nonzero[k]==v>0 for k,v in coverage['classification8_nonzero_counts'].items())
assert len(unit['near_threshold_input_searches'])==2
for x in unit['near_threshold_input_searches']:
 assert int(x['nonzero_classification_mass_bits']['value_bits'],16)==int(x['zero_classification_mass_bits']['value_bits'],16)+1 and x['full_function_probe_count']==66
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];changes=[];corrections=[]
for i,row in enumerate(old['files'],1):
 name=row['canonical_path'];before=auth(row['before']).read_bytes();previous=auth(row['proposed']).read_bytes();proposed=previous
 if name.endswith('/fixtures/native_system_report_b.rs'):
  f=fixture(auth(row['proposed']));assert len(f['cases'])==306 and f['engine_cases']==306 and f['native_unit_variants']==0
  old_engine=f['cases'];engine_methods=Counter()
  for c in old_engine:
   k=(c['method'],c['entry']['invocation_ordinal']);assert c['origin']['kind']=='engine'
   for field in ['state','clock']:assert c['entry'][field]==normalize(entries[k][field]) and c['expected_exit'][field]==normalize(exits[k][field])
   engine_methods[c['method']]+=1
  assert engine_methods=={'ReportSystemEnergyUse':153,'ReportVentilationLoads':153}
  f['cases']=old_engine+variants;f['native_unit_variants']=165;f['counts']={'ReportSystemEnergyUse':153,'ReportVentilationLoads':318}
  f['provenance']['Native_unit_variant_status']='EXECUTED genuine original full-Native report functions:306 actual base exits fully asserted before165 explicitly named/probe input variants. Source numerical execution remains pending.'
  f['provenance']['Native_full_function_unit']={'actual_run':ref(rp),'full_output':ref(up),'actual_build':run['actual_build'],'independent_Source_peer':run['independent_Source_peer'],'baseline_projection':'All306 original Engine entry/exit cases retained once, not replaced or duplicated by restored Native base replays. Only165 explicit Native unit variants appended.','normalization':'Only exact singleton value_bits objects become existing16hexstrings; no numeric transformations, formula/property/load reconstruction or fabricated expected answers.'}
  f['coverage']['genuine_Native_unit_nonzero_coverage']=coverage
  f['coverage']['positive_primary_DSOA_distribution_claimed']=False
  f['coverage']['TargetVoz_TimeBelow_TimeAt_nonzero_claimed']=False
  f['coverage']['source_case_counts']={'engine':306,'explicit_Native_unit_inputs':165,'total':471}
  assert f['cases'][:306]==old_engine
  proposed=('// Test-only genuine Native engine and full-function unit entry/exit results. No production reads.\nconst NATIVE_SYSTEM_REPORT_COHORT_JSON: &str = r###"'+json.dumps(f,ensure_ascii=False,separators=(',',':'))+'"###;\n').encode()
 elif name.endswith('/native_cohort/report_cohort.rs'):
  s=previous.decode()
  s=replace(s,'let mut energy=0;let mut vent=0;let mut variants=0;','let mut energy=0;let mut vent=0;let mut variants=0;let mut thermal_nonzero=[false;8];')
  s=replace(s,'                    for (v,name) in values.into_iter().zip(ZONE_FIELDS){assert_real(v,member(expected,name)?,&context,name)?;}','''                    for (i,(v,name)) in values.into_iter().zip(ZONE_FIELDS).enumerate(){
                        assert_real(v,member(expected,name)?,&context,name)?;
                        if kind=="native-unit-variant" && i<8 && v!=0.0 {thermal_nonzero[i]=true;}
                    }''')
  s=replace(s,'    Ok((energy,vent,variants))','    assert!(thermal_nonzero.into_iter().all(|v|v),"all eight actual thermal classifications need nonzero Native-paired Source output");\n    Ok((energy,vent,variants))')
  proposed=s.encode()
 if proposed!=previous:
  changes.append(name);delta=''.join(difflib.unified_diff(previous.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='scaffold03/'+name,tofile='finaldraft04/'+name));assert ns['diff_apply'](previous,delta)==proposed
  corrections.append({'canonical_path':name,'previous':row['proposed'],'proposed':save('proposed/'+name,proposed),'literal_delta':save(f'corrections/{i:02}.diff',delta.encode())})
 forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name));inverse=''.join(difflib.unified_diff(proposed.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 assert ns['diff_apply'](before,forward)==proposed and ns['diff_apply'](proposed,inverse)==before
 whole=save('proposed/'+name,proposed);p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',whole['path']],capture_output=True);assert p.returncode==0,(name,p.stderr)
 files.append({'canonical_path':name,'before_absent':row['before_absent'],'before':save('before/'+name,before),'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}.forward.diff',forward.encode()),'inverse_diff':save(f'diffs/{i:02}.inverse.diff',inverse.encode()),'literal_forward_inverse_exact':True,'Source_only_parse':{'exit_code':0,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':save(f'parse/{i:02}.stderr',p.stderr)}})
 assert proposed.count(b'#[test]')==before.count(b'#[test]')
assert len(changes)==2 and raw_scalars>0
projection=dump('Native-unit-projection-proof.json',{'actual_Native_run':ref(rp),'full_Native_output':ref(up),'all306_baseline_state_clock_bits_independently_checked':True,'all165_entry_states_exact_actual_base_plus_named_INPUT_overrides':True,'removed_for_cross_Native_replay_comparison_only':['address','owner_address','manager_address','state_address'],'Source_fixture_engine306_whole_observed_entry_exit_values_exact':True,'Source_fixture_variants165_whole_unit_entry_exit_values_exact':True,'duplicate_Native_base_replays_added_to_Source_fixture':0,'only_singleton_value_bits_to_existing_string_normalization':True,'no_binary64_math_for_fixture_values':True,'allowed_input_override_fields':sorted(allowed_other|{unit_prefix+s for s in allowed_suffixes}),'nonzero_thermal8':coverage['classification8_nonzero_counts'],'nonzero_coverage':coverage,'Source_PASS_claimed':False})
out=dict(old);out.update({'schema':'src06-system-report-cohort40-complete-Native-paired-draft04.v1','author_Source':ref(Path(__file__)),'previous_scaffold':ref(oldp),'files':files,'final_data_successor':corrections,'actual_Native_unit_run':ref(rp),'actual_Native_unit_full_output':ref(up),'strict_fixture_projection_proof':projection,'engine_cases':306,'Native_unit_input_variants':165,'total_report_cases':471,'report_method_counts':{'ReportSystemEnergyUse':153,'ReportVentilationLoads':318},'source_thermal8_nonzero_coverage_asserted':True,'literal_applications':14,'fresh_syntax_parses':7,'existing_cohort_body_extended':1,'new_test_bodies':0,'status':'FROZEN complete genuine Native-paired Source40 draft04 for full independent Source/fixture/privacy/API peer. Final committed parent/compiler plan join and Root focused execution pending. NO Cargo/main/test/Native execution by Source author; no Source scientific PASS yet.'})
print(json.dumps({'draft':dump('draft.json',out),'fixture':next(x['proposed'] for x in files if x['canonical_path'].endswith('/fixtures/native_system_report_b.rs')),'projection_proof':projection}))

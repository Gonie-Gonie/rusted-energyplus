"""ROOT ONLY: correct one known test-input block; leave the other six files alone."""
from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-system-report-cohort-application-40-02'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert len(sys.argv)==2 and not O.exists()
mr=ref(D/'source-system-report-cohort-held-Audit-40-02/manifest.json');assert mr['sha256']==sys.argv[1]=='970cc54e3b740597a62d2ac7207ab6a7e3c718c9609a6cfdad80fec709fb1460';m=json.loads(checked(mr))
original=json.loads(checked(m['original_producer']));oldapp=json.loads(checked(m['original_application']));assert oldapp['accepted'] and oldapp['producer']==m['original_producer']
pr=m['independent_full_semantic_peer'];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft']
cp=m['independent_correction_peer'];cpeer=json.loads(checked(cp));assert cpeer['accepted'] and not cpeer['findings'] and cpeer['reviewed_draft']==m['raw_deadband_correction']
fix=json.loads(checked(m['raw_deadband_correction']));assert len(fix['files'])==1 and fix['production_formula_expected_fixture_assertion_changes']==0
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip()==m['base_HEAD']=='e47c117f313281428d6c928c4007e580b557a4fa'
old_selected={f['canonical_path']:f for f in original['files']};selected={f['canonical_path']:f for f in m['files']};assert len(old_selected)==len(selected)==7 and set(old_selected)==set(selected)
assert set(git('diff','--name-only').decode().splitlines())=={n for n,f in old_selected.items() if not f['before_absent']} and not git('diff','--cached','--name-only').strip()
assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={n for n,f in old_selected.items() if f['before_absent']}
failed_refs=m['preserved_failed_focused_executions'];assert len(failed_refs)==1;failed=json.loads(checked(failed_refs[0]));assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after'] and b'"same DeadBand"' in checked(failed['stderr'])
beforeplan=json.loads(checked(m['current_prior_complete_compiler_Source_plan']));before={v['path']:v for v in beforeplan['entries']};archives={f['historical_path']:f for f in json.loads(checked(m['current_prior_WIP_snapshot']))['files']};assert len(before)==4510 and set(before)==set(archives)
inventory={p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert inventory==set(before)
for n,v in before.items():
 b=checked(v['source']);assert b==(R/n).read_bytes()==checked(archives[n]['archive']) and len(b)==v['final_bytes']==archives[n]['size_bytes'] and hashlib.sha256(b).hexdigest()==v['final_sha256'],n
tree=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal>','exec'))
f=fix['files'][0];name=f['canonical_path'];a=checked(f['before']);b=checked(f['proposed']);assert m['actual_changed_current_files']==[name] and a==(R/name).read_bytes()==checked(before[name]['source']) and (R/name).stat().st_nlink==1
assert apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and checked(f['literal_inverse'])==a and f['Source_only_parse']['exit_code']==0
assert selected[name]['proposed']['sha256']==f['proposed']['sha256'] and b==checked(selected[name]['proposed'])==checked(cpeer['files'][0]['proposed'])
for n,s in selected.items():
 if n!=name:assert checked(s['proposed'])==checked(old_selected[n]['proposed'])==(R/n).read_bytes()
 assert checked(s['before'])==checked(old_selected[n]['before']) and s['before_absent']==old_selected[n]['before_absent']
finalplan=json.loads(checked(m['complete_final_compiler_Source_plan']));after={v['path']:v for v in finalplan['entries']};assert len(after)==4510 and sum(n.endswith('.rs') for n in after)==4497 and set(after)==set(before)
changed=[n for n,v in after.items() if (v['final_sha256'],v['final_bytes'])!=(before[n]['final_sha256'],before[n]['final_bytes'])];assert changed==[name]
for n,v in after.items():
 data=checked(v['source']);assert hashlib.sha256(data).hexdigest()==v['final_sha256'] and len(data)==v['final_bytes'] and data==(b if n==name else (R/n).read_bytes()),n
checked(m['old_air_fixture_whole_unchanged']);assert a.count(b'#[test]')==b.count(b'#[test]')==0
O.mkdir();(R/name).write_bytes(b)
for n,v in after.items():assert (R/n).read_bytes()==checked(v['source']),n
result={'schema':'src06-system-report-cohort-narrow-correction-application40-02.v1','accepted':True,'findings':[],'base_HEAD':head,'producer':mr,'original_producer':m['original_producer'],'original_application':m['original_application'],'independent_peer':pr,'independent_correction_peer':cp,'raw_deadband_correction':m['raw_deadband_correction'],'complete_compiler_plan':m['complete_final_compiler_Source_plan'],'selected':selected,'selected_Source_files':7,'existing_Source_files':5,'new_Source_files':2,'actual_rewritten_files':[name],'actual_rewrites':1,'literal_correction_applications':2,'all4510_prior_WIP_archive_live_plan_equal':True,'all4510_final_plan_live_equal':True,'other6_whole_exact_not_rewritten':True,'old_Air_fixture_and_all_expected_values_unchanged':True,'production_numerical_bodies_unchanged_after_cfg_exclusion':True,'preserved_failed_focused_executions':failed_refs,'new_test_bodies':0,'existing_cohort_body_extended':1,'command':m['command'],'Cargo_tests_or_Native_executed':False,'author_Source':ref(Path(__file__)),'literal_helper_Source':ref(D/'review-meter-final-predefined-Root-01.py')}
p=O/'receipt.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

"""Narrow immutable one-file correction over the actual known seven-file WIP."""
from pathlib import Path
import argparse,ast,copy,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-system-report-cohort-held-Audit-40-02'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return p
def load(n,h):
 p=R/n;assert ref(p)['sha256']==h;return p,json.loads(p.read_bytes())
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,x):return save(n,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
a=argparse.ArgumentParser();a.add_argument('--peer',required=True);a.add_argument('--peer-sha',required=True);a=a.parse_args();assert not O.exists()
mp,m=load('.runtime/porting/SRC-06/source-system-report-cohort-held-Audit-40/manifest.json','1a14003b55fccf5381cc0ded3e2fa23a55fd8a8eb6f809828803202d7955a220')
cp,c=load('.runtime/porting/SRC-06/source-system-report-cohort-deadband-fix-held-Audit-40-02/manifest.json','a6a67f90046295bb66a02bb8e7c8124f3e519f58c9d08a9975607fa005c68237')
pp,p=load(a.peer,a.peer_sha);assert p['accepted'] and not p['findings'] and p['reviewed_draft']==ref(cp)
ap,app=load('.runtime/porting/SRC-06/Root-system-report-cohort-application-40/receipt.json','e02ddc5c41f7a16367e13042f7877e2d7ff82cabbf69034cce27e59743a81abf');assert app['accepted'] and app['producer']==ref(mp)
failed=json.loads(checked(c['failed_actual_focused_test']).read_bytes());assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after'] and b'"same DeadBand"' in checked(failed['stderr']).read_bytes()
planp=checked(m['complete_final_compiler_Source_plan']);plan=json.loads(planp.read_bytes());rows={v['path']:copy.deepcopy(v) for v in plan['entries']};archive={v['historical_path']:v for v in json.loads(checked(c['actual_failed_snapshot']).read_bytes())['files']};assert len(rows)==4510 and set(rows)==set(archive)
for n,v in rows.items():assert (v['final_sha256'],v['final_bytes'])==(archive[n]['archive']['sha256'],archive[n]['size_bytes'])
fix=c['files'][0];name=fix['canonical_path'];assert checked(fix['before']).read_bytes()==(R/name).read_bytes()==checked(rows[name]['source']).read_bytes()
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];changed=[]
for i,f in enumerate(m['files'],1):
 out=copy.deepcopy(f);n=f['canonical_path'];current=checked(f['proposed']).read_bytes();assert current==(R/n).read_bytes()
 if n==name:
  historical=checked(f['before']).read_bytes();after=checked(fix['proposed']).read_bytes();fwd=''.join(difflib.unified_diff(historical.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='before/'+n,tofile='proposed/'+n));inv=''.join(difflib.unified_diff(after.decode().splitlines(keepends=True),historical.decode().splitlines(keepends=True),fromfile='proposed/'+n,tofile='before/'+n));assert ns['diff_apply'](historical,fwd)==after and ns['diff_apply'](after,inv)==historical
  out.update(proposed=save('proposed/'+n,after),reviewed_original_proposal=f['proposed'],reviewed_correction_proposal=fix['proposed'],forward_diff=save(f'diffs/{i:02}.forward.diff',fwd.encode()),inverse_diff=save(f'diffs/{i:02}.inverse.diff',inv.encode()),Source_only_parse=fix['Source_only_parse']);out.pop('reviewed_draft_whole',None);changed.append(n)
  rows[n]={'path':n,'final_sha256':out['proposed']['sha256'],'final_bytes':out['proposed']['bytes'],'source':out['proposed'],'origin':'Whole independently reviewed captured DeadBand allocation correction only'}
 files.append(out)
assert len(changed)==1 and len(files)==7 and sum(n.endswith('.rs') for n in rows)==4497
finalplan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-system-report-cohort-complete-compiler-plan40-02.v1','base_HEAD':m['base_HEAD'],'prior_failed_focused_snapshot':c['actual_failed_snapshot'],'prior_complete_compiler_Source_plan':ref(planp),'compiler_inputs':4510,'Rust_sources':4497,'entries':[rows[n] for n in sorted(rows)],'exactly_one_row_changed':changed,'other4509_metadata_and_Source_refs_whole_equal':True,'Root_full_before_after_readback_required':True})
result=copy.deepcopy(m);result.update(schema='src06-held-system-report-cohort40-02.v1',status='HELD actual-failure correction, original full peer plus narrow correction peer accepted; Root one-file application and focused report-only rerun pending',original_producer=ref(mp),original_application=ref(ap),current_prior_complete_compiler_Source_plan=ref(planp),current_prior_WIP_snapshot=c['actual_failed_snapshot'],current_worktree_clean_claim=False,original_full_Source_fixture_peer=m['independent_full_semantic_peer'],raw_deadband_correction=ref(cp),independent_correction_peer=ref(pp),preserved_failed_focused_executions=[c['failed_actual_focused_test']],preserved_failed_execution_count=1,files=files,complete_final_compiler_Source_plan=finalplan,actual_changed_current_files=changed,actual_rewrites=1,original7_Root_writes=7,existing_cohort_body_extended=1,actual_expected_successful_executions=1,expected_total_focused_executions_after_success=2,author_Source=ref(Path(__file__)))
result.pop('whole4497_Rust_API_census',None);result['original_whole4497_Rust_API_census_unchanged_API_qualified']=m['whole4497_Rust_API_census'];result['narrow_API_signature_and_call_set_changes']=0
result['validation_policy']='Preserve first actual focused invocation1 (same DeadBand test-input allocation failure before report math); apply only the one corrected cfg-test helper and rerun the same existing process-main target --report-only once. No expectation/tolerance/fixture/production/Air/CLI/Native change or rerun. After success, report1 failure+1 success=2 actual focused invocations.'
print(json.dumps({'producer':dump('manifest.json',result),'plan':finalplan,'actual_rewrites':1,'compiler_inputs':4510,'Rust_sources':4497}))

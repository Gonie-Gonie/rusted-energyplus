"""Metadata only: one TU/full original Native functions, exact frozen direct argv."""
from pathlib import Path
import ast, hashlib, json, re, subprocess
R=Path(__file__).resolve().parents[3]; D=R/'.runtime/porting/SRC-06'
O=D/'system-report-native-unit-draft-Peer-40'; B=R/'.runtime/ep261-gcc13-o0'
U=Path('D:/CodexBuild/rusted-energyplus/SRC-06/system-report-native-unit-Root-40')
PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 p=p.resolve(); b=p.read_bytes(); return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=(R/row['path']).resolve(); v=ref(p); assert v['sha256']==row['sha256'] and v['bytes']==row.get('bytes',v['bytes']); return p
def write(p,x):
 assert not p.exists(); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes((json.dumps(x,indent=2)+'\n').encode()); return ref(p)
def load(p): return json.loads(p.read_bytes())
def norm(p): return str(p).replace('\\','/').casefold()
assert not O.exists()
buildp=D/'system-report-native-build-Root-39/native-build.json'; assert ref(buildp)['sha256']=='fbcc0a26ddc997adea2c29b8c48aaa4d690d06f816eea8bc8fe9bd87c01f534b'
build=load(buildp); assert build['accepted'] and not build['findings']
capturep=D/'system-report-native-capture-Root-39/capture.json'; assert ref(capturep)['sha256']=='0737360b8f1759af3a3fd427b18d72f1b884f7222ad56ac8952858c299a67fed'
capture=load(capturep); assert capture['accepted']; checked(capture['full_retained_observation'])
harness=load(checked(build['accepted_harness'])); ledger=load(checked(harness['field_ledger']))
observer=checked(next(row for row in harness['payload'] if Path(row['path']).name=='system_report_observer.cc'))
template=D/'system-report-unit-author-Peer-40/system_report_unit_main.cpp.in'; text=template.read_text(encoding='utf8')
clock=[]
for owner,names in [('g','CalendarYear DayOfSim HourOfDay TimeStep'),('e','Month DayOfMonth'),('h','NumOfSysTimeSteps NumOfSysTimeStepsLastZoneTimeStep')]:
 clock += [f'    {owner}.{n}=c.at("{n}").get<int>();' for n in names.split()]
for owner,names in [('g','CurrentTime TimeStepZone TimeStepZoneSec'),('h','TimeStepSys TimeStepSysSec SysTimeElapsed FracTimeStepZone PreviousTimeStep'),('e','OutBaroPress OutHumRat')]:
 clock += [f'    {owner}.{n}=real(c.at("{n}"));' for n in names.split()]
for owner,names in [('g','WarmupFlag DoingSizing KickOffSimulation BeginSimFlag BeginEnvrnFlag BeginDayFlag BeginTimeStepFlag'),('h','FirstTimeStepSysFlag ShortenTimeStepSys UseZoneTimeStepHistory')]:
 clock += [f'    {owner}.{n}=c.at("{n}").get<bool>();' for n in names.split()]
clock+=['    e.CurEnvirNum=c.at("environment_index").get<int>();','    e.EnvironmentName=c.at("environment_name").get<std::string>();','    g.KindOfSim=static_cast<decltype(g.KindOfSim)>(c.at("KindOfSim").get<int>());']
flags=[]
for owner,names,kind in [('r','AirLoopLoadsReportEnabled VentReportStructureCreated VentLoadsReportEnabled VentEnergyReportEnabled','bool'),('s.dataGlobal->','NumOfZones','int'),('s.dataGlobal->','DoOutputReporting ZoneSizingCalc','bool'),('s.dataHVACGlobal->','NumPrimaryAirSys NumPlantLoops NumCondLoops','int')]:
 prefix=owner if owner.endswith('->') else owner+'.'
 flags += [f'    {prefix}{n}=flags.at("{n}").get<{kind}>();' for n in names.split()]
facility=[f'        r.{n}=real(v.at("facility_report").at("{n}"));' for n in ledger['module_facility7']]
facility += [f'        s.dataOutRptPredefined->{n}=real(v.at("facility_predefined_totals").at("{n}"));' for n in ledger['facility_summary7']]
replace={'CLOCK_ASSIGNMENTS':clock,'FLAG_ASSIGNMENTS':flags,'FACILITY_RESTORE':facility,
 'AIR_REPORT_RESTORE':[f'        air_report.{n}=real(air_values.at("{n}"));' for n in ['InfilVolumeCurDensity','InfilVolumeStdDensity','VentilVolumeCurDensity','VentilVolumeStdDensity']],
 'PREDEFINED_RESTORE':[f'        pre.{n}=real(pre_values.at("{n}"));' for n in ledger['zone_predefined_consumed_and_written'] if n!='isOccupied'],
 'REPORT_RESTORE':[f'        report.{n}=real(report_values.at("{n}"));' for n in ledger['zone_report20']]}
for key,lines in replace.items():
 marker='@@'+key+'@@'; assert text.count(marker)==1; text=text.replace(marker,'\n'.join(lines),1)
assert '@@' not in text
text=text.replace('#include <fstream>','#include <fstream>\n#include <filesystem>')
O.mkdir(); cpp=O/'system_report_unit_main.cpp'; cpp.write_bytes(text.encode())
mainrow=next(row['compile_registration'] for row in build['objects_and_map_LOADs'] if Path(row['compile_registration']['file']).name=='system_report_main.cpp')
assert '"' not in mainrow['command']; oldcompile=mainrow['command'].split(); compileargs=list(oldcompile)
assert norm(compileargs[-1])==norm(mainrow['file']) and compileargs[-2]=='-c'; compileargs[-1]=str(cpp.resolve())
at=compileargs.index('-o'); obj=U/'system_report_unit_main.cpp.obj'; compileargs[at+1]=str(obj)
rawlink=build['actual_only_five_compile_operations_one_link'][-1]
before=' /C "cd . && '; after=' && cd ."'; assert rawlink.count(before)==1 and rawlink.endswith(after)
oldlink=rawlink.split(before,1)[1][:-len(after)].split(); link=list(oldlink)
objectrows=build['objects_and_map_LOADs']; allobjects=[row['compile_registration']['output'] for row in objectrows]
names=['system_report_main.cpp','SystemReports.reporting.cc','system_report_observer.cc']
removed=[]
for filename in names:
 row=next(row for row in objectrows if Path(row['compile_registration']['file']).name==filename)
 oldobject=Path(row['compile_registration']['output']).relative_to(B).as_posix(); idx=next(i for i,v in enumerate(link) if norm(v)==norm(oldobject)); removed.append(link.pop(idx))
link.insert(next(i for i,v in enumerate(link) if v.endswith('EnergyPlusPgm.cc.obj')),str(obj))
exe=U/'system_report_native_unit.exe'; mapfile=U/'system_report_native_unit.map'; implib=U/'libsystem_report_native_unit.dll.a'
for i,value in enumerate(link):
 if value.startswith('-Wl,-Map,'): link[i]='-Wl,-Map,'+mapfile.as_posix()
 if value.startswith('-Wl,--out-implib,'): link[i]='-Wl,--out-implib,'+implib.as_posix()
link[link.index('-o')+1]=str(exe)
assert all(not any(name+'.obj' in v for name in names) for v in link)
retained_objects=[row['object'] for row in objectrows if Path(row['compile_registration']['file']).name in ['EnergyPlusPgm.cc','CommandLineInterface.cc']]
assert len(retained_objects)==2
for row in retained_objects: checked(row)
# Finite Native sources used by actual owner restoration and full called routine.
native=[]
paths=[x['Native_path'] for x in harness['Native_authorities']]+['src/EnergyPlus/Data/EnergyPlusData.cc','src/EnergyPlus/Data/EnergyPlusData.hh','src/EnergyPlus/EPVector.hh']
for rel in dict.fromkeys(paths):
 p=R/'.reference/energyplus-src/26.1.0'/rel; b=p.read_bytes(); assert subprocess.check_output(['git','show',PIN+':'+rel],cwd=R/'.reference/energyplus-src/26.1.0')==b
 native.append({'Native_path':rel,'whole':ref(p),'pinned_Git':PIN,'Git_whole_exact':True})
assert not U.exists()
plan={'schema':'src06-original-core-report-unit-direct-build-plan.v1','status':'PREPARED_NO_BUILD_OR_UNIT_EXECUTED',
 'actual_accepted_build39':ref(buildp),'actual_engine_capture39':ref(capturep),'actual_capture_raw':capture['full_retained_observation'],
 'accepted_observer_included_whole_unchanged':ref(observer),'observer_parent_peer':ref(D/'Outer-system-report-Native-extension-Source-review-39/review.json'),
 'observer_field_ledger':harness['field_ledger'],'Native_authorities':native,
 'main_Source':ref(cpp),'template_Source':ref(template),'author_Source':ref(Path(__file__)),
 'compile_cwd':B.as_posix(),'one_compile_argv':compileargs,'one_link_argv':link,'original_compile_argv':oldcompile,'original_link_argv':oldlink,
 'removed_three_objects':removed,'retained_actual_API_CLI_objects':retained_objects,'retained_ordered_archives':build['explicit_link_archives_after'],
 'actual_providers':build['actual_providers'],'frozen_environment':build['frozen_environment'],'pinned_runtime_DLLs':build['pinned_runtime_DLLs'],
 'live_cache':ref(B/'CMakeCache.txt'),'live_compile_registry':ref(B/'compile_commands.json'),'registry_count':len(load(B/'compile_commands.json')),
 'object':obj.as_posix(),'binary':exe.as_posix(),'map':mapfile.as_posix(),'implib':implib.as_posix(),'fresh_unit_directory':U.as_posix(),
 'original_core_SystemReports_member_MUST_present':True,'derived_SystemReports_and_observer_objects_MUST_absent':True,
 'baseline_closure':'Every actual153 E and153V entry restored; original constructor containers and scalar members only. Entire observed clock/state/allocation extents bit-compared before and after calls, excluding only actual addresses.',
 'unit_input_variants':'Explicit MixedT/W, supply mass/OA, demand including +/-adjacent0.1, occupancy/natural volume/deadband/zero ZoneVolume. No computed load/H/Rho/outputs supplied. All original engine cases asserted first.',
 'near_threshold':'For positive and negative MixedT unit offsets, binary search positive binary64 supply-mass inputs using ONLY fullNative NoLoadHeating/Cooling result!=0 as branch oracle. Retain every probe plus adjacent zero/nonzero input bits and count; no formula copy or expected answer injection.',
 'scientific_scope':'Original actual engine baseline replay plus separate named Native unit INPUT cases; not another wholeengine case or production matrix extension. Positive primary/DSOA/air-distribution intentionally outside this finite unit.',
 'no_configure_registry_or_cache_write':True,'no_Cargo_tests_engine_or_Native_execution_by_preparation':True}
print(json.dumps({'draft':write(O/'draft.json',plan),'main':ref(cpp)}))

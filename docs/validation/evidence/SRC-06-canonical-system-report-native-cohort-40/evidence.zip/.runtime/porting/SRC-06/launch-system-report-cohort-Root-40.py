"""ROOT ONLY: one recorded existing dedicated safe-main report-only invocation."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
assert len(sys.argv)==2
mp=D/'source-system-report-cohort-held-Audit-40/manifest.json';assert hashlib.sha256(mp.read_bytes()).hexdigest()=='1a14003b55fccf5381cc0ded3e2fa23a55fd8a8eb6f809828803202d7955a220';m=json.loads(mp.read_bytes())
ap=D/'Root-system-report-cohort-application-40/receipt.json';assert hashlib.sha256(ap.read_bytes()).hexdigest()==sys.argv[1];a=json.loads(ap.read_bytes());assert a['accepted'] and not a['findings'] and a['producer']['sha256']==hashlib.sha256(mp.read_bytes()).hexdigest()
cmd=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--report-only'];assert cmd==m['command']==a['command']
out=D/'canonical-source-system-report-cohort-Root-40';assert not out.exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',out.relative_to(R).as_posix(),'--',*cmd],cwd=R))

"""Isolated test-only scaffold and exact engine-origin report fixture; no execution."""
from pathlib import Path
import collections,difflib,hashlib,json,re,struct,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-system-report-cohort-draft-Audit-40'
assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];assert ref(p)['sha256']==x['sha256'];return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,x):return save(n,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
cp=D/'system-report-native-capture-Root-39/capture.json';assert ref(cp)['sha256']=='0737360b8f1759af3a3fd427b18d72f1b884f7222ad56ac8952858c299a67fed'
capture=json.loads(cp.read_bytes());assert capture['accepted'] and capture['exit_code']==0 and capture['Native_runtime_bytes_match_before_and_after']
rawp=auth(capture['full_retained_observation']);assert ref(rawp)['sha256']=='5d4659dfc09426bca4411f33cf4efc49e0c73a07253b9edfa8798c6dc996533e'
raw=json.loads(rawp.read_bytes());assert raw['schema']=='src06-system-report-native-observation.v1'
terminal=raw['terminal_summary'];assert terminal['copy_failures']==terminal['methods'][0]['unwinds']==terminal['methods'][1]['unwinds']==0
assert terminal['actual_engine_exit_code']==0 and terminal['actual_engine_entry_returned'] and not terminal['counter_overflow'] and not terminal['stream_failed']
assert len(raw['events'])==terminal['attempted_events']==terminal['retained_events']==612
scalars=0
def normalize(v):
 global scalars
 if isinstance(v,dict):
  if set(v)=={'value_bits'}:
   assert re.fullmatch('[0-9a-f]{16}',v['value_bits']);scalars+=1;return v['value_bits']
  return {k:normalize(x) for k,x in v.items()}
 if isinstance(v,list):return [normalize(x) for x in v]
 assert not isinstance(v,float);return v
cases=[];stack=[];counts=collections.Counter();zones={};positive=0;nonzero=0
for ordinal,event in enumerate(raw['events'],1):
 assert event['event_ordinal']==ordinal and event['parent_method'] is None and event['parent_invocation_ordinal'] is None
 identity=(event['method'],event['invocation_ordinal']);assert identity[0] in ['ReportSystemEnergyUse','ReportVentilationLoads']
 normalized=normalize(event)
 if event['phase']=='entry':
  assert not stack;counts[identity[0]]+=1;assert identity[1]==counts[identity[0]];stack.append((identity,normalized))
 else:
  assert event['phase']=='normal_exit' and stack and stack[-1][0]==identity
  _,entry=stack.pop();cases.append({'origin':{'kind':'engine','method_invocation':identity[1]},'method':identity[0],'entry':entry,'expected_exit':normalized})
  if identity[0]=='ReportVentilationLoads':
   for z in event['state']['zones']:
    index=z['index'];name=z['zone']['Name'];assert index not in zones or zones[index]==name;zones[index]=name
    for e in z['equipment_list']['value']['equipment']:
     unit=e['PurchasedAir'];flow=unit['supply_node']['value']['MassFlowRate']['value_bits']
     positive+=struct.unpack('>d',bytes.fromhex(flow))[0]>0
    nonzero+=any(struct.unpack('>d',bytes.fromhex(v['value_bits']))[0]!=0 for k,v in z['report']['value'].items() if k!='address')
assert not stack and dict(counts)=={'ReportSystemEnergyUse':153,'ReportVentilationLoads':153} and scalars==28458
bndrow=next(x for x in capture['output_inventory'] if x['path'].endswith('/eplusout.bnd'));bndp=auth(bndrow)
nodes=[]
for line in bndp.read_text(encoding='utf-8').splitlines():
 fields=line.strip().split(',')
 if fields[0]=='Node':nodes.append({'index':int(fields[1]),'name':fields[2]})
assert [v['index'] for v in nodes]==list(range(1,len(nodes)+1)) and len(nodes)==3
fixture={'schema':'src06-Native-report-entry-exit-cohort40.v1','provenance':{'engine_capture':ref(cp),'raw_observation':ref(rawp),'actual_Native_BND':ref(bndp),'normalization':'Only exact singleton value_bits objects become their existing16hexstring; all actual events retained, no arithmetic or expected outputs fabricated.','Native_unit_variant_status':'PENDING genuine full-Native-function replay/variants; this initial fixture contains engine-origin cases only.'},'counts':dict(counts),'engine_cases':len(cases),'native_unit_variants':0,'node_ids':nodes,'zone_names':[{'index':i,'name':n} for i,n in sorted(zones.items())],'coverage':{'positive_supply_flow_cases':positive,'nonzero_report_output_cases':nonzero,'raw_binary64_values':scalars},'cases':cases}
assert positive==110 and nonzero==0
F='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/'
fixture_bytes=('// Test-only complete genuine Native report entries/exits. No production reads.\nconst NATIVE_SYSTEM_REPORT_COHORT_JSON: &str = r###"'+json.dumps(fixture,ensure_ascii=False,separators=(',',':'))+'"###;\n').encode()
fixture_ref=save('proposed/'+F+'fixtures/native_system_report_b.rs',fixture_bytes)
field_ledger=json.loads((D/'system-report-native-draft-Peer-39/field-ledger.json').read_bytes())
Z=dict(zip(field_ledger['zone_report20'],['cooling_load_met_by_vent','cooling_load_added_by_vent','overcooling_by_vent','heating_load_met_by_vent','heating_load_added_by_vent','overheating_by_vent','no_load_heating_by_vent','no_load_cooling_by_vent','oa_mass_flow','oa_mass','oa_vol_flow_std_rho','oa_vol_std_rho','oa_vol_flow_crnt_rho','oa_vol_crnt_rho','mech_ach','target_ventilation_flow_voz','time_below_voz_dyn','time_at_voz_dyn','time_above_voz_dyn','time_vent_unocc']))
FAC=dict(zip(field_ledger['module_facility7'],['any_zone_time_below_voz_dyn','all_zones_time_at_voz_dyn','any_zone_time_above_voz_dyn','any_zone_time_vent_unocc','any_zone_time_below_voz_dyn_occ','all_zones_time_at_voz_dyn_occ','any_zone_time_above_voz_dyn_occ']))
SUM=dict(zip(field_ledger['facility_summary7'],['total_any_zone_below_voz_dyn_for_oa','total_all_zones_at_voz_dyn_for_oa','total_any_zone_above_voz_dyn_for_oa','total_any_zone_vent_unocc_for_oa','total_any_zone_below_voz_dyn_occ_for_oa','total_all_zones_at_voz_dyn_occ_for_oa','total_any_zone_above_voz_dyn_occ_for_oa']))
PF={'AFNVentVolStdDen':'afn_vent_vol_std_den','TotTimeOcc':'tot_time_occ','MechVentVolTotalOcc':'mech_vent_vol_total_occ','MechVentVolMin':'mech_vent_vol_min','MechVentVolTotalOccStdDen':'mech_vent_vol_total_occ_std_den','InfilVolTotalOcc':'infil_vol_total_occ','InfilVolMin':'infil_vol_min','InfilVolTotalOccStdDen':'infil_vol_total_occ_std_den','SimpVentVolTotalOcc':'simp_vent_vol_total_occ','SimpVentVolMin':'simp_vent_vol_min','SimpVentVolTotalOccStdDen':'simp_vent_vol_total_occ_std_den','VozTargetTotalOcc':'voz_target_total_occ','VozTargetTimeBelowOcc':'voz_target_time_below_occ','VozTargetTimeAtOcc':'voz_target_time_at_occ','VozTargetTimeAboveOcc':'voz_target_time_above_occ','TotVentTimeNonZeroUnocc':'tot_vent_time_non_zero_unocc','MechVentVolTotalStdDen':'mech_vent_vol_total_std_den','InfilVolTotalStdDen':'infil_vol_total_std_den','SimpVentVolTotalStdDen':'simp_vent_vol_total_std_den','VozTargetTotal':'voz_target_total','VozTargetTimeBelow':'voz_target_time_below','VozTargetTimeAt':'voz_target_time_at','VozTargetTimeAbove':'voz_target_time_above'}
assert set(PF)|{'isOccupied'}==set(field_ledger['zone_predefined_consumed_and_written'])
def mapping(m):return ','.join('"'+n+'"=>'+s for n,s in m.items())
proposals={}
equipment='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'
s=(R/equipment).read_text(encoding='utf-8')
s+=r'''
// Only genuine captured/unit-variant report-entry operands; no production API.
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
impl OrdinaryEquipment {
    pub(crate) fn restore_native_report_config(&mut self, zone:i32, name:&str,
        controlled:bool, inlets:Option<&[i32]>, reporting_indices:Option<(i32,i32,i32)>)
        -> Result<usize, super::selected_heat_balance_input::HeatBalanceInputError> {
        use super::selected_heat_balance_input::HeatBalanceInputError as E;
        let index=zone.checked_sub(1).and_then(|n|usize::try_from(n).ok()).ok_or(E::Unavailable("report cohort Config ordinal"))?;
        let row=self.zone_config.as_mut().and_then(|rows|rows.get_mut(index)).ok_or(E::Unavailable("report cohort getter-created Config"))?;
        if row.zone_name!=name {return Err(E::Unavailable("report cohort actual Zone identity"));}
        if controlled { match (row.inlet_node_air_loop_numbers.as_mut(),inlets) {
            (Some(actual),Some(captured)) if actual.len()==captured.len() && row.inlet_nodes==captured.len()=>actual.copy_from_slice(captured),
            (None,None) if row.inlet_nodes==0=>{},
            _=>return Err(E::Unavailable("report cohort actual inlet allocation/extent")),
        }}
        row.is_controlled=controlled;
        if let Some((list,dsoa,distribution))=reporting_indices {
            let at=list.checked_sub(1).and_then(|n|usize::try_from(n).ok()).ok_or(E::Unavailable("report cohort captured List ordinal"))?;
            let actual=self.equipment_lists.as_ref().and_then(|rows|rows.get(at)).ok_or(E::Unavailable("report cohort getter-created List"))?;
            if actual.name!=row.equipment_list_name {return Err(E::Unavailable("report cohort actual Config/List name association"));}
            row.equipment_list_index=usize::try_from(list).map_err(|_|E::Unavailable("report cohort List integer"))?;
            row.zone_design_specification_outdoor_air_index=dsoa;row.zone_air_distribution_index=distribution;
        }
        Ok(std::ptr::from_ref(row) as usize)
    }
    pub(crate) fn restore_native_report_equipment_index(&mut self,list:i32,pointer:i32,kind:i32,index:i32)
        -> Result<usize,super::selected_heat_balance_input::HeatBalanceInputError> {
        use super::selected_heat_balance_input::HeatBalanceInputError as E;
        let at=|n:i32|n.checked_sub(1).and_then(|n|usize::try_from(n).ok()).ok_or(E::Unavailable("report cohort equipment ordinal"));
        let row=self.equipment_lists.as_mut().and_then(|rows|rows.get_mut(at(list).ok()?)).ok_or(E::Unavailable("report cohort genuine equipment List"))?;
        let i=at(pointer)?;
        if row.equipment_types.as_ref().and_then(|rows|rows.get(i))!=Some(&kind) {return Err(E::Unavailable("report cohort getter-created equipment type"));}
        *row.equipment_indices.as_mut().and_then(|rows|rows.get_mut(i)).ok_or(E::Unavailable("report cohort actual EquipIndex cell"))?=index;
        Ok(std::ptr::from_ref(row) as usize)
    }
    pub(crate) fn restore_native_report_node(&mut self,ordinal:i32,name:&str,
        temperature:Option<f64>,humidity_ratio:Option<f64>,mass_flow_rate:Option<f64>)
        -> Result<usize,super::selected_heat_balance_input::HeatBalanceInputError> {
        use super::selected_heat_balance_input::HeatBalanceInputError as E;
        let n=usize::try_from(ordinal).map_err(|_|E::Unavailable("report cohort Node ordinal"))?;
        let at=n.checked_sub(1).ok_or(E::Unavailable("report cohort positive Node"))?;
        if self.nodes.node_ids.as_ref().and_then(|rows|rows.get(n)).map(String::as_str)!=Some(name) {return Err(E::Unavailable("report cohort NativeBND/genuine getter NodeID"));}
        let row=self.nodes.physical.as_mut().and_then(|rows|rows.get_mut(at)).ok_or(E::Unavailable("report cohort physical Node"))?;
        if let Some(v)=temperature {row.temperature=v;}
        if let Some(v)=humidity_ratio {row.humidity_ratio=v;}
        if let Some(v)=mass_flow_rate {row.mass_flow_rate=v;}
        Ok(std::ptr::from_ref(row) as usize)
    }
}
'''
proposals[equipment]=s
hub='crates/ep_runtime/src/heat_balance/ordinary_system_reports.rs';s=(R/hub).read_text(encoding='utf-8')
s=s.replace('//! Genuine SystemReports zero-primary/uncontrolled route on its sole Source owner.','//! Genuine controlled-zone SystemReports on its sole live Source owner.',1)
s+='''
// Captured entry restoration on the same report allocation, test target only.
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
impl SourceSystemReports {
    pub(crate) fn prepare_native_report_cohort_rows(&mut self,count:usize) -> Result<(),Error> {
        if let Some(rows)=&self.zone_vent_rep_vars {
            if rows.len()!=count {return Err(Error::Unavailable("report cohort stable ZoneVent allocation"));}
        } else {self.zone_vent_rep_vars=Some(vec![state::SourceZoneVentReportVariables::default();count]);}
        Ok(())
    }
    pub(crate) fn restore_native_report_cohort_row(&mut self,number:i32,values:[f64;20]) -> Result<usize,Error> {
        let row=self.zone_vent_rep_vars.as_mut().and_then(|rows|rows.get_mut(at(number).ok()?)).ok_or(Error::Unavailable("report cohort real ZoneVent row"))?;
'''+''.join('        row.'+f+'=values['+str(i)+'];\n' for i,f in enumerate(Z.values()))+'''        Ok(std::ptr::from_ref(row) as usize)
    }
    pub(crate) fn native_report_cohort_row(&self,number:i32) -> Result<[f64;20],Error> {
        let row=self.zone_vent_rep_vars.as_ref().and_then(|rows|rows.get(at(number).ok()?)).ok_or(Error::Unavailable("report cohort ZoneVent read"))?;
        Ok(['''+','.join('row.'+f for f in Z.values())+'''])
    }
}
'''
proposals[hub]=s
state='crates/ep_runtime/src/heat_balance/ordinary_system_reports/state.rs';s=(R/state).read_text(encoding='utf-8');s=s.replace('//! Complete actual SystemReports module constructors; positive report rows remain explicit boundaries.','//! Complete actual SystemReports constructors; positive primary rows remain explicit boundaries.',1);proposals[state]=s
child=r'''//! Full genuine Native report entry/exit cohort; no report-formula mirrors.
//! Engine cases and later explicit Native-unit input variants retain separate origins.
use super::*;
use crate::heat_balance::ordinary_system_reports::SourceSystemReports;
use crate::heat_balance::ordinary_thermal_comfort::SourceComfortPredefinedSummary;
use crate::heat_balance::selected_heat_balance_input::zone::ZonePredefined;
use crate::heat_balance::ordinary_equipment::source_purchased_air::owners::SourceZonePurchasedAir;
include!("../fixtures/native_system_report_b.rs");
const ZONE_FIELDS:[&str;20]=@@ZONE_NAMES@@;
fn index(n:i32)->Result<usize>{Ok(usize::try_from(n.checked_sub(1).ok_or_else(||invalid("report positive ordinal"))?)?)}
fn row_value(v:&Value)->Result<&Value>{let x=member(v,"value")?;if x.is_null(){return Err(invalid("missing captured actual row").into());}Ok(x)}
fn allocated(v:&Value)->Result<usize>{assert!(boolean(member(v,"allocated")?)?);count(member(v,"size")?)}
fn bind(ids:&mut BTreeMap<(String,usize),usize>,kind:&str,native:&Value,source:usize)->Result {
    let native=count(member(native,"address")?)?;assert!(native>0 && source>0);
    let key=(kind.to_owned(),native);
    if let Some(old)=ids.get(&key){assert_eq!(*old,source,"same {kind} physical row across invocations");}
    else {assert!(!ids.iter().any(|((k,n),s)|k==kind && *n!=native && *s==source),"distinct actual {kind} rows stay distinct");ids.insert(key,source);}
    Ok(())
}
fn identity_name(fixture:&Value,key:&str,ordinal:i32)->Result<String>{
    let rows=array(member(fixture,key)?)?;
    let row=rows.iter().find(|v|member(v,"index").and_then(integer).is_ok_and(|n|n==ordinal)).ok_or_else(||invalid("captured identity ordinal"))?;
    Ok(text(member(row,"name")?)?.to_owned())
}
fn seed_config(equipment:&mut OrdinaryEquipment,fixture:&Value,zone:&Value,vent:bool,ids:&mut BTreeMap<(String,usize),usize>)->Result {
    let number=integer(member(zone,"index")?)?;let outer=member(zone,"config")?;allocated(outer)?;
    assert_eq!(integer(member(outer,"index")?)?,number);let raw=row_value(outer)?;
    let controlled=boolean(member(raw,"IsControlled")?)?;
    let mut inlet_values=None;
    if controlled {
        let n=count(member(raw,"NumInletNodes")?)?;let shape=member(raw,"InletNodeAirLoopNum")?;
        if boolean(member(shape,"allocated")?)? {
            assert_eq!(allocated(shape)?,n);let values=array(member(shape,"values")?)?;assert_eq!(values.len(),n);
            let values=values.iter().map(integer).collect::<Result<Vec<_>>>()?;
            // This is an observed replay-domain check, never a production skip.
            assert!(values.iter().all(|v|*v==0),"positive primary child not represented by Source39");inlet_values=Some(values);
        }else{assert_eq!(n,0);}
    }
    let indices=if vent && controlled {
        let dsoa=integer(member(raw,"ZoneDesignSpecOAIndex")?)?;let distribution=integer(member(raw,"ZoneAirDistributionIndex")?)?;
        assert_eq!(dsoa,0,"positive DSOA child outside this replay");assert_eq!(distribution,0,"positive air distribution outside this replay");
        Some((integer(member(raw,"EquipListIndex")?)?,dsoa,distribution))
    }else{None};
    let address=equipment.restore_native_report_config(number,&identity_name(fixture,"zone_names",number)?,controlled,inlet_values.as_deref(),indices)?;
    bind(ids,"Config",raw,address)
}
fn seed_node(equipment:&mut OrdinaryEquipment,fixture:&Value,raw:&Value,supply:bool,ids:&mut BTreeMap<(String,usize),usize>)->Result {
    let number=integer(member(raw,"index")?)?;allocated(raw)?;let value=row_value(raw)?;
    let (t,w,m)=if supply{(None,None,Some(real(member(value,"MassFlowRate")?)?))}else{(Some(real(member(value,"Temp")?)?),Some(real(member(value,"HumRat")?)?),None)};
    let address=equipment.restore_native_report_node(number,&identity_name(fixture,"node_ids",number)?,t,w,m)?;
    bind(ids,"Node",value,address)
}
fn check_node(equipment:&OrdinaryEquipment,raw:&Value,supply:bool,context:&str)->Result {
    let n=equipment.source_zone_air_node(integer(member(raw,"index")?)?)?;let value=row_value(raw)?;
    if supply{assert_real(*n.mass_flow_rate,member(value,"MassFlowRate")?,context,"physical supply Mdot unchanged")?;}
    else{assert_real(*n.temperature,member(value,"Temp")?,context,"physical recirc T unchanged")?;assert_real(*n.humidity_ratio,member(value,"HumRat")?,context,"physical recirc W unchanged")?;}
    Ok(())
}
fn seed_units(equipment:&mut OrdinaryEquipment,fixture:&Value,zone:&Value,ids:&mut BTreeMap<(String,usize),usize>)->Result {
    let list=member(zone,"equipment_list")?;allocated(list)?;let list_number=integer(member(list,"index")?)?;let list_value=row_value(list)?;
    let entries=array(member(list_value,"equipment")?)?;assert_eq!(entries.len(),count(member(list_value,"NumOfEquipTypes")?)?);
    for entry in entries {
        let kind=integer(member(entry,"EquipType")?)?;let ordinal=integer(member(entry,"index")?)?;let unit_index=integer(member(entry,"EquipIndex")?)?;
        let address=equipment.restore_native_report_equipment_index(list_number,ordinal,kind,unit_index)?;bind(ids,"EquipmentList",list_value,address)?;
        assert_eq!(kind,12,"this cohort observes the actual PurchasedAir normal domain");
        let p=member(entry,"PurchasedAir")?;let size=allocated(p)?;let number=integer(member(p,"NumPurchAir")?)?;
        assert_eq!(size,usize::try_from(number)?);
        equipment.purchased_air.number_purchased_air=number;
        equipment.purchased_air.get_purchased_air_input=boolean(member(p,"GetPurchAirInputFlag")?)?;
        assert!(!equipment.purchased_air.get_purchased_air_input,"true lazy input remains Source39 child boundary");
        if let Some(rows)=&equipment.purchased_air.units{assert_eq!(rows.len(),size);}else{equipment.purchased_air.units=Some(vec![SourceZonePurchasedAir::default();size]);}
        let unit=equipment.purchased_air.units.as_mut().and_then(|rows|rows.get_mut(index(unit_index).ok()?)).ok_or_else(||invalid("actual unit ordinal"))?;
        let value=row_value(p)?;
        seed_reals!(unit,value,{"OutdoorAirMassFlowRate"=>outdoor_air_mass_flow_rate,"MixedAirTemp"=>mixed_air_temp,"MixedAirHumRat"=>mixed_air_hum_rat});
        unit.zone_supply_air_node_num=integer(member(value,"ZoneSupplyAirNodeNum")?)?;unit.zone_recirc_air_node_num=integer(member(value,"ZoneRecircAirNodeNum")?)?;
        bind(ids,"PurchasedAir",value,std::ptr::from_ref(unit) as usize)?;
        if let Some(n)=object(p)?.get("supply_node"){seed_node(equipment,fixture,n,true,ids)?;}
        if let Some(n)=object(p)?.get("recirc_node"){seed_node(equipment,fixture,n,false,ids)?;}
    }
    Ok(())
}
fn check_units(equipment:&OrdinaryEquipment,zone:&Value,context:&str)->Result {
    let list=member(zone,"equipment_list")?;let value=row_value(list)?;let source=equipment.source_zone_equipment_list(integer(member(list,"index")?)?)?;
    for e in array(member(value,"equipment")?)? {
        let number=integer(member(e,"EquipIndex")?)?;let ordinal=usize::try_from(integer(member(e,"index")?)?)?;
        assert_eq!(*source.equipment_index(ordinal).ok_or_else(||invalid("same EquipIndex"))?,number);
        assert_eq!(*source.equipment_type(ordinal).ok_or_else(||invalid("same EquipType"))?,integer(member(e,"EquipType")?)?);
        let p=member(e,"PurchasedAir")?;assert_eq!(equipment.purchased_air.get_purchased_air_input,boolean(member(p,"GetPurchAirInputFlag")?)?);
        assert_eq!(equipment.purchased_air.number_purchased_air,integer(member(p,"NumPurchAir")?)?);
        let u=equipment.purchased_air.units.as_ref().and_then(|rows|rows.get(index(number).ok()?)).ok_or_else(||invalid("same unit"))?;let v=row_value(p)?;
        check_reals!(u,v,context,{"OutdoorAirMassFlowRate"=>outdoor_air_mass_flow_rate,"MixedAirTemp"=>mixed_air_temp,"MixedAirHumRat"=>mixed_air_hum_rat});
        assert_eq!(u.zone_supply_air_node_num,integer(member(v,"ZoneSupplyAirNodeNum")?)?);assert_eq!(u.zone_recirc_air_node_num,integer(member(v,"ZoneRecircAirNodeNum")?)?);
        if let Some(n)=object(p)?.get("supply_node"){check_node(equipment,n,true,context)?;}
        if let Some(n)=object(p)?.get("recirc_node"){check_node(equipment,n,false,context)?;}
    }
    Ok(())
}
fn report_values(raw:&Value)->Result<[f64;20]>{let mut out=[0.0;20];for (i,name) in ZONE_FIELDS.iter().enumerate(){out[i]=real(member(raw,name)?)?;}Ok(out)}
pub(super) fn run()->Result<(usize,usize,usize)> {
    let fixture:Value=serde_json::from_str(NATIVE_SYSTEM_REPORT_COHORT_JSON)?;
    let original:Value=serde_json::from_str(NATIVE_PREDICTION_COHORT_JSON)?;
    let mut input=input(&original)?;
    let inventory=object(member(&original,"raw")?)?.iter().map(|(f,o)|Ok((f.as_str(),object(o)?.len()))).collect::<Result<Vec<_>>>()?;
    let admitted=OrdinaryEquipmentInput::from_source_family_inventory(inventory,4)?;let model=identity_model();
    let mut equipment=OrdinaryEquipment::new_for_source(&model,admitted)?;
    let mut globals=SelectedHeatBalanceGlobals::default();globals.num_of_zones=i32::try_from(model.zones.len())?;globals.num_spaces=i32::try_from(model.spaces.len())?;
    assert_eq!(array(member(&fixture,"zone_names")?)?.len(),model.zones.len());
    let mut zones=SelectedZoneInputOwners::default();
    zones.zones=Some(vec![SelectedZoneData {name:"ZONE ONE".into(),typed_zone_id:Some(ep_model::ZoneId(0)),space_indexes:vec![1],num_spaces:1,..Default::default()}]);
    let mut schedules=SelectedScheduleManager::default();schedules.init_constant_state(4)?;
    let mut sizing=SelectedSizingManager::default();let mut branch=SourceBranchNodeConnections::default();let mut gains=SelectedInternalHeatGains::default();
    equipment.get_zone_equipment_source(&mut input,admitted,false,false,&globals,&mut gains,
        SourceEquipmentInputOwners {zones:zones.zones.as_deref_mut().ok_or_else(||invalid("actual Zone"))?,schedules:&mut schedules,sizing:&mut sizing,branch:Some(&mut branch),source_is_epjson:false})?;
    let space_controls=SelectedHeatBalanceSpaceControls::default();let mut controller=SourceZoneAirPredictorCorrector::default();
    controller.demand.allocate_source_demands(&globals,&space_controls)?;controller.reports.allocate_source_reports(&globals,&space_controls)?;
    let mut air=SourceAirHeatBalance::default();air.allocate_source_arrays(&globals)?;
    zones.zone_predefined=Some(vec![ZonePredefined::default();model.zones.len()]);
    let mut reports=SourceSystemReports::default();let mut summary=SourceComfortPredefinedSummary::default();
    let mut hvac=SelectedHvacGlobals::default();let mut environment=WeatherEnvironmentState::default();
    // Separate genuine Native process/state lifetimes never assert cross-process addresses.
    let mut identity_groups:BTreeMap<String,BTreeMap<(String,usize),usize>>=BTreeMap::new();let mut energy=0;let mut vent=0;let mut variants=0;
    for case in array(member(&fixture,"cases")?)? {
        let method=text(member(case,"method")?)?;let is_vent=method=="ReportVentilationLoads";assert!(is_vent || method=="ReportSystemEnergyUse");
        let origin=member(case,"origin")?;let kind=text(member(origin,"kind")?)?;
        assert!(kind=="engine" || kind=="native-unit-variant");if kind=="native-unit-variant"{variants+=1;}
        let entry=member(case,"entry")?;let expected=member(case,"expected_exit")?;
        let state=member(entry,"state")?;let flags=member(state,"flags")?;let clock=member(entry,"clock")?;
        let identity_scope=format!("{kind}:{}",count(member(clock,"state_address")?)?);
        let identities=identity_groups.entry(identity_scope).or_default();
        let context=format!("Native report {method} origin{kind} invocation{}",integer(member(entry,"invocation_ordinal")?)?);
        globals.num_of_zones=integer(member(flags,"NumOfZones")?)?;assert_eq!(usize::try_from(globals.num_of_zones)?,model.zones.len());
        hvac.number_of_primary_air_systems=integer(member(flags,"NumPrimaryAirSys")?)?;assert_eq!(hvac.number_of_primary_air_systems,0);
        hvac.time_step_sys=real(member(clock,"TimeStepSys")?)?;hvac.time_step_sys_seconds=real(member(clock,"TimeStepSysSec")?)?;
        reports.air_loop_loads_report_enabled=boolean(member(flags,"AirLoopLoadsReportEnabled")?)?;
        reports.vent_report_structure_created=boolean(member(flags,"VentReportStructureCreated")?)?;
        reports.vent_loads_report_enabled=boolean(member(flags,"VentLoadsReportEnabled")?)?;
        reports.vent_energy_report_enabled=boolean(member(flags,"VentEnergyReportEnabled")?)?;
        let enabled=if is_vent{reports.vent_report_structure_created && reports.vent_loads_report_enabled}else{reports.air_loop_loads_report_enabled};
        if enabled {
            if is_vent {
                environment.std_rho_air=real(member(state,"StdRhoAir")?)?;environment.current_weather.out_baro_press=real(member(clock,"OutBaroPress")?)?;
                seed_reals!(reports,member(state,"facility_report")?,{@@FAC@@});
                seed_reals!(summary,member(state,"facility_predefined_totals")?,{@@SUM@@});
            }
            for z in array(member(state,"zones")?)? {
                let number=integer(member(z,"index")?)?;let i=index(number)?;seed_config(&mut equipment,&fixture,z,is_vent,identities)?;
                if is_vent {
                    let report=member(z,"report")?;reports.prepare_native_report_cohort_rows(allocated(report)?)?;
                    let address=reports.restore_native_report_cohort_row(number,report_values(row_value(report)?)?)?;bind(identities,"ZoneVent",row_value(report)?,address)?;
                }
                let config=row_value(member(z,"config")?)?;
                if !boolean(member(config,"IsControlled")?)?{continue;}
                let d=member(z,"demand")?;let demand=controller.demand.zones.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same demand"))?;
                demand.base.total_output_required=real(member(d,"TotalOutputRequired")?)?;bind(identities,"Demand",d,std::ptr::from_ref(demand) as usize)?;
                *controller.demand.deadband_or_setback.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same DeadBand"))?=bool_integer(member(member(z,"DeadBandOrSetback")?,"value")?)?;
                if !is_vent{continue;}
                let zone=member(z,"zone")?;let actual=zones.zones.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same Zone"))?;
                assert_eq!(actual.name,text(member(zone,"Name")?)?);actual.multiplier=integer(member(zone,"Multiplier")?)?;actual.list_multiplier=integer(member(zone,"ListMultiplier")?)?;actual.volume=real(member(zone,"Volume")?)?;
                bind(identities,"Zone",zone,std::ptr::from_ref(actual) as usize)?;
                let predef=row_value(member(z,"predefined")?)?;let actual=zones.zone_predefined.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same predef"))?;
                actual.is_occupied=boolean(member(predef,"isOccupied")?)?;seed_reals!(actual,predef,{@@PF@@});bind(identities,"Predef",predef,std::ptr::from_ref(actual) as usize)?;
                let a=member(z,"air")?;let actual=air.zones.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same AirHB"))?;
                actual.air.mat=real(member(a,"MAT")?)?;actual.air.air_hum_rat_avg=real(member(a,"airHumRatAvg")?)?;bind(identities,"AirHB",a,std::ptr::from_ref(actual) as usize)?;
                let r=member(z,"ZnAirRpt")?;let actual=controller.reports.zones.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same ZnAirRpt"))?;
                seed_reals!(actual,r,{"InfilVolumeCurDensity"=>infil_volume_cur_density,"InfilVolumeStdDensity"=>infil_volume_std_density,"VentilVolumeCurDensity"=>ventil_volume_cur_density,"VentilVolumeStdDensity"=>ventil_volume_std_density});bind(identities,"ZnAirRpt",r,std::ptr::from_ref(actual) as usize)?;
                seed_units(&mut equipment,&fixture,z,identities)?;
            }
        }
        if is_vent {reports.report_source_ventilation_loads(&globals,&hvac,&equipment,&mut zones,&controller.demand,&controller.reports,&air,&environment,&sizing,&mut summary)?;vent+=1;}
        else {reports.report_source_system_energy_use(&globals,&hvac,&equipment,&controller.demand)?;energy+=1;}
        let out=member(expected,"state")?;
        if enabled {
            for z in array(member(out,"zones")?)? {
                let number=integer(member(z,"index")?)?;let i=index(number)?;let config=row_value(member(z,"config")?)?;
                let source=equipment.source_zone_equipment_config(number)?;assert_eq!(*source.is_controlled(),boolean(member(config,"IsControlled")?)?);
                if is_vent {
                    let values=reports.native_report_cohort_row(number)?;let expected=row_value(member(z,"report")?)?;
                    for (v,name) in values.into_iter().zip(ZONE_FIELDS){assert_real(v,member(expected,name)?,&context,name)?;}
                }
                if !*source.is_controlled(){continue;}
                let d=controller.demand.zones.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("actual same demand after"))?;
                assert_real(d.base.total_output_required,member(member(z,"demand")?,"TotalOutputRequired")?,&context,"demandTotal unchanged")?;
                assert_eq!(*controller.demand.deadband_or_setback.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("actual same deadband after"))?,bool_integer(member(member(z,"DeadBandOrSetback")?,"value")?)?);
                for (j,raw) in array(member(member(config,"InletNodeAirLoopNum")?,"values")?)?.iter().enumerate(){assert_eq!(*source.inlet_node_air_loop_number(j+1).ok_or_else(||invalid("same inlet association"))?,integer(raw)?);}
                if !is_vent{continue;}
                let predef=zones.zone_predefined.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("same predef after"))?;let raw=row_value(member(z,"predefined")?)?;
                assert_eq!(predef.is_occupied,boolean(member(raw,"isOccupied")?)?);check_reals!(predef,raw,&context,{@@PF@@});
                let a=air.zones.as_ref().and_then(|r|r.get(i)).ok_or_else(||invalid("same air after"))?;let raw=member(z,"air")?;
                assert_real(a.air.mat,member(raw,"MAT")?,&context,"MAT unchanged")?;assert_real(a.air.air_hum_rat_avg,member(raw,"airHumRatAvg")?,&context,"Wavg unchanged")?;
                check_units(&equipment,z,&context)?;
            }
            if is_vent{check_reals!(reports,member(out,"facility_report")?,&context,{@@FAC@@});check_reals!(summary,member(out,"facility_predefined_totals")?,&context,{@@SUM@@});}
        }
    }
    let expected=member(&fixture,"counts")?;assert_eq!(energy,count(member(expected,"ReportSystemEnergyUse")?)?);assert_eq!(vent,count(member(expected,"ReportVentilationLoads")?)?);
    assert_eq!(variants,count(member(&fixture,"native_unit_variants")?)?);assert!(energy>0 && vent>0 && identity_groups.values().all(|ids|ids.len()>1));
    Ok((energy,vent,variants))
}
'''
child=child.replace('@@ZONE_NAMES@@',json.dumps(list(Z))).replace('@@FAC@@',mapping(FAC)).replace('@@SUM@@',mapping(SUM)).replace('@@PF@@',mapping(PF))
assert '@@' not in child
proposals[F+'native_cohort/report_cohort.rs']=child
native=F+'native_cohort.rs';before=(R/native).read_text(encoding='utf-8');proposals[native]=before+'''
// One consolidated target; the original complete air cohort above is unchanged.
mod report_cohort;
impl SourceZoneAirPredictorCorrector {
    pub(crate) fn run_native_system_report_cohort() -> Result<(usize,usize,usize)> {
        report_cohort::run()
    }
}
'''
main='crates/ep_runtime/src/lib.rs';s=(R/main).read_text(encoding='utf-8');needle='''    println!("running 1 native controlled-air cohort on process main");'''
replacement='''    let selection=std::env::args().skip(1).collect::<Vec<_>>();
    if selection.len()==1 && selection[0]=="--report-only" {
        println!("running 1 native system-report cohort on process main");
        let (energy,vent,variants)=crate::heat_balance::ordinary_air_heat_balance::predictor_corrector::SourceZoneAirPredictorCorrector::run_native_system_report_cohort()?;
        println!("cohort native_controlled_air_cohort ... ok");
        println!("cohort result: ok. 1 passed; 0 failed; energy entries={energy}; ventilation entries={vent}; named Native-unit variants={variants}");
        return Ok(());
    }
    if !selection.is_empty() {return Err(std::io::Error::new(std::io::ErrorKind::InvalidInput,"expected no arguments or --report-only").into());}
    println!("running 1 native controlled-air cohort on process main");'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
needle='''    println!("cohort native_controlled_air_cohort ... ok");
    println!("cohort result: ok. 1 passed; 0 failed; predictor entries=1168; whole corrector entries=1168; positive inlet cases=810");'''
assert s.count(needle)==1;s=s.replace(needle,'''    let (energy,vent,variants)=crate::heat_balance::ordinary_air_heat_balance::predictor_corrector::SourceZoneAirPredictorCorrector::run_native_system_report_cohort()?;
    println!("system-report entries: energy={energy}; ventilation={vent}; named Native-unit variants={variants}");
'''+needle,1);proposals[main]=s
files=[]
for i,(name,s) in enumerate(proposals.items(),1):
 before=(R/name).read_bytes() if (R/name).exists() else b'';new=s.encode();proposed=save('proposed/'+name,new)
 forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name));inverse=''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',proposed['path']],capture_output=True);assert parsed.returncode==0,(name,parsed.stderr)
 files.append({'canonical_path':name,'before_absent':not (R/name).exists(),'before':save('before/'+name,before),'proposed':proposed,'forward_diff':save(f'diffs/{i:02}.forward.diff',forward.encode()),'inverse_diff':save(f'diffs/{i:02}.inverse.diff',inverse.encode()),'Source_only_parse':{'exit_code':0,'stderr':save(f'parse/{i:02}.stderr',parsed.stderr),'stdout_sha256':hashlib.sha256(parsed.stdout).hexdigest()}})
files.append({'canonical_path':F+'fixtures/native_system_report_b.rs','before_absent':True,'proposed':fixture_ref})
assert (R/F/'native_cohort.rs').read_bytes()==proposals[F+'native_cohort.rs'].encode()[:len((R/F/'native_cohort.rs').read_bytes())]
result={'schema':'src06-system-report-cohort40-engine-origin-scaffold.v1','status':'ISOLATED ENGINE-ORIGIN SCAFFOLD; Native named-unit variant oracle/consumed-closure self-review/independent peer and final custody still pending','author_Source':ref(Path(__file__)),'actual_Native_capture':ref(cp),'actual_observation':ref(rawp),'actual_Native_BND':ref(bndp),'files':files,'engine_cases':306,'engine_method_counts':dict(counts),'positive_supply_flow_cases':positive,'nonzero_engine_report_output_cases':nonzero,'raw_binary64_values':scalars,'old_air_fixture_whole_unchanged':ref(R/F/'fixtures/native_prediction_b.rs'),'old_air_cohort_whole_prefix_preserved':True,'new_test_bodies':0,'new_Cargo_targets_or_features':0,'tests_executed':0,'Cargo_executed':False,'Native_engine_or_unit_executed_by_author':False,'scientific_report_PASS_claimed':False,'qualifications':['All153 actual engine-origin ventilation outputs are0; no nonzero/classification/occupied/threshold coverage claim. Genuine Native unit variants remain pending.','Only captured report entry fields are restored. Physical Node H/Tset are not fabricated or touched.','OARequirements shape is observed but positive DSOA is not consumed in admitted pointer0 domain; no sizing-owner parity claim.','Same input/getter-created Config/List/Node owners, exact NativeBND NodeID checks, same same actual report/predef/air/demand/unit types and stable addresses.','No production API/math/tolerance changes; cfg(test,feature) helpers and same safe process-main target only.']}
print(json.dumps({'draft':dump('draft.json',result),'fixture':fixture_ref}))

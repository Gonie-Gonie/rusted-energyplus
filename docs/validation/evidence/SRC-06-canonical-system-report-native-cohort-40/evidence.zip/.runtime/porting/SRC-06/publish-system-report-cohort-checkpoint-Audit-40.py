"""Root-only cohort40 publisher: one actual report-only target; never executes tests.

Seven test-only Sources, three short existing docs appends, one existing command
section and one SRC06 plan key. Pending metadata cannot publish.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-system-report-native-cohort-40'
BACK=D/'system-report-cohort-publication-readback-Audit-40'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=(R/row['path']).resolve();p.relative_to(R);v=ref(p);assert v['sha256']==row['sha256'] and v['bytes']==row.get('bytes',row.get('size_bytes',v['bytes']));return p
def load(p):return json.loads(p.read_bytes())
def contains(v,row):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(row['path'],row['sha256']) or any(contains(x,row) for x in v.values())
 return isinstance(v,list) and any(contains(x,row) for x in v)
def accepted(row):
 v=load(checked(row));assert v['accepted'] is True and not v.get('findings',[]);return v
def write_json(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def main(a):
 assert a.publish and not PUBLIC.exists() and not BACK.exists()
 tp=(R/a.template).resolve();tp.relative_to(R);t=load(tp);assert t['status']=='HELD_READY_FOR_ROOT_REPORT_COHORT40_AND_FULL_READ'
 assert ref(Path(__file__))==t['publisher_Source'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==t['base_HEAD']
 producer=load(checked(t['producer']));plan=load(checked(t['complete_plan']));assert len(producer['files'])==7 and producer['existing_Source_files']==5 and producer['new_Source_files']==2
 assert (plan['compiler_inputs'],plan['Rust_sources'])==(4510,4497)
 peer=accepted(t['independent_peer']);assert peer['reviewed_draft']==producer['original_draft']
 parent_review=accepted(t['accepted_parent_review']);assert parent_review['complete_compiler_plan']['sha256']==t['accepted_parent_plan']['sha256']
 ar=dict(path=t['expected_actual_review_path'],sha256=a.actual_sha);actual=accepted(ar);ar=ref(checked(ar))
 for r in [t['producer'],t['complete_plan'],t['independent_peer'],t['accepted_parent_review']]:assert contains(actual,r),r['path']
 assert actual['all4510_inputs_exact_final_plan_and_live'] and actual['old_Air_helper_prefix_fixture_whole_unchanged']
 assert actual['actual_executed_test_bodies']==actual['successful_main_report_cohort_executions']==1 and actual['new_test_bodies']==0
 assert actual['engine_origin_cases']==306 and actual['explicit_Native_unit_input_variants']==165 and actual['total_actual_report_function_calls']==471
 assert actual['actual_report_method_counts']=={'ReportSystemEnergyUse':153,'ReportVentilationLoads':318}
 assert actual['all8_Source_nonzero_classifications_asserted'] and actual['unchanged_predictor_and_corrector_cases_reexecuted_this_checkpoint']==0
 assert actual['production_numerical_bodies_unchanged'] and not actual['historical_CLI_compiler_snapshot_is_current_test_snapshot']
 unit=load(checked(actual['actual_focused_test']));assert unit['exit_code']==0 and unit['launch_error'] is None and unit['source_bytes_match_before_and_after'] and unit['command']==producer['command']
 assert checked(unit['stdout']).read_text(encoding='utf-8').splitlines()==['running 1 native system-report cohort on process main','cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; energy entries=153; ventilation entries=318; named Native-unit variants=165']
 observed={r['historical_path']:r for r in load(checked(unit['source_snapshot']))['files']};index={r['path']:r for r in plan['entries']};assert len(index)==len(observed)==4510 and set(index)==set(observed)
 for p,r in index.items():assert (r['final_sha256'],r['final_bytes'])==(observed[p]['archive']['sha256'],observed[p]['size_bytes'])
 for r in producer['files']:
  p=r['canonical_path'];assert (R/p).read_bytes()==checked(r['proposed']).read_bytes()==checked(observed[p]['archive']).read_bytes()
 checked(producer['old_air_fixture_whole_unchanged'])
 native=accepted(producer['actual_Native_unit_run']);assert native['exit_code']==0 and native['actual_three_GNU_DLL_binding_proved']
 assert native['admission_and_nonzero_coverage']['actual_engine_bases']==306 and native['admission_and_nonzero_coverage']['explicit_variants']==165
 assert all(v>0 for v in native['admission_and_nonzero_coverage']['classification8_nonzero_counts'].values())
 base=R/'energyplus_porting_plan';names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md'];docs={n:(base/n).read_bytes() for n in names};pp=base/'plan.json';oldplan=pp.read_bytes();oldvalue=json.loads(oldplan)
 for n,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R) and '\ufffd' not in b.decode('utf-8','strict')
 assert oldplan==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
 previous=load(checked(t['previous_checkpoint']));assert (previous['A'],previous['B'])==('14/54','14/64')
 contributing=R/'CONTRIBUTING.md';contributing_before=contributing.read_bytes();contributing_after=checked(t['contributing_change']['after']).read_bytes()
 assert contributing_before==checked(t['contributing_change']['before']).read_bytes()==subprocess.check_output(['git','show',head+':CONTRIBUTING.md'],cwd=R)
 assert b'--report-only' in contributing_after and b'\xef\xbf\xbd' not in contributing_after
 files={}
 def add(p):
  p=p.resolve();p.relative_to(R);r=ref(p);assert p.suffix.lower()!='.zip' and r['bytes']<64*1024*1024
  assert p.suffix.lower() not in {'.exe','.dll','.a','.obj','.map'} and p.name not in {'frozen-environment.json','Native-before.json','Native-after.json','native_prediction_b.rs'}
  assert r['path'] not in files or files[r['path']]['ref']==r;files[r['path']]=dict(path=p,ref=r)
 for r in t['finite_archive_inputs']:add(checked(r))
 for p in [Path(__file__),tp,checked(ar)]:add(p)
 apppath=checked(actual['application']);app=load(apppath);assert app['accepted'] and not app.get('findings',[]) and app['base_HEAD']==head
 for r in [t['producer'],t['complete_plan']]:assert contains(app,r)
 for p in [apppath,checked(actual['author_Source']),checked(app['author_Source']),checked(t['launcher_Source']),checked(t['literal_helper_Source'])]:add(p)
 add(checked(actual['actual_focused_test']))
 for key in ['stdout','stderr','source_snapshot']:add(checked(unit[key]))
 if 'executed_launcher' in unit:add(checked(unit['executed_launcher']['archive']))
 for key in ['before','after','forward_diff','inverse_diff']:add(checked(t['contributing_change'][key]))
 for r in producer['files']:add(R/r['canonical_path'])
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan);(BACK/'CONTRIBUTING-before.md').write_bytes(contributing_before)
 for n,b in docs.items():p=BACK/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 archive=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,item in sorted(files.items()):assert ref(item['path'])==item['ref'];z.write(item['path'],arcname=n)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and set(z.namelist())==set(files)
  for n,item in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==item['ref']['sha256']
 manifest=PUBLIC/'manifest.json';write_json(manifest,dict(schema='src06-canonical40-finite-Native-report-cohort-evidence.v1',archive=ref(archive),entries=[x['ref'] for n,x in sorted(files.items())],scope='Seven test-only Sources and one existing safe-main target report-only invocation. Exact306 actual Engine report cases and165 separate full-Native-function unit input variants; every recorded field/raw-bit result retained. Direct Native39 raw3MB, full Native unit6MB and5MB fixture plus producer/projector/proof/receipts. No old20MBAirfixture, recursive ZIPs, explicit environment, executables/providers/core/map or unrelated annual payload.'))
 summary=dict(t['summary_template']);summary.update(schema='src06-canonical-system-report-Native-cohort40.v1',status='PASS: one existing safe process-main report-only cohort, all471 genuine Native-paired calls exact',producer=t['producer'],independent_peer=t['independent_peer'],complete_compiler_plan=t['complete_plan'],accepted_parent_review=t['accepted_parent_review'],accepted_parent_plan=t['accepted_parent_plan'],actual_focused_test=actual['actual_focused_test'],Root_actual_review=ar,actual_Native_engine_capture=producer['actual_Native_capture'],actual_Native_full_function_unit=producer['actual_Native_unit_run'],Source_fixture_projector=producer['Source_fixture_projector'],strict_fixture_projection_proof=producer['strict_fixture_projection_proof'],actual_Native_thermal8_nonzero_counts=actual['Native_thermal8_nonzero_counts'],actual_test_bodies_executed=1,new_test_bodies=0,unchanged_Air_cases_reexecuted=0,inherited_production5352_proof=dict(actual41=t['accepted_parent_review'],series=58,samples=5352,qualification='Inherited actual41 production CLI after test/feature exclusion; historical CLI did not execute current test snapshot.'),archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json';write_json(sp,summary);relative='evidence/SRC-06-canonical-system-report-native-cohort-40/summary.json'
 for n,b in docs.items():
  link='../'+relative if n.startswith('cards/') else relative;text=t['doc_appends'][n]
  append='\n\n[Source40 Native report cohort]('+link+'). '+text+'\n'
  assert '\ufffd' not in append and '{{' not in append and (base/n).read_bytes()==b;(base/n).write_bytes(b+append.encode('utf-8'))
 after=json.loads(oldplan);task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_system_report_native_cohort_40';assert key not in task
 task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=ref(sp)['sha256'],size_bytes=sp.stat().st_size);inverse=json.loads(json.dumps(after));del next(x for x in inverse['tasks'] if x['id']=='SRC-06')[key];assert inverse==oldvalue and pp.read_bytes()==oldplan;write_json(pp,after)
 assert contributing.read_bytes()==contributing_before;contributing.write_bytes(contributing_after)
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),actual_engine_CLI_receipts=0,actual_test_bodies_executed_by40=1,new_test_bodies=0,existing_cohort_body_extended=1,CONTRIBUTING_before=ref(BACK/'CONTRIBUTING-before.md'),Cargo_Native_or_tests_executed=False,gate_changes=False,Git_mutated=False)
 p=BACK/'publication-readback.json';write_json(p,result);print(json.dumps(ref(p)))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--template',required=True);ap.add_argument('--actual-sha',required=True);ap.add_argument('--publish',action='store_true');main(ap.parse_args())

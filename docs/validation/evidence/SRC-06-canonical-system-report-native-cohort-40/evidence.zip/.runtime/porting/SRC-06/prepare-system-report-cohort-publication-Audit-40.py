"""Private waiting publication on the accepted39 finite evidence engine."""
from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'system-report-cohort-publication-prepared-Audit-40';OLD=D/'publish-controlled-system-report-checkpoint-Audit-39.py';NEW=D/'publish-system-report-cohort-checkpoint-Audit-40.py'
assert not O.exists() and not NEW.exists();O.mkdir()
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R) and ref(p)['sha256']==v['sha256'];return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,v):return save(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
before=OLD.read_text(encoding='utf-8');assert ref(OLD)['sha256']=='969710d9e05cb140a56e99e4cda4e786cfb3ee64a1accdb285300acb919e2e43';s=before
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
replace('"""Root-only engine39 publisher: two genuine CLI receipts; never runs Cargo/tests.\n\nRequires a finalized template after the accepted cohort parent and final six-file\npacket. No action occurs without --publish. Pending draft metadata cannot publish.\n"""','"""Root-only cohort40 publisher: one actual report-only target; never executes tests.\n\nSeven test-only Sources, three short existing docs appends, one existing command\nsection and one SRC06 plan key. Pending metadata cannot publish.\n"""')
replace("SRC-06-canonical-controlled-system-report-39'","SRC-06-canonical-system-report-native-cohort-40'")
replace("controlled-system-report-publication-readback-Audit-39'","system-report-cohort-publication-readback-Audit-40'")
replace("t['status']=='HELD_READY_FOR_ROOT_ACTUAL39_AND_FULL_READ'","t['status']=='HELD_READY_FOR_ROOT_REPORT_COHORT40_AND_FULL_READ'")
start=s.index(' producer=load(');end=s.index(" base=R/'energyplus_porting_plan'",start)
s=s[:start]+''' producer=load(checked(t['producer']));plan=load(checked(t['complete_plan']));assert len(producer['files'])==7 and producer['existing_Source_files']==5 and producer['new_Source_files']==2
 assert (plan['compiler_inputs'],plan['Rust_sources'])==(4510,4497)
 peer=accepted(t['independent_peer']);assert peer['reviewed_draft']==producer['original_draft']
 parent_review=accepted(t['accepted_parent_review']);assert parent_review['complete_compiler_plan']['sha256']==t['accepted_parent_plan']['sha256']
 ar=dict(path=t['expected_actual_review_path'],sha256=a.actual_sha);actual=accepted(ar);ar=ref(checked(ar))
 for r in [t['producer'],t['complete_plan'],t['independent_peer'],t['accepted_parent_review']]:assert contains(actual,r),r['path']
 assert actual['all4510_inputs_exact_final_plan_and_live'] and actual['old_Air_helper_prefix_fixture_whole_unchanged']
 assert actual['actual_executed_test_bodies']==actual['successful_main_report_cohort_executions']==1 and actual['new_test_bodies']==0
 assert actual['engine_origin_cases']==306 and actual['explicit_Native_unit_input_variants']==165 and actual['total_actual_report_function_calls']==471
 assert actual['actual_report_method_counts']=={'ReportSystemEnergyUse':153,'ReportVentilationLoads':318}
 assert actual['all8_Source_nonzero_classifications_asserted'] and actual['unchanged_predictor_and_corrector_cases_reexecuted_this_checkpoint']==0
 assert actual['production_numerical_bodies_unchanged'] and not actual['historical_CLI_compiler_snapshot_is_current_test_snapshot']
 unit=load(checked(actual['actual_focused_test']));assert unit['exit_code']==0 and unit['launch_error'] is None and unit['source_bytes_match_before_and_after'] and unit['command']==producer['command']
 assert checked(unit['stdout']).read_text(encoding='utf-8').splitlines()==['running 1 native system-report cohort on process main','cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; energy entries=153; ventilation entries=318; named Native-unit variants=165']
 observed={r['historical_path']:r for r in load(checked(unit['source_snapshot']))['files']};index={r['path']:r for r in plan['entries']};assert len(index)==len(observed)==4510 and set(index)==set(observed)
 for p,r in index.items():assert (r['final_sha256'],r['final_bytes'])==(observed[p]['archive']['sha256'],observed[p]['size_bytes'])
 for r in producer['files']:
  p=r['canonical_path'];assert (R/p).read_bytes()==checked(r['proposed']).read_bytes()==checked(observed[p]['archive']).read_bytes()
 checked(producer['old_air_fixture_whole_unchanged'])
 native=accepted(producer['actual_Native_unit_run']);assert native['exit_code']==0 and native['actual_three_GNU_DLL_binding_proved']
 assert native['admission_and_nonzero_coverage']['actual_engine_bases']==306 and native['admission_and_nonzero_coverage']['explicit_variants']==165
 assert all(v>0 for v in native['admission_and_nonzero_coverage']['classification8_nonzero_counts'].values())
'''+s[end:]
replace("previous=load(checked(t['previous_engine_checkpoint']))","previous=load(checked(t['previous_checkpoint']))")
replace(" files={}\n",''' contributing=R/'CONTRIBUTING.md';contributing_before=contributing.read_bytes();contributing_after=checked(t['contributing_change']['after']).read_bytes()
 assert contributing_before==checked(t['contributing_change']['before']).read_bytes()==subprocess.check_output(['git','show',head+':CONTRIBUTING.md'],cwd=R)
 assert b'--report-only' in contributing_after and b'\\xef\\xbf\\xbd' not in contributing_after
 files={}
''')
replace("  assert r['path'] not in files or files[r['path']]['ref']==r;files[r['path']]=dict(path=p,ref=r)","  assert p.suffix.lower() not in {'.exe','.dll','.a','.obj','.map'} and p.name not in {'frozen-environment.json','Native-before.json','Native-after.json','native_prediction_b.rs'}\n  assert r['path'] not in files or files[r['path']]['ref']==r;files[r['path']]=dict(path=p,ref=r)")
replace(" for p in [apppath,checked(actual['author_Source']),checked(app['author_Source']),checked(actual['launcher_Source'])]:add(p)"," for p in [apppath,checked(actual['author_Source']),checked(app['author_Source']),checked(t['launcher_Source']),checked(t['literal_helper_Source'])]:add(p)")
start=s.index(" for key,run in zip(");end=s.index(" for r in producer['files']:add",start)
s=s[:start]+''' add(checked(actual['actual_focused_test']))
 for key in ['stdout','stderr','source_snapshot']:add(checked(unit[key]))
 if 'executed_launcher' in unit:add(checked(unit['executed_launcher']['archive']))
 for key in ['before','after','forward_diff','inverse_diff']:add(checked(t['contributing_change'][key]))
'''+s[end:]
replace(" PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan)"," PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan);(BACK/'CONTRIBUTING-before.md').write_bytes(contributing_before)")
start=s.index(" manifest=PUBLIC/'manifest.json'");end=s.index(" sp=PUBLIC/'summary.json'",start)
s=s[:start]+''' manifest=PUBLIC/'manifest.json';write_json(manifest,dict(schema='src06-canonical40-finite-Native-report-cohort-evidence.v1',archive=ref(archive),entries=[x['ref'] for n,x in sorted(files.items())],scope='Seven test-only Sources and one existing safe-main target report-only invocation. Exact306 actual Engine report cases and165 separate full-Native-function unit input variants; every recorded field/raw-bit result retained. Direct Native39 raw3MB, full Native unit6MB and5MB fixture plus producer/projector/proof/receipts. No old20MBAirfixture, recursive ZIPs, explicit environment, executables/providers/core/map or unrelated annual payload.'))
 summary=dict(t['summary_template']);summary.update(schema='src06-canonical-system-report-Native-cohort40.v1',status='PASS: one existing safe process-main report-only cohort, all471 genuine Native-paired calls exact',producer=t['producer'],independent_peer=t['independent_peer'],complete_compiler_plan=t['complete_plan'],accepted_parent_review=t['accepted_parent_review'],accepted_parent_plan=t['accepted_parent_plan'],actual_focused_test=actual['actual_focused_test'],Root_actual_review=ar,actual_Native_engine_capture=producer['actual_Native_capture'],actual_Native_full_function_unit=producer['actual_Native_unit_run'],Source_fixture_projector=producer['Source_fixture_projector'],strict_fixture_projection_proof=producer['strict_fixture_projection_proof'],actual_Native_thermal8_nonzero_counts=actual['Native_thermal8_nonzero_counts'],actual_test_bodies_executed=1,new_test_bodies=0,unchanged_Air_cases_reexecuted=0,inherited_production5352_proof=dict(actual41=t['accepted_parent_review'],series=58,samples=5352,qualification='Inherited actual41 production CLI after test/feature exclusion; historical CLI did not execute current test snapshot.'),archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
'''+s[end:]
replace("relative='evidence/SRC-06-canonical-controlled-system-report-39/summary.json'","relative='evidence/SRC-06-canonical-system-report-native-cohort-40/summary.json'")
replace("text=t['doc_appends'][n].replace('{{actual_B_result}}',bresult)","text=t['doc_appends'][n]")
replace("[Source39 controlled system reports]","[Source40 Native report cohort]")
replace("key='canonical_controlled_system_report_39'","key='canonical_system_report_native_cohort_40'")
replace(" result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK'"," assert contributing.read_bytes()==contributing_before;contributing.write_bytes(contributing_after)\n result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK'")
replace("actual_engine_CLI_receipts=2,actual_test_bodies_executed_by39=0","actual_engine_CLI_receipts=0,actual_test_bodies_executed_by40=1,new_test_bodies=0,existing_cohort_body_extended=1,CONTRIBUTING_before=ref(BACK/'CONTRIBUTING-before.md')")
ast.parse(s);NEW.write_text(s,encoding='utf-8',newline='')
forward=''.join(difflib.unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='accepted39publisher',tofile='report-cohort40publisher'));inverse=''.join(difflib.unified_diff(s.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='report-cohort40publisher',tofile='accepted39publisher'))
fr=save('publisher-forward.diff',forward.encode());ir=save('publisher-inverse.diff',inverse.encode())
mp=D/'source-system-report-cohort-held-Audit-40/manifest.json';m=json.loads(mp.read_bytes());assert ref(mp)['sha256']=='1a14003b55fccf5381cc0ded3e2fa23a55fd8a8eb6f809828803202d7955a220'
finite={}
def add(v):
 p=checked(v);r=ref(p);assert p.name not in {'frozen-environment.json','Native-before.json','Native-after.json','native_prediction_b.rs'} and p.suffix.lower() not in {'.zip','.exe','.dll','.obj','.a','.map'};finite[r['path']]=r
for v in [ref(mp),m['complete_final_compiler_Source_plan'],m['original_draft'],m['independent_full_semantic_peer'],m['author_Source'],m['full4508_parent_readback'],m['whole4497_Rust_API_census'],m['accepted41_production_actual_review'],m['parent_producer'],m['prior_complete_compiler_Source_plan'],m['actual_Native_capture'],m['finite_Native_engine_observation'],m['actual_Native_unit_run'],m['finite_Native_unit_full_output'],m['actual_Native_unit_build'],m['independent_Native_unit_Source_peer'],m['strict_fixture_projection_proof'],m['Source_fixture_projector'],m['engine_scaffold_author_Source'],m['compact_setup_address_self_review_author_Source'],ref(D/'refine-system-report-cohort-Audit-40-02.py'),ref(OLD),ref(Path(__file__)),fr,ir,ref(D/'apply-system-report-cohort-Root-40.py'),ref(D/'launch-system-report-cohort-Root-40.py'),ref(D/'check-system-report-cohort-actual-Root-40.py'),ref(D/'review-meter-final-predefined-Root-01.py'),ref(R/'tools/porting/record_command.py')]:add(v)
for f in m['files']:
 for k in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(f[k])
 add(f['Source_only_parse']['stderr'])
run=json.loads(checked(m['actual_Native_unit_run']).read_bytes());build=json.loads(checked(m['actual_Native_unit_build']).read_bytes());unitdraft=json.loads(checked(build['reviewed_draft']).read_bytes())
for v in [build['reviewed_draft'],build['compile'],build['link'],build['launcher_Source'],run['launcher_Source'],unitdraft['main_Source'],unitdraft['template_Source'],unitdraft['author_Source'],unitdraft['accepted_observer_included_whole_unchanged'],unitdraft['observer_field_ledger'],unitdraft['observer_parent_peer'],run['stdout'],run['stderr'],run['actual_child_modules']]:add(v)
for key in ['compile','link']:
 x=json.loads(checked(build[key]).read_bytes())
 for k in ['stdout','stderr']:add(x[k])
base=R/'energyplus_porting_plan';plan=json.loads((base/'plan.json').read_bytes());task=next(x for x in plan['tasks'] if x['id']=='SRC-06');previous=task['canonical_node_setpoint_endrun_41'];previous={'path':previous['path'],'sha256':previous['sha256'],'bytes':previous['size_bytes']};add(previous)
contributing=R/'CONTRIBUTING.md';oldcon=contributing.read_bytes().decode('utf-8');start=oldcon.index('The controlled-air Native cohort uses one dedicated process-main target:');end=oldcon.index('Keep one behavioral regression',start)
newsection='''The Native comparison cohort uses one dedicated process-main target:

```powershell
cargo test --locked -p ep_runtime --features native-controlled-air-cohort --test native_controlled_air_cohort
```

The default runs all 1,168 predictor entries, 1,168 whole-corrector entries
(810 positive inlet-flow cases), and 471 system-report cases. For changes to
energy or ventilation reporting and its consumed state, select reports only:

```powershell
cargo test --locked -p ep_runtime --features native-controlled-air-cohort --test native_controlled_air_cohort -- --report-only
```

This runs 306 engine-origin report calls and 165 separate full-Native-function
unit input variants, including nonzero loads and adjacent binary64 boundaries.
It skips the unchanged predictor/corrector cases. Run the full target when those
calculations or their consumed state change, and before closing integration gates.
On Windows GNU, process main preserves the Native comparison context without
changing floating-point controls or assertions. Without its explicit required
feature, ordinary library tests exclude these large cohort fixtures.

'''
newcon=oldcon[:start]+newsection+oldcon[end:];conbefore=save('CONTRIBUTING-before.md',contributing.read_bytes());conafter=save('CONTRIBUTING-after.md',newcon.encode());conforward=save('CONTRIBUTING-forward.diff',''.join(difflib.unified_diff(oldcon.splitlines(keepends=True),newcon.splitlines(keepends=True),fromfile='before/CONTRIBUTING.md',tofile='proposed/CONTRIBUTING.md')).encode());coninverse=save('CONTRIBUTING-inverse.diff',''.join(difflib.unified_diff(newcon.splitlines(keepends=True),oldcon.splitlines(keepends=True),fromfile='proposed/CONTRIBUTING.md',tofile='before/CONTRIBUTING.md')).encode())
t={'schema':'src06-system-report-cohort-publication-template40.v1','status':'WAITING_FOR_ROOT_REPORT_ONLY_EXECUTION_AND_ACCEPTED_REVIEW','base_HEAD':m['base_HEAD'],'publisher_Source':ref(NEW),'producer':ref(mp),'complete_plan':m['complete_final_compiler_Source_plan'],'independent_peer':m['independent_full_semantic_peer'],'accepted_parent_review':m['accepted41_production_actual_review'],'accepted_parent_plan':m['prior_complete_compiler_Source_plan'],'previous_checkpoint':previous,'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-system-report-cohort-actual-review-40/review.json','launcher_Source':ref(D/'launch-system-report-cohort-Root-40.py'),'literal_helper_Source':ref(D/'review-meter-final-predefined-Root-01.py'),'finite_archive_inputs':list(finite.values()),'finite_archive_scope':'Current7 test-only Sources/custody/strict471 projection, actual Native39 raw3MB and Native full-function unit6MB, finite direct producers/peers/build compile/link receipts and observed DLL path+hash proof. No recursive ZIP, full environment, provider/exe/core/map or old20MBAirfixture.','contributing_change':{'before':conbefore,'after':conafter,'forward_diff':conforward,'inverse_diff':coninverse},'summary_template':{'A':'14/54','B':'14/64','gate_changes':False,'tolerance_policy_changes':False,'report_only_existing_target':True,'engine_origin_report_calls':306,'separate_Native_full_function_unit_input_variants':165,'total_report_function_calls':471,'report_method_counts':m['report_method_counts'],'all_observed_output_and_consumed_readonly_bits_exact':True,'eight_thermal_classifications_have_nonzero_Source_Native_pairs':True,'scope':'Normal controlled PurchasedAir report domain with primary/DSOA/distribution0. TargetVoz/TimeBelow/TimeAt nonzero and other positive report children remain unexercised. No all-case/full-engine/card completion claim.','production_scope':'Actual41 production5352 proof is inherited after test/feature exclusion; historical CLI did not execute current test-only compiler snapshot.','unchanged_original_Air_cohort_reexecuted':False,'new_test_bodies':0,'existing_cohort_body_extended':1},'doc_appends':{'cards/SRC-06.md':'기존 프로세스 메인 코호트의 보고 전용 선택으로 실제 엔진 306회와 전체 Native 함수의 별도 입력 변형 165회, 총 471회 보고 호출을 비트 단위로 대조했습니다. 비영 부하 8분류와 인접 이진64 경계를 포함하며, 기존 예측·보정 1,168쌍은 수정 없이 이번 실행에서 제외했습니다. 양의 1차 공조·DSOA 및 전체 B 완료는 주장하지 않습니다.','CHECKLIST.md':'보고 전용 단일 코호트에 471회 Native 대조를 통합했습니다. 실행 범위 선택은 CONTRIBUTING.md에 정리했으며 카드·게이트 수는 유지합니다.','STATE_CONTRACTS.md':'실제 입력 getter가 만든 Config·List·물리 Node와 기존 수요·공기·보고·누적 사전정의 소유자에 관측된 함수 진입 피연산자만 복원합니다. 보고 20항목·시설 7항목·요약 7항목·사전정의 24항목 및 소비된 읽기값을 대조하며, 엔진 수명과 매번 새로 생성되는 Native 단위 입력의 주소 수명을 구분합니다.'}}
print(json.dumps({'publisher':ref(NEW),'template':dump('publication-template.json',t),'finite_inputs':len(finite),'status':t['status']}))

from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OLD=D/'source-system-report-cohort-draft-Audit-40-02';O=D/'source-system-report-cohort-draft-Audit-40-03'
assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];assert ref(p)['sha256']==x['sha256'];return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,x):return save(n,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
def fixture(p):
 s=p.read_text(encoding='utf-8');m=re.search(r'r(#+)"(.*)"\1;',s,re.S);assert m;return json.loads(m[2])
oldp=OLD/'draft.json';assert ref(oldp)['sha256']=='8853c6160458770cb0d42236a76380ce05314f996259c992e9c03ea0e22cb93a';old=json.loads(oldp.read_bytes())
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
F='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/'
old_air=R/F/'fixtures/native_prediction_b.rs';air=fixture(old_air)
files=[];changes=[];corrections=[]
for i,row in enumerate(old['files'],1):
 name=row['canonical_path'];before=auth(row['before']).read_bytes();previous=auth(row['proposed']).read_bytes();proposed=previous;s=previous.decode()
 if name.endswith('/native_cohort/report_cohort.rs'):
  s=replace(s,'    let original:Value=serde_json::from_str(NATIVE_PREDICTION_COHORT_JSON)?;\n    let mut input=input(&original)?;','    let mut input=input(&fixture)?;')
  s=replace(s,'member(&original,"raw")','member(&fixture,"raw")')
  s=replace(s,'        let identity_scope=format!("{kind}:{}",count(member(clock,"state_address")?)?);','''        // Engine calls share one real state lifetime. Each full Native unit call
        // constructs a fresh EnergyPlusData, even if its allocator reuses an address.
        let identity_scope=if kind=="engine" {
            format!("engine:{}",count(member(clock,"state_address")?)?)
        } else {
            format!("native-unit:{method}:{}",integer(member(entry,"invocation_ordinal")?)?)
        };''')
  s=replace(s,'fn check_node(equipment:&OrdinaryEquipment,raw:&Value,supply:bool,context:&str)->Result {','fn check_node(equipment:&OrdinaryEquipment,raw:&Value,supply:bool,context:&str,ids:&mut BTreeMap<(String,usize),usize>)->Result {')
  s=replace(s,'    if supply{assert_real(*n.mass_flow_rate','    bind(ids,"Node",value,std::ptr::from_ref(n.temperature) as usize)?;\n    if supply{assert_real(*n.mass_flow_rate')
  s=replace(s,'fn check_units(equipment:&OrdinaryEquipment,zone:&Value,context:&str)->Result {','fn check_units(equipment:&OrdinaryEquipment,zone:&Value,context:&str,ids:&mut BTreeMap<(String,usize),usize>)->Result {')
  s=replace(s,'        check_reals!(u,v,context,','        bind(ids,"PurchasedAir",v,std::ptr::from_ref(u) as usize)?;\n        check_reals!(u,v,context,')
  s=replace(s,'check_node(equipment,n,true,context)?','check_node(equipment,n,true,context,ids)?')
  s=replace(s,'check_node(equipment,n,false,context)?','check_node(equipment,n,false,context,ids)?')
  s=replace(s,'                    let values=reports.native_report_cohort_row(number)?;let expected=row_value(member(z,"report")?)?;','''                    let values=reports.native_report_cohort_row(number)?;let expected=row_value(member(z,"report")?)?;
                    bind(identities,"ZoneVent",expected,reports.native_report_cohort_row_address(number)?)?;''')
  s=replace(s,'                assert_real(d.base.total_output_required,member(member(z,"demand")?,"TotalOutputRequired")?,','                bind(identities,"Demand",member(z,"demand")?,std::ptr::from_ref(d) as usize)?;\n                assert_real(d.base.total_output_required,member(member(z,"demand")?,"TotalOutputRequired")?,')
  s=replace(s,'                assert_eq!(actual_zone.name,text(member(raw_zone,"Name")?)?);','                bind(identities,"Zone",raw_zone,std::ptr::from_ref(actual_zone) as usize)?;\n                assert_eq!(actual_zone.name,text(member(raw_zone,"Name")?)?);')
  s=replace(s,'                check_reals!(actual_air_report,member(z,"ZnAirRpt")?,','                bind(identities,"ZnAirRpt",member(z,"ZnAirRpt")?,std::ptr::from_ref(actual_air_report) as usize)?;\n                check_reals!(actual_air_report,member(z,"ZnAirRpt")?,')
  s=replace(s,'                assert_eq!(predef.is_occupied,','                bind(identities,"Predef",raw,std::ptr::from_ref(predef) as usize)?;\n                assert_eq!(predef.is_occupied,')
  s=replace(s,'                assert_real(a.air.mat,member(raw,"MAT")?,','                bind(identities,"AirHB",raw,std::ptr::from_ref(a) as usize)?;\n                assert_real(a.air.mat,member(raw,"MAT")?,')
  s=replace(s,'                check_units(&equipment,z,&context)?;','                check_units(&equipment,z,&context,identities)?;')
  s=replace(s,'assert!(energy>0 && vent>0 && identity_groups.values().all(|ids|ids.len()>1));','assert!(energy>0 && vent>0 && variants>0 && identity_groups.values().all(|ids|ids.len()>1),"genuine nonzero/boundary Native unit variants are required before report-cohort PASS");')
  assert 'NATIVE_PREDICTION_COHORT_JSON' not in s
  proposed=s.encode()
 elif name.endswith('/ordinary_equipment.rs'):
  a='''        if let Some(v)=mass_flow_rate {row.mass_flow_rate=v;}
        Ok(std::ptr::from_ref(row) as usize)'''
  b='''        if let Some(v)=mass_flow_rate {row.mass_flow_rate=v;}
        // A stable real field identifies this physical Node through the borrowed view.
        Ok(std::ptr::from_ref(&row.temperature) as usize)'''
  proposed=replace(s,a,b).encode()
 elif name.endswith('/ordinary_system_reports.rs'):
  a='''    pub(crate) fn native_report_cohort_row(&self,number:i32) -> Result<[f64;20],Error> {'''
  b='''    pub(crate) fn native_report_cohort_row_address(&self,number:i32) -> Result<usize,Error> {
        let row=self.zone_vent_rep_vars.as_ref().and_then(|rows|rows.get(at(number).ok()?)).ok_or(Error::Unavailable("report cohort same ZoneVent address"))?;
        Ok(std::ptr::from_ref(row) as usize)
    }
'''+a
  proposed=replace(s,a,b).encode()
 elif name.endswith('/fixtures/native_system_report_b.rs'):
  x=fixture(auth(row['proposed']));old_cases=json.dumps(x['cases'],sort_keys=True)
  for key in ['definitions','raw','object_order']:x[key]=air[key]
  x['provenance']['genuine_raw_input_setup_projection']={'source':ref(old_air),'keys':['definitions','raw','object_order'],'semantics':'Whole exact original admitted raw family/schema/order data, no Air case data or numerical expectations. Report-only path parses only this compact fixture.'}
  names={}
  for case in x['cases']:
   if case['method']=='ReportVentilationLoads':
    for z in case['entry']['state']['zones']:
     n=z['index'];name_=z['zone']['Name'];assert names.get(n,name_)==name_;names[n]=name_
     exit_z=next(v for v in case['expected_exit']['state']['zones'] if v['index']==n);assert exit_z['zone']['Name']==name_
  assert x['zone_names']==[{'index':i,'name':n} for i,n in sorted(names.items())]
  assert old_cases==json.dumps(x['cases'],sort_keys=True)
  proposed=('// Test-only complete genuine Native report entries/exits. No production reads.\nconst NATIVE_SYSTEM_REPORT_COHORT_JSON: &str = r###"'+json.dumps(x,ensure_ascii=False,separators=(',',':'))+'"###;\n').encode()
 if proposed!=previous:
  changes.append(name)
  correction=''.join(difflib.unified_diff(previous.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='scaffold02/'+name,tofile='scaffold03/'+name))
  assert ns['diff_apply'](previous,correction)==proposed
  corrections.append({'canonical_path':name,'previous':row['proposed'],'proposed':save('proposed/'+name,proposed),'literal_correction':save(f'corrections/{i:02}.diff',correction.encode())})
 forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name));inverse=''.join(difflib.unified_diff(proposed.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 assert ns['diff_apply'](before,forward)==proposed and ns['diff_apply'](proposed,inverse)==before
 whole=save('proposed/'+name,proposed);p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',whole['path']],capture_output=True);assert p.returncode==0,(name,p.stderr)
 files.append({'canonical_path':name,'before_absent':row['before_absent'],'before':save('before/'+name,before),'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}.forward.diff',forward.encode()),'inverse_diff':save(f'diffs/{i:02}.inverse.diff',inverse.encode()),'literal_forward_inverse_exact':True,'Source_only_parse':{'exit_code':0,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':save(f'parse/{i:02}.stderr',p.stderr)}})
 assert proposed.count(b'#[test]')==before.count(b'#[test]')
assert len(changes)==4
assert auth(next(x for x in files if x['canonical_path']==F+'native_cohort.rs')['proposed']).read_bytes()==auth(next(x for x in old['files'] if x['canonical_path']==F+'native_cohort.rs')['proposed']).read_bytes()
out=dict(old);out.update({'schema':'src06-system-report-cohort40-engine-origin-scaffold03.v1','author_Source':ref(Path(__file__)),'previous_scaffold':ref(oldp),'files':files,'self_review_successor':corrections,'selected_sources':7,'existing_sources':5,'new_sources':2,'literal_applications':14,'fresh_syntax_parses':7,'compact_raw_setup_exact_source':ref(old_air),'scaffold_only_rejects_PASS_without_true_Native_unit_variants':True,'owner_address_qualification':'Engine cases share captured state-address lifetime; each genuine full-Native-unit invocation has a separate method/invocation scope even if allocator reuses addresses. Physical Node/unit/report and other observed row addresses are checked before and after each actual Source report call. No address equality across languages or fresh Native lifetimes.','status':'FROZEN ENGINE-ORIGIN SCAFFOLD03; Native unit outputs/variant projection and final semantic/API/privacy/compiler-parent peer pending. This scaffold deliberately rejects PASS because native_unit_variants remains0. NO Cargo/main/test/Native execution.'})
print(json.dumps(dump('draft.json',out)))

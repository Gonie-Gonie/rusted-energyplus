"""ROOT ONLY: read one actual report-only result and exact complete compiler inputs."""
from pathlib import Path
from collections import Counter
import hashlib,json,struct,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-source-system-report-cohort-actual-review-40-02'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
def auth(n,sha):
 p=D/n;r=ref(p);assert r['sha256']==sha;return r,json.loads(checked(r))
assert len(sys.argv)==3 and not O.exists()
mr,m=auth('source-system-report-cohort-held-Audit-40-02/manifest.json','970cc54e3b740597a62d2ac7207ab6a7e3c718c9609a6cfdad80fec709fb1460')
ar,a=auth('Root-system-report-cohort-application-40-02/receipt.json',sys.argv[1]);rr,r=auth('canonical-source-system-report-cohort-Root-40-02/receipt.json',sys.argv[2])
assert a['accepted'] and not a['findings'] and a['producer']==mr and r['exit_code']==0 and r['launch_error'] is None and r['source_bytes_match_before_and_after'] and r['command']==a['command']==m['command']
assert r['repository_before']==r['repository_after'] and r['repository_before']['head']==a['base_HEAD']==m['base_HEAD']=='e47c117f313281428d6c928c4007e580b557a4fa'
out=checked(r['stdout']).decode('utf-8');err=checked(r['stderr']).decode('utf-8');assert out.splitlines()==['running 1 native system-report cohort on process main','cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; energy entries=153; ventilation entries=318; named Native-unit variants=165'] and 'error[' not in err
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};actual={v['historical_path']:v for v in json.loads(checked(r['source_snapshot']))['files']};assert len(rows)==4510 and sum(n.endswith('.rs') for n in rows)==4497 and set(rows)==set(actual)
for n,v in rows.items():
 b=checked(v['source']);assert b==checked(actual[n]['archive'])==(R/n).read_bytes() and hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes']==actual[n]['size_bytes'],n
selected={f['canonical_path']:f for f in m['files']};assert len(selected)==len(a['selected'])==7
for n,f in selected.items():assert (R/n).read_bytes()==checked(f['proposed'])==checked(a['selected'][n]['proposed'])
F='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/'
assert checked(selected[F+'native_cohort.rs']['proposed']).startswith(checked(selected[F+'native_cohort.rs']['before']));checked(m['old_air_fixture_whole_unchanged'])
fixture=json.loads(checked(selected[F+'fixtures/native_system_report_b.rs']['proposed']).split(b'r###"',1)[1].rsplit(b'"###;',1)[0]);assert len(fixture['cases'])==m['total_report_cases']==471 and fixture['engine_cases']==306 and fixture['native_unit_variants']==165
counts=Counter();origins=Counter();nonzero=Counter()
for case in fixture['cases']:
 counts[case['method']]+=1;origins[case['origin']['kind']]+=1
 if case['origin']['kind']=='native-unit-variant':
  for n,v in case['expected_exit']['state']['zones'][0]['report']['value'].items():
   if n!='address' and struct.unpack('>d',bytes.fromhex(v))[0]!=0.0:nonzero[n]+=1
assert dict(counts)==m['report_method_counts']=={'ReportSystemEnergyUse':153,'ReportVentilationLoads':318} and dict(origins)=={'engine':306,'native-unit-variant':165}
run=json.loads(checked(m['actual_Native_unit_run']));assert run['accepted'] and run['exit_code']==0 and not run['findings'] and run['actual_three_GNU_DLL_binding_proved']
assert all(nonzero[n]==v>0 for n,v in run['admission_and_nonzero_coverage']['classification8_nonzero_counts'].items())
pr=m['independent_full_semantic_peer'];peer=json.loads(checked(pr));assert a['independent_peer']==pr and peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft']
correction_peer=json.loads(checked(m['independent_correction_peer']));assert correction_peer['accepted'] and not correction_peer['findings'] and correction_peer['reviewed_draft']==m['raw_deadband_correction']
assert a['independent_correction_peer']==m['independent_correction_peer'] and a['actual_rewrites']==1 and a['other6_whole_exact_not_rewritten']
failed_refs=m['preserved_failed_focused_executions'];assert len(failed_refs)==1
for row in failed_refs:
 failed=json.loads(checked(row));assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after'] and b'"same DeadBand"' in checked(failed['stderr'])
 checked(failed['stdout']);checked(failed['source_snapshot'])
production=json.loads(checked(m['accepted41_production_actual_review']));assert production['accepted'] and not production['findings'] and production['original_tolerance_RMSE_5352_proof_transferred'] and a['production_numerical_bodies_unchanged_after_cfg_exclusion']
O.mkdir();result={'schema':'src06-system-report-Native-paired-actual-cohort40-02.v1','accepted':True,'findings':[],'producer':mr,'application':ar,'independent_full_Source_fixture_peer':pr,'complete_compiler_plan':m['complete_final_compiler_Source_plan'],'actual_focused_test':rr,'actual_snapshot':r['source_snapshot'],'all4510_inputs_exact_final_plan_and_live':True,'Rust_sources':4497,'selected_Source_files':7,'existing_Source_files':5,'new_Source_files':2,'new_test_bodies':0,'existing_cohort_body_extended':1,'successful_main_report_cohort_executions':1,'actual_executed_test_bodies':2,'failed_focused_execution_count':1,'preserved_failed_focused_executions':failed_refs,'total_source_focused_invocations':2,'original_application':m['original_application'],'original_producer':m['original_producer'],'raw_deadband_correction':m['raw_deadband_correction'],'independent_correction_peer':m['independent_correction_peer'],'engine_origin_cases':306,'engine_method_counts':m['engine_method_counts'],'explicit_Native_unit_input_variants':165,'total_actual_report_function_calls':471,'actual_report_method_counts':dict(counts),'all20_zone_report_7facility_7summary_24predef_and_consumed_readonly_fields_raw_bits_asserted':True,'same_real_owner_addresses_checked_within_true_lifetimes':True,'Native_thermal8_nonzero_counts':run['admission_and_nonzero_coverage']['classification8_nonzero_counts'],'Native_unit_coverage':run['admission_and_nonzero_coverage'],'all8_Source_nonzero_classifications_asserted':True,'actual_Native_unit_run':m['actual_Native_unit_run'],'actual_Native_unit_build':m['actual_Native_unit_build'],'actual_Native_engine_capture':m['actual_Native_capture'],'finite_Native_engine_observation':m['finite_Native_engine_observation'],'finite_Native_unit_full_output':m['finite_Native_unit_full_output'],'strict_fixture_projection_proof':m['strict_fixture_projection_proof'],'Source_fixture_projector':m['Source_fixture_projector'],'old_Air_helper_prefix_fixture_whole_unchanged':True,'unchanged_predictor_and_corrector_cases_reexecuted_this_checkpoint':0,'production_numerical_bodies_unchanged':True,'inherited_production_integration':m['accepted41_production_actual_review'],'inherited_actual_B':production['actual_B'],'inherited_actual_A24':production['actual_A24'],'historical_CLI_compiler_snapshot_is_current_test_snapshot':False,'final_CLI_or_Native_rebuilt_or_executed_by_test_checker':False,'actual_test_stdout':r['stdout'],'actual_test_stderr':r['stderr'],'test_result':'PASS after correcting one test-entry allocation omission: preserve first failed invocation and one successful invocation. The same existing safe process-main target --report-only executes all306 genuine engine-origin reports once plus165 separate genuine full-Native-function unit input variants. Every observed write and consumed readonly value matches exact raw binary64, eight thermal classifications include actual nonzero values. Original Air cohort is unchanged and not rerun.','qualifications':m['qualifications'][:-1]+['Positive primary/DSOA/distribution and nonzero TargetVoz/TimeBelow/TimeAt remain unexercised; no all-case/full-port/card completion. Production41 CLI evidence is inherited after test/feature exclusion, not reexecuted with this test-only snapshot.'],'validation_policy':m['validation_policy'],'author_Source':ref(Path(__file__))}
p=O/'review.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

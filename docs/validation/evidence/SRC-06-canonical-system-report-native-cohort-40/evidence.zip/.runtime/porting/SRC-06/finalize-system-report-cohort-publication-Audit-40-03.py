"""Private immutable READY metadata after actual Root report-cohort success."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'system-report-cohort-publication-READY-Audit-40-03';assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,v):return save(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
oldpub=D/'publish-system-report-cohort-checkpoint-Audit-40-02.py';newpub=D/'publish-system-report-cohort-checkpoint-Audit-40-03.py';assert not newpub.exists() and ref(oldpub)['sha256']=='4d0edaeec107e576c542289aef0e284d98b898c0cb7293b9a1d40cf3f4a78ea8'
before=oldpub.read_text(encoding='utf-8');after=before
a="system-report-cohort-publication-readback-Audit-40-02'";b="system-report-cohort-publication-readback-Audit-40-03'";assert after.count(a)==1;after=after.replace(a,b,1)
a='Seven test-only Sources and one existing safe-main target report-only invocation.';b='Seven test-only Sources and one existing safe-main target; two actual report-only invocations (first input-setup failure retained, second successful 471 calls).';assert after.count(a)==1;after=after.replace(a,b,1)
ast.parse(after);newpub.write_text(after,encoding='utf-8',newline='')
forward=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='reviewed-publisher40-02',tofile='scope-wording-publisher40-03'));inverse=''.join(difflib.unified_diff(after.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='scope-wording-publisher40-03',tofile='reviewed-publisher40-02'))
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns);assert ns['diff_apply'](oldpub.read_bytes(),forward)==newpub.read_bytes() and ns['diff_apply'](newpub.read_bytes(),inverse)==oldpub.read_bytes()
fr=save('publisher-forward.diff',forward.encode());ir=save('publisher-inverse.diff',inverse.encode())
actualp=D/'Root-source-system-report-cohort-actual-review-40-02/review.json';assert ref(actualp)['sha256']=='fb60c1444896085f7f0a65aefc38221919931235343844010700d86934da95e7';actual=json.loads(actualp.read_bytes());assert actual['accepted'] and not actual['findings'] and actual['actual_executed_test_bodies']==actual['total_source_focused_invocations']==2 and actual['successful_main_report_cohort_executions']==actual['failed_focused_execution_count']==1
assert actual['total_actual_report_function_calls']==471 and actual['all8_Source_nonzero_classifications_asserted'] and actual['all4510_inputs_exact_final_plan_and_live']
tp=D/'system-report-cohort-publication-prepared-Audit-40-02/publication-template.json';assert ref(tp)['sha256']=='106fd55853ff66464be5cd4c7b29ff60aa71b9090eda00c455c8a7d71194db71';t=json.loads(tp.read_bytes());oldtemplate=tp.read_bytes();assert actual['producer']==t['producer'] and actual['complete_compiler_plan']==t['complete_plan']
t.update(status='HELD_READY_FOR_ROOT_REPORT_COHORT40_02_AND_FULL_READ',publisher_Source=ref(newpub),accepted_actual_review=ref(actualp),actual_focused_test=actual['actual_focused_test'],actual_application=actual['application'])
finite={v['path']:v for v in t['finite_archive_inputs']}
for v in [ref(newpub),ref(oldpub),ref(Path(__file__)),ref(tp),fr,ir,ref(actualp),actual['actual_focused_test'],actual['application'],actual['author_Source']]:
 p=checked(v);finite[v['path']]=ref(p)
t['finite_archive_inputs']=list(finite.values());t['summary_template'].update(actual_test_bodies_executed=2,successful_report_only_invocations=1,failed_report_only_invocations=1,total_source_focused_invocations=2,first_failed_invocation_preserved=True,Source471_report_function_calls_exact=True,all8_thermal_classifications_nonzero_Native_pairs=True)
newtemplate=(json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode();tr=save('publication-template.json',newtemplate)
tf=''.join(difflib.unified_diff(oldtemplate.decode().splitlines(keepends=True),newtemplate.decode().splitlines(keepends=True),fromfile='waiting-template40-02',tofile='ready-template40-03'));ti=''.join(difflib.unified_diff(newtemplate.decode().splitlines(keepends=True),oldtemplate.decode().splitlines(keepends=True),fromfile='ready-template40-03',tofile='waiting-template40-02'));assert ns['diff_apply'](oldtemplate,tf)==newtemplate and ns['diff_apply'](newtemplate,ti)==oldtemplate
save('template-forward.diff',tf.encode());save('template-inverse.diff',ti.encode())
assert (R/'CONTRIBUTING.md').read_bytes()==checked(t['contributing_change']['before']).read_bytes()
print(json.dumps({'publisher':ref(newpub),'template':tr,'actual':ref(actualp),'publisher_literal_apps':2,'template_literal_apps':2,'finite_inputs':len(finite),'canonical_publication_executed':False}))

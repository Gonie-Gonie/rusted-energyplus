"""Root-only original-core unit execution/readback; no engine, build, Cargo or FP changes."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import argparse,ast,ctypes,hashlib,json,math,os,re,struct,subprocess,time
from ctypes import wintypes
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
M=D/'system-report-native-unit-run-Root-40'
def need(ok,why):
 if not ok:raise ValueError(why)
def ref(p):
 p=p.resolve()
 with p.open('rb') as s:h=hashlib.file_digest(s,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(row):
 p=(R/row['path']).resolve();a=ref(p);need(a['sha256']==row['sha256'] and a['bytes']==row.get('bytes',a['bytes']),'Changed '+row['path']);return p
def read(p):return json.loads(p.read_bytes())
def write(name,obj):
 p=M/name
 with p.open('xb') as f:f.write((json.dumps(obj,indent=2)+'\n').encode())
 return ref(p)
def number(v):
 need(set(v)=={'value_bits'} and re.fullmatch('[0-9a-f]{16}',v['value_bits']) is not None,'Raw finite scalar required')
 x=struct.unpack('>d',bytes.fromhex(v['value_bits']))[0];need(math.isfinite(x),'Nonfinite unit scalar');return x
def strip(v):
 if isinstance(v,dict):return {k:strip(x) for k,x in v.items() if k not in ('address','owner_address','manager_address','state_address')}
 if isinstance(v,list):return [strip(x) for x in v]
 return v
def validate_bits(v):
 if isinstance(v,dict):
  if 'value_bits' in v:number(v);return 1
  return sum(validate_bits(x) for x in v.values())
 if isinstance(v,list):return sum(validate_bits(x) for x in v)
 need(not isinstance(v,float),'No floating JSON transport');return 0
def main(args):
 need(args.run_only and not M.exists(),'Root run flag/fresh metadata required')
 path,digest=args.build.rsplit('#',1);bp=(R/path).resolve();need(ref(bp)['sha256']==digest,'Actual unit build SHA')
 b=read(bp);need(b['accepted'] and not b['findings'] and b['Native_bytes_match_before_and_after'],'Actual unit build0/custody required')
 need(b['original_core_SystemReports_member_count']>0 and not b['forbidden_derived_object_witnesses'],'Genuine original core only')
 dp=checked(b['reviewed_draft']);p=read(dp);binary=checked(b['binary']);raw=checked(p['actual_capture_raw']);capture=read(checked(p['actual_engine_capture39']))
 frozen=read(checked(p['frozen_environment']));need(frozen['accepted'],'Accepted frozen environment');environment=frozen['environment']
 env={k.casefold():v for k,v in environment.items()};need(len(env)==len(environment),'No env collisions');systemroot=Path(env['systemroot'])
 cp=D/'capture-system-report-native-Peer-39.py';need(ref(cp)['sha256']=='f33991e09067b062d967365d0875fc44f057344722dfe18f9cdfe7ee3ce2553b','Authenticated read-only PID query provider')
 tree=ast.parse(cp.read_bytes());classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ChildModules'];need(len(classes)==1,'Single inherited PSAPI class')
 ns={'need':need,'os':os,'ctypes':ctypes,'wintypes':wintypes,'Path':Path};exec(compile(ast.Module(body=classes,type_ignores=[]),'<whole-unchanged-Native39-child-module-query>','exec'),ns)
 output=Path(p['fresh_unit_directory'])/'unit-output.json';need(not output.exists(),'Fresh unit output')
 protected=[ref(bp),b['reviewed_draft'],b['independent_Source_peer'],b['binary'],ref(Path(__file__)),p['main_Source'],p['accepted_observer_included_whole_unchanged'],p['observer_field_ledger'],p['actual_engine_capture39'],p['actual_capture_raw'],p['frozen_environment'],ref(cp),*p['pinned_runtime_DLLs'],ref(systemroot/'System32/kernel32.dll'),ref(systemroot/'System32/psapi.dll')]
 protected=list({r['path']:r for r in protected}.values());before=[ref(checked(r)) for r in protected]
 expected={Path(r['path']).name.casefold():checked(r) for r in p['pinned_runtime_DLLs']};need(len(expected)==3,'Three GNU DLLs')
 M.mkdir();before_ref=write('Native-before.json',before)
 command=[str(binary),'--capture',str(raw),'--output',str(output)];start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();process=None;code=None;error=None;query=None;modules=None;query_errors=[];attempts=0
 with (M/'stdout.log').open('xb') as out,(M/'stderr.log').open('xb') as err:
  try:process=subprocess.Popen(command,cwd=R,env=environment,stdout=out,stderr=err)
  except OSError as e:error={'type':type(e).__name__,'message':str(e)}
  if process is not None:
   while process.poll() is None and modules is None:
    attempts+=1
    try:
     if query is None:query=ns['ChildModules'](process.pid,systemroot)
     rows=query.snapshot()
     if set(expected).issubset({Path(r['actual_path']).name.casefold() for r in rows}):modules=rows
    except (OSError,ValueError) as e:
     if len(query_errors)<16:query_errors.append({'type':type(e).__name__,'message':str(e)})
    if modules is None:time.sleep(0.01)
   code=process.wait()
 if query is not None:query.close()
 elapsed=time.monotonic()-tick;findings=[];bindings=[]
 if modules is None:findings.append('Actual child three GNU modules were not observed')
 else:
  for name,path in expected.items():
   rows=[r for r in modules if Path(r['actual_path']).name.casefold()==name]
   need(len(rows)==1 and Path(rows[0]['actual_path']).resolve()==path,'Actual GNU DLL binding differs')
   bindings.append({'module':rows[0],'actual_file':ref(path)})
 if code!=0 or error is not None:findings.append('Native unit child did not exit0')
 after=[ref(checked(r)) for r in protected];need(after==before,'Runtime files changed');after_ref=write('Native-after.json',after)
 modules_ref=write('actual-child-modules.json',dict(child_PID=process.pid if process else None,attempts=attempts,first16_query_errors=query_errors,all_observed_modules=modules,three_GNU_bindings=bindings))
 report=None
 if code==0 and not findings:
  result=read(output);need(result['schema']=='src06-system-report-full-Native-unit.v1' and result['accepted'] and not result['findings'],'Complete genuine unit result required')
  need(result['all_actual_base_exit_bits_asserted_before_variants'],'All genuine bases first')
  actual=read(raw);entries={(e['method'],e['invocation_ordinal']):e for e in actual['events'] if e['phase']=='entry'};exits={(e['method'],e['invocation_ordinal']):e for e in actual['events'] if e['phase']=='normal_exit'}
  bases=[];variants=[];scalar_count=0;nonzero=Counter();conditions=Counter();previous_entry={m:0 for m in ('ReportSystemEnergyUse','ReportVentilationLoads')};event_ordinal=0
  ledger=read(checked(p['observer_field_ledger']))
  for case in result['cases']:
   scalar_count+=validate_bits(case);origin=case['origin'];entry=case['entry'];exit=case['expected_exit'];method=entry['method']
   previous_entry[method]+=1;need(entry['invocation_ordinal']==exit['invocation_ordinal']==previous_entry[method],'Contiguous direct method calls')
   need(entry['event_ordinal']==event_ordinal+1 and exit['event_ordinal']==event_ordinal+2,'Complete case order');event_ordinal+=2
   need(entry['phase']=='entry' and exit['phase']=='normal_exit' and entry['method']==exit['method'],'Full function entry/normal exit')
   if origin['kind']=='actual_engine_entry_replay':
    need(not variants,'Every genuine engine base before variants');need(not case['input_overrides'] and case['actual_captured_exit_bit_asserted'],'Base has no unit overrides')
    key=(origin['method'],origin['actual_invocation']);need(key in entries and key in exits,'Genuine base identity')
    for field in ('clock','state'):
     need(strip(entry[field])==strip(entries[key][field]) and strip(exit[field])==strip(exits[key][field]),'Independent complete actual baseline bit/shape check')
    bases.append(key)
   else:
    need(origin['kind']=='explicit_Native_full_function_unit_input' and not case['actual_captured_exit_bit_asserted'],'Variant origin explicit')
    base_key=(origin['base_actual_method'],origin['base_actual_invocation']);need(base_key in entries,'Explicit variant actual base identity')
    reconstructed=json.loads(json.dumps(entries[base_key]))
    for pointer,value in case['input_overrides'].items():
     tokens=[t.replace('~1','/').replace('~0','~') for t in pointer.split('/')[1:]];need(pointer.startswith('/state/'),'Only explicit retained state INPUT override')
     parent=reconstructed
     for token in tokens[:-1]:parent=parent[int(token)] if isinstance(parent,list) else parent[token]
     if isinstance(parent,list):parent[int(tokens[-1])]=value
     else:
      need(tokens[-1] in parent,'No fabricated input member');parent[tokens[-1]]=value
    need(strip(entry['state'])==strip(reconstructed['state']) and strip(entry['clock'])==strip(reconstructed['clock']),'Independent complete base-plus-explicit-unit-input reconstruction')
    variants.append(origin['name']);conditions['explicit_variants']+=1
    zone=exit['state']['zones'][0];reportvars=zone['report']['value'];pre=zone['predefined']['value']
    for name in ledger['zone_report20']:
     if number(reportvars[name])!=0:nonzero[name]+=1
    conditions['occupied']+=pre['isOccupied'];conditions['unoccupied']+=not pre['isOccupied']
    conditions['OA_mass_positive']+=number(reportvars['OAMassFlow'])>0
    conditions['std_density_volume_positive']+=number(reportvars['OAVolStdRho'])>0
    conditions['current_density_volume_positive']+=number(reportvars['OAVolCrntRho'])>0
    conditions['mechanical_ACH_positive']+=number(reportvars['MechACH'])>0
    conditions['minima_actual_bits_changed']+=any(entry['state']['zones'][0]['predefined']['value'][n]!=pre[n] for n in ('MechVentVolMin','InfilVolMin','SimpVentVolMin'))
  need(len(bases)==len(set(bases))==len(entries)==len(exits) and set(bases)==set(entries),'Every actual base once')
  need(len(variants)==len(set(variants))==result['named_variant_count']>0,'Every named unit variant once')
  need(all(nonzero[n]>0 for n in ledger['zone_report20'][:8]),'Every thermal classification needs genuine nonzero Native output')
  need(all(conditions[n]>0 for n in ('occupied','unoccupied','OA_mass_positive','std_density_volume_positive','current_density_volume_positive','mechanical_ACH_positive','minima_actual_bits_changed')),'Nonzero ventilation/occupied minima coverage')
  need(len(result['near_threshold_input_searches'])==2,'Positive and negative full-function threshold search')
  for s in result['near_threshold_input_searches']:
   low=s['zero_classification_mass_bits']['value_bits'];high=s['nonzero_classification_mass_bits']['value_bits']
   need(int(high,16)==int(low,16)+1 and s['positive_binary64_bit_distance']==1 and s['full_function_probe_count']>2,'Adjacent positive binary64 input boundary')
  report=dict(actual_engine_bases=len(bases),base_counts=result['actual_engine_base_counts'],explicit_variants=len(variants),raw_finite_binary64_transports=scalar_count,
   classification8_nonzero_counts={n:nonzero[n] for n in ledger['zone_report20'][:8]},all20_nonzero_counts={n:nonzero[n] for n in ledger['zone_report20']},conditions=dict(conditions),near_threshold_input_searches=result['near_threshold_input_searches'],
   all_original_actual_engine_base_exits_independently_bit_asserted=True,no_expected_formula_property_or_load_reconstruction=True,
   qualification='Native unit INPUT variants are separate from actual engine cases; positive primary/DSOA/distribution and Source equivalence are not claimed.')
 receipt=dict(schema='src06-system-report-full-Native-unit-run.v1',accepted=code==0 and not findings and report is not None,findings=findings,
  actual_build=ref(bp),reviewed_draft=ref(dp),independent_Source_peer=b['independent_Source_peer'],command=command,cwd=R.as_posix(),child_PID=process.pid if process else None,exit_code=code,launch_error=error,
  started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=elapsed,stdout=ref(M/'stdout.log'),stderr=ref(M/'stderr.log'),Native_before=before_ref,Native_after=after_ref,Native_bytes_match_before_and_after=True,
  actual_child_modules=modules_ref,actual_three_GNU_DLL_binding_proved=len(bindings)==3,full_unit_output=ref(output) if output.exists() else None,
  admission_and_nonzero_coverage=report,original_engine_capture=p['actual_engine_capture39'],original_engine_raw=p['actual_capture_raw'],launcher_Source=ref(Path(__file__)),
  configure_build_engine_Cargo_or_Source_test_executed=False,static_core_runtime_rehash=False,core_original_member_proof_inherited_from_actual_build=b['original_core_SystemReports_first10_witnesses'])
 print(json.dumps(write('receipt.json',receipt)));return 0 if receipt['accepted'] else 1
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--run-only',action='store_true');parser.add_argument('--build',required=True)
 raise SystemExit(main(parser.parse_args()))

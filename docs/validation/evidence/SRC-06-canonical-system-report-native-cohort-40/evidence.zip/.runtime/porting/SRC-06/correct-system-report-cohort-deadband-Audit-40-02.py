"""Restore a genuinely observed input-array allocation missed by the first replay."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-system-report-cohort-deadband-fix-held-Audit-40-02';assert not O.exists()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,v):return save(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
mp=D/'source-system-report-cohort-held-Audit-40/manifest.json';assert ref(mp)['sha256']=='1a14003b55fccf5381cc0ded3e2fa23a55fd8a8eb6f809828803202d7955a220';m=json.loads(mp.read_bytes())
rp=D/'canonical-source-system-report-cohort-Root-40/receipt.json';assert ref(rp)['sha256']=='a40d40d92b92d1c0649c82b718622569b0bcc09637a3bc0f23260b7610b2fb3d';run=json.loads(rp.read_bytes());assert run['exit_code']==1 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
assert b'"same DeadBand"' in checked(run['stderr']).read_bytes() and b'cohort native_controlled_air_cohort ... ok' not in checked(run['stdout']).read_bytes()
name='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/native_cohort/report_cohort.rs';parent=next(f for f in m['files'] if f['canonical_path']==name);before=checked(parent['proposed']).read_bytes();assert (R/name).read_bytes()==before;s=before.decode()
a='''                *controller.demand.deadband_or_setback.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same DeadBand"))?=bool_integer(member(member(z,"DeadBandOrSetback")?,"value")?)?;'''
b='''                // This input array is allocated separately from demand rows in Native2390.
                let deadband=member(z,"DeadBandOrSetback")?;let deadband_size=allocated(deadband)?;
                assert_eq!(deadband_size,model.zones.len());assert_eq!(integer(member(deadband,"index")?)?,number);
                assert_eq!(integer(member(deadband,"lower")?)?,1);assert_eq!(count(member(deadband,"upper")?)?,deadband_size);
                if let Some(rows)=&controller.demand.deadband_or_setback {assert_eq!(rows.len(),deadband_size);}
                else {controller.demand.deadband_or_setback=Some(vec![false;deadband_size]);}
                *controller.demand.deadband_or_setback.as_mut().and_then(|r|r.get_mut(i)).ok_or_else(||invalid("same DeadBand"))?=bool_integer(member(deadband,"value")?)?;'''
assert s.count(a)==1;s=s.replace(a,b,1);after=s.encode();assert after.count(b'#[test]')==before.count(b'#[test]')==0
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
fwd=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),s.splitlines(keepends=True),fromfile='failed40/'+name,tofile='corrected40-02/'+name));inv=''.join(difflib.unified_diff(s.splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='corrected40-02/'+name,tofile='failed40/'+name));assert ns['diff_apply'](before,fwd)==after and ns['diff_apply'](after,inv)==before
snapshotp=checked(run['source_snapshot']);snapshot={f['historical_path']:f for f in json.loads(snapshotp.read_bytes())['files']};planp=checked(m['complete_final_compiler_Source_plan']);plan=json.loads(planp.read_bytes());rows={v['path']:v for v in plan['entries']};assert len(rows)==len(snapshot)==4510 and set(rows)==set(snapshot)
for n,v in rows.items():assert checked(v['source']).read_bytes()==checked(snapshot[n]['archive']).read_bytes()==(R/n).read_bytes()
native=R/'.reference/energyplus-src/26.1.0';authorities=[]
for path,spans in [('src/EnergyPlus/DataZoneEnergyDemands.hh',[(165,180)]),('src/EnergyPlus/ZoneTempPredictorCorrector.cc',[(2380,2392)])]:
 raw=(native/path).read_bytes();assert raw==subprocess.check_output(['git','-C',str(native),'show','6f2e40d10250a105b49966baa24d843711e61048:'+path]);lines=raw.splitlines(keepends=True)
 authorities.append({'Native_path':path,'pinned_Git':'6f2e40d10250a105b49966baa24d843711e61048','whole':save('Native/'+path,raw),'extents':[{'first':a,'last':b,'source':save(f'Native/extents/{Path(path).name}.{a}-{b}.txt',b''.join(lines[a-1:b]))} for a,b in spans]})
sourcep=R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/initialization.rs';context=save('Source-context/initialization.rs',sourcep.read_bytes());assert b'self.demand.deadband_or_setback = Some(vec![false; n]);' in sourcep.read_bytes()
fixturep=next(f['proposed'] for f in m['files'] if f['canonical_path'].endswith('/fixtures/native_system_report_b.rs'));fixture=json.loads(checked(fixturep).read_bytes().split(b'r###"',1)[1].rsplit(b'"###;',1)[0]);shapes=[]
for case in fixture['cases']:
 for z in case['entry']['state']['zones']:
  if not z['config']['value']['IsControlled']:continue
  x=z['DeadBandOrSetback'];assert x['allocated'] and x['size']==1 and x['index']==z['index']==1 and x['lower']==x['upper']==1 and x['value'] in [0,1];shapes.append((case['method'],case['entry']['invocation_ordinal'],x['value']))
assert len(shapes)==471
proposed=save('proposed/'+name,after);parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert parse.returncode==0
files=[{'canonical_path':name,'before_absent':False,'before':save('before/'+name,before),'proposed':proposed,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save('diffs/01.forward.diff',fwd.encode()),'inverse_diff':save('diffs/01.inverse.diff',inv.encode()),'Source_only_parse':{'exit_code':0,'stdout_sha256':hashlib.sha256(parse.stdout).hexdigest(),'stderr':save('parse/01.stderr',parse.stderr)}}]
carry=[]
for f in m['files']:
 if f['canonical_path']!=name:assert checked(f['proposed']).read_bytes()==(R/f['canonical_path']).read_bytes();carry.append({'canonical_path':f['canonical_path'],'proposed':f['proposed'],'whole_unchanged':True})
result={'schema':'src06-system-report-cohort-captured-deadband-allocation-fix40-02.v1','status':'HELD narrow actual-failure fix; independent peer/composite final-plan/Root one-file application pending','base_HEAD':m['base_HEAD'],'original_producer':ref(mp),'original_full_Source_fixture_peer':m['independent_full_semantic_peer'],'failed_actual_focused_test':ref(rp),'actual_failed_snapshot':ref(snapshotp),'prior_complete_compiler_Source_plan':ref(planp),'files':files,'carried6_whole_unchanged':carry,'Native_authorities':authorities,'actual_Source_initialization_context':context,'captured_deadband_shape_proof':{'cases':471,'allocated_size1_lower1_upper1_index1':True,'both_boolean_values_present':sorted({x[2] for x in shapes})},'fixture_whole_unchanged':fixturep,'literal_applications':2,'Source_only_parses':1,'new_test_bodies':0,'production_formula_expected_fixture_assertion_changes':0,'correction_scope':'Restore the genuinely observed allocated extent on SAME existing demand.deadband_or_setback owner before loading each actual incoming captured boolean. Native ctor/dimension2390 false default is not a ready flag or fabricated report input. No report formula, expected value, tolerance, Source production owner or assertion changed.','author_Source':ref(Path(__file__)),'Cargo_or_Native_or_canonical_executed':False}
print(json.dumps(dump('manifest.json',result)))

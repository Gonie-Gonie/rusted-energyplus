"""Read-only A24 proof transfer after genuine B raw ingress/dictionary IO changes.

Requires authenticated actual canonical check and A24 command exit0. No command,
simulation, tests, expected-value injection, or comparison policy changes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'

def ref(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def checked(row):
    path = R / row['path']
    actual = ref(path)
    assert actual['sha256'] == row['sha256'] and actual['bytes'] == row.get('bytes', actual['bytes']), row
    return path

def pairs(rows):
    result = {}
    for key, value in rows:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result

def decode(data):
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda text: (_ for _ in ()).throw(ValueError('nonfinite JSON ' + text)))

def load(path):
    return decode(path.read_bytes())

def auth(path, sha):
    path = R / path
    assert ref(path)['sha256'] == sha, str(path)
    return path, load(path)

def contains_ref(value, expected):
    if isinstance(value, dict):
        return ((value.get('path'), value.get('sha256')) == (expected['path'], expected['sha256'])
                or any(contains_ref(item, expected) for item in value.values()))
    return isinstance(value, list) and any(contains_ref(item, expected) for item in value)

def option(command, name):
    assert command.count(name) == 1
    index = command.index(name)
    assert index + 1 < len(command)
    return command[index + 1]

def same_path(value, expected):
    assert isinstance(value, str) and Path(value).resolve() == expected.resolve(), (value, str(expected))

def typed_metadata(now, old, classification, extension):
    if classification == 'producer version/build':
        return now == old
    if classification == 'actual wall clock':
        pattern = rb'( *)\d{2}:\d{2}:\d{2}(</b></p>)?(\r?\n)?'
    else:
        assert classification == 'actual wall date'
        pattern = rb'( *)\d{4}-\d{2}-\d{2}(\r?\n)?'
        if extension == 'htm' and old.startswith((b'<p>Timestamp: <b>', b'<p>Simulation Timestamp: <b>')):
            pattern = rb'(<p>(?:Simulation )?Timestamp: <b>)\d{4}-\d{2}-\d{2}(\r?\n)?'
    left, right = re.fullmatch(pattern, now), re.fullmatch(pattern, old)
    return left is not None and right is not None and left.groups() == right.groups()

parser = argparse.ArgumentParser(description=__doc__)
for name in ('check-receipt', 'check-sha', 'actual-receipt', 'actual-sha', 'first-b-receipt', 'first-b-sha', 'combined-plan', 'combined-plan-sha', 'combined-review', 'combined-review-sha', 'b-peer', 'b-peer-sha'):
    parser.add_argument('--' + name, required=True)
parser.add_argument('--review-successful-canonical-A24', action='store_true')
parser.add_argument('--artifact-name', default='Peer-canonical-B-ingress-IO-A24-transfer-02')
a = parser.parse_args()
assert a.review_successful_canonical_A24
assert re.fullmatch(r'Peer-canonical-B-ingress-IO-A24-transfer-\d{2}', a.artifact_name)
out = D / a.artifact_name
# Receipt0 and stable same producer guard precede all outcome reads and writes.
check_path, check = auth(a.check_receipt, a.check_sha)
cli_path, cli = auth(a.actual_receipt, a.actual_sha)
for receipt in (check, cli):
    assert receipt['schema'] == 'recorded-porting-command.v1'
    assert receipt['exit_code'] == 0 and receipt['launch_error'] is None
    assert receipt['source_bytes_match_before_and_after'] is True
    same_path(receipt['cwd'], R)
first_B_path, first_B = auth(a.first_b_receipt, a.first_b_sha)
assert first_B['schema'] == 'recorded-porting-command.v1'
assert first_B['exit_code'] == 6 and first_B['launch_error'] is None
assert first_B['source_bytes_match_before_and_after'] is True
same_path(first_B['cwd'], R)
assert option(first_B['command'], '--porting-scope') == 'B'
assert not {'--oracle-baseline', '--compare-oracle'} & set(first_B['command'])
first_B_output = Path(option(first_B['command'], '--output-dir')).resolve()
assert first_B_output.is_relative_to(D.resolve())
assert check['source_snapshot'] == first_B['source_snapshot'] == cli['source_snapshot']
assert '--all-targets' in check['command'] and '--workspace' in check['command']
assert option(cli['command'], '--porting-scope') == 'A'
assert not {'--oracle-baseline', '--compare-oracle'} & set(cli['command'])
source = Path(option(cli['command'], '--output-dir')).resolve()
assert source.is_relative_to(D.resolve()) and source != first_B_output and not out.exists()
plan_path, plan = auth(a.combined_plan, a.combined_plan_sha)
review_path, review = auth(a.combined_review, a.combined_review_sha)
assert ref(plan_path)['sha256'] == '4c6cbcd44d2180f3ea86379c16ed4fe994f79a0ab22af01dced9e3363b8737b0'
assert ref(review_path)['sha256'] == 'c602b6089021db0f2acbc2340cd7c27aba7bcdd3f9978845a2c3f706040c96d1'
assert review['accepted'] is True and review['findings'] == []
assert contains_ref(review, ref(plan_path)), 'combined review must bind exact complete plan'
raw_path, raw = auth('.runtime/porting/SRC-06/ordinary-source-B-raw-ingress-held-Audit-01/manifest.json', 'da19dc653e37e8a6c6249a129c98c84080b44e74b5d407e75b457dad731807c7')
io_path, io_packet = auth('.runtime/porting/SRC-06/dictionary-native-text-mode-held-Root-01/manifest.json', 'cc12ee6af5d90291394b3d616cc8a5bb989e1ee54e468cd0ee0e80dcd817723b')
B_peer_path, B_peer = auth(a.b_peer, a.b_peer_sha)
io_peer_path, io_peer = auth('.runtime/porting/SRC-06/Outer-dictionary-native-text-mode-Source-review-01/review.json', 'ff9478c85b685667272675ffe60e4a4caec03b3c9b2b214d3d81d248a5e88c09')
for accepted, packet in ((B_peer, ref(raw_path)), (io_peer, ref(io_path))):
    assert accepted['accepted'] is True and accepted['findings'] == [] and contains_ref(accepted, packet)
assert contains_ref(review, ref(raw_path)) and contains_ref(review, ref(io_path))
assert plan['schema'] == 'src06-combined12-complete-input-plan.v1'
assert plan['base_HEAD'] == review['base_HEAD'] == '1435b44537a920ded21ae732bdc7c81051df0282'
assert plan['before_inputs'] == 4472
entries = {row['path']: row for row in plan['entries']}
assert len(entries) == len(plan['entries']) == plan['after_inputs'] == 4473
assert sum(name.endswith('.rs') for name in entries) == plan['after_Rust'] == 4460
inventory = subprocess.check_output(['rg', '--files', '--hidden', '--no-ignore', '-g', '*.rs', '-g', 'Cargo.toml', 'crates'], cwd=R)
paths = {name.replace('\\', '/') for name in inventory.decode().splitlines()}
paths |= {name for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml') if (R / name).is_file()}
assert paths == set(entries)
snapshot = load(checked(cli['source_snapshot']))
observed = {row['historical_path']: row for row in snapshot['files']}
assert set(observed) == paths and len(observed) == len(snapshot['files'])
for name, row in entries.items():
    live = (R / name).read_bytes()
    assert live == checked(observed[name]['archive']).read_bytes()
    assert len(live) == row['after_bytes'] and hashlib.sha256(live).hexdigest() == row['after_sha256']
selected = {}
for packet in (raw, io_packet):
    for row in packet['files']:
        name = row['canonical_path']
        assert name not in selected
        selected[name] = row
        assert (R / name).read_bytes() == checked(row['proposed']).read_bytes()
assert len(selected) == 11 and sum(row.get('before_absent', False) for row in selected.values()) == 1
assert len(plan['selected']) == 12 and len(plan['packets']) == 3
assert set(plan['selected']) == set(selected) | {'tools/porting/check_completed_reported_streams.py'}
for name, row in plan['selected'].items():
    assert (R / name).read_bytes() == checked(row['proposed']).read_bytes()
    checked(row['packet'])
    if name in selected:
        assert row['proposed'] == selected[name]['proposed']
diagnostic_child = R / 'crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs'
assert not diagnostic_child.exists() and diagnostic_child.relative_to(R).as_posix() not in entries
def core_artifacts(receipt, fresh):
    rows = []
    for line in checked(receipt['stdout']).read_bytes().splitlines():
        try:
            row = decode(line)
        except (ValueError, UnicodeError, AssertionError):
            continue
        if isinstance(row, dict) and row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') in ('ep_runtime', 'ep_run', 'eplus-rs'):
            name = row['target']['name']
            expected = {'ep_runtime': 'crates/ep_runtime/src/lib.rs', 'ep_run': 'crates/ep_run/src/lib.rs', 'eplus-rs': 'crates/ep_cli/src/main.rs'}[name]
            same_path(row['target']['src_path'], R / expected)
            assert row['fresh'] is fresh
            rows.append(row)
    assert len(rows) == 3 and len({row['target']['name'] for row in rows}) == 3
    return rows

first_B_compiler = core_artifacts(first_B, False)
compiler = core_artifacts(cli, True)
for previous, current in zip(first_B_compiler, compiler):
    previous_without_fresh = {key: value for key, value in previous.items() if key != 'fresh'}
    current_without_fresh = {key: value for key, value in current.items() if key != 'fresh'}
    assert previous_without_fresh == current_without_fresh, 'A24 must reuse same actual B-compiled core artifacts'
baseline_path, baseline = auth('.runtime/porting/SRC-06/Peer-canonical11-A24-export-roundtrip-01/review.json', '0d971eca58811c5b81b5abad452d8983eff0cfd871a828e543b4ff389385a2db')
assert baseline['accepted'] is True and baseline['findings'] == [] and baseline['JSON_CSV_scalar_roundtrips'] == 5352
assert baseline['native_hour_scope'] == 24
baseline_summary_path = checked(baseline['run_summary'])
old_source = baseline_summary_path.parent.resolve()
assert source != old_source
prior_root_path, prior_root = auth('.runtime/porting/SRC-06/Root-canonical82-activation-actual-review-11/review.json', 'f1f733b69767e3b595f1b49ea6517be5a1a74b713bb54cb74d960d4c2bf0ecfd')
assert prior_root['accepted'] is True and prior_root['findings'] == [] and prior_root['canonical_A24_peer'] == ref(baseline_path)
assert prior_root['compiled_main_artifacts_all_three_fresh_false'] is True and prior_root['original_tolerances_all58_series_pass_by_whole_same_physical_output'] is True
tol_path = checked(baseline['prior_operational_A24_tolerance_audit'])
tol_peer_path = checked(baseline['prior_independent_tolerance_peer'])
tol, tol_peer = load(tol_path), load(tol_peer_path)
assert ref(tol_path)['sha256'] == '3cd42ca127c9eef3edff9d38a127dfa0d63cf8edcb4bc9ccab31079240e379a4'
assert ref(tol_peer_path)['sha256'] == '7bb564ccdb175c90b56ef71ed2bf0bad948abe4e2aea9ecb5b30851cd850731b'
assert tol_peer['accepted'] and tol_peer['findings'] == []
policy_path = checked(baseline['unchanged_original_tolerance_policy'])
assert ref(policy_path)['sha256'] == 'd3cd3e5956ce7e02dbcebe9e8c48799673b66c7b181d932f57514a949dcbf698'
assert subprocess.check_output(['git', 'show', '2fffe68fb9131c80efcd3232de3a81d5290045c6:' + policy_path.relative_to(R).as_posix()], cwd=R) == policy_path.read_bytes()
cases = load(checked(tol['scope']))['cases']
case = next(row for row in cases if row['id'] == 'A-24H')
first_B_case = next(row for row in cases if row['id'] == 'B-NOLIMIT-24H')
same_path(option(first_B['command'], '--weather'), checked(first_B_case['weather']))
assert any(Path(value).resolve() == checked(first_B_case['input']).resolve() for value in first_B['command'])
first_B_diagnostics = first_B_output / 'diagnostics.json'
first_B_summary = first_B_output / 'run-summary.json'
assert load(first_B_summary)['exit_code'] == 6
assert any(row['severity'] == 'error' or row['blocking'] for row in load(first_B_diagnostics)['diagnostics'])
for key in ('input', 'weather'):
    checked(case[key])
same_path(option(cli['command'], '--weather'), R / case['weather']['path'])
assert any(Path(value).resolve() == (R / case['input']['path']).resolve() for value in cli['command'])
physical = []
for row in baseline['canonical11_physical_streams_whole82_and79_equal']:
    previous = checked(row['canonical11'])
    current = source / previous.name
    assert current.read_bytes() == previous.read_bytes()
    physical.append({'current': ref(current), 'accepted_canonical11': ref(previous), 'whole_bytes_equal': True})
assert {Path(row['current']['path']).name for row in physical} == {'eplusrs.eso', 'eplusrs.mtr', 'eplusrs.eio', 'eplusrs.audit', 'eplusrs.shd'}
native_receipt = load(checked(tol['Native_receipt']))
assert native_receipt['exit_code'] == 0 and native_receipt['launch_error'] is None and native_receipt['source_bytes_match_before_and_after'] is True
native_dir = Path(option(native_receipt['command'], '--output-directory')).resolve()
dictionaries = []
dictionary_authority_hashes = {
    'rdd': ('a09f30a711e8bdf3a9b70423cb82673687363bc6fbd5414497e2991d25007477', 'c02aba52c29d58418961ef1d721fd76cb00efe91aa7a6eda4e4f461a27031e50'),
    'mdd': ('6863483ad38fd937068cc44773c44158dff696ddf55a339626c51628a6295a62', '3f266fbb675e61eed67f1bfd5cb49e0a71eba5ea7108b75c3c5faa275e08e44c'),
}
for extension in ('rdd', 'mdd'):
    previous_path, current_path = old_source / ('eplusrs.' + extension), source / ('eplusrs.' + extension)
    native_path = native_dir / ('energyplusout.' + extension)
    previous, current, native = previous_path.read_bytes(), current_path.read_bytes(), native_path.read_bytes()
    assert (ref(previous_path)['sha256'], ref(native_path)['sha256']) == dictionary_authority_hashes[extension]
    assert b'\r' not in previous and previous.endswith(b'\n') and previous.count(b'\n') > 1
    assert current == previous.replace(b'\n', b'\r\n')
    assert current.count(b'\r\n') == current.count(b'\n') and native.count(b'\r\n') == native.count(b'\n')
    source_header, source_body = current.split(b'\r\n', 1)
    native_header, native_body = native.split(b'\r\n', 1)
    assert source_header.startswith(b'! Program Version,') and native_header.startswith(b'! Program Version,')
    assert source_body == native_body
    dictionaries.append({'current': ref(current_path), 'canonical11_before': ref(previous_path), 'Native': ref(native_path), 'exact_old_LF_to_CRLF_at_write': True, 'complete_nonheader_bytes_exact_Native': True, 'nonheader_lines': source_body.count(b'\r\n')})
bundle_path = source / 'results/source-reported-results.json'
previous_bundle_path = checked(baseline['reported_bundle'])
previous_bundle, bundle = load(previous_bundle_path), load(bundle_path)
bridged = previous_bundle_path.read_bytes()
path_bridges = []
for kind in ('eso', 'mtr'):
    old, new = previous_bundle[kind]['path'], bundle[kind]['path']
    same_path(old, old_source / ('eplusrs.' + kind))
    same_path(new, source / ('eplusrs.' + kind))
    old_token = b'"path": ' + json.dumps(old, ensure_ascii=False).encode()
    new_token = b'"path": ' + json.dumps(new, ensure_ascii=False).encode()
    assert bridged.count(old_token) == 1
    bridged = bridged.replace(old_token, new_token, 1)
    path_bridges.append({'stream': kind, 'accepted_canonical11_owned_path': old, 'actual_owned_path': new})
assert bridged == bundle_path.read_bytes(), 'complete JSON differs beyond the two exact owned-path fields'
assert bundle['schema'] == 'rusted-energyplus.source-reported-streams.v1'
csv_files = []
for stream in baseline['streams']:
    previous = checked(stream['CSV'])
    current = source / 'results' / previous.name
    assert current.read_bytes() == previous.read_bytes()
    csv_files.append({'current': ref(current), 'accepted_canonical11': ref(previous), 'whole_bytes_equal': True, 'records': stream['records'], 'series': stream['series']})
summary_path = source / 'run-summary.json'
summary, previous_summary = load(summary_path), load(baseline_summary_path)
assert summary['schema_version'] == 1 and summary['status'] == 'success' and summary['exit_code'] == 0
assert summary['oracle'] is None and summary['comparison'] is None and summary['oracle_status'] == summary['compare_status'] == 'not-requested'
assert summary['config']['oracle_baseline'] is False and summary['config']['compare_oracle'] is False and summary['config']['dry_run'] is False
assert ref(Path(summary['input']['original']))['sha256'] == case['input']['sha256']
old_runtime = decode(json.dumps(previous_summary['rust_runtime']))
for owner in old_runtime['reported_streams']:
    owner['owned_path'] = next(owner_now['owned_path'] for owner_now in summary['rust_runtime']['reported_streams'] if owner_now['stream'] == owner['stream'])
    same_path(owner['owned_path'], source / ('eplusrs.' + owner['stream']))
assert summary['rust_runtime'] == old_runtime
assert summary['rust_runtime']['execution'] == 'actual Source ManageSimulation successful through620'
assert summary['rust_runtime']['native_environment_hour_scope'] == 24
assert summary['config']['hours'] == summary['rust_runtime']['requested_hours']
assert summary['source_order_gate_scope'] == previous_summary['source_order_gate_scope'] == 'execution-plan preflight; not an actual Source caller trace'
assert summary['support']['conformance_claim'] is False
assert set(summary['artifacts']) == set(previous_summary['artifacts'])
assert not {'result_store_json', 'selected_outputs_csv', 'meters_csv'} & set(summary['artifacts'])
for key, filename in (('source_reported_results_json', 'source-reported-results.json'), ('source_eso_csv', 'source-eso.csv'), ('source_mtr_csv', 'source-mtr.csv')):
    same_path(summary['artifacts'][key], source / 'results' / filename)
assert {path.name for path in (source / 'results').iterdir()} == {'source-reported-results.json', 'source-eso.csv', 'source-mtr.csv'}
for name in baseline['diagnostic_sidecar_and_two_snapshots_absent']:
    assert not (source / name).exists()
diagnostics_path = source / 'diagnostics.json'
diagnostics = load(diagnostics_path)
assert summary['diagnostics']['error'] == 0
assert not any(row['severity'] == 'error' or row['blocking'] for row in diagnostics['diagnostics'])
metadata_path = checked(baseline['complete_metadata_differences'])
metadata = {(row['format'], row['line']): row for row in load(metadata_path)['canonical11_vs_Native_all_uncapped']}
assert len(metadata) == 70
tables, differences, native_differences = [], [], []
total = exact_native = 0
for row in baseline['full_tables']:
    previous_path, native_path = checked(row['canonical11']), checked(row['Native'])
    current_path = source / previous_path.name
    current_lines = current_path.read_bytes().splitlines(keepends=True)
    previous_lines, native_lines = previous_path.read_bytes().splitlines(keepends=True), native_path.read_bytes().splitlines(keepends=True)
    assert len(current_lines) == len(previous_lines) == len(native_lines) == row['all_four_complete_line_counts']
    extension = row['format']
    for index, (current, previous, native) in enumerate(zip(current_lines, previous_lines, native_lines), 1):
        authority = metadata.get((extension, index))
        if current != previous:
            assert authority is not None and authority['classification'] in ('actual wall date', 'actual wall clock')
            assert typed_metadata(current, previous, authority['classification'], extension)
            differences.append({'format': extension, 'line': index, 'classification': authority['classification'], 'actual_complete_raw_hex': current.hex(), 'canonical11_complete_raw_hex': previous.hex()})
        if current != native:
            assert authority is not None and previous.hex() == authority['canonical11_complete_raw_hex'] and native.hex() == authority['Native_complete_raw_hex']
            assert typed_metadata(current, previous, authority['classification'], extension)
            native_differences.append({'format': extension, 'line': index, 'classification': authority['classification'], 'actual_complete_raw_hex': current.hex(), 'Native_complete_raw_hex': native.hex()})
        else:
            exact_native += 1
    total += len(current_lines)
    tables.append({'format': extension, 'actual': ref(current_path), 'canonical11': ref(previous_path), 'Native': ref(native_path), 'lines': len(current_lines)})
assert total == 19312 and exact_native == 19242 and len(native_differences) == 70
assert re.findall(rb'<!-- FullName:(.*?)-->', (source / 'eplustbl.htm').read_bytes()) == re.findall(rb'<!-- FullName:(.*?)-->', (old_source / 'eplustbl.htm').read_bytes())
out.mkdir()
diff_path = out / 'full-table-metadata-differences.json'
diff_path.write_text(json.dumps({'actual_vs_canonical11_all_uncapped': differences, 'actual_vs_Native_all_uncapped': native_differences}, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
result = {
    'schema': 'src06-canonical-B-raw-ingress-dictionary-IO-A24-bounded-proof-transfer.v1',
    'accepted': True, 'findings': [],
    'actual_check': ref(check_path), 'actual_A24_CLI': ref(cli_path),
    'actual_first_B_CLI': ref(first_B_path), 'actual_first_B_diagnostics': ref(first_B_diagnostics), 'actual_first_B_summary': ref(first_B_summary),
    'combined_plan': ref(plan_path), 'accepted_combined_review': ref(review_path),
    'B_raw_ingress_manifest': ref(raw_path), 'B_raw_ingress_independent_peer': ref(B_peer_path),
    'dictionary_IO_manifest': ref(io_path), 'dictionary_IO_independent_peer': ref(io_peer_path),
    'all4473_compiled_archived_live_planned_inputs_exact': True, 'Rust_sources': 4460,
    'selected_canonical_Rust_files': len(selected), 'all11_Rust_plus_one_public_tool_proposals_exact': True,
    'diagnostic_child_absent': True, 'first_B_all_three_core_compiler_artifacts_fresh_false': first_B_compiler,
    'A24_all_three_same_core_artifacts_reused_fresh_true': compiler,
    'accepted_canonical11_A24_full5352_proof': ref(baseline_path), 'accepted_canonical11_Root_aggregate': ref(prior_root_path),
    'physical_streams_whole_canonical11_equal': physical, 'dictionaries': dictionaries,
    'reported_bundle': ref(bundle_path), 'accepted_canonical11_bundle': ref(previous_bundle_path),
    'whole_JSON_only_two_owned_path_field_bridges': path_bridges, 'CSV_files_whole_canonical11_equal': csv_files,
    'transferred_JSON_CSV_scalar_roundtrips': 5352, 'transferred_reported_series': 58,
    'proof_transfer_method': 'Five physical stream files and two complete CSV files are byte-identical to the accepted canonical11 whole-file roundtrip proof. The complete JSON is byte-identical after exactly two owned-path field replacements. Therefore every one of the 5,352 raw operands, parsed binary64 bits, series metadata, native environment/stamp strings, ordering, indices and physical lines retains that same checked relationship; no per-sample scan was repeated.',
    'run_summary': ref(summary_path), 'diagnostics': ref(diagnostics_path), 'whole_runtime_canonical11_except_two_owned_paths': True,
    'native_hour_scope': 24, 'legacy_results_and_diagnostic_artifacts_absent': True,
    'full_tables': tables, 'table_lines': total, 'exact_Native_table_lines': exact_native,
    'Native_table_metadata_difference_lines': 70, 'all_table_metadata_differences': ref(diff_path),
    'unchanged_original_tolerance_policy': ref(policy_path), 'prior_operational_A24_audit': ref(tol_path), 'prior_independent_tolerance_peer': ref(tol_peer_path),
    'policy_metadata_notes': tol['policy_metadata_notes'],
    'numeric_observation': 'Identical complete physical ESO/MTR transfer the prior A24 observation: 3,536 unequal parsed reported values, zero failures under original per-row atols and RMSE limits. No new threshold, unit conversion or internal-bit claim.',
    'limits': ['A24 after this exact combined Source snapshot only. The first genuine B run is recorded as incomplete exit6 and proves the fresh core compilation reused by A24; no B frontier-name or duration completion acceptance is established by this checker.', 'RDD/MDD line endings intentionally change at the real physical write; complete old LF-to-CRLF bytes and Native nonheader bytes are verified. No file is rewritten or normalized by this checker.', 'No new simulation, tests, annual JSON load, whole15matrix, internal operation bit-conformance or card/gate completion claim.'],
    'Cargo_Native_tests_executed_by_checker': False, 'main_mutations': 0, 'new_test_bodies': 0, 'policy_changes': 0, 'gate_changes': 0,
    'author_Source': ref(Path(__file__)),
}
report_path = out / 'review.json'
report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(ref(report_path)))

"""Private metadata preparation only; never writes canonical Source or runs CLI."""
import ast,copy,hashlib,importlib.util,json,pathlib,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
R=pathlib.Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(x):
 p=R/x['path'];a=ref(p);assert a['sha256']==x['sha256']and a['bytes']==x['bytes'];return p
def load(p):return json.loads(p.read_bytes())
base='dcb9dfe4a8e610affd883ef9211be31d54a1bd8a';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=R)==b''
draft=D/'successful-source-log-layout-draft-Root-48/draft.json';assert ref(draft)['sha256']=='96a003049d3073433e023744091b32143a630b413ba7f71f98dac83514130912'
peer=D/'Peer-successful-source-log-layout-Source-review-48/review.json';assert ref(peer)['sha256']=='0513493e22856c75934a9851a6ae5f58f5e748d544c04852745159898f873421'
actual=D/'Root-full-predictor-parent-actual-review-P2/review.json';assert ref(actual)['sha256']=='3a023b7649744a15a0340053e4c08d3aaacb9a650ce8a1e2f9b632115246fde9';a=load(actual);assert a['accepted']and not a['findings']
parent=checked(a['complete_compiler_plan']);assert ref(parent)['sha256']=='70d6b6ab3943fe061735b3c6b1dab41b15244bb5f0664c5fd6b74edd6165b22f'
d=load(draft);p=load(peer);assert p['accepted']and not p['findings']and p['reviewed_draft']==ref(draft)
spec=importlib.util.spec_from_file_location('layout49_preparation_readonly',D/'apply-successful-source-log-layout-Root-49.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
plan=load(parent);g.whole(plan);final=copy.deepcopy(plan);final.update(schema='src06-successful-source-log-layout-complete-compiler-plan49.v1',base_HEAD=base,prior_complete_compiler_Source_plan=ref(parent),selected_existing=2,selected_new=0,qualification='Exactly two normal Source persistence files; all other4523 compiler inputs whole unchanged from accepted P2 plan. No execution.')
rows={x['path']:x for x in final['entries']};apply=g.literal()
for f in d['files']:
 n=f['canonical_path'];before=checked(f['before']).read_bytes();after=checked(f['proposed']).read_bytes();assert(R/n).read_bytes()==subprocess.check_output(['git','show',base+':'+n],cwd=R)==before
 assert apply(before,checked(f['forward_diff']).read_bytes())==after and apply(after,checked(f['inverse_diff']).read_bytes())==before
 rows[n].update(final_sha256=f['proposed']['sha256'],final_bytes=f['proposed']['bytes'],source=f['proposed'],origin='accepted successful Source log-layout49')
files=['apply-successful-source-log-layout-Root-49.py','launch-successful-source-log-layout-Root-49.py','check-successful-source-log-layout-Root-49.py']
for name in files:ast.parse((D/name).read_text(encoding='utf-8-sig'))
cases=[]
for c in g.CASES:
 rp=D/f'canonical-source-normal-completion-{c}-command-Root-47/receipt.json';r=load(rp);assert r['exit_code']==0 and r['source_bytes_match_before_and_after'];cmd=r['command']
 ip=next(pathlib.Path(x)for x in cmd if x.lower().endswith('.idf'));weather=pathlib.Path(cmd[cmd.index('--weather')+1]);out=D/f'canonical-source-successful-log-layout-{c}-Root-49/output';receipt=D/f'canonical-source-successful-log-layout-{c}-command-Root-49/receipt.json';assert not out.parent.exists()and not receipt.parent.exists()
 cases.append(dict(case=c,prior47_receipt=ref(rp),prior47_readback=ref(D/f'Root-normal-completion-{c}-readback-47/review.json'),prior47_output=(D/f'canonical-source-normal-completion-{c}-Root-47/output').relative_to(R).as_posix(),input=ref(ip),weather=ref(weather),output=out.relative_to(R).as_posix(),receipt=receipt.relative_to(R).as_posix()))
folder=D/'successful-source-log-layout-prepared-Peer-49';folder.mkdir(exist_ok=False);fp=folder/'complete-final-compiler-Source-plan.json';fp.write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8',newline='\n')
q=dict(schema='src06-successful-source-log-layout-prepared49.v1',status='READY_ROOT_ONLY_NOT_EXECUTED',base_HEAD=base,draft=ref(draft),independent_semantic_peer=ref(peer),parent_actual=ref(actual),parent_compiler_plan=ref(parent),prior47_actual=a['parent_End47_actual'],complete_compiler_plan=ref(fp),application_Source=ref(D/files[0]),launch_Source=ref(D/files[1]),checker_Source=ref(D/files[2]),record_command_Source=ref(R/'tools/porting/record_command.py'),cases=cases,inputs=4525,Rust_sources=4512,existing_Source_changes=2,new_Source_files=0,actual_invocations=0,Root_order=['apply2','A-24H','B-NOLIMIT-24H','read-only checker'],scope='Successful Source physical log layout only; actual future invocations remain unknown. No tests/yearly/Native/math reruns.',author_Source=ref(pathlib.Path(__file__)))
qp=folder/'prepared.json';qp.write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(qp)));print(json.dumps(ref(fp)))

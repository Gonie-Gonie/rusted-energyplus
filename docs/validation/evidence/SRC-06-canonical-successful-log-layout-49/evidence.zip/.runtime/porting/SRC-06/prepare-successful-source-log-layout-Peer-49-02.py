"""Immutable helper successor: authenticate retained47 baseline bytes too."""
import ast,hashlib,json,pathlib,sys
sys.stdout.reconfigure(encoding='utf-8')
R=pathlib.Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
old=D/'successful-source-log-layout-prepared-Peer-49/prepared.json';assert ref(old)['sha256']=='dc6586eb9b74ff1d3653c87e5834afede70e19f868c67285b460cce1bfaf59d2';q=json.loads(old.read_bytes())
names={p:p.replace('Root-49.py','Root-49-02.py')for p in['apply-successful-source-log-layout-Root-49.py','launch-successful-source-log-layout-Root-49.py','check-successful-source-log-layout-Root-49.py']}
extra=""" prior_review=g.read(g.checked(q['prior47_actual']));assert prior_review['accepted']and not prior_review['findings']
 back=g.read(g.checked(x['prior47_readback']));assert back['accepted']and not back['findings']and back['actual_receipt']==x['prior47_receipt']and back['case']==x['case']
 prefix=x['prior47_output'].rstrip('/')+'/'
 def authenticate_retained(value):
  if isinstance(value,dict):
   if isinstance(value.get('path'),str)and 'sha256'in value and value['path'].startswith(prefix):g.checked(value)
   for v in value.values():authenticate_retained(v)
  elif isinstance(value,list):
   for v in value:authenticate_retained(v)
 authenticate_retained(back)
"""
for before,after in names.items():
 src=D/before;text=src.read_text(encoding='utf-8-sig')
 for a,b in names.items():text=text.replace(a,b)
 text=text.replace('successful-source-log-layout-prepared-Peer-49/prepared.json','successful-source-log-layout-prepared-Peer-49-02/prepared.json')
 if before.startswith('check-'):
  anchor=" source=R/x['output'];old=R/x['prior47_output'];summary=g.read(source/'run-summary.json');diags=g.read(source/'diagnostics.json')\n";assert text.count(anchor)==1;text=text.replace(anchor,extra+anchor)
 ast.parse(text);dest=D/after;assert not dest.exists();dest.write_text(text,encoding='utf-8',newline='\n')
folder=D/'successful-source-log-layout-prepared-Peer-49-02';folder.mkdir(exist_ok=False)
q.update(predecessor_prepared=ref(old),author_Source=ref(pathlib.Path(__file__)),preparation_correction='Only read-only helper guard extended: accepted47 baseline file hashes are reauthenticated through its accepted readback before transfer. Original unexecuted49 helper set retained. Same two proposals, complete plan, input commands and future outputs.')
for k,n in zip(['application_Source','launch_Source','checker_Source'],names.values(),strict=True):q[k]=ref(D/n)
p=folder/'prepared.json';p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))
for k in['application_Source','launch_Source','checker_Source']:print(k,json.dumps(q[k]))

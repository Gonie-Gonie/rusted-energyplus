"""Root-only exactly two normal CLI commands, copied from authentic47 argv."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def main(a):
 assert a.execute,'Root --execute required'
 spec=importlib.util.spec_from_file_location('layout49',D/'apply-successful-source-log-layout-Root-49-03.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 q,d,ar,app,plan=g.application(a.application);assert g.ref(Path(__file__))==q['launch_Source'];cmd,x=g.command(a.case,q)
 for prior in g.CASES[:g.CASES.index(a.case)]:
  f=next(x for x in q['cases']if x['case']==prior);r=g.read(R/f['receipt']);assert r['exit_code']==0 and r['launch_error']is None and r['source_bytes_match_before_and_after'];g.snapshot(r,plan)
 output=R/x['output'];receipt=R/x['receipt'];assert not output.parent.exists()and not receipt.parent.exists()
 print('Root49 '+a.case+': exact normal featureNone command; target55/incremental0; no Native/test/yearly command.',flush=True)
 rc=subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',receipt.parent.relative_to(R).as_posix(),'--',*cmd],cwd=R,env=g.environment())
 g.whole(plan);r=g.read(receipt);assert r['exit_code']==rc and r['launch_error']is None and r['source_bytes_match_before_and_after'];g.snapshot(r,plan);return rc
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case',choices=['A-24H','B-NOLIMIT-24H']);p.add_argument('--application',required=True);p.add_argument('--execute',action='store_true');raise SystemExit(main(p.parse_args()))

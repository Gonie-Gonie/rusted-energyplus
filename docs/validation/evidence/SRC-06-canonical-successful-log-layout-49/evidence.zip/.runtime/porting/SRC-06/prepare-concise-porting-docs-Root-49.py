from pathlib import Path
import difflib
import hashlib
import json

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06/concise-porting-docs-Root-49'

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def main():
    assert not D.exists()
    D.mkdir()
    P = R / 'energyplus_porting_plan'
    names = ['CHECKLIST.md', 'STATE_CONTRACTS.md', 'cards/SRC-06.md', 'README.md']
    old = {n: (P / n).read_text(encoding='utf8') for n in names}
    checklist = '\n'.join(old['CHECKLIST.md'].splitlines()[:179]) + '''

## 현재 진행 상태

최신 구현·검증 결과와 남은 작업은 [작업계획 안내](README.md#현재-진행-상태)에 모았습니다.
64개 카드의 완료 여부는 위 표와 `plan.json`의 네 gate를 기준으로 판단합니다.
과거 단계별 실행 기록은 `evidence/`와 Git 이력에 보존하며, 과거 테스트 개수를 현재 검증 결과로 사용하지 않습니다.
'''
    state = '\n'.join(old['STATE_CONTRACTS.md'].splitlines()[:32]) + '''

## 실제 구현의 소유권과 호출 순서

- 날씨의 Today/Tomorrow, 달력, 스케줄, CTF master history는 서로 다른 지속 상태입니다. 환경 초기화·warmup·RunPeriod의 인계와 accepted step의 갱신 시점을 각각 검증합니다.
- 실내 대류는 공간별 MAT/ZT/ZTAV와 두 표면온도 배열을 구분합니다. Natural의 strict 부호·exact-zero 분기, Detailed의 하한 대입 및 원본 반복 갱신 순서를 유지합니다. [TARP 비교](evidence/SRC-06-tarp-inside-selected/summary.json), [dispatcher 상태 비교](evidence/SRC-06-tarp-dispatcher/summary.json).
- Predictor/corrector는 실제 AirHeatBalance·Node·Demand 소유자를 공유합니다. [전체 predictor 부모 1,168건](evidence/SRC-06-canonical-full-predictor-parent-48/summary.json)은 독립적으로 포착한 호출의 검증이며, 연속 push/revert/retry 이력과 multiplier 변형의 검증은 별도로 남아 있습니다. 코드에서 도출한 네 사후조건은 Native 관측 비트로 세지 않습니다.
- IdealLoads의 입력·가용성·초기화·계산·노드 갱신·보고는 같은 장비와 노드 상태를 사용합니다. [hard-sized 네 Sizer 및 전체 Size](evidence/SRC-06-canonical-hard-sized-purchased-air-43/summary.json)의 검증 범위와 전체 SimPurchasedAir의 지속 호출 검증을 구분합니다.
- OutputProcessor의 system step 누적과 zone step 확정은 별개입니다. accepted 시간만 누적하고, 원본 zone 호출이 수행하는 meter 갱신을 중복 호출하지 않습니다. warmup·시간·일·월·환경 reset과 report latch는 원본 시점에 유지합니다.
- 종료 처리는 같은 Source 오류 카운터·진단 상태·타이머를 소비합니다. [일반 종료 검증](evidence/SRC-06-canonical-normal-completion-47/summary.json)과 [성공 실행 로그 정리](evidence/SRC-06-canonical-successful-log-layout-49/summary.json)를 참조합니다. ERR·END·콘솔의 실제 실행 시간은 보존하며, 실패/Legacy 경로는 기존 출력 경로를 유지합니다.

## 증거 해석

같은 입력·초기 상태·관측 필드와 실제 Source 버전을 확인한 뒤 비교 결과를 재사용합니다. 단위 호출, 일반 실행, 보고 값, JSON/CSV 재읽기 검증은 각각 기록합니다. 과거 원본 실행의 부동소수점 환경이나 private cache 상태를 관측하지 않았다면 추정값으로 대체하지 않습니다.

[과거 CTF 이력 비교](evidence/CTF-10-main-thread-history-comparison/summary.json)의 235,456개 불일치와 2,754개 필수 미확인 경계는 해당 과거 Source의 실패 기록입니다. 현재 실행의 결과로 바꾸어 표기하거나 삭제하지 않습니다. 최신 검증 범위와 아직 닫히지 않은 gate는 [작업계획 안내](README.md#현재-진행-상태)와 `plan.json`을 참조합니다.
'''
    tarp = '\n'.join(old['cards/SRC-06.md'].splitlines()[:65]) + '''

## 현재 구현과 증거

원본 TARP Natural/Detailed과 선택 InitIntConvCoeff dispatcher를 구현했습니다. [선택 수식 비교](../evidence/SRC-06-tarp-inside-selected/summary.json)는 28개 사례·60회 원본 호출 중 유한한 endpoint 54개가 일치합니다. 비유한 endpoint 6개는 class 진단만 기록했고, 필수 미확인 34개는 수치 PASS에 포함하지 않았습니다.

[선택 dispatcher 비교](../evidence/SRC-06-tarp-dispatcher/summary.json)는 실제 공간 MAT/ZT/ZTAV·표면온도 배열·지속 scratch·호출 순서를 구분합니다. [호출자 소유 공간 상태 인터페이스](../evidence/SRC-06-live-space-convection-interface.json)를 통해 같은 owner를 빌려 읽습니다.

남은 카드 조건은 실제 표면 열수지 부모에서 환경 reset·두 온도 배열·복사 후 완료 반복 30회마다의 계수 갱신·즉시 소비 순서를 확인하는 것입니다. 선택 단위 검증만으로 전체 카드의 네 gate를 닫지 않습니다. A 14/54·B 14/64는 유지합니다.

다른 모듈의 포팅 현황은 [전체 진행 상태](../README.md#현재-진행-상태)에 모았습니다. 이전 단계별 기록과 실패 자료는 `../evidence/` 및 Git 이력에 보존합니다.
'''
    status = '''
## 현재 진행 상태

완료 카드는 A **14/54**, B **14/64**입니다. 보고 값이 일치한 실행과 카드 전체의 완료 조건은 구분합니다. 아래 결과는 해당 기록의 Source 버전과 검증 범위에 한정합니다.

| 검증 범위 | 실제 결과·증거 |
|---|---|
| A 비공조 24시간·72시간·연간 보고 값 | [현재 일반 종료 실행 3건](evidence/SRC-06-canonical-normal-completion-47/summary.json), 허용오차 위반·RMSE 0 |
| B NoLimit 24시간·72시간·연간 보고 값 | [3건·3,613,248값](evidence/SRC-06-canonical-nolimit-duration-validation-45/summary.json), 허용오차 위반·RMSE 0 |
| B flow/capacity/both × 24시간·72시간·연간 | [9건·10,839,744값](evidence/SRC-06-canonical-limit-mode-reported-validation-46/summary.json), 허용오차 위반·RMSE 0 |
| hard-sized IdealLoads | [원본 59건과 네 Sizer·전체 Size](evidence/SRC-06-canonical-hard-sized-purchased-air-43/summary.json) 비교 통과 |
| 전체 predictor 부모 | [포착한 실제 호출 1,168건](evidence/SRC-06-canonical-full-predictor-parent-48/summary.json) 비교 통과 |
| 성공 실행 출력 정리 | [A/B 24시간 두 건](evidence/SRC-06-canonical-successful-log-layout-49/summary.json), 기존 계산·CSV·JSON 유지, 중복 오류 파일 제거, 콘솔 원문을 `logs/source-console.log`로 이동 |

다음 작업은 전체 PurchasedAir 지속 호출, 복사·되돌리기·재시도 이력과 multiplier, 복사열·태양열·내부발열 생산자, CTF master history·분 단위 스케줄 경계, 전체 OutputProcessor 누적·reset의 원본 비교입니다. 이어 warmup→RunPeriod 상태 인계와 같은 최종 Source의 15개 실행 및 전체 JSON/CSV 재읽기를 마무리합니다. 현재 15건의 과거 증거를 하나의 최종 Source 검증으로 합쳐 표기하지 않습니다.

검증은 변경한 계산 경로에 필요한 기존 통합 cohort 또는 실행만 수행합니다. 같은 몸체를 다시 검증할 근거가 없다면 이전 대규모 cohort·연간 실행·전체 테스트를 반복하지 않습니다. 문서와 로그 경로만 바꾼 경우에는 해당 출력 확인과 문서 검사를 사용합니다.

각 카드의 네 gate와 증거 색인은 [CHECKLIST.md](CHECKLIST.md), [plan.json](plan.json), 상태 소유권은 [STATE_CONTRACTS.md](STATE_CONTRACTS.md)에 있습니다. 과거 단계별 진행 문장은 이 세 문서에서 걷어냈고, 기존 `evidence/`와 Git 이력은 보존했습니다. 과거 CTF 비교의 235,456개 불일치·2,754개 미확인은 해당 실행의 역사적 기록이며 현재 결과로 재분류하지 않습니다.

'''
    readme = old['README.md']
    marker = '## 범위'
    assert readme.count(marker) == 1 and '## 현재 진행 상태' not in readme
    readme = readme.replace(marker, status + marker, 1)
    proposed = dict(zip(names, [checklist, state, tarp, readme]))
    operations = []
    for name in names:
        before = D / (name.replace('/', '__') + '.before')
        after = D / (name.replace('/', '__') + '.proposed')
        before.write_bytes((P / name).read_bytes())
        after.write_text(proposed[name], encoding='utf8', newline='\n')
        diffs = []
        for suffix, a, b in [('forward', before, after), ('inverse', after, before)]:
            out = D / (name.replace('/', '__') + '.' + suffix + '.diff')
            out.write_text(''.join(difflib.unified_diff(a.read_text(encoding='utf8').splitlines(True), b.read_text(encoding='utf8').splitlines(True), fromfile=a.name, tofile=b.name)), encoding='utf8', newline='\n')
            diffs.append(ref(out))
        operations.append(dict(canonical_path='energyplus_porting_plan/'+name, before=ref(before), proposed=ref(after), forward_diff=diffs[0], inverse_diff=diffs[1]))
    manifest = dict(schema='porting-concise-docs-root49.v1', doc_replacements=operations, author_Source=ref(Path(__file__)), gate_or_policy_changes=False, source_changes=False, archived_evidence_removed=False, checklist_original_first179_lines_unchanged=True, state_original_first32_lines_unchanged=True, SRC06_original_first65_lines_unchanged=True, README_original_text_preserved=True, reason='Replace chronological status dumps with one current progress index; retain all evidence and Git history.')
    out = D / 'manifest.json'
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf8', newline='\n')
    print(json.dumps(ref(out)))

if __name__ == '__main__':
    main()

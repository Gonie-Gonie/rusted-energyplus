"""Private immutable04: carry strict historical table-position metadata policy."""
import ast,difflib,hashlib,json,pathlib,sys
sys.stdout.reconfigure(encoding='utf-8')
R=pathlib.Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
old=D/'successful-source-log-layout-prepared-Peer-49-03/prepared.json';assert ref(old)['sha256']=='8391b6e7e1391d40c7b0b9ee7ae0d94b7af062e49a78574f4ea2fac6a7fe4e55';q=json.loads(old.read_bytes())
names={p:p.replace('Root-49-03.py','Root-49-04.py')for p in['apply-successful-source-log-layout-Root-49-03.py','launch-successful-source-log-layout-Root-49-03.py','check-successful-source-log-layout-Root-49-03.py']}
authority=dict(Root13_checker=ref(D/'check-source-compact-actual-Root-13.py'),strict_metadata_function_Source=ref(D/'check-canonical-B-ingress-IO-A24-transfer-Peer-03.py'),accepted_metadata_proof=ref(D/'Peer-canonical-B-ingress-IO-A24-transfer-03/full-table-metadata-differences.json'),original_accepted_peer=ref(D/'Peer-canonical-B-ingress-IO-A24-transfer-03/review.json'))
assert authority['Root13_checker']['sha256']=='e74ca3d9d2a85102f0dca30ed978ed25d7f8bee8e1fd72459b7b7ba131c2dea4'
assert authority['strict_metadata_function_Source']['sha256']=='0742d4694653c9f80e93e1ebe89ed80bf14696b148e39f8477f0c67c1cb50c74'
assert authority['accepted_metadata_proof']['sha256']=='17ab6463df871616e6c4e66cfaa805a403d2bcc7e74025862c565ca4bdba2257'
assert authority['original_accepted_peer']['sha256']=='6bfe7736ea81fc1123ebc4ee11c64e9de64d123f3e3a92e49636f13cd9dc4dca'
helper='''def tables_transfer(g,source,prior,q):
 authority=q['table_metadata_authority']
 for v in authority.values():g.checked(v)
 peer=g.read(g.checked(authority['original_accepted_peer']));assert peer['accepted']and not peer['findings']and peer['all_table_metadata_differences']==authority['accepted_metadata_proof']
 proof=g.read(g.checked(authority['accepted_metadata_proof']));allowed={(x['format'],x['line']):x for x in proof['actual_vs_canonical11_all_uncapped']}
 tree=ast.parse(g.checked(authority['strict_metadata_function_Source']).read_text(encoding='utf-8-sig'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='typed_metadata');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<accepted-Root13-strict-table-metadata>','exec'),ns)
 rows=[];changes=[];total=0;present=0
 for ext in['csv','tab','txt','htm','xml']:
  a,b=source/('eplustbl.'+ext),prior/('eplustbl.'+ext);assert a.exists()==b.exists()
  if not a.exists():rows.append(dict(format=ext,both_absent=True));continue
  present+=1;now,old=a.read_bytes().splitlines(keepends=True),b.read_bytes().splitlines(keepends=True);assert len(now)==len(old);total+=len(now)
  for line,(left,right)in enumerate(zip(now,old,strict=True),1):
   if left==right:continue
   rule=allowed[(ext,line)];kind=rule['classification'];assert kind in['actual wall clock','actual wall date']and ns['typed_metadata'](left,right,kind,ext)
   changes.append(dict(format=ext,line=line,classification=kind,current_complete_raw_hex=left.hex(),prior47_complete_raw_hex=right.hex()))
  rows.append(dict(format=ext,current=g.ref(a),prior47=g.ref(b),physical_lines=len(now)))
 assert(present==0 and total==0)or(present==5 and total==19312)
 return dict(files=rows,physical_lines=total,all_nonmetadata_lines_whole_exact=True,exact_allowlist_authority=authority,all_uncapped_metadata_differences=changes,unequal_metadata_lines=len(changes),no_file_wide_regex_or_other_normalization=True)
'''
folder=D/'successful-source-log-layout-prepared-Peer-49-04';folder.mkdir(exist_ok=False);deltas=[]
for before,after in names.items():
 src=D/before;raw=src.read_bytes();text=raw.decode('utf-8-sig')
 for a,b in names.items():text=text.replace(a,b)
 text=text.replace('successful-source-log-layout-prepared-Peer-49-03/prepared.json','successful-source-log-layout-prepared-Peer-49-04/prepared.json')
 if before.startswith('check-'):
  text=text.replace('import argparse,copy,importlib.util,json,re,math\n','import argparse,copy,importlib.util,json,re,math,ast\n')
  anchor='def transfer(g,source,old):\n';assert text.count(anchor)==1;text=text.replace(anchor,helper+'def transfer(g,source,old,q):\n')
  anchor=" tables=[exact(g,source/('eplustbl.'+k),old/('eplustbl.'+k))for k in['csv','htm','tab','txt','xml']]\n";assert text.count(anchor)==1;text=text.replace(anchor,' tables=tables_transfer(g,source,old,q)\n')
  text=text.replace('physics=transfer(g,source,old);','physics=transfer(g,source,old,q);')
  anchor="'No new Native or scientific unit execution. Prior numerical proofs transfer only through exact physical/export/runtime equality.'";assert text.count(anchor)==1;text=text.replace(anchor,anchor+",'A tables reuse only accepted Root13 format/line clock-date positions and exact typed_metadata shapes; every other one of19312 lines is exact47, and all raw unequal lines are retained uncapped.'")
 ast.parse(text);dest=D/after;assert not dest.exists();dest.write_text(text,encoding='utf-8',newline='\n')
 fp=folder/(before+'.forward.diff');ip=folder/(before+'.inverse.diff');fp.write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),text.splitlines(True),fromfile=before,tofile=after)),encoding='utf-8',newline='\n');ip.write_text(''.join(difflib.unified_diff(text.splitlines(True),raw.decode().splitlines(True),fromfile=after,tofile=before)),encoding='utf-8',newline='\n');deltas.append(dict(before=ref(src),after=ref(dest),forward=ref(fp),inverse=ref(ip)))
q.update(predecessor_prepared=ref(old),author_Source=ref(pathlib.Path(__file__)),table_metadata_authority=authority,preparation_correction='Root second pre-execution finding: A five tables have real clock/date metadata.04 carries InputResolved03 and adds exact accepted Root13 position/typed-shape checks with uncapped raw unequal-line ledger; no broad regex or scientific normalization.02/03 retained unexecuted. Same two Source proposals/plan/commands.')
for k,n in zip(['application_Source','launch_Source','checker_Source'],names.values(),strict=True):q[k]=ref(D/n)
ledger=folder/'helper-correction.json';ledger.write_text(json.dumps(dict(original_prepared=ref(old),unchanged_compiler_plan=q['complete_compiler_plan'],production_Source_changes=0,actual_invocations=0,deltas=deltas),indent=2)+'\n',encoding='utf-8',newline='\n');q['helper_correction']=ref(ledger)
p=folder/'prepared.json';p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))
for k in['application_Source','launch_Source','checker_Source','helper_correction']:print(k,json.dumps(q[k]))

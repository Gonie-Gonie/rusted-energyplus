"""Authenticate Root's concise docs and freeze an unexecuted finite publisher template."""
from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'successful-log-layout-publication-ready-Audit-49-02'

def ref(p):
    p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

def checked(v):
    p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']);return p

def write(p,v):p.write_text(json.dumps(v,ensure_ascii=True,indent=2)+'\n',encoding='utf8',newline='\n');return ref(p)

def apply(raw,patch):
    before=raw.decode('utf8').splitlines(keepends=True);lines=patch.decode('utf8').splitlines(keepends=True)
    assert lines[0].startswith('--- ') and lines[1].startswith('+++ ')
    at=0;out=[];i=2
    while i<len(lines):
        m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n',lines[i]);assert m
        start=int(m[1])-1;oldn=int(m[2] or 1);newn=int(m[4] or 1);assert start>=at
        out+=before[at:start];at=start;i+=1;seenold=seennew=0
        while i<len(lines) and not lines[i].startswith('@@ '):
            mark,text=lines[i][:1],lines[i][1:];assert mark in [' ','-','+']
            if mark in [' ','-']:assert before[at]==text;at+=1;seenold+=1
            if mark in [' ','+']:out.append(text);seennew+=1
            i+=1
        assert (seenold,seennew)==(oldn,newn)
    return ''.join(out+before[at:]).encode('utf8')

assert not O.exists()
oldp=D/'successful-log-layout-publication-draft-Audit-49-01/template.json'
assert ref(oldp)['sha256']=='877f5c38e7ff7612f94b896711eb4eb06405f32a29b5da5500f3245a23875a7e'
t=json.loads(oldp.read_bytes());mp=D/'concise-porting-docs-Root-49/manifest.json'
assert ref(mp)['sha256']=='799babbcd661c749cc71d35a0103abe00f23e1c5bb01806b43978ef6c68cfff3'
doc=json.loads(mp.read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==t['base_HEAD']
assert not doc['gate_or_policy_changes'] and not doc['source_changes'] and not doc['archived_evidence_removed']
expected={'energyplus_porting_plan/'+x for x in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md','README.md']}
assert {x['canonical_path'] for x in doc['doc_replacements']}==expected
prefixes={'energyplus_porting_plan/CHECKLIST.md':179,'energyplus_porting_plan/STATE_CONTRACTS.md':32,'energyplus_porting_plan/cards/SRC-06.md':65}
proof=[];links=[];future='energyplus_porting_plan/evidence/SRC-06-canonical-successful-log-layout-49/summary.json'
for op in doc['doc_replacements']:
    old=checked(op['before']).read_bytes();new=checked(op['proposed']).read_bytes();name=op['canonical_path']
    assert (R/name).read_bytes()==old==subprocess.check_output(['git','show',head+':'+name])
    assert apply(old,checked(op['forward_diff']).read_bytes())==new and apply(new,checked(op['inverse_diff']).read_bytes())==old
    assert '\ufffd' not in new.decode('utf8')
    if name in prefixes:assert old.splitlines(keepends=True)[:prefixes[name]]==new.splitlines(keepends=True)[:prefixes[name]]
    if name.endswith('CHECKLIST.md'):
        row=lambda b:[x for x in b.splitlines() if re.match(rb'\|\s*(?:CON|GEO|CLK|SCH|PSY|CTF|SRC|RAD|SUR|ZON|HVAC|SYS)-\d\d\s*\|',x)]
        assert row(old)==row(new) and len(row(new))==64
    for target in re.findall(r'\]\(([^)]+)\)',new.decode('utf8')):
        if target.startswith(('http://','https://','#')):continue
        resolved=((R/name).parent/target.split('#',1)[0]).resolve();assert resolved.is_relative_to(R)
        assert resolved.exists() or resolved==R/future,(name,target)
        links.append(dict(document=name,target=target,status='pending_this_publication' if resolved==R/future else 'existing'))
    proof.append(dict(canonical_path=name,before=op['before'],proposed=op['proposed'],both_literal_applications_exact=True,preserved_prefix_lines=prefixes.get(name),UTF8_valid=True))
O.mkdir()
pr=write(O/'Root-doc-replacement-integration-proof.json',dict(status='READ_ONLY_DOC_BYTES_INVERSES_LINKS_AND_UNCHANGED_SCOPE_VERIFIED',Root_manifest=ref(mp),checks=proof,checklist_rows=64,local_links=links,chronological_appends=0,gate_or_policy_changes=False,canonical_mutations=False,author_Source=ref(Path(__file__))))
rows={x['path']:x for x in t['finite_archive_inputs']}
def add(v):
    p=checked(v);a=ref(p);assert a['bytes']<64*1024*1024 and p.suffix.lower() not in ['.zip','.exe','.dll','.obj','.a','.map','.rlib','.rmeta'];rows[a['path']]=a
for v in [ref(mp),doc['author_Source'],pr,ref(Path(__file__))]:add(v)
for op in doc['doc_replacements']:
    for key in ['before','proposed','forward_diff','inverse_diff']:add(op[key])
t['status']='READY_FOR_ROOT_FULL_READ_AND_PUBLICATION'
t['doc_replacements']=doc['doc_replacements'];t['doc_replacement_manifest']=ref(mp);t['doc_replacement_author_Source']=doc['author_Source']
t['finite_archive_inputs']=sorted(rows.values(),key=lambda x:x['path'])
t['finite_archive_scope']+=' Four exact compact Root-authored document replacements preserve the original card/policy prefixes, all64 table rows, gates and historical evidence. No chronological appends.'
t['doc_replacement_integration_proof']=pr;t['previous_private_template']=ref(oldp)
t['summary_template']['document_policy']='Four compact Root-authored whole-document replacements; policy/card prefixes and64 table rows unchanged, all evidence retained. No chronological appends.'
t['author_Source']=ref(Path(__file__))
total=sum(x['bytes'] for x in rows.values());assert total<64*1024*1024
tp=O/'template.json';write(tp,t)
import difflib
for n,a,b in [('forward.diff',oldp.read_text(encoding='utf8'),tp.read_text(encoding='utf8')),('inverse.diff',tp.read_text(encoding='utf8'),oldp.read_text(encoding='utf8'))]:
    (O/n).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='draft01' if n=='forward.diff' else 'READY02',tofile='READY02' if n=='forward.diff' else 'draft01')),encoding='utf8',newline='')
print(json.dumps(dict(template=ref(tp),publisher=t['publisher_Source'],forward=ref(O/'forward.diff'),proof=pr,finite_entries=len(rows),finite_uncompressed_bytes=total,canonical_mutations=False)))

"""Metadata-only final finite archive closure for the preserved doc precheck."""
from pathlib import Path
import difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'successful-log-layout-publication-ready-Audit-49-03'
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
assert not O.exists()
p=D/'successful-log-layout-publication-ready-Audit-49-02/template.json';assert ref(p)['sha256']=='2fce4aefcf4d93d3f6de7ab78bffe76f5badaf90644c9cbc91b3f0b9aa7a6151'
v=json.loads(p.read_bytes());rows={x['path']:x for x in v['finite_archive_inputs']}
for n in ['failure.json','original-preparer.py']:
    a=ref(D/'successful-log-layout-publication-doc-precheck-Audit-49-01'/n);rows[a['path']]=a
a=ref(Path(__file__));rows[a['path']]=a
v['finite_archive_inputs']=sorted(rows.values(),key=lambda x:x['path']);v['previous_READY_template']=ref(p);v['final_metadata_author_Source']=a
assert sum(x['bytes'] for x in rows.values())<64*1024*1024
O.mkdir();q=O/'template.json';q.write_text(json.dumps(v,ensure_ascii=True,indent=2)+'\n',encoding='utf8',newline='\n')
for n,x,y in [('forward.diff',p,q),('inverse.diff',q,p)]:
    (O/n).write_text(''.join(difflib.unified_diff(x.read_text(encoding='utf8').splitlines(keepends=True),y.read_text(encoding='utf8').splitlines(keepends=True),fromfile=x.parent.name,tofile=y.parent.name)),encoding='utf8',newline='')
print(json.dumps(dict(template=ref(q),publisher=v['publisher_Source'],forward=ref(O/'forward.diff'),finite_entries=len(rows),finite_uncompressed_bytes=sum(x['bytes'] for x in rows.values()),canonical_mutations=False)))

"""Private immutable03: compare one actual conversion timing message precisely."""
import ast,difflib,hashlib,json,pathlib,sys
sys.stdout.reconfigure(encoding='utf-8')
R=pathlib.Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
old=D/'successful-source-log-layout-prepared-Peer-49-02/prepared.json';assert ref(old)['sha256']=='8c8324aee04c0d2491ad6767211380d7d1a5feb81cf586914c8107ad3b26957f';q=json.loads(old.read_bytes())
names={p:p.replace('Root-49-02.py','Root-49-03.py')for p in['apply-successful-source-log-layout-Root-49-02.py','launch-successful-source-log-layout-Root-49-02.py','check-successful-source-log-layout-Root-49-02.py']}
helper='''def diagnostics_transfer(g,current,prior):
 now=current.read_bytes();old=prior.read_bytes();nv,ov=json.loads(now),json.loads(old)
 ni=[(i,v)for i,v in enumerate(nv['diagnostics'])if v['code']=='InputResolved'and v['stage']=='input']
 oi=[(i,v)for i,v in enumerate(ov['diagnostics'])if v['code']=='InputResolved'and v['stage']=='input']
 assert len(ni)==len(oi)==1 and ni[0][0]==oi[0][0]
 times=[]
 for _,v in[ni[0],oi[0]]:
  assert v['severity']=='info'and v['blocking']is False
  match=re.fullmatch(r'input kind idf staged; IDF conversion wall seconds ([0-9]+(?:\\.[0-9]+)?)',v['message']);assert match
  value=float(match.group(1));assert math.isfinite(value)and value>=0.0;times.append(dict(decimal_payload=match.group(1),seconds=value))
 left,right=json.dumps(ni[0][1]['message']).encode(),json.dumps(oi[0][1]['message']).encode();assert now.count(left)==1
 assert now.replace(left,right,1)==old,'diagnostics differ beyond sole InputResolved/input elapsed message'
 return dict(current=g.ref(current),prior47=g.ref(prior),all_rows_order_codes_severities_context_and_blocking_equal=True,sole_owned_conversion_time_message_bridge=True,current_actual_conversion_time=times[0],prior47_actual_conversion_time=times[1])
'''
folder=D/'successful-source-log-layout-prepared-Peer-49-03';folder.mkdir(exist_ok=False);deltas=[]
for before,after in names.items():
 src=D/before;raw=src.read_bytes();text=raw.decode('utf-8-sig')
 for a,b in names.items():text=text.replace(a,b)
 text=text.replace('successful-source-log-layout-prepared-Peer-49-02/prepared.json','successful-source-log-layout-prepared-Peer-49-03/prepared.json')
 if before.startswith('check-'):
  text=text.replace('import argparse,copy,importlib.util,json,re\n','import argparse,copy,importlib.util,json,re,math\n')
  anchor='def time_token(raw,prefix):\n';assert text.count(anchor)==1;text=text.replace(anchor,helper+anchor)
  anchor="diag=exact(g,source/'diagnostics.json',old/'diagnostics.json')";assert text.count(anchor)==1;text=text.replace(anchor,"diag=diagnostics_transfer(g,source/'diagnostics.json',old/'diagnostics.json')")
  anchor="'No new Native or scientific unit execution. Prior numerical proofs transfer only through exact physical/export/runtime equality.'"
  assert text.count(anchor)==1;text=text.replace(anchor,anchor+",'The one actual InputResolved/input conversion wall-time decimal is separately retained; all other diagnostic bytes/order/fields are exact47. No warning filtering.'")
 ast.parse(text);dest=D/after;assert not dest.exists();dest.write_text(text,encoding='utf-8',newline='\n')
 forward=''.join(difflib.unified_diff(raw.decode().splitlines(True),text.splitlines(True),fromfile=before,tofile=after));inverse=''.join(difflib.unified_diff(text.splitlines(True),raw.decode().splitlines(True),fromfile=after,tofile=before))
 fp=folder/(before+'.forward.diff');ip=folder/(before+'.inverse.diff');fp.write_text(forward,encoding='utf-8',newline='\n');ip.write_text(inverse,encoding='utf-8',newline='\n')
 deltas.append(dict(before=ref(src),after=ref(dest),forward=ref(fp),inverse=ref(ip)))
q.update(predecessor_prepared=ref(old),author_Source=ref(pathlib.Path(__file__)),preparation_correction='Root pre-execution finding: complete diagnostic byte equality was too strict for the actual InputResolved/input IDF conversion wall seconds. Only its exact info message numeric payload is bridged; actual finite nonnegative current/prior decimals are retained separately, every other diagnostic byte/row/code/severity/context/blocking state stays exact. Original02 retained unexecuted. Same two production proposals, plan and exact commands.')
for k,n in zip(['application_Source','launch_Source','checker_Source'],names.values(),strict=True):q[k]=ref(D/n)
ledger=folder/'helper-correction.json';ledger.write_text(json.dumps(dict(original_prepared=ref(old),unchanged_compiler_plan=q['complete_compiler_plan'],production_Source_changes=0,actual_invocations=0,deltas=deltas),indent=2)+'\n',encoding='utf-8',newline='\n');q['helper_correction']=ref(ledger)
p=folder/'prepared.json';p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))
for k in['application_Source','launch_Source','checker_Source','helper_correction']:print(k,json.dumps(q[k]))

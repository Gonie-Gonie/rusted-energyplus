"""Root-only read-only two-case evidence; no CLI, Native or test launches."""
from pathlib import Path
import argparse,copy,importlib.util,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def exact(g,a,b):
 assert a.exists()==b.exists(),(a,b)
 if not a.exists():return dict(both_absent=True,current_path=a.relative_to(R).as_posix(),prior47_path=b.relative_to(R).as_posix())
 x,y=g.ref(a),g.ref(b);assert(x['sha256'],x['bytes'])==(y['sha256'],y['bytes']),(a,b);return dict(current=x,prior47=y,whole_bytes_equal=True)
def time_token(raw,prefix):
 pattern=re.escape(prefix)+rb'([0-9]+hr [0-9]+min [ 0-9.]+sec)';m=list(re.finditer(pattern,raw));assert len(m)==1;v=m[0];return raw[:v.start(1)]+b'<actual elapsed runtime>'+raw[v.end(1):],v.group(1)
def transfer(g,source,old):
 files=[exact(g,source/('eplusrs.'+k),old/('eplusrs.'+k))for k in['eso','mtr','eio','rdd','mdd','shd','bnd','audit']]
 tables=[exact(g,source/('eplustbl.'+k),old/('eplustbl.'+k))for k in['csv','htm','tab','txt','xml']]
 csv=[exact(g,source/'results'/('source-'+k+'.csv'),old/'results'/('source-'+k+'.csv'))for k in['eso','mtr']]
 p,op=source/'results/source-reported-results.json',old/'results/source-reported-results.json';b=p.read_bytes();prior=op.read_bytes();nv,ov=json.loads(b),json.loads(prior)
 for stream in['eso','mtr']:
  assert Path(nv[stream]['path']).resolve()==(source/('eplusrs.'+stream)).resolve()and Path(ov[stream]['path']).resolve()==(old/('eplusrs.'+stream)).resolve()
  left,right=json.dumps(nv[stream]['path']).encode(),json.dumps(ov[stream]['path']).encode();assert b.count(left)==1;b=b.replace(left,right,1)
 assert b==prior,'JSON differs beyond exact two owner paths'
 now=copy.deepcopy(g.read(source/'run-summary.json')['rust_runtime']);before=g.read(old/'run-summary.json')['rust_runtime'];assert len(now['reported_streams'])==len(before['reported_streams'])==2
 for a,b in zip(now['reported_streams'],before['reported_streams'],strict=True):
  assert Path(a['owned_path']).resolve()==(source/Path(b['owned_path']).name).resolve();a['owned_path']=b['owned_path']
 assert now==before,'Runtime differs beyond exact two owner paths'
 return dict(physical_streams=files,tables=tables,whole_CSV=csv,current_JSON=g.ref(p),prior47_JSON=g.ref(op),whole_JSON_and_runtime_equal_after_two_exact_owner_path_bridges=True)
def case(g,q,app,plan,x):
 rp=R/x['receipt'];r=g.read(rp);assert r['exit_code']==0 and r['launch_error']is None and r['source_bytes_match_before_and_after']
 assert r['repository_before']==r['repository_after']and r['repository_before']['head']==g.BASE;g.snapshot(r,plan)
 cmd,_=g.command(x['case'],q);assert cmd==r['command'];assert Path(r['launch_environment_selected']['CARGO_TARGET_DIR']).resolve()==g.TARGET
 assert all(r['launch_environment_selected'].get(k)is None for k in['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_HOME'])
 source=R/x['output'];old=R/x['prior47_output'];summary=g.read(source/'run-summary.json');diags=g.read(source/'diagnostics.json')
 assert summary['status']=='success'and summary['exit_code']==0 and summary['oracle']is None and summary['comparison']is None
 assert not any(summary['config'][k]for k in['compare_oracle','oracle_baseline','dry_run'])and summary['rust_runtime']['execution']=='actual Source ManageSimulation successful through620'
 assert not any(v['severity']=='error'or v['blocking']for v in diags['diagnostics'])
 physics=transfer(g,source,old);diag=exact(g,source/'diagnostics.json',old/'diagnostics.json')
 end,err,console=source/'eplusrs.end',source/'eplusrs.err',source/'logs/source-console.log';eb,rb,cb=end.read_bytes(),err.read_bytes(),console.read_bytes()
 assert eb.count(b'\r\n')==eb.count(b'\n')==1 and re.fullmatch(rb'EnergyPlus Completed Successfully-- [0-9]+ Warning; [0-9]+ Severe Errors; Elapsed Time=[0-9]+hr [0-9]+min [ 0-9.]+sec\r\n',eb)
 assert rb.count(b'\r\n')==rb.count(b'\n')and rb.endswith(b'   ************* '+eb)
 ce,et=time_token(eb,b'Elapsed Time=');oe,_=time_token((old/'eplusrs.end').read_bytes(),b'Elapsed Time=');assert ce==oe
 cr,ert=time_token(rb,b'Elapsed Time=');orr,_=time_token((old/'eplusrs.err').read_bytes(),b'Elapsed Time=');assert cr==orr and et==ert
 cc,ct=time_token(cb,b'EnergyPlus Run Time=');oc,_=time_token((old/'eplusrs.ctf.log').read_bytes(),b'EnergyPlus Run Time=');assert cc==oc and ct==et
 assert not(source/'eplusrs.ctf.err').exists()and not(source/'eplusrs.ctf.log').exists();assert cb.endswith(b'EnergyPlus Completed Successfully.\n')
 # Actual JSON Cargo messages identify normal core artifacts; no invented recorder capture.
 cores={}
 for line in g.checked(r['stdout']).read_text(encoding='utf-8-sig').splitlines():
  if not line.startswith('{'):continue
  try:v=json.loads(line)
  except json.JSONDecodeError:continue
  if v.get('reason')!='compiler-artifact'or v['target']['name']not in['ep_runtime','ep_run','eplus-rs']:continue
  assert v['features']==[]and isinstance(v['fresh'],bool);paths=[Path(p).resolve()for p in v['filenames']];assert paths and all(p.is_relative_to(g.TARGET)and p.is_file()for p in paths)
  cores[v['target']['name']]=dict(fresh=v['fresh'],features=v['features'],files=[g.ref(p)for p in paths])
 assert set(cores)=={'ep_runtime','ep_run','eplus-rs'}
 return dict(case=x['case'],actual_receipt=g.ref(rp),actual_snapshot=r['source_snapshot'],all4525_archived_inputs_exact=True,summary=g.ref(source/'run-summary.json'),diagnostics=diag,whole47_physics_and_export_transfer=physics,primary_ERR=g.ref(err),primary_END=g.ref(end),verbatim_console_at_new_location=g.ref(console),old_duplicate_error_and_console_prefixes_absent=True,exactly_owned_elapsed_runtime_bridge=True,current_elapsed=et.decode(),same_ERR_END_console_elapsed=True,normal_core_artifacts=cores)
def main(a):
 spec=importlib.util.spec_from_file_location('layout49',D/'apply-successful-source-log-layout-Root-49.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 q,d,ar,app,plan=g.application(a.application);assert g.ref(Path(__file__))==q['checker_Source'];out=D/'Root-source-successful-log-layout-actual-review-49';assert not out.exists()
 rows=[case(g,q,app,plan,x)for x in q['cases']];g.whole(plan)
 result=dict(schema='src06-successful-source-log-layout-twoCLI-actual-review49.v1',accepted=True,findings=[],base_HEAD=g.BASE,application=ar,producer=q['draft'],independent_semantic_peer=q['independent_semantic_peer'],parent_P2_actual=q['parent_actual'],parent47_actual=q['prior47_actual'],complete_compiler_plan=q['complete_compiler_plan'],all4525_final_live_inputs_exact=True,Rust_sources=4512,actual_production_CLI_invocations=2,actual_test_bodies_executed=0,new_test_bodies=0,ordered_cases=rows,incremental_environment_qualification='Guard sets CARGO_INCREMENTAL=0; existing recorder omits that selected key. Exact authenticated launcher/guard prove intent, not a captured receipt value.',limits=['No new Native or scientific unit execution. Prior numerical proofs transfer only through exact physical/export/runtime equality.','Only A24 and B-NOLIMIT24 current normal commands; no current limit/long-duration rerun claimed.','Console elapsed and ERR/END elapsed are actual and retained. Only exact own-runtime payloads are bridged against47; no Native runtime normalization or full ancillary IO PASS.','Failure/Legacy branches are covered by the accepted semantic peer, not by these two successful runtime cases.'],author_Source=g.ref(Path(__file__)))
 out.mkdir();p=out/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);main(p.parse_args())

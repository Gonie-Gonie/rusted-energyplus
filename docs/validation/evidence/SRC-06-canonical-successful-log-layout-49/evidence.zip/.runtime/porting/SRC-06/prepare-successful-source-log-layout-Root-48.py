"""Private two-file output-layout proposal; never writes canonical Source."""
from pathlib import Path
import difflib, hashlib, json

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def main():
    parent = D / 'source-normal-completion-held-Audit-47/complete-final-compiler-Source-plan.json'
    assert ref(parent)['sha256'] == 'b7e8572d708ee1ad5562861f35524a27f1ffb2f4cbc23988e8203d3ed2f77aa9'
    rows = {x['path']: x for x in json.loads(parent.read_bytes())['entries']}
    out = D / 'successful-source-log-layout-draft-Root-48'
    assert not out.exists()
    changes = []
    n = 'crates/ep_run/src/ctf_initialization_outputs.rs'
    before = (R / n).read_bytes()
    old = b'    pub(crate) fn persist(&mut self, output_dir: &Path) -> Result<(), String> {\n'
    new = old + b'''        self.persist_after_runtime(output_dir, false)
    }

    /// Keep the Source console in the application log directory after actual
    /// completion. Its primary ERR already belongs to the successful Source
    /// file owner; failure and Legacy prefixes retain the original layout.
    pub(crate) fn persist_after_runtime(
        &mut self,
        output_dir: &Path,
        source_completed: bool,
    ) -> Result<(), String> {
'''
    assert before.count(old) == 1
    after = before.replace(old, new, 1)
    old = b'''            std::fs::write(output_dir.join(name), bytes)
                .map_err(|error| format!("failed to write {name}: {error}"))?;
'''
    new = b'''            if source_completed && name == "eplusrs.ctf.err" {
                continue;
            }
            let path = if source_completed && name == "eplusrs.ctf.log" {
                let logs = output_dir.join("logs");
                std::fs::create_dir_all(&logs)
                    .map_err(|error| format!("failed to create Source log directory: {error}"))?;
                logs.join("source-console.log")
            } else {
                output_dir.join(name)
            };
            std::fs::write(path, bytes)
                .map_err(|error| format!("failed to write {name}: {error}"))?;
'''
    assert after.count(old) == 1
    after = after.replace(old, new, 1)
    changes.append((n, before, after))
    n = 'crates/ep_run/src/pipeline.rs'
    before = (R / n).read_bytes()
    old = b'''        ctf_outputs
            .persist(&config.output_dir)
'''
    new = b'''        ctf_outputs
            .persist_after_runtime(
                &config.output_dir,
                matches!(&runtime_result, Ok(RuntimeExecutionOutcome::Source(_))),
            )
'''
    assert before.count(old) == 1
    changes.append((n, before, before.replace(old, new, 1)))
    for n, before, after in changes:
        assert hashlib.sha256(before).hexdigest() == rows[n]['final_sha256']
        assert len(before) == rows[n]['final_bytes']
    out.mkdir()
    files = []
    for n, before, after in changes:
        bp, ap = out / 'before' / n, out / 'proposed' / n
        bp.parent.mkdir(parents=True, exist_ok=True)
        ap.parent.mkdir(parents=True, exist_ok=True)
        bp.write_bytes(before)
        ap.write_bytes(after)
        fwd, inv = out / (Path(n).name + '.forward.diff'), out / (Path(n).name + '.inverse.diff')
        fwd.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile=n, tofile=n, n=3)).encode())
        inv.write_bytes(''.join(difflib.unified_diff(after.decode().splitlines(True), before.decode().splitlines(True), fromfile=n, tofile=n, n=3)).encode())
        files.append(dict(canonical_path=n, before=ref(bp), proposed=ref(ap), forward_diff=ref(fwd), inverse_diff=ref(inv)))
    draft = dict(schema='successful-source-console-layout-draft48.v1', status='PRIVATE_NOT_APPLIED_NOT_EXECUTED', parent_compiler_plan=ref(parent), files=files, normal_condition='Only an actual Ok(RuntimeExecutionOutcome::Source) after same620, wrapUp/End and completed own-file read. No new numerical or diagnostic calculation.', behavior='Successful Source primary ERR remains the actual file owner; duplicate logical prefix is not exported. Genuine buffered console is retained verbatim at logs/source-console.log. Original failure/Legacy persist call and all existing tests retain source_completed=false.', actual_invocations=0, author_Source=ref(Path(__file__)))
    p = out / 'draft.json'
    p.write_bytes((json.dumps(draft, indent=2) + '\n').encode())
    print(json.dumps(ref(p)))

if __name__ == '__main__':
    main()

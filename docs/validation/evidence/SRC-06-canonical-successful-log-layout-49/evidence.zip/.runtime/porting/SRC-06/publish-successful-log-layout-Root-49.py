"""Root-only finite two-CLI layout publication and exact Root document replacements.

No Source/scientific execution and no chronological document appends.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, zipfile
R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
PUBLIC = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-successful-log-layout-49'
BACK = D / 'Root-successful-log-layout-publication-49'
DOCS = {'energyplus_porting_plan/' + x for x in ['CHECKLIST.md', 'STATE_CONTRACTS.md', 'cards/SRC-06.md', 'README.md']}

def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)

def checked(x):
    p=(R/x['path']).resolve();assert p.is_relative_to(R)
    v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes'])),x['path']
    return p

def read(p):return json.loads(p.read_bytes())

def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))

def no_raw_environment(v):
    if isinstance(v,dict):
        assert 'full_explicit_environment' not in v
        for x in v.values():no_raw_environment(x)
    elif isinstance(v,list):
        for x in v:no_raw_environment(x)

def main(a):
    assert a.publish and not PUBLIC.exists() and not BACK.exists()
    tp=(R/a.template).resolve();t=read(tp)
    assert t['status']=='READY_FOR_ROOT_FULL_READ_AND_PUBLICATION' and t['publisher_Source']==ref(Path(__file__))
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==t['base_HEAD']
    actual=read(checked(t['actual_review']));draft=read(checked(t['producer']));application=read(checked(t['application']));peer=read(checked(t['independent_semantic_peer']))
    assert actual['accepted'] and not actual['findings'] and application['accepted'] and not application['findings']
    for k in ['producer','application','independent_semantic_peer','complete_compiler_plan']:assert actual[k]==t[k]
    assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==t['producer']
    assert actual['all4525_final_live_inputs_exact'] and actual['Rust_sources']==4512
    assert actual['actual_production_CLI_invocations']==2 and actual['actual_test_bodies_executed']==actual['new_test_bodies']==0
    assert application['changed_existing_sources']==len(draft['files'])==2 and application['new_sources']==0
    plan=read(checked(t['complete_compiler_plan']));assert (plan['inputs'],plan['Rust_sources'])==(4525,4512)
    assert [x['case'] for x in actual['ordered_cases']]==['A-24H','B-NOLIMIT-24H']
    for f in draft['files']:assert (R/f['canonical_path']).read_bytes()==checked(f['proposed']).read_bytes()
    for case in actual['ordered_cases']:
        assert case['all4525_archived_inputs_exact'] and case['old_duplicate_error_and_console_prefixes_absent'] and case['same_ERR_END_console_elapsed']
        assert case['whole47_physics_and_export_transfer']['whole_JSON_and_runtime_equal_after_two_exact_owner_path_bridges']
        assert all(x.get('whole_bytes_equal') or x.get('both_absent') for x in case['whole47_physics_and_export_transfer']['physical_streams'])
        assert all(x['whole_bytes_equal'] for x in case['whole47_physics_and_export_transfer']['whole_CSV'])
        assert case['whole47_physics_and_export_transfer']['tables']['all_nonmetadata_lines_whole_exact']
        receipt=read(checked(case['actual_receipt']));assert receipt['exit_code']==0 and receipt['repository_before']==receipt['repository_after']
        assert all(not v['features'] for v in case['normal_core_artifacts'].values())
    pp=R/'energyplus_porting_plan/plan.json';before=pp.read_bytes();before_value=json.loads(before)
    assert before==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
    previous=read(checked(t['previous_checkpoint']));assert (previous['A'],previous['B'])==('14/54','14/64')
    documents=[]
    for op in t['doc_replacements']:
        name=op['canonical_path'];assert name in DOCS and name not in [x[0] for x in documents]
        old=checked(op['before']).read_bytes();new=checked(op['proposed']).read_bytes()
        assert (R/name).read_bytes()==old==subprocess.check_output(['git','show',head+':'+name],cwd=R)
        assert '\ufffd' not in old.decode('utf8','strict') and '\ufffd' not in new.decode('utf8','strict')
        assert new!=old
        documents.append((name,old,new,op))
    files={}
    def add(row):
        p=checked(row);v=ref(p)
        assert p.suffix.lower() not in ['.zip','.exe','.dll','.a','.obj','.map','.rlib','.rmeta'] and v['bytes']<64*1024*1024
        if p.suffix=='.json':no_raw_environment(read(p))
        assert v['path'] not in files or files[v['path']]==v
        files[v['path']]=v
    for row in t['finite_archive_inputs']+[ref(tp),ref(Path(__file__)),t['actual_review']]:add(row)
    for _,_,_,op in documents:
        for key in ['before','proposed','forward_diff','inverse_diff']:
            if key in op:add(op[key])
    for key in ['doc_replacement_author_Source','doc_replacement_manifest']:
        if t.get(key):add(t[key])
    assert sum(x['bytes'] for x in files.values())<64*1024*1024
    PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(before)
    zp=PUBLIC/'evidence.zip'
    with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,row in sorted(files.items()):z.write(checked(row),arcname=name)
    with zipfile.ZipFile(zp) as z:
        assert z.testzip() is None and set(z.namelist())==set(files)
        for name,row in files.items():
            b=z.read(name);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
    mp=PUBLIC/'manifest.json';write(mp,dict(schema='src06-successful-log-layout49-finite-evidence.v1',archive=ref(zp),entries=[v for _,v in sorted(files.items())],scope=t['finite_archive_scope']))
    summary=dict(t['summary_template'])
    summary.update(schema='src06-canonical-successful-log-layout49.v1',base_HEAD=head,A='14/54',B='14/64',gate_changes=False,policy_changes=0,final_checkpoint=False,producer=t['producer'],independent_semantic_peer=t['independent_semantic_peer'],application=t['application'],Root_actual_review=t['actual_review'],complete_compiler_plan=t['complete_compiler_plan'],actual_production_CLI_invocations=2,actual_test_bodies_executed=0,new_test_bodies=0,ordered_cases=actual['ordered_cases'],selected_Source_files=[x['canonical_path'] for x in draft['files']],parent47_actual=actual['parent47_actual'],parent_P2_actual=actual['parent_P2_actual'],overall_ancillary_IO_PASS=False,limitations=actual['limits'],incremental_environment_qualification=actual['incremental_environment_qualification'],archive=ref(zp),archive_manifest=ref(mp),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
    sp=PUBLIC/'summary.json';write(sp,summary)
    proofs=[]
    for name,old,new,op in documents:
        saved=BACK/'docs-before'/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(old)
        p=R/name;assert p.read_bytes()==old;p.write_bytes(new)
        assert p.read_bytes()==checked(op['proposed']).read_bytes() and saved.read_bytes()==checked(op['before']).read_bytes()
        proofs.append(dict(path=name,before=ref(saved),proposed=op['proposed'],after=ref(p),exact_whole_replacement=True,exact_inverse_available_from_before=True))
    after=json.loads(before);task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_successful_log_layout_49';assert key not in task
    task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=ref(sp)['sha256'],size_bytes=sp.stat().st_size)
    inv=json.loads(json.dumps(after));del next(x for x in inv['tasks'] if x['id']=='SRC-06')[key];assert inv==before_value
    assert pp.read_bytes()==before;write(pp,after)
    rp=BACK/'publication-readback.json';write(rp,dict(status='PUBLISHED_PENDING_ROOT_QA_AND_COMMIT',summary=ref(sp),archive=ref(zp),archive_manifest=ref(mp),archive_entries=len(files),docs=proofs,chronological_doc_appends=0,plan_before=ref(BACK/'plan-before.json'),plan_after=ref(pp),one_SRC06_key_inverse=True,base_HEAD=head,actual_production_CLI_invocations=2,actual_test_bodies_executed=0,Cargo_Native_or_test_execution=False,author_Source=ref(Path(__file__))))
    print(json.dumps(ref(rp)))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--template',required=True);ap.add_argument('--publish',action='store_true');main(ap.parse_args())

"""Root-only two-Source application. Importing this module performs no action."""
from pathlib import Path
import argparse,ast,hashlib,json,os,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
BASE='dcb9dfe4a8e610affd883ef9211be31d54a1bd8a'
PREP=D/'successful-source-log-layout-prepared-Peer-49-04/prepared.json'
OUT=D/'Root-successful-source-log-layout-application-49'
CASES=['A-24H','B-NOLIMIT-24H']
TARGET=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(x):
 p=(R/x['path']).resolve();assert p.is_relative_to(R);a=ref(p);assert a['sha256']==x['sha256']and a['bytes']==x.get('bytes',a['bytes']),(x,a);return p
def read(p):return json.loads(p.read_bytes())
def argument(s):
 p,h=s.rsplit('#',1);return ref(checked(dict(path=p,sha256=h)))
def inventory():return {p.relative_to(R).as_posix()for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix()for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
def whole(plan):
 rows={x['path']:x for x in plan['entries']};assert(len(rows),plan['inputs'],plan['Rust_sources'])==(4525,4525,4512);assert inventory()==set(rows)
 for n,x in rows.items():
  a=ref(R/n);assert(a['sha256'],a['bytes'])==(x['final_sha256'],x['final_bytes']),n
 return rows
def literal():
 p=D/'seal-compact-annual-daygroup-helper-Peer-01.py';fn=next(x for x in ast.parse(p.read_text(encoding='utf-8-sig')).body if isinstance(x,ast.FunctionDef)and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<accepted-literal-only>','exec'),ns);return ns['apply_literal']
def authority():
 q=read(PREP);assert q['status']=='READY_ROOT_ONLY_NOT_EXECUTED'and q['base_HEAD']==BASE
 for k in ['application_Source','launch_Source','checker_Source','record_command_Source']:checked(q[k])
 assert ref(Path(__file__))==q['application_Source']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
 d=read(checked(q['draft']));p=read(checked(q['independent_semantic_peer']));assert p['accepted']and not p['findings']and p['reviewed_draft']==q['draft']
 assert {f['canonical_path']:f['proposed']for f in p['files']}=={f['canonical_path']:f['proposed']for f in d['files']}
 prior=read(checked(q['parent_actual']));assert prior['accepted']and not prior['findings']and prior['all4525_live_and_archived_inputs_exact']and prior['complete_compiler_plan']==q['parent_compiler_plan']
 return q,d
def environment():
 e=dict(os.environ);assert TARGET.is_dir();e['CARGO_TARGET_DIR']=str(TARGET);e['CARGO_INCREMENTAL']='0'
 for k in('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_HOME'):assert e.get(k)is None,k
 return e
def application(spec):
 q,d=authority();ar=argument(spec);assert checked(ar)==(OUT/'receipt.json').resolve();a=read(checked(ar));assert a['accepted']and not a['findings']and a['base_HEAD']==BASE and a['prepared']==ref(PREP)and a['complete_compiler_plan']==q['complete_compiler_plan']and a['all4525_final_inputs_exact']
 plan=read(checked(a['complete_compiler_plan']));whole(plan);return q,d,ar,a,plan
def snapshot(receipt,plan):
 snap=read(checked(receipt['source_snapshot']));rows={x['historical_path']:x for x in snap['files']};assert set(rows)=={x['path']for x in plan['entries']}
 for v in plan['entries']:
  a=ref(checked(rows[v['path']]['archive']));assert(a['sha256'],a['bytes'])==(v['final_sha256'],v['final_bytes']),v['path']
def command(case,q):
 x=next(x for x in q['cases']if x['case']==case);old=read(checked(x['prior47_receipt']));assert old['exit_code']==0 and old['launch_error']is None and old['source_bytes_match_before_and_after']
 cmd=list(old['command']);assert cmd[:3]==['cargo','run','--locked']and cmd[cmd.index('--bin')+1]=='eplus-rs'and cmd[cmd.index('--porting-scope')+1]==case[0]
 assert not{'--features','test','--all-targets','--oracle-baseline','--compare-oracle','--hours','--dry-run'}&set(cmd)
 ids=[i for i,v in enumerate(cmd)if v.lower().endswith('.idf')];assert len(ids)==1 and Path(cmd[ids[0]]).resolve()==checked(x['input'])
 assert Path(cmd[cmd.index('--weather')+1]).resolve()==checked(x['weather'])
 cmd[cmd.index('--output-dir')+1]=(R/x['output']).resolve().as_posix();return cmd,x
def main(a):
 assert a.execute,'Root --execute required';q,d=authority();assert not OUT.exists();assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=R)==b''
 parent=read(checked(q['parent_compiler_plan']));whole(parent);plan=read(checked(q['complete_compiler_plan']));overlay={x['path']:dict(x)for x in parent['entries']};apply=literal();saved={}
 for f in d['files']:
  n=f['canonical_path'];before=checked(f['before']).read_bytes();after=checked(f['proposed']).read_bytes();assert(R/n).read_bytes()==before
  assert subprocess.check_output(['git','show',BASE+':'+n],cwd=R)==before
  assert apply(before,checked(f['forward_diff']).read_bytes())==after and apply(after,checked(f['inverse_diff']).read_bytes())==before
  saved[n]=before;overlay[n].update(final_sha256=f['proposed']['sha256'],final_bytes=f['proposed']['bytes'],source=f['proposed'],origin='accepted successful Source log-layout49')
 assert plan['entries']==[overlay[x['path']]for x in parent['entries']]
 OUT.mkdir();written=[]
 try:
  for f in d['files']:
   n=f['canonical_path'];p=OUT/'before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(saved[n]);(R/n).write_bytes(checked(f['proposed']).read_bytes());written.append(n)
  whole(plan)
  receipt=dict(schema='src06-successful-source-log-layout-application49.v1',accepted=True,findings=[],base_HEAD=BASE,prepared=ref(PREP),producer=q['draft'],independent_semantic_peer=q['independent_semantic_peer'],parent_actual=q['parent_actual'],parent_compiler_plan=q['parent_compiler_plan'],complete_compiler_plan=q['complete_compiler_plan'],all4525_before_inputs_exact=True,selected2_before_Git_wholes_exact=True,all4525_final_inputs_exact=True,changed_existing_sources=2,new_sources=0,actual_test_or_CLI_invocations=0,files=d['files'],author_Source=ref(Path(__file__)))
  p=OUT/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))
 except BaseException:
  for n in written:(R/n).write_bytes(saved[n])
  raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');main(p.parse_args())

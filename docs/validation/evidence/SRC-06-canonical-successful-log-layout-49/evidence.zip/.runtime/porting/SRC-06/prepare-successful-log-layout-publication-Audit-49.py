"""Private finite Source49 archive/template preparation; never publishes."""
from pathlib import Path
import ast, difflib, hashlib, json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'successful-log-layout-publication-draft-Audit-49-01'

def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)

def checked(v):
    p=(R/v['path']).resolve();a=ref(p)
    assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',v.get('size_bytes',a['bytes'])),v['path'];return p

def write(p,v):p.write_text(json.dumps(v,ensure_ascii=True,indent=2)+'\n',encoding='utf8',newline='\n');return ref(p)

assert not O.exists()
actualp=D/'Root-source-successful-log-layout-actual-review-49/review.json'
assert ref(actualp)['sha256']=='58a4af24ebf043ce5bc6654818f5e161d08d7914ffb6d471998eaba4d73eac51'
actual=json.loads(actualp.read_bytes());assert actual['accepted'] and not actual['findings']
app=json.loads(checked(actual['application']).read_bytes());draft=json.loads(checked(actual['producer']).read_bytes());peer=json.loads(checked(actual['independent_semantic_peer']).read_bytes())
prepared=json.loads(checked(app['prepared']).read_bytes())
publisher=D/'publish-successful-log-layout-Root-49.py';ast.parse(publisher.read_bytes())
rows={};exclusions=[]

def no_raw_env(v):
    if isinstance(v,dict):
        assert 'full_explicit_environment' not in v
        for x in v.values():no_raw_env(x)
    elif isinstance(v,list):
        for x in v:no_raw_env(x)

def add(v):
    p=checked(v);assert p.is_relative_to(R)
    a=ref(p);assert p.suffix.lower() not in ['.zip','.exe','.dll','.obj','.a','.map','.rlib','.rmeta'] and a['bytes']<64*1024*1024
    assert 'frozen-environment' not in p.name.casefold()
    if p.suffix=='.json':no_raw_env(json.loads(p.read_bytes()))
    assert a['path'] not in rows or rows[a['path']]==a
    rows[a['path']]=a

def refs(v,skip=()):
    if isinstance(v,dict):
        if 'path' in v and 'sha256' in v:add(v)
        else:
            for key,x in v.items():
                if key not in skip:refs(x,skip)
    elif isinstance(v,list):
        for x in v:refs(x,skip)

# Only direct bounded evidence. Never recursively load parent archives or raw
# scientific fixture/capture references, and never traverse binary file refs.
for p in [actualp,publisher,Path(__file__),checked(app['prepared'])]:add(ref(p))
refs(actual,skip={'normal_core_artifacts'})
refs(app);refs(draft);refs(peer)
for key in ['application_Source','launch_Source','checker_Source','record_command_Source','author_Source','helper_correction','table_metadata_authority','parent_actual','parent_compiler_plan','prior47_actual']:
    refs(prepared[key])
for case in prepared['cases']:
    refs({k:case[k] for k in ['prior47_receipt','prior47_readback','input']})
# Read actual CLI receipts to include their real stdout/stderr and timing
# records, but not their compiler binary captures or old Source archive trees.
for case in actual['ordered_cases']:
    r=json.loads(checked(case['actual_receipt']).read_bytes())
    for key in ['stdout','stderr']:
        if key in r:refs(r[key])
# All small private preparation versions/corrections and their exact helper
# Sources are retained. These are pre-execution metadata corrections, not
# additional successful or failed production CLI invocations.
for folder in sorted(D.glob('successful-source-log-layout-prepared-Peer-49*')):
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in ['.json','.diff','.stderr']:add(ref(p))
for stem in ['apply-successful-source-log-layout-Root-49','launch-successful-source-log-layout-Root-49','check-successful-source-log-layout-Root-49','prepare-successful-source-log-layout-Peer-49']:
    for p in sorted(D.glob(stem+'*.py')):add(ref(p))
for p in [D/'prepare-successful-source-log-layout-Root-48.py',D/'publish-full-predictor-parent-Root-P2.py',D/'publish-normal-completion-Root-47.py']:
    add(ref(p))
prior48=D/'Root-full-predictor-parent-publication-48/publication-readback.json'
previous=json.loads(prior48.read_bytes())['summary'];add(ref(prior48));add(previous)
assert len(draft['files'])==2 and actual['actual_production_CLI_invocations']==2
assert actual['actual_test_bodies_executed']==actual['new_test_bodies']==0
total=sum(x['bytes'] for x in rows.values());assert total<64*1024*1024
O.mkdir()
for p in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md','README.md']:
    raw=(R/'energyplus_porting_plan'/p).read_bytes();assert '\ufffd' not in raw.decode('utf8')
template=dict(schema='src06-successful-log-layout49-publication-template.v1',status='DRAFT_AWAITING_ROOT_WHOLE_DOCUMENT_REPLACEMENT_REFS',base_HEAD=actual['base_HEAD'],publisher_Source=ref(publisher),actual_review=ref(actualp),application=actual['application'],producer=actual['producer'],independent_semantic_peer=actual['independent_semantic_peer'],complete_compiler_plan=actual['complete_compiler_plan'],previous_checkpoint=previous,doc_replacements=[],doc_replacement_author_Source=None,doc_replacement_manifest=None,chronological_doc_appends=0,doc_operation_contract=dict(allowed_canonical_paths=['energyplus_porting_plan/'+x for x in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md','README.md']],required_fields=['canonical_path','before','proposed'],optional_fields=['forward_diff','inverse_diff'],before_must_equal_current_and_HEAD=True,proposed_exact_UTF8_bytes=True,whole_inverse_from_saved_before=True,author='Root supplies compact replacements; no document prose authored by this preparation.'),finite_archive_scope='Two existing Source layout changes and actual A24/B-NOLIMIT24 normal CLIs only. Exact old/new Sources, independent semantic review, preparation corrections, actual receipts/logs/ERR/END and precise whole47 physical/CSV/JSON/runtime transfers. No new Native or scientific unit; no prior archive recursion, binaries, full environments, old scientific fixtures or long-duration output trees.',finite_archive_inputs=sorted(rows.values(),key=lambda x:x['path']),summary_template=dict(status='Successful Source log layout verified by two actual normal CLIs; numerical proofs inherited only through exact transfers.',behavior='After a real successful Source completion and own-file read, retain the primary Source ERR, omit its duplicate logical-prefix error export, and move the unchanged buffered console bytes to logs/source-console.log. Failure and Legacy paths retain the old writer behavior.',existing_Source_changes=2,new_Source_files=0,actual_production_CLI_invocations=2,actual_test_bodies_executed=0,new_test_bodies=0,current_cases=['A-24H','B-NOLIMIT-24H'],genuine_current_elapsed={c['case']:c['current_elapsed'] for c in actual['ordered_cases']},elapsed_policy='Actual ERR/END/console elapsed bytes remain retained. The only old-versus-current elapsed bridge belongs to the same Source runtime output; no Native elapsed substitution or blanket normalization.',normal_features=[],scientific_unit_execution_claim=False,current_limit_or_long_duration_reexecution_claim=False,overall_ancillary_IO_PASS=False,scope_status='A14/54 and B14/64 gates unchanged; this is not a final checkpoint.',document_policy='No chronological appends. Exact compact replacements are supplied by Root and receive full before/proposed byte custody.'),author_Source=ref(Path(__file__)))
tp=O/'template.json';write(tp,template)
parent=D/'publish-normal-completion-Root-47.py'
for name,a,b in [('publisher.forward.diff',parent.read_text(encoding='utf8'),publisher.read_text(encoding='utf8')),('publisher.inverse.diff',publisher.read_text(encoding='utf8'),parent.read_text(encoding='utf8'))]:
    (O/name).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='accepted47' if name.endswith('forward.diff') else 'layout49',tofile='layout49' if name.endswith('forward.diff') else 'accepted47')),encoding='utf8',newline='')
manifest=dict(schema='src06-successful-log-layout49-private-publication-preparation.v1',status='PRIVATE_UNEXECUTED_AWAITING_ROOT_DOC_REFS_AND_FULL_READ',template=ref(tp),publisher_Source=ref(publisher),accepted_engine_lineage=[ref(parent),ref(D/'publish-full-predictor-parent-Root-P2.py')],publisher_forward=ref(O/'publisher.forward.diff'),publisher_inverse=ref(O/'publisher.inverse.diff'),actual_review=ref(actualp),finite_entries=len(rows),finite_uncompressed_bytes=total,publication_or_document_mutations=False,Source_or_Native_or_Cargo_execution=False,author_Source=ref(Path(__file__)))
print(json.dumps(dict(manifest=write(O/'manifest.json',manifest),template=ref(tp),publisher=ref(publisher),finite_entries=len(rows),finite_uncompressed_bytes=total)))

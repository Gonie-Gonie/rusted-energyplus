"""Restore genuine cfg-factory output-open phase; no expected fixture value used."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0';O=D/'source-P1-open-output-fix-Peer-53'
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert all(ref(p)[k]==v[k] for k in ['path','sha256','bytes'] if k in v);return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();prior_path=D/'source-P1-Node-shape-fix-Peer-52/manifest.json';pm=read(prior_path);row=pm['files'][0];name=row['canonical_path']
 before=checked(row['proposed']).read_bytes();assert (R/name).read_bytes()==before
 a=before.decode();b=a;needle='        let mut eio = Vec::new();';replacement='''        // Genuine init_state -> OpenOutputFiles precedes GetProjectData.
        // The cold version string is actual owner input, not expected output.
        let output_header = format!("Program Version,{}\\n", state.version_string);
        let mut eio = output_header.as_bytes().to_vec();
        let eso = output_header.into_bytes();'''
 assert b.count(needle)==1;b=b.replace(needle,replacement);assert b.count('            eso: Vec::new(),')==1;b=b.replace('            eso: Vec::new(),','            eso,')
 assert b.replace(replacement,needle).replace('            eso,','            eso: Vec::new(),')==a
 target=O/'proposed'/name;target.parent.mkdir(parents=True);target.write_text(b,encoding='utf-8',newline='\n');diffs={}
 for key,x,y in [('forward_diff',a,b),('inverse_diff',b,a)]:
  p=O/(key+'.diff');p.write_text(''.join(difflib.unified_diff(x.splitlines(keepends=True),y.splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');diffs[key]=ref(p)
 parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
 (O/'syntax.stdout.rs').write_bytes(parse.stdout);(O/'syntax.stderr.txt').write_bytes(parse.stderr)
 authorities=[]
 for path,first,last in [('src/EnergyPlus/Data/EnergyPlusData.cc',840,857),('src/EnergyPlus/SimulationManager.hh',103,111),('src/EnergyPlus/SimulationManager.cc',1734,1762),('src/EnergyPlus/DataStringGlobals.hh',127,137),('src/EnergyPlus/IOFiles.cc',244,252)]:
  p=N/path;whole=p.read_bytes();assert subprocess.check_output(['git','-C',str(N),'show','HEAD:'+path])==whole
  e=O/'Native'/path;e.parent.mkdir(parents=True,exist_ok=True);e=e.with_name(e.name+f'.{first}-{last}.txt');e.write_bytes(b''.join(whole.splitlines(keepends=True)[first-1:last]));authorities.append(dict(Native_path=path,whole=ref(p),first=first,last=last,extent=ref(e)))
 parent_ref=pm['complete_proposed_compiler_Source_plan'];plan=read(checked(parent_ref));final=copy.deepcopy(plan);fr=next(x for x in final['entries'] if x['path']==name);fr.update(source=ref(target),final_sha256=ref(target)['sha256'],final_bytes=ref(target)['bytes'],origin='cfg-only genuine OpenOutputFiles stream initial phase before project getter')
 final['schema']='src06-P1-real-output-open-plan53.v1';final['prior_complete_compiler_Source_plan']=parent_ref;fp=save(O/'complete-proposed-compiler-Source-plan.json',final)
 fail_path=D/'canonical-source-purchased-air-gap-cohort-Root-52/receipt.json';failed=read(fail_path);assert failed['exit_code']==101 and failed['source_bytes_match_before_and_after'];err=checked(failed['stderr']).read_bytes();assert b'setup.reports.eio exact observed value' in err
 native=read(checked(pm['external_fixtures_unchanged'][0]))['native_output']['groups']['purchased_air'];all_eio=[]
 for case in native['cases']:
  snapshots=[case['setup']]
  for step in case['steps']:
   snapshots.extend([step['entry'],step['exit']]);prefix=step['actual_caller_InitZoneEquipment_prefix']
   if prefix is not None:snapshots.extend([prefix['entry'],prefix['exit']])
  for snapshot in snapshots:
   value=snapshot['reports']['eio'];assert value.startswith('Program Version,\n') and value.count('Program Version,\n')==1;all_eio.append(value)
 proof=save(O/'initial-stream-provenance.json',dict(Native_authorities=authorities,actual_Native_factory=ref(D/'purchased-air-native-TU-draft-Audit-02/purchased_air_batch.cpp'),
  Source_contexts=[ref(R/'crates/ep_runtime/src/heat_balance/source_initialization.rs'),ref(R/'crates/ep_runtime/src/heat_balance/error_backend.rs')],
  chain='make_factory calls s.init_state; EnergyPlusData840 dispatches SimulationManagerData107 -> OpenOutputFiles1747 resets StdOutputRecordCount then prints code-literal Program Version,{actual cold version} to ESO/EIO/MTR/BND before GetProjectData.',
  Source_factory_correction='Only represented EIO/ESO streams initialized from the code-literal writer plus same Source state.version_string before project getter; no fixture value enters the factory. P1 has no MTR/BND output member. Actual ancillary standard record counter remains constructor0.',
  open_as_stringstream_does_not_write_header=True,all244_observed_EIO_snapshots=len(all_eio),exact_single_header_every_snapshot=True,header_is_code_derived_not_captured_numeric_observation=True))
 manifest=save(O/'manifest.json',dict(schema='src06-P1-genuine-output-open-phase-fix.v1',status='FROZEN_PRIVATE_INDEPENDENT_PEER_PENDING',files=[dict(canonical_path=name,before=row['proposed'],proposed=ref(target),**diffs)],
  prior_manifest=ref(prior_path),prior_compiler_plan=parent_ref,complete_proposed_compiler_Source_plan=fp,compiler_inputs=4534,Rust_sources=4521,actual_failed_P1_setup=ref(fail_path),actual_Surface50_pass=pm['actual_Surface50_pass'],original_full_Source50_peer=pm['original_full_Source50_peer'],
  independent_Node52_peer=ref(D/'Peer-P1-Node-shape-review-Audit-52/review.json'),initial_stream_provenance=proof,external_fixtures_unchanged=pm['external_fixtures_unchanged'],
  correction='Restore genuine cfg factory output-open header for represented EIO/ESO at actual init_state phase. Same current production methods/writers and all strict state/values/bit assertions unchanged; no expected-derived initialization.',Surface50_reuse_bridge=pm['Surface50_reuse_bridge'],
  syntax=dict(exit=0,stdout=ref(O/'syntax.stdout.rs'),stderr=ref(O/'syntax.stderr.txt'),qualification='syntax only'),no_Cargo_Native_or_canonical_execution=True,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,plan=fp,Source=ref(target),provenance=proof)))
if __name__=='__main__':main()

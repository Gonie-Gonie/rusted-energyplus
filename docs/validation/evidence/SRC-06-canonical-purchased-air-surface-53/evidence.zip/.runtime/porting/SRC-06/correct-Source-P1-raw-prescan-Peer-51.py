"""Private authentic lexical pre-scan association correction; no production or expected-state edit."""
from pathlib import Path
import copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-P1-raw-prescan-fix-Peer-51'
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert ref(p)==v;return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir()
 parent_path=D/'source-P1-Surface-coherent-draft-Peer-50/complete-proposed-compiler-Source-plan.json';parent=read(parent_path)
 name='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs'
 row=next(x for x in parent['entries'] if x['path']==name);before=checked(row['source']).read_bytes();assert (R/name).read_bytes()==before
 a=before.decode('utf-8');b=a
 needle='    Ok((out, prescan))\n}\nfn identity_model('
 assert b.count(needle)==1
 b=b.replace(needle,'''    // Production reporting_prescan::resolve walks raw object maps lexically.
    // Getter rows above retain their genuine IDF order; these raw pre-scan
    // associations are distinct and must match SelectedInputProcessor shapes.
    prescan.variables.sort_by(|a, b| a.object_name.cmp(&b.object_name));
    prescan.summaries.sort_by(|a, b| a.object_name.cmp(&b.object_name));
    Ok((out, prescan))
}
fn identity_model(''')
 needle='        let mut source = Box::new(Factory::new(definitions, definition)?);'
 assert b.count(needle)==1
 b=b.replace(needle,'''        let factory_name = text(member(definition, "name")?)?;
        let mut source = Box::new(Factory::new(definitions, definition).map_err(|error| {
            invalid(&format!("Source P1 factory {factory_name} phase Factory::new/preparation: {error}"))
        })?);''')
 # Reverse only the input-association fix and contextual error annotation.
 inverse=b
 inserted=b[b.index('    // Production reporting_prescan::resolve walks'):b.index('    Ok((out, prescan))')]
 inverse=inverse.replace(inserted,'',1)
 wrapped='''        let factory_name = text(member(definition, "name")?)?;
        let mut source = Box::new(Factory::new(definitions, definition).map_err(|error| {
            invalid(&format!("Source P1 factory {factory_name} phase Factory::new/preparation: {error}"))
        })?);'''
 inverse=inverse.replace(wrapped,needle,1);assert inverse==a
 target=O/'proposed'/name;target.parent.mkdir(parents=True);target.write_text(b,encoding='utf-8',newline='\n')
 parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
 (O/'syntax.stdout.rs').write_bytes(parse.stdout);(O/'syntax.stderr.txt').write_bytes(parse.stderr)
 diffs={}
 for key,x,y in [('forward_diff',a,b),('inverse_diff',b,a)]:
  p=O/(key+'.diff');p.write_text(''.join(difflib.unified_diff(x.splitlines(keepends=True),y.splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');diffs[key]=ref(p)
 source_input_path=D/'source-purchased-air-gap-scaffold-Peer-01/input-only.json';input_only=read(source_input_path);proof=[]
 for factory in input_only['factories']:
  families=[]
  for family in ['Output:Variable','Output:Table:SummaryReports']:
   raw=factory['raw'].get(family,{})
   source_shapes=sorted(raw)
   idf=factory['object_order'].get(family,[])
   assert set(idf)==set(source_shapes) and len(set(idf))==len(idf)
   corrected=sorted(idf);assert corrected==source_shapes
   families.append(dict(family=family,actual_raw_lexical_names=source_shapes,old_IDF_getter_order=idf,corrected_pre_scan_order=corrected,changed=corrected!=idf,
       all_actual_fields_untouched=True,real_getter_row_order_untouched=True))
  proof.append(dict(factory=factory['name'],families=families))
 pp=save(O/'all4-raw-association-proof.json',dict(input_only=ref(source_input_path),factories=proof,association='Same actual raw membership/fields; only pre-scan vector lexical association matches production resolver/BTreeMap and retained family-shape order. Report getter row vector retains IDF order, which is independently consumed later.',Native_expected_read_or_reconstructed=False))
 final=copy.deepcopy(parent)
 fr=next(x for x in final['entries'] if x['path']==name);fr.update(final_sha256=ref(target)['sha256'],final_bytes=ref(target)['bytes'],source=ref(target),origin='cfg-only actual raw lexical pre-scan association correction after first setup failure')
 final['schema']='src06-Source-P1-lexical-prescan-plan51.v1';final['prior_complete_compiler_Source_plan']=ref(parent_path)
 plan=save(O/'complete-proposed-compiler-Source-plan.json',final)
 failed_path=D/'canonical-source-gap-batch-purchased_air-Root-50/receipt.json';failed=read(failed_path);assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after']
 stderr=(R/failed['stderr']['path']).read_bytes();assert hashlib.sha256(stderr).hexdigest()==failed['stderr']['sha256'] and b'raw lexical object association' in stderr
 surface_path=D/'canonical-source-gap-batch-surface-Root-50/receipt.json';surface=read(surface_path);assert surface['exit_code']==0 and surface['source_bytes_match_before_and_after']
 contexts=[R/'crates/ep_runtime/src/heat_balance/source_output_prescan.rs',R/'crates/ep_run/src/ordinary_input_processor/reporting_prescan.rs',R/'crates/ep_runtime/src/heat_balance/selected_input_processor.rs']
 manifest=save(O/'manifest.json',dict(schema='src06-P1-real-raw-prescan-association-fix.v1',status='FROZEN_PRIVATE_INDEPENDENT_PEER_PENDING',
  files=[dict(canonical_path=name,before=row['source'],proposed=ref(target),**diffs)],
  actual_failed_P1_setup=ref(failed_path),actual_Surface50_pass=ref(surface_path),original_full_Source50_peer=ref(D/'Peer-coherent-Source50-join-review-Audit-01/review.json'),
  prior_compiler_plan=ref(parent_path),complete_proposed_compiler_Source_plan=plan,compiler_inputs=4534,Rust_sources=4521,
  static_actual_association_proof=pp,actual_resolver_and_validator_contexts=[ref(x) for x in contexts],
  root_cause='The P1 cfg factory reused IDF getter ordering for raw direct-JSON pre-scan association. Production reporting_prescan::resolve iterates actual raw BTreeMap lexically; SourceOutputPreScan::validate_names requires that precise shape order. All four real OutputVariable families have nonlexical synthetic IDF names (e.g. ordinal10 vs2).',
  actual_correction='Only variables/summaries raw pre-scan vectors sorted by their actual raw object_name; real report getter vector/object_order/fields/casing/statistics unchanged. Input names/membership/schema/values come from genuine raw ingress. No validation disabled.',
  added_failure_context='Factory name plus Factory::new/preparation phase in returned setup errors only, without writing scientific/error-backend owner state.',
  prior_setup_failure_is_not_a_physics_mismatch=True,Surface50_reuse_bridge='Single changed P1-only cfg child is called only purchased_air branch. Shared main, surface dispatch and all13 Surface bodies/inputs/fixture/helpers unchanged; Surface50 actual55-record pass is retained without rerun.',
  external_fixtures_unchanged=[ref(D/'source-purchased-air-runtime-fixture-Peer-P1-01/fixture.json'),ref(D/'source-Surface-hub-fixture-Outer-01/surface.fixture.json')],
  syntax=dict(exit=0,stdout=ref(O/'syntax.stdout.rs'),stderr=ref(O/'syntax.stderr.txt'),qualification='syntax only; no contextual execution'),
  no_scientific_state_formula_expected_or_production_source_change=True,no_Cargo_Native_or_canonical_execution=True,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,plan=plan,proposed=ref(target))))
if __name__=='__main__':main()

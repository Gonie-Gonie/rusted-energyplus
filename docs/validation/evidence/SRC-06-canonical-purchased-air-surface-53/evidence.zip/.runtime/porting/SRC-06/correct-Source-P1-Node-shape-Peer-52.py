"""Private one-line observer shape correction; genuine owner ordinal bounds only."""
from pathlib import Path
import copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-P1-Node-shape-fix-Peer-52'
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert all(ref(p)[k]==v[k] for k in ('path','sha256','bytes') if k in v);return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir()
 prior=D/'source-P1-raw-prescan-fix-Peer-51/manifest.json';pm=read(prior);pp=pm['complete_proposed_compiler_Source_plan'];plan=read(checked(pp))
 row=pm['files'][0];name=row['canonical_path'];before=checked(row['proposed']).read_bytes();assert (R/name).read_bytes()==before
 needle=b'    let mut values = shape(&n.physical);';replacement=b'    let mut values = array1(&n.physical);'
 assert before.count(needle)==1;after=before.replace(needle,replacement);assert after.replace(replacement,needle)==before
 target=O/'proposed'/name;target.parent.mkdir(parents=True);target.write_bytes(after)
 diffs={}
 for key,a,b in [('forward_diff',before,after),('inverse_diff',after,before)]:
  p=O/(key+'.diff');p.write_text(''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');diffs[key]=ref(p)
 parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
 (O/'syntax.stdout.rs').write_bytes(parse.stdout);(O/'syntax.stderr.txt').write_bytes(parse.stderr)
 census_path=D/'P1-static-shape-census-Audit-51/census.json';census=read(census_path);assert (census['actual_snapshots'],census['shape_paths'])==(124,37)
 # Independently close generated record keysets against true current Native snapshots.
 fixture_ref=pm['external_fixtures_unchanged'][0];fixture=read(checked(fixture_ref));cases=fixture['native_output']['groups']['purchased_air']['cases']
 snapshots=[]
 for case in cases:
  snapshots.append(case['setup'])
  for step in case['steps']:
   snapshots.extend([step['entry'],step['exit']])
   prefix=step['actual_caller_InitZoneEquipment_prefix']
   if prefix is not None:snapshots.extend([prefix['entry'],prefix['exit']])
 source=after.decode();records=[]
 selectors={'unit':lambda x:x['manager']['PurchAir']['items'],'node':lambda x:x['nodes']['Node']['items'],'zone_row':lambda x:x['sizing']['ZoneEqSizing']['items'],'globals':lambda x:[x['sizing']]}
 for function,select in selectors.items():
  start=source.index('fn '+function+'(');end=source.find('\nfn ',start+1);body=source[start:end if end>=0 else len(source)]
  keys=set(re.findall(r'out\.insert\(\s*"([^"]+)"\.into\(\)',body));assert keys
  native_sets={tuple(sorted(v)) for snapshot in snapshots for v in select(snapshot)}
  assert native_sets=={tuple(sorted(keys))},(function,keys,native_sets)
  records.append(dict(function=function,Source_literal_keys=sorted(keys),Native_all_snapshot_keysets=[list(x) for x in sorted(native_sets)],whole_keyset_equal=True))
 audit=save(O/'static-schema-audit.json',dict(independent_container_census=ref(census_path),snapshots_including_caller_prefixes=len(snapshots),generated_record_keysets=records,
  only_container_schema_correction='nodes.Node is actual Array1D<NodeData>; its current real Vec extent projects actual Native ordinal domain lower1/upperlen. NodeID lower0 remains separate.',
  manually_closed_literal_records=['snapshot','manager','plenum','schedule','reports','registration.dictionary/live/meters','context/config/demand/moisture/availability','errors'],
  scalar_values_not_computed_or_replaced=True,no_observation_skips_or_relaxed_assertions=True))
 final=copy.deepcopy(plan);fr=next(x for x in final['entries'] if x['path']==name);fr.update(final_sha256=ref(target)['sha256'],final_bytes=ref(target)['bytes'],source=ref(target),origin='cfg-only physical Node Array1D shape transport correction')
 final['schema']='src06-Source-P1-physical-Node-shape-plan52.v1';final['prior_complete_compiler_Source_plan']=pp
 fp=save(O/'complete-proposed-compiler-Source-plan.json',final)
 failed_path=D/'canonical-source-purchased-air-gap-cohort-Root-51/receipt.json';failed=read(failed_path);assert failed['exit_code']==101 and failed['source_bytes_match_before_and_after']
 stderr=checked(failed['stderr']).read_bytes();assert b'setup.nodes.Node complete observed keys' in stderr and b'lower' in stderr and b'upper' in stderr
 manifest=save(O/'manifest.json',dict(schema='src06-P1-physical-Node-observer-shape-fix.v1',status='FROZEN_PRIVATE_INDEPENDENT_PEER_PENDING',
  files=[dict(canonical_path=name,before=row['proposed'],proposed=ref(target),**diffs)],prior_manifest=ref(prior),prior_compiler_plan=pp,complete_proposed_compiler_Source_plan=fp,compiler_inputs=4534,Rust_sources=4521,
  actual_failed_P1_setup=ref(failed_path),actual_Surface50_pass=pm['actual_Surface50_pass'],original_full_Source50_peer=pm['original_full_Source50_peer'],prior_raw_prescan_peer=ref(D/'Peer-P1-raw-prescan-review-Audit-51/review.json'),
  static_schema_audit=audit,independent_complete_container_census=ref(census_path),external_fixtures_unchanged=pm['external_fixtures_unchanged'],
  correction='One cfg-only physical Node observer switches shape to existing array1 helper; same real physical owner/cells, lower1 and upperactualLength. No scientific/state/API/call/assertion/expected-input change.',
  Surface50_reuse_bridge=pm['Surface50_reuse_bridge'],syntax=dict(exit=0,stdout=ref(O/'syntax.stdout.rs'),stderr=ref(O/'syntax.stderr.txt'),qualification='syntax only; no contextual execution'),
  initial_failure_is_observer_schema_not_numeric_mismatch=True,no_Cargo_Native_or_canonical_execution=True,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,plan=fp,proposed=ref(target),audit=audit)))
if __name__=='__main__':main()

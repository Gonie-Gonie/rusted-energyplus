// Private original-core unit batch ABI. No scientific initialization here.
#pragma once
#include <nlohmann/json_fwd.hpp>

namespace NativeGapBatch {
nlohmann::json run_purchased_air_batch(nlohmann::json const &named_inputs);
nlohmann::json run_surface_batch(nlohmann::json const &named_inputs);
nlohmann::json run_exterior_batch(nlohmann::json const &named_inputs);
} // namespace NativeGapBatch

"""Read-only actual53 P1 plus exact unchanged Surface50 impact bridge; no commands run."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
LEAF='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs'
def main(a):
 helper=D/'apply-Source-gap-batch-Root-50.py';assert hashlib.sha256(helper.read_bytes()).hexdigest()=='03f08ddbc7f1ccfcaafeec69f9105cf0de23d3da453f01fa0149f9d8c385fb2e'
 spec=importlib.util.spec_from_file_location('Source50_exact_guards',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);g=m.g
 ar=g.argument(a.application);app=g.read(g.checked(ar));assert g.checked(ar)==(D/'Root-P1-open-output-application-53/receipt.json').resolve()
 assert app['accepted'] and not app['findings'] and app['all_final_compiler_bytes_exact'] and (app['compiler_inputs'],app['Rust_sources'])==(4534,4521)
 initial_ref=app['actual_Source50_application'];initial=g.read(g.checked(initial_ref));assert initial['accepted'] and not initial['findings'] and initial['base_HEAD']==app['base_HEAD']
 d=g.read(g.checked(initial['draft']));joint=g.read(g.checked(initial['independent_join_peer']));assert joint['accepted'] and not joint['findings'] and joint['reviewed_draft']==initial['draft']
 plan_ref=app['complete_compiler_plan'];old_ref=initial['complete_compiler_plan'];assert plan_ref['sha256']=='2695383e35a3600ed2e862c8616bcb9816df8e5d776598e8b0d3b55535ac4128'
 assert old_ref['sha256']=='6fa41d549ca3df3ab074b663c2b0c9bae34529db74e9cc910bb90b7c3a8d417e'
 plan=g.read(g.checked(plan_ref));old=g.read(g.checked(old_ref));rows={x['path']:x for x in plan['entries']};oldrows={x['path']:x for x in old['entries']}
 assert (plan['inputs'],plan['Rust_sources'],len(rows))==(4534,4521,4534) and rows.keys()==oldrows.keys();g.exact(rows)
 delta=[name for name in rows if (rows[name]['final_sha256'],rows[name]['final_bytes'])!=(oldrows[name]['final_sha256'],oldrows[name]['final_bytes'])];assert delta==[LEAF]
 bridge_files=[]
 for f in d['files']:
  name=f['canonical_path']
  if name!=LEAF:assert (R/name).read_bytes()==g.checked(f['proposed']).read_bytes()
  bridge_files.append(dict(canonical_path=name,unchanged=name!=LEAF))
 surface=g.read(g.checked(d['Surface_adapter']));assert len(surface['Sources'])==13
 for f in surface['Sources']:
  name=f['canonical_path'];assert rows[name]['final_sha256']==oldrows[name]['final_sha256'] and (R/name).read_bytes()==g.checked(f['proposed']).read_bytes()
 # Follow all three independently reviewed cfg-only corrections to the current leaf.
 corrections=[];previous=oldrows[LEAF]['source'];previous_plan=old_ref
 for label,mp,peerp in [
  ('raw lexical pre-scan association','source-P1-raw-prescan-fix-Peer-51/manifest.json','Peer-P1-raw-prescan-review-Audit-51/review.json'),
  ('physical Node Array1D ordinal shape','source-P1-Node-shape-fix-Peer-52/manifest.json','Peer-P1-Node-shape-review-Audit-52/review.json'),
  ('genuine initial EIO/ESO open phase','source-P1-open-output-fix-Peer-53/manifest.json','Peer-P1-open-output-review-Audit-53/review.json')]:
  mr=g.ref(D/mp);packet=g.read(g.checked(mr));pr=g.ref(D/peerp);peer=g.read(g.checked(pr));assert peer['accepted'] and not peer['findings'] and peer.get('reviewed_packet',peer.get('reviewed_draft'))==mr
  assert packet['prior_compiler_plan']==previous_plan and len(packet['files'])==1;f=packet['files'][0];assert f['canonical_path']==LEAF and f['before']==previous
  apply=g.literal();before=g.checked(previous).read_bytes();after=g.checked(f['proposed']).read_bytes()
  assert apply(before,g.checked(f['forward_diff']).read_bytes())==after and apply(after,g.checked(f['inverse_diff']).read_bytes())==before
  previous=f['proposed'];previous_plan=packet['complete_proposed_compiler_Source_plan'];corrections.append(dict(scope=label,manifest=mr,independent_peer=pr,files=packet['files']))
 assert previous_plan==plan_ref and previous==rows[LEAF]['source'] and app['manifest']==corrections[-1]['manifest'] and app['independent_peer']==corrections[-1]['independent_peer']
 settings_path=D/'purchased-air-gap-prepared-WAIT-Peer-P1/prepared.json';settings=g.read(settings_path);envguard=settings['inherited_environment_guard'];assert envguard['sha256']=='fc76790e89122784da36a9687c22079a2aefe67cdf498b0d55e32ac9d52b598e';g.checked(envguard)
 assert b"env['CARGO_INCREMENTAL']='0'" in g.checked(envguard).read_bytes();g.checked(settings['record_command_Source']);g.checked(app['application_Source'])
 prepared_path=D/'P1-open-output-helpers-prepared-Peer-53-02/prepared.json';prepared=g.read(prepared_path);assert prepared['manifest']==app['manifest'] and prepared['files'][0]['proposed']==app['application_Source']
 target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve();results=[]
 for group,arg,calls,expected_app,expected_rows,expected_plan,guard_path in [
  ('purchased_air',a.p1_receipt,60,ar,rows,plan_ref,D/'Root-P1-runtime-fixture-guard-53/after.json'),
  ('surface',a.surface_receipt,55,initial_ref,oldrows,old_ref,D/'Root-runtime-fixture-surface-guard-50/after.json')]:
  rr=g.argument(arg);run=g.read(g.checked(rr));assert run['exit_code']==0 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
  assert run['repository_before']==run['repository_after'] and run['repository_before']['head']==app['base_HEAD']
  fixture,protected=m.fixtures(d,group);command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',group,str(g.checked(fixture))];assert run['command']==command
  env=run['launch_environment_selected'];assert Path(env['CARGO_TARGET_DIR']).resolve()==target and all(v is None for k,v in env.items() if k!='CARGO_TARGET_DIR')
  assert run['cargo_compiler_artifacts_capture']['requested'] is False
  guard=g.read(guard_path);assert guard['accepted'] and not guard['findings'] and guard['exit_code']==0 and guard['application']==expected_app and guard['actual_receipt']==rr and guard['command']==command and guard['all4534_compiler_inputs_unchanged']
  assert guard['protected_before']==guard['protected_after']==protected
  if group=='purchased_air':assert guard['launch_Source']==prepared['files'][1]['proposed'];g.checked(guard['launch_Source'])
  snapshot_path=R/run['source_snapshot']['path'];snapshot_ref=g.ref(snapshot_path);assert snapshot_ref['sha256']==run['source_snapshot']['sha256'];snapshot=g.read(snapshot_path);archived={x['historical_path']:x for x in snapshot['files']};assert archived.keys()==expected_rows.keys()
  for name,row in expected_rows.items():
   item=archived[name];arch=g.ref(R/item['archive']['path']);assert arch['bytes']==item['size_bytes']==row['final_bytes'] and arch['sha256']==item['archive']['sha256']==row['final_sha256'],name
  out=R/run['stdout']['path'];err=R/run['stderr']['path'];assert g.ref(out)['sha256']==run['stdout']['sha256'] and g.ref(err)['sha256']==run['stderr']['sha256'];lines=out.read_text(encoding='utf8').splitlines()
  assert lines[0]=='running 1 original-core gap cohort group='+group+' on process main' and lines[-2:]==['cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; group='+group+'; full-call records='+str(calls)+'; private cache state unobserved']
  observations=None
  if group=='purchased_air':
   assert len(lines)==4;match=re.fullmatch(r'PurchasedAir genuine persistent calls=60; finite raw-bit observations=(\d+); four true getter factories; private Psy cache state unobserved',lines[1]);assert match;observations=int(match[1]);assert observations==75524
  else:assert len(lines)==3
  stderr=err.read_text(encoding='utf8');assert 'Finished `test` profile' in stderr and 'Running src\\lib.rs (' in stderr and not re.search(r'^error(?:\[|:)',stderr,re.M);compiles=len(re.findall(r'^\s*Compiling ep_runtime ',stderr,re.M))
  if group=='surface':assert compiles==0
  native_ref=d['Surface_actual_Native_run'] if group=='surface' else g.read(g.checked(d['P1_fixture_proof']))['actual_Native_group_run'];native=g.read(g.checked(native_ref));assert native['accepted'] and not native['findings'] and native['exit_code']==0
  if group=='purchased_air':assert native['admission']['raw_finite_binary64_fields']==75672
  results.append(dict(group=group,full_call_records=calls,actual_receipt=rr,application=expected_app,fixture=fixture,fixture_guard=g.ref(guard_path),source_snapshot=snapshot_ref,stdout=g.ref(out),stderr=g.ref(err),complete_executed_compiler_plan=expected_plan,all4534_archived_inputs_exact=True,actual_Native_run=native_ref,Source_snapshot_raw_bit_comparisons=observations,Native_entire_output_raw_finite_fields=native['admission']['raw_finite_binary64_fields'],raw_bit_denominators_are_distinct=True,Cargo_ep_runtime_compile_messages=compiles))
 failures=[]
 for label,ref0,code,token in [
  ('initial two cfg API compile bindings',initial['initial_failed_P1_compile'],101,b'AutoOrNumber'),
  ('cfg raw lexical pre-scan setup',g.read(D/'source-P1-raw-prescan-fix-Peer-51/manifest.json')['actual_failed_P1_setup'],1,b'raw lexical object association'),
  ('cfg Node observation shape',g.read(D/'source-P1-Node-shape-fix-Peer-52/manifest.json')['actual_failed_P1_setup'],101,b'setup.nodes.Node complete observed keys'),
  ('cfg initial EIO stream phase',g.read(D/'source-P1-open-output-fix-Peer-53/manifest.json')['actual_failed_P1_setup'],101,b'setup.reports.eio exact observed value')]:
  fail=g.read(g.checked(ref0));assert fail['exit_code']==code and fail['source_bytes_match_before_and_after'];logs=[]
  for k in ['stdout','stderr']:
   p=R/fail[k]['path'];assert g.ref(p)['sha256']==fail[k]['sha256'];logs.append(p.read_bytes())
  assert any(token in x for x in logs);failures.append(dict(scope=label,actual_receipt=ref0,exit_code=code,qualification='Preserved compile/setup/schema failure, not an observed scientific mismatch; no pass relabelling.'))
 g.exact(rows)
 result=dict(schema='src06-Source53-P1-and-carried-Surface50-actual-review.v1',accepted=True,findings=[],application=ar,original_Source50_application=initial_ref,draft=initial['draft'],independent_join_peer=initial['independent_join_peer'],cfg_corrections=corrections,base_HEAD=app['base_HEAD'],complete_compiler_plan=plan_ref,compiler_inputs=4534,Rust_sources=4521,
  Surface50_to_Source53_impact_bridge=dict(old_compiler_plan=old_ref,current_compiler_plan=plan_ref,changed_paths=delta,only_changed_path_is_P1_private_cfg_child=True,shared_runner_and_all13_Surface_sources_whole_unchanged=True,all_other4533_compiler_inputs_whole_unchanged=True,selected_Source_union=bridge_files,Surface_fixture_whole_unchanged=True,Surface_reexecuted=False),
  ordered_successful_groups=results,accepted_selected_Cargo_invocations=2,all_P1_Cargo_attempts=5,preserved_failed_P1_invocations=failures,full_call_records=115,P1_compared_state_snapshots=204,P1_Source_raw_bit_observations=75524,P1_Native_entire_group_raw_finite_fields=75672,P1_named_input_bit_objects_not_owner_observations=148,
  inherited_environment_guard=envguard,record_command_Source=settings['record_command_Source'],scoped_P1_helpers_prepared=g.ref(prepared_path),current_Source53_all4534_live_and_archive_exact=True,Surface50_all4534_archive_exact=True,new_test_targets_features_or_functions=0,old2336_471_59_P2_bodies_executed=0,normal_CLI_or_additional_Native_runs_by_this_checker=0,gates_or_tolerances_changed=False,
  qualification='P1 full same-owner methods pass against actual original-core unit output; Surface50 pass transferred only across exact P1-only cfg child change. Different successful compiler snapshots are retained, not relabelled one snapshot. Private cache state, broad engine warmup/calendar/positive unrepresented children and later OP/history/Exterior batches remain outside this certificate.',author_Source=g.ref(Path(__file__)))
 dest=D/'Root-source-gap-batch-actual-review-53';assert not dest.exists();dest.mkdir();p=dest/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(g.ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);p.add_argument('--p1-receipt',required=True);p.add_argument('--surface-receipt',required=True);main(p.parse_args())

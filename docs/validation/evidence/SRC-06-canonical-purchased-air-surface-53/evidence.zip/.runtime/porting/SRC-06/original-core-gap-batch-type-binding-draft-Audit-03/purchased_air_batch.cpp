// Private P1 full-function caller. No copied scientific body or expected state.
#include "native_gap_batches.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataErrorTracking.hh>
#include <EnergyPlus/DataContaminantBalance.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataHeatBalFanSys.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataLoopNode.hh>
#include <EnergyPlus/DataSizing.hh>
#include <EnergyPlus/DataStringGlobals.hh>
#include <EnergyPlus/DataZoneEnergyDemands.hh>
#include <EnergyPlus/DataZoneEquipment.hh>
#include <EnergyPlus/InputProcessing/InputProcessor.hh>
#include <EnergyPlus/HeatBalanceManager.hh>
#include <EnergyPlus/ZoneEquipmentManager.hh>
#include <EnergyPlus/ZoneTempPredictorCorrector.hh>
#include <EnergyPlus/SystemAvailabilityManager.hh>
#include <EnergyPlus/SimulationManager.hh>
#include <EnergyPlus/PurchasedAirManager.hh>
#include <EnergyPlus/ScheduleManager.hh>
#include <EnergyPlus/Psychrometrics.hh>
#include <EnergyPlus/OutputProcessor.hh>
#include <EnergyPlus/OutputReportPredefined.hh>
#include <EnergyPlus/ReportCoilSelection.hh>
#include <EnergyPlus/SQLiteProcedures.hh>
#include <EnergyPlus/UtilityRoutines.hh>
#include <EnergyPlus/IOFiles.hh>
#include <nlohmann/json.hpp>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
namespace NativeGapBatch::PurchasedAirDetail {
using json=nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
void require(bool value,char const *message){if(!value)throw std::runtime_error(message);}
std::uint64_t bits(double v){std::uint64_t b;std::memcpy(&b,&v,sizeof b);return b;}
double from_bits(std::uint64_t b){double out;std::memcpy(&out,&b,sizeof out);return out;}
json number(double v){require(std::isfinite(v),"finite real Native unit scalar");std::ostringstream s;s<<std::hex<<std::setfill('0')<<std::setw(16)<<bits(v);return json{{"value_bits",s.str()}};}
double real(json const &v){auto text=v.at("value_bits").get<std::string>();require(v.size()==1&&text.size()==16,"raw16hex input");std::uint64_t b=0;for(char c:text){require((c>='0'&&c<='9')||(c>='a'&&c<='f'),"hex input");b=(b<<4)|static_cast<unsigned>(c<='9'?c-'0':c-'a'+10);}double out;std::memcpy(&out,&b,sizeof out);require(std::isfinite(out),"finite input");return out;}
template<class A> json shape(A const&a){json out{{"allocated",a.allocated()},{"size",a.size()}};if constexpr(requires{a.l();a.u();}){out["lower"]=a.l();out["upper"]=a.u();}return out;}
template<class A> json integer_array(A const&a){auto out=shape(a);out["items"]=json::array();for(std::size_t i=1;i<=a.size();++i)out["items"].push_back(a(i));return out;}
json zone_row(DataSizing::ZoneEqSizingData const&row){json out;
    out["AirVolFlow"]=number(row.AirVolFlow);
    out["MaxHWVolFlow"]=number(row.MaxHWVolFlow);
    out["MaxCWVolFlow"]=number(row.MaxCWVolFlow);
    out["OAVolFlow"]=number(row.OAVolFlow);
    out["ATMixerVolFlow"]=number(row.ATMixerVolFlow);
    out["ATMixerCoolPriDryBulb"]=number(row.ATMixerCoolPriDryBulb);
    out["ATMixerCoolPriHumRat"]=number(row.ATMixerCoolPriHumRat);
    out["ATMixerHeatPriDryBulb"]=number(row.ATMixerHeatPriDryBulb);
    out["ATMixerHeatPriHumRat"]=number(row.ATMixerHeatPriHumRat);
    out["DesCoolingLoad"]=number(row.DesCoolingLoad);
    out["DesHeatingLoad"]=number(row.DesHeatingLoad);
    out["CoolingAirVolFlow"]=number(row.CoolingAirVolFlow);
    out["HeatingAirVolFlow"]=number(row.HeatingAirVolFlow);
    out["SystemAirVolFlow"]=number(row.SystemAirVolFlow);
    out["AirFlow"]=row.AirFlow;
    out["CoolingAirFlow"]=row.CoolingAirFlow;
    out["HeatingAirFlow"]=row.HeatingAirFlow;
    out["SystemAirFlow"]=row.SystemAirFlow;
    out["Capacity"]=row.Capacity;
    out["CoolingCapacity"]=row.CoolingCapacity;
    out["HeatingCapacity"]=row.HeatingCapacity;
    out["SystemCapacity"]=row.SystemCapacity;
    out["DesignSizeFromParent"]=row.DesignSizeFromParent;
    out["HVACSizingIndex"]=static_cast<int>(row.HVACSizingIndex);
    out["SizingMethod"]=integer_array(row.SizingMethod);out["CapSizingMethod"]=integer_array(row.CapSizingMethod);return out;
}
template<class A>json zone_array(A const&a){auto out=shape(a);out["items"]=json::array();for(std::size_t i=1;i<=a.size();++i)out["items"].push_back(zone_row(a(i)));return out;}
json globals(EnergyPlusData const&s){json out;
    out["CurOASysNum"]=static_cast<int>(s.dataSize->CurOASysNum);
    out["CurDuctType"]=static_cast<int>(s.dataSize->CurDuctType);
    out["TermUnitSingDuct"]=s.dataSize->TermUnitSingDuct;
    out["TermUnitPIU"]=s.dataSize->TermUnitPIU;
    out["TermUnitIU"]=s.dataSize->TermUnitIU;
    out["ZoneEqFanCoil"]=s.dataSize->ZoneEqFanCoil;
    out["ZoneEqUnitHeater"]=s.dataSize->ZoneEqUnitHeater;
    out["ZoneEqUnitVent"]=s.dataSize->ZoneEqUnitVent;
    out["ZoneEqVentedSlab"]=s.dataSize->ZoneEqVentedSlab;
    out["ZoneSizingInput"]=shape(s.dataSize->ZoneSizingInput);
    out["FinalZoneSizing"]=shape(s.dataSize->FinalZoneSizing);
    out["TermUnitFinalZoneSizing"]=shape(s.dataSize->TermUnitFinalZoneSizing);
    out["SysSizInput"]=shape(s.dataSize->SysSizInput);
    out["FinalSysSizing"]=shape(s.dataSize->FinalSysSizing);
    out["PlantSizData"]=shape(s.dataSize->PlantSizData);
    out["DataEMSOverrideON"]=s.dataSize->DataEMSOverrideON;
    out["DataEMSOverride"]=number(s.dataSize->DataEMSOverride);
    out["DataAutosizable"]=s.dataSize->DataAutosizable;
    out["DataConstantUsedForSizing"]=number(s.dataSize->DataConstantUsedForSizing);
    out["DataFractionUsedForSizing"]=number(s.dataSize->DataFractionUsedForSizing);
    out["DataFanIndex"]=static_cast<int>(s.dataSize->DataFanIndex);
    out["DataFanType"]=static_cast<int>(s.dataSize->DataFanType);
    out["DataPltSizHeatNum"]=static_cast<int>(s.dataSize->DataPltSizHeatNum);
    out["DataWaterLoopNum"]=static_cast<int>(s.dataSize->DataWaterLoopNum);
    out["DataPltSizCoolNum"]=static_cast<int>(s.dataSize->DataPltSizCoolNum);
    out["DataWaterCoilSizHeatDeltaT"]=number(s.dataSize->DataWaterCoilSizHeatDeltaT);
    out["DataWaterCoilSizCoolDeltaT"]=number(s.dataSize->DataWaterCoilSizCoolDeltaT);
    out["DataCapacityUsedForSizing"]=number(s.dataSize->DataCapacityUsedForSizing);
    out["DataHeatSizeRatio"]=number(s.dataSize->DataHeatSizeRatio);
    out["DataAirFlowUsedForSizing"]=number(s.dataSize->DataAirFlowUsedForSizing);
    out["DataDesInletAirTemp"]=number(s.dataSize->DataDesInletAirTemp);
    out["DataDesAccountForFanHeat"]=s.dataSize->DataDesAccountForFanHeat;
    out["DataFanPlacement"]=static_cast<int>(s.dataSize->DataFanPlacement);
    out["DataDesInletAirHumRat"]=number(s.dataSize->DataDesInletAirHumRat);
    out["DataDesOutletAirHumRat"]=number(s.dataSize->DataDesOutletAirHumRat);
    out["DataDesOutletAirTemp"]=number(s.dataSize->DataDesOutletAirTemp);
    out["DataDesInletWaterTemp"]=number(s.dataSize->DataDesInletWaterTemp);
    out["DataFlowUsedForSizing"]=number(s.dataSize->DataFlowUsedForSizing);
    out["DataWaterFlowUsedForSizing"]=number(s.dataSize->DataWaterFlowUsedForSizing);
    out["DataSizingFraction"]=number(s.dataSize->DataSizingFraction);
    out["DataDXSpeedNum"]=static_cast<int>(s.dataSize->DataDXSpeedNum);
    out["DataDesicRegCoil"]=s.dataSize->DataDesicRegCoil;
    out["DataZoneUsedForSizing"]=static_cast<int>(s.dataSize->DataZoneUsedForSizing);
    out["DataDesicDehumNum"]=static_cast<int>(s.dataSize->DataDesicDehumNum);
    out["DataNomCapInpMeth"]=s.dataSize->DataNomCapInpMeth;
    out["DataCoilNum"]=static_cast<int>(s.dataSize->DataCoilNum);
    out["DataFanOp"]=static_cast<int>(s.dataSize->DataFanOp);
    out["DataDesignCoilCapacity"]=number(s.dataSize->DataDesignCoilCapacity);
    out["DataErrorsFound"]=s.dataSize->DataErrorsFound;
    out["DataBypassFrac"]=number(s.dataSize->DataBypassFrac);
    out["DataIsDXCoil"]=s.dataSize->DataIsDXCoil;
    out["DataNonZoneNonAirloopValue"]=number(s.dataSize->DataNonZoneNonAirloopValue);
    out["DataDXCoolsLowSpeedsAutozize"]=s.dataSize->DataDXCoolsLowSpeedsAutozize;
    out["DataScalableSizingON"]=s.dataSize->DataScalableSizingON;
    out["DataScalableCapSizingON"]=s.dataSize->DataScalableCapSizingON;
    out["HRFlowSizingFlag"]=s.dataSize->HRFlowSizingFlag;
    out["DataFracOfAutosizedCoolingAirflow"]=number(s.dataSize->DataFracOfAutosizedCoolingAirflow);
    out["DataFracOfAutosizedHeatingAirflow"]=number(s.dataSize->DataFracOfAutosizedHeatingAirflow);
    out["DataFlowPerCoolingCapacity"]=number(s.dataSize->DataFlowPerCoolingCapacity);
    out["DataAutosizedCoolingCapacity"]=number(s.dataSize->DataAutosizedCoolingCapacity);
    out["DataFlowPerHeatingCapacity"]=number(s.dataSize->DataFlowPerHeatingCapacity);
    out["DataAutosizedHeatingCapacity"]=number(s.dataSize->DataAutosizedHeatingCapacity);
    out["DataCoilSizingAirInTemp"]=number(s.dataSize->DataCoilSizingAirInTemp);
    out["DataCoilSizingAirInHumRat"]=number(s.dataSize->DataCoilSizingAirInHumRat);
    out["DataCoilSizingAirOutTemp"]=number(s.dataSize->DataCoilSizingAirOutTemp);
    out["DataCoilSizingAirOutHumRat"]=number(s.dataSize->DataCoilSizingAirOutHumRat);
    out["DataCoilSizingFanCoolLoad"]=number(s.dataSize->DataCoilSizingFanCoolLoad);
    out["DataCoilSizingCapFT"]=number(s.dataSize->DataCoilSizingCapFT);
    out["DataTotCapCurveIndex"]=static_cast<int>(s.dataSize->DataTotCapCurveIndex);
    out["DataTotCapCurveValue"]=number(s.dataSize->DataTotCapCurveValue);
    out["DataFracOfAutosizedCoolingCapacity"]=number(s.dataSize->DataFracOfAutosizedCoolingCapacity);
    out["DataFracOfAutosizedHeatingCapacity"]=number(s.dataSize->DataFracOfAutosizedHeatingCapacity);
    out["DataCoilIsSuppHeater"]=s.dataSize->DataCoilIsSuppHeater;
    out["SuppHeatCap"]=number(s.dataSize->SuppHeatCap);
    out["UnitaryHeatCap"]=number(s.dataSize->UnitaryHeatCap);
    out["DataCoolCoilType"]=static_cast<int>(s.dataSize->DataCoolCoilType);
    out["DataCoolCoilIndex"]=static_cast<int>(s.dataSize->DataCoolCoilIndex);
    out["ZoneHVACSizing"]=shape(s.dataSize->ZoneHVACSizing);
    out["DataZoneNumber"]=static_cast<int>(s.dataSize->DataZoneNumber);
    out["AutoVsHardSizingThreshold"]=number(s.dataSize->AutoVsHardSizingThreshold);
    out["SysSizingRunDone"]=s.dataSize->SysSizingRunDone;
    out["ZoneSizingRunDone"]=s.dataSize->ZoneSizingRunDone;
    out["CurSysNum"]=static_cast<int>(s.dataSize->CurSysNum);
    out["CurZoneEqNum"]=static_cast<int>(s.dataSize->CurZoneEqNum);
    out["CurTermUnitSizingNum"]=static_cast<int>(s.dataSize->CurTermUnitSizingNum);
    out["NumSysSizInput"]=static_cast<int>(s.dataSize->NumSysSizInput);
    out["NumZoneSizingInput"]=static_cast<int>(s.dataSize->NumZoneSizingInput);
    out["UnitarySysEqSizing"]=zone_array(s.dataSize->UnitarySysEqSizing);
    out["OASysEqSizing"]=zone_array(s.dataSize->OASysEqSizing);
    out["TermUnitSizing"]=shape(s.dataSize->TermUnitSizing);
    out["ZoneEqSizing"]=zone_array(s.dataSize->ZoneEqSizing);
    out["ZoneCoolingOnlyFan"]=s.dataSize->ZoneCoolingOnlyFan;
    out["ZoneHeatingOnlyFan"]=s.dataSize->ZoneHeatingOnlyFan;
    out["DataCoolCoilCap"]=number(s.dataSize->DataCoolCoilCap);
 out["StdRhoAir"]=number(s.dataEnvrn->StdRhoAir);out["isEpJSON"]=s.dataGlobal->isEpJSON;out["DoZoneSizing"]=s.dataGlobal->DoZoneSizing;out["DoSystemSizing"]=s.dataGlobal->DoSystemSizing;out["DisplayExtraWarnings"]=s.dataGlobal->DisplayExtraWarnings;out["NumPrimaryAirSys"]=s.dataHVACGlobal->NumPrimaryAirSys;return out;
}
json reports(EnergyPlusData&s){json out{{"oneTimeCompRptHeaderFlag",s.dataEnvrn->oneTimeCompRptHeaderFlag},{"eio",s.files.eio.get_output()},{"sqlite_present",bool(s.dataSQLiteProcedures->sqlite)}};
 auto const&owner=*s.dataOutRptPredefined;out["sizeCompSizeTableEntry"]=owner.sizeCompSizeTableEntry;out["numCompSizeTableEntry"]=owner.numCompSizeTableEntry;out["CompSizeTableEntry"]=shape(owner.CompSizeTableEntry);auto&items=out["CompSizeTableEntry"]["items"]=json::array();
 for(std::size_t i=1;i<=owner.CompSizeTableEntry.size();++i){auto const&r=owner.CompSizeTableEntry(i);items.push_back(json{{"typeField",r.typeField},{"nameField",r.nameField},{"description",r.description},{"valField",number(r.valField)},{"strField",r.strField},{"active",r.active},{"written",r.written}});}return out;
}

json pointer(void const*p){std::ostringstream out;out<<p;return p?json(out.str()):json(nullptr);}
json schedule_pointer(EnergyPlusData const&s,Sched::Schedule const*p){
    if(!p)return nullptr;
    json out{{"address",pointer(p)},{"Name",p->Name},{"Num",p->Num},{"currentVal",number(p->currentVal)},
             {"EMSActuatedOn",p->EMSActuatedOn},{"EMSVal",number(p->EMSVal)},{"isUsed",p->isUsed}};
    json matches=json::array();
    for(std::size_t i=0;i<s.dataSched->schedules.size();++i)if(s.dataSched->schedules[i]==p)matches.push_back(i);
    out["same_actual_schedule_owner_ordinals_zero_based"]=matches;return out;
}
json unit(EnergyPlusData const&s,PurchasedAirManager::ZonePurchasedAir const&row){json out;
    out["cObjectName"]=row.cObjectName;
    out["Name"]=row.Name;
    out["availSched"]=schedule_pointer(s,row.availSched);
    out["ZoneSupplyAirNodeNum"]=row.ZoneSupplyAirNodeNum;
    out["ZoneExhaustAirNodeNum"]=row.ZoneExhaustAirNodeNum;
    out["PlenumExhaustAirNodeNum"]=row.PlenumExhaustAirNodeNum;
    out["ReturnPlenumIndex"]=row.ReturnPlenumIndex;
    out["PurchAirArrayIndex"]=row.PurchAirArrayIndex;
    out["ReturnPlenumName"]=row.ReturnPlenumName;
    out["ZoneRecircAirNodeNum"]=row.ZoneRecircAirNodeNum;
    out["MaxHeatSuppAirTemp"]=number(row.MaxHeatSuppAirTemp);
    out["MinCoolSuppAirTemp"]=number(row.MinCoolSuppAirTemp);
    out["MaxHeatSuppAirHumRat"]=number(row.MaxHeatSuppAirHumRat);
    out["MinCoolSuppAirHumRat"]=number(row.MinCoolSuppAirHumRat);
    out["HeatingLimit"]=static_cast<int>(row.HeatingLimit);
    out["MaxHeatVolFlowRate"]=number(row.MaxHeatVolFlowRate);
    out["MaxHeatSensCap"]=number(row.MaxHeatSensCap);
    out["CoolingLimit"]=static_cast<int>(row.CoolingLimit);
    out["MaxCoolVolFlowRate"]=number(row.MaxCoolVolFlowRate);
    out["MaxCoolTotCap"]=number(row.MaxCoolTotCap);
    out["heatAvailSched"]=schedule_pointer(s,row.heatAvailSched);
    out["coolAvailSched"]=schedule_pointer(s,row.coolAvailSched);
    out["DehumidCtrlType"]=static_cast<int>(row.DehumidCtrlType);
    out["CoolSHR"]=number(row.CoolSHR);
    out["HumidCtrlType"]=static_cast<int>(row.HumidCtrlType);
    out["OARequirementsPtr"]=row.OARequirementsPtr;
    out["DCVType"]=static_cast<int>(row.DCVType);
    out["EconomizerType"]=static_cast<int>(row.EconomizerType);
    out["OutdoorAir"]=row.OutdoorAir;
    out["OutdoorAirNodeNum"]=row.OutdoorAirNodeNum;
    out["HtRecType"]=static_cast<int>(row.HtRecType);
    out["HtRecSenEff"]=number(row.HtRecSenEff);
    out["HtRecLatEff"]=number(row.HtRecLatEff);
    out["oaFlowFracSched"]=schedule_pointer(s,row.oaFlowFracSched);
    out["MaxHeatMassFlowRate"]=number(row.MaxHeatMassFlowRate);
    out["MaxCoolMassFlowRate"]=number(row.MaxCoolMassFlowRate);
    out["EMSOverrideMdotOn"]=row.EMSOverrideMdotOn;
    out["EMSValueMassFlowRate"]=number(row.EMSValueMassFlowRate);
    out["EMSOverrideOAMdotOn"]=row.EMSOverrideOAMdotOn;
    out["EMSValueOAMassFlowRate"]=number(row.EMSValueOAMassFlowRate);
    out["EMSOverrideSupplyTempOn"]=row.EMSOverrideSupplyTempOn;
    out["EMSValueSupplyTemp"]=number(row.EMSValueSupplyTemp);
    out["EMSOverrideSupplyHumRatOn"]=row.EMSOverrideSupplyHumRatOn;
    out["EMSValueSupplyHumRat"]=number(row.EMSValueSupplyHumRat);
    out["MinOAMassFlowRate"]=number(row.MinOAMassFlowRate);
    out["OutdoorAirMassFlowRate"]=number(row.OutdoorAirMassFlowRate);
    out["OutdoorAirVolFlowRateStdRho"]=number(row.OutdoorAirVolFlowRateStdRho);
    out["SupplyAirMassFlowRate"]=number(row.SupplyAirMassFlowRate);
    out["SupplyAirVolFlowRateStdRho"]=number(row.SupplyAirVolFlowRateStdRho);
    out["HtRecSenOutput"]=number(row.HtRecSenOutput);
    out["HtRecLatOutput"]=number(row.HtRecLatOutput);
    out["OASenOutput"]=number(row.OASenOutput);
    out["OALatOutput"]=number(row.OALatOutput);
    out["SenOutputToZone"]=number(row.SenOutputToZone);
    out["LatOutputToZone"]=number(row.LatOutputToZone);
    out["SenCoilLoad"]=number(row.SenCoilLoad);
    out["LatCoilLoad"]=number(row.LatCoilLoad);
    out["OAFlowMaxCoolOutputError"]=row.OAFlowMaxCoolOutputError;
    out["OAFlowMaxHeatOutputError"]=row.OAFlowMaxHeatOutputError;
    out["SaturationOutputError"]=row.SaturationOutputError;
    out["OAFlowMaxCoolOutputIndex"]=row.OAFlowMaxCoolOutputIndex;
    out["OAFlowMaxHeatOutputIndex"]=row.OAFlowMaxHeatOutputIndex;
    out["SaturationOutputIndex"]=row.SaturationOutputIndex;
    out["availStatus"]=static_cast<int>(row.availStatus);
    out["CoolErrIndex"]=row.CoolErrIndex;
    out["HeatErrIndex"]=row.HeatErrIndex;
    out["SenHeatEnergy"]=number(row.SenHeatEnergy);
    out["LatHeatEnergy"]=number(row.LatHeatEnergy);
    out["TotHeatEnergy"]=number(row.TotHeatEnergy);
    out["SenCoolEnergy"]=number(row.SenCoolEnergy);
    out["LatCoolEnergy"]=number(row.LatCoolEnergy);
    out["TotCoolEnergy"]=number(row.TotCoolEnergy);
    out["ZoneSenHeatEnergy"]=number(row.ZoneSenHeatEnergy);
    out["ZoneLatHeatEnergy"]=number(row.ZoneLatHeatEnergy);
    out["ZoneTotHeatEnergy"]=number(row.ZoneTotHeatEnergy);
    out["ZoneSenCoolEnergy"]=number(row.ZoneSenCoolEnergy);
    out["ZoneLatCoolEnergy"]=number(row.ZoneLatCoolEnergy);
    out["ZoneTotCoolEnergy"]=number(row.ZoneTotCoolEnergy);
    out["OASenHeatEnergy"]=number(row.OASenHeatEnergy);
    out["OALatHeatEnergy"]=number(row.OALatHeatEnergy);
    out["OATotHeatEnergy"]=number(row.OATotHeatEnergy);
    out["OASenCoolEnergy"]=number(row.OASenCoolEnergy);
    out["OALatCoolEnergy"]=number(row.OALatCoolEnergy);
    out["OATotCoolEnergy"]=number(row.OATotCoolEnergy);
    out["HtRecSenHeatEnergy"]=number(row.HtRecSenHeatEnergy);
    out["HtRecLatHeatEnergy"]=number(row.HtRecLatHeatEnergy);
    out["HtRecTotHeatEnergy"]=number(row.HtRecTotHeatEnergy);
    out["HtRecSenCoolEnergy"]=number(row.HtRecSenCoolEnergy);
    out["HtRecLatCoolEnergy"]=number(row.HtRecLatCoolEnergy);
    out["HtRecTotCoolEnergy"]=number(row.HtRecTotCoolEnergy);
    out["SenHeatRate"]=number(row.SenHeatRate);
    out["LatHeatRate"]=number(row.LatHeatRate);
    out["TotHeatRate"]=number(row.TotHeatRate);
    out["SenCoolRate"]=number(row.SenCoolRate);
    out["LatCoolRate"]=number(row.LatCoolRate);
    out["TotCoolRate"]=number(row.TotCoolRate);
    out["ZoneSenHeatRate"]=number(row.ZoneSenHeatRate);
    out["ZoneLatHeatRate"]=number(row.ZoneLatHeatRate);
    out["ZoneTotHeatRate"]=number(row.ZoneTotHeatRate);
    out["ZoneSenCoolRate"]=number(row.ZoneSenCoolRate);
    out["ZoneLatCoolRate"]=number(row.ZoneLatCoolRate);
    out["ZoneTotCoolRate"]=number(row.ZoneTotCoolRate);
    out["OASenHeatRate"]=number(row.OASenHeatRate);
    out["OALatHeatRate"]=number(row.OALatHeatRate);
    out["OATotHeatRate"]=number(row.OATotHeatRate);
    out["OASenCoolRate"]=number(row.OASenCoolRate);
    out["OALatCoolRate"]=number(row.OALatCoolRate);
    out["OATotCoolRate"]=number(row.OATotCoolRate);
    out["HtRecSenHeatRate"]=number(row.HtRecSenHeatRate);
    out["HtRecLatHeatRate"]=number(row.HtRecLatHeatRate);
    out["HtRecTotHeatRate"]=number(row.HtRecTotHeatRate);
    out["HtRecSenCoolRate"]=number(row.HtRecSenCoolRate);
    out["HtRecLatCoolRate"]=number(row.HtRecLatCoolRate);
    out["HtRecTotCoolRate"]=number(row.HtRecTotCoolRate);
    out["TimeEconoActive"]=number(row.TimeEconoActive);
    out["TimeHtRecActive"]=number(row.TimeHtRecActive);
    out["ZonePtr"]=row.ZonePtr;
    out["HVACSizingIndex"]=row.HVACSizingIndex;
    out["SupplyTemp"]=number(row.SupplyTemp);
    out["SupplyHumRat"]=number(row.SupplyHumRat);
    out["MixedAirTemp"]=number(row.MixedAirTemp);
    out["MixedAirHumRat"]=number(row.MixedAirHumRat);
    out["heatFuelEffSched"]=schedule_pointer(s,row.heatFuelEffSched);
    out["coolFuelEffSched"]=schedule_pointer(s,row.coolFuelEffSched);
    out["ZoneTotHeatFuelRate"]=number(row.ZoneTotHeatFuelRate);
    out["ZoneTotCoolFuelRate"]=number(row.ZoneTotCoolFuelRate);
    out["ZoneTotHeatFuelEnergy"]=number(row.ZoneTotHeatFuelEnergy);
    out["ZoneTotCoolFuelEnergy"]=number(row.ZoneTotCoolFuelEnergy);
    out["TotHeatFuelRate"]=number(row.TotHeatFuelRate);
    out["TotCoolFuelRate"]=number(row.TotCoolFuelRate);
    out["TotHeatFuelEnergy"]=number(row.TotHeatFuelEnergy);
    out["TotCoolFuelEnergy"]=number(row.TotCoolFuelEnergy);
    out["heatingFuelType"]=static_cast<int>(row.heatingFuelType);
    out["coolingFuelType"]=static_cast<int>(row.coolingFuelType);
    out["address"]=pointer(&row);return out;
}

template<class A>json strings(A const&a){auto out=shape(a);out["items"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i)out["items"].push_back(a(i));return out;}
template<class A>json booleans(A const&a){auto out=shape(a);out["items"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i)out["items"].push_back(bool(a(i)));return out;}
json manager(EnergyPlusData const&s){auto const&m=*s.dataPurchasedAirMgr;json out;
    out["NumPurchAir"]=m.NumPurchAir;out["NumPlenumArrays"]=m.NumPlenumArrays;out["GetPurchAirInputFlag"]=m.GetPurchAirInputFlag;
    out["CheckEquipName"]=booleans(m.CheckEquipName);out["PurchAir"]=shape(m.PurchAir);out["PurchAir"]["items"]=json::array();
    if(m.PurchAir.allocated())for(int i=m.PurchAir.l();i<=m.PurchAir.u();++i)out["PurchAir"]["items"].push_back(unit(s,m.PurchAir(i)));
    out["PurchAirNumericFields"]=shape(m.PurchAirNumericFields);out["PurchAirNumericFields"]["items"]=json::array();
    if(m.PurchAirNumericFields.allocated())for(int i=m.PurchAirNumericFields.l();i<=m.PurchAirNumericFields.u();++i)out["PurchAirNumericFields"]["items"].push_back(strings(m.PurchAirNumericFields(i).FieldNames));
    auto plenum=[&](auto const&a){auto v=shape(a);v["items"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i){auto const&r=a(i);v["items"].push_back(json{{"NumPurchAir",r.NumPurchAir},{"ReturnPlenumIndex",r.ReturnPlenumIndex},{"PurchAirArray",integer_array(r.PurchAirArray)},{"IsSimulated",booleans(r.IsSimulated)}});}return v;};
    out["PurchAirPlenumArrays"]=plenum(m.PurchAirPlenumArrays);out["InitPurchasedAirMyOneTimeFlag"]=m.InitPurchasedAirMyOneTimeFlag;
    out["InitPurchasedAirZoneEquipmentListChecked"]=m.InitPurchasedAirZoneEquipmentListChecked;
    out["InitPurchasedAirMyEnvrnFlag"]=booleans(m.InitPurchasedAirMyEnvrnFlag);out["InitPurchasedAirMySizeFlag"]=booleans(m.InitPurchasedAirMySizeFlag);
    out["InitPurchasedAirOneTimeUnitInitsDone"]=booleans(m.InitPurchasedAirOneTimeUnitInitsDone);out["TempPurchAirPlenumArrays"]=plenum(m.TempPurchAirPlenumArrays);
    return out;
}
json node(EnergyPlusData const&s,Node::NodeData const&row){json out;
    out["fluidType"]=static_cast<int>(row.fluidType);
    out["FluidIndex"]=row.FluidIndex;
    out["Temp"]=number(row.Temp);
    out["TempMin"]=number(row.TempMin);
    out["TempMax"]=number(row.TempMax);
    out["TempSetPoint"]=number(row.TempSetPoint);
    out["TempLastTimestep"]=number(row.TempLastTimestep);
    out["MassFlowRateRequest"]=number(row.MassFlowRateRequest);
    out["MassFlowRate"]=number(row.MassFlowRate);
    out["MassFlowRateMin"]=number(row.MassFlowRateMin);
    out["MassFlowRateMax"]=number(row.MassFlowRateMax);
    out["MassFlowRateMinAvail"]=number(row.MassFlowRateMinAvail);
    out["MassFlowRateMaxAvail"]=number(row.MassFlowRateMaxAvail);
    out["MassFlowRateSetPoint"]=number(row.MassFlowRateSetPoint);
    out["Quality"]=number(row.Quality);
    out["Press"]=number(row.Press);
    out["Enthalpy"]=number(row.Enthalpy);
    out["EnthalpyLastTimestep"]=number(row.EnthalpyLastTimestep);
    out["HumRat"]=number(row.HumRat);
    out["HumRatMin"]=number(row.HumRatMin);
    out["HumRatMax"]=number(row.HumRatMax);
    out["HumRatSetPoint"]=number(row.HumRatSetPoint);
    out["TempSetPointHi"]=number(row.TempSetPointHi);
    out["TempSetPointLo"]=number(row.TempSetPointLo);
    out["Height"]=number(row.Height);
    out["IsLocalNode"]=row.IsLocalNode;
    out["OutAirDryBulb"]=number(row.OutAirDryBulb);
    out["EMSOverrideOutAirDryBulb"]=row.EMSOverrideOutAirDryBulb;
    out["EMSValueForOutAirDryBulb"]=number(row.EMSValueForOutAirDryBulb);
    out["OutAirWetBulb"]=number(row.OutAirWetBulb);
    out["EMSOverrideOutAirWetBulb"]=row.EMSOverrideOutAirWetBulb;
    out["EMSValueForOutAirWetBulb"]=number(row.EMSValueForOutAirWetBulb);
    out["OutAirWindSpeed"]=number(row.OutAirWindSpeed);
    out["EMSOverrideOutAirWindSpeed"]=row.EMSOverrideOutAirWindSpeed;
    out["EMSValueForOutAirWindSpeed"]=number(row.EMSValueForOutAirWindSpeed);
    out["OutAirWindDir"]=number(row.OutAirWindDir);
    out["EMSOverrideOutAirWindDir"]=row.EMSOverrideOutAirWindDir;
    out["EMSValueForOutAirWindDir"]=number(row.EMSValueForOutAirWindDir);
    out["CO2"]=number(row.CO2);
    out["CO2SetPoint"]=number(row.CO2SetPoint);
    out["GenContam"]=number(row.GenContam);
    out["GenContamSetPoint"]=number(row.GenContamSetPoint);
    out["SPMNodeWetBulbRepReq"]=row.SPMNodeWetBulbRepReq;
    out["plantNodeErrorMsgIssued"]=row.plantNodeErrorMsgIssued;
    out["outAirDryBulbSched"]=schedule_pointer(s,row.outAirDryBulbSched);
    out["outAirWetBulbSched"]=schedule_pointer(s,row.outAirWetBulbSched);
    out["outAirWindSpeedSched"]=schedule_pointer(s,row.outAirWindSpeedSched);
    out["outAirWindDirSched"]=schedule_pointer(s,row.outAirWindDirSched);
    out["address"]=pointer(&row);return out;
}

json nodes(EnergyPlusData const&s){auto const&n=*s.dataLoopNodes;json out{{"NodeID",strings(n.NodeID)},{"Node",shape(n.Node)}};out["Node"]["items"]=json::array();for(std::size_t i=1;i<=n.Node.size();++i)out["Node"]["items"].push_back(node(s,n.Node(i)));return out;}
json real_member_matches(EnergyPlusData const&s,Real64 const*ptr){json out=json::array();auto const&a=s.dataPurchasedAirMgr->PurchAir;if(a.allocated())for(int i=a.l();i<=a.u();++i){auto const&row=a(i);
    if(ptr==&row.MaxHeatSuppAirTemp)out.push_back(json{{"unit",i},{"member","MaxHeatSuppAirTemp"}});
    if(ptr==&row.MinCoolSuppAirTemp)out.push_back(json{{"unit",i},{"member","MinCoolSuppAirTemp"}});
    if(ptr==&row.MaxHeatSuppAirHumRat)out.push_back(json{{"unit",i},{"member","MaxHeatSuppAirHumRat"}});
    if(ptr==&row.MinCoolSuppAirHumRat)out.push_back(json{{"unit",i},{"member","MinCoolSuppAirHumRat"}});
    if(ptr==&row.MaxHeatVolFlowRate)out.push_back(json{{"unit",i},{"member","MaxHeatVolFlowRate"}});
    if(ptr==&row.MaxHeatSensCap)out.push_back(json{{"unit",i},{"member","MaxHeatSensCap"}});
    if(ptr==&row.MaxCoolVolFlowRate)out.push_back(json{{"unit",i},{"member","MaxCoolVolFlowRate"}});
    if(ptr==&row.MaxCoolTotCap)out.push_back(json{{"unit",i},{"member","MaxCoolTotCap"}});
    if(ptr==&row.CoolSHR)out.push_back(json{{"unit",i},{"member","CoolSHR"}});
    if(ptr==&row.HtRecSenEff)out.push_back(json{{"unit",i},{"member","HtRecSenEff"}});
    if(ptr==&row.HtRecLatEff)out.push_back(json{{"unit",i},{"member","HtRecLatEff"}});
    if(ptr==&row.MaxHeatMassFlowRate)out.push_back(json{{"unit",i},{"member","MaxHeatMassFlowRate"}});
    if(ptr==&row.MaxCoolMassFlowRate)out.push_back(json{{"unit",i},{"member","MaxCoolMassFlowRate"}});
    if(ptr==&row.EMSValueMassFlowRate)out.push_back(json{{"unit",i},{"member","EMSValueMassFlowRate"}});
    if(ptr==&row.EMSValueOAMassFlowRate)out.push_back(json{{"unit",i},{"member","EMSValueOAMassFlowRate"}});
    if(ptr==&row.EMSValueSupplyTemp)out.push_back(json{{"unit",i},{"member","EMSValueSupplyTemp"}});
    if(ptr==&row.EMSValueSupplyHumRat)out.push_back(json{{"unit",i},{"member","EMSValueSupplyHumRat"}});
    if(ptr==&row.MinOAMassFlowRate)out.push_back(json{{"unit",i},{"member","MinOAMassFlowRate"}});
    if(ptr==&row.OutdoorAirMassFlowRate)out.push_back(json{{"unit",i},{"member","OutdoorAirMassFlowRate"}});
    if(ptr==&row.OutdoorAirVolFlowRateStdRho)out.push_back(json{{"unit",i},{"member","OutdoorAirVolFlowRateStdRho"}});
    if(ptr==&row.SupplyAirMassFlowRate)out.push_back(json{{"unit",i},{"member","SupplyAirMassFlowRate"}});
    if(ptr==&row.SupplyAirVolFlowRateStdRho)out.push_back(json{{"unit",i},{"member","SupplyAirVolFlowRateStdRho"}});
    if(ptr==&row.HtRecSenOutput)out.push_back(json{{"unit",i},{"member","HtRecSenOutput"}});
    if(ptr==&row.HtRecLatOutput)out.push_back(json{{"unit",i},{"member","HtRecLatOutput"}});
    if(ptr==&row.OASenOutput)out.push_back(json{{"unit",i},{"member","OASenOutput"}});
    if(ptr==&row.OALatOutput)out.push_back(json{{"unit",i},{"member","OALatOutput"}});
    if(ptr==&row.SenOutputToZone)out.push_back(json{{"unit",i},{"member","SenOutputToZone"}});
    if(ptr==&row.LatOutputToZone)out.push_back(json{{"unit",i},{"member","LatOutputToZone"}});
    if(ptr==&row.SenCoilLoad)out.push_back(json{{"unit",i},{"member","SenCoilLoad"}});
    if(ptr==&row.LatCoilLoad)out.push_back(json{{"unit",i},{"member","LatCoilLoad"}});
    if(ptr==&row.SenHeatEnergy)out.push_back(json{{"unit",i},{"member","SenHeatEnergy"}});
    if(ptr==&row.LatHeatEnergy)out.push_back(json{{"unit",i},{"member","LatHeatEnergy"}});
    if(ptr==&row.TotHeatEnergy)out.push_back(json{{"unit",i},{"member","TotHeatEnergy"}});
    if(ptr==&row.SenCoolEnergy)out.push_back(json{{"unit",i},{"member","SenCoolEnergy"}});
    if(ptr==&row.LatCoolEnergy)out.push_back(json{{"unit",i},{"member","LatCoolEnergy"}});
    if(ptr==&row.TotCoolEnergy)out.push_back(json{{"unit",i},{"member","TotCoolEnergy"}});
    if(ptr==&row.ZoneSenHeatEnergy)out.push_back(json{{"unit",i},{"member","ZoneSenHeatEnergy"}});
    if(ptr==&row.ZoneLatHeatEnergy)out.push_back(json{{"unit",i},{"member","ZoneLatHeatEnergy"}});
    if(ptr==&row.ZoneTotHeatEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotHeatEnergy"}});
    if(ptr==&row.ZoneSenCoolEnergy)out.push_back(json{{"unit",i},{"member","ZoneSenCoolEnergy"}});
    if(ptr==&row.ZoneLatCoolEnergy)out.push_back(json{{"unit",i},{"member","ZoneLatCoolEnergy"}});
    if(ptr==&row.ZoneTotCoolEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotCoolEnergy"}});
    if(ptr==&row.OASenHeatEnergy)out.push_back(json{{"unit",i},{"member","OASenHeatEnergy"}});
    if(ptr==&row.OALatHeatEnergy)out.push_back(json{{"unit",i},{"member","OALatHeatEnergy"}});
    if(ptr==&row.OATotHeatEnergy)out.push_back(json{{"unit",i},{"member","OATotHeatEnergy"}});
    if(ptr==&row.OASenCoolEnergy)out.push_back(json{{"unit",i},{"member","OASenCoolEnergy"}});
    if(ptr==&row.OALatCoolEnergy)out.push_back(json{{"unit",i},{"member","OALatCoolEnergy"}});
    if(ptr==&row.OATotCoolEnergy)out.push_back(json{{"unit",i},{"member","OATotCoolEnergy"}});
    if(ptr==&row.HtRecSenHeatEnergy)out.push_back(json{{"unit",i},{"member","HtRecSenHeatEnergy"}});
    if(ptr==&row.HtRecLatHeatEnergy)out.push_back(json{{"unit",i},{"member","HtRecLatHeatEnergy"}});
    if(ptr==&row.HtRecTotHeatEnergy)out.push_back(json{{"unit",i},{"member","HtRecTotHeatEnergy"}});
    if(ptr==&row.HtRecSenCoolEnergy)out.push_back(json{{"unit",i},{"member","HtRecSenCoolEnergy"}});
    if(ptr==&row.HtRecLatCoolEnergy)out.push_back(json{{"unit",i},{"member","HtRecLatCoolEnergy"}});
    if(ptr==&row.HtRecTotCoolEnergy)out.push_back(json{{"unit",i},{"member","HtRecTotCoolEnergy"}});
    if(ptr==&row.SenHeatRate)out.push_back(json{{"unit",i},{"member","SenHeatRate"}});
    if(ptr==&row.LatHeatRate)out.push_back(json{{"unit",i},{"member","LatHeatRate"}});
    if(ptr==&row.TotHeatRate)out.push_back(json{{"unit",i},{"member","TotHeatRate"}});
    if(ptr==&row.SenCoolRate)out.push_back(json{{"unit",i},{"member","SenCoolRate"}});
    if(ptr==&row.LatCoolRate)out.push_back(json{{"unit",i},{"member","LatCoolRate"}});
    if(ptr==&row.TotCoolRate)out.push_back(json{{"unit",i},{"member","TotCoolRate"}});
    if(ptr==&row.ZoneSenHeatRate)out.push_back(json{{"unit",i},{"member","ZoneSenHeatRate"}});
    if(ptr==&row.ZoneLatHeatRate)out.push_back(json{{"unit",i},{"member","ZoneLatHeatRate"}});
    if(ptr==&row.ZoneTotHeatRate)out.push_back(json{{"unit",i},{"member","ZoneTotHeatRate"}});
    if(ptr==&row.ZoneSenCoolRate)out.push_back(json{{"unit",i},{"member","ZoneSenCoolRate"}});
    if(ptr==&row.ZoneLatCoolRate)out.push_back(json{{"unit",i},{"member","ZoneLatCoolRate"}});
    if(ptr==&row.ZoneTotCoolRate)out.push_back(json{{"unit",i},{"member","ZoneTotCoolRate"}});
    if(ptr==&row.OASenHeatRate)out.push_back(json{{"unit",i},{"member","OASenHeatRate"}});
    if(ptr==&row.OALatHeatRate)out.push_back(json{{"unit",i},{"member","OALatHeatRate"}});
    if(ptr==&row.OATotHeatRate)out.push_back(json{{"unit",i},{"member","OATotHeatRate"}});
    if(ptr==&row.OASenCoolRate)out.push_back(json{{"unit",i},{"member","OASenCoolRate"}});
    if(ptr==&row.OALatCoolRate)out.push_back(json{{"unit",i},{"member","OALatCoolRate"}});
    if(ptr==&row.OATotCoolRate)out.push_back(json{{"unit",i},{"member","OATotCoolRate"}});
    if(ptr==&row.HtRecSenHeatRate)out.push_back(json{{"unit",i},{"member","HtRecSenHeatRate"}});
    if(ptr==&row.HtRecLatHeatRate)out.push_back(json{{"unit",i},{"member","HtRecLatHeatRate"}});
    if(ptr==&row.HtRecTotHeatRate)out.push_back(json{{"unit",i},{"member","HtRecTotHeatRate"}});
    if(ptr==&row.HtRecSenCoolRate)out.push_back(json{{"unit",i},{"member","HtRecSenCoolRate"}});
    if(ptr==&row.HtRecLatCoolRate)out.push_back(json{{"unit",i},{"member","HtRecLatCoolRate"}});
    if(ptr==&row.HtRecTotCoolRate)out.push_back(json{{"unit",i},{"member","HtRecTotCoolRate"}});
    if(ptr==&row.TimeEconoActive)out.push_back(json{{"unit",i},{"member","TimeEconoActive"}});
    if(ptr==&row.TimeHtRecActive)out.push_back(json{{"unit",i},{"member","TimeHtRecActive"}});
    if(ptr==&row.SupplyTemp)out.push_back(json{{"unit",i},{"member","SupplyTemp"}});
    if(ptr==&row.SupplyHumRat)out.push_back(json{{"unit",i},{"member","SupplyHumRat"}});
    if(ptr==&row.MixedAirTemp)out.push_back(json{{"unit",i},{"member","MixedAirTemp"}});
    if(ptr==&row.MixedAirHumRat)out.push_back(json{{"unit",i},{"member","MixedAirHumRat"}});
    if(ptr==&row.ZoneTotHeatFuelRate)out.push_back(json{{"unit",i},{"member","ZoneTotHeatFuelRate"}});
    if(ptr==&row.ZoneTotCoolFuelRate)out.push_back(json{{"unit",i},{"member","ZoneTotCoolFuelRate"}});
    if(ptr==&row.ZoneTotHeatFuelEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotHeatFuelEnergy"}});
    if(ptr==&row.ZoneTotCoolFuelEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotCoolFuelEnergy"}});
    if(ptr==&row.TotHeatFuelRate)out.push_back(json{{"unit",i},{"member","TotHeatFuelRate"}});
    if(ptr==&row.TotCoolFuelRate)out.push_back(json{{"unit",i},{"member","TotCoolFuelRate"}});
    if(ptr==&row.TotHeatFuelEnergy)out.push_back(json{{"unit",i},{"member","TotHeatFuelEnergy"}});
    if(ptr==&row.TotCoolFuelEnergy)out.push_back(json{{"unit",i},{"member","TotCoolFuelEnergy"}});

}return out;}
json int_member_matches(EnergyPlusData const&s,int const*ptr){json out=json::array();auto const&a=s.dataPurchasedAirMgr->PurchAir;if(a.allocated())for(int i=a.l();i<=a.u();++i)if(static_cast<void const*>(ptr)==static_cast<void const*>(&a(i).availStatus))out.push_back(json{{"unit",i},{"member","availStatus"}});return out;}
json registration(EnergyPlusData const&s){json out{{"dictionary",json::array()},{"live",json::array()},{"meters",json::array()}};
    for(auto const*d:s.dataOutputProcessor->ddOutVars)out["dictionary"].push_back(json{{"name",d->name},{"units",static_cast<int>(d->units)},{"timeStepType",static_cast<int>(d->timeStepType)},{"storeType",static_cast<int>(d->storeType)},{"variableType",static_cast<int>(d->variableType)},{"keyOutVarNums",d->keyOutVarNums}});
    for(auto const*v:s.dataOutputProcessor->outVars){json row{{"name",v->name},{"key",v->key},{"units",static_cast<int>(v->units)},{"timeStepType",static_cast<int>(v->timeStepType)},{"storeType",static_cast<int>(v->storeType)},{"freq",static_cast<int>(v->freq)},{"meterNums",v->meterNums},{"owner_address",pointer(v)}};
        if(auto const*r=dynamic_cast<OutputProcessor::OutVarReal const*>(v)){row["Which"]=pointer(r->Which);row["same_unit_field"]=real_member_matches(s,r->Which);row["live_value"]=r->Which?number(*r->Which):json(nullptr);}
        else if(auto const*i=dynamic_cast<OutputProcessor::OutVarInt const*>(v)){row["Which"]=pointer(i->Which);row["same_unit_field"]=int_member_matches(s,i->Which);if(!row["same_unit_field"].empty()){int u=row["same_unit_field"][0]["unit"];row["live_value"]=static_cast<int>(s.dataPurchasedAirMgr->PurchAir(u).availStatus);}else row["live_value"]=i->Which?json(*i->Which):json(nullptr);}
        out["live"].push_back(row);
    }
    for(auto const*m:s.dataOutputProcessor->meters)out["meters"].push_back(json{{"Name",m->Name},{"type",static_cast<int>(m->type)},{"resource",static_cast<int>(m->resource)},{"endUseCat",static_cast<int>(m->endUseCat)},{"group",static_cast<int>(m->group)},{"units",static_cast<int>(m->units)},{"srcVarNums",m->srcVarNums},{"srcMeterNums",m->srcMeterNums},{"CurTSValue",number(m->CurTSValue)}});
    return out;
}
json errors(EnergyPlusData const&s,std::ostringstream const&error){auto const&e=*s.dataErrTracking;return json{{"text",error.str()},{"TotalWarningErrors",e.TotalWarningErrors},{"TotalSevereErrors",e.TotalSevereErrors},{"TotalWarningErrorsDuringWarmup",e.TotalWarningErrorsDuringWarmup},{"TotalSevereErrorsDuringWarmup",e.TotalSevereErrorsDuringWarmup},{"TotalWarningErrorsDuringSizing",e.TotalWarningErrorsDuringSizing},{"TotalSevereErrorsDuringSizing",e.TotalSevereErrorsDuringSizing},{"NumRecurringErrors",e.NumRecurringErrors},{"RecurringErrors",shape(e.RecurringErrors)},{"MatchCounts",integer_array(e.MatchCounts)}};}
json context(EnergyPlusData const&s,int zone,int list,int equipment){auto const&c=s.dataZoneEquip->ZoneEquipConfig(zone);auto const&l=s.dataZoneEquip->ZoneEquipList(list);auto const&d=s.dataZoneEnergyDemand->ZoneSysEnergyDemand(zone);auto const&w=s.dataZoneEnergyDemand->ZoneSysMoistureDemand(zone);auto const&h=*s.dataHVACGlobal;auto const&g=*s.dataGlobal;
    json out{{"state_address",pointer(&s)},{"zone",zone},{"list",list},{"equipment",equipment},{"CompIndex",l.EquipIndex(equipment)},
    {"config",json{{"address",pointer(&c)},{"ZoneName",c.ZoneName},{"IsControlled",c.IsControlled},{"ZoneNode",c.ZoneNode},{"EquipListIndex",c.EquipListIndex},{"InletNode",integer_array(c.InletNode)},{"ReturnNode",integer_array(c.ReturnNode)},{"ExhaustNode",integer_array(c.ExhaustNode)}}},
    {"demand",json{{"address",pointer(&d)},{"RemainingOutputRequired",number(d.RemainingOutputRequired)},{"RemainingOutputReqToHeatSP",number(d.RemainingOutputReqToHeatSP)},{"RemainingOutputReqToCoolSP",number(d.RemainingOutputReqToCoolSP)},{"SequencedOutputRequired",shape(d.SequencedOutputRequired)},{"SequencedOutputRequiredToHeatingSP",shape(d.SequencedOutputRequiredToHeatingSP)},{"SequencedOutputRequiredToCoolingSP",shape(d.SequencedOutputRequiredToCoolingSP)}}},
    {"moisture",json{{"address",pointer(&w)},{"RemainingOutputReqToHumidSP",number(w.RemainingOutputReqToHumidSP)},{"RemainingOutputReqToDehumidSP",number(w.RemainingOutputReqToDehumidSP)},{"SequencedOutputRequired",shape(w.SequencedOutputRequired)},{"SequencedOutputRequiredToHumidSP",shape(w.SequencedOutputRequiredToHumidSP)},{"SequencedOutputRequiredToDehumidSP",shape(w.SequencedOutputRequiredToDehumidSP)}}},
    {"TimeStepSys",number(h.TimeStepSys)},{"TimeStepSysSec",number(h.TimeStepSysSec)},{"HourOfDay",g.HourOfDay},{"TimeStep",g.TimeStep},{"BeginEnvrnFlag",g.BeginEnvrnFlag},{"SysSizingCalc",g.SysSizingCalc},{"WarmupFlag",g.WarmupFlag},
    {"TempControlType",static_cast<int>(s.dataHeatBalFanSys->TempControlType(zone))},{"setptLo",number(s.dataHeatBalFanSys->zoneTstatSetpts(zone).setptLo)},{"setptHi",number(s.dataHeatBalFanSys->zoneTstatSetpts(zone).setptHi)},
    {"airHumRat",number(s.dataZoneTempPredictorCorrector->zoneHeatBalance(zone).airHumRat)},{"StdRhoAir",number(s.dataEnvrn->StdRhoAir)},{"OutBaroPress",number(s.dataEnvrn->OutBaroPress)},{"OutHumRat",number(s.dataEnvrn->OutHumRat)},
    {"DayOfYear_Schedule",s.dataEnvrn->DayOfYear_Schedule},{"DayOfWeek",s.dataEnvrn->DayOfWeek},{"DSTIndicator",s.dataEnvrn->DSTIndicator},{"HolidayIndex",s.dataEnvrn->HolidayIndex},
    {"CO2Simulation",s.dataContaminantBalance->Contaminant.CO2Simulation},{"GenericContamSimulation",s.dataContaminantBalance->Contaminant.GenericContamSimulation},
    {"GetZoneEquipmentInputFlag",s.dataZoneEquipmentManager->GetZoneEquipmentInputFlag},{"ZoneEquipInputsFilled",s.dataZoneEquip->ZoneEquipInputsFilled},{"InitZoneEquipmentOneTimeFlag",s.dataZoneEquipmentManager->InitZoneEquipmentOneTimeFlag},{"InitZoneEquipmentEnvrnFlag",s.dataZoneEquipmentManager->InitZoneEquipmentEnvrnFlag},{"GetAvailMgrInputFlag",s.dataAvail->GetAvailMgrInputFlag}};
    out["availability_allocated"]=s.dataAvail->ZoneComp.allocated();if(s.dataAvail->ZoneComp.allocated()){auto const&a=s.dataAvail->ZoneComp(DataZoneEquipment::ZoneEquipType::PurchasedAir);out["availability"]=json{{"TotalNumComp",a.TotalNumComp},{"rows",shape(a.ZoneCompAvailMgrs)}};if(a.ZoneCompAvailMgrs.allocated())for(int i=a.ZoneCompAvailMgrs.l();i<=a.ZoneCompAvailMgrs.u();++i){auto const&r=a.ZoneCompAvailMgrs(i);out["availability"]["items"].push_back(json{{"address",pointer(&r)},{"NumAvailManagers",r.NumAvailManagers},{"availStatus",static_cast<int>(r.availStatus)},{"ZoneNum",r.ZoneNum}});}}
    return out;
}
struct Factory {
    std::unique_ptr<EnergyPlusData> state;
    std::ostringstream *error=nullptr;
    int zone=0,list=0,equipment=0;
    double sensible=0.0,moisture=0.0;
};
Factory make_factory(json const&input){Factory out;out.state=std::make_unique<EnergyPlusData>();auto&s=*out.state;
    s.files.eio.open_as_stringstream();s.files.eso.open_as_stringstream();s.files.mtr.open_as_stringstream();s.files.audit.open_as_stringstream();s.files.bnd.open_as_stringstream();s.files.debug.open_as_stringstream();s.files.mtd.open_as_stringstream();s.files.edd.open_as_stringstream();
    auto error=std::make_unique<std::ostringstream>();out.error=error.get();s.files.err_stream=std::move(error);
    s.init_constant_state(s);createCoilSelectionReportObj(s);
    s.dataStrGlobals->inputFilePath=input.at("input_file").get<std::string>();
    s.dataInputProcessing->inputProcessor->processInput(s);SimulationManager::PostIPProcessing(s);s.init_state(s);
    bool found_error=false;HeatBalanceManager::GetZoneData(s,found_error);require(!found_error,"actual GetZoneData error");ZoneEquipmentManager::GetZoneEquipment(s);
    require(s.dataGlobal->NumOfZones>0,"genuine positive zone count");
    for(int z=1;z<=s.dataGlobal->NumOfZones;++z){auto const&c=s.dataZoneEquip->ZoneEquipConfig(z);if(!c.IsControlled)continue;auto list=c.EquipListIndex;require(list>0,"getter-produced EquipListIndex");auto const&l=s.dataZoneEquip->ZoneEquipList(list);for(int i=1;i<=l.NumOfEquipTypes;++i)if(l.EquipType(i)==DataZoneEquipment::ZoneEquipType::PurchasedAir){require(out.zone==0,"unit factory selects unique actual PurchasedAir component");out.zone=z;out.list=list;out.equipment=i;}}
    require(out.zone>0,"actual PurchasedAir binding exists");
    // These are genuine class allocations for the narrow caller unit, with
    // extents produced by the real Zone getter, not fabricated count/ready flags.
    s.dataZoneEnergyDemand->ZoneSysEnergyDemand.allocate(s.dataGlobal->NumOfZones);s.dataZoneEnergyDemand->ZoneSysMoistureDemand.allocate(s.dataGlobal->NumOfZones);
    s.dataZoneTempPredictorCorrector->zoneHeatBalance.allocate(s.dataGlobal->NumOfZones);s.dataHeatBalFanSys->zoneTstatSetpts.allocate(s.dataGlobal->NumOfZones);s.dataHeatBalFanSys->TempControlType.allocate(s.dataGlobal->NumOfZones);
    Avail::ManageSystemAvailability(s); // genuine first flag -> full input -> flagfalse/return
    ZoneEquipmentManager::InitZoneEquipment(s,true);OutputReportPredefined::SetPredefinedTables(s);
    s.dataSize->CurZoneEqNum=out.zone; // same actual native caller assignment before Sim
    return out;
}
void apply_phase_inputs(Factory&f,json const&input){auto&s=*f.state;
    // Actual caller phase INPUTS before the genuine InitZoneEquipment prefix.
    if(input.contains("begin_environment"))s.dataGlobal->BeginEnvrnFlag=input.at("begin_environment").get<bool>();
    if(input.contains("std_rho"))s.dataEnvrn->StdRhoAir=real(input.at("std_rho"));
    if(input.contains("pressure"))s.dataEnvrn->OutBaroPress=real(input.at("pressure"));
    if(input.contains("system_hours"))s.dataHVACGlobal->TimeStepSys=real(input.at("system_hours"));
    if(input.contains("system_seconds"))s.dataHVACGlobal->TimeStepSysSec=real(input.at("system_seconds"));
    if(input.contains("hour"))s.dataGlobal->HourOfDay=input.at("hour").get<int>();
    if(input.contains("timestep"))s.dataGlobal->TimeStep=input.at("timestep").get<int>();
    if(input.contains("day_of_year"))s.dataEnvrn->DayOfYear_Schedule=input.at("day_of_year").get<int>();
    if(input.contains("day_of_week"))s.dataEnvrn->DayOfWeek=input.at("day_of_week").get<int>();
    if(input.contains("dst"))s.dataEnvrn->DSTIndicator=input.at("dst").get<int>();
    if(input.contains("warmup"))s.dataGlobal->WarmupFlag=input.at("warmup").get<bool>();
}
void apply_inputs(Factory&f,json const&input){auto&s=*f.state;auto z=f.zone;
    // Explicit named physical/demand INPUTS at the narrow Sim caller boundary.
    // No PurchasedAir output/result fields or computed current-operation answers.
    if(input.contains("heat_demand"))s.dataZoneEnergyDemand->ZoneSysEnergyDemand(z).RemainingOutputReqToHeatSP=real(input.at("heat_demand"));
    if(input.contains("cool_demand"))s.dataZoneEnergyDemand->ZoneSysEnergyDemand(z).RemainingOutputReqToCoolSP=real(input.at("cool_demand"));
    if(input.contains("thermostat_low"))s.dataHeatBalFanSys->zoneTstatSetpts(z).setptLo=real(input.at("thermostat_low"));
    if(input.contains("thermostat_high"))s.dataHeatBalFanSys->zoneTstatSetpts(z).setptHi=real(input.at("thermostat_high"));
    if(input.contains("control_type")){int value=input.at("control_type");require(value>=0&&value<(int)HVAC::SetptType::Num,"named control enum domain");s.dataHeatBalFanSys->TempControlType(z)=static_cast<HVAC::SetptType>(value);}
    auto const&c=s.dataZoneEquip->ZoneEquipConfig(z);require(c.ZoneNode>0,"actual Config ZoneNode");
    if(input.contains("zone_temp"))s.dataLoopNodes->Node(c.ZoneNode).Temp=real(input.at("zone_temp"));
    if(input.contains("zone_humidity")){auto value=real(input.at("zone_humidity"));s.dataLoopNodes->Node(c.ZoneNode).HumRat=value;s.dataZoneTempPredictorCorrector->zoneHeatBalance(z).airHumRat=value;}
    if(input.contains("zone_temp")||input.contains("zone_humidity")){auto&n=s.dataLoopNodes->Node(c.ZoneNode);n.Enthalpy=Psychrometrics::PsyHFnTdbW(n.Temp,n.HumRat);}
    // A single actual return node is a checked property of this raw unit input,
    // never a substituted Node ordinal. Native Init will select it itself.
    require(c.NumReturnNodes==1,"finite input has one actual return node");int r=c.ReturnNode(1);require(r>0,"actual return ordinal");
    if(input.contains("return_temp"))s.dataLoopNodes->Node(r).Temp=real(input.at("return_temp"));
    if(input.contains("return_humidity"))s.dataLoopNodes->Node(r).HumRat=real(input.at("return_humidity"));
    if(input.contains("return_temp")||input.contains("return_humidity")){auto&n=s.dataLoopNodes->Node(r);n.Enthalpy=Psychrometrics::PsyHFnTdbW(n.Temp,n.HumRat);}
    Sched::UpdateScheduleVals(s); // actual current values; no observer getter/Psy call
}
json snapshot(Factory&f){auto&s=*f.state;return json{{"manager",manager(s)},{"nodes",nodes(s)},{"context",context(s,f.zone,f.list,f.equipment)},{"sizing",globals(s)},{"reports",reports(s)},{"registration",registration(s)},{"errors",errors(s,*f.error)},{"returned_sensible",number(f.sensible)},{"returned_moisture",number(f.moisture)}};}
} // namespace NativeGapBatch::PurchasedAirDetail

namespace NativeGapBatch {
nlohmann::json run_purchased_air_batch(nlohmann::json const&named_inputs){using namespace PurchasedAirDetail;
    require(named_inputs.at("schema")=="src06-purchased-air-full-function-batch-input.v1","P1 input schema");json out{{"schema","src06-purchased-air-full-function-batch-output.v1"},{"cases",json::array()}};
    for(auto const&definition:named_inputs.at("factories")){
        auto factory=make_factory(definition);auto&s=*factory.state;json result{{"factory",definition.at("name")},{"origin",definition.at("origin")},{"setup",snapshot(factory)},{"steps",json::array()}};
        std::size_t ordinal=0;
        for(auto const&step:definition.at("steps")){
            ++ordinal;auto operation=step.at("operation").get<std::string>();bool first=step.value("first_hvac_iteration",false);
            apply_phase_inputs(factory,step.at("inputs"));
            json prefix=nullptr;
            if(operation=="simulate"){
                prefix=json{{"entry",snapshot(factory)}};
                ZoneEquipmentManager::InitZoneEquipment(s,first);
                prefix["exit"]=snapshot(factory);
            }
            apply_inputs(factory,step.at("inputs"));json record{{"name",step.at("name")},{"ordinal",ordinal},{"operation",step.at("operation")},{"named_inputs",step.at("inputs")},{"actual_caller_InitZoneEquipment_prefix",prefix},{"entry",snapshot(factory)}};
            auto&list=s.dataZoneEquip->ZoneEquipList(factory.list);auto const&actual_name=list.EquipName(factory.equipment);std::string name=step.value("name_argument",actual_name);int&index=list.EquipIndex(factory.equipment);std::string error;
            try {
                if(operation=="simulate")PurchasedAirManager::SimPurchasedAir(s,name,factory.sensible,factory.moisture,first,factory.zone,index);
                else if(operation=="init")PurchasedAirManager::InitPurchasedAir(s,index,factory.zone);
                else if(operation=="calc")PurchasedAirManager::CalcPurchAirLoads(s,index,factory.sensible,factory.moisture,factory.zone);
                else if(operation=="update")PurchasedAirManager::UpdatePurchasedAir(s,index,first);
                else if(operation=="report")PurchasedAirManager::ReportPurchasedAir(s,index);
                else throw std::runtime_error("unknown full-function operation");
            }catch(std::exception const&e){error=e.what();}
            record["exception"]=error.empty()?json(nullptr):json(error);record["exit"]=snapshot(factory);result["steps"].push_back(record);
            auto expected=step.value("expected_control_outcome",std::string("normal"));require((expected=="normal"&&error.empty())||(expected=="exception"&&!error.empty()),"full Native call did not reach named control outcome");
        }
        out["cases"].push_back(result);
    }
    out["no_existing59_2336_471_suite_reexecuted"]=true;return out;
}
} // namespace NativeGapBatch

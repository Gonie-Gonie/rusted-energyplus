"""Scoped one cfg genuine initial output stream fix over actual Source51 snapshot."""
from pathlib import Path
import argparse,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OUT=D/'Root-P1-open-output-application-53'
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
base=module(D/'apply-Source-gap-batch-Root-50.py','Source50_guards');g=base.g
def main(a):
 mr=g.argument(a.manifest);m=g.read(g.checked(mr));peer_ref=g.argument(a.peer);peer=g.read(g.checked(peer_ref))
 g.need(peer['accepted'] and not peer['findings'] and peer.get('reviewed_packet',peer.get('reviewed_draft'))==mr,'Exact accepted initial output stream peer')
 initial=g.read(D/'Root-gap-batch-P1-Surface-application-50/receipt.json');g.need(initial['accepted'] and not initial['findings'],'Actual Source50 application')
 g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==initial['base_HEAD'],'Same committed parent')
 old=g.read(g.checked(m['prior_compiler_plan']));g.exact({x['path']:x for x in old['entries']})
 failed=g.read(g.checked(m['actual_failed_P1_setup']));passed=g.read(g.checked(m['actual_Surface50_pass']))
 g.need(failed['exit_code']==101 and failed['source_bytes_match_before_and_after'] and passed['exit_code']==0 and passed['source_bytes_match_before_and_after'],'Preserved actual stream setup failure and separate Surface pass')
 row=m['files'][0];g.need(len(m['files'])==1,'One cfg leaf only');target=R/row['canonical_path'];before=g.checked(row['before']).read_bytes();proposed=g.checked(row['proposed']).read_bytes();g.need(target.read_bytes()==before,'Actual selected cfg leaf before')
 apply=g.literal();g.need(apply(before,g.checked(row['forward_diff']).read_bytes())==proposed and apply(proposed,g.checked(row['inverse_diff']).read_bytes())==before,'Literal forward/inverse')
 plan=g.read(g.checked(m['complete_proposed_compiler_Source_plan']));g.need((plan['inputs'],plan['Rust_sources'])==(4534,4531),'Unchanged full compiler inventory')
 fixtures=[g.ref(g.checked(x)) for x in m['external_fixtures_unchanged']];g.need(not OUT.exists(),'Fresh application directory');OUT.mkdir();(OUT/'before.rs').write_bytes(before)
 try:
  target.write_bytes(proposed);g.exact({x['path']:x for x in plan['entries']});g.need([g.ref(g.checked(x)) for x in fixtures]==fixtures,'External fixtures unchanged')
 except BaseException:target.write_bytes(before);raise
 result=dict(schema='src06-P1-open-output-application53.v1',accepted=True,findings=[],manifest=mr,independent_peer=peer_ref,base_HEAD=initial['base_HEAD'],
  actual_Source50_application=g.ref(D/'Root-gap-batch-P1-Surface-application-50/receipt.json'),complete_compiler_plan=m['complete_proposed_compiler_Source_plan'],
  initial_P1_stream_setup_failure=m['actual_failed_P1_setup'],carried_Surface50_pass=m['actual_Surface50_pass'],changed_Source_files=1,compiler_inputs=4534,Rust_sources=4531,
  all_final_compiler_bytes_exact=True,external_fixtures_unchanged=fixtures,actual_test_invocations=0,application_Source=g.ref(Path(__file__)))
 p=OUT/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--peer',required=True);main(p.parse_args())

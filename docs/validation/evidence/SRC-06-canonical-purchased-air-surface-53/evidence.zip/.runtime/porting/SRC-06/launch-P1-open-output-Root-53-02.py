"""Root-only ONE fresh PurchasedAir retry; unchanged Surface proof is carried, never rerun."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def module(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main(a):
 appmod=module(D/'apply-P1-open-output-Root-53-02.py','P1_53_guards');g=appmod.g
 ar=g.argument(a.application);g.need(g.checked(ar)==(appmod.OUT/'receipt.json').resolve(),'Expected application53')
 app=g.read(g.checked(ar));g.need(app['accepted'] and not app['findings'] and app['actual_test_invocations']==0,'Accepted application53')
 g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==app['base_HEAD'],'Same committed parent')
 plan=g.read(g.checked(app['complete_compiler_plan']));rows={x['path']:x for x in plan['entries']};g.exact(rows)
 source50=g.read(g.checked(g.read(D/'Root-gap-batch-P1-Surface-application-50/receipt.json')['draft']))
 fixture,refs=appmod.base.fixtures(source50,'purchased_air');before=[g.ref(g.checked(x)) for x in refs]
 settings=g.read(D/'purchased-air-gap-prepared-WAIT-Peer-P1/prepared.json');envmod=module(g.checked(settings['inherited_environment_guard']),'P1_53_exact_environment');env=envmod.environment();g.checked(settings['record_command_Source'])
 command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only','purchased_air',str(g.checked(fixture))]
 output=D/'canonical-source-purchased-air-gap-cohort-Root-53';guard=D/'Root-P1-runtime-fixture-guard-53';g.need(not output.exists() and not guard.exists(),'Fresh P1-only retry paths');guard.mkdir()
 (guard/'before.json').write_text(json.dumps(dict(application=ar,fixture=fixture,protected=before,command=command),indent=2)+'\n',encoding='utf-8',newline='\n')
 print('Root53: one genuine Source P1 genuine initial output stream retry; unchanged Surface50 and old2336/471/59/P2 not invoked.',flush=True)
 code=subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',output.relative_to(R).as_posix(),'--',*command],cwd=R,env=env)
 after=[g.ref(g.checked(x)) for x in refs];g.exact(rows)
 result=dict(schema='src06-P1-runtime-fixture-custody53.v1',accepted=before==after,findings=[] if before==after else ['Fixture changed'],application=ar,
  command=command,exit_code=code,protected_before=before,protected_after=after,all4534_compiler_inputs_unchanged=True,actual_receipt=g.ref(output/'receipt.json'),launch_Source=g.ref(Path(__file__)))
 (guard/'after.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');return code if before==after else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);raise SystemExit(main(p.parse_args()))

"""Root-only original-core unit caller, exact PID module gate before science.

Uses the frozen Native environment without recording its contents. No engine,
Cargo or Source test is launched; no FPU/cache controls are changed.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ast, ctypes, hashlib, json, math, os, re, struct, subprocess, time
from ctypes import wintypes
R = Path(__file__).resolve().parents[3]; D = R / '.runtime/porting/SRC-06'


def need(ok, why):
    if not ok: raise ValueError(why)


def ref(p):
    p = p.resolve()
    with p.open('rb') as f: h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(), sha256=h, bytes=p.stat().st_size)


def checked(v):
    p = (R / v['path']).resolve(); actual = ref(p)
    need(actual['sha256'] == v['sha256'] and actual['bytes'] == v.get('bytes', actual['bytes']), 'Changed authenticated file: ' + v['path'])
    return p


def read(p): return json.loads(p.read_bytes())


def scalar_count(value):
    if isinstance(value, dict):
        if 'value_bits' in value:
            need(set(value) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', value['value_bits']) is not None, 'One raw16hex scalar')
            number = struct.unpack('>d', bytes.fromhex(value['value_bits']))[0]; need(math.isfinite(number), 'Finite observed scalar'); return 1
        return sum(scalar_count(x) for x in value.values())
    if isinstance(value, list): return sum(scalar_count(x) for x in value)
    need(not isinstance(value, float), 'No unwrapped floating JSON field'); return 0



def admit(p, result, named, selected):
    need(selected in ['purchased_air','surface','exterior'],'One authenticated whole group')
    need(result['schema'] == 'src06-original-core-gap-batch-output.v1' and result['normal_completion'] is True,'Normal complete selected group schema')
    need(result['group_order'] == [selected] and set(result['groups']) == {selected},'Exactly selected complete group, no other science')
    count = scalar_count(result); output = result['groups'][selected]
    if selected == 'purchased_air':
        need(output['schema'] == 'src06-purchased-air-full-function-batch-output.v1','PurchasedAir full-function schema')
        need(len(output['cases']) == len(named[selected]['factories']) == 4,'Four actual raw-input factory lifetimes')
        calls = 0; lifetimes = []
        for actual, expected in zip(output['cases'],named[selected]['factories'],strict=True):
            need(actual['factory'] == expected['name'] and actual['origin'] == expected['origin'],'Factory identity/input provenance')
            need(len(actual['steps']) == len(expected['steps']) == 15,'All fifteen persistent calls')
            state = actual['setup']['context']['state_address']; need(state is not None,'Actual state constructor address')
            units = {}; nodes = {}; which = {}; operations = {}; snapshots = [actual['setup']]
            for ordinal,(step,definition) in enumerate(zip(actual['steps'],expected['steps'],strict=True),1):
                need(step['ordinal'] == ordinal and step['name'] == definition['name'] and step['operation'] == definition['operation'] and step['named_inputs'] == definition['inputs'],'Exact named operation/input sequence')
                need(step['exception'] is None,'Normal finite original full-function call')
                need((step['actual_caller_InitZoneEquipment_prefix'] is not None) == (step['operation'] == 'simulate'),'Actual prefix exactly at full Sim calls')
                if step['actual_caller_InitZoneEquipment_prefix'] is not None:
                    snapshots += [step['actual_caller_InitZoneEquipment_prefix'][k] for k in ['entry','exit']]
                snapshots += [step['entry'],step['exit']]
                manager = step['exit']['manager']
                need(manager['NumPurchAir'] == 1 and not manager['GetPurchAirInputFlag'] and len(manager['PurchAir']['items']) == 1,'Genuine lazy getter count/latch/row')
                need(0 < step['exit']['context']['CompIndex'] <= manager['NumPurchAir'],'Actual retained CompIndex lvalue')
                operations[step['operation']] = operations.get(step['operation'],0)+1;calls += 1
            for snap in snapshots:
                need(snap['context']['state_address'] == state,'Same state throughout complete factory lifetime')
                node_rows=snap['nodes']['Node']['items']; ids=snap['nodes']['NodeID']['items']
                need(len(ids) == len(node_rows)+1 and ids[0] == 'Undefined','Actual NodeID lower0/physical Node association')
                for ordinal,row in enumerate(node_rows,1):
                    need(len(row) == 49 and row['address'] is not None,'All48 initialized actual Node members plus address')
                    if ordinal in nodes:need(nodes[ordinal] == row['address'],'Same physical Node row over retained calls')
                    else:nodes[ordinal]=row['address']
                for ordinal,row in enumerate(snap['manager']['PurchAir']['items'],1):
                    need(len(row) == 135 and row['address'] is not None,'All134 initialized actual unit members plus address')
                    if ordinal in units:need(units[ordinal] == row['address'],'Same retained unit row over calls')
                    else:units[ordinal]=row['address']
                for ordinal,row in enumerate(snap['registration']['live']):
                    need(row['Which'] is not None,'Real registered Which target')
                    key=(ordinal,row['name'],row['key'])
                    if key in which:need(which[key] == row['Which'],'Same live Which target over calls')
                    else:which[key]=row['Which']
                    for match in row['same_unit_field']:
                        unit=snap['manager']['PurchAir']['items'][match['unit']-1]
                        need(unit[match['member']] == row['live_value'],'Live Which read equals actual same unit member, no cached answer')
            lifetimes.append(dict(name=actual['factory'],step_count=15,direct_operation_counts=operations,snapshots_checked=len(snapshots),physical_Node_rows=len(nodes),unit_rows=len(units),live_Which_targets=len(which),same_state_address=state,qualification='Identity only within this factory; later lifetimes may reuse allocator addresses.'))
        need(calls == 60,'All sixty original PurchasedAir calls')
        return dict(selected_group=selected,raw_finite_binary64_fields=count,purchased_air_factories=4,PurchasedAir_full_function_calls=60,same_lifetime_physical_owners=lifetimes)
    need(output['schema'] == ('src06-original-surface-gap-output.v1' if selected == 'surface' else 'src06-original-exterior-gap-output.v1'),'Exact selected full-function schema')
    shapes = {}; call_counts = {}
    for key,values in named[selected].items():
        if key == 'schema':continue
        need(isinstance(values,list) and isinstance(output[key],list) and len(output[key]) == len(values),'Every named case retained: '+key)
        need([x['name'] for x in output[key]] == [x['name'] for x in values],'Exact named case order: '+key)
        shapes[key]=len(values);calls=0
        for case,definition in zip(output[key],values,strict=True):
            if 'input' in case:need(case['input'] == definition,'Actual primary input provenance: '+key)
            source_key='exchanges' if key == 'radiation' else 'calls' if key == 'schedule_minute' else 'times' if key == 'solar_clock' else 'steps'
            if source_key in definition:
                extra=2 if key == 'radiation' else 0
                need(len(case['calls']) == len(definition[source_key])+extra,'Every ordered full call: '+key);calls += len(case['calls'])
                for actual,primary in zip(case['calls'][extra:],definition[source_key],strict=True):
                    operand='primary_call' if key == 'schedule_minute' else 'primary_time' if key == 'solar_clock' else 'primary_clock' if key in ['internal_gains','beam_producer','surface_internal_gains'] else 'primary_step'
                    need(actual[operand] == primary,'Exact actual named call input: '+key)
            else:calls += 1
        call_counts[key]=calls
    return dict(selected_group=selected,raw_finite_binary64_fields=count,supplemental_named_case_counts=shapes,ordered_full_call_record_counts=call_counts,qualification='Actual original full-method outputs from named primary INPUTS. Absorption/solar paired records each invoke two full methods; not Source equivalence or whole-engine/card completion.')




def retry_custody(p):
    previous = read(checked(p['previous_ready_manifest']))
    actual = read(checked(p['preserved_accepted_build02']))
    failed = read(checked(p['preserved_failed_science_run02']))
    assert actual['accepted'] and not actual['findings'] and actual['Native_bytes_match_before_and_after'] and actual['reviewed_manifest'] == p['previous_ready_manifest']
    assert not failed['accepted'] and failed['exit_code'] != 0 and failed['Native_bytes_match_before_and_after'] and failed['actual_three_GNU_DLL_binding_proved_before_any_science_call'] and failed['full_unit_output'] is None and failed['actual_build'] == p['preserved_accepted_build02']
    rows = [p['previous_ready_manifest'],p['preserved_accepted_build02'],p['preserved_failed_science_run02'],p['binding_only_correction'],p['independent_binding_only_peer']]
    binding = read(checked(p['binding_only_correction'])); peer = read(checked(p['independent_binding_only_peer']))
    assert peer['accepted'] and not peer['findings'] and peer.get('reviewed_draft',peer.get('reviewed_packet')) == p['binding_only_correction']
    assert p['caller_Sources'][1] == binding['files'][0]['proposed'] == previous['caller_Sources'][1]
    assert p['caller_Sources'][2] == binding['files'][1]['proposed'] == previous['caller_Sources'][2]
    for leaf in p['retry_independent_peers']:
        reviewed = read(checked(leaf['peer'])); assert reviewed['accepted'] and not reviewed['findings'] and reviewed.get('reviewed_draft',reviewed.get('reviewed_packet')) == leaf['draft']
        rows += [leaf['draft'],leaf['peer']]
    driver = read(checked(p['retry_independent_peers'][0]['draft']))
    producer = read(checked(p['retry_independent_peers'][2]['draft']))
    assert p['caller_Sources'][0] == driver['main']['proposed'] and p['common_header'] == driver['unchanged_original_header'] == previous['common_header']
    correction = read(checked(p['compile_only_correction08']))
    correction_peer = read(checked(p['independent_compile_only_peer08']))
    assert correction_peer['accepted'] and not correction_peer['findings'] and correction_peer['reviewed_draft'] == p['compile_only_correction08']
    assert correction['preserved_07'] == p['retry_independent_peers'][2]['draft'] and correction['accepted_07_peer'] == p['retry_independent_peers'][2]['peer']
    assert correction['before'] == producer['payload'][1] and correction['proposed'] == p['caller_Sources'][3]
    assert correction['literal_inverse_whole_07_exact'] and correction['all_primary_input_bytes_unchanged_from07']
    failed03 = read(checked(p['preserved_failed_compile_build03']))
    assert correction['preserved_actual_failed_build'] == p['preserved_failed_compile_build03'] == correction_peer['actual_failed_build']
    assert not failed03['accepted'] and failed03['Native_bytes_match_before_and_after'] and failed03['reviewed_manifest'] == p['retry_predecessor_READY05']
    assert len(failed03['compiles']) == 4 and [read(checked(x))['exit_code'] for x in failed03['compiles']] == [0, 0, 0, 1]
    assert failed03['link'] is None and failed03['actual_link_invocations'] == 0
    rows += [p['compile_only_correction08'], p['independent_compile_only_peer08'], p['preserved_failed_compile_build03'], p['retry_predecessor_READY05']]
    lu = read(checked(p['retry_independent_peers'][1]['draft']))
    old_named = read(checked(previous['named_inputs'])); new_named = read(checked(p['named_inputs']))
    corrected = read(checked(lu['input_corrections'][2]['proposed']))
    assert new_named['purchased_air'] == old_named['purchased_air'] and new_named['surface'] == corrected['surface'] and new_named['exterior'] == corrected['exterior']
    assert set(new_named) == {'schema','purchased_air','surface','exterior'} and new_named['schema'] == old_named['schema']
    def collect(value):
        if isinstance(value,dict):
            if {'path','sha256','bytes'} <= value.keys(): rows.append(value)
            else:
                for child in value.values(): collect(child)
        elif isinstance(value,list):
            for child in value: collect(child)
    for value in [binding,driver,producer,lu,correction,correction_peer,failed03]: collect(value)
    for value in failed03['compiles']: collect(read(checked(value)))
    for row in p['strict_new_producer_original_function_refs']:
        whole = next(x['whole'] for x in p['Native_authorities'] if x['Native_path'] == row['Native_path'])
        lines = checked(whole).read_bytes().splitlines(keepends=True)
        body = b''.join(lines[row['first']-1:row['last']]).rstrip(b'\r\n')
        assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
    return [ref(checked(v)) for v in {x['path']:x for x in rows}.values()]


def main(a):
    need(a.run_only, 'Root explicit run-only flag')
    name, sha = a.build.rsplit('#', 1); bp = (R / name).resolve(); need(ref(bp)['sha256'] == sha, 'Authenticated actual build receipt')
    build = read(bp); need(build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after'], 'Actual accepted original-core build')
    need(all(build['original_core_member_counts'].values()) and not build['forbidden_derived_object_witnesses'], 'Original core symbols witnessed')
    mp = checked(build['reviewed_manifest']); p = read(mp); need(checked(p['run_Source']) == Path(__file__).resolve(), 'Exact reviewed run Source')
    binding_rows = retry_custody(p)
    base = read(checked(p['inherited_original_core_recipe'])); binary = checked(build['binary']); ip = checked(p['named_inputs']); named = read(ip)
    need(named['schema'] == 'src06-original-core-gap-batch-input.v1', 'Named input schema')
    frozen = read(checked(base['frozen_environment'])); need(frozen['accepted'], 'Frozen accepted environment')
    environment = frozen['environment']; env = {k.casefold(): v for k, v in environment.items()}; need(len(env) == len(environment), 'No environment key collision')
    env_hash = hashlib.sha256(json.dumps(environment, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf8')).hexdigest()
    need(env_hash == build['environment_values_sha256'], 'Same true frozen environment values by hash only')
    systemroot = Path(env['systemroot'])
    query_source = checked(base['inherited_module_query_Source']); tree = ast.parse(query_source.read_bytes())
    classes = [x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'ChildModules']; need(len(classes) == 1, 'One complete inherited PSAPI query class')
    ns = dict(need=need, os=os, ctypes=ctypes, wintypes=wintypes, Path=Path)
    exec(compile(ast.Module(body=classes, type_ignores=[]), '<unchanged inherited child module observer>', 'exec'), ns)
    output = D / ('original-core-gap-batch-run-Root-04-' + a.group); need(not output.exists(), 'Fresh run metadata directory')
    result_path = Path(p['fresh_unit_directory']) / (a.group + '.unit-output.json'); need(not result_path.exists(), 'Fresh actual result path')
    rows = [ref(bp), ref(mp), build['binary'], p['named_inputs'], p['common_header'], *p['caller_Sources'], *base['protected_files'], ref(systemroot / 'System32/kernel32.dll'), ref(systemroot / 'System32/psapi.dll')]
    rows += [x[k] for x in p['independent_leaves'] for k in ['draft', 'peer']]
    rows += p['input_files']
    rows += binding_rows
    checkout = p['Native_checkout']; native = (R / checkout['path']).resolve()
    def checkout_unchanged():
        need(subprocess.check_output(['git', '-C', str(native), 'rev-parse', 'HEAD'], text=True).strip() == checkout['pinned_HEAD'], 'Pinned Native checkout HEAD')
        need(subprocess.check_output(['git', '-C', str(native), 'status', '--porcelain=v1', '--untracked-files=no'], text=True) == checkout['tracked_status'], 'Unchanged Native tracked source/header state')
    checkout_unchanged()
    protected = list({x['path']: x for x in rows}.values()); before = [ref(checked(x)) for x in protected]
    expected = {Path(x['path']).name.casefold(): checked(x) for x in base['pinned_runtime_DLLs']}; need(len(expected) == 3, 'Three exact GNU providers')
    output.mkdir()

    def write(name, value):
        target = output / name
        with target.open('xb') as f: f.write((json.dumps(value, indent=2) + '\n').encode())
        return ref(target)

    br = write('Native-before.json', dict(protected_files=before, frozen_environment_ref=base['frozen_environment'], environment_values_sha256=env_hash, no_environment_values_recorded=True))
    command = [str(binary), str(ip), str(result_path), '--group', a.group]; so, se = output / 'stdout.log', output / 'stderr.log'
    process = None; code = None; error = None; query = None; modules = None; bindings = []; errors = []; attempts = 0; ready = False; released = False
    start = datetime.now(timezone.utc).isoformat(); tick = time.monotonic()
    with so.open('xb') as out, se.open('xb') as err:
        try:
            process = subprocess.Popen(command, cwd=R, env=environment, stdout=out, stderr=err, stdin=subprocess.PIPE)
            deadline = time.monotonic() + 30
            while process.poll() is None and time.monotonic() < deadline:
                ready = so.read_bytes() in [b'NATIVE_GAP_BATCH_READY\n', b'NATIVE_GAP_BATCH_READY\r\n']
                if ready:
                    attempts += 1
                    try:
                        if query is None: query = ns['ChildModules'](process.pid, systemroot)
                        snapshot = query.snapshot()
                        if set(expected).issubset({Path(x['actual_path']).name.casefold() for x in snapshot}): modules = snapshot; break
                    except (OSError, ValueError) as e:
                        if len(errors) < 16: errors.append(dict(type=type(e).__name__, message=str(e)))
                time.sleep(.01)
            need(ready and modules is not None and process.poll() is None, 'Actual ready child and all three modules before any science call')
            for name, path in expected.items():
                matches = [x for x in modules if Path(x['actual_path']).name.casefold() == name]
                need(len(matches) == 1 and Path(matches[0]['actual_path']).resolve() == path, 'Exact PID GNU provider path')
                bindings.append(dict(module=matches[0], actual_file=ref(path)))
            need(len(bindings) == 3, 'All provider hashes bound before release')
            process.stdin.write(b'g'); process.stdin.flush(); process.stdin.close(); released = True; code = process.wait(timeout=600)
        except (OSError, ValueError, subprocess.TimeoutExpired) as e:
            error = dict(type=type(e).__name__, message=str(e))
            if process is not None and process.poll() is None: process.kill()
            if process is not None: code = process.wait()
        finally:
            if query is not None: query.close()
    checkout_unchanged()
    after = [ref(checked(x)) for x in protected]; need(before == after, 'Protected original-core/provider/recipe bytes unchanged')
    ar = write('Native-after.json', dict(protected_files=after, environment_values_sha256=env_hash, no_environment_values_recorded=True))
    mr = write('actual-child-modules.json', dict(child_PID=process.pid if process else None, ready_before_release=ready, module_proof_before_release=len(bindings) == 3, one_byte_release_sent=released, attempts=attempts, first16_query_errors=errors, all_observed_modules=modules, actual_three_GNU_bindings=bindings))
    findings = []; admission = None
    if code != 0 or error: findings.append('Original-core scientific caller did not complete0 after genuine module admission.')
    if not findings:
        try:
            admission = admit(p, read(result_path), named, a.group)
            completed = Path(str(result_path) + '.' + a.group + '.json'); checkpoint = Path(str(result_path) + '.checkpoint.json')
            data = read(result_path); need(read(completed) == dict(schema='src06-original-core-gap-completed-group.v1',group=a.group,native_group=data['groups'][a.group],normal_completion=True),'Exact completed-group checkpoint provenance')
            partial = read(checkpoint); need(partial['normal_completion'] is False and partial['groups'] == data['groups'] and partial['group_order'] == [a.group] and partial['schema'] == data['schema'],'Passive partial checkpoint never claims normal completion')
        except (AssertionError, KeyError, TypeError, ValueError, OSError) as e: findings.append(dict(type=type(e).__name__, message=str(e)))
    accepted = code == 0 and error is None and not findings and admission is not None
    receipt = dict(schema='src06-original-core-gap-batch-run.v1', accepted=accepted, findings=findings, actual_build=ref(bp), reviewed_manifest=ref(mp), independent_leaves=p['independent_leaves'], selected_group=a.group, retry_independent_peers=p['retry_independent_peers'], preserved_accepted_build02=p['preserved_accepted_build02'], preserved_failed_science_run02=p['preserved_failed_science_run02'], binding_only_correction=p['binding_only_correction'], independent_binding_only_peer=p['independent_binding_only_peer'], preserved_first_failed_build=p['preserved_first_failed_build'], compile_only_correction08=p['compile_only_correction08'], independent_compile_only_peer08=p['independent_compile_only_peer08'], preserved_failed_compile_build03=p['preserved_failed_compile_build03'], retry_predecessor_READY05=p['retry_predecessor_READY05'], command=command, cwd=R.as_posix(), child_PID=process.pid if process else None, exit_code=code, launch_error=error, started_utc=start, finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-tick, stdout=ref(so), stderr=ref(se), Native_before=br, Native_after=ar, Native_bytes_match_before_and_after=before == after, actual_child_modules=mr, actual_three_GNU_DLL_binding_proved_before_any_science_call=len(bindings) == 3 and released, full_unit_output=ref(result_path) if result_path.exists() else None, completed_group_output=ref(Path(str(result_path)+'.'+a.group+'.json')) if Path(str(result_path)+'.'+a.group+'.json').exists() else None, partial_checkpoint=ref(Path(str(result_path)+'.checkpoint.json')) if Path(str(result_path)+'.checkpoint.json').exists() else None, admission=admission, frozen_environment_ref=base['frozen_environment'], environment_values_sha256=env_hash, no_environment_values_recorded=True, previous59_2336_471_Source_suites_executed=False, engine_Cargo_or_Source_test_executed=False, author_Source=ref(Path(__file__)))
    print(json.dumps(write('receipt.json', receipt))); return 0 if accepted else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--build', required=True); p.add_argument('--run-only', action='store_true'); p.add_argument('--group',required=True,choices=['purchased_air','surface','exterior']); raise SystemExit(main(p.parse_args()))

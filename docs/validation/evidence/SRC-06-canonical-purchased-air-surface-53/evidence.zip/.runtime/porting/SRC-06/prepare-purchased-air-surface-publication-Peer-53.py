"""Finite private evidence whitelist/archive and curated publication suggestions only."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'purchased-air-surface-publication-draft-Peer-53'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',v.get('size_bytes',a['bytes']));return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();actual_path=D/'Root-source-gap-batch-actual-review-53/review.json';actual=read(actual_path);assert ref(actual_path)['sha256']=='bbac4d29c940910b1f30d9f75811a1ca916521b37b6bce0903e67d26f006a940'
 assert actual['accepted'] and not actual['findings'] and actual['full_call_records']==115
 app=read(checked(actual['application']));original=read(checked(actual['original_Source50_application']));draft=read(checked(actual['draft']));plan=read(checked(actual['complete_compiler_plan']));current={x['path']:x for x in plan['entries']};rows={}
 def add(v,purpose):
  p=checked(v);a=ref(p);assert p.is_file() and p.suffix.lower() not in ['.zip','.exe','.dll','.obj','.a','.map','.rlib','.rmeta'] and a['bytes']<32*1024*1024
  assert 'frozen-environment' not in p.name.casefold() and 'source-objects' not in p.as_posix() and 'observation.json' not in p.name
  if p.suffix.lower()=='.json':
   value=read(p);assert not isinstance(value,dict) or not any(k in value for k in ['full_explicit_environment','environment'])
  name=a['path'];archive_name=name if p.is_relative_to(R) else 'external-metadata/'+a['sha256']+'/'+p.name
  if name in rows:assert rows[name]['source']==a;rows[name]['purposes']=sorted(set(rows[name]['purposes']+[purpose]))
  else:rows[name]=dict(source=a,archive_path=archive_name,purposes=[purpose])
 def file(p,purpose):add(ref(p),purpose)
 def direct_refs(v,purpose):
  # Explicit already-selected small packet fields only. Never open referenced JSON recursively.
  if isinstance(v,dict):
   if 'path' in v and 'sha256' in v:add(v,purpose)
   else:
    for c in v.values():direct_refs(c,purpose)
  elif isinstance(v,list):
   for c in v:direct_refs(c,purpose)
 for p in [actual_path,Path(__file__),D/'check-Source-gap-batch-actual-Root-53.py',D/'check-Source-gap-batch-actual-Root-53-02.py',D/'gap-actual-checker-correction-Peer-53-02/correction.json']:
  file(p,'Actual combined review/checker and preserved metadata-only checker precheck')
 for v in [actual['application'],actual['original_Source50_application'],actual['draft'],actual['independent_join_peer'],actual['complete_compiler_plan'],actual['Surface50_to_Source53_impact_bridge']['old_compiler_plan'],actual['inherited_environment_guard'],actual['record_command_Source'],actual['scoped_P1_helpers_prepared']]:add(v,'Current actual applications/plans/peer/environment policy')
 prep=read(checked(actual['scoped_P1_helpers_prepared']));direct_refs(prep['files'],'Scoped53 helper sources/diffs');direct_refs(prep['preserved_unexecuted_preparation'],'Preserved helper metadata correction');add(app['application_Source'],'Actual scoped application Source')
 # Current selected20 Sources and only their literal before/proposed/diffs.
 assert len(draft['files'])==20
 for f in draft['files']:
  name=f['canonical_path'];p=R/name;a=ref(p);assert (a['sha256'],a['bytes'])==(current[name]['final_sha256'],current[name]['final_bytes']);add(a,'Current selected20 compiler Source wholes');direct_refs(f,'Original20 literal Source history')
 for c in actual['cfg_corrections']:
  add(c['manifest'],'Actual cfg-only correction packet');add(c['independent_peer'],'Independent narrow correction peer');direct_refs(c['files'],'Exact cfg-only correction before/proposed/forward/inverse')
  packet=read(checked(c['manifest']));add(packet['author_Source'],'Correction author')
  for key in ['static_actual_association_proof','static_schema_audit','independent_complete_container_census','initial_stream_provenance']:
   if key in packet:add(packet[key],'Bounded factory/schema/stream provenance')
 # Whole external fixtures contain authentic full selected Native output losslessly;
 # do not duplicate the28MB raw Native P1 output or archive old Source trees.
 for result in actual['ordered_successful_groups']:
  for k in ['actual_receipt','application','fixture','fixture_guard','stdout','stderr','actual_Native_run']:add(result[k],'Accepted selected group actual/custody/whole fixture')
  native=read(checked(result['actual_Native_run']));add(native['actual_build'],'Shared actual original-core build metadata')
  for k in ['stdout','stderr','Native_before','Native_after','actual_child_modules','author_Source']:
   if k in native:direct_refs(native[k],'Native actual admission/modules/custody metadata')
 for failure in actual['preserved_failed_P1_invocations']:
  add(failure['actual_receipt'],'Preserved real P1 compile/setup failure');f=read(checked(failure['actual_receipt']))
  for k in ['stdout','stderr']:add(f[k],'Preserved actual failure log')
 for key in ['original_P1_full_peer','original_P1_scaffold','runtime_runner_peer','original_runtime_runner','Surface_full_independent_peer','Surface_adapter','P1_independent_correction_peer','P1_two_binding_correction','Surface_hub_fixture','P1_fixture_proof']:
  add(draft[key],'Accepted original bounded Source/fixture/caller lineage')
 # Select only the real actual Native producer TU/header/main and its two bounded
 # P1/Surface readsets/peers. No recursive snapshots/core/archives/registry/env.
 ready=read(D/'original-core-gap-batch-recipes-ready-Peer-06/manifest.json')
 for v in ready['caller_Sources'][:3]+[ready['common_header'],ready['named_inputs']]:add(v,'Actual Native P1/Surface/common producer Source or named primary inputs')
 for leaf in ready['independent_leaves']:
  add(leaf['draft'],'Original Native P1/Surface bounded readset');add(leaf['peer'],'Independent original Native P1/Surface Source peer');doc=read(checked(leaf['draft']))
  for authority in doc['Native_authorities']:
   add(authority['whole'],'Pinned Native whole authority')
   for extent in authority.get('extents',[]):
    source=extent.get('source',extent.get('excerpt'))
    if source:add(source,'Pinned strict Native readset extent')
 for key in ['input_transport_proof','P1_input_transport_proof']:
  if key in draft:add(draft[key],'Genuine raw/IDF ingress preservation proof')
 file(D/'source-purchased-air-gap-scaffold-Peer-01/input-transport-proof.json','Genuine raw47 input transport proof')
 total=sum(x['source']['bytes'] for x in rows.values());assert total<80*1024*1024
 whitelist=save(O/'finite-whitelist.json',dict(schema='src06-P1-Surface53-explicit-finite-whitelist.v1',entries=sorted(rows.values(),key=lambda x:x['source']['path']),uncompressed_bytes=total,exclusions=['All old Source snapshot ledgers/trees and parent evidence ZIP recursion','Original core/static archives/objects/binaries/DLLs/maps','Full frozen environment values and live compile registry','Duplicate original28MB Native P1 output; whole runtime fixture already retains it losslessly','Unexecuted later OP/history/Exterior numerical claims'],author_Source=ref(Path(__file__))))
 z=O/'evidence.zip'
 with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for row in sorted(rows.values(),key=lambda x:x['archive_path']):
   info=zipfile.ZipInfo(row['archive_path'],date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;archive.writestr(info,checked(row['source']).read_bytes())
 with zipfile.ZipFile(z) as archive:
  assert archive.testzip() is None and set(archive.namelist())=={x['archive_path'] for x in rows.values()}
  for row in rows.values():
   content=archive.read(row['archive_path']);assert len(content)==row['source']['bytes'] and hashlib.sha256(content).hexdigest()==row['source']['sha256']
 doc_suggestions=dict(policy='Suggested compact replacements/short card facts only; Root owns exact current UTF8 before/proposed custody and canonical publication. No gate promotion or chronological Source chain append.',
  README_progress_rows=[dict(scope='Persistent direct no-OA IdealLoads',fact='Four genuine getter factories and60 retained full Sim/Init/Calc/Update/Report calls pass75,524 strict Source state observations; Native whole output has75,672finite values, including148named input values.'),dict(scope='Radiation/LU/master-history/minute schedule',fact='Surface50 passed55records:21radiation,3LU inverses,14master-history and17minute-schedule records. Result carries to Source53 only through one exact P1-private cfg-child plan delta; all other4,533compiler inputs are unchanged.')],
  replace_next_work_sentence='Remaining work includes retry/revert air history and multipliers, solar/internal-gain producers and their consumers, full OutputProcessor accumulation/reset, warmup-to-RunPeriod handoff, and final same-Source15-case/ownJSONCSV closure. This checkpoint does not repeat old2336/471/59/P2bodies or long-duration runs.',
  card_facts={
   'HVAC-01..07':'60actual full persistent calls cover first/repeat/off/heating/cooling/deadband/rearm/new-environment behavior through real Config/List/Node/Schedule/availability/output owners in four finite limit-mode factories. All134unit/13manager/48Node members and real EIO/CompSize/liveWhich state are observed; positive excluded children/private cache remain qualified.',
   'RAD-02':'Full FixViewFactors and same-lifetime ScriptF/exchange records include small/unbalanced and enforced-reciprocity behavior, exact diagnostics/output arguments and preserved state. This is not CalcApproximateViewFactors producer coverage.',
   'RAD-03':'Same true ScriptF path plus3original LU/inverse cases; corrected nonsingular named primary input is retained with original failed singular execution. No toy inverse or expected matrix seeding.',
   'RAD-04':'Three retained radiation lifetimes and21records include full original exchange calls; scratch definedness is shape-only until genuine first normal writer. No broader geometry/solar producer claim.',
   'SUR-06':'Two retained master-history lifetimes,14records, compare the actual UpdateThermalHistories kernel with19x8arrays and related counter/scratch/report owners. No unrelated warmup handoff claim.',
   'SCH-02':'Eleven named minute lifetimes and17records exercise actual shared No/Average/Linear/minute-grid/Day-populate paths, full1,440values and set mask, retained sum and diagnostics. Broader production non-No admission remains a separate boundary.'},
  four_gates='A14/54 and B14/64 unchanged; card obligations are not blanket closed by this scoped comparison.',evidence_link='evidence/SRC-06-canonical-purchased-air-surface-53/summary.json')
 suggestions=save(O/'curated-doc-suggestions.json',doc_suggestions)
 template=save(O/'template.json',dict(schema='src06-P1-Surface53-private-publication-template.v1',status='READY_FOR_ROOT_CURATED_DOC_REPLACEMENTS_AND_PUBLICATION',public_directory='energyplus_porting_plan/evidence/SRC-06-canonical-purchased-air-surface-53',base_HEAD=actual['base_HEAD'],actual_review=ref(actual_path),complete_compiler_plan=actual['complete_compiler_plan'],finite_archive=ref(z),finite_whitelist=whitelist,curated_doc_suggestions=suggestions,
  summary=dict(accepted=True,findings=[],full_call_records=115,P1_calls=60,Surface_records=55,P1_Source_strict_raw_bit_state_observations=75524,P1_Native_entire_output_finite_f64=75672,P1_named_input_bit_objects=148,P1_state_snapshots=204,SourceP1_successful_receipt=actual['ordered_successful_groups'][0]['actual_receipt'],Surface50_successful_receipt=actual['ordered_successful_groups'][1]['actual_receipt'],Surface_to_current_exact_P1_cfg_only_bridge=actual['Surface50_to_Source53_impact_bridge'],compiler_inputs=4534,Rust_sources=4521,accepted_selected_Cargo_invocations=2,P1_total_attempts=5,prior_compile_setup_failures=actual['preserved_failed_P1_invocations'],same_successful_compiler_snapshot_claim=False,private_cache_state_observed=False,new_normal_CLI_or_engine_runs=0,old2336_471_59_P2_rerun=False,gates_changed=False),
  publication_contract='Root alone copies finite archive, writes summary/entry index and compact current-document replacements, runs docsQA, verifies staged rawbytes, commits/pushes. This private author does not mutate canonical docs/Git.',author_Source=ref(Path(__file__))))
 manifest=save(O/'manifest.json',dict(schema='src06-P1-Surface53-private-publication-preparation.v1',status='READY_PRIVATE_NO_PUBLICATION',template=template,evidence_archive=ref(z),finite_whitelist=whitelist,finite_entries=len(rows),uncompressed_bytes=total,all_ZIP_CRC_size_SHA_checked=True,actual_review=ref(actual_path),curated_doc_suggestions=suggestions,canonical_docs_Source_Git_or_Cargo_mutations=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,template=template,archive=ref(z),whitelist=whitelist,entries=len(rows),uncompressed_bytes=total,suggestions=suggestions)))
if __name__=='__main__':main()

from pathlib import Path
import hashlib, json, subprocess
R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
O=D/'Root-source43-Git-text-transport-view'
assert not O.exists()
def ref(p):
    b=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
    p=R/v['path'];assert ref(p)==v;return p
mp=D/'source-hard-sized-purchased-air-cohort-combined-held-Peer-43/manifest.json'
assert ref(mp)['sha256']=='07042064f18e8ccbf7eb42a3303c68b5d0cf393cc9f5acc0a1bcbc624a4712c2'
m=json.loads(mp.read_bytes())
expected={
 'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/initialization.rs':294,
 'crates/ep_runtime/src/heat_balance/selected_sizing/autosizing.rs':311,
 'crates/ep_runtime/src/heat_balance/selected_sizing/autosizing/globals.rs':167,
}
rows=[];projections={}
for v in m['files']:
    n=v['canonical_path'];p=R/n;b=p.read_bytes();assert b==checked(v['proposed']).read_bytes()
    count=b.count(b'\r\n');assert b.count(b'\r')==count
    assert count==expected.get(n,0),(n,count)
    projected=b.replace(b'\r\n',b'\n')
    oid=subprocess.check_output(['git','hash-object','--stdin','--path='+n],cwd=R,input=b).strip().decode()
    raw_oid=subprocess.check_output(['git','hash-object','--stdin','--no-filters'],cwd=R,input=projected).strip().decode()
    assert oid==raw_oid,(n,oid,raw_oid)
    row=dict(path=n,actual_compiled_live=ref(p),CRLF_count=count,Git_filter_blob_oid=oid,canonical_Git_LF_sha256=hashlib.sha256(projected).hexdigest(),canonical_Git_LF_bytes=len(projected),only_CRLF_to_LF=count>0)
    if count:projections[n]=projected
    rows.append(row)
assert len(rows)==16 and len(projections)==3
attrs=subprocess.check_output(['git','check-attr','text','eol','--',*expected],cwd=R,text=True)
assert attrs.count(': text: auto')==3 and attrs.count(': eol: lf')==3
O.mkdir()
for n,b in projections.items():
    p=O/'canonical-Git-LF-view'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    next(x for x in rows if x['path']==n)['LF_view']=ref(p)
result=dict(schema='src06-Root43-actual-Git-text-filter-view.v1',accepted=True,findings=[],base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),producer=ref(mp),author_Source=ref(Path(__file__)),Git_attributes=ref(R/'.gitattributes'),actual_attributes=attrs,selected_files=rows,raw_compiler_Source_CRLF_files=3,raw_compiler_Source_other_whole_preserved_files=13,Git_filter_actual_readonly_calls=16,canonical_source_index_or_worktree_mutations=0,actual_staged_index_verified=False,qualification='Actual compiled/archive/live Source43 bytes remain authentic and unchanged. Real read-only Git hash-object --path filters prove exactly three selected files project CRLF to canonical LF; the other thirteen remain whole exact. Root must verify the actual staged index against this exact view before commit. This is no scientific rerun or claim that all raw index bytes equal compiled raw bytes.')
p=O/'receipt.json';p.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(ref(p)))

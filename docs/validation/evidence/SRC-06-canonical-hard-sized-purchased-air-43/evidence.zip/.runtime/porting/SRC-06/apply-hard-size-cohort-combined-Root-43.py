"""Root-only one-write union of two independently accepted Source stages."""
from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-hard-sized-purchased-air-cohort-application-43'
assert sys.argv[1:]==['--apply'] and not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',v.get('size_bytes',len(b))),v['path'];return b
def read(v):return json.loads(checked(v))
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
mp=D/'source-hard-sized-purchased-air-cohort-combined-held-Peer-43/manifest.json';mr=ref(mp);assert mr['sha256']=='07042064f18e8ccbf7eb42a3303c68b5d0cf393cc9f5acc0a1bcbc624a4712c2';m=read(mr)
pm=read(m['production43_manifest']);pd=read(pm['original_draft']);pp=read(m['production43_independent_full_semantic_peer']);td=read(m['test59_draft']);tp=read(m['test59_independent_full_semantic_peer'])
assert m['production43_independent_full_semantic_peer']['sha256']=='3fe10f9e890c8737c06935296a360f0a028a141188661c71bc70b98fd786e843' and m['test59_independent_full_semantic_peer']['sha256']=='b11edd054913319872d6656e4d4713f3fc690bd9c91d3d558812d873c3d9554d'
assert pp['accepted'] and tp['accepted'] and not pp['findings'] and not tp['findings'] and pp['reviewed_draft']==pm['original_draft'] and tp['reviewed_draft']==m['test59_draft']
head=git('rev-parse','HEAD').decode().strip();assert head=='728bceba565cd960077f161c93865c6a4730c99a' and not git('status','--porcelain')
assert m['base_HEAD']==pm['base_HEAD']=='73b35d70c1397a7718e4b2bdd13587d31d06b066';subprocess.run(['git','merge-base','--is-ancestor',m['base_HEAD'],head],cwd=R,check=True)
bridge=git('diff','--name-only',m['base_HEAD'],head).decode().splitlines();tool='tools/porting/check_completed_reported_streams.py'
allowed={'energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/cards/SRC-06.md','energyplus_porting_plan/plan.json',tool};assert all(n in allowed or n.startswith('energyplus_porting_plan/evidence/') for n in bridge)
before_tool=git('show',m['base_HEAD']+':'+tool);after_tool=git('show',head+':'+tool);assert hashlib.sha256(before_tool).hexdigest()=='46a1b6f9081d9a0ff5a2d430b17ec647b88a41f5052c3bb1c95df98174ab754c' and hashlib.sha256(after_tool).hexdigest()=='dfd48ccfbbe1d88b4d70bbf4634eb3963679659442e2d8cacf929abb02f7186e' and after_tool==(R/tool).read_bytes()
held=(D/'completed-B-comparison-ready-Audit-01/proposed/tools/porting/check_completed_reported_streams.py').read_bytes();assert hashlib.sha256(held).hexdigest()=='1f0fd5053748210d812201957ec9e1ae56e8712e0082a2c9b7cdac3cba79e7b8'
function=lambda b:next(n for n in ast.parse(b).body if isinstance(n,ast.FunctionDef) and n.name=='available_variables');f,g=function(before_tool),function(held);lines=before_tool.splitlines(keepends=True);assert b''.join(lines[:f.lineno-1]+held.splitlines(keepends=True)[g.lineno-1:g.end_lineno]+lines[f.end_lineno:])==after_tool
parent=read(m['actual_parent_snapshot']);parents={v['historical_path']:v for v in parent['files']};prior=read(m['prior_complete_compiler_Source_plan'])
inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
assert len(inventory)==4511 and set(parents)==inventory=={v['path'] for v in prior['entries']}
for v in prior['entries']:
 n=v['path'];b=checked(parents[n]['archive']);assert b==(R/n).read_bytes() and len(b)==v['final_bytes'] and hashlib.sha256(b).hexdigest()==v['final_sha256']
h=D/'review-meter-final-predefined-Root-01.py';assert ref(h)['sha256']=='e5aa0bb38df690b77f53b2ef63ec4083dca5a500b745881a2dd8d4b831515256';t=ast.parse(h.read_bytes());exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply'],type_ignores=[]),'literal','exec'))
prod={v['canonical_path']:v for v in pm['files']};test={v['canonical_path']:v for v in td['files']};pf={v['canonical_path']:v for v in pp['files']};tf={v['canonical_path']:v for v in tp['files']};assert len(prod)==13 and len(test)==6 and len(set(prod)&set(test))==3
stages=0
for rows,peer in ((prod,pf),(test,tf)):
 for n,v in rows.items():
  a=b'' if v['before_absent'] else checked(v['before']);b=checked(v['proposed']);assert b==checked(peer[n]['proposed']) and apply(a,checked(v['forward_diff']))==b and apply(b,checked(v['inverse_diff']))==a;stages+=2
  expected_before=(checked(prod[n]['proposed']) if rows is test and n in prod else (checked(parents[n]['archive']) if n in parents else b''));assert a==expected_before
assert stages==38
for v in m['shared3_sequential_whole_prefix_proofs']:
 b=checked(v['production43_whole']);assert b==checked(v['test_before_whole']) and checked(v['test_successor_whole'])==b+checked(v['only_test_feature_cfg_suffix'])
selected={};new=set()
for v in m['files']:
 n=v['canonical_path'];assert n not in selected;a=b'' if v['before_absent'] else checked(v['before']);b=checked(v['proposed']);assert apply(a,checked(v['forward_diff']))==b and apply(b,checked(v['inverse_diff']))==a
 assert b==checked((test[n] if n in test else prod[n])['proposed']) and a.count(b'#[test]')==b.count(b'#[test]')
 if v['before_absent']:assert not(R/n).exists();new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==git('show',head+':'+n) and (R/n).stat().st_nlink==1
 assert v['Source_only_parse']['exit_code']==0;checked(v['Source_only_parse']['stderr']);selected[n]=v
assert len(selected)==16 and len(new)==6 and set(selected)==set(prod)|set(test)
for authorities in (m['Native_authorities'],td['Native_authorities']):
 for v in authorities:
  b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
  for e in v['extents']:
   first=e.get('first',e.get('first_line'));last=e.get('last',e.get('last_line'));assert b''.join(b.splitlines(keepends=True)[first-1:last])==checked(e['source'])
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==checked(v['reviewed_draft_context'])
for k in ('constructor_ledger','whole4504_Rust_API_census'):checked(m[k])
native=read(m['actual_Native_fullmethod_unit']);projection=read(m['fixture_projection']);assert native['accepted'] and not native['findings'] and native['exit_code']==0 and native['Native_bytes_match_before_and_after'] and native['actual_three_GNU_DLL_binding_proved_before_any_science_call']
assert projection['accepted'] and not projection['findings'] and projection['actual_Native_unit_run']==m['actual_Native_fullmethod_unit'] and projection['cases']==59 and projection['raw_finite_binary64_fields']==19781 and projection['entire_output_and_input_JSON_lossless_inverse'];checked(projection['compiler_captured_fixture'])
assert projection['full_Native_unit_output']==native['full_unit_output'];np=Path(native['full_unit_output']['path']).resolve();assert np==Path('D:/CodexBuild/rusted-energyplus/SRC-06/hard-size-native-unit-Root-43/unit-output.json').resolve();nb=np.read_bytes();assert len(nb)==native['full_unit_output']['bytes'] and hashlib.sha256(nb).hexdigest()==native['full_unit_output']['sha256']
plan=read(m['complete_final_compiler_Source_plan']);rows={v['path']:v for v in plan['entries']};assert len(rows)==4517 and sum(n.endswith('.rs') for n in rows)==4504 and set(rows)==inventory|new
test_rows={v['path']:v for v in read(td['complete_proposed_compiler_Source_plan'])['entries']};assert rows.keys()==test_rows.keys()
assert {n for n in rows if rows[n]!=test_rows[n]}==set(selected)
for n,v in rows.items():assert {k:x for k,x in v.items() if k!='origin'}=={k:x for k,x in test_rows[n].items() if k!='origin'}
# Exactly sixteen provenance-origin annotations change; all compiler bytes/source references stay exact.
for n,v in rows.items():
 b=checked(v['source']);assert len(b)==v['final_bytes'] and hashlib.sha256(b).hexdigest()==v['final_sha256'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes())
O.mkdir()
for n,v in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(v['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source'])
result=dict(schema='src06-Root-combined-hard-size-production-cohort-application43.v1',accepted=True,findings=[],base_HEAD=head,prepared_source_parent_HEAD=m['base_HEAD'],non_compiler_HEAD_bridge=bridge,bridge_qualification='One exact Regular validation-reader function plus docs/evidence only; all4511 accepted44 compiler archives/plan/live and10selected currentGit before wholes exact. Prepared producers retain authentic historical73b HEAD.',producer=mr,production_producer=m['production43_manifest'],independent_peer=m['production43_independent_full_semantic_peer'],test_independent_peer=m['test59_independent_full_semantic_peer'],test_draft=m['test59_draft'],actual_Native_unit=m['actual_Native_fullmethod_unit'],fixture_projection=m['fixture_projection'],complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4511,final_inputs=4517,final_Rust_sources=4504,selected_Rust=16,new_Rust=6,literal_applications=32,carried_stage_literal_applications=38,combined_plan_metadata_delta='Exactly16 selected origin annotations only; all4517 other entry fields/source references equal full-peer test plan',production_shared_exact_prefixes=3,new_test_bodies=0,new_Cargo_targets_features_dependencies=0,actual_test_bodies_executed=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,Source_numerical_PASS_or_gate_change=False,author_Source=ref(Path(__file__)))
p=O/'receipt.json';p.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(ref(p)))

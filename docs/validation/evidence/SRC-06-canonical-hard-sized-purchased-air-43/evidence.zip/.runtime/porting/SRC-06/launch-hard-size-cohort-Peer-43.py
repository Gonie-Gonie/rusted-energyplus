﻿"""Root-only FIRST one existing safe-main59case invocation; no other test body."""
from pathlib import Path
import argparse,importlib.util,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';P=D/'hard-size-command-guards-Peer-43.py';spec=importlib.util.spec_from_file_location('hard_size_guards',P);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def main(a):
 g.authority(a.application);old=D/'canonical-source-system-report-cohort-Root-40-02/receipt.json';assert g.ref(old)['sha256']=='768b38cc20a6bf9c0ac70d5935d27b79831e1b22f0119e03595ed803386f18f3';cmd=g.read(old)['command'];assert cmd[-1]=='--report-only';cmd[-1]='--sizer-only';assert cmd==g.FOCUSED;assert not g.FOCUS_DIR.exists();assert not any(D.glob('canonical-source-hard-sized-purchased-air-*-command-Root-43'))
 env=g.environment();print('Root43 FIRST: one59case processmain --sizer-only, canonical target, incremental0.',flush=True)
 return subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',g.FOCUS_DIR.relative_to(R).as_posix(),'--',*cmd],cwd=R,env=env)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);raise SystemExit(main(p.parse_args()))

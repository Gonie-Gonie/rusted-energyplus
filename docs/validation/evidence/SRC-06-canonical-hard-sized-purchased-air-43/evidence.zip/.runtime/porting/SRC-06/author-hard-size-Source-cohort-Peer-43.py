﻿"""Unsealed test-only59case Source scaffold on immutable43; real Native output fixture is pending Root."""
from pathlib import Path
import json,re,hashlib,subprocess
R=Path.cwd();D=R/'.runtime/porting/SRC-06';O=D/'source-hard-size-cohort-author-Peer-43';assert not O.exists();O.mkdir();M=json.loads((D/'source-hard-sized-purchased-air-held-Peer-43/manifest.json').read_bytes());rows={x['canonical_path']:x for x in M['files']};L=json.loads((R/M['constructor_ledger']['path']).read_bytes());src=O/'proposed';chosen={}
def get(p):return (R/rows[p]['proposed']['path']).read_text(encoding='utf8') if p in rows else (R/p).read_text(encoding='utf8')
def put(p,s):
 q=src/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s,encoding='utf8',newline='');chosen[p]=q
base='crates/ep_runtime/src/heat_balance/selected_sizing/autosizing';hub=base+'.rs';s=get(hub);assert '\nmod native_cohort;' not in s;s+='\n#[cfg(all(test, feature = "native-controlled-air-cohort"))]\nmod native_cohort;\n';put(hub,s)
p='crates/ep_runtime/src/lib.rs';s=get(p);anchor='    if selection.len()==1 && selection[0]=="--report-only" {';assert s.count(anchor)==1;s=s.replace(anchor,'''    if selection.len()==1 && selection[0]=="--sizer-only" {
        println!("running 1 native hard-size cohort on process main");
        let cases=crate::heat_balance::selected_sizing::SelectedSizingManager::run_native_hard_size_cohort()?;
        println!("cohort native_controlled_air_cohort ... ok");
        println!("cohort result: ok. 1 passed; 0 failed; genuine Native hard-size cases={cases}");
        return Ok(());
    }
'''+anchor).replace('expected no arguments or --report-only','expected no arguments, --report-only or --sizer-only');put(p,s)
# Test-only associated bridges remain inside the private method's own leaf. No production visibility changes.
p='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/initialization.rs';s=get(p);s+='''
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
impl OrdinaryEquipment {
    // These typed0 identities are unused Source bookkeeping only; Native's sizing
    // unit has no Zone/Space allocation, and this helper does not construct one.
    pub(crate) fn source_sizer_cohort_cold_owner() -> Result<Self, Error> {
        Self::new_owners(None, &[ep_model::ZoneId(0)], &[ep_model::SpaceId(0)])
            .map_err(|_| Error::Unavailable("test-only Source cold sizing owner"))
    }
    pub(crate) fn source_sizer_cohort_full_size<D:SourceOutputDictionaryHost>(
        &mut self, o:&mut SourcePurchasedAirInitOwners<'_>, report:&mut SourceSizerReportingOwners<'_,D>
    ) -> Result<(), Error> { self.size_source_purchased_air(1,o,report) }
}
''';put(p,s)
# The init owner borrow type itself stays private. Export only a cfg-only associated
# call from the source_purchased_air hub with real same-owner arguments.
p='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air.rs';s=get(p);s+='''
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
impl OrdinaryEquipment {
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn source_sizer_cohort_size_bridge<D:SourceOutputDictionaryHost>(
        &mut self, sizing:&mut crate::heat_balance::selected_sizing::SelectedSizingManager,
        globals:&crate::heat_balance::selected_heat_balance_globals::SelectedHeatBalanceGlobals,
        hvac:&crate::heat_balance::selected_simulation_startup::SelectedHvacGlobals,
        air_loop:&crate::heat_balance::ordinary_hvac_manager::simulation::state::SourceAirLoopData,
        report:&mut crate::heat_balance::selected_sizing::sizer_output::SourceSizerReportingOwners<'_,D>,
    )->Result<(),crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError>{
        let fan=crate::heat_balance::ordinary_air_heat_balance::environment::SourceZoneFanHeatBalanceArrays::default();
        let clock=crate::weather::day::WeatherGlobalState::default();let format=false;
        let mut o=initialization::SourcePurchasedAirInitOwners{sizing,fan:&fan,globals,clock:&clock,hvac,air_loop,source_is_epjson:&format};
        self.source_sizer_cohort_full_size(&mut o,report)
    }
}
''';put(p,s)
# Mechanical read-only snapshots mirror genuine member/declaration names, not expected numerical outputs.
local=[]
for name,t,*_ in L['local_inherited_fields']:
 expr='s.'+name
 if t.startswith('Option<Vec'):v='zone_array(&'+expr+')' if 'SourceZoneEquipmentSizing' in t else 'shape(&'+expr+')'
 elif t.startswith('Vec'):v='json!({"size":'+expr+'.len(),"container":"std::vector"})'
 elif t=='f64':v='number('+expr+')'
 else:v='json!('+expr+')'
 local.append(f'    out.insert("{name}".into(),{v});')
gl=[]
for name,t,*_ in L['new_DataSizing_fields']:
 expr='s.sizing.autosizing.'+name
 v='shape(&'+expr+')' if t.startswith('Option<Vec') else ('number('+expr+')' if t=='f64' else 'json!('+expr+')');gl.append(f'    out.insert("{name}".into(),{v});')
maptypes={'SysSizingRunDone':'bool','ZoneSizingRunDone':'bool','CurSysNum':'i32','CurZoneEqNum':'i32','CurTermUnitSizingNum':'i32','NumSysSizInput':'usize','NumZoneSizingInput':'usize','UnitarySysEqSizing':'zone','OASysEqSizing':'zone','TermUnitSizing':'shape','ZoneEqSizing':'zone','ZoneCoolingOnlyFan':'bool','ZoneHeatingOnlyFan':'bool','DataCoolCoilCap':'f64'}
for name,field in L['mapped_existing'].items():
 expr='s.sizing.'+field;t=maptypes[name];v='zone_array(&'+expr+')' if t=='zone' else ('shape(&'+expr+')' if t=='shape' else ('number('+expr+')' if t=='f64' else 'json!('+expr+')'));gl.append(f'    out.insert("{name}".into(),{v});')
zone=[];ztext=get('crates/ep_runtime/src/heat_balance/selected_sizing.rs').split('pub(crate) struct SourceZoneEquipmentSizing {',1)[1].split('\n}',1)[0]
for field,t,native in re.findall(r'pub\(crate\)\s+(\w+):\s*(f64|bool|i32),\s*// Native (\w+)',ztext):zone.append(f'    out.insert("{native}".into(),'+('number(r.'+field+')' if t=='f64' else 'json!(r.'+field+')')+');')
assert len(local)==136 and len(gl)==94 and len(zone)==24
unitmap={'Name':'name','cObjectName':'c_object_name','HeatingLimit':'heating_limit','MaxHeatVolFlowRate':'max_heat_vol_flow_rate','MaxHeatSensCap':'max_heat_sens_cap','CoolingLimit':'cooling_limit','MaxCoolVolFlowRate':'max_cool_vol_flow_rate','MaxCoolTotCap':'max_cool_tot_cap','HVACSizingIndex':'hvac_sizing_index','ZonePtr':'zone_ptr'}
unit=[]
for n,f in unitmap.items():v='number(p.'+f+')' if n.startswith('Max') else ('json!(p.'+f+' as i32)' if n.endswith('Limit') else 'json!(p.'+f+')');unit.append(f'out.insert("{n}".into(),{v});')
code='''//! One existing process-main cohort selector; true Native full-method answers only.
#![allow(non_snake_case,dead_code)]
use super::*;
use crate::heat_balance::ordinary_equipment::{OrdinaryEquipment,source_purchased_air::owners::{SourceZonePurchasedAir,SourcePurchasedAirNumericFieldData,SourcePurchasedAirLimit}};
use crate::heat_balance::predefined_tables::PredefinedRegistry;
use crate::heat_balance::source_output_registration::dictionary::SourceOutputDictionaryStreams;
use crate::weather::day::WeatherEnvironmentState;
use serde_json::{Value,json,Map};
type Result<T=()> = std::result::Result<T,Box<dyn std::error::Error>>;
// This compiler-captured fixture is written ONLY from accepted Root Native43
// output after its real run, and includes named INPUT provenance separately.
include!("native_cohort/fixtures/native_hard_size.rs");
fn invalid(s:&str)->std::io::Error{std::io::Error::new(std::io::ErrorKind::InvalidData,s)}
fn number(v:f64)->Value{assert!(v.is_finite());json!({"value_bits":format!("{:016x}",v.to_bits())})}
fn real(v:&Value)->Result<f64>{let s=v.get("value_bits").and_then(Value::as_str).ok_or_else(||invalid("raw16hex"))?;if s.len()!=16||v.as_object().map_or(true,|x|x.len()!=1){return Err(invalid("raw16hex scalar only").into());}let x=f64::from_bits(u64::from_str_radix(s,16)?);if !x.is_finite(){return Err(invalid("finite input").into());}Ok(x)}
fn shape<T>(a:&Option<Vec<T>>)->Value{json!({"allocated":a.is_some(),"size":a.as_ref().map_or(0,Vec::len)})}
fn array1<T>(a:&Option<Vec<T>>)->Value{let mut v=shape(a);v["lower"]=json!(1);v["upper"]=json!(a.as_ref().map_or(0,Vec::len));v}
fn integers(a:&Option<Vec<i32>>)->Value{let mut v=array1(a);v["items"]=json!(a.as_deref().unwrap_or(&[]));v}
fn zone_row(r:&SourceZoneEquipmentSizing)->Value{let mut out=Map::new();
@ZONE@
 out.insert("SizingMethod".into(),integers(&r.sizing__method));out.insert("CapSizingMethod".into(),integers(&r.cap__sizing__method));Value::Object(out)}
fn zone_array(a:&Option<Vec<SourceZoneEquipmentSizing>>)->Value{let mut v=shape(a);v["items"]=Value::Array(a.as_deref().unwrap_or(&[]).iter().map(zone_row).collect());v}
fn local(s:&SourceBaseSizer)->Value{let mut out=Map::new();
@LOCAL@
 Value::Object(out)}
struct State{sizing:SelectedSizingManager,globals:SelectedHeatBalanceGlobals,hvac:SelectedHvacGlobals,air_loop:SourceAirLoopData,environment:WeatherEnvironmentState,registry:PredefinedRegistry,eio:Vec<u8>}
impl State{fn new()->Self{let mut sizing=SelectedSizingManager::default();sizing.current_zone_equipment_number=1;let mut row=SourceZoneEquipmentSizing::default();row.sizing__method=Some(vec![0;35]);sizing.zone_equipment_sizing=Some(vec![row]);let mut environment=WeatherEnvironmentState::default();environment.std_rho_air=1.2;Self{sizing,globals:Default::default(),hvac:Default::default(),air_loop:Default::default(),environment,registry:Default::default(),eio:Vec::new()}}}
fn globals(s:&State)->Value{let mut out=Map::new();
@GLOBALS@
 out.insert("StdRhoAir".into(),number(s.environment.std_rho_air));out.insert("isEpJSON".into(),json!(false));out.insert("DoZoneSizing".into(),json!(s.globals.do_zone_sizing));out.insert("DoSystemSizing".into(),json!(s.globals.do_system_sizing));out.insert("DisplayExtraWarnings".into(),json!(s.globals.display_extra_warnings));out.insert("NumPrimaryAirSys".into(),json!(s.hvac.number_of_primary_air_systems));Value::Object(out)}
fn reports(s:&State)->Result<Value>{let mut rows=array1(&s.registry.component_sizing_entries);rows["items"]=Value::Array(s.registry.component_sizing_entries.as_deref().unwrap_or(&[]).iter().map(|r|json!({"typeField":r.component_type,"nameField":r.component_name,"description":r.description,"valField":number(r.value),"strField":r.string_value,"active":r.active,"written":r.written})).collect());Ok(json!({"oneTimeCompRptHeaderFlag":s.environment.one_time_component_report_header_flag,"eio":std::str::from_utf8(&s.eio)?,"sqlite_present":false,"sizeCompSizeTableEntry":s.registry.component_sizing_capacity,"numCompSizeTableEntry":s.registry.component_sizing_count,"CompSizeTableEntry":rows}))}
fn unit(e:&OrdinaryEquipment)->Result<Value>{let p=e.purchased_air.units.as_ref().and_then(|x|x.first()).ok_or_else(||invalid("unit1"))?;let mut out=Map::new();@UNIT@Value::Object(out).pipe(Ok)}
trait Pipe:Sized{fn pipe<T>(self,f:impl FnOnce(Self)->T)->T{f(self)}}impl<T>Pipe for T{}
fn limit(v:&str)->Result<SourcePurchasedAirLimit>{match v{"LimitFlowRate"=>Ok(SourcePurchasedAirLimit::FlowRate),"LimitCapacity"=>Ok(SourcePurchasedAirLimit::Capacity),"LimitFlowRateAndCapacity"=>Ok(SourcePurchasedAirLimit::FlowRateAndCapacity),_=>Err(invalid("actual limit enum").into())}}
fn setup(input:&Value)->Result<OrdinaryEquipment>{let mut e=OrdinaryEquipment::source_sizer_cohort_cold_owner()?;let mut row=SourceZonePurchasedAir::default();row.name=input["Name"].as_str().ok_or_else(||invalid("name"))?.into();row.c_object_name=input["cObjectName"].as_str().ok_or_else(||invalid("object"))?.into();row.heating_limit=limit(input["HeatingLimit"].as_str().ok_or_else(||invalid("heat limit"))?)?;row.cooling_limit=limit(input["CoolingLimit"].as_str().ok_or_else(||invalid("cool limit"))?)?;row.max_heat_vol_flow_rate=real(&input["MaxHeatVolFlowRate"])?;row.max_heat_sens_cap=real(&input["MaxHeatSensCap"])?;row.max_cool_vol_flow_rate=real(&input["MaxCoolVolFlowRate"])?;row.max_cool_tot_cap=real(&input["MaxCoolTotCap"])?;e.purchased_air.number_purchased_air=1;e.purchased_air.units=Some(vec![row]);let names=input["numeric_field_names"].as_array().ok_or_else(||invalid("actual field names"))?.iter().map(|x|x.as_str().map(str::to_owned).ok_or_else(||invalid("fieldname"))).collect::<std::result::Result<Vec<_>,_>>()?;e.purchased_air.numeric_fields=Some(vec![SourcePurchasedAirNumericFieldData{field_names:Some(names)}]);Ok(e)}
fn call_size(s:&mut State,e:&mut OrdinaryEquipment,name:&str,origin:Value)->Result<Value>{let entry=json!({"globals":globals(s),"reports":reports(s)?,"unit":unit(e)?});let mut rf=Vec::new();let dict=SourceOutputDictionaryStreams{eso:None,sqlite_present:false,results_framework_output_variables:&mut rf};{let mut report=SourceSizerReportingOwners{registry:&mut s.registry,environment:&mut s.environment,dictionary_host:&dict,eio:&mut s.eio};e.source_sizer_cohort_size_bridge(&mut s.sizing,&s.globals,&s.hvac,&s.air_loop,&mut report)?;}Ok(json!({"kind":"full_SizePurchasedAir","name":name,"origin":origin,"entry":entry,"exit":{"globals":globals(s),"reports":reports(s)?,"unit":unit(e)?}}))}
fn kind(n:usize)->SourceAutoSizingType{match n{0=>SourceAutoSizingType::HeatingAirFlow,1=>SourceAutoSizingType::HeatingCapacity,2=>SourceAutoSizingType::CoolingAirFlow,3=>SourceAutoSizingType::CoolingCapacity,_=>panic!("method")}}
fn call_direct(s:&mut State,n:usize,name:&str,description:&str,value:f64,print:bool,origin:Value)->Result<Value>{let kind=kind(n);let method=["HeatingAirFlowSizer","HeatingCapacitySizer","CoolingAirFlowSizer","CoolingCapacitySizer"][n];let mut local_sizer=SourceBaseSizer::new(kind);let constructor=local(&local_sizer);let before=globals(s);let reports_before=reports(s)?;local_sizer.override_sizing_string(description);local_sizer.initialize(&mut s.sizing,&s.globals,&s.hvac,&s.air_loop,&false,&s.environment,"ZoneHVAC:IdealLoadsAirSystem","ZONE ONE IDEAL LOADS",print)?;let initialized=local(&local_sizer);let after_init=globals(s);let mut errors=false;let mut rf=Vec::new();let dict=SourceOutputDictionaryStreams{eso:None,sqlite_present:false,results_framework_output_variables:&mut rf};let returned;{let mut report=SourceSizerReportingOwners{registry:&mut s.registry,environment:&mut s.environment,dictionary_host:&dict,eio:&mut s.eio};returned=local_sizer.size(kind,value,&mut s.sizing,&s.globals,&mut report,&mut errors)?;}Ok(json!({"kind":"full_Sizer","name":name,"method":method,"origin":origin,"input":number(value),"print_flag":print,"constructor":constructor,"globals_before_initialize":before,"reports_before":reports_before,"initialized":initialized,"globals_after_initialize":after_init,"returned":number(returned),"errorsFound":errors,"exit":local(&local_sizer),"globals_after":globals(s),"reports_after":reports(s)?}))}
fn cp(name:&str,value:f64)->Value{json!({"kind":"public_normal_Cp_probe","name":name,"input":number(value),"returned":number(crate::psychrometrics::energyplus_psy_cp_air_fn_w(value)),"qualification":"Explicit named public call sequence, not direct private static cache state/hitcount observation"})}
struct Check{expected:Value,count:usize}
impl Check{fn case(&mut self,actual:Value){let expected=&self.expected["cases"][self.count];assert_eq!(actual["name"],expected["name"],"case order{}",self.count);assert_eq!(&actual,expected,"full Native case{} {}",self.count,actual["name"]);self.count+=1;}}
pub(crate) fn run()->Result<usize>{let inputs:Value=serde_json::from_str(NATIVE_HARD_SIZE_INPUT_JSON)?;let native:Value=serde_json::from_str(NATIVE_HARD_SIZE_EXPECTED_JSON)?;if native["schema"]!="src06-hard-size-full-Native-unit.v1"||native["case_count"]!=59||native["cases"].as_array().map_or(0,Vec::len)!=59{return Err(invalid("complete genuine59case Native fixture required").into());}let mut c=Check{expected:native,count:0};
 c.case(cp("fresh-process-cold-minus100",-100.0));let actual=&inputs["cases"];let names=actual["BOTH"]["numeric_field_names"].as_array().ok_or_else(||invalid("numeric fields"))?;let desc=[format!("{} [m3/s]",names[4].as_str().unwrap()),format!("{} [m3/s]",names[5].as_str().unwrap()),"Maximum Cooling Air Flow Rate [m3/s]".into(),format!("{} [m3/s]",names[7].as_str().unwrap())];
 {let mut s=State::new();c.case(call_direct(&mut s,1,"Cp-sequence-HeatingCapacity-positive",&desc[1],120.0,true,json!({"kind":"named_cache_sequence"}))?);}c.case(cp("post-HeatingCapacity-minus100",-100.0));c.case(cp("post-minus100-zero",0.0));{let mut s=State::new();c.case(call_direct(&mut s,1,"Cp-sequence-HeatingCapacity-zero",&desc[1],0.0,true,json!({"kind":"named_cache_sequence"}))?);}c.case(cp("post-zero-Sizer-zero",0.0));
 for method in 0..4{let positive=if method==0||method==2{0.02}else{120.0};for value in [positive,0.0,-1.0]{let mut s=State::new();c.case(call_direct(&mut s,method,&format!("direct-hard-{method}-{value:.6}"),&desc[method],value,true,json!({"kind":"named_direct_input"}))?);} {let mut s=State::new();c.case(call_direct(&mut s,method,&format!("direct-print-false-{method}"),&desc[method],positive,false,json!({"kind":"named_direct_input"}))?);} {let mut s=State::new();s.sizing.autosizing.DataAutosizable=false;c.case(call_direct(&mut s,method,&format!("direct-not-autosizable-{method}"),&desc[method],positive,true,json!({"kind":"named_direct_input","input_overrides":{"DataAutosizable":false}}))?);} {let mut s=State::new();s.sizing.autosizing.DataEMSOverrideON=true;s.sizing.autosizing.DataEMSOverride=7.25;c.case(call_direct(&mut s,method,&format!("direct-EMS-{method}"),&desc[method],positive,true,json!({"kind":"named_direct_input","input_overrides":{"DataEMSOverrideON":true,"DataEMSOverride":number(7.25)}}))?);}}
 for method in [0,2]{let mut s=State::new();s.sizing.autosizing.DataEMSOverrideON=true;s.sizing.autosizing.DataEMSOverride=7.25;s.sizing.autosizing.DataScalableSizingON=true;let ordinal=if method==0{14}else{1};s.sizing.zone_equipment_sizing.as_mut().unwrap()[0].sizing__method.as_mut().unwrap()[ordinal-1]=4;c.case(call_direct(&mut s,method,&format!("airflow-EMS-plus-scalable-{method}"),&desc[method],0.02,true,json!({"kind":"named_generalized_metadata_input"}))?);}
 for method in [1,3]{let mut s=State::new();s.sizing.autosizing.DataEMSOverrideON=true;s.sizing.autosizing.DataEMSOverride=7.25;s.sizing.autosizing.DataScalableCapSizingON=true;let ordinal=if method==1{18}else{17};s.sizing.zone_equipment_sizing.as_mut().unwrap()[0].sizing__method.as_mut().unwrap()[ordinal-1]=10;c.case(call_direct(&mut s,method,&format!("capacity-EMS-plus-scalable-{method}"),&desc[method],120.0,true,json!({"kind":"named_generalized_metadata_input"}))?);}
 for mode in ["FLOW","CAPACITY","BOTH"]{let mut s=State::new();let mut e=setup(&actual[mode])?;c.case(call_size(&mut s,&mut e,&format!("full-SizePurchasedAir-{mode}"),json!({"kind":"actual_case_sizing_user_inputs","case_id":format!("B-{mode}-24H"),"input":actual[mode]}))?);}
 for value in [0.5,f64::from_bits(0x3fefffffffffffff),1.0]{let mut s=State::new();let mut input=actual["CAPACITY"].clone();input["MaxHeatSensCap"]=number(value);let mut e=setup(&input)?;c.case(call_size(&mut s,&mut e,&format!("full-SizePurchasedAir-SmallLoad-{}",value.to_bits()),json!({"kind":"named_user_input_boundary","base_case":"B-CAPACITY-24H","input_override":{"MaxHeatSensCap":number(value)}}))?);}
 {let mut s=State::new();s.sizing.autosizing.DataConstantUsedForSizing=5.0;s.sizing.autosizing.DataFractionUsedForSizing=2.0;c.case(call_direct(&mut s,0,"constant-fraction-first",&desc[0],0.02,true,json!({"kind":"named_shared_state_sequence","sequence":"constant-fraction-reset","ordinal":1}))?);c.case(call_direct(&mut s,2,"constant-fraction-second-no-reseed",&desc[2],0.02,true,json!({"kind":"named_shared_state_sequence","sequence":"constant-fraction-reset","ordinal":2}))?);}
 {let mut s=State::new();let mut e=setup(&actual["BOTH"])?;for i in 1..=17{c.case(call_size(&mut s,&mut e,&format!("repeated-BOTH-{i}"),json!({"kind":"named_shared_state_sequence","sequence":"real-class-row-growth","ordinal":i,"input":actual["BOTH"]}))?);}}
 assert_eq!(c.count,59);Ok(c.count)}
impl SelectedSizingManager{pub(crate) fn run_native_hard_size_cohort()->Result<usize>{run()}}
'''
code=code.replace('@LOCAL@','\n'.join(local)).replace('@GLOBALS@','\n'.join(gl)).replace('@ZONE@','\n'.join(zone)).replace('@UNIT@',''.join(unit));put(base+'/native_cohort.rs',code)
# No genuine Native unit output exists yet: no expected fixture is invented or sealed.
parses=[]
for p,q in chosen.items():
 r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=q.read_bytes(),capture_output=True);assert r.returncode==0,(p,r.stderr);parses.append(dict(path=p,syntax_exit0=True))
status=dict(schema='src06-hard-size-Source-cohort-unsealed-scaffold43.v1',status='UNSEALED: actual Native59output/custody fixture and full independent Source peer pending. Cannot execute or claim Source scientific PASS.',production43_manifest=M['original_draft'],Source_wholes=len(chosen),new_Rust_leaf=base+'/native_cohort.rs',new_test_functions=0,new_targets_features_dependencies=0,old_Air_report_body_fixture_consumed_helpers_unchanged=True,selectors='Existing harness=false target --sizer-only early branch before every Air/report call; cold normal Cp must be first science operation on fresh processmain.',fixture='Intentionally not authored until accepted actual Root Native43 run. include path is compiler-captured Rust Source, never private runtime JSON read.',syntax_only=parses,author_Source=str(Path(__file__).relative_to(R)).replace('\\','/'))
(O/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(files=len(chosen),parses=len(parses),new_test_functions=0,expected_fixture_pending=True)))

"""Freeze the cfg-only59case Source replay after a genuine accepted Root Native43 result."""
from pathlib import Path
import argparse,copy,difflib,hashlib,json,re,subprocess,ast
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-hard-size-cohort-draft-Peer-43-02';A=D/'source-hard-size-cohort-author-Peer-43'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(r):
 p=(R/r['path']).resolve();a=ref(p);assert a['sha256']==r['sha256'] and a['bytes']==r.get('bytes',a['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,o):return put(p,(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode())
def main(a):
 assert not O.exists();heldp=D/'source-hard-sized-purchased-air-held-Peer-43/manifest.json';held=read(heldp);assert ref(heldp)['sha256']=='fcc0f89806809bb91e3c231a0f631f35a0154dcfc0622ef09c3adb10c09b239d';plan=read(checked(held['complete_final_compiler_Source_plan']));rows={r['path']:copy.deepcopy(r)for r in plan['entries']};assert len(rows)==4515 and sum(p.endswith('.rs')for p in rows)==4502
 # This is explicitly a logical43 draft. Actual source43/canonical custody joins later.
 for row in rows.values():b=checked(row['source']).read_bytes();assert len(b)==row['final_bytes'] and hashlib.sha256(b).hexdigest()==row['final_sha256']
 O.mkdir();fixture='crates/ep_runtime/src/heat_balance/selected_sizing/autosizing/native_cohort/fixtures/native_hard_size.rs';projector=D/'project-hard-size-Native-unit-fixture-Peer-43.py';out=O/'proposed'/fixture;subprocess.run(['C:/Users/GonieGonie/AppData/Local/Programs/Python/Python312/python.exe',str(projector),'--actual',a.native_run,'--output',str(out.relative_to(R))],cwd=R,check=True,capture_output=True);projection=read(out.parent/'projection.json');assert projection['accepted'] and not projection['findings'] and projection['cases']==59
 srcs={p.relative_to(A/'proposed').as_posix():p.read_bytes() for p in (A/'proposed').rglob('*.rs')};assert len(srcs)==5;srcs[fixture]=out.read_bytes();assert len(srcs)==6
 t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal-only>','exec'),ns);files=[]
 for i,(p,b)in enumerate(sorted(srcs.items()),1):
  new=p not in rows;before=b'' if new else checked(rows[p]['source']).read_bytes();f=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='logical43/'+p,tofile='cohort43/'+p)).encode();inv=''.join(difflib.unified_diff(b.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='cohort43/'+p,tofile='logical43/'+p)).encode();assert ns['apply_literal'](before,f)==b and ns['apply_literal'](b,inv)==before
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert q.returncode==0,(p,q.stderr);pr=put(O/'proposed'/p,b);files.append(dict(canonical_path=p,before_absent=new,before=None if new else put(O/'before'/p,before),proposed=pr,forward_diff=put(O/'diffs'/f'{i:02}.forward.diff',f),inverse_diff=put(O/'diffs'/f'{i:02}.inverse.diff',inv),Source_only_parse=dict(exit_code=0,stdout=put(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=put(O/'parse'/f'{i:02}.stderr',q.stderr))))
  rows[p]=dict(path=p,final_sha256=pr['sha256'],final_bytes=pr['bytes'],source=pr,origin='test-only Native43 full-method59cohort proposal')
 assert len(rows)==4517 and sum(p.endswith('.rs')for p in rows)==4504 and sum(x['before_absent']for x in files)==2
 # Established main-target and old Air/report data are preserved; no suite multiplication.
 lib='crates/ep_runtime/src/lib.rs';old=checked(next(f['before']for f in files if f['canonical_path']==lib)).read_text();new=srcs[lib].decode();start=new.index('    if selection.len()==1 && selection[0]=="--sizer-only" {');end=new.index('    if selection.len()==1 && selection[0]=="--report-only" {');restored=new[:start]+new[end:];restored=restored.replace('expected no arguments, --report-only or --sizer-only','expected no arguments or --report-only');assert restored==old
 assert all(b'#[test]'not in b for p,b in srcs.items()if p!=fixture);assert 'crates/ep_runtime/Cargo.toml'not in srcs
 old_tests=[p for p in rows if p.endswith('.rs')and ('native_cohort'in p or 'native_controlled'in p)and p not in srcs];assert old_tests
 preserved=[]
 for p in old_tests:preserved.append(dict(path=p,whole=rows[p]['source'],unchanged=True))
 # All helpers are additive cfg(test)+existingfeature. Production methods and privacy unchanged.
 for p in ['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/initialization.rs']:
  f=next(f for f in files if f['canonical_path']==p);before=checked(f['before']).read_bytes();assert srcs[p].startswith(before);tail=srcs[p][len(before):];assert tail.startswith(b'\n#[cfg(all(test, feature = "native-controlled-air-cohort"))]')
 p='crates/ep_runtime/src/heat_balance/selected_sizing/autosizing.rs';f=next(f for f in files if f['canonical_path']==p);assert srcs[p]==checked(f['before']).read_bytes()+b'\n#[cfg(all(test, feature = "native-controlled-air-cohort"))]\nmod native_cohort;\n'
 fp=write(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-hard-size-cohort43-logical-final-plan.v1',status='logical Source43 exact held parent, actual Source43 commit/custody join pending',parent=ref(heldp),prior_complete_compiler_Source_plan=held['complete_final_compiler_Source_plan'],compiler_inputs=4517,inputs=4517,Rust_sources=4504,selected_existing=4,selected_new=2,entries=[rows[p]for p in sorted(rows)]))
 pattern=re.compile(r'run_native_hard_size_cohort|source_sizer_cohort_|SourcePurchasedAirInitOwners|SourcePurchasedAirCalcOwners|native-controlled-air-cohort|NATIVE_HARD_SIZE|SourceBaseSizer');hits=[]
 for p,row in sorted(rows.items()):
  if not p.endswith('.rs')or '/fixtures/'in p:continue
  for i,line in enumerate(checked(row['source']).read_text(encoding='utf8').splitlines(),1):
   if pattern.search(line):hits.append(dict(path=p,line=i,literal=line))
 api=write(O/'full4504-Rust-API-census.json',dict(inputs=4517,Rust_sources=4504,fixture_payload_excluded_only_for_API_text_search=True,pattern=pattern.pattern,hits=hits))
 draft=dict(schema='src06-hard-size-native-cohort-private-draft43.v1',status='FROZEN test-only semantic draft on exact held Source43; actual Source43/parent/custody finaljoin pending, no Source scientific PASS',logical_parent=ref(heldp),prior_complete_compiler_Source_plan=held['complete_final_compiler_Source_plan'],complete_proposed_compiler_Source_plan=fp,files=files,existing_Source_files=4,new_Source_files=2,inputs=4517,Rust_sources=4504,literal_applications=12,Source_only_parses=6,new_test_functions=0,new_Cargo_targets_features_dependencies=0,actual_test_bodies_executed=0,fixture_projection=ref(out.parent/'projection.json'),actual_Native_fullmethod_unit=projection['actual_Native_unit_run'],Native_unit_draft=projection['Native_draft'],Native_unit_independent_peer=projection['Native_independent_peer'],Native_output=projection['full_Native_unit_output'],named_input_source=projection['separate_named_input_Source'],old_Air_report_fixtures_and_helpers_whole_preserved=preserved,old_lib_fullbody_inverse_after_selector_and_error_text_only=True,all_three_production_prefixes_exact_before_cfg_test_helpers=True,complete_API_census=api,constructor_ledger=held['constructor_ledger'],Native_authorities=held['Native_authorities'],case_counts=dict(total=59,public_Cp=4,full_Sizers=32,full_SizePurchasedAir=23,repeated_BOTH=17),snapshot_closure='136 actual Source Sizer local fields,94 shared sizing plus6 context fields,26 real ZoneEqSizing members/array shapes,full EIO memory bytes/header and all7 members of entire allocated CompSize capacity. No expected state restored.',input_restore='Only explicit named inputs and existing actual Native-equivalent constructors/allocations, no computed output/property/sizing/cache answers. Same processmain normal Cp cache is never seeded/reset/read; public call sequence first before every old Air/report consumer.',unused_Source_bookkeeping='Existing cold OrdinaryEquipment constructor stores typed ZoneId(0)/SpaceId(0) bookkeeping required by its existing interface, never consumed by full SizePurchasedAir and never projected as a Native Zone/Node owner.',author_Source=ref(Path(__file__)),scaffold_author_Source=ref(D/'author-hard-size-Source-cohort-Peer-43.py'),no_Cargo_Native_engine_or_canonical_mutation=True)
 print(json.dumps(write(O/'draft.json',draft)))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--native-run',required=True);main(ap.parse_args())

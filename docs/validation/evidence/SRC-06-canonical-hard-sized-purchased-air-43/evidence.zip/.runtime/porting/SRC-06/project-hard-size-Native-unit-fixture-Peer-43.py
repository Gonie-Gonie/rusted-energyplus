﻿"""Prepare Native43 direct whole-output fixture only after authenticated Root actual run0."""
from pathlib import Path
import argparse,hashlib,json,math,struct
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(r):
 p=(R/r['path']).resolve();a=ref(p);assert a['sha256']==r['sha256'] and a['bytes']==r.get('bytes',a['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def scalars(v):
 if isinstance(v,dict):
  if 'value_bits'in v:assert set(v)=={'value_bits'} and len(v['value_bits'])==16 and math.isfinite(struct.unpack('>d',bytes.fromhex(v['value_bits']))[0]);return 1
  return sum(scalars(x)for x in v.values())
 if isinstance(v,list):return sum(scalars(x)for x in v)
 assert not isinstance(v,float);return 0
def main(a):
 p,h=a.actual.rsplit('#',1);p=(R/p).resolve();assert ref(p)['sha256']==h;receipt=read(p);assert receipt['accepted'] and not receipt['findings'] and receipt['exit_code']==0 and receipt['Native_bytes_match_before_and_after'] and receipt['actual_three_GNU_DLL_binding_proved_before_any_science_call']
 build=read(checked(receipt['actual_build']));assert build['accepted'] and not build['findings'] and all(build['original_core_member_counts'].values()) and not build['forbidden_derived_object_witnesses'];draft=read(checked(receipt['reviewed_draft']));assert receipt['reviewed_draft']==build['reviewed_draft'];assert receipt['reviewed_draft']['sha256']=='ca289401224257c313d7a39b34eefa33934fe5db1bda43691bc2fdc62f7165df';peer=read(checked(build['independent_Source_peer']));assert peer['accepted'] and not peer['findings'];output=checked(receipt['full_unit_output']);v=read(output);inputs=checked(draft['input_Source']);inp=read(inputs)
 assert v['schema']=='src06-hard-size-full-Native-unit.v1' and v['case_count']==len(v['cases'])==59 and not v['Native_engine_called'] and not v['expected_values_reconstructed'];assert receipt['admission']['cases']==59 and receipt['admission']['kind_counts']=={'public_normal_Cp_probe':4,'full_Sizer':32,'full_SizePurchasedAir':23};bits=scalars(v)
 out=R/a.output;assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);vtext=json.dumps(v,separators=(',',':'),ensure_ascii=False);itext=json.dumps(inp,separators=(',',':'),ensure_ascii=False);assert '"####' not in vtext+itext
 body='// Actual Root Native43 full-method output; every expected bit copied directly.\n// Named INPUT fields kept separate; no reconstructed output or cache reset.\n'+'pub(super) const NATIVE_HARD_SIZE_EXPECTED_JSON:&str=r####"'+vtext+'"####;\n'+'pub(super) const NATIVE_HARD_SIZE_INPUT_JSON:&str=r####"'+itext+'"####;\n';out.write_text(body,encoding='utf8',newline='')
 # Lossless projection inverse independent of eventual Source execution.
 s=out.read_text();assert json.loads(s.split('r####"',1)[1].split('"####;',1)[0])==v;assert json.loads(s.split('NATIVE_HARD_SIZE_INPUT_JSON:&str=r####"',1)[1].split('"####;',1)[0])==inp
 result=dict(schema='src06-hard-size-Native43-unit-fixture-projection.v1',accepted=True,findings=[],actual_Native_unit_run=ref(p),actual_original_core_build=receipt['actual_build'],Native_draft=receipt['reviewed_draft'],Native_independent_peer=build['independent_Source_peer'],full_Native_unit_output=ref(output),separate_named_input_Source=ref(inputs),compiler_captured_fixture=ref(out),cases=59,public_Cp_probes=4,full_Sizers=32,full_SizePurchasedAir=23,raw_finite_binary64_fields=bits,entire_output_and_input_JSON_lossless_inverse=True,all_expected_fields_direct_Native_output_only=True,no_scientific_expected_formula_or_property_reconstruction=True,no_Source_PASS_or_gate_change=True,author_Source=ref(Path(__file__)))
 rp=out.parent/'projection.json';rp.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(ref(rp)))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--actual',required=True);ap.add_argument('--output',required=True);main(ap.parse_args())

"""Root-only Source43 finite publication; no command/build/test/Native execution."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-hard-sized-purchased-air-43';BACK=D/'hard-sized-purchased-air-publication-readback-Peer-43'
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(r):
 p=(R/r['path']).resolve();assert p.is_relative_to(R);v=ref(p);assert v['sha256']==r['sha256']and v['bytes']==r.get('bytes',v['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def accepted(r):
 v=read(checked(r));assert v['accepted']and not v.get('findings',[]);return v
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def main(a):
 assert a.publish and not PUBLIC.exists()and not BACK.exists();tp=(R/a.template).resolve();t=read(tp);assert t['status']=='HELD_READY_FOR_ROOT_ACTUAL43_AND_FULL_READ';assert ref(Path(__file__))==t['publisher_Source'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==t['base_HEAD'];actual=accepted(t['accepted_actual_review']);app=accepted(actual['application']);assert app['base_HEAD']==head and actual['application']==t['application'];m=read(checked(t['producer']));plan=read(checked(t['complete_plan']));assert actual['producer']==t['producer']and actual['complete_compiler_plan']==t['complete_plan'];assert(plan['inputs'],plan['Rust_sources'])==(4517,4504)and len(m['files'])==16 and sum(x['before_absent']for x in m['files'])==6
 assert actual['same4517_archived_inputs_exact_final_plan_and_live']and actual['selected16_final_sources_exact'];assert actual['actual_test_bodies_executed']==1 and actual['new_test_bodies']==0 and actual['Source59_bit_exact_cases']==59 and actual['Source59_finite_fields']==19781;assert actual['actual_production_CLI_invocations']==5 and len(actual['Source_completed_cases'])==5 and not actual['typed_after_sizing_frontiers'];assert actual['NoLimit_original_policy_and_JSON_CSV_9792_proof_transferred']and actual['A24_original_policy_and_JSON_CSV_5352_proof_transferred'];assert actual['policy_changes']==actual['gate_changes']==0
 focus=accepted(actual['actual_focused_test_review']);assert focus['Source_cases_bit_exact']==59 and focus['actual_executed_test_bodies']==1;unit=accepted(actual['actual_Native_fullmethod_unit']);assert unit['exit_code']==0 and unit['actual_three_GNU_DLL_binding_proved_before_any_science_call'];accepted(t['production_peer']);accepted(t['test_peer']);assert actual['independent_production_peer']==t['production_peer']and actual['independent_test_peer']==t['test_peer'];assert actual['actual_focused_test_review']==t['actual_focused_test_review']
 transport=t['source_Git_transport'];view=accepted(transport['Git_filter_view']);index=accepted(transport['actual_staged_index_view']);assert view['producer']==t['producer']and index['preflight_view']==transport['Git_filter_view'];assert view['base_HEAD']==index['base_HEAD']==head and index['actual_index_verified']and index['actual_raw_compiler_sources_unchanged'];assert(index['canonical_Git_index_LF_transport_files'],index['raw_index_live_whole_equal_files'])==(3,13);assert{f['canonical_path']for f in m['files']}=={f['path']for f in view['selected_files']}=={f['path']for f in index['selected16_index_views']}
 rows={x['path']:x for x in plan['entries']};archives={x['historical_path']:x for x in read(checked(actual['actual_snapshot']))['files']};assert len(rows)==len(archives)==4517 and rows.keys()==archives.keys()
 for p,v in rows.items():assert(v['final_sha256'],v['final_bytes'])==(archives[p]['archive']['sha256'],archives[p]['size_bytes']);b=(R/p).read_bytes();assert hashlib.sha256(b).hexdigest()==v['final_sha256']and len(b)==v['final_bytes']
 for f in m['files']:assert(R/f['canonical_path']).read_bytes()==checked(f['proposed']).read_bytes()
 cases=['B-NOLIMIT-24H','B-FLOW-24H','B-CAPACITY-24H','B-BOTH-24H','A-24H'];assert[x['case']for x in actual['ordered_cases']]==cases;assert[x['rows']for x in actual['physical_sizing_rows_equal_genuine_fullNative_Size']]==[2,4,6]
 supplemental=[]
 for row in t.get('supplemental_24h_limit_comparisons',[]):
  comp=accepted(row);assert comp['case']in cases[1:4] and comp['totals']['series']==102 and comp['totals']['samples']==9792 and comp['totals']['tolerance_failures']==comp['totals']['rmse_failures']==0 and comp['totals']['passed'];assert comp['Source_receipt']==next(x['receipt']for x in actual['ordered_cases']if x['case']==comp['case']);supplemental.append(dict(comparison=row,case=comp['case'],Native_authority=comp['Native_authority'],Native_authority_kind=comp['Native_authority_kind'],totals=comp['totals']))
 assert len(supplemental)==3
 for case in actual['ordered_cases']:
  run=read(checked(case['receipt']));assert run['exit_code']==0 and run['launch_error']is None and run['source_bytes_match_before_and_after'];assert run['source_snapshot']==actual['actual_snapshot'];assert case['Source620_completed']and case['true_post_sizing_frontier']is None
 base=R/'energyplus_porting_plan';docs={n:(base/n).read_bytes()for n in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']};pp=base/'plan.json';oldplan=pp.read_bytes();oldvalue=json.loads(oldplan)
 for n,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R)and '\ufffd'not in b.decode('utf8','strict')
 assert oldplan==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R);previous=read(checked(t['previous_checkpoint']));assert(previous['A'],previous['B'])==('14/54','14/64')
 files={}
 def add(p):
  p=p.resolve();assert p.is_relative_to(R);v=ref(p);assert p.suffix.lower()not in ['.zip','.exe','.obj','.dll','.a']and v['bytes']<64*1024*1024;assert v['path']not in files or files[v['path']]['ref']==v;files[v['path']]=dict(path=p,ref=v)
 for r in t['finite_archive_inputs']:add(checked(r))
 for r in actual['publication_artifacts']:add(checked(r))
 for p in [Path(__file__),tp,checked(t['accepted_actual_review']),checked(actual['application']),checked(app['author_Source']),checked(actual['author_Source']),checked(actual['actual_focused_test_review']),checked(focus['actual_focused_test']),checked(focus['actual_test_stdout']),checked(focus['actual_test_stderr'])]:add(p)
 # Actual24h outputs only; presence in this archive does not certify ancillary
 # equivalence. The three separate24h limit comparisons are qualified below.
 for case in cases:
  out=D/f'canonical-source-hard-sized-purchased-air-{case}-Root-43/output'
  for p in out.rglob('*'):
   if p.is_file():assert p.resolve().is_relative_to(out.resolve());add(p)
 for f in m['files']:add(R/f['canonical_path'])
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan)
 for n,b in docs.items():p=BACK/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 archive=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,item in sorted(files.items()):assert ref(item['path'])==item['ref'];z.write(item['path'],arcname=name)
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and set(z.namelist())==set(files)
  for name,item in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['ref']['sha256']
 manifest=PUBLIC/'manifest.json';write(manifest,dict(schema='src06-canonical-hard-size43-finite-evidence.v1',archive=ref(archive),entries=[v['ref']for _,v in sorted(files.items())],source_Git_transport=transport,scope='Current16 Source whole proposals and all6 actual Source invocations only: one same-existing59case selector then5 real24h CLIs, Native59 direct original-core unit Source/output/recipes/authority and explicit EIO2/4/6 evidence. Previous proofs are referenced/compact metadata only; no historical ZIP, annual JSON, old Air fixture, core/exe/providers or full shell environment is archived. Ancillary outputs remain raw unclassified evidence. Three separately authenticated FLOW/CAPACITY/BOTH24h reported-stream comparisons are numerical PASS under unchanged original tolerances/RMSE; CAPACITY25 raw/binary64 differences remain explicit. The earlier7d99 aggregate retains its original capture-time pending scope. Limit72h/annual/internal-state and ancillary full-IO certification remain open here. Actual compiled/archive/live raw Source bytes are retained; exactly three Git blobs are the separately authenticated CRLF-to-LF byte projection, and thirteen are whole exact.'))
 summary=dict(t['summary_template']);summary.update(schema='src06-canonical-hard-sized-purchased-air43.v1',status='Genuine Base/FanHeat/Scalable four Sizers and real component sizing reports; actual59case pass and five Source62024h completions',producer=t['producer'],production_peer=t['production_peer'],test_peer=t['test_peer'],complete_compiler_plan=t['complete_plan'],application=t['application'],Root_actual_review=t['accepted_actual_review'],Source_focused_test=actual['actual_focused_test'],actual_focused_review=actual['actual_focused_test_review'],actual_Native59_unit=actual['actual_Native_fullmethod_unit'],actual_59cases_bit_exact=59,actual_finite_binary64_fields=19781,actual_test_bodies_executed=1,actual_production_CLI_invocations=5,actual_Source_completed_cases=actual['Source_completed_cases'],ordered_cases=actual['ordered_cases'],physical_sizing_EIO_rows_paired=actual['physical_sizing_rows_equal_genuine_fullNative_Size'],regression_proof_transfers=dict(A24_series=58,A24_samples=5352,NoLimit_series=102,NoLimit_samples=9792,accepted44=actual['accepted44_A24_5352_proof'],accepted45_NoLimit=actual['accepted45_B24_9792_reported_proof'],scope='Separate actual unchanged full physical/CSV/JSON/runtime proofs; no A/B production evidence is inferred from the sizing unit.'),supplemental_24h_limit_reported_comparisons=supplemental,FLOW_CAPACITY_BOTH_reported_Native_numerics='Separate later read-only actual24h comparisons all pass unchanged original tolerances/RMSE; CAPACITY25 raw/binary64 differences retained. Historical aggregate7d99 remains unchanged. Limit72h/annual/internal-state and ancillary IO not certified here',ancillary_full_IO_PASS=False,source_Git_transport=transport,limits=actual['limits'],archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json';write(sp,summary);relative='evidence/SRC-06-canonical-hard-sized-purchased-air-43/summary.json'
 for n,b in docs.items():
  link='../'+relative if n.startswith('cards/')else relative;append='\n\n[Source43 hard-sized PurchasedAir]('+link+'). '+t['doc_appends'][n]+'\n';assert '\ufffd'not in append and '{{'not in append and(base/n).read_bytes()==b;(base/n).write_bytes(b+append.encode('utf8'))
 after=json.loads(oldplan);task=next(x for x in after['tasks']if x['id']=='SRC-06');key='canonical_hard_sized_purchased_air_43';assert key not in task;task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=ref(sp)['sha256'],size_bytes=sp.stat().st_size);inverse=json.loads(json.dumps(after));del next(x for x in inverse['tasks']if x['id']=='SRC-06')[key];assert inverse==oldvalue and pp.read_bytes()==oldplan;write(pp,after)
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),actual_Source_test_bodies=1,actual_Source_CLI_invocations=5,actual_Native_unit_invocations=1,no_new_tests_targets_features=True,gate_changes=False,policy_changes=False,Cargo_Native_or_tests_executed=False,Git_mutated=False);p=BACK/'publication-readback.json';write(p,result);print(json.dumps(ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--template',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

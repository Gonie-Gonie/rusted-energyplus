"""Root-only full Native43 unit: prove child DLLs before releasing any science call."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import argparse,ast,ctypes,hashlib,json,math,os,re,struct,subprocess,time
from ctypes import wintypes
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';M=D/'hard-size-native-unit-run-Root-43'
def need(ok,why):
 if not ok:raise ValueError(why)
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(r):
 p=(R/r['path']).resolve();a=ref(p);need(a['sha256']==r['sha256'] and a['bytes']==r.get('bytes',a['bytes']),'Changed '+r['path']);return p
def read(p):return json.loads(p.read_bytes())
def write(n,o):
 p=M/n
 with p.open('xb') as f:f.write((json.dumps(o,indent=2)+'\n').encode())
 return ref(p)
def number(v):
 need(set(v)=={'value_bits'} and re.fullmatch('[0-9a-f]{16}',v['value_bits']) is not None,'Raw16hex scalar');x=struct.unpack('>d',bytes.fromhex(v['value_bits']))[0];need(math.isfinite(x),'Finite real');return x
def scalar_count(v):
 if isinstance(v,dict):
  if 'value_bits' in v:number(v);return 1
  return sum(scalar_count(x) for x in v.values())
 if isinstance(v,list):return sum(scalar_count(x) for x in v)
 need(not isinstance(v,float),'No floating JSON transport');return 0
def main(args):
 need(args.run_only and not M.exists(),'Root-only fresh metadata');path,sha=args.build.rsplit('#',1);bp=(R/path).resolve();need(ref(bp)['sha256']==sha,'Actual build SHA');b=read(bp);need(b['accepted'] and not b['findings'] and b['Native_bytes_match_before_and_after'],'Native build0 and stable');need(all(b['original_core_member_counts'].values()) and not b['forbidden_derived_object_witnesses'],'Original core members witnessed')
 dp=checked(b['reviewed_draft']);p=read(dp);need(checked(p['run_launcher_Source'])==Path(__file__).resolve(),'Exact reviewed run Source');binary=checked(b['binary']);inputs=checked(p['input_Source']);frozen=read(checked(p['frozen_environment']));need(frozen['accepted'],'Frozen accepted environment');environment=frozen['environment'];env={k.casefold():v for k,v in environment.items()};need(len(env)==len(environment),'No environment collision');systemroot=Path(env['systemroot'])
 cp=checked(p['inherited_module_query_Source']);tree=ast.parse(cp.read_bytes());classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ChildModules'];need(len(classes)==1,'Whole inherited PSAPI class');ns=dict(need=need,os=os,ctypes=ctypes,wintypes=wintypes,Path=Path);exec(compile(ast.Module(body=classes,type_ignores=[]),'<whole-unchanged-PSAPI-child-query>','exec'),ns)
 output=Path(p['fresh_unit_directory'])/'unit-output.json';need(not output.exists(),'Fresh unit output');protected=[ref(bp),b['reviewed_draft'],b['independent_Source_peer'],b['binary'],*p['protected_files'],ref(systemroot/'System32/kernel32.dll'),ref(systemroot/'System32/psapi.dll')];protected=list({r['path']:r for r in protected}.values());before=[ref(checked(r)) for r in protected];expected={Path(r['path']).name.casefold():checked(r) for r in p['pinned_runtime_DLLs']};need(len(expected)==3,'Three GNU DLLs');M.mkdir();br=write('Native-before.json',before)
 command=[str(binary),str(inputs),str(output),'--await-parent-modules'];process=None;code=None;error=None;query=None;modules=None;bindings=[];attempts=0;errors=[];released=False;ready=False;start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();stdout=M/'stdout.log';stderr=M/'stderr.log'
 with stdout.open('xb') as out,stderr.open('xb') as err:
  try:
   process=subprocess.Popen(command,cwd=R,env=environment,stdout=out,stderr=err,stdin=subprocess.PIPE)
   deadline=time.monotonic()+30
   while process.poll() is None and time.monotonic()<deadline:
    ready=stdout.read_bytes() in (b'NATIVE_SIZING_UNIT_READY_FOR_PARENT_MODULE_PROOF\n',b'NATIVE_SIZING_UNIT_READY_FOR_PARENT_MODULE_PROOF\r\n')
    if ready:
     attempts+=1
     try:
      if query is None:query=ns['ChildModules'](process.pid,systemroot)
      rows=query.snapshot()
      if set(expected).issubset({Path(r['actual_path']).name.casefold() for r in rows}):modules=rows;break
     except (OSError,ValueError) as e:
      if len(errors)<16:errors.append(dict(type=type(e).__name__,message=str(e)))
    time.sleep(0.01)
   need(ready and modules is not None and process.poll() is None,'Actual ready child + all3 GNU DLLs before any science call')
   for name,path in expected.items():
    rows=[r for r in modules if Path(r['actual_path']).name.casefold()==name];need(len(rows)==1 and Path(rows[0]['actual_path']).resolve()==path,'Exact PID GNU DLL path');bindings.append(dict(module=rows[0],actual_file=ref(path)))
   need(len(bindings)==3,'All3 exact bindings before release');process.stdin.write(b'g');process.stdin.flush();process.stdin.close();released=True;code=process.wait(timeout=300)
  except (OSError,ValueError,subprocess.TimeoutExpired) as e:
   error=dict(type=type(e).__name__,message=str(e))
   if process is not None and process.poll() is None:process.kill()
   if process is not None:code=process.wait()
  finally:
   if query is not None:query.close()
 after=[ref(checked(r)) for r in protected];need(before==after,'Protected runtime files changed');ar=write('Native-after.json',after);mr=write('actual-child-modules.json',dict(child_PID=process.pid if process else None,ready_marker_before_release=ready,module_proof_before_release=len(bindings)==3,one_byte_release_sent=released,attempts=attempts,first16_query_errors=errors,all_observed_modules=modules,three_GNU_bindings=bindings));findings=[];report=None
 if code!=0 or error:findings.append('Native unit did not complete0 after pre-science module proof')
 if not findings:
  o=read(output);need(o['schema']=='src06-hard-size-full-Native-unit.v1' and not o['Native_engine_called'] and not o['expected_values_reconstructed'],'Actual original full-function unit schema');cases=o['cases'];need(o['case_count']==len(cases)==59,'All59 named cases');counts=Counter(x['kind'] for x in cases);need(counts=={'public_normal_Cp_probe':4,'full_Sizer':32,'full_SizePurchasedAir':23},'All4 probes/32 Sizers/23 full SizePurchasedAir calls');need(len({x['name'] for x in cases})==59,'Unique named cases');bits=scalar_count(o)
  need([x['name'] for x in cases[:6]]==['fresh-process-cold-minus100','Cp-sequence-HeatingCapacity-positive','post-HeatingCapacity-minus100','post-minus100-zero','Cp-sequence-HeatingCapacity-zero','post-zero-Sizer-zero'],'Cold public Cp sequence before other consumers')
  methods=Counter();row_extents=[];baseline=[]
  for c in cases:
   if c['kind']=='full_Sizer':
    need(not c['errorsFound'],'Sizer actual errorsFoundfalse');need(len(c['constructor'])==len(c['initialized'])==len(c['exit'])==136,'Full136 local fields');methods[c['method']]+=1
   if c['kind']=='full_SizePurchasedAir':
    r=c['exit']['reports'];a=r['CompSizeTableEntry'];need(a['size']==len(a['items'])==r['sizeCompSizeTableEntry'] and r['numCompSizeTableEntry']<=a['size'],'Actual whole CompSize allocation/count');row_extents.append(dict(name=c['name'],capacity=a['size'],count=r['numCompSizeTableEntry']))
    for v in a['items'][r['numCompSizeTableEntry']:]:need(v==dict(typeField='',nameField='',description='',valField={'value_bits':'0000000000000000'},strField='',active=False,written=False),'Genuine unused class-row constructor defaults')
  need(set(methods)=={'HeatingAirFlowSizer','HeatingCapacitySizer','CoolingAirFlowSizer','CoolingCapacitySizer'},'Four real Sizer methods')
  need(any(x['capacity']==100 for x in row_extents) and row_extents[-1]['capacity']==200 and row_extents[-1]['count']==102,'Actual repeated row growth100 to200/count102')
  for old in p['retained_genuine_full_engine_EIO_baselines']:
   mode=old['case_id'].split('-')[1];case=next(c for c in cases if c['name']=='full-SizePurchasedAir-'+mode);memory=case['exit']['reports']['eio'].encode();need(b'\r' not in memory,'Memory stream explicitlyLF');raw=checked(old['actual_raw_eio']).read_bytes();prefix=b' Component Sizing Information, ZoneHVAC:IdealLoadsAirSystem, ZONE ONE IDEAL LOADS,';mr0=[v for v in memory.splitlines(keepends=True) if v.startswith(prefix)];rr=[v for v in raw.splitlines(keepends=True) if v.startswith(prefix)];need(all(v.endswith(b'\n') and not v.endswith(b'\r\n') for v in mr0) and all(v.endswith(b'\r\n') for v in rr),'Owned selected row terminators LF/CRLF');need([v[:-1]+b'\r\n' for v in mr0]==rr,'Exact selected Native EIO bytes with sole explicit stream terminator bridge');need(len(rr)=={'FLOW':2,'CAPACITY':4,'BOTH':6}[mode],'Actual ordinary report row count');baseline.append(dict(case_id=old['case_id'],summary=old['summary'],actual_raw_eio=old['actual_raw_eio'],rows=len(rr),all_selected_bytes_equal_after_owned_LF_CRLF_row_terminator_bridge=True,qualification=old['qualification']))
  report=dict(cases=len(cases),kind_counts=dict(counts),direct_method_counts=dict(methods),raw_finite_binary64_fields=bits,actual_all_CompSize_extents=row_extents,retained_original_CON01_EIO_comparisons=baseline,public_Cp_probe_results=[c for c in cases if c['kind']=='public_normal_Cp_probe'],qualification='Named full Native unit INPUT cases, not engine cases; results are direct Native outputs. Cp public behavior only, no direct private-static state/hit count proof. No Source equivalence asserted.')
 receipt=dict(schema='src06-hard-size-full-Native-unit-run.v1',accepted=code==0 and not findings and report is not None,findings=findings,actual_build=ref(bp),reviewed_draft=ref(dp),independent_Source_peer=b['independent_Source_peer'],command=command,cwd=R.as_posix(),child_PID=process.pid if process else None,exit_code=code,launch_error=error,started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,stdout=ref(stdout),stderr=ref(stderr),Native_before=br,Native_after=ar,Native_bytes_match_before_and_after=True,actual_child_modules=mr,actual_three_GNU_DLL_binding_proved_before_any_science_call=len(bindings)==3 and released,full_unit_output=ref(output) if output.exists() else None,admission=report,configure_build_engine_Cargo_or_Source_test_executed=False,launcher_Source=ref(Path(__file__)))
 print(json.dumps(write('receipt.json',receipt)));return 0 if receipt['accepted'] else 1
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--run-only',action='store_true');ap.add_argument('--build',required=True);raise SystemExit(main(ap.parse_args()))

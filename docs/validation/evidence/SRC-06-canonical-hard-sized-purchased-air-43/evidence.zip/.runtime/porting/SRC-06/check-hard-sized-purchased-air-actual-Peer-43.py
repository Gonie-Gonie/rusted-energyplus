﻿"""Root-only aggregate: actual59 first, five real production CLIs, bounded independent regressions."""
from pathlib import Path
from collections import Counter
import argparse,ast,copy,hashlib,importlib.util,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';P=D/'hard-size-command-guards-Peer-43.py';spec=importlib.util.spec_from_file_location('hard_size_guards',P);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
O=D/'Root-source-hard-sized-purchased-air-actual-review-43';CASES=['B-NOLIMIT-24H','B-FLOW-24H','B-CAPACITY-24H','B-BOTH-24H','A-24H']
PARENTS={'B':('canonical-source-thermostat-predefined-B-NOLIMIT-24H-command-Root-44/receipt.json','c87dc0133188773ba95f8b78efd25ee22e772b60a2d57e63551c41497820f49d'),'A':('canonical-source-thermostat-predefined-A-24H-command-Root-44/receipt.json','8671b32221d7122c80c51c1a53014d811da1135def25eec411f150a6c4002f57')}

def whole_ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix()if p.is_relative_to(R)else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def extchecked(row):
 p=(R/row['path']).resolve();v=whole_ref(p);assert(v['sha256'],v['bytes'])==(row['sha256'],row.get('bytes',v['bytes']));return p

def compare_complete(current,old,case,allow_tables):
 # Exact physical streams and exporter records transfer an already accepted
 # case proof; this is independent of the sizing scientific unit.
 rows=[];csv=[];missing=[]
 for ext in ['eso','mtr','eio','audit','shd','rdd','mdd','bnd']:
  x=current/f'eplusrs.{ext}';y=old/f'eplusrs.{ext}';assert x.exists()==y.exists(),(case,ext)
  if x.exists():assert x.read_bytes()==y.read_bytes(),(case,ext);rows.append(dict(current=g.ref(x),accepted44=g.ref(y)))
  else:missing.append(ext)
 now=(current/'results/source-reported-results.json').read_bytes();prior=(old/'results/source-reported-results.json').read_bytes();nv=json.loads(now);pv=json.loads(prior);bridged=now
 for stream in ['eso','mtr']:
  assert Path(nv[stream]['path']).resolve()==(current/f'eplusrs.{stream}').resolve();assert Path(pv[stream]['path']).resolve()==(old/f'eplusrs.{stream}').resolve();x=json.dumps(nv[stream]['path']).encode();y=json.dumps(pv[stream]['path']).encode();assert bridged.count(x)==1;bridged=bridged.replace(x,y,1)
 assert bridged==prior,(case,'whole JSON beyond2ownedpaths')
 for stream in ['eso','mtr']:
  x=current/f'results/source-{stream}.csv';y=old/f'results/source-{stream}.csv';assert x.read_bytes()==y.read_bytes();csv.append(dict(current=g.ref(x),accepted44=g.ref(y)))
 ns=g.read(current/'run-summary.json');ps=g.read(old/'run-summary.json');runtime=copy.deepcopy(ns['rust_runtime'])
 for a,b in zip(runtime['reported_streams'],ps['rust_runtime']['reported_streams'],strict=True):
  assert Path(a['owned_path']).resolve()==(current/Path(b['owned_path']).name).resolve();a['owned_path']=b['owned_path']
 assert runtime==ps['rust_runtime'],(case,'full runtime beyond2ownedpaths')
 changes=[];tables=[];lines=0
 if allow_tables:
  # Reuse the exact established strict metadata reader and only previously
  # classified clock/date positions; no newly guessed/normalized rows.
  reader=D/'check-canonical-B-ingress-IO-A24-transfer-Peer-03.py';assert g.ref(reader)['sha256']=='0742d4694653c9f80e93e1ebe89ed80bf14696b148e39f8477f0c67c1cb50c74';tree=ast.parse(reader.read_bytes());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='typed_metadata');ns0={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<unchanged-strict-metadata>','exec'),ns0)
  prior=g.read(D/'Peer-canonical-B-ingress-IO-A24-transfer-03/review.json');metadata=g.read(g.checked(prior['all_table_metadata_differences']));allowed={(v['format'],v['line']):v['classification']for v in metadata['actual_vs_canonical11_all_uncapped']}
  for ext in ['csv','tab','txt','htm','xml']:
   x=current/f'eplustbl.{ext}';y=old/f'eplustbl.{ext}';a=x.read_bytes().splitlines(keepends=True);b=y.read_bytes().splitlines(keepends=True);assert len(a)==len(b);lines+=len(a)
   for i,(left,right)in enumerate(zip(a,b),1):
    if left==right:continue
    cls=allowed[(ext,i)];assert cls in ['actual wall clock','actual wall date']and ns0['typed_metadata'](left,right,cls,ext);changes.append(dict(case=case,format=ext,line=i,classification=cls,current_raw_hex=left.hex(),accepted44_raw_hex=right.hex()))
   tables.append(dict(current=g.ref(x),accepted44=g.ref(y),lines=len(a)))
  assert lines==19312
 return dict(case=case,whole_physical_streams=rows,expected_both_absent_streams=missing,whole_CSV=csv,whole_reported_JSON_equal_after_exactly2_owned_path_bridges=True,whole_runtime_equal_after_exactly2_owned_path_bridges=True,full_tables=tables,table_lines=lines,table_clock_changes=changes)

def main(a):
 assert not O.exists();ar,app,m,pr,plan=g.authority(a.application);fr=g.argument(a.focused_review);assert g.checked(fr)==g.FOCUS_REVIEW.resolve();focus=g.read(g.FOCUS_REVIEW);assert focus['accepted']and not focus['findings']and focus['application']==ar and focus['complete_compiler_plan']==pr and focus['actual_executed_test_bodies']==1 and focus['Source_cases_bit_exact']==59
 shas=dict(x.split('=',1)for x in a.case_sha);assert set(shas)==set(CASES)and len(a.case_sha)==5;commands={};artifacts=[];core_template=D/'check-source-compact-actual-Root-13.py';assert g.ref(core_template)['sha256']=='e74ca3d9d2a85102f0dca30ed978ed25d7f8bee8e1fd72459b7b7ba131c2dea4';tree=ast.parse(core_template.read_bytes());functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['same_path','core']];ns={'Path':Path,'json':json,'copy':copy,'R':R,'checked':lambda row:g.checked(row).read_bytes()};exec(compile(ast.Module(body=functions,type_ignores=[]),'<whole-unchanged-core-reader>','exec'),ns);core_rows=None
 native=g.read(g.checked(m['actual_Native_fullmethod_unit']));native_output=json.loads(extchecked(native['full_unit_output']).read_bytes());assert native['accepted']and native['exit_code']==0 and not native['findings'];eio=[];case_results=[]
 for case in CASES:
  rp=D/f'canonical-source-hard-sized-purchased-air-{case}-command-Root-43/receipt.json';rr=g.ref(rp);assert rr['sha256']==shas[case];r=g.read(rp);scope=case[0];assert r['exit_code']in(0,6)and r['launch_error']is None and r['source_bytes_match_before_and_after'];assert r['repository_before']==r['repository_after']and r['repository_before']['head']==app['base_HEAD'];assert r['source_snapshot']==focus['actual_snapshot'];assert Path(r['cwd']).resolve()==R;assert Path(r['launch_environment_selected']['CARGO_TARGET_DIR']).resolve()==g.TARGET
  for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_HOME']:assert r['launch_environment_selected'].get(key)is None
  parent_name,parent_sha=PARENTS[scope];parent=D/parent_name;assert g.ref(parent)['sha256']==parent_sha;cmd=list(g.read(parent)['command']);ids=[i for i,v in enumerate(cmd)if v.lower().endswith('.idf')];assert len(ids)==1;case_input=R/'energyplus_porting_plan/cases'/case/'input.idf';assert case_input.read_bytes()==subprocess.check_output(['git','show',app['base_HEAD']+':'+case_input.relative_to(R).as_posix()],cwd=R);cmd[ids[0]]=case_input.resolve().as_posix();out=D/f'canonical-source-hard-sized-purchased-air-{case}-Root-43/output';cmd[cmd.index('--output-dir')+1]=out.as_posix();assert cmd==r['command'];weather=Path(cmd[cmd.index('--weather')+1]);assert whole_ref(weather)['sha256']=='c184b947cd34d41c6d6474d63d66dbb82bc0e6cae4c888edcf837348282bce7f';assert '--features'not in cmd[:cmd.index('--')]
  core=ns['core'](r,case!='B-NOLIMIT-24H');assert all(not v['features']for v in core.values());assert core_rows is None or core==core_rows;core_rows=core
  s=g.read(out/'run-summary.json');d=g.read(out/'diagnostics.json');assert s['exit_code']==r['exit_code']and s['oracle']is None and s['config']['compare_oracle']is False and s['config']['oracle_baseline']is False;errors=[v for v in d['diagnostics']if v['severity']=='error'];completed=r['exit_code']==0
  if case in ['B-NOLIMIT-24H','A-24H']:assert completed,(case,'required regression0')
  if completed:
   assert not errors and s['rust_runtime']['schema']=='rusted-energyplus.source-runtime.v1'and s['rust_runtime']['execution']=='actual Source ManageSimulation successful through620'and s['rust_runtime']['native_environment_hour_scope']==24;assert{p.name for p in(out/'results').iterdir()}=={'source-reported-results.json','source-eso.csv','source-mtr.csv'};frontier=None
  else:
   assert s['rust_runtime']is None and len(errors)==1 and errors[0]['code']=='RuntimeConvergenceFailure'and errors[0]['message'].startswith('GetHeatBalanceInput: ');assert(out/'results').is_dir()and not any((out/'results').iterdir());frontier=errors[0]['message']
  if case in ['B-FLOW-24H','B-CAPACITY-24H','B-BOTH-24H']:
   mode=case.split('-')[1];expected=next(x for x in native_output['cases']if x['name']=='full-SizePurchasedAir-'+mode)['exit']['reports']['eio'].encode();memory=[x for x in expected.splitlines(keepends=True)if x.startswith(b' Component Sizing Information, ZoneHVAC:IdealLoadsAirSystem, ZONE ONE IDEAL LOADS,')];physical=(out/'eplusrs.eio').read_bytes();rows=[x for x in physical.splitlines(keepends=True)if x.startswith(b' Component Sizing Information, ZoneHVAC:IdealLoadsAirSystem, ZONE ONE IDEAL LOADS,')];assert len(memory)==len(rows)=={'FLOW':2,'CAPACITY':4,'BOTH':6}[mode];assert all(x.endswith(b'\n')and not x.endswith(b'\r\n')for x in memory)and all(x.endswith(b'\r\n')for x in rows);assert[x[:-1]+b'\r\n'for x in memory]==rows;assert physical.count(b'! <Component Sizing Information>')==1;eio.append(dict(case=case,physical_Source_EIO=g.ref(out/'eplusrs.eio'),actual_Native_unit=m['actual_Native_fullmethod_unit'],Native_full_Size_case='full-SizePurchasedAir-'+mode,rows=len(rows),selected_all_row_bytes_equal_after_only_memoryLF_to_physicalCRLF_terminator_bridge=True))
  case_results.append(dict(case=case,receipt=rr,exit_code=r['exit_code'],Source620_completed=completed,true_post_sizing_frontier=frontier,reported_output_Native_equivalence_claim=False,summary=g.ref(out/'run-summary.json'),diagnostics=g.ref(out/'diagnostics.json'),input=g.ref(case_input),weather=whole_ref(weather)));commands[case]=(rr,r);artifacts += [rr,r['stdout'],r['stderr'],g.ref(out/'run-summary.json'),g.ref(out/'diagnostics.json')]
  if(out/'eplusrs.eio').exists():artifacts.append(g.ref(out/'eplusrs.eio'))
 # One exact complete snapshot proof shared by focused test and all five CLIs.
 rows={x['path']:x for x in plan['entries']};snap=g.read(g.checked(focus['actual_snapshot']));actual={x['historical_path']:x for x in snap['files']};assert rows.keys()==actual.keys()and len(rows)==4517
 for name,row in rows.items():b=(R/name).read_bytes();assert b==g.checked(actual[name]['archive']).read_bytes()and len(b)==row['final_bytes']and hashlib.sha256(b).hexdigest()==row['final_sha256']
 parent_review=D/'Root-source-thermostat-predefined-actual-review-44/review.json';pv=g.read(parent_review);assert pv['accepted']and not pv['findings']and pv['original_tolerance_RMSE_5352_proof_transferred'];transfers=[]
 for case in ['B-NOLIMIT-24H','A-24H']:
  transfers.append(compare_complete(D/f'canonical-source-hard-sized-purchased-air-{case}-Root-43/output',D/f'canonical-source-thermostat-predefined-{case}-Root-44/output',case,case=='A-24H'))
 b3p=D/'Root-nolimit-B24-durations-actual-review-45/review.json';b3=g.read(b3p);assert b3['accepted']and not b3['findings'];b24=next(x for x in b3['cases']if x['case']=='B-NOLIMIT-24H');assert b24['Source_receipt']==g.ref(D/PARENTS['B'][0])and b24['strict_ordered_reported_stream_comparison_pass']and b24['raw_and_binary64_exact']and b24['own_JSON_CSV_verified'];policy=R/'energyplus_porting_plan/contracts/output-tolerances.json';assert g.ref(policy)['sha256']=='d3cd3e5956ce7e02dbcebe9e8c48799673b66c7b181d932f57514a949dcbf698'
 O.mkdir();lp=O/'A24-table-clock-differences.json';lp.write_text(json.dumps(transfers[1]['table_clock_changes'],indent=2)+'\n',encoding='utf8');artifacts += [g.ref(lp),g.ref(parent_review),g.ref(b3p),b24['comparison'],focus['actual_snapshot'],fr,m['actual_Native_fullmethod_unit']]
 for transfer in transfers:
  for k in ['whole_physical_streams','whole_CSV','full_tables']:artifacts +=[x['current']for x in transfer[k]]
  out=D/f"canonical-source-hard-sized-purchased-air-{transfer['case']}-Root-43/output";artifacts.append(g.ref(out/'results/source-reported-results.json'))
 result=dict(schema='src06-hard-sized-purchased-air-actual59-and-fiveCLI43.v1',accepted=True,findings=[],application=ar,producer=g.ref(g.MANIFEST),production_producer=m['production43_manifest'],independent_production_peer=m['production43_independent_full_semantic_peer'],independent_test_peer=m['test59_independent_full_semantic_peer'],complete_compiler_plan=pr,actual_focused_test_review=fr,actual_focused_test=focus['actual_focused_test'],actual_snapshot=focus['actual_snapshot'],same4517_archived_inputs_exact_final_plan_and_live=True,Rust_sources=4504,selected16_final_sources_exact=True,actual_test_bodies_executed=1,new_test_bodies=0,existing59case_body_pass_first_invocation=True,Source59_bit_exact_cases=59,Source59_finite_fields=19781,actual_Native_fullmethod_unit=m['actual_Native_fullmethod_unit'],actual_production_CLI_invocations=5,ordered_cases=case_results,all_five_normal_featureNone_core_artifacts_exact_first_false_rest_true=True,physical_sizing_rows_equal_genuine_fullNative_Size=eio,Source_completed_cases=[x['case']for x in case_results if x['Source620_completed']],typed_after_sizing_frontiers=[x for x in case_results if x['true_post_sizing_frontier']],accepted44_A24_5352_proof=g.ref(parent_review),accepted45_B24_9792_reported_proof=g.ref(b3p),accepted_B24_Native_comparison=b24['comparison'],regression_transfers=transfers,NoLimit_original_policy_and_JSON_CSV_9792_proof_transferred=True,A24_original_policy_and_JSON_CSV_5352_proof_transferred=True,NoLimit_transferred_series=102,NoLimit_transferred_samples=9792,A24_transferred_series=58,A24_transferred_samples=5352,table_clock_ledger=g.ref(lp),unchanged_original_tolerance_policy=g.ref(policy),publication_artifacts=list({x['path']:x for x in artifacts}.values()),production_launcher_Source=g.ref(D/'launch-hard-sized-purchased-air-Peer-43.py'),focused_launcher_Source=g.ref(D/'launch-hard-size-cohort-Peer-43.py'),command_guards_Source=g.ref(P),core_reader_Source=g.ref(core_template),limits=['One actual59case Source main-body pass is a separate scientific sizing certificate, not A/B production regression evidence.','NoLimit+A24 original numerical/own-export proofs transfer only through separate whole physical/CSV/JSON/runtime comparisons; A tables allow only exact existing clock/date metadata positions.','FLOW/CAP/BOTH actual0 results are Source620 execution facts only until separate Native reported comparisons; typed6 records remain actual frontiers, never numerical PASS.','Only component sizing EIO selected rows are paired here to true Native full functions/retained original CON01 rows, with explicit owned LF/CRLF terminator bridge. No blanket normalization.','No whole15/card/gate/ancillary-I/O completion or positive unrepresented design/autosize/fan/SQL branch proof.'],main_mutations=0,policy_changes=0,gate_changes=0,author_Source=g.ref(Path(__file__)))
 p=O/'review.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(g.ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);p.add_argument('--focused-review',required=True);p.add_argument('--case-sha',action='append',required=True);main(p.parse_args())

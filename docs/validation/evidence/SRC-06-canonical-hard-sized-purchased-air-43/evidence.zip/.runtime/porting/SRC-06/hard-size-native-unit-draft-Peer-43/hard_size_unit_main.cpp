// Private full Native sizing unit: no engine, science body extraction, or expected-answer seeds.
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/Autosizing/HeatingAirFlowSizing.hh>
#include <EnergyPlus/Autosizing/HeatingCapacitySizing.hh>
#include <EnergyPlus/Autosizing/CoolingAirFlowSizing.hh>
#include <EnergyPlus/Autosizing/CoolingCapacitySizing.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataSizing.hh>
#include <EnergyPlus/OutputReportPredefined.hh>
#include <EnergyPlus/PurchasedAirManager.hh>
#include <EnergyPlus/Psychrometrics.hh>
#include <EnergyPlus/IOFiles.hh>
#include <EnergyPlus/SQLiteProcedures.hh>
#include <nlohmann/json.hpp>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
namespace HardSizeUnit {
using json=nlohmann::json;
using EnergyPlus::EnergyPlusData;
using namespace EnergyPlus;
void require(bool value,char const *message){if(!value)throw std::runtime_error(message);}
std::uint64_t bits(double v){std::uint64_t b;std::memcpy(&b,&v,sizeof b);return b;}
double from_bits(std::uint64_t b){double out;std::memcpy(&out,&b,sizeof out);return out;}
json number(double v){require(std::isfinite(v),"finite real Native unit scalar");std::ostringstream s;s<<std::hex<<std::setfill('0')<<std::setw(16)<<bits(v);return json{{"value_bits",s.str()}};}
double real(json const &v){auto text=v.at("value_bits").get<std::string>();require(v.size()==1&&text.size()==16,"raw16hex input");std::uint64_t b=0;for(char c:text){require((c>='0'&&c<='9')||(c>='a'&&c<='f'),"hex input");b=(b<<4)|static_cast<unsigned>(c<='9'?c-'0':c-'a'+10);}double out;std::memcpy(&out,&b,sizeof out);require(std::isfinite(out),"finite input");return out;}
template<class A> json shape(A const&a){json out{{"allocated",a.allocated()},{"size",a.size()}};if constexpr(requires{a.l();a.u();}){out["lower"]=a.l();out["upper"]=a.u();}return out;}
template<class A> json integer_array(A const&a){auto out=shape(a);out["items"]=json::array();for(std::size_t i=1;i<=a.size();++i)out["items"].push_back(a(i));return out;}
json zone_row(DataSizing::ZoneEqSizingData const&row){json out;
    out["AirVolFlow"]=number(row.AirVolFlow);
    out["MaxHWVolFlow"]=number(row.MaxHWVolFlow);
    out["MaxCWVolFlow"]=number(row.MaxCWVolFlow);
    out["OAVolFlow"]=number(row.OAVolFlow);
    out["ATMixerVolFlow"]=number(row.ATMixerVolFlow);
    out["ATMixerCoolPriDryBulb"]=number(row.ATMixerCoolPriDryBulb);
    out["ATMixerCoolPriHumRat"]=number(row.ATMixerCoolPriHumRat);
    out["ATMixerHeatPriDryBulb"]=number(row.ATMixerHeatPriDryBulb);
    out["ATMixerHeatPriHumRat"]=number(row.ATMixerHeatPriHumRat);
    out["DesCoolingLoad"]=number(row.DesCoolingLoad);
    out["DesHeatingLoad"]=number(row.DesHeatingLoad);
    out["CoolingAirVolFlow"]=number(row.CoolingAirVolFlow);
    out["HeatingAirVolFlow"]=number(row.HeatingAirVolFlow);
    out["SystemAirVolFlow"]=number(row.SystemAirVolFlow);
    out["AirFlow"]=row.AirFlow;
    out["CoolingAirFlow"]=row.CoolingAirFlow;
    out["HeatingAirFlow"]=row.HeatingAirFlow;
    out["SystemAirFlow"]=row.SystemAirFlow;
    out["Capacity"]=row.Capacity;
    out["CoolingCapacity"]=row.CoolingCapacity;
    out["HeatingCapacity"]=row.HeatingCapacity;
    out["SystemCapacity"]=row.SystemCapacity;
    out["DesignSizeFromParent"]=row.DesignSizeFromParent;
    out["HVACSizingIndex"]=static_cast<int>(row.HVACSizingIndex);
    out["SizingMethod"]=integer_array(row.SizingMethod);out["CapSizingMethod"]=integer_array(row.CapSizingMethod);return out;
}
template<class A>json zone_array(A const&a){auto out=shape(a);out["items"]=json::array();for(std::size_t i=1;i<=a.size();++i)out["items"].push_back(zone_row(a(i)));return out;}
template<class T>struct ObservedSizer:T {std::string const&error_text()const{return this->lastErrorMessages;}};
template<class T>json local(ObservedSizer<T> const&s){json out;
    out["stdRhoAir"]=number(s.stdRhoAir);
    out["zoneAirFlowSizMethod"]=static_cast<int>(s.zoneAirFlowSizMethod);
    out["dataScalableSizingON"]=s.dataScalableSizingON;
    out["dataScalableCapSizingON"]=s.dataScalableCapSizingON;
    out["isCoilReportObject"]=s.isCoilReportObject;
    out["isFanReportObject"]=s.isFanReportObject;
    out["initialized"]=s.initialized;
    out["errorType"]=static_cast<int>(s.errorType);
    out["sizingType"]=static_cast<int>(s.sizingType);
    out["sizingString"]=s.sizingString;
    out["sizingStringScalable"]=s.sizingStringScalable;
    out["overrideSizeString"]=s.overrideSizeString;
    out["originalValue"]=number(s.originalValue);
    out["autoSizedValue"]=number(s.autoSizedValue);
    out["wasAutoSized"]=s.wasAutoSized;
    out["hardSizeNoDesignRun"]=s.hardSizeNoDesignRun;
    out["sizingDesRunThisAirSys"]=s.sizingDesRunThisAirSys;
    out["sizingDesRunThisZone"]=s.sizingDesRunThisZone;
    out["sizingDesValueFromParent"]=s.sizingDesValueFromParent;
    out["airLoopSysFlag"]=s.airLoopSysFlag;
    out["oaSysFlag"]=s.oaSysFlag;
    out["coilType_Num"]=static_cast<int>(s.coilType_Num);
    out["compType"]=s.compType;
    out["compName"]=s.compName;
    out["isEpJSON"]=s.isEpJSON;
    out["sysSizingRunDone"]=s.sysSizingRunDone;
    out["zoneSizingRunDone"]=s.zoneSizingRunDone;
    out["curSysNum"]=static_cast<int>(s.curSysNum);
    out["curOASysNum"]=static_cast<int>(s.curOASysNum);
    out["curZoneEqNum"]=static_cast<int>(s.curZoneEqNum);
    out["curDuctType"]=static_cast<int>(s.curDuctType);
    out["curTermUnitSizingNum"]=static_cast<int>(s.curTermUnitSizingNum);
    out["numPrimaryAirSys"]=static_cast<int>(s.numPrimaryAirSys);
    out["numSysSizInput"]=static_cast<int>(s.numSysSizInput);
    out["doSystemSizing"]=s.doSystemSizing;
    out["numZoneSizingInput"]=static_cast<int>(s.numZoneSizingInput);
    out["doZoneSizing"]=s.doZoneSizing;
    out["autoCalculate"]=s.autoCalculate;
    out["termUnitSingDuct"]=s.termUnitSingDuct;
    out["termUnitPIU"]=s.termUnitPIU;
    out["termUnitIU"]=s.termUnitIU;
    out["zoneEqFanCoil"]=s.zoneEqFanCoil;
    out["otherEqType"]=s.otherEqType;
    out["zoneEqUnitHeater"]=s.zoneEqUnitHeater;
    out["zoneEqUnitVent"]=s.zoneEqUnitVent;
    out["zoneEqVentedSlab"]=s.zoneEqVentedSlab;
    out["minOA"]=static_cast<int>(s.minOA);
    out["dataEMSOverrideON"]=s.dataEMSOverrideON;
    out["dataEMSOverride"]=number(s.dataEMSOverride);
    out["dataAutosizable"]=s.dataAutosizable;
    out["dataConstantUsedForSizing"]=number(s.dataConstantUsedForSizing);
    out["dataFractionUsedForSizing"]=number(s.dataFractionUsedForSizing);
    out["dataDXCoolsLowSpeedsAutozize"]=s.dataDXCoolsLowSpeedsAutozize;
    out["dataPltSizHeatNum"]=static_cast<int>(s.dataPltSizHeatNum);
    out["dataWaterLoopNum"]=static_cast<int>(s.dataWaterLoopNum);
    out["dataFanIndex"]=static_cast<int>(s.dataFanIndex);
    out["dataFanType"]=static_cast<int>(s.dataFanType);
    out["dataWaterCoilSizCoolDeltaT"]=number(s.dataWaterCoilSizCoolDeltaT);
    out["dataWaterCoilSizHeatDeltaT"]=number(s.dataWaterCoilSizHeatDeltaT);
    out["dataCapacityUsedForSizing"]=number(s.dataCapacityUsedForSizing);
    out["dataPltSizCoolNum"]=static_cast<int>(s.dataPltSizCoolNum);
    out["dataDesInletAirHumRat"]=number(s.dataDesInletAirHumRat);
    out["dataAirFlowUsedForSizing"]=number(s.dataAirFlowUsedForSizing);
    out["dataDesInletAirTemp"]=number(s.dataDesInletAirTemp);
    out["dataDesAccountForFanHeat"]=s.dataDesAccountForFanHeat;
    out["dataFanPlacement"]=static_cast<int>(s.dataFanPlacement);
    out["dataFlowUsedForSizing"]=number(s.dataFlowUsedForSizing);
    out["dataDesOutletAirHumRat"]=number(s.dataDesOutletAirHumRat);
    out["dataDesInletWaterTemp"]=number(s.dataDesInletWaterTemp);
    out["dataDesOutletAirTemp"]=number(s.dataDesOutletAirTemp);
    out["dataWaterFlowUsedForSizing"]=number(s.dataWaterFlowUsedForSizing);
    out["dataSizingFraction"]=number(s.dataSizingFraction);
    out["dataDXSpeedNum"]=static_cast<int>(s.dataDXSpeedNum);
    out["dataDesicRegCoil"]=s.dataDesicRegCoil;
    out["dataHeatSizeRatio"]=number(s.dataHeatSizeRatio);
    out["dataZoneUsedForSizing"]=static_cast<int>(s.dataZoneUsedForSizing);
    out["dataDesicDehumNum"]=static_cast<int>(s.dataDesicDehumNum);
    out["dataNomCapInpMeth"]=s.dataNomCapInpMeth;
    out["dataCoilNum"]=static_cast<int>(s.dataCoilNum);
    out["dataFanOp"]=static_cast<int>(s.dataFanOp);
    out["dataDesignCoilCapacity"]=number(s.dataDesignCoilCapacity);
    out["dataErrorsFound"]=s.dataErrorsFound;
    out["dataBypassFrac"]=number(s.dataBypassFrac);
    out["dataIsDXCoil"]=s.dataIsDXCoil;
    out["dataNonZoneNonAirloopValue"]=number(s.dataNonZoneNonAirloopValue);
    out["printWarningFlag"]=s.printWarningFlag;
    out["callingRoutine"]=s.callingRoutine;
    out["sysSizingInputData"]=shape(s.sysSizingInputData);
    out["zoneSizingInput"]=shape(s.zoneSizingInput);
    out["unitarySysEqSizing"]=zone_array(s.unitarySysEqSizing);
    out["oaSysEqSizing"]=zone_array(s.oaSysEqSizing);
    out["zoneEqSizing"]=zone_array(s.zoneEqSizing);
    out["outsideAirSys"]=shape(s.outsideAirSys);
    out["termUnitSizing"]=shape(s.termUnitSizing);
    out["termUnitFinalZoneSizing"]=shape(s.termUnitFinalZoneSizing);
    out["finalZoneSizing"]=shape(s.finalZoneSizing);
    out["finalSysSizing"]=shape(s.finalSysSizing);
    out["plantSizData"]=shape(s.plantSizData);
    out["primaryAirSystem"]=shape(s.primaryAirSystem);
    out["airloopDOAS"]=json{{"size",s.airloopDOAS.size()},{"container","std::vector"}};
    out["airLoopControlInfo"]=shape(s.airLoopControlInfo);
    out["deltaP"]=number(s.deltaP);
    out["motEff"]=number(s.motEff);
    out["totEff"]=number(s.totEff);
    out["motInAirFrac"]=number(s.motInAirFrac);
    out["fanCompModel"]=s.fanCompModel;
    out["fanShaftPow"]=number(s.fanShaftPow);
    out["motInPower"]=number(s.motInPower);
    out["zoneCoolingOnlyFan"]=s.zoneCoolingOnlyFan;
    out["zoneHeatingOnlyFan"]=s.zoneHeatingOnlyFan;
    out["dataHRFlowSizingFlag"]=s.dataHRFlowSizingFlag;
    out["dataFracOfAutosizedCoolingAirflow"]=number(s.dataFracOfAutosizedCoolingAirflow);
    out["dataFracOfAutosizedHeatingAirflow"]=number(s.dataFracOfAutosizedHeatingAirflow);
    out["dataFlowPerCoolingCapacity"]=number(s.dataFlowPerCoolingCapacity);
    out["dataAutosizedCoolingCapacity"]=number(s.dataAutosizedCoolingCapacity);
    out["dataFlowPerHeatingCapacity"]=number(s.dataFlowPerHeatingCapacity);
    out["dataAutosizedHeatingCapacity"]=number(s.dataAutosizedHeatingCapacity);
    out["dataCoilSizingAirInTemp"]=number(s.dataCoilSizingAirInTemp);
    out["dataCoilSizingAirInHumRat"]=number(s.dataCoilSizingAirInHumRat);
    out["dataCoilSizingAirOutTemp"]=number(s.dataCoilSizingAirOutTemp);
    out["dataCoilSizingAirOutHumRat"]=number(s.dataCoilSizingAirOutHumRat);
    out["dataCoilSizingFanCoolLoad"]=number(s.dataCoilSizingFanCoolLoad);
    out["dataCoilSizingCapFT"]=number(s.dataCoilSizingCapFT);
    out["dataTotCapCurveValue"]=number(s.dataTotCapCurveValue);
    out["dataFracOfAutosizedCoolingCapacity"]=number(s.dataFracOfAutosizedCoolingCapacity);
    out["dataFracOfAutosizedHeatingCapacity"]=number(s.dataFracOfAutosizedHeatingCapacity);
    out["dataCoolCoilCap"]=number(s.dataCoolCoilCap);
    out["dataCoilIsSuppHeater"]=s.dataCoilIsSuppHeater;
    out["suppHeatCap"]=number(s.suppHeatCap);
    out["unitaryHeatCap"]=number(s.unitaryHeatCap);
    out["dataTotCapCurveIndex"]=static_cast<int>(s.dataTotCapCurveIndex);
    out["dataCoolCoilType"]=static_cast<int>(s.dataCoolCoilType);
    out["dataCoolCoilIndex"]=static_cast<int>(s.dataCoolCoilIndex);
    out["zoneHVACSizingIndex"]=static_cast<int>(s.zoneHVACSizingIndex);
    out["zoneHVACSizing"]=shape(s.zoneHVACSizing);
    out["lastErrorMessages"]=s.error_text();
 return out;
}
json globals(EnergyPlusData const&s){json out;
    out["CurOASysNum"]=static_cast<int>(s.dataSize->CurOASysNum);
    out["CurDuctType"]=static_cast<int>(s.dataSize->CurDuctType);
    out["TermUnitSingDuct"]=s.dataSize->TermUnitSingDuct;
    out["TermUnitPIU"]=s.dataSize->TermUnitPIU;
    out["TermUnitIU"]=s.dataSize->TermUnitIU;
    out["ZoneEqFanCoil"]=s.dataSize->ZoneEqFanCoil;
    out["ZoneEqUnitHeater"]=s.dataSize->ZoneEqUnitHeater;
    out["ZoneEqUnitVent"]=s.dataSize->ZoneEqUnitVent;
    out["ZoneEqVentedSlab"]=s.dataSize->ZoneEqVentedSlab;
    out["ZoneSizingInput"]=shape(s.dataSize->ZoneSizingInput);
    out["FinalZoneSizing"]=shape(s.dataSize->FinalZoneSizing);
    out["TermUnitFinalZoneSizing"]=shape(s.dataSize->TermUnitFinalZoneSizing);
    out["SysSizInput"]=shape(s.dataSize->SysSizInput);
    out["FinalSysSizing"]=shape(s.dataSize->FinalSysSizing);
    out["PlantSizData"]=shape(s.dataSize->PlantSizData);
    out["DataEMSOverrideON"]=s.dataSize->DataEMSOverrideON;
    out["DataEMSOverride"]=number(s.dataSize->DataEMSOverride);
    out["DataAutosizable"]=s.dataSize->DataAutosizable;
    out["DataConstantUsedForSizing"]=number(s.dataSize->DataConstantUsedForSizing);
    out["DataFractionUsedForSizing"]=number(s.dataSize->DataFractionUsedForSizing);
    out["DataFanIndex"]=static_cast<int>(s.dataSize->DataFanIndex);
    out["DataFanType"]=static_cast<int>(s.dataSize->DataFanType);
    out["DataPltSizHeatNum"]=static_cast<int>(s.dataSize->DataPltSizHeatNum);
    out["DataWaterLoopNum"]=static_cast<int>(s.dataSize->DataWaterLoopNum);
    out["DataPltSizCoolNum"]=static_cast<int>(s.dataSize->DataPltSizCoolNum);
    out["DataWaterCoilSizHeatDeltaT"]=number(s.dataSize->DataWaterCoilSizHeatDeltaT);
    out["DataWaterCoilSizCoolDeltaT"]=number(s.dataSize->DataWaterCoilSizCoolDeltaT);
    out["DataCapacityUsedForSizing"]=number(s.dataSize->DataCapacityUsedForSizing);
    out["DataHeatSizeRatio"]=number(s.dataSize->DataHeatSizeRatio);
    out["DataAirFlowUsedForSizing"]=number(s.dataSize->DataAirFlowUsedForSizing);
    out["DataDesInletAirTemp"]=number(s.dataSize->DataDesInletAirTemp);
    out["DataDesAccountForFanHeat"]=s.dataSize->DataDesAccountForFanHeat;
    out["DataFanPlacement"]=static_cast<int>(s.dataSize->DataFanPlacement);
    out["DataDesInletAirHumRat"]=number(s.dataSize->DataDesInletAirHumRat);
    out["DataDesOutletAirHumRat"]=number(s.dataSize->DataDesOutletAirHumRat);
    out["DataDesOutletAirTemp"]=number(s.dataSize->DataDesOutletAirTemp);
    out["DataDesInletWaterTemp"]=number(s.dataSize->DataDesInletWaterTemp);
    out["DataFlowUsedForSizing"]=number(s.dataSize->DataFlowUsedForSizing);
    out["DataWaterFlowUsedForSizing"]=number(s.dataSize->DataWaterFlowUsedForSizing);
    out["DataSizingFraction"]=number(s.dataSize->DataSizingFraction);
    out["DataDXSpeedNum"]=static_cast<int>(s.dataSize->DataDXSpeedNum);
    out["DataDesicRegCoil"]=s.dataSize->DataDesicRegCoil;
    out["DataZoneUsedForSizing"]=static_cast<int>(s.dataSize->DataZoneUsedForSizing);
    out["DataDesicDehumNum"]=static_cast<int>(s.dataSize->DataDesicDehumNum);
    out["DataNomCapInpMeth"]=s.dataSize->DataNomCapInpMeth;
    out["DataCoilNum"]=static_cast<int>(s.dataSize->DataCoilNum);
    out["DataFanOp"]=static_cast<int>(s.dataSize->DataFanOp);
    out["DataDesignCoilCapacity"]=number(s.dataSize->DataDesignCoilCapacity);
    out["DataErrorsFound"]=s.dataSize->DataErrorsFound;
    out["DataBypassFrac"]=number(s.dataSize->DataBypassFrac);
    out["DataIsDXCoil"]=s.dataSize->DataIsDXCoil;
    out["DataNonZoneNonAirloopValue"]=number(s.dataSize->DataNonZoneNonAirloopValue);
    out["DataDXCoolsLowSpeedsAutozize"]=s.dataSize->DataDXCoolsLowSpeedsAutozize;
    out["DataScalableSizingON"]=s.dataSize->DataScalableSizingON;
    out["DataScalableCapSizingON"]=s.dataSize->DataScalableCapSizingON;
    out["HRFlowSizingFlag"]=s.dataSize->HRFlowSizingFlag;
    out["DataFracOfAutosizedCoolingAirflow"]=number(s.dataSize->DataFracOfAutosizedCoolingAirflow);
    out["DataFracOfAutosizedHeatingAirflow"]=number(s.dataSize->DataFracOfAutosizedHeatingAirflow);
    out["DataFlowPerCoolingCapacity"]=number(s.dataSize->DataFlowPerCoolingCapacity);
    out["DataAutosizedCoolingCapacity"]=number(s.dataSize->DataAutosizedCoolingCapacity);
    out["DataFlowPerHeatingCapacity"]=number(s.dataSize->DataFlowPerHeatingCapacity);
    out["DataAutosizedHeatingCapacity"]=number(s.dataSize->DataAutosizedHeatingCapacity);
    out["DataCoilSizingAirInTemp"]=number(s.dataSize->DataCoilSizingAirInTemp);
    out["DataCoilSizingAirInHumRat"]=number(s.dataSize->DataCoilSizingAirInHumRat);
    out["DataCoilSizingAirOutTemp"]=number(s.dataSize->DataCoilSizingAirOutTemp);
    out["DataCoilSizingAirOutHumRat"]=number(s.dataSize->DataCoilSizingAirOutHumRat);
    out["DataCoilSizingFanCoolLoad"]=number(s.dataSize->DataCoilSizingFanCoolLoad);
    out["DataCoilSizingCapFT"]=number(s.dataSize->DataCoilSizingCapFT);
    out["DataTotCapCurveIndex"]=static_cast<int>(s.dataSize->DataTotCapCurveIndex);
    out["DataTotCapCurveValue"]=number(s.dataSize->DataTotCapCurveValue);
    out["DataFracOfAutosizedCoolingCapacity"]=number(s.dataSize->DataFracOfAutosizedCoolingCapacity);
    out["DataFracOfAutosizedHeatingCapacity"]=number(s.dataSize->DataFracOfAutosizedHeatingCapacity);
    out["DataCoilIsSuppHeater"]=s.dataSize->DataCoilIsSuppHeater;
    out["SuppHeatCap"]=number(s.dataSize->SuppHeatCap);
    out["UnitaryHeatCap"]=number(s.dataSize->UnitaryHeatCap);
    out["DataCoolCoilType"]=static_cast<int>(s.dataSize->DataCoolCoilType);
    out["DataCoolCoilIndex"]=static_cast<int>(s.dataSize->DataCoolCoilIndex);
    out["ZoneHVACSizing"]=shape(s.dataSize->ZoneHVACSizing);
    out["DataZoneNumber"]=static_cast<int>(s.dataSize->DataZoneNumber);
    out["AutoVsHardSizingThreshold"]=number(s.dataSize->AutoVsHardSizingThreshold);
    out["SysSizingRunDone"]=s.dataSize->SysSizingRunDone;
    out["ZoneSizingRunDone"]=s.dataSize->ZoneSizingRunDone;
    out["CurSysNum"]=static_cast<int>(s.dataSize->CurSysNum);
    out["CurZoneEqNum"]=static_cast<int>(s.dataSize->CurZoneEqNum);
    out["CurTermUnitSizingNum"]=static_cast<int>(s.dataSize->CurTermUnitSizingNum);
    out["NumSysSizInput"]=static_cast<int>(s.dataSize->NumSysSizInput);
    out["NumZoneSizingInput"]=static_cast<int>(s.dataSize->NumZoneSizingInput);
    out["UnitarySysEqSizing"]=zone_array(s.dataSize->UnitarySysEqSizing);
    out["OASysEqSizing"]=zone_array(s.dataSize->OASysEqSizing);
    out["TermUnitSizing"]=shape(s.dataSize->TermUnitSizing);
    out["ZoneEqSizing"]=zone_array(s.dataSize->ZoneEqSizing);
    out["ZoneCoolingOnlyFan"]=s.dataSize->ZoneCoolingOnlyFan;
    out["ZoneHeatingOnlyFan"]=s.dataSize->ZoneHeatingOnlyFan;
    out["DataCoolCoilCap"]=number(s.dataSize->DataCoolCoilCap);
 out["StdRhoAir"]=number(s.dataEnvrn->StdRhoAir);out["isEpJSON"]=s.dataGlobal->isEpJSON;out["DoZoneSizing"]=s.dataGlobal->DoZoneSizing;out["DoSystemSizing"]=s.dataGlobal->DoSystemSizing;out["DisplayExtraWarnings"]=s.dataGlobal->DisplayExtraWarnings;out["NumPrimaryAirSys"]=s.dataHVACGlobal->NumPrimaryAirSys;return out;
}
json reports(EnergyPlusData&s){json out{{"oneTimeCompRptHeaderFlag",s.dataEnvrn->oneTimeCompRptHeaderFlag},{"eio",s.files.eio.get_output()},{"sqlite_present",bool(s.dataSQLiteProcedures->sqlite)}};
 auto const&owner=*s.dataOutRptPredefined;out["sizeCompSizeTableEntry"]=owner.sizeCompSizeTableEntry;out["numCompSizeTableEntry"]=owner.numCompSizeTableEntry;out["CompSizeTableEntry"]=shape(owner.CompSizeTableEntry);auto&items=out["CompSizeTableEntry"]["items"]=json::array();
 for(std::size_t i=1;i<=owner.CompSizeTableEntry.size();++i){auto const&r=owner.CompSizeTableEntry(i);items.push_back(json{{"typeField",r.typeField},{"nameField",r.nameField},{"description",r.description},{"valField",number(r.valField)},{"strField",r.strField},{"active",r.active},{"written",r.written}});}return out;
}
std::unique_ptr<EnergyPlusData> state(){auto s=std::make_unique<EnergyPlusData>();s->files.eio.open_as_stringstream();s->dataEnvrn->StdRhoAir=1.2;s->dataSize->CurZoneEqNum=1;s->dataSize->ZoneEqSizing.allocate(1);s->dataSize->ZoneEqSizing(1).SizingMethod.allocate(HVAC::NumOfSizingTypes);s->dataSize->ZoneEqSizing(1).SizingMethod=0;return s;}
json unit(EnergyPlusData const&s){auto const&p=s.dataPurchasedAirMgr->PurchAir(1);return json{{"Name",p.Name},{"cObjectName",p.cObjectName},{"HeatingLimit",static_cast<int>(p.HeatingLimit)},{"MaxHeatVolFlowRate",number(p.MaxHeatVolFlowRate)},{"MaxHeatSensCap",number(p.MaxHeatSensCap)},{"CoolingLimit",static_cast<int>(p.CoolingLimit)},{"MaxCoolVolFlowRate",number(p.MaxCoolVolFlowRate)},{"MaxCoolTotCap",number(p.MaxCoolTotCap)},{"HVACSizingIndex",p.HVACSizingIndex},{"ZonePtr",p.ZonePtr}};}
PurchasedAirManager::LimitType limit(std::string const&v){if(v=="LimitFlowRate")return PurchasedAirManager::LimitType::FlowRate;if(v=="LimitCapacity")return PurchasedAirManager::LimitType::Capacity;if(v=="LimitFlowRateAndCapacity")return PurchasedAirManager::LimitType::FlowRateAndCapacity;throw std::runtime_error("actual case limit enum");}
void setup_purchased(EnergyPlusData&s,json const&input){auto&m=*s.dataPurchasedAirMgr;m.NumPurchAir=1;m.PurchAir.allocate(1);m.PurchAirNumericFields.allocate(1);auto const&names=input.at("numeric_field_names");m.PurchAirNumericFields(1).FieldNames.allocate(names.size());for(std::size_t i=0;i<names.size();++i)m.PurchAirNumericFields(1).FieldNames(i+1)=names.at(i).get<std::string>();auto&p=m.PurchAir(1);p.Name=input.at("Name").get<std::string>();p.cObjectName=input.at("cObjectName").get<std::string>();p.HeatingLimit=limit(input.at("HeatingLimit").get<std::string>());p.MaxHeatVolFlowRate=real(input.at("MaxHeatVolFlowRate"));p.MaxHeatSensCap=real(input.at("MaxHeatSensCap"));p.CoolingLimit=limit(input.at("CoolingLimit").get<std::string>());p.MaxCoolVolFlowRate=real(input.at("MaxCoolVolFlowRate"));p.MaxCoolTotCap=real(input.at("MaxCoolTotCap"));}
json call_size(EnergyPlusData&s,std::string const&name,json const&origin){json out{{"kind","full_SizePurchasedAir"},{"name",name},{"origin",origin},{"entry",json{{"globals",globals(s)},{"reports",reports(s)},{"unit",unit(s)}}}};PurchasedAirManager::SizePurchasedAir(s,1);out["exit"]=json{{"globals",globals(s)},{"reports",reports(s)},{"unit",unit(s)}};return out;}
template<class T>json call_direct(EnergyPlusData&s,std::string const&method,std::string const&name,std::string const&description,double input,bool print,json const&origin){ObservedSizer<T> sizer;json out{{"kind","full_Sizer"},{"name",name},{"method",method},{"origin",origin},{"input",number(input)},{"print_flag",print},{"constructor",local(sizer)},{"globals_before_initialize",globals(s)},{"reports_before",reports(s)}};sizer.overrideSizingString(description);sizer.initializeWithinEP(s,"ZoneHVAC:IdealLoadsAirSystem","ZONE ONE IDEAL LOADS",print,"SizePurchasedAir: ");out["initialized"]=local(sizer);out["globals_after_initialize"]=globals(s);bool errors=false;auto value=sizer.size(s,input,errors);out["returned"]=number(value);out["errorsFound"]=errors;out["exit"]=local(sizer);out["globals_after"]=globals(s);out["reports_after"]=reports(s);return out;}
json direct(EnergyPlusData&s,int method,std::string const&name,std::string const&description,double input,bool print,json const&origin){switch(method){case 0:return call_direct<HeatingAirFlowSizer>(s,"HeatingAirFlowSizer",name,description,input,print,origin);case 1:return call_direct<HeatingCapacitySizer>(s,"HeatingCapacitySizer",name,description,input,print,origin);case 2:return call_direct<CoolingAirFlowSizer>(s,"CoolingAirFlowSizer",name,description,input,print,origin);case 3:return call_direct<CoolingCapacitySizer>(s,"CoolingCapacitySizer",name,description,input,print,origin);default:throw std::runtime_error("method ordinal");}}
json cp(std::string const&name,double input){auto value=Psychrometrics::PsyCpAirFnW(input);return json{{"kind","public_normal_Cp_probe"},{"name",name},{"input",number(input)},{"returned",number(value)},{"qualification","Explicit named public call sequence, not direct private static cache state/hitcount observation"}};}
json run(json const&inputs){require(inputs.at("schema")=="src06-hard-size-Native-unit-input.v1","input schema");json out{{"schema","src06-hard-size-full-Native-unit.v1"},{"origin","private named full-Native-method unit; no whole engine"},{"cases",json::array()}};auto&cases=out["cases"];
 // MUST precede every HeatingCapacity consumer: function-local Cp state is process-wide, not EnergyPlusData-owned.
 cases.push_back(cp("fresh-process-cold-minus100",-100.0));
 auto const&actual=inputs.at("cases");auto const&names=actual.at("BOTH").at("numeric_field_names");
 std::string descriptions[4]={names.at(4).get<std::string>()+" [m3/s]",names.at(5).get<std::string>()+" [m3/s]","Maximum Cooling Air Flow Rate [m3/s]",names.at(7).get<std::string>()+" [m3/s]"};
 {auto s=state();cases.push_back(direct(*s,1,"Cp-sequence-HeatingCapacity-positive",descriptions[1],120.0,true,json{{"kind","named_cache_sequence"}}));}
 cases.push_back(cp("post-HeatingCapacity-minus100",-100.0));cases.push_back(cp("post-minus100-zero",0.0));
 {auto s=state();cases.push_back(direct(*s,1,"Cp-sequence-HeatingCapacity-zero",descriptions[1],0.0,true,json{{"kind","named_cache_sequence"}}));}
 cases.push_back(cp("post-zero-Sizer-zero",0.0));
 for(int method=0;method<4;++method){double positive=(method==0||method==2)?0.02:120.0;for(double value:{positive,0.0,-1.0}){auto s=state();cases.push_back(direct(*s,method,"direct-hard-"+std::to_string(method)+"-"+std::to_string(value),descriptions[method],value,true,json{{"kind","named_direct_input"}}));}
  {auto s=state();cases.push_back(direct(*s,method,"direct-print-false-"+std::to_string(method),descriptions[method],positive,false,json{{"kind","named_direct_input"}}));}
  {auto s=state();s->dataSize->DataAutosizable=false;cases.push_back(direct(*s,method,"direct-not-autosizable-"+std::to_string(method),descriptions[method],positive,true,json{{"kind","named_direct_input"},{"input_overrides",json{{"DataAutosizable",false}}}}));}
  {auto s=state();s->dataSize->DataEMSOverrideON=true;s->dataSize->DataEMSOverride=7.25;cases.push_back(direct(*s,method,"direct-EMS-"+std::to_string(method),descriptions[method],positive,true,json{{"kind","named_direct_input"},{"input_overrides",json{{"DataEMSOverrideON",true},{"DataEMSOverride",number(7.25)}}}}));}
 }
 for(int method:{0,2}){auto s=state();s->dataSize->DataEMSOverrideON=true;s->dataSize->DataEMSOverride=7.25;s->dataSize->DataScalableSizingON=true;int ordinal=(method==0)?HVAC::HeatingAirflowSizing:HVAC::CoolingAirflowSizing;s->dataSize->ZoneEqSizing(1).SizingMethod(ordinal)=DataSizing::FractionOfAutosizedCoolingAirflow;cases.push_back(direct(*s,method,"airflow-EMS-plus-scalable-"+std::to_string(method),descriptions[method],0.02,true,json{{"kind","named_generalized_metadata_input"}}));}
 for(int method:{1,3}){auto s=state();s->dataSize->DataEMSOverrideON=true;s->dataSize->DataEMSOverride=7.25;s->dataSize->DataScalableCapSizingON=true;int ordinal=(method==1)?HVAC::HeatingCapacitySizing:HVAC::CoolingCapacitySizing;s->dataSize->ZoneEqSizing(1).SizingMethod(ordinal)=DataSizing::CapacityPerFloorArea;cases.push_back(direct(*s,method,"capacity-EMS-plus-scalable-"+std::to_string(method),descriptions[method],120.0,true,json{{"kind","named_generalized_metadata_input"}}));}
 for(char const*mode:{"FLOW","CAPACITY","BOTH"}){auto s=state();setup_purchased(*s,actual.at(mode));cases.push_back(call_size(*s,std::string("full-SizePurchasedAir-")+mode,json{{"kind","actual_case_sizing_user_inputs"},{"case_id",std::string("B-")+mode+"-24H"},{"input",actual.at(mode)}}));}
 for(double value:{0.5,from_bits(UINT64_C(0x3fefffffffffffff)),1.0}){auto s=state();auto input=actual.at("CAPACITY");input["MaxHeatSensCap"]=number(value);setup_purchased(*s,input);cases.push_back(call_size(*s,"full-SizePurchasedAir-SmallLoad-"+std::to_string(bits(value)),json{{"kind","named_user_input_boundary"},{"base_case","B-CAPACITY-24H"},{"input_override",json{{"MaxHeatSensCap",number(value)}}}}));}
 {auto s=state();s->dataSize->DataConstantUsedForSizing=5.0;s->dataSize->DataFractionUsedForSizing=2.0;cases.push_back(direct(*s,0,"constant-fraction-first",descriptions[0],0.02,true,json{{"kind","named_shared_state_sequence"},{"sequence","constant-fraction-reset"},{"ordinal",1}}));cases.push_back(direct(*s,2,"constant-fraction-second-no-reseed",descriptions[2],0.02,true,json{{"kind","named_shared_state_sequence"},{"sequence","constant-fraction-reset"},{"ordinal",2}}));}
 {auto s=state();setup_purchased(*s,actual.at("BOTH"));for(int i=1;i<=17;++i)cases.push_back(call_size(*s,"repeated-BOTH-"+std::to_string(i),json{{"kind","named_shared_state_sequence"},{"sequence","real-class-row-growth"},{"ordinal",i},{"input",actual.at("BOTH")}}));}
 out["case_count"]=cases.size();out["Native_engine_called"]=false;out["expected_values_reconstructed"]=false;out["Cp_state_scope"]="Same process function-local static across all EnergyPlusData lifetimes; public probes infer behavior only";return out;
}
}
int main(int argc,char**argv){try{HardSizeUnit::require(argc==4&&std::string(argv[3])=="--await-parent-modules","usage: hard_size_native_unit INPUT.json OUTPUT.json --await-parent-modules");std::cout<<"NATIVE_SIZING_UNIT_READY_FOR_PARENT_MODULE_PROOF\n"<<std::flush;char release;std::cin.get(release);HardSizeUnit::require(bool(std::cin)&&release=='g',"parent module proof release required");std::ifstream in(argv[1],std::ios::binary);HardSizeUnit::require(bool(in),"input opens");HardSizeUnit::json input;in>>input;auto out=HardSizeUnit::run(input);std::ofstream stream(argv[2],std::ios::binary);HardSizeUnit::require(bool(stream),"fresh output opens");stream<<out.dump()<<'\n';stream.flush();HardSizeUnit::require(bool(stream),"complete unit flush");std::cout<<"Native full sizing unit cases="<<out.at("case_count")<<"\n";return 0;}catch(std::exception const&e){std::cerr<<e.what()<<"\n";return 2;}}

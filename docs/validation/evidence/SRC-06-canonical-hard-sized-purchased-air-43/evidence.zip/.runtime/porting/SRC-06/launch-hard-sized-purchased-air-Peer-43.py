﻿"""Root-only five selected production CLIs after accepted one-body59case review."""
from pathlib import Path
import argparse,importlib.util,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';P=D/'hard-size-command-guards-Peer-43.py';spec=importlib.util.spec_from_file_location('hard_size_guards',P);g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
CASES=['B-NOLIMIT-24H','B-FLOW-24H','B-CAPACITY-24H','B-BOTH-24H','A-24H'];PARENTS={'B':('canonical-source-thermostat-predefined-B-NOLIMIT-24H-command-Root-44/receipt.json','c87dc0133188773ba95f8b78efd25ee22e772b60a2d57e63551c41497820f49d'),'A':('canonical-source-thermostat-predefined-A-24H-command-Root-44/receipt.json','8671b32221d7122c80c51c1a53014d811da1135def25eec411f150a6c4002f57')}
def main(a):
 ar,app,m,pr,plan=g.authority(a.application);fr=g.argument(a.focused_review);assert g.checked(fr)==g.FOCUS_REVIEW.resolve();f=g.read(g.FOCUS_REVIEW);assert f['accepted']and not f['findings']and f['application']==ar and f['complete_compiler_plan']==pr and f['all4517_inputs_exact_final_plan_archive_and_live']and f['actual_executed_test_bodies']==1 and f['Source_cases_bit_exact']==59
 for previous in CASES[:CASES.index(a.case)]:
  r=D/f'canonical-source-hard-sized-purchased-air-{previous}-command-Root-43/receipt.json';old=g.read(r);assert old['exit_code']in(0,6)and old['launch_error']is None and old['source_bytes_match_before_and_after'];assert old['source_snapshot']==f['actual_snapshot']
 scope=a.case[0];name,sha=PARENTS[scope];base=D/name;assert g.ref(base)['sha256']==sha;cmd=list(g.read(base)['command']);assert cmd[cmd.index('--porting-scope')+1]==scope;assert cmd[:2]==['cargo','run']and cmd[cmd.index('--bin')+1]=='eplus-rs';assert '--features'not in cmd[:cmd.index('--')]and not{'test','--all-targets','--oracle-baseline','--compare-oracle'}&set(cmd)
 idfs=[i for i,v in enumerate(cmd)if v.lower().endswith('.idf')];assert len(idfs)==1;input_path=(R/'energyplus_porting_plan/cases'/a.case/'input.idf').resolve();assert input_path.is_file();cmd[idfs[0]]=input_path.as_posix();assert Path(cmd[cmd.index('--weather')+1]).is_file()
 out=D/f'canonical-source-hard-sized-purchased-air-{a.case}-Root-43/output';receipt=D/f'canonical-source-hard-sized-purchased-air-{a.case}-command-Root-43';assert not out.parent.exists()and not receipt.exists();cmd[cmd.index('--output-dir')+1]=out.as_posix();env=g.environment();print('Root43 productionCLI: '+a.case+'; normal featureNone, canonical target, incremental0.',flush=True)
 return subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',receipt.relative_to(R).as_posix(),'--',*cmd],cwd=R,env=env)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case',choices=CASES);p.add_argument('--application',required=True);p.add_argument('--focused-review',required=True);raise SystemExit(main(p.parse_args()))

﻿"""Root-only exact original-core Native43 compile/link. No unit/engine run."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,re,subprocess,time
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';B=R/'.runtime/ep261-gcc13-o0';P=D/'hard-size-native-unit-draft-Peer-43/draft.json';M=D/'hard-size-native-unit-build-Root-43'
def ref(p):
 p=p.resolve()
 with p.open('rb') as s:h=hashlib.file_digest(s,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(r):
 p=(R/r['path']).resolve();a=ref(p);assert a['sha256']==r['sha256'] and a['bytes']==r.get('bytes',a['bytes']),r['path'];return p
def read(p):return json.loads(p.read_bytes())
def write(n,o):
 p=M/n
 with p.open('xb') as f:f.write((json.dumps(o,indent=2)+'\n').encode())
 return ref(p)
def norm(v):return str(v).replace('\\','/').casefold()
def record(argv,label,env):
 start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();code=None;error=None
 with (M/(label+'.stdout')).open('xb') as out,(M/(label+'.stderr')).open('xb') as err:
  try:code=subprocess.run(argv,cwd=B,env=env,stdout=out,stderr=err).returncode
  except OSError as e:error=dict(type=type(e).__name__,message=str(e))
 return dict(command=argv,cwd=B.as_posix(),exit_code=code,launch_error=error,started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,stdout=ref(M/(label+'.stdout')),stderr=ref(M/(label+'.stderr')))
def main(args):
 assert args.build_only and not M.exists();p=read(P);assert p['status']=='PREPARED_NO_BUILD_OR_UNIT_EXECUTED';assert checked(p['build_launcher_Source'])==Path(__file__).resolve()
 pp,sha=args.peer.rsplit('#',1);pp=(R/pp).resolve();assert ref(pp)['sha256']==sha;peer=read(pp);assert peer['accepted'] and not peer['findings'];assert peer.get('reviewed_draft',peer.get('reviewed_packet'))==ref(P)
 parent=read(checked(p['accepted_original_core_build40']));assert parent['accepted'] and not parent['findings'];frozen=read(checked(p['frozen_environment']));assert frozen['accepted'] and frozen['provider_set_complete_for_this_build'];env=frozen['environment'];assert len(env)==len({k.casefold() for k in env}) and all(isinstance(k,str) and isinstance(v,str) for k,v in env.items())
 compiler=checked(frozen['compiler']);assert norm(p['one_compile_argv'][0])==norm(compiler) and norm(p['one_link_argv'][0])==norm(compiler);assert '-ffp-contract=off' in p['one_compile_argv'] and '-UNDEBUG' in p['one_compile_argv'] and '-ffp-contract=off' in p['one_link_argv'];assert not any('fast-math' in v for v in p['one_compile_argv']+p['one_link_argv'])
 u=Path(p['fresh_unit_directory']);assert u.resolve()==Path('D:/CodexBuild/rusted-energyplus/SRC-06/hard-size-native-unit-Root-43').resolve() and not u.exists();assert all(Path(p[k]).resolve().is_relative_to(u.resolve()) for k in ('object','binary','map','implib'))
 def custody():
  print('Native43: authenticating unchanged core/archives/providers/registry and private Sources.',flush=True)
  rows=[ref(P),ref(pp),*p['protected_files'],*[r['whole'] for r in p['Native_authorities']],*[e['source'] for r in p['Native_authorities'] for e in r.get('extents',[])]];actual=[ref(checked(r)) for r in {r['path']:r for r in rows}.values()]
  assert len(read(checked(p['live_compile_registry'])))==p['registry_count']==800;assert norm(next(v for k,v in env.items() if k.casefold()=='path').split(';')[0])==norm(compiler.parent)
  sr=Path(next(v for k,v in env.items() if k.casefold()=='systemroot'));assert all(not (folder/Path(r['path']).name).exists() for folder in [u,R,sr/'System32',sr/'System',sr] for r in p['pinned_runtime_DLLs'])
  return dict(protected_files=actual,full_explicit_environment=env,earlier_DLL_shadows_absent=True)
 before=custody();M.mkdir();u.mkdir();br=write('Native-before.json',before);compile_r=record(p['one_compile_argv'],'compile',env);cr=write('compile-receipt.json',compile_r);link_r=None;lr=None
 if compile_r['exit_code']==0 and compile_r['launch_error'] is None:assert Path(p['object']).is_file();link_r=record(p['one_link_argv'],'link',env);lr=write('link-receipt.json',link_r)
 after=None;error=None
 try:after=custody();assert after==before
 except (AssertionError,OSError) as e:error=dict(type=type(e).__name__,message=str(e))
 ar=write('Native-after.json',dict(custody=after,error=error));ok=compile_r['exit_code']==0 and link_r is not None and link_r['exit_code']==0 and not error;counts={name:0 for name in p['original_core_members_required']};witness={name:[] for name in counts};bad=[];lines=0
 if ok:
  with Path(p['map']).open(encoding='utf8',errors='strict') as f:
   for lines,line in enumerate(f,1):
    for name in counts:
     if re.search(r'libenergypluslib\.a\('+re.escape(name)+r'\)',line):
      counts[name]+=1
      if len(witness[name])<3:witness[name].append(dict(line=lines,literal=line.rstrip('\r\n')))
    if any(x in line for x in p['forbidden_derived_objects']):bad.append(dict(line=lines,literal=line.rstrip('\r\n')))
  assert all(counts.values()) and not bad,'All real sizing/PurchasedAir/report core members required; derived objects forbidden';assert Path(p['binary']).is_file()
 result=dict(schema='src06-hard-size-full-Native-unit-build.v1',accepted=ok,findings=[] if ok else ['Compile/link/custody did not close0'],reviewed_draft=ref(P),independent_Source_peer=ref(pp),actual_parent_build=p['accepted_original_core_build40'],compile=cr,link=lr,Native_before=br,Native_after=ar,Native_bytes_match_before_and_after=after==before and not error,original_core_member_counts=counts,original_core_member_first3_witnesses=witness,forbidden_derived_object_witnesses=bad,map_lines_streamed=lines,actual_only_one_compile_one_link=True,no_CMake_cache_registry_Native_or_canonical_mutation=True,engine_Cargo_tests_or_unit_executed=False,launcher_Source=ref(Path(__file__)))
 for k in ('object','binary','map'):result[k]=ref(Path(p[k])) if Path(p[k]).exists() else None
 print(json.dumps(write('native-build.json',result)));return 0 if ok else 1
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--build-only',action='store_true');ap.add_argument('--peer',required=True);raise SystemExit(main(ap.parse_args()))

"""Lossless actual P4 runtime wrapper; only primary ingress is added separately."""
from pathlib import Path
import collections, hashlib, json, re

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'source-output-processor-runtime-fixture-Audit-01'

def ref(p):
    p = p.resolve()
    with p.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),
            'sha256': digest, 'bytes': p.stat().st_size}

def checked(v):
    p = Path(v['path'])
    p = p if p.is_absolute() else R / p
    actual = ref(p)
    assert actual['sha256'] == v['sha256'] and actual['bytes'] == v['bytes']
    return p

def read(p):
    return json.loads(p.read_bytes())

def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n', encoding='utf-8', newline='\n')
    return ref(p)

def bits(value):
    if isinstance(value, dict):
        if set(value) == {'value_bits'}:
            raw = value['value_bits']
            assert re.fullmatch('[0-9a-f]{16}', raw) and (int(raw,16) >> 52) & 2047 != 2047
            return 1
        return sum(bits(x) for x in value.values())
    if isinstance(value, list):
        return sum(bits(x) for x in value)
    return 0

assert not O.exists()
actual_path = D / 'original-core-gap-batch-run-Root-07-output_processor/receipt.json'
assert ref(actual_path)['sha256'] == 'b3d0e29c6940823f39996aa099d1293e94bf8aa242ef9e6425906dfbe0aec5dd'
actual = read(actual_path)
assert actual['accepted'] is True and actual['findings'] == [] and actual['exit_code'] == 0
assert actual['selected_group'] == 'output_processor'
assert actual['Native_bytes_match_before_and_after'] is True
assert actual['actual_three_GNU_DLL_binding_proved_before_any_science_call'] is True
build = read(checked(actual['actual_build']))
assert build['accepted'] is True and build['Native_bytes_match_before_and_after'] is True
ready = read(checked(actual['reviewed_manifest']))
named_ref = ready['named_inputs']
named = read(checked(named_ref))
output = read(checked(actual['full_unit_output']))
assert output['normal_completion'] is True
assert output['group_order'] == ['output_processor'] and set(output['groups']) == {'output_processor'}

source_path = D / 'source-output-processor-gap-author-Audit-P4-01/input-only.json'
assert ref(source_path)['sha256'] == 'a748185c3ad4cd265b09d3b574ed2f6180525f2491d370f448af8c7f0020d115'
source = read(source_path)
source_proof_path = source_path.with_name('input-only-proof.json')
source_proof = read(source_proof_path)
assert source_proof['complete_prefix_raw_and_order_recovery_exact'] is True
assert source_proof['no_computed_expected_data'] is True
native_cases = named['output_processor']['cases']
actual_cases = output['groups']['output_processor']['cases']
assert len(native_cases) == len(actual_cases) == len(source['factories']) == 1
case, result, ingress = native_cases[0], actual_cases[0], source['factories'][0]
assert case['name'] == result['name'] and case['origin'] == result['origin']
assert case['name'] == ingress['name']
assert ref(Path(case['factory']['input_file'])) == source_proof['Native_primary_IDF']
assert case['steps'] == ingress['steps'] and len(case['steps']) == len(result['steps']) == 38
assert len(result['setup']) == 9
operations = collections.Counter()
snapshots = [result['initial']]
for item in result['setup']:
    snapshots.extend([item['entry'], item['exit']])
for ordinal, (step, event) in enumerate(zip(case['steps'], result['steps'], strict=True),1):
    assert (step['name'], step['operation'], step['inputs']) == (event['name'], event['operation'], event['named_inputs'])
    assert event['ordinal'] == ordinal
    operations[step['operation']] += 1
    snapshots.extend([event['entry'], event['exit']])
assert operations == {'system':25, 'zone':12, 'warmup_reset':1}
assert len(snapshots) == actual['admission']['snapshots_checked'] == 95
whole_bits = bits(output)
assert whole_bits == actual['admission']['raw_finite_binary64_fields'] == 34470

O.mkdir()
fixture = {'schema':'src06-Native-gap-batch-fixture.v1',
           'named_inputs':named, 'native_output':output, 'source_inputs':source}
fixture_ref = save(O / 'fixture.json', fixture)
roundtrip = read(checked(fixture_ref))
assert set(roundtrip) == {'schema','named_inputs','native_output','source_inputs'}
assert roundtrip['named_inputs'] == named
assert roundtrip['native_output'] == output
assert roundtrip['source_inputs'] == source
proof = {
    'schema':'src06-P4-lossless-runtime-fixture-provenance.v1',
    'accepted':True, 'findings':[],
    'actual_Native_group_run':ref(actual_path),
    'exact_Native_named_inputs':named_ref,
    'exact_Native_output':actual['full_unit_output'],
    'fixture':fixture_ref,
    'Source_scaffold':ref(D/'source-output-processor-gap-scaffold-Audit-01/draft.json'),
    'independent_Source_scaffold_peer':ref(D/'Root-Source-P4-scaffold-independent-review-01/review.json'),
    'exact_Source_primary_input_projection':ref(source_path),
    'Source_primary_input_proof':ref(source_proof_path),
    'actual_original_core_build':actual['actual_build'],
    'actual_reviewed_manifest':actual['reviewed_manifest'],
    'actual_genuine_factory_guard_correction':actual['P4_factory_guard02'],
    'independent_genuine_factory_guard_peer':actual['P4_factory_guard_independent_peer02'],
    'preserved_initial_factory_guard_failure':ref(D/'original-core-gap-batch-run-Root-06-output_processor/receipt.json'),
    'whole_JSON_inverses_exact':True,
    'wrapper_keys':['schema','named_inputs','native_output','source_inputs'],
    'persistent_lifetimes':1, 'original_setup_calls':9,
    'original_update_reset_calls':38, 'operation_counts':dict(operations),
    'full_snapshots':95, 'Native_whole_raw_finite_binary64_fields':whole_bits,
    'Source_state_assertion_raw_bits_if_executed':sum(bits(x) for x in snapshots),
    'transformations':'Only a lossless JSON wrapper around complete actual named-input and complete actual output documents, plus the separately proven primary-only Source ingress document. No pruning, output reconstruction, copied formula, expected-state seeding, property/cache change or tolerance adjustment.',
    'guard_contract':'Authenticate this proof, all three exact input/output refs, and fixture. Parse fixture and require the exact four keys; compare entire named_inputs/native_output/source_inputs trees to their authenticated originals. Runtime Source reads source_inputs and named_inputs as inputs, native_output solely as strict expected observations.',
    'qualifications':['Native original-core full function run passed; Source runtime is still pending.',
                      'Native legacy/disabled-frame/catalogue fields absent from Source have the explicit representation qualifications recorded by the Source scaffold. No broader calendar or whole-engine OP claim.',
                      'One selected existing main target; unchanged old Air/report59/P2/P1/Surface suites are not rerun.'],
    'compiler_Cargo_Native_or_Source_scientific_execution':False,
    'author_Source':ref(Path(__file__))
}
proof_ref = save(O/'projection.json', proof)
print(json.dumps({'fixture':fixture_ref,'projection':proof_ref,'snapshots':95,'whole_bits':whole_bits}))

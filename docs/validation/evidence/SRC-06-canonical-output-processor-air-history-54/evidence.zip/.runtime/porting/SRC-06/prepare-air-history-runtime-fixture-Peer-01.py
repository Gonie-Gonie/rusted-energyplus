"""Lossless actual Native history container only; no formula or scientific execution."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-air-history-runtime-fixture-Peer-01'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def count(v):
 if isinstance(v,dict):return int(set(v)=={'value_bits'})+sum(count(x)for x in v.values())
 if isinstance(v,list):return sum(count(x)for x in v)
 return 0
def save(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();actual_path=D/'original-core-gap-batch-run-Root-06-air_history/receipt.json';actual=read(actual_path);assert ref(actual_path)['sha256']=='717ef1911a028cd5c0963825bb34e5003a49a641ad89aa6690fd52c5819f103d'
 assert actual['accepted'] and not actual['findings'] and actual['exit_code']==0 and actual['Native_bytes_match_before_and_after'] and actual['actual_three_GNU_DLL_binding_proved_before_any_science_call']
 build=read(checked(actual['actual_build']));assert build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after'];ready=read(checked(actual['reviewed_manifest']));named_ref=ready['named_inputs'];named=read(checked(named_ref));output=read(checked(actual['full_unit_output']))
 assert output['normal_completion'] is True and output['group_order']==['air_history'] and set(output['groups'])=={'air_history'}
 native_doc=read(D/'air-history-Native-gap-draft-Peer-02/draft.json');assert named['air_history']==read(checked(native_doc['named_inputs']))
 ingress_path=D/'source-purchased-air-gap-scaffold-Peer-01/input-only.json';ingress=read(ingress_path);factories={x['name']:x for x in ingress['factories']};proof=[];snapshots=[];calls=0
 assert len(named['air_history']['cases'])==len(output['groups']['air_history']['cases'])==4
 for definition,result in zip(named['air_history']['cases'],output['groups']['air_history']['cases'],strict=True):
  assert definition['name']==result['name'] and definition['origin']==result['origin'];factory=definition['factory'];source=factories[factory['name']]
  expected_idf=factory['origin']['input'];path=checked(expected_idf);assert path==(R/'energyplus_porting_plan/cases'/source['case']/'input.idf').resolve();assert factory['steps']==source['steps']
  assert len(definition['steps'])==len(result['steps'])==10;operations={}
  snapshots.extend([result['before_real_RoomAir_getter'],result['after_real_RoomAir_getter']])
  for ordinal,(step,actual_step)in enumerate(zip(definition['steps'],result['steps'],strict=True),1):
   assert actual_step['ordinal']==ordinal and actual_step['name']==step['name'] and actual_step['operation']==step['operation'] and actual_step['named_inputs']==step['inputs']
   assert set(step['inputs'])<={'MAT','ZT','ZTAV','airHumRatAvg','airHumRatTemp','pressure'};snapshots.extend([actual_step['entry'],actual_step['exit']]);operations[step['operation']]=operations.get(step['operation'],0)+1;calls+=1
  assert operations==dict(push_zone=5,push_system=4,revert_zone=1)
  proof.append(dict(name=definition['name'],real_P1_factory_name=factory['name'],Source_case=source['case'],actual_IDF=expected_idf,named_original_P1_steps_equal=True,operation_counts=operations,history_or_exit_values_seeded=False))
 assert calls==40 and len(snapshots)==88;owner_bits=sum(count(x)for x in snapshots);whole_bits=count(output);assert whole_bits==actual['admission']['raw_finite_binary64_fields']==23352
 fixture=dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output);fp=save(O/'fixture.json',fixture);roundtrip=read(checked(fp));assert roundtrip['named_inputs']==named and roundtrip['native_output']==output
 projection=save(O/'projection.json',dict(schema='src06-history-lossless-runtime-fixture-provenance.v1',accepted=True,findings=[],actual_Native_group_run=ref(actual_path),exact_Native_named_inputs=named_ref,exact_Native_output=actual['full_unit_output'],fixture=fp,actual_original_core_build=actual['actual_build'],actual_reviewed_manifest=actual['reviewed_manifest'],Source_history_scaffold=ref(D/'source-air-history-gap-scaffold-Peer-01/draft.json'),authentic_Source_raw_ingress=ref(ingress_path),Source_ingress_transport_proof=ref(D/'source-purchased-air-gap-scaffold-Peer-01/input-transport-proof.json'),all_four_factories_and_forty_named_calls=proof,compared_state_snapshots=88,Source_state_raw_bit_observations_if_executed=owner_bits,Native_entire_output_raw_finite_fields=whole_bits,whole_JSON_inverses_exact=True,
  transformations='Only a lossless JSON container/serialization around complete actual named-input/output documents. Every shape, field, order, rawbit string, address and output remains intact. No formula reconstruction, expected output projection, snapshot input seeding or Native/Source execution.',author_Source=ref(Path(__file__))))
 print(json.dumps(dict(fixture=fp,projection=projection,Source_state_bits=owner_bits,Native_whole_output_bits=whole_bits)))
if __name__=='__main__':main()

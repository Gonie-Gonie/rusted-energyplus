"""Private retained same-owner full history adapter, actual named inputs only."""
from pathlib import Path
import copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-air-history-gap-scaffold-Peer-01'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
TEMPLATE=r'''//! Full production history methods on the retained genuine P1 factory owners.
//! No exit/history restore; only named external air and pressure inputs are written.
use super::*;
use hb::ordinary_air_heat_balance::predictor_corrector::SourceZoneAirOwners;
use hb::ordinary_air_heat_balance::SourceZoneSpaceHeatBalanceData;

fn air(row: &SourceZoneSpaceHeatBalanceData) -> Value {
    let mut out=Map::new();
@@AIR_FIELDS@@
    out.insert("address".into(),pointer(row));
    Value::Object(out)
}
fn state(factory:&Factory)->Result<Value>{
    let mut zones=shape(&factory.air.zones);
    zones["items"]=Value::Array(factory.air.zones.as_deref().unwrap_or(&[]).iter().map(|row|air(&row.air)).collect());
    let mut spaces=shape(&factory.air.spaces);
    spaces["items"]=Value::Array(factory.air.spaces.as_deref().unwrap_or(&[]).iter().map(|row|air(&row.air)).collect());
    let room=&factory.controller.subsystems.room_air;
    let mut models=shape(&room.air_models);
    models["items"]=Value::Array(room.air_models.as_deref().unwrap_or(&[]).iter().map(|row|json!({
        "address":pointer(row),"Name":row.name,"ZoneName":row.zone_name,"ZonePtr":row.zone_ptr,
        "AirModel":row.model,"TempCoupleScheme":row.coupling_scheme,"SimAirModel":row.simulate_air_model})).collect());
    let zone_metadata=factory.zones.zones.as_deref().ok_or_else(||invalid("real getter Zone metadata"))?.iter().enumerate().map(|(at,row)|json!({
        "address":pointer(row),"ordinal":at+1,"Name":row.name,"Multiplier":row.multiplier,"ListMultiplier":row.list_multiplier,"spaceIndexes":row.space_indexes})).collect::<Vec<_>>();
    let algorithm=match factory.control.zone_air_solution {
        hb::selected_heat_balance_input::SelectedZoneAirSolution::ThirdOrder=>0,
        hb::selected_heat_balance_input::SelectedZoneAirSolution::Euler=>2,
    }; // Pinned DataHeatBalance.hh100-107; these inputs genuinely select ThirdOrder0.
    Ok(json!({"P1_owners":snapshot(factory)?,"zoneHeatBalance":zones,"spaceHeatBalance":spaces,"AirModel":models,
        "anyNonMixingRoomAirModel":room.any_non_mixing,"GetAirModelData":room.get_air_model_data,
        "doSpaceHeatBalance":factory.space_controls.current,"doSpaceHeatBalanceSimulation":factory.space_controls.simulation,
        "doSpaceHeatBalanceSizing":factory.space_controls.sizing,"ZoneAirSolutionAlgo":algorithm,
        "NumOfZones":factory.globals.num_of_zones,"Zone_metadata":zone_metadata,
        "RoomAir_owner_address":pointer(room),"predictor_owner_address":pointer(&factory.controller)}))
}
fn primary_inputs(factory:&mut Factory,input:&Value)->Result{
    let input=object(input)?;
    for key in input.keys(){
        if !matches!(key.as_str(),"MAT"|"ZT"|"ZTAV"|"airHumRatAvg"|"airHumRatTemp"|"pressure"){
            return Err(invalid("history accepts only real external caller inputs, no histories or computed answers").into());
        }
    }
    let row=factory.air.zones.as_mut().and_then(|rows|rows.get_mut(index(factory.zone).ok()?)).ok_or_else(||invalid("same actual history zone"))?;
    if let Some(v)=input.get("MAT"){row.air.mat=real(v)?;}
    if let Some(v)=input.get("ZT"){row.air.zt=real(v)?;}
    if let Some(v)=input.get("ZTAV"){row.air.ztav=real(v)?;}
    if let Some(v)=input.get("airHumRatAvg"){row.air.air_hum_rat_avg=real(v)?;}
    if let Some(v)=input.get("airHumRatTemp"){row.air.air_hum_rat_temp=real(v)?;}
    if let Some(v)=input.get("pressure"){factory.weather.environment.current_weather.out_baro_press=real(v)?;}
    Ok(())
}
fn call(factory:&mut Factory,operation:&str)->Result{
    let mut backend=SourceErrorBackend{state:&mut factory.error_state,error_stream:Some(&mut factory.error),console:&mut factory.console,
        out_unit1:None,out_unit2:None,f_message:None,message_callback:None,error_callback:None,sqlite:None};
    let source_is_epjson=false;
    let mut owners=SourceZoneAirOwners{
        zones:&mut factory.zones,equipment:&mut factory.equipment,geometry:&factory.ancillary.surface_geometry_input,
        surface_arrays:&factory.surface.arrays,fan:&mut factory.fan,gains:&factory.ancillary.selected_internal_heat_gains,
        control:&mut factory.control,space_controls:&factory.space_controls,globals:&factory.globals,clock:&factory.weather.global,
        environment:&factory.weather.environment,hvac:&mut factory.startup.hvac_globals,input:&mut factory.input,shortcut:&mut factory.shortcut,
        source_is_epjson:&source_is_epjson,faults:&factory.ancillary.source_faults_manager,schedules:&mut factory.schedules,
        availability:&factory.hvac_manager.ancillary.availability,psychrometrics:&mut factory.psych,backend:&mut backend};
    match operation{
        "push_zone"=>factory.air.push_source_zone_timestep_histories(&factory.controller,&mut owners)?,
        "push_system"=>factory.air.push_source_system_timestep_histories(&factory.controller,&owners)?,
        "revert_zone"=>factory.air.revert_source_zone_timestep_histories(&factory.controller,&owners)?,
        _=>return Err(invalid("unknown real full history operation").into()),
    }
    Ok(())
}
#[derive(Default)]
struct HistoryIdentities { pairs:BTreeMap<(String,String),String>, raw_bits:usize }
impl HistoryIdentities {
    fn check(&mut self,source:&Value,native:&Value,path:&str)->Result {
        match(source,native){
            (Value::Object(a),Value::Object(b))=>{
                assert_eq!(a.keys().collect::<Vec<_>>(),b.keys().collect::<Vec<_>>(),"{path} full observed keyset");
                if a.len()==1&&a.contains_key("value_bits"){self.raw_bits+=1;}
                for(k,v)in a{
                    let expected=b.get(k).ok_or_else(||invalid("same observed history key"))?;
                    if matches!(k.as_str(),"address"|"Which"|"owner_address"|"state_address"|"RoomAir_owner_address"|"predictor_owner_address"){
                        match(v,expected){
                            (Value::Null,Value::Null)=>{},
                            (Value::String(actual),Value::String(expected))=>{
                                assert!(actual.starts_with("0x")&&expected.starts_with("0x"),"{path} true pointer transport");
                                let kind=if k!="address"{k.as_str()}else if path.contains("zoneHeatBalance.items"){"ZoneAir"}
                                    else if path.contains("spaceHeatBalance.items"){"SpaceAir"}else if path.contains("AirModel.items"){"AirModel"}
                                    else if path.contains("Zone_metadata"){"Zone"}else if path.contains(".Node.items"){"Node"}
                                    else if path.contains(".PurchAir.items"){"Unit"}else if path.contains(".availability.items"){"Availability"}
                                    else if path.ends_with(".config"){"Config"}else if path.ends_with(".demand"){"Demand"}
                                    else if path.ends_with(".moisture"){"Moisture"}else{"Schedule"};
                                let key=(kind.to_owned(),expected.clone());
                                if let Some(old)=self.pairs.get(&key){assert_eq!(old,actual,"{path} same real persistent owner");}
                                else{assert!(!self.pairs.iter().any(|((old_kind,old_native),old_source)|old_kind==kind&&old_native!=expected&&old_source==actual),"{path} distinct logical rows remain distinct");self.pairs.insert(key,actual.clone());}
                            },
                            _=>return Err(invalid("actual history pointer/null shape").into()),
                        }
                    }else{self.check(v,expected,&format!("{path}.{k}"))?;}
                }
            },
            (Value::Array(a),Value::Array(b))=>{assert_eq!(a.len(),b.len(),"{path} whole array extent");for(i,(a,b))in a.iter().zip(b).enumerate(){self.check(a,b,&format!("{path}[{i}]"))?;}},
            _=>assert_eq!(source,native,"{path} strict observed value"),
        }
        Ok(())
    }
}
pub(super) fn run(fixture:&Value)->Result<usize>{
    let ingress:Value=serde_json::from_str(input::SOURCE_PURCHASED_AIR_INPUT_JSON)?;
    let definitions=member(&ingress,"definitions")?;
    let factories=array(member(&ingress,"factories")?)?;
    let named=member(member(fixture,"named_inputs")?,"air_history")?;
    let expected=member(member(member(fixture,"native_output")?,"groups")?,"air_history")?;
    assert_eq!(member(named,"schema")?,"src06-air-history-original-core-input.v1");
    assert_eq!(member(expected,"schema")?,"src06-air-history-original-core-output.v1");
    let cases=array(member(named,"cases")?)?;let outputs=array(member(expected,"cases")?)?;assert_eq!(cases.len(),4);assert_eq!(outputs.len(),4);
    let mut calls=0;let mut raw_bits=0;
    for(case,expected)in cases.iter().zip(outputs){
        assert_eq!(member(case,"name")?,member(expected,"name")?);assert_eq!(member(case,"origin")?,member(expected,"origin")?);
        let native_factory=member(case,"factory")?;let factory_name=text(member(native_factory,"name")?)?;
        let definition=factories.iter().find(|f|f.get("name").and_then(Value::as_str)==Some(factory_name)).ok_or_else(||invalid("actual history IDF factory ingress"))?;
        assert_eq!(member(definition,"steps")?,member(native_factory,"steps")?);
        let mut factory=Box::new(Factory::new(definitions,definition)?);let mut ids=HistoryIdentities::default();
        let name=text(member(case,"name")?)?;
        assert!(factory.controller.subsystems.room_air.air_models.is_none());
        ids.check(&state(&factory)?,member(expected,"before_real_RoomAir_getter")?,&format!("{name}.before_RoomAir"))?;
        factory.controller.subsystems.room_air.get_source_model_parameters(&factory.zones,&factory.globals,&factory.space_controls,&factory.input,&mut factory.shortcut,&mut factory.eio)?;
        assert!(!factory.controller.subsystems.room_air.any_non_mixing&&!factory.space_controls.current);
        assert_eq!(factory.control.zone_air_solution,hb::selected_heat_balance_input::SelectedZoneAirSolution::ThirdOrder);
        assert!(factory.controller.subsystems.room_air.air_models.as_deref().ok_or_else(||invalid("genuine RoomAir getter allocation"))?.iter().all(|row|row.model==1));
        ids.check(&state(&factory)?,member(expected,"after_real_RoomAir_getter")?,&format!("{name}.after_RoomAir"))?;
        let steps=array(member(case,"steps")?)?;let exits=array(member(expected,"steps")?)?;assert_eq!(steps.len(),10);assert_eq!(exits.len(),10);
        for(at,(step,expected))in steps.iter().zip(exits).enumerate(){
            assert_eq!(member(step,"name")?,member(expected,"name")?);assert_eq!(member(step,"operation")?,member(expected,"operation")?);
            assert_eq!(member(step,"inputs")?,member(expected,"named_inputs")?);assert_eq!(count(member(expected,"ordinal")?)?,at+1);
            primary_inputs(&mut factory,member(step,"inputs")?)?;
            ids.check(&state(&factory)?,member(expected,"entry")?,&format!("{name}.step{}.entry",at+1))?;
            call(&mut factory,text(member(step,"operation")?)?)?;
            ids.check(&state(&factory)?,member(expected,"exit")?,&format!("{name}.step{}.exit",at+1))?;calls+=1;
        }
        raw_bits+=ids.raw_bits;
    }
    assert_eq!(calls,40);assert!(raw_bits>0);
    println!("Air-history genuine persistent calls={calls}; strict raw-bit state observations={raw_bits}; four getter factories; no history/exit restore; private cache unobserved");
    Ok(calls)
}
impl OrdinaryEquipment {
    pub(crate) fn run_native_gap_air_history_cohort(fixture:&Value)->Result<usize>{run(fixture)}
}
'''
def main():
 assert not O.exists();O.mkdir();base_path=D/'source-P1-open-output-fix-Peer-53/complete-proposed-compiler-Source-plan.json';base=read(base_path)
 rows={x['path']:x for x in base['entries']}
 for n,row in rows.items():a=ref(R/n);assert (a['sha256'],a['bytes'])==(row['final_sha256'],row['final_bytes']),n
 structpath=R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance.rs';s=structpath.read_text();body=s[s.index('pub(crate) struct SourceZoneSpaceHeatBalanceData'):s.index('impl Default for SourceZoneSpaceHeatBalanceData')]
 fields=re.findall(r'/// Source ([A-Za-z]\w*)\.\s*pub\(crate\) (\w+): (f64|\[f64; 4\]|i32)',body);assert len(fields)==74 and sum(t=='f64' for _,_,t in fields)==67
 inserts=[]
 for native,source,kind in fields:
  value='number(row.'+source+')' if kind=='f64' else ('Value::Array(row.'+source+'.iter().copied().map(number).collect())' if kind=='[f64; 4]' else 'json!(row.'+source+')')
  inserts.append('    out.insert("'+native+'".into(),'+value+');')
 code=TEMPLATE.replace('@@AIR_FIELDS@@','\n'.join(inserts));new='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort/air_history.rs'
 parent='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs';gap='crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs'
 oldparent=(R/parent).read_text();oldgap=(R/gap).read_text();assert not (R/new).exists();assert '\nmod air_history;' not in oldparent
 parentafter=oldparent+'\nmod air_history;\n';gapafter=oldgap.replace('"purchased_air"|"surface"|"exterior"','"purchased_air"|"surface"|"exterior"|"air_history"')
 needle='        "surface"=>surface::run(&fixture),';assert gapafter.count(needle)==1;gapafter=gapafter.replace(needle,needle+'\n        "air_history"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_air_history_cohort(&fixture),')
 materials=[(parent,oldparent,parentafter),(gap,oldgap,gapafter),(new,'',code)];files=[]
 for number,(name,a,b)in enumerate(materials,1):
  before=None
  if a:
   p=O/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(a,encoding='utf-8',newline='\n');before=ref(p)
  target=O/'proposed'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(b,encoding='utf-8',newline='\n')
  if name==new:
   run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true'],input=None,args=None) if False else subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(target)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert run.returncode==0;b=target.read_text()
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
  so=O/(str(number)+'.syntax.stdout.rs');se=O/(str(number)+'.syntax.stderr');so.write_bytes(parse.stdout);se.write_bytes(parse.stderr)
  record=dict(canonical_path=name,before=before,proposed=ref(target),syntax=dict(exit=0,stdout=ref(so),stderr=ref(se)))
  for key,x,y in [('forward_diff',a,b),('inverse_diff',b,a)]:
   p=O/(str(number)+'.'+key+'.diff');p.write_text(''.join(difflib.unified_diff(x.splitlines(keepends=True),y.splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');record[key]=ref(p)
  files.append(record)
 final=copy.deepcopy(base)
 for f in files:
  row=next((x for x in final['entries'] if x['path']==f['canonical_path']),None)
  if row is None:row=dict(path=f['canonical_path'],before=None,origin='new cfg-only history scientific adapter');final['entries'].append(row)
  row.update(source=f['proposed'],final_sha256=f['proposed']['sha256'],final_bytes=f['proposed']['bytes'])
 final['entries'].sort(key=lambda x:x['path']);final.update(schema='src06-history-only-private-compiler-overlay.v1',inputs=4535,Rust_sources=4522,prior_complete_compiler_Source_plan=ref(base_path));plan=save(O/'complete-proposed-compiler-Source-plan.json',final)
 actual_path=D/'original-core-gap-batch-run-Root-06-air_history/receipt.json';actual=read(actual_path);assert actual['accepted'] and not actual['findings'] and actual['admission']['original_history_method_calls']==40
 native_doc=read(D/'air-history-Native-gap-draft-Peer-02/draft.json');native=read(checked(actual['full_unit_output']))['groups']['air_history'];records=[row for c in native['cases'] for snapshot in [c['before_real_RoomAir_getter'],c['after_real_RoomAir_getter']]+[snapshot for step in c['steps'] for snapshot in [step['entry'],step['exit']]] for row in snapshot['zoneHeatBalance']['items']]
 assert len(records)==88 and all(set(row)=={'address',*[n for n,_,_ in fields]} for row in records)
 proof=save(O/'owner-field-readset.json',dict(air_member_map=[dict(Native_member=n,Source_member=f,type=t)for n,f,t in fields],actual_all88_zone_row_keys_match=True,Source_constructor_and_fields=ref(structpath),parent_P1_entire_prefix_unchanged=True,main_selected_P1_Surface_paths_unchanged=True,primary_write_whitelist=['MAT','ZT','ZTAV','airHumRatAvg','airHumRatTemp','pressure'],explicit_state_resets_between_steps=False,RoomAir_getter='actual get_source_model_parameters once per same factory; no copied model records',relative_humidity='Only production push_source_zone_timestep_histories invokes its actual normal property helper; observer makes no psych/cache call.',no_expected_value_crosses_factory_or_primary_input_writes=True))
 contexts=[R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/history.rs',R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/subsystems.rs',R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector.rs',R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance.rs',R/'crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs',R/'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs']
 draft=save(O/'draft.json',dict(schema='src06-full-Source-air-history-scaffold.v1',status='FROZEN_PRIVATE_SEMANTIC_PEER_PENDING_NO_CONTEXTUAL_TYPECHECK',base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),actual_parent_Source53=ref(D/'Root-source-gap-batch-actual-review-53/review.json'),prior_compiler_plan=ref(base_path),complete_proposed_compiler_Source_plan=plan,files=files,Source_count=3,existing=2,new=1,compiler_inputs=4535,Rust_sources=4522,
  actual_Native_history=ref(actual_path),actual_Native_full_output=actual['full_unit_output'],actual_Native_named_inputs=read(checked(actual['reviewed_manifest']))['named_inputs'],Native_history_draft=ref(D/'air-history-Native-gap-draft-Peer-02/draft.json'),Native_history_independent_peer=ref(D/'Peer-air-history-Native-review-Audit-02/review.json'),Native_authorities=native_doc['Native_authorities'],same_Source_contexts=[ref(x)for x in contexts],readset_and_field_mapping=proof,
  runtime_fixture='WAIT_PRIVATE_LOSSLESS_ACTUAL_WRAPPER_NO_GENERATED_RUST_EXPECTED_CONSTANT',owned_file_coordination='P4 may append independent mod output_processor; this draft only appends mod air_history and its root selector/branch. Final shared suffix literal join is separate and must preserve both original bodies.',qualifications=['Current production full three methods and genuine RoomAir getter, four actual raw47 factory ingresses,40 retained calls. No history/output restore between steps.','All67scalars/six4-valuehistories/initialized index, actual model/Zone/physical Node/P1 owners observed.','No multiplier2/nonmixing/Space/whole ManageZoneAirUpdates acceptance or cache internals claim; no old2336/471/59/P2/P1sixty-call/Surface scientific comparison rerun.'],canonical_Cargo_or_Native_execution=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(draft=draft,plan=plan,readset=proof,files=[f['proposed']for f in files])))
if __name__=='__main__':main()

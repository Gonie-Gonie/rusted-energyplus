"""Private guard-only correction; no compile, link, engine or Source mutation."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'Native-P4-genuine-factory-guard-draft-Audit-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def check(v):
 p=R/v['path'];assert ref(p)==v;return p
assert not O.exists();O.mkdir()
ready=D/'P4-history-Native-recipes-ready-Peer-07/manifest.json';parent=json.loads(ready.read_bytes())
before_ref=parent['caller_Sources'][1];before=check(before_ref).read_bytes()
old=b'''    require(o.outVars.empty() && o.ddOutVars.empty() && o.meters.empty(), "P4 real factory has no output registration producer yet");
    require(o.GetOutputInputFlag, "P4 real first request getter latch");'''
new=b'''    // GetZoneData genuinely performed its four Zone-weather declarations.
    // Preserve their dictionaries and the consumed request latch; never reset
    // those actual factory-produced owners to a pretend cold OP state.
    require(o.outVars.empty() && o.meters.empty(), "P4 genuine factory has no requested live variables or meters");
    constexpr std::string_view factory_dictionary_names[] = {
        "Zone Outdoor Air Drybulb Temperature", "Zone Outdoor Air Wetbulb Temperature",
        "Zone Outdoor Air Wind Speed", "Zone Outdoor Air Wind Direction"};
    require(o.ddOutVars.size() == sizeof(factory_dictionary_names) / sizeof(factory_dictionary_names[0]),
            "P4 actual four GetZoneData dictionary declarations");
    for (std::size_t i = 0; i < o.ddOutVars.size(); ++i) {
        require(o.ddOutVars[i] != nullptr && o.ddOutVars[i]->name == factory_dictionary_names[i] &&
                    o.ddOutVars[i]->keyOutVarNums.empty(), "P4 same genuine unrequested Zone-weather dictionary rows");
    }
    require(o.OutputInitialized && !o.GetOutputInputFlag, "P4 genuine GetZoneData initialized OP and consumed requests");
    auto const &factory_requests = s.dataInputProcessing->inputProcessor->epJSON.at("Output:Variable");
    require(factory_requests.is_object() && o.reqVars.size() == factory_requests.size(),
            "P4 real retained request rows match the original input objects");'''
assert before.count(old)==1
after=before.replace(old,new,1);assert after.replace(new,old,1)==before
after_ref=put(O/'purchased_air_P4_history_batch.cpp',after)
diffs={}
for tag,a,b in [('forward',before,after),('inverse',after,before)]:
 diffs[tag]=put(O/(tag+'.diff'),''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='purchased_air_P4_history_batch.cpp',tofile='purchased_air_P4_history_batch.cpp')).encode())
failure=D/'original-core-gap-batch-run-Root-06-output_processor/receipt.json'
f=json.loads(failure.read_bytes());assert f['accepted'] is False
authorities=[]
for name,ranges in [('HeatBalanceManager.cc',[(2391,2420)]),('OutputProcessor.cc',[(281,319),(421,548),(3039,3084)])]:
 p=R/'.reference/energyplus-src/26.1.0/src/EnergyPlus'/name;b=p.read_bytes()
 g=subprocess.run(['git','-C',str(R/'.reference/energyplus-src/26.1.0'),'show','6f2e40d10250a105b49966baa24d843711e61048:src/EnergyPlus/'+name],capture_output=True,check=True).stdout
 assert b==g
 extents=[]
 for first,last in ranges:extents.append(dict(first=first,last=last,source=put(O/'Native'/f'{name}.{first}-{last}.txt',b''.join(b.splitlines(keepends=True)[first-1:last]))))
 authorities.append(dict(Native_path='src/EnergyPlus/'+name,whole=ref(p),pinned_Git='6f2e40d10250a105b49966baa24d843711e61048',extents=extents))
fixture=D/'source-purchased-air-runtime-fixture-Peer-P1-01/fixture.json';j=json.loads(fixture.read_bytes())
rows=j['native_output']['groups']['purchased_air']['cases'][0]['setup']['registration']
names=['Zone Outdoor Air Drybulb Temperature','Zone Outdoor Air Wetbulb Temperature','Zone Outdoor Air Wind Speed','Zone Outdoor Air Wind Direction']
assert [r['name'] for r in rows['dictionary']]==names and rows['live']==[] and rows['meters']==[]
assert all(r['keyOutVarNums']==[] for r in rows['dictionary'])
proof=put(O/'correction-proof.json',(json.dumps(dict(schema='src06-Native-P4-real-factory-guard-correction.v1',before=before_ref,proposed=after_ref,whole_inverse_exact=True,only_one_guard_block_replaced=True,original_P1_prefix_exact=before[:50921]==after[:50921],history_suffix_exact=before[before.index(b'// Air-history'):]==after[after.index(b'// Air-history'): ] if b'// Air-history' in before else before[-9874:]==after[-9874:],all_original_scientific_calls_inputs_and_observers_unchanged=True,no_owner_write_reset_or_fake_getter_call_added=True,actual_prior_P1_fixture=ref(fixture),independent_existing_factory_dictionary_observation=rows,qualification='Prior P1 observation corroborates genuine GetZoneData producer; it is not P4 output or seeded expected state.'),indent=2)+'\n').encode())
result=dict(schema='src06-Native-P4-factory-guard-correction-draft.v1',status='SOURCE_ONLY_WAIT_INDEPENDENT_PEER_AND_ROOT_EXECUTION',original_P4_draft=ref(D/'output-processor-Native-P4-draft-Audit-01/draft.json'),original_P4_peer=ref(D/'Peer-output-processor-Native-P4-review-01/review.json'),actual_failed_P4_run=ref(failure),actual_accepted_build=f['actual_build'],parent_READY=ref(ready),before=before_ref,proposed=after_ref,forward_diff=diffs['forward'],inverse_diff=diffs['inverse'],correction_proof=proof,Native_authorities=authorities,named_inputs=parent['named_inputs'],unmodified_other_caller_Sources=[parent['caller_Sources'][0],parent['caller_Sources'][2]],no_expected_fixture_or_runtime_PASS=True,author_Source=ref(Path(__file__)))
print(json.dumps(put(O/'draft.json',(json.dumps(result,indent=2)+'\n').encode())))

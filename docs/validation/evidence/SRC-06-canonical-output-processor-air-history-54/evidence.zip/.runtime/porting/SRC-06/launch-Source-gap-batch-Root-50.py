"""Root-only one selected P1 or Surface process main, same final Source50 binary/profile."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def module(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main(a):
 appguard=module(D/'apply-Source-gap-batch-Root-50.py','Source50_application_guards');g=appguard.g
 ar=g.argument(a.application);g.need(g.checked(ar)==(appguard.OUT/'receipt.json').resolve(),'Expected Source50 application path')
 app=g.read(g.checked(ar));g.need(app['accepted'] and not app['findings'] and app['test_or_CLI_invocations']==0,'Accepted one application')
 d=g.read(g.checked(app['draft']));g.need(app['complete_compiler_plan']==d['complete_proposed_compiler_Source_plan'],'Exact final plan')
 g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==app['base_HEAD'],'Same actual HEAD')
 plan=g.read(g.checked(app['complete_compiler_plan']));rows={x['path']:x for x in plan['entries']};g.exact(rows)
 fixture,refs=appguard.fixtures(d,a.group);before=[g.ref(g.checked(x)) for x in refs]
 old=g.read(D/'purchased-air-gap-prepared-WAIT-Peer-P1/prepared.json');g.checked(old['inherited_environment_guard']);g.checked(old['record_command_Source'])
 envguard=module(g.checked(old['inherited_environment_guard']),'Source50_exact_environment');env=envguard.environment()
 command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',a.group,str(g.checked(fixture))]
 output=D/('canonical-source-gap-batch-'+a.group+'-Root-50');guard=D/('Root-runtime-fixture-'+a.group+'-guard-50')
 g.need(not output.exists() and not guard.exists(),'Fresh selected group invocation and custody paths');guard.mkdir()
 (guard/'before.json').write_text(json.dumps(dict(application=ar,fixture=fixture,protected_refs=before,actual_command=command),indent=2)+'\n',encoding='utf-8',newline='\n')
 print('Root Source50: one fresh selected '+a.group+' process-main cohort; old2336/471/59/P2 and other groups skipped.',flush=True)
 code=subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',output.relative_to(R).as_posix(),'--',*command],cwd=R,env=env)
 after=[g.ref(g.checked(x)) for x in refs];g.exact(rows)
 result=dict(schema='src06-runtime-fixture-custody-Source50.v1',accepted=before==after,findings=[] if before==after else ['Fixture changed'],
  application=ar,selected_group=a.group,command=command,exit_code=code,protected_before=before,protected_after=after,
  all4534_compiler_inputs_unchanged=True,actual_receipt=g.ref(output/'receipt.json'),launch_Source=g.ref(Path(__file__)))
 (guard/'after.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');return code if before==after else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);p.add_argument('--group',required=True,choices=['purchased_air','surface']);raise SystemExit(main(p.parse_args()))

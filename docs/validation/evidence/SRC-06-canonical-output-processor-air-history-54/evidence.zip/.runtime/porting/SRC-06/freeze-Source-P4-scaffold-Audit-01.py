"""Freeze cfg-only P4 primary-input caller; no Cargo/native/expected output."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-output-processor-gap-scaffold-Audit-01'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def encode(j):return (json.dumps(j,indent=2,ensure_ascii=False)+'\n').encode()
def check(v):
 p=R/v['path'];assert ref(p)==v;return p
def apply(a,patch):
 lines=a.decode().splitlines(True);p=patch.decode().splitlines(True);out=[];cursor=0;i=2
 while i<len(p):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',p[i]);assert m,p[i]
  start=int(m[1]);index=start-1 if start else 0;assert index>=cursor
  out+=lines[cursor:index];cursor=index;i+=1
  while i<len(p) and not p[i].startswith('@@ '):
   line=p[i];i+=1;assert line[0] in ' +-'
   if line[0] in ' -':assert cursor<len(lines) and lines[cursor]==line[1:];cursor+=1
   if line[0] in ' +':out.append(line[1:])
 out+=lines[cursor:];return ''.join(out).encode()
assert not O.exists();O.mkdir()
parent_path=D/'source-P1-open-output-fix-Peer-53/manifest.json';parent=json.loads(parent_path.read_bytes())
prior_ref=parent['complete_proposed_compiler_Source_plan'];prior=json.loads(check(prior_ref).read_bytes());rows={r['path']:r for r in prior['entries']}
assert len(rows)==4534
for name,row in rows.items():
 b=(R/name).read_bytes();assert len(b)==row['final_bytes'] and hashlib.sha256(b).hexdigest()==row['final_sha256'],name
 assert check(row['source']).read_bytes()==b
old_status_path=D/'source-output-processor-gap-author-Audit-P4-01/status.json';old=json.loads(old_status_path.read_bytes())
native_path=D/'output-processor-Native-P4-draft-Audit-01/draft.json';native=json.loads(native_path.read_bytes())
proposals={}
for v in old['files']:
 name=v['canonical_path']
 if name.endswith('/native_p4.rs'):continue
 assert check(v['before']).read_bytes()==(R/name).read_bytes()
 proposals[name]=check(v['proposed']).read_bytes()
p1='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs'
proposals[p1]=(R/p1).read_bytes()+b'\nmod output_processor;\n'
hub='crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs';a=(R/hub).read_bytes()
needle=b'"purchased_air"|"surface"|"exterior"';assert a.count(needle)==1
b=a.replace(needle,needle+b'|"output_processor"',1)
needle=b'        "exterior"=>Err(invalid("Source Exterior adapter literal join pending").into()),';assert b.count(needle)==1
b=b.replace(needle,b'        "output_processor"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_output_processor_cohort(&fixture),\n'+needle,1);proposals[hub]=b
new={
 'crates/ep_runtime/src/heat_balance/source_output_registration/native_p4.rs':D/'source-P4-output-state-author-Audit-01.rs',
 'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort/output_processor.rs':D/'source-P4-caller-author-Audit-01.rs'}
templates=[]
for name,p in new.items():
 r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=p.read_bytes(),capture_output=True)
 assert r.returncode==0,r.stderr;proposals[name]=r.stdout;templates.append(ref(p))
assert len(proposals)==12 and sum(not (R/n).exists() for n in proposals)==2
files=[];applications=0
for name,b in sorted(proposals.items()):
 a=(R/name).read_bytes() if (R/name).exists() else b''
 assert a!=b and not b'\r' in b,name
 before=put(O/'before'/name,a) if a else None
 after=put(O/'proposed'/name,b);patches={}
 for tag,x,y in [('forward',a,b),('inverse',b,a)]:
  diff=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=name,tofile=name)).encode()
  assert apply(x,diff)==y,name;applications+=1
  patches[tag]=put(O/'diffs'/(name.replace('/','__')+'.'+tag+'.diff'),diff)
 fmt=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True)
 assert fmt.returncode==0,fmt.stderr
 if name in new:assert fmt.stdout==b
 syntax=put(O/'syntax'/(name.replace('/','__')+'.json'),encode(dict(tool='rustfmt --edition 2024 --config skip_children=true --emit stdout',input=after,exit_code=fmt.returncode,new_file_formatted=name in new,stderr_utf8=fmt.stderr.decode(),qualification='Syntax-only stdin parse, not contextual compilation. Existing full files are not reformatted.')))
 files.append(dict(canonical_path=name,before_absent=not bool(a),before=before,proposed=after,forward_diff=patches['forward'],inverse_diff=patches['inverse'],Source_only_parse=syntax))
 rows[name]=dict(path=name,final_sha256=after['sha256'],final_bytes=after['bytes'],source=after,origin='private cfg-only P4 scaffold proposal')
plan=dict(schema='src06-prospective-cfg-P4-compiler-Source-plan.v1',observed_HEAD=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True).stdout.decode().strip(),prior_complete_compiler_Source_plan=prior_ref,parent_is_known_Root_Source53_applied_worktree_not_clean_committed_tree=True,entries=[rows[k] for k in sorted(rows)],compiler_inputs=len(rows),Rust_sources=sum(k.endswith('.rs') for k in rows),selected_files=12,existing=10,new=2,contextual_compilation_and_final_parent_join_pending=True)
assert plan['compiler_inputs']==4536 and plan['Rust_sources']==4523
plan_ref=put(O/'complete-proposed-compiler-Source-plan.json',encode(plan))
# The full prior 4534 inventory check above preserves every old Air/report/
# Sizer/P2 fixture and all unselected production sources without re-execution.
census=subprocess.run(['rg','--json','-n','SourceRealOutputTarget|SourceIntegerOutputTarget','crates'],capture_output=True,check=True).stdout
census_ref=put(O/'concrete-target-API-census.jsonl',census)
coverage=dict(schema='src06-P4-explicit-observation-coverage.v1',primary_inputs=['five stable typed named lvalues','named actual caller time/calendar/end/warmup fields only','genuine original IDF plus exactly 44 appended requests'],real_calls=['two SetupTimePointers','GetReportVariableInput real already-read return','three real SetupOutputVariable registrations','two integer SetupOutputVariable registrations','UpdateMeterReporting','25 System +12 Zone UpdateDataandReport +1 ResetAccumulationWhenWarmupComplete'],compared=['all represented registration counters/latches/time values','all OutVar/DD/request/meter rows and mapped scalar/string fields','all seven meter period arrays/last-simulation/final-year cells','same five live Which and actual time-step target cells','actual EndUseCategory counts/name arrays','actual meterValues','actual ESO/MTR/EIO/MTD bytes and error counters/text','actual seven meter frames whole/filtered JSON and owner options','actual caller calendar/time and prescan records'],unrepresented_native_fields={'output_processor':['NumVariablesForOutput','MaxVariablesForOutput','GetMeterIndexFirstCall','InitFlag','Rept','apiVarRequests_size'],'results_framework':['detailed','frequency'],'dictionary_rows':['unitNameCustomEMS'],'request_rows':['case_insensitive_pattern_present'],'prescan_key_rows':['pattern_present','case_insensitive_pattern_present']},exclusion_policy='Only these exact role/key exclusions are permitted. Every other object key and complete array extent must exist in both snapshots. Excluded values are neither restored nor replaced with invented constants; no full absent-owner equivalence is claimed.',pointer_layout_bridge='Native individually allocated OutVar/DD/Meter objects versus Source Vec rows: row ordinal and every represented field are exact; raw row allocation addresses/relocation are excluded. Actual scalar Which/TimeStep/owner pointers are passively paired by logical pointer class; no cross-language layout equivalence claim.',system_variable_lineage='Actual ProjectSystemVariables cold false/empty constructors and genuine GetProjectData are retained; unit factory does not invoke production processEnvironmentVariables. Minimum-report-frequency and warmup flags are consumed from the same project.system owner, never an expected-output scalar.',factory_lineage='Real Factory::new performs GetZoneData and therefore four unrequested weather dictionary registrations, OutputInitialized=true and consumed GetOutputInputFlag. These owners are validated and preserved; no cold reset.',expected_fixture='Absent: no current expected output or numerical Source PASS can be inferred. Future actual Native fixture must be independently authenticated and preserve complete input/output trees.')
coverage_ref=put(O/'observation-coverage.json',encode(coverage))
context_names=['crates/ep_runtime/src/heat_balance/selected_project_data.rs','crates/ep_runtime/src/heat_balance/selected_project_data/getter.rs','crates/ep_runtime/src/heat_balance/source_output_registration/general_real.rs','crates/ep_runtime/src/heat_balance/source_output_registration/bound_integer.rs','crates/ep_runtime/src/heat_balance/source_output_registration/requested_input.rs','crates/ep_runtime/src/heat_balance/source_output_registration/update_data.rs','crates/ep_runtime/src/heat_balance/source_output_registration/update_meters.rs','crates/ep_runtime/src/heat_balance/source_output_registration/results_meter.rs','crates/ep_runtime/src/heat_balance/source_output_registration/report_streams.rs','crates/ep_runtime/src/heat_balance/source_output_registration/meter_request_input.rs','crates/ep_runtime/src/heat_balance/ordinary_output_control.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs','crates/ep_runtime/src/weather_day/context.rs']
result=dict(schema='src06-Source-full-OutputProcessor-gap-scaffold.v1',status='SOURCE_ONLY_NO_EXPECTED_FIXTURE_NO_CONTEXTUAL_COMPILE_OR_NUMERICAL_PASS',files=files,original_authoring_status=ref(old_status_path),input_only=old['input_only'],primary_input_projection_proof=old['input_proof'],Native_P4_draft=ref(native_path),independent_Native_P4_peer=old['Native_P4_peer'],Native_factory_guard_correction=ref(D/'Native-P4-genuine-factory-guard-draft-Audit-02/draft.json'),independent_factory_guard_peer=ref(D/'Root-Native-P4-real-factory-guard-independent-review-02/review.json'),accepted_Source53_parent=ref(parent_path),independent_Source53_stream_setup_peer=ref(D/'Peer-P1-open-output-review-Audit-53/review.json'),prior_complete_compiler_Source_plan=prior_ref,complete_proposed_compiler_Source_plan=plan_ref,full4534_parent_archive_and_live_readback_exact=True,whole_target_API_census=census_ref,observation_coverage=coverage_ref,Native_authorities=native['Native_authorities'],concrete_same_owner_contexts=[dict(canonical_path=n,whole=ref(R/n)) for n in context_names],source_templates=templates,literal_applications=applications,new_formatted_Rust_sources=2,syntax_only_parses=12,new_test_bodies=0,new_targets_features_dependencies=0,old_Air_report_Sizer_P2_bodies_and_fixtures_unchanged=True,scope='One additional selected group in the same safe-main runtime JSON route. Genuine full OP methods run persistently on retained owners; no expected data enters factory/update inputs. Normal cfg-off production is unchanged. This scaffold deliberately rejects missing or wrong runtime fixtures.',pending=['Root accepted actual Native P4 output and lossless fixture binding.','Independent full Source/privacy/primary-input observation review.','Final shared-parent composition with isolated production IHG proposals and Root compiler execution.'],author_Source=ref(Path(__file__)))
assert applications==24
print(json.dumps(put(O/'draft.json',encode(result))))

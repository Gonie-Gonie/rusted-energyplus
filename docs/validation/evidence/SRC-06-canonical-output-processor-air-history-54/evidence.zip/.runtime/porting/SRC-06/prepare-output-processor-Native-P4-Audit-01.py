"""Private original-core P4 CPP/input proposal only. No build or execution."""
from pathlib import Path
import difflib, hashlib, json, struct, subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'output-processor-Native-P4-draft-Audit-01'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))
def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='utf-8', newline='\n')
def raw(x):
    return {'value_bits': struct.pack('>d', float(x)).hex()}
def checked(path, sha):
    p = R / path
    assert ref(p)['sha256'] == sha
    return p

assert not (O / 'draft.json').exists()
base = checked('.runtime/porting/SRC-06/original-core-gap-batch-type-binding-draft-Audit-03/purchased_air_batch.cpp',
               '3f1e0e286f4fe451672e5fc2673c0dc5004a74714b00281fea9506f1b4d01e4b')
fragment = O / 'output_processor_fragment.cpp'
before, suffix = base.read_bytes(), fragment.read_bytes()
assert b'\r' not in suffix and b'run_output_processor_batch' in suffix
combined = O / 'purchased_air_and_output_processor_batch.cpp'
combined.write_bytes(before + suffix)
assert combined.read_bytes()[:len(before)] == before
forward = O / 'purchased_air_batch.cpp.forward.diff'
inverse = O / 'purchased_air_batch.cpp.inverse.diff'
for p, a, b in [(forward, before, before + suffix), (inverse, before + suffix, before)]:
    p.write_text(''.join(difflib.unified_diff(a.decode().splitlines(keepends=True), b.decode().splitlines(keepends=True),
                    fromfile='purchased_air_batch.cpp', tofile='purchased_air_batch.cpp')), encoding='utf-8', newline='\n')

tracked = checked('energyplus_porting_plan/cases/B-NOLIMIT-24H/input.idf',
                  '47f2dcfd3e129980e5dbe6fd8412902074cb86dade25c08839c66cf781be9f12')
prefix = tracked.read_bytes()
assert prefix.rstrip().endswith(b';') and b'Output:Meter,' not in prefix
freqs = ['Detailed', 'TimeStep', 'Hourly', 'Daily', 'Monthly', 'RunPeriod', 'Annual']
names = ['P4 Zone Average', 'P4 System Average', 'P4 System Energy', 'P4 System Integer', 'P4 Zone Sum Integer']
requests = ['\n! Explicit named P4 ORIGINAL-CORE UNIT requests; original input prefix retained.\n']
for name in names:
    for frequency in freqs:
        requests.append(f'Output:Variable,P4 OWNER,{name},{frequency};\n')
for frequency in freqs[1:]:
    requests.append(f'Output:Meter,Electricity:Facility,{frequency};\n')
requests += [
    'Output:Meter:MeterFileOnly,Heating:Electricity,Hourly;\n',
    'Output:Meter:Cumulative,Electricity:Facility,RunPeriod;\n',
    'Output:Meter:Cumulative:MeterFileOnly,Electricity:Facility,Annual;\n',
]
addition = ''.join(requests).encode('ascii')
idf = O / 'p4-original-prefix-plus-named-requests.idf'
idf.write_bytes(prefix + addition)
assert idf.read_bytes()[:-len(addition)] == prefix
request_append = O / 'named-request-append.idf.txt'
request_append.write_bytes(addition)

steps = []
def step(name, operation, **inputs):
    assert operation in ['system', 'zone', 'warmup_reset']
    steps.append(dict(name=name, operation=operation, inputs=inputs))
def interval(label, quarter, samples, zone, *, warmup, hour, day, month, day_of_month, final=False, year=None):
    # Explicit test caller clock and sample inputs only. No TSValue, report,
    # meter period, extrema, expected energy or output state is accepted.
    clock = dict(zone_hours=raw(0.25), hour=hour, timestep=quarter, day_of_sim=day,
        environment_days=2, month=month, day_of_month=day_of_month, day_of_week=3,
        holiday=0, dst=0, warmup=warmup, end_hour=False, end_day=False,
        end_environment=False, end_month=False, end_year=False)
    if year is not None:
        clock['calendar_year'] = year
    for i, (minutes, average, energy, integer) in enumerate(samples, 1):
        step(f'{label}.system{i}', 'system', **clock, system_hours=raw(minutes / 60.0),
             system_seconds=raw(minutes * 60.0), system_average=raw(average),
             system_energy=raw(energy), system_integer=integer)
    zone_clock = dict(clock)
    zone_clock['end_hour'] = quarter == 4
    if final:
        assert not warmup and quarter == 4
        zone_clock.update(end_day=True, end_environment=True, end_month=True, end_year=True)
    step(f'{label}.zone', 'zone', **zone_clock, zone_average=raw(zone[0]), zone_sum_integer=zone[1])

# One lifetime, four complete warmup quarter-hours, genuine reset, a second
# complete hour including cancellation and all period ends, then one new hour.
for q in range(1, 5):
    interval(f'warmup.q{q}', q, [(10, 10 + q, 11, q), (5, 20 + q, 13, -q)],
             (30 + q, q), warmup=True, hour=1, day=0, month=12, day_of_month=31, year=2020)
step('actual_warmup_complete_reset', 'warmup_reset', warmup=False)
normal = [
    ([(10, 12.0, 2.0, 3), (5, 24.0, 5.0, 8)], (18.0, 4)),
    ([(10, -12.0, -3.0, -3), (5, -24.0, -4.0, -8)], (-18.0, -4)),
    ([(5, 1.0, 1.0e16, 5), (5, 2.0, 1.0, 6), (5, 3.0, -1.0e16, 7)], (0.0, 0)),
    ([(10, -0.0, 0.0, 0), (5, 0.0, -0.0, 0)], (-0.0, 0)),
]
for q, (samples, zone) in enumerate(normal, 1):
    interval(f'normal.year_end.q{q}', q, samples, zone, warmup=False,
             hour=24, day=1, month=12, day_of_month=31, final=q == 4)
for q in range(1, 5):
    interval(f'normal.next_year.q{q}', q, [(10, q, -q, -q), (5, -q, q, q)],
             (q / 2.0, q - 2), warmup=False, hour=1, day=2, month=1, day_of_month=1)

assert len(steps) == 38
allowed = {'zone_average', 'system_average', 'system_energy', 'system_integer', 'zone_sum_integer',
    'zone_hours', 'system_hours', 'system_seconds', 'hour', 'timestep', 'day_of_sim', 'calendar_year',
    'environment_days', 'month', 'day_of_month', 'day_of_week', 'holiday', 'dst', 'warmup', 'end_hour',
    'end_day', 'end_environment', 'end_month', 'end_year'}
assert all(set(x['inputs']) <= allowed for x in steps)
assert sum(x['operation'] == 'zone' for x in steps) == 12
assert sum(x['operation'] == 'system' for x in steps) == 25
assert sum(x['operation'] == 'warmup_reset' for x in steps) == 1
named = dict(schema='src06-output-processor-gap-input.v1', cases=[dict(
    name='persistent_unequal_steps_warmup_cancellation_and_periods',
    origin=dict(kind='explicit_original_core_full_method_unit_inputs', original_tracked_IDF=ref(tracked),
        appended_request_input=ref(request_append), input_prefix_preserved_exact=True,
        qualification='Explicit unit input/calendar sequence, not a full-hour/day/year simulation or production admission.'),
    factory=dict(input_file=idf.as_posix()), steps=steps)])
named_path = O / 'named-inputs.json'
save(named_path, named)

# Bind actual declarations/methods; never compile, derive a body, or run Native.
plan_path = checked('.runtime/porting/SRC-06/output-processor-full-method-P4-readonly-plan-Audit-01/plan.json',
                    'b01685b58deb1e34d90b44c6ffe93ae1da8cb46957c9568d9755a3185833f0c5')
plan = json.loads(plan_path.read_bytes())
authorities = list(plan['Native_authorities'])
extras = {
    'src/EnergyPlus/OutputProcessor.hh': [(588, 654), (785, 843)],
    'src/EnergyPlus/ResultsFramework.cc': [(263, 281), (390, 504), (1179, 1194)],
    'src/EnergyPlus/DataOutputs.hh': [(74, 123)],
    'src/EnergyPlus/DataGlobals.hh': [(65, 145)],
    'src/EnergyPlus/DataEnvironment.hh': [(90, 130)],
    'src/EnergyPlus/DataHVACGlobals.hh': [(490, 532)],
    'src/EnergyPlus/DataGlobalConstants.hh': [(371, 450)],
}
for rel, ranges in extras.items():
    path = N / rel
    data = path.read_bytes()
    assert data == subprocess.check_output(['git', '-C', str(N), 'show', PIN + ':' + rel])
    lines = data.splitlines(keepends=True)
    a = next((x for x in authorities if x['Native_path'] == rel), None)
    if a is None:
        a = dict(Native_path=rel, pinned_Git=PIN, whole=ref(path), extents=[])
        authorities.append(a)
    for first, last in ranges:
        assert 1 <= first <= last <= len(lines)
        file = O / 'Native-extents' / (rel.replace('/', '__') + f'.{first}-{last}.txt')
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(b''.join(lines[first-1:last]))
        a['extents'].append(dict(first=first, last=last, source=ref(file), physical_line_extent=True,
            meaning='P4 exact observed members or original method/API implementation'))
for a in authorities:
    file = R / a['whole']['path']
    assert ref(file) == a['whole']
    assert file.read_bytes() == subprocess.check_output(['git', '-C', str(N), 'show', PIN + ':' + a['Native_path']])

prefix_proof = O / 'accepted-P1-prefix-and-input-inverse.json'
save(prefix_proof, dict(accepted_P1=ref(base), proposed_combined=ref(combined), appended_fragment=ref(fragment),
    inverse_operand=dict(operation='remove only exact appended fragment at prior byte length', byte_offset=len(before),
                         entire_prior_P1_bytes_recovered=True), forward_diff=ref(forward), inverse_diff=ref(inverse),
    original_IDF=ref(tracked), new_IDF=ref(idf), appended_request_bytes=ref(request_append),
    IDF_prefix_inverse=dict(remove_exact_suffix_bytes=len(addition), recovers_original_whole=True),
    requested_lvalues=5, requested_frequencies=freqs, actual_variable_request_count=35, actual_meter_request_count=9,
    whole_method_calls=dict(setup=9, system=25, zone=12, warmup_reset=1), expected_answers_authored=False))

packet = dict(schema='src06-original-core-OutputProcessor-P4-CPP-draft.v1',
    status='FROZEN_PRIVATE_CPP_NO_COMPILE_RUN_EXPECTED_OR_SOURCE_NUMERICAL_PASS',
    prepared_at_HEAD=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    read_only_design=ref(plan_path), accepted_P1_prefix=ref(base), proposed_combined_TU=ref(combined),
    appended_P4_only_fragment=ref(fragment), exact_prefix_and_input_inverse=ref(prefix_proof), named_inputs=ref(named_path),
    full_unit_input_IDF=ref(idf), original_input_IDF=ref(tracked), Native_authorities=authorities,
    reused_P1_peer=ref(D / 'Peer-purchased-air-Native-caller-review-P1-02/review.json'),
    binding_peer=ref(D / 'Peer-original-core-gap-batch-type-binding-review-03/review.json'),
    Source_contexts=plan['current_Source_contexts'],
    export='nlohmann::json NativeGapBatch::run_output_processor_batch(nlohmann::json const&)',
    selected_group='output_processor', required_future_main_header='Outer09 design or an exact successor; current three-group10 remains unchanged',
    actual_original_method_route=[
        'Reuse genuine P1 raw InputProcessor/PostIP/GetZoneData/GetZoneEquipment/availability/InitZoneEquipment factory on an exact original B input prefix plus named Output requests. Cold actual OP empty arrays/latch/unbound time pointers are checked, never cleared or forced.',
        'SetupTimePointers binds same real Global.TimeStepZone and HVAC.TimeStepSys. Actual GetReportVariableInput consumes true raw requests and latch. Five SetupOutputVariable calls bind stable three real and two integer lvalues at all seven frequencies. Sum energy alone uses true Electricity/HVAC/Heating/General meter allocation with native 2x3 multipliers.',
        'Actual UpdateMeterReporting performs normal meter discovery/IDs/memberships/period reporting flags and meterValues storage; it is called once after setup. There is no hand-filled reqVar/map/latch/count/period/ID.',
        'System callbacks execute full UpdateDataandReport only. Each Zone callback executes full UpdateDataandReport once; its own original body calls UpdateMeters/ReportTSMeters and later ReportMeters in original order. Never call UpdateMeters a second time after Zone.',
        'One real persistent factory executes four warmup quarter-hours, the actual warmup reset, four normal quarter-hours with unequal steps/cancellation and real day/month/environment/year flags, then four next-year quarter-hours. Intermediate report owners/cache/calendar outputs are never restored. CalendarYear is seeded only at warmup caller input; the original year-end method creates the next year.'
    ],
    normal_domain_and_observation=[
        'Full initialized OutVar/DD/request state, real/int Which identities+raw live samples, all initialized normal Meter fields including produced RT_forIPUnits/periods/extrema/dates/flags/IDs, meterValues, real pointers/minute cursors/report counters, EndUseCategory arrays, exact ESO/MTR/EIO/MTD memory bytes and diagnostic changes are observed before and after every original full method.',
        'Actual public ResultsFramework detailed/frequency/meter frame flags and full JSON are observed read-only, with every float transformed to raw bits. Meter frames are observed even when the actual variable-frame option is false. Whole and meter-file-filtered public meter JSON are separately retained.',
        'Protected ResultsFramework outputVariables catalogue and lastHour/lastMinute have no public raw getter. The catalogue is written but not consumed by this tested update path (future CSV export remains excluded); exact emitted dictionaries and public frames are observed. lastHour/lastMinute are only consumed by beginningOfInterval=true, which is checked false from actual constructor/input. No private-memory reinterpretation, friend/header edits or pretend full-RF-state equivalence.',
        'No scheduled requested variables, custom/decrement meters, SQLite, positive API-variable requests, enabled variable frames/ISO beginning-of-interval extensions or full engine/calendar completion are claimed. No FP changes/private-cache reset/expected numerical answers.'
    ],
    pending=['Fresh independent full P4 CPP/context/definedness/readset peer',
        'Root review and explicit next consolidated-main/header/input/build/run recipe successor; never alter running first three-group files',
        'Root-only original-core compile/link and per-PID three-GNU-module gate before any science',
        'Genuine Native output and lossless expected projection, then actual Source cohort adapter/peer/full compiler-parent/focused runtime'],
    canonical_changes=False, compiler_Cargo_Native_or_scientific_execution=False, author_Source=ref(Path(__file__)))
save(O / 'draft.json', packet)
print(json.dumps(dict(draft=ref(O / 'draft.json'), CPP=ref(combined), fragment=ref(fragment), named_inputs=ref(named_path),
    calls=packet['actual_original_method_route'].__len__(), explicit_update_calls=len(steps))))

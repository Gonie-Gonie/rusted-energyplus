"""Private append-only original-core history unit caller; no compiler or science execution."""
from pathlib import Path
import copy,difflib,hashlib,json,re,struct,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'air-history-Native-gap-draft-Peer-01';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert ref(p)==v;return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def bits(v):return {'value_bits':struct.pack('>d',v).hex()}

TEMPLATE=r'''
// Future gap-only air-history caller. Accepted P1 prefix remains byte-identical.
#include <EnergyPlus/HeatBalanceAirManager.hh>
#include <EnergyPlus/DataRoomAirModel.hh>

namespace NativeGapBatch::AirHistoryDetail {
using json=nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
using PurchasedAirDetail::require;
using PurchasedAirDetail::number;
using PurchasedAirDetail::pointer;
using PurchasedAirDetail::real;

json air(ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData const &a) {
    json out{{"address",pointer(&a)},{"hmThermalMassMultErrIndex",a.hmThermalMassMultErrIndex}};
@SCALARS@
@HISTORIES@
    return out;
}

json state(PurchasedAirDetail::Factory &factory) {
    auto &s=*factory.state;
    auto const &zones=s.dataZoneTempPredictorCorrector->zoneHeatBalance;
    auto const &spaces=s.dataZoneTempPredictorCorrector->spaceHeatBalance;
    auto const &models=s.dataRoomAir->AirModel;
    json zone_rows=PurchasedAirDetail::shape(zones);zone_rows["items"]=json::array();
    for(std::size_t i=1;i<=zones.size();++i)zone_rows["items"].push_back(air(zones(i)));
    json space_rows=PurchasedAirDetail::shape(spaces);space_rows["items"]=json::array();
    for(std::size_t i=1;i<=spaces.size();++i)space_rows["items"].push_back(air(spaces(i)));
    json model_rows=PurchasedAirDetail::shape(models);model_rows["items"]=json::array();
    for(std::size_t i=1;i<=models.size();++i){auto const &m=models(i);model_rows["items"].push_back(json{
        {"address",pointer(&m)},{"Name",m.Name},{"ZoneName",m.ZoneName},{"ZonePtr",m.ZonePtr},
        {"AirModel",static_cast<int>(m.AirModel)},{"TempCoupleScheme",static_cast<int>(m.TempCoupleScheme)},
        {"SimAirModel",m.SimAirModel}});}
    json zone_metadata=json::array();
    for(int i=1;i<=s.dataGlobal->NumOfZones;++i){auto const &z=s.dataHeatBal->Zone(i);zone_metadata.push_back(json{
        {"address",pointer(&z)},{"ordinal",i},{"Name",z.Name},{"Multiplier",z.Multiplier},{"ListMultiplier",z.ListMultiplier},
        {"spaceIndexes",z.spaceIndexes}});}
    return json{{"P1_owners",PurchasedAirDetail::snapshot(factory)},
        {"zoneHeatBalance",zone_rows},{"spaceHeatBalance",space_rows},{"AirModel",model_rows},
        {"anyNonMixingRoomAirModel",s.dataRoomAir->anyNonMixingRoomAirModel},
        {"GetAirModelData",s.dataRoomAir->GetAirModelData},
        {"doSpaceHeatBalance",s.dataHeatBal->doSpaceHeatBalance},
        {"doSpaceHeatBalanceSimulation",s.dataHeatBal->doSpaceHeatBalanceSimulation},
        {"doSpaceHeatBalanceSizing",s.dataHeatBal->doSpaceHeatBalanceSizing},
        {"ZoneAirSolutionAlgo",static_cast<int>(s.dataHeatBal->ZoneAirSolutionAlgo)},
        {"NumOfZones",s.dataGlobal->NumOfZones},{"Zone_metadata",zone_metadata},
        {"RoomAir_owner_address",pointer(s.dataRoomAir.get())},
        {"predictor_owner_address",pointer(s.dataZoneTempPredictorCorrector.get())}};
}

void apply_inputs(PurchasedAirDetail::Factory &factory,json const &input) {
    auto &s=*factory.state;
    require(input.is_object(),"history primary caller input object");
    constexpr std::string_view allowed[]={"MAT","ZT","ZTAV","airHumRatAvg","airHumRatTemp","pressure"};
    for(auto it=input.begin();it!=input.end();++it){bool found=false;for(auto key:allowed)if(key==it.key())found=true;
        require(found,"history accepts only external air/pressure inputs, never histories or computed answers");}
    auto &a=s.dataZoneTempPredictorCorrector->zoneHeatBalance(factory.zone);
    if(input.contains("MAT"))a.MAT=real(input.at("MAT"));
    if(input.contains("ZT"))a.ZT=real(input.at("ZT"));
    if(input.contains("ZTAV"))a.ZTAV=real(input.at("ZTAV"));
    if(input.contains("airHumRatAvg"))a.airHumRatAvg=real(input.at("airHumRatAvg"));
    if(input.contains("airHumRatTemp"))a.airHumRatTemp=real(input.at("airHumRatTemp"));
    if(input.contains("pressure"))s.dataEnvrn->OutBaroPress=real(input.at("pressure"));
}

json run_case(json const &input) {
    auto factory=PurchasedAirDetail::make_factory(input.at("factory"));auto &s=*factory.state;
    require(!s.dataRoomAir->AirModel.allocated(),"real P1 factory precedes RoomAir getter");
    json out{{"name",input.at("name")},{"origin",input.at("origin")},
        {"before_real_RoomAir_getter",state(factory)},{"steps",json::array()}};
    bool errors=false;
    HeatBalanceAirManager::GetRoomAirModelParameters(s,errors);
    require(!errors,"actual RoomAir input getter succeeds");
    require(s.dataRoomAir->AirModel.allocated() && static_cast<int>(s.dataRoomAir->AirModel.size())==s.dataGlobal->NumOfZones,"real getter model allocation");
    require(!s.dataRoomAir->anyNonMixingRoomAirModel && !s.dataHeatBal->doSpaceHeatBalance,"actual finite mixed zone branch");
    require(s.dataHeatBal->ZoneAirSolutionAlgo==DataHeatBalance::SolutionAlgo::ThirdOrder,"actual finite ThirdOrder branch");
    for(auto const &m:s.dataRoomAir->AirModel)require(m.AirModel==RoomAir::RoomAirModel::Mixing,"actual getter mixing row");
    out["after_real_RoomAir_getter"]=state(factory);
    std::size_t ordinal=0;
    for(auto const &step:input.at("steps")){
        apply_inputs(factory,step.at("inputs"));auto operation=step.at("operation").get<std::string>();
        json record{{"ordinal",++ordinal},{"name",step.at("name")},{"operation",operation},
            {"named_inputs",step.at("inputs")},{"entry",state(factory)}};
        if(operation=="push_zone")ZoneTempPredictorCorrector::PushZoneTimestepHistories(s);
        else if(operation=="push_system")ZoneTempPredictorCorrector::PushSystemTimestepHistories(s);
        else if(operation=="revert_zone")ZoneTempPredictorCorrector::RevertZoneTimestepHistories(s);
        else throw std::runtime_error("unknown original full history operation");
        record["exit"]=state(factory);out["steps"].push_back(record);
    }
    require(ordinal==10,"all accepted/trial/revert/retry operations retained");
    return out;
}
} // namespace NativeGapBatch::AirHistoryDetail
namespace NativeGapBatch {
nlohmann::json run_air_history_batch(nlohmann::json const &input) {
    PurchasedAirDetail::require(input.at("schema")=="src06-air-history-original-core-input.v1","history schema");
    nlohmann::json out{{"schema","src06-air-history-original-core-output.v1"},{"cases",nlohmann::json::array()}};
    for(auto const &item:input.at("cases"))out["cases"].push_back(AirHistoryDetail::run_case(item));
    return out;
}
} // namespace NativeGapBatch
'''

def main():
 assert not O.exists();O.mkdir()
 p1_path=D/'purchased-air-native-TU-draft-Audit-02/draft.json';p1=read(p1_path)
 binding=read(D/'original-core-gap-batch-type-binding-draft-Audit-03/draft.json');prefix_ref=binding['files'][0]['proposed'];prefix=checked(prefix_ref).read_bytes()
 older_path=D/'controlled-air-native-held-Outer-21/manifest.json';older=read(older_path)
 fields=older['air_scalar_fields'];histories=older['air_history_arrays'];assert len(fields)==67 and len(histories)==6
 source=TEMPLATE.replace('@SCALARS@','\n'.join('    out["'+key+'"]=number(a.'+key+');' for key in fields)).replace('@HISTORIES@','\n'.join('    out["'+key+'"]=json::array();for(double value:a.'+key+')out["'+key+'"].push_back(number(value));' for key in histories))
 cpp=O/'air_history_fragment.cpp';cpp.write_text(source,encoding='utf-8',newline='\n')
 combined=O/'purchased_air_and_air_history_batch.cpp';combined.write_bytes(prefix+cpp.read_bytes());assert combined.read_bytes()[:len(prefix)]==prefix
 old=prefix.decode('utf-8');new=combined.read_text(encoding='utf-8')
 diffs={}
 for label,a,b in [('forward',old,new),('inverse',new,old)]:
  target=O/('history.'+label+'.diff');target.write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='acceptedP1',tofile='futureP1history')),encoding='utf-8',newline='\n');diffs[label]=ref(target)
 primary=read(checked(p1['named_inputs']))
 def inputs(t,zt,av,wavg,wtemp):return {k:bits(v) for k,v in dict(MAT=t,ZT=zt,ZTAV=av,airHumRatAvg=wavg,airHumRatTemp=wtemp,pressure=101325.0).items()}
 sequence=[('accepted1.zone','push_zone',inputs(20.0,21.0,20.5,0.008,0.0075)),('accepted1.system','push_system',{}),
  ('trial2.zone','push_zone',inputs(25.0,26.0,25.5,0.012,0.0115)),('trial2.revert','revert_zone',{}),
  ('retry2.zone','push_zone',inputs(22.0,23.0,22.5,0.009,0.0085)),('retry2.system','push_system',{}),
  ('accepted3.zone','push_zone',inputs(18.0,19.0,18.5,0.006,0.0055)),('accepted3.system','push_system',{}),
  ('accepted4.zone','push_zone',inputs(24.0,25.0,24.5,0.010,0.0095)),('accepted4.system','push_system',{})]
 cases=[]
 for factory in primary['factories']:
  cases.append(dict(name='retained_history_'+factory['name'],origin=dict(kind='named_original_core_full_method_history_unit',actual_P1_factory=factory['origin'],qualification='External air/pressure primary inputs only; true class constructor histories are retained across every call; trial/revert/retry is a unit protocol, not complete HVAC controller acceptance.'),factory=copy.deepcopy(factory),steps=[dict(name=name,operation=op,inputs=values) for name,op,values in sequence]))
 named=save(O/'named-inputs.json',dict(schema='src06-air-history-original-core-input.v1',cases=cases))
 authority_specs={
  'src/EnergyPlus/ZoneTempPredictorCorrector.cc':[(4167,4431)],
  'src/EnergyPlus/ZoneTempPredictorCorrector.hh':[(102,253)],
  'src/EnergyPlus/HeatBalanceAirManager.cc':[(4246,4492)],
  'src/EnergyPlus/HeatBalanceAirManager.hh':[(69,99)],
  'src/EnergyPlus/DataRoomAirModel.hh':[(55,90),(168,180),(495,515)],
  'src/EnergyPlus/Psychrometrics.hh':[(1475,1515)],
  'src/EnergyPlus/DataHeatBalance.hh':[(107,126)],
 }
 authorities=[]
 for path,ranges in authority_specs.items():
  p=N/path;b=p.read_bytes();assert b==subprocess.check_output(['git','-C',str(N),'show',PIN+':'+path]);lines=b.splitlines(keepends=True);ext=[]
  for first,last in ranges:
   target=O/(path.replace('/','__')+f'.{first}-{last}.txt');target.write_bytes(b''.join(lines[first-1:last]));ext.append(dict(first=first,last=last,source=ref(target)))
  authorities.append(dict(Native_path=path,pinned_Git=PIN,whole=ref(p),extents=ext))
 manifest=dict(schema='src06-original-core-air-history-gap-draft.v1',status='FROZEN_PRIVATE_FUTURE_CPP_NO_COMPILE_OR_RUN',prepared_at_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
  accepted_P1_prefix=prefix_ref,P1_full_caller_draft=ref(p1_path),P1_independent_peer=ref(D/'Peer-purchased-air-Native-caller-review-P1-02/review.json'),
  exact_observer_member_list_authority=ref(older_path),appended_fragment=ref(cpp),proposed_combined_TU=ref(combined),append_only_diffs=diffs,
  original_prefix_recovery_exact=True,prefix_bytes=len(prefix),named_inputs=named,Native_authorities=authorities,
  Source_context=ref(R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/history.rs'),
  exports='nlohmann::json NativeGapBatch::run_air_history_batch(nlohmann::json const&)',future_selected_group='air_history',
  four_actual_raw_factory_modes=True,persistent_lifetimes=4,full_method_calls_per_lifetime=10,total_full_history_calls=40,
  operation_counts_per_lifetime=dict(push_zone=5,push_system=4,revert_zone=1),actual_RoomAir_getter_calls=4,
  consumed_readset=['Real P1 GetZoneData count/defaultSpace/zoneHeatBalance class allocation and physical Nodes; no guessed ordinals.',
   'Real RoomAirModel parameter getter allocates/counts/names/class defaults and EIO; checks actual Mixing/ThirdOrder/doSpace=false before original history calls. No fake readiness or manual model array.',
   'PushZone consumes named ZTAV/ZT/Wavg/Wtemp and retained XMAT/WPrevZoneTS, original PsyRH consumes real pressure/current humidity; full core updates XMPT/WTimeMinusP/airRelHum in order.',
   'PushSystem consumes named MAT and previously produced airHumRat plus retained DSXMAT/DSWPrevZoneTS. Revert shifts only original indices0..2; no last-cell or output reset.',
   'All67 initialized class real fields, six4element histories, initialized hmThermalMassMultErrIndex and true model/zone flags/counts/pointers plus same P1 Node/manager/context/diagnostic observations before and after every call. No private Psy cache state observed.'],
  pending=['Independent NEW history fragment/readset peer and Root review; actual main/header/helper/complete-compiler integration are not authored here.',
   'Root-only future original-core build/run/module gate, then lossless actual output fixture and Source history same-owner replay.',
   'Zone multiplier2 full Predict/Correct branch remains separate; this history unit does not claim multiplier numerical coverage.'],
  new_formulas_expected_answers_history_state_reset_or_FP_changes=False,Native_Cargo_engine_or_canonical_execution=False,author_Source=ref(Path(__file__)))
 draft=save(O/'draft.json',manifest);print(json.dumps(dict(draft=draft,fragment=ref(cpp),combined=ref(combined),named_inputs=named)))
if __name__=='__main__':main()


// Future gap-only air-history caller. Accepted P1 prefix remains byte-identical.
#include <EnergyPlus/HeatBalanceAirManager.hh>
#include <EnergyPlus/DataRoomAirModel.hh>

namespace NativeGapBatch::AirHistoryDetail {
using json=nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
using PurchasedAirDetail::require;
using PurchasedAirDetail::number;
using PurchasedAirDetail::pointer;
using PurchasedAirDetail::real;

json air(ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData const &a) {
    json out{{"address",pointer(&a)},{"hmThermalMassMultErrIndex",a.hmThermalMassMultErrIndex}};
    out["MAT"]=number(a.MAT);
    out["MRT"]=number(a.MRT);
    out["ZTAV"]=number(a.ZTAV);
    out["ZT"]=number(a.ZT);
    out["ZTAVComf"]=number(a.ZTAVComf);
    out["XMPT"]=number(a.XMPT);
    out["TMX"]=number(a.TMX);
    out["TM2"]=number(a.TM2);
    out["T1"]=number(a.T1);
    out["airHumRat"]=number(a.airHumRat);
    out["airHumRatAvg"]=number(a.airHumRatAvg);
    out["airHumRatTemp"]=number(a.airHumRatTemp);
    out["airHumRatAvgComf"]=number(a.airHumRatAvgComf);
    out["WTimeMinusP"]=number(a.WTimeMinusP);
    out["WMX"]=number(a.WMX);
    out["WM2"]=number(a.WM2);
    out["W1"]=number(a.W1);
    out["SumIntGain"]=number(a.SumIntGain);
    out["SumHA"]=number(a.SumHA);
    out["SumHATsurf"]=number(a.SumHATsurf);
    out["SumHATref"]=number(a.SumHATref);
    out["SumMCp"]=number(a.SumMCp);
    out["SumMCpT"]=number(a.SumMCpT);
    out["SumSysMCp"]=number(a.SumSysMCp);
    out["SumSysMCpT"]=number(a.SumSysMCpT);
    out["SumIntGainExceptPeople"]=number(a.SumIntGainExceptPeople);
    out["SumHmAW"]=number(a.SumHmAW);
    out["SumHmARa"]=number(a.SumHmARa);
    out["SumHmARaW"]=number(a.SumHmARaW);
    out["SumHmARaZ"]=number(a.SumHmARaZ);
    out["TempDepCoef"]=number(a.TempDepCoef);
    out["TempIndCoef"]=number(a.TempIndCoef);
    out["TempHistoryTerm"]=number(a.TempHistoryTerm);
    out["MCPI"]=number(a.MCPI);
    out["MCPTI"]=number(a.MCPTI);
    out["MCPV"]=number(a.MCPV);
    out["MCPTV"]=number(a.MCPTV);
    out["MCPM"]=number(a.MCPM);
    out["MCPTM"]=number(a.MCPTM);
    out["MCPE"]=number(a.MCPE);
    out["EAMFL"]=number(a.EAMFL);
    out["EAMFLxHumRat"]=number(a.EAMFLxHumRat);
    out["MCPTE"]=number(a.MCPTE);
    out["MCPC"]=number(a.MCPC);
    out["CTMFL"]=number(a.CTMFL);
    out["MCPTC"]=number(a.MCPTC);
    out["ThermChimAMFL"]=number(a.ThermChimAMFL);
    out["MCPTThermChim"]=number(a.MCPTThermChim);
    out["MCPThermChim"]=number(a.MCPThermChim);
    out["latentGain"]=number(a.latentGain);
    out["latentGainExceptPeople"]=number(a.latentGainExceptPeople);
    out["OAMFL"]=number(a.OAMFL);
    out["VAMFL"]=number(a.VAMFL);
    out["NonAirSystemResponse"]=number(a.NonAirSystemResponse);
    out["SysDepZoneLoads"]=number(a.SysDepZoneLoads);
    out["SysDepZoneLoadsLagged"]=number(a.SysDepZoneLoadsLagged);
    out["MDotCPOA"]=number(a.MDotCPOA);
    out["MDotOA"]=number(a.MDotOA);
    out["MixingMAT"]=number(a.MixingMAT);
    out["MixingHumRat"]=number(a.MixingHumRat);
    out["MixingMassFlowZone"]=number(a.MixingMassFlowZone);
    out["MixingMassFlowXHumRat"]=number(a.MixingMassFlowXHumRat);
    out["setPointLast"]=number(a.setPointLast);
    out["tempIndLoad"]=number(a.tempIndLoad);
    out["tempDepLoad"]=number(a.tempDepLoad);
    out["airRelHum"]=number(a.airRelHum);
    out["AirPowerCap"]=number(a.AirPowerCap);
    out["XMAT"]=json::array();for(double value:a.XMAT)out["XMAT"].push_back(number(value));
    out["DSXMAT"]=json::array();for(double value:a.DSXMAT)out["DSXMAT"].push_back(number(value));
    out["WPrevZoneTS"]=json::array();for(double value:a.WPrevZoneTS)out["WPrevZoneTS"].push_back(number(value));
    out["DSWPrevZoneTS"]=json::array();for(double value:a.DSWPrevZoneTS)out["DSWPrevZoneTS"].push_back(number(value));
    out["ZTM"]=json::array();for(double value:a.ZTM)out["ZTM"].push_back(number(value));
    out["WPrevZoneTSTemp"]=json::array();for(double value:a.WPrevZoneTSTemp)out["WPrevZoneTSTemp"].push_back(number(value));
    return out;
}

json state(PurchasedAirDetail::Factory &factory) {
    auto &s=*factory.state;
    auto const &zones=s.dataZoneTempPredictorCorrector->zoneHeatBalance;
    auto const &spaces=s.dataZoneTempPredictorCorrector->spaceHeatBalance;
    auto const &models=s.dataRoomAir->AirModel;
    json zone_rows=PurchasedAirDetail::shape(zones);zone_rows["items"]=json::array();
    for(std::size_t i=1;i<=zones.size();++i)zone_rows["items"].push_back(air(zones(i)));
    json space_rows=PurchasedAirDetail::shape(spaces);space_rows["items"]=json::array();
    for(std::size_t i=1;i<=spaces.size();++i)space_rows["items"].push_back(air(spaces(i)));
    json model_rows=PurchasedAirDetail::shape(models);model_rows["items"]=json::array();
    for(std::size_t i=1;i<=models.size();++i){auto const &m=models(i);model_rows["items"].push_back(json{
        {"address",pointer(&m)},{"Name",m.Name},{"ZoneName",m.ZoneName},{"ZonePtr",m.ZonePtr},
        {"AirModel",static_cast<int>(m.AirModel)},{"TempCoupleScheme",static_cast<int>(m.TempCoupleScheme)},
        {"SimAirModel",m.SimAirModel}});}
    json zone_metadata=json::array();
    for(int i=1;i<=s.dataGlobal->NumOfZones;++i){auto const &z=s.dataHeatBal->Zone(i);zone_metadata.push_back(json{
        {"address",pointer(&z)},{"ordinal",i},{"Name",z.Name},{"Multiplier",z.Multiplier},{"ListMultiplier",z.ListMultiplier},
        {"spaceIndexes",z.spaceIndexes}});}
    return json{{"P1_owners",PurchasedAirDetail::snapshot(factory)},
        {"zoneHeatBalance",zone_rows},{"spaceHeatBalance",space_rows},{"AirModel",model_rows},
        {"anyNonMixingRoomAirModel",s.dataRoomAir->anyNonMixingRoomAirModel},
        {"GetAirModelData",s.dataRoomAir->GetAirModelData},
        {"doSpaceHeatBalance",s.dataHeatBal->doSpaceHeatBalance},
        {"doSpaceHeatBalanceSimulation",s.dataHeatBal->doSpaceHeatBalanceSimulation},
        {"doSpaceHeatBalanceSizing",s.dataHeatBal->doSpaceHeatBalanceSizing},
        {"ZoneAirSolutionAlgo",static_cast<int>(s.dataHeatBal->ZoneAirSolutionAlgo)},
        {"NumOfZones",s.dataGlobal->NumOfZones},{"Zone_metadata",zone_metadata},
        {"RoomAir_owner_address",pointer(s.dataRoomAir.get())},
        {"predictor_owner_address",pointer(s.dataZoneTempPredictorCorrector.get())}};
}

void apply_inputs(PurchasedAirDetail::Factory &factory,json const &input) {
    auto &s=*factory.state;
    require(input.is_object(),"history primary caller input object");
    constexpr std::string_view allowed[]={"MAT","ZT","ZTAV","airHumRatAvg","airHumRatTemp","pressure"};
    for(auto it=input.begin();it!=input.end();++it){bool found=false;for(auto key:allowed)if(key==it.key())found=true;
        require(found,"history accepts only external air/pressure inputs, never histories or computed answers");}
    auto &a=s.dataZoneTempPredictorCorrector->zoneHeatBalance(factory.zone);
    if(input.contains("MAT"))a.MAT=real(input.at("MAT"));
    if(input.contains("ZT"))a.ZT=real(input.at("ZT"));
    if(input.contains("ZTAV"))a.ZTAV=real(input.at("ZTAV"));
    if(input.contains("airHumRatAvg"))a.airHumRatAvg=real(input.at("airHumRatAvg"));
    if(input.contains("airHumRatTemp"))a.airHumRatTemp=real(input.at("airHumRatTemp"));
    if(input.contains("pressure"))s.dataEnvrn->OutBaroPress=real(input.at("pressure"));
}

json run_case(json const &input) {
    auto factory=PurchasedAirDetail::make_factory(input.at("factory"));auto &s=*factory.state;
    require(!s.dataRoomAir->AirModel.allocated(),"real P1 factory precedes RoomAir getter");
    json out{{"name",input.at("name")},{"origin",input.at("origin")},
        {"before_real_RoomAir_getter",state(factory)},{"steps",json::array()}};
    bool errors=false;
    HeatBalanceAirManager::GetRoomAirModelParameters(s,errors);
    require(!errors,"actual RoomAir input getter succeeds");
    require(s.dataRoomAir->AirModel.allocated() && static_cast<int>(s.dataRoomAir->AirModel.size())==s.dataGlobal->NumOfZones,"real getter model allocation");
    require(!s.dataRoomAir->anyNonMixingRoomAirModel && !s.dataHeatBal->doSpaceHeatBalance,"actual finite mixed zone branch");
    require(s.dataHeatBal->ZoneAirSolutionAlgo==DataHeatBalance::SolutionAlgo::ThirdOrder,"actual finite ThirdOrder branch");
    for(auto const &m:s.dataRoomAir->AirModel)require(m.AirModel==RoomAir::RoomAirModel::Mixing,"actual getter mixing row");
    out["after_real_RoomAir_getter"]=state(factory);
    std::size_t ordinal=0;
    for(auto const &step:input.at("steps")){
        AirHistoryDetail::apply_inputs(factory,step.at("inputs"));auto operation=step.at("operation").get<std::string>();
        json record{{"ordinal",++ordinal},{"name",step.at("name")},{"operation",operation},
            {"named_inputs",step.at("inputs")},{"entry",state(factory)}};
        if(operation=="push_zone")ZoneTempPredictorCorrector::PushZoneTimestepHistories(s);
        else if(operation=="push_system")ZoneTempPredictorCorrector::PushSystemTimestepHistories(s);
        else if(operation=="revert_zone")ZoneTempPredictorCorrector::RevertZoneTimestepHistories(s);
        else throw std::runtime_error("unknown original full history operation");
        record["exit"]=state(factory);out["steps"].push_back(record);
    }
    require(ordinal==10,"all accepted/trial/revert/retry operations retained");
    return out;
}
} // namespace NativeGapBatch::AirHistoryDetail
namespace NativeGapBatch {
nlohmann::json run_air_history_batch(nlohmann::json const &input) {
    PurchasedAirDetail::require(input.at("schema")=="src06-air-history-original-core-input.v1","history schema");
    nlohmann::json out{{"schema","src06-air-history-original-core-output.v1"},{"cases",nlohmann::json::array()}};
    for(auto const &item:input.at("cases"))out["cases"].push_back(AirHistoryDetail::run_case(item));
    return out;
}
} // namespace NativeGapBatch

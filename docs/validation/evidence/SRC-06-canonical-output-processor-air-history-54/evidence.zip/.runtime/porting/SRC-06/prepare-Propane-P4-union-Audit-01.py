"""Private literal union plan; no expected fixture/compiler/Cargo/main writes."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Propane-P4-coherent-draft-Audit-01'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def encode(j):return (json.dumps(j,indent=2)+'\n').encode()
def check(v):
 p=R/v['path'];assert ref(p)==v;return p
assert not O.exists();O.mkdir()
paths=[D/'source-OtherEquipment-Propane-OP-draft-Outer-05/draft.json',D/'source-output-processor-gap-scaffold-Audit-01/draft.json']
prod,p4=[json.loads(p.read_bytes()) for p in paths];A={v['canonical_path']:v for v in prod['files']};B={v['canonical_path']:v for v in p4['files']}
head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True).stdout.decode().strip();assert head=='58c77de0c95ebd20470c5857ef861d9a76f1251b'
prior_ref=p4['prior_complete_compiler_Source_plan'];prior=json.loads(check(prior_ref).read_bytes());rows={v['path']:v for v in prior['entries']}
for n,v in rows.items():
 b=(R/n).read_bytes();assert len(b)==v['final_bytes'] and hashlib.sha256(b).hexdigest()==v['final_sha256'];assert check(v['source']).read_bytes()==b
tree=ast.parse((D/'freeze-Source-P4-scaffold-Audit-01.py').read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<literal-apply-only>','exec'),ns)
CFG=b'#[cfg(all(test, feature = "native-controlled-air-cohort"))]'
files=[];joins=[]
for n in sorted(A.keys()|B.keys()):
 v=A.get(n) or B[n];before=check(v['before']).read_bytes() if v['before'] else b''
 if before:
  assert (R/n).read_bytes()==before
  assert subprocess.run(['git','show',head+':'+n],capture_output=True,check=True).stdout==before
 else:assert not (R/n).exists()
 if n in A and n in B:
  assert check(B[n]['before']).read_bytes()==before
  pa=check(A[n]['proposed']).read_bytes();pb=check(B[n]['proposed']).read_bytes()
  if n.endswith('/source_output_registration.rs'):
   assert pb.startswith(before);extra=pb[len(before):];assert CFG in extra
   merged=pa+extra;assert merged[:-len(extra)]==pa
  else:
   if n.endswith('/bound_real.rs'):
    token=b'pub(crate) enum SourceRealOutputTarget {\n'
    extra=b'    '+CFG+b'\n    CohortReal { slot: u8 },\n'
   elif n.endswith('/remaining.rs'):
    token=b'        use SourceRealOutputTarget as T;\n        match target {\n'
    extra=b'            '+CFG+b'\n            T::CohortReal { .. } => Err(OrdinaryRadiationUnavailable::StorageDomain.into()),\n'
   else:
    token=b'        match target {\n'
    variant=b'T' if n.endswith('/facility_target.rs') else b'SourceRealOutputTarget'
    extra=b'            '+CFG+b'\n            '+variant+b'::CohortReal { .. } => Err(super::OrdinaryRadiationUnavailable::StorageDomain.into()),\n'
   assert before.count(token)==1 and pa.count(token)==1
   assert before.replace(token,token+extra,1)==pb
   merged=pa.replace(token,token+extra,1);assert merged.replace(extra,b'',1)==pa
  joins.append(dict(canonical_path=n,common_before=v['before'],production_proposed=A[n]['proposed'],cfg_proposed=B[n]['proposed'],cfg_added_literal=extra.decode(),remove_only_cfg_exact_production=True,production_inverse_then_same_cfg_exact_P4=True))
 else:merged=check(v['proposed']).read_bytes()
 proposed=put(O/'proposed'/n,merged);before_ref=put(O/'before'/n,before) if before else None;diffs={}
 for tag,a,b in [('forward',before,merged),('inverse',merged,before)]:
  diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile=n,tofile=n)).encode();assert ns['apply'](a,diff)==b
  diffs[tag]=put(O/'diffs'/(n.replace('/','__')+'.'+tag+'.diff'),diff)
 syntax=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=merged,capture_output=True);assert syntax.returncode==0,syntax.stderr
 files.append(dict(canonical_path=n,before_absent=not bool(before),before=before_ref,proposed=proposed,diffs=diffs,Source_only_parse=dict(exit_code=0,qualification='Fresh stdin syntax-only parse; existing proposal formatting is preserved. Not contextual compilation.')))
 rows[n]=dict(path=n,final_sha256=proposed['sha256'],final_bytes=proposed['bytes'],source=proposed,origin='private literal Propane production + P4 cfg union')
assert len(files)==20 and len(joins)==6 and sum(v['before_absent'] for v in files)==3
plan=dict(schema='src06-private-prospective-Propane-P4-compiler-plan.v1',base_HEAD=head,prior_complete_compiler_Source_plan=prior_ref,entries=[rows[n] for n in sorted(rows)],compiler_inputs=len(rows),Rust_sources=sum(n.endswith('.rs') for n in rows),selected=20,existing=17,new=3,expected_fixture_absent=True,contextual_compilation_and_final_integration_pending=True)
assert plan['compiler_inputs']==4537 and plan['Rust_sources']==4524
plan_ref=put(O/'complete-proposed-compiler-Source-plan.json',encode(plan));join_ref=put(O/'literal-six-file-union-proof.json',encode(joins))
result=dict(schema='src06-private-coherent-Propane-P4-union-planning.v1',status='SOURCE_ONLY_WAIT_P4_SOURCE_PEER_ACTUAL_NATIVE_FIXTURE_AND_ROOT_INTEGRATION',base_HEAD=head,files=files,original_production_draft=ref(paths[0]),independent_production_peer=ref(D/'Peer-OtherEquipment-Propane-OP-review-Audit-05/review.json'),original_P4_scaffold=ref(paths[1]),P4_independent_Source_peer='pending',literal_shared_file_union=join_ref,prior_complete_compiler_Source_plan=prior_ref,complete_proposed_compiler_Source_plan=plan_ref,full4534_prior_archive_live_readback_exact=True,selected_existing17_Git_and_live_exact=True,whole_unselected_parent_preserved=True,literal_applications=40,fresh_syntax_parses=20,new_expected_fixture_test_target_feature_dependency_or_FP_control=False,qualification='Twenty source union is mechanical composition only. Production None/Propane scope and P4 observer exclusions are inherited unchanged; no P4 expected output exists and no compilation/PASS is inferred. Each shared source recovers the complete accepted production proposal after removing only the original cfg addition; base recovery plus the same cfg addition recovers original P4 proposal.',author_Source=ref(Path(__file__)))
print(json.dumps(put(O/'draft.json',encode(result))))

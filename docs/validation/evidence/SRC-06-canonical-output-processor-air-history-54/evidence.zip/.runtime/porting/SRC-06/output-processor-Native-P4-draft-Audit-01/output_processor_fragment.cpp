
// P4 is appended after the complete accepted P1 TU, without changing its bytes.
// Only original full OutputProcessor methods produce report/meter state.
#include <EnergyPlus/ResultsFramework.hh>
#include <EnergyPlus/DataOutputs.hh>
#include <vector>

namespace NativeGapBatch::OutputProcessorDetail {
using json = nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
namespace OP = EnergyPlus::OutputProcessor;
using PurchasedAirDetail::number;
using PurchasedAirDetail::pointer;
using PurchasedAirDetail::real;
using PurchasedAirDetail::require;

struct Values {
    Real64 zone_average = 0.0;
    Real64 system_average = 0.0;
    Real64 system_energy = 0.0;
    int system_integer = 0;
    int zone_sum_integer = 0;
};

// Public ResultsFramework JSON is an actual read-only observation. Convert
// every binary64 leaf to raw bits; retain true integral/string/null types.
json raw_json(json const &value)
{
    if (value.is_number_float()) return number(value.get<double>());
    if (value.is_array()) {
        json out = json::array();
        for (auto const &item : value) out.push_back(raw_json(item));
        return out;
    }
    if (value.is_object()) {
        json out = json::object();
        for (auto it = value.begin(); it != value.end(); ++it) out[it.key()] = raw_json(it.value());
        return out;
    }
    return value;
}

json period(OP::MeterPeriod const &p)
{
    return json{{"Value", number(p.Value)}, {"MaxVal", number(p.MaxVal)}, {"MaxValDate", p.MaxValDate},
                {"MinVal", number(p.MinVal)}, {"MinValDate", p.MinValDate}, {"Rpt", p.Rpt}, {"RptFO", p.RptFO},
                {"RptNum", p.RptNum}, {"accRpt", p.accRpt}, {"accRptFO", p.accRptFO}, {"accRptNum", p.accRptNum}};
}

json frame(ResultsFramework::DataFrame const &f)
{
    require(!f.beginningOfInterval, "P4 normal frame format: beginningOfInterval=false");
    return json{{"address", pointer(&f)}, {"enabled", f.dataFrameEnabled()}, {"scanned", f.variablesScanned()},
                {"iso8601", f.iso8601}, {"beginningOfInterval", f.beginningOfInterval}, {"json", raw_json(f.getJSON())}};
}

json frames(EnergyPlusData const &s)
{
    auto const &r = *s.dataResultsFramework->resultsFramework;
    json out{{"owner_address", pointer(&r)}, {"timeSeriesEnabled", r.timeSeriesEnabled()},
             {"timeSeriesAndTabularEnabled", r.timeSeriesAndTabularEnabled()}, {"JSONEnabled", r.JSONEnabled()},
             {"CBOREnabled", r.CBOREnabled()}, {"MsgPackEnabled", r.MsgPackEnabled()}, {"RDD", r.RDD}, {"MDD", r.MDD},
             {"detailed", json::array()}, {"frequency", json::array()}, {"meters", json::array()}};
    require(!r.timeSeriesEnabled(), "P4 disabled variable-frame domain must come from real input/defaults");
    for (auto const &f : r.detailedTSData) out["detailed"].push_back(frame(f));
    for (auto const &f : r.freqTSData) out["frequency"].push_back(frame(f));
    for (auto const &f : r.Meters) {
        // MeterDataFrame owns a separate meterMap. Observe its real derived
        // whole JSON rather than interpreting the empty base variableMap.
        require(!f.beginningOfInterval, "P4 normal meter-frame format");
        out["meters"].push_back(json{{"address", pointer(&f)}, {"enabled", f.dataFrameEnabled()},
            {"scanned", f.variablesScanned()}, {"iso8601", f.iso8601}, {"beginningOfInterval", f.beginningOfInterval},
            {"whole", raw_json(f.getJSON(false))}, {"without_meter_file_only", raw_json(f.getJSON(true))}});
    }
    return out;
}

json sample_values(Values const &v)
{
    return json{{"zone_average", number(v.zone_average)}, {"system_average", number(v.system_average)},
                {"system_energy", number(v.system_energy)}, {"system_integer", v.system_integer}, {"zone_sum_integer", v.zone_sum_integer},
                {"addresses", {{"zone_average", pointer(&v.zone_average)}, {"system_average", pointer(&v.system_average)},
                               {"system_energy", pointer(&v.system_energy)}, {"system_integer", pointer(&v.system_integer)},
                               {"zone_sum_integer", pointer(&v.zone_sum_integer)}}}};
}

json outvar(OP::OutVar const &v, Values const &values)
{
    json out{{"address", pointer(&v)}, {"ddVarNum", v.ddVarNum}, {"varType", static_cast<int>(v.varType)},
        {"timeStepType", static_cast<int>(v.timeStepType)}, {"storeType", static_cast<int>(v.storeType)},
        {"Value", number(v.Value)}, {"TSValue", number(v.TSValue)}, {"EITSValue", number(v.EITSValue)},
        {"StoreValue", number(v.StoreValue)}, {"NumStored", number(v.NumStored)}, {"Stored", v.Stored},
        {"Report", v.Report}, {"tsStored", v.tsStored}, {"thisTSStored", v.thisTSStored}, {"thisTSCount", v.thisTSCount},
        {"freq", static_cast<int>(v.freq)}, {"MaxValue", number(v.MaxValue)}, {"MinValue", number(v.MinValue)},
        {"maxValueDate", v.maxValueDate}, {"minValueDate", v.minValueDate}, {"ReportID", v.ReportID},
        {"sched", pointer(v.sched)}, {"ZoneMult", v.ZoneMult}, {"ZoneListMult", v.ZoneListMult},
        {"keyColonName", v.keyColonName}, {"keyColonNameUC", v.keyColonNameUC}, {"name", v.name}, {"nameUC", v.nameUC},
        {"key", v.key}, {"keyUC", v.keyUC}, {"units", static_cast<int>(v.units)}, {"unitNameCustomEMS", v.unitNameCustomEMS},
        {"indexGroup", v.indexGroup}, {"indexGroupKey", v.indexGroupKey}, {"meterNums", v.meterNums}};
    require(v.sched == nullptr, "P4 unscheduled requests are real input facts");
    if (auto const *r = dynamic_cast<OP::OutVarReal const *>(&v)) {
        require(r->Which != nullptr, "actual real Which");
        out["Which"] = pointer(r->Which);
        out["live_value"] = number(*r->Which);
        if (r->Which == &values.zone_average) out["same_named_lvalue"] = "zone_average";
        else if (r->Which == &values.system_average) out["same_named_lvalue"] = "system_average";
        else if (r->Which == &values.system_energy) out["same_named_lvalue"] = "system_energy";
        else throw std::runtime_error("unexpected genuine real Which");
    } else if (auto const *i = dynamic_cast<OP::OutVarInt const *>(&v)) {
        require(i->Which == &values.system_integer || i->Which == &values.zone_sum_integer, "actual integer Which identity");
        out["Which"] = pointer(i->Which);
        out["live_value"] = *i->Which;
        out["same_named_lvalue"] = i->Which == &values.system_integer ? "system_integer" : "zone_sum_integer";
    } else throw std::runtime_error("unexpected actual OutVar discriminator");
    return out;
}

json output_state(EnergyPlusData const &s, Values const &values)
{
    auto const &o = *s.dataOutputProcessor;
    json out{{"owner_address", pointer(&o)}, {"NumVariablesForOutput", o.NumVariablesForOutput},
        {"MaxVariablesForOutput", o.MaxVariablesForOutput}, {"NumTotalRVariable", o.NumTotalRVariable},
        {"NumOfRVariable", o.NumOfRVariable}, {"NumOfRVariable_Setup", o.NumOfRVariable_Setup},
        {"NumOfRVariable_Sum", o.NumOfRVariable_Sum}, {"NumOfRVariable_Meter", o.NumOfRVariable_Meter},
        {"NumOfIVariable", o.NumOfIVariable}, {"NumOfIVariable_Setup", o.NumOfIVariable_Setup},
        {"NumTotalIVariable", o.NumTotalIVariable}, {"NumOfIVariable_Sum", o.NumOfIVariable_Sum},
        {"OutputInitialized", o.OutputInitialized}, {"ProduceReportVDD", static_cast<int>(o.ProduceReportVDD)},
        {"NumHoursInMonth", o.NumHoursInMonth}, {"NumHoursInSim", o.NumHoursInSim},
        {"freqStampReportNums", o.freqStampReportNums}, {"freqTrackingVariables", o.freqTrackingVariables},
        {"TimeStepZoneSec", number(o.TimeStepZoneSec)}, {"ErrorsLogged", o.ErrorsLogged}, {"isFinalYear", o.isFinalYear},
        {"GetOutputInputFlag", o.GetOutputInputFlag}, {"minimumReportFreq", static_cast<int>(o.minimumReportFreq)},
        {"ReportNumberCounter", o.ReportNumberCounter}, {"LHourP", o.LHourP}, {"LStartMin", number(o.LStartMin)},
        {"LEndMin", number(o.LEndMin)}, {"GetMeterIndexFirstCall", o.GetMeterIndexFirstCall}, {"InitFlag", o.InitFlag},
        {"Rept", o.Rept}, {"OpaqSurfWarned", o.OpaqSurfWarned}, {"MaxNumSubcategories", o.MaxNumSubcategories},
        {"maxNumEndUseSpaceTypes", o.maxNumEndUseSpaceTypes}, {"ddOutVarMap", o.ddOutVarMap}, {"meterMap", o.meterMap},
        {"apiVarRequests_size", o.apiVarRequests.size()}, {"time_values", json::array()}, {"outVars", json::array()},
        {"ddOutVars", json::array()}, {"reqVars", json::array()}, {"meters", json::array()}, {"meterValues", json::array()}};
    require(o.apiVarRequests.empty(), "P4 no positive API request producer");
    for (int i = 0; i < static_cast<int>(OP::TimeStepType::Num); ++i) {
        auto const &t = o.TimeValue[i];
        out["time_values"].push_back(json{{"address", pointer(&t)}, {"TimeStep", pointer(t.TimeStep)},
            {"value", t.TimeStep ? number(*t.TimeStep) : json(nullptr)}, {"CurMinute", number(t.CurMinute)},
            {"is_actual_zone_pointer", t.TimeStep == &s.dataGlobal->TimeStepZone},
            {"is_actual_system_pointer", t.TimeStep == &s.dataHVACGlobal->TimeStepSys}});
    }
    for (auto const *v : o.outVars) out["outVars"].push_back(outvar(*v, values));
    for (auto const *d : o.ddOutVars) out["ddOutVars"].push_back(json{{"address", pointer(d)}, {"name", d->name},
        {"timeStepType", static_cast<int>(d->timeStepType)}, {"storeType", static_cast<int>(d->storeType)},
        {"variableType", static_cast<int>(d->variableType)}, {"Next", d->Next}, {"ReportedOnDDFile", d->ReportedOnDDFile},
        {"units", static_cast<int>(d->units)}, {"unitNameCustomEMS", d->unitNameCustomEMS}, {"keyOutVarNums", d->keyOutVarNums}});
    for (auto const *r : o.reqVars) out["reqVars"].push_back(json{{"address", pointer(r)}, {"key", r->key}, {"name", r->name},
        {"freq", static_cast<int>(r->freq)}, {"sched", pointer(r->sched)}, {"Used", r->Used},
        {"is_simple_string", r->is_simple_string}, {"case_insensitive_pattern_present", bool(r->case_insensitive_pattern)}});
    for (auto const *m : o.meters) {
        require(m->type == OP::MeterType::Normal, "P4 only actual generated normal meters");
        json v{{"address", pointer(m)}, {"Name", m->Name}, {"type", static_cast<int>(m->type)},
            {"resource", static_cast<int>(m->resource)}, {"endUseCat", static_cast<int>(m->endUseCat)}, {"EndUseSub", m->EndUseSub},
            {"group", static_cast<int>(m->group)}, {"units", static_cast<int>(m->units)},
            {"RT_forIPUnits", static_cast<int>(m->RT_forIPUnits)}, {"CurTSValue", number(m->CurTSValue)},
            {"indexGroup", m->indexGroup}, {"dstMeterNums", m->dstMeterNums}, {"decMeterNum", m->decMeterNum},
            {"srcVarNums", m->srcVarNums}, {"srcMeterNums", m->srcMeterNums}, {"periods", json::array()},
            {"periodLastSM", period(m->periodLastSM)}, {"periodFinYrSM", period(m->periodFinYrSM)}};
        for (auto const &p : m->periods) v["periods"].push_back(period(p));
        out["meters"].push_back(v);
    }
    for (double v : o.meterValues) out["meterValues"].push_back(number(v));
    json enduse = PurchasedAirDetail::shape(o.EndUseCategory);
    enduse["items"] = json::array();
    for (std::size_t i = 1; i <= o.EndUseCategory.size(); ++i) {
        auto const &v = o.EndUseCategory(i);
        enduse["items"].push_back(json{{"Name", v.Name}, {"DisplayName", v.DisplayName},
            {"NumSubcategories", v.NumSubcategories}, {"SubcategoryName", PurchasedAirDetail::strings(v.SubcategoryName)},
            {"numSpaceTypes", v.numSpaceTypes}, {"spaceTypeName", PurchasedAirDetail::strings(v.spaceTypeName)}});
    }
    out["EndUseCategory"] = enduse;
    // o.stamp is an uninitialized legacy character buffer, never serialized.
    return out;
}

json context(EnergyPlusData const &s)
{
    auto const &g = *s.dataGlobal;
    auto const &h = *s.dataHVACGlobal;
    auto const &e = *s.dataEnvrn;
    json prescan = json::array();
    for (auto const &[name, keys] : s.dataOutput->OutputVariablesForSimulation) {
        json items = json::array();
        for (auto const &[key, v] : keys) items.push_back(json{{"map_key", key}, {"key", v.key}, {"variableName", v.variableName},
            {"is_simple_string", v.is_simple_string}, {"pattern_present", bool(v.pattern)},
            {"case_insensitive_pattern_present", bool(v.case_insensitive_pattern)}});
        prescan.push_back(json{{"map_name", name}, {"keys", items}});
    }
    return json{{"state_address", pointer(&s)}, {"global_address", pointer(&g)}, {"hvac_address", pointer(&h)},
        {"environment_address", pointer(&e)}, {"TimeStepZone", number(g.TimeStepZone)}, {"TimeStepSys", number(h.TimeStepSys)},
        {"TimeStepSysSec", number(h.TimeStepSysSec)}, {"MinutesInTimeStep", g.MinutesInTimeStep}, {"TimeStep", g.TimeStep},
        {"TimeStepsInHour", g.TimeStepsInHour}, {"HourOfDay", g.HourOfDay}, {"DayOfSim", g.DayOfSim},
        {"DayOfSimChr", g.DayOfSimChr}, {"CalendarYear", g.CalendarYear}, {"CalendarYearChr", g.CalendarYearChr},
        {"NumOfDayInEnvrn", g.NumOfDayInEnvrn}, {"WarmupFlag", g.WarmupFlag}, {"EndHourFlag", g.EndHourFlag},
        {"EndDayFlag", g.EndDayFlag}, {"EndEnvrnFlag", g.EndEnvrnFlag}, {"Month", e.Month}, {"DayOfMonth", e.DayOfMonth},
        {"DayOfWeek", e.DayOfWeek}, {"HolidayIndex", e.HolidayIndex}, {"DSTIndicator", e.DSTIndicator},
        {"EndMonthFlag", e.EndMonthFlag}, {"EndYearFlag", e.EndYearFlag}, {"StdOutputRecordCount", g.StdOutputRecordCount},
        {"StdMeterRecordCount", g.StdMeterRecordCount}, {"sqlite_present", bool(s.dataSQLiteProcedures->sqlite)},
        {"prescan_address", pointer(s.dataOutput.get())}, {"NumConsideredOutputVariables", s.dataOutput->NumConsideredOutputVariables},
        {"MaxConsideredOutputVariables", s.dataOutput->MaxConsideredOutputVariables}, {"prescan", prescan}};
}

json snapshot(PurchasedAirDetail::Factory &factory, Values const &values)
{
    auto &s = *factory.state;
    require(!s.dataSQLiteProcedures->sqlite, "P4 actual null SQLite constructor domain");
    return json{{"context", context(s)}, {"named_lvalues", sample_values(values)},
        {"output_processor", output_state(s, values)}, {"results_framework", frames(s)},
        {"streams", {{"eso", s.files.eso.get_output()}, {"mtr", s.files.mtr.get_output()},
                     {"eio", s.files.eio.get_output()}, {"mtd", s.files.mtd.get_output()}}},
        {"errors", PurchasedAirDetail::errors(s, *factory.error)}};
}

void apply_inputs(EnergyPlusData &s, Values &v, json const &p)
{
    require(p.is_object(), "P4 named caller-input object");
    constexpr std::string_view keys[] = {"zone_average", "system_average", "system_energy", "system_integer", "zone_sum_integer",
        "zone_hours", "system_hours", "system_seconds", "hour", "timestep", "day_of_sim", "calendar_year", "environment_days",
        "month", "day_of_month", "day_of_week", "holiday", "dst", "warmup", "end_hour", "end_day", "end_environment", "end_month", "end_year"};
    for (auto it = p.begin(); it != p.end(); ++it) {
        bool allowed = false;
        for (auto key : keys) if (it.key() == key) allowed = true;
        require(allowed, "P4 accepts only explicit caller/Which inputs, never report or meter answers");
    }
    auto &g = *s.dataGlobal;
    auto &h = *s.dataHVACGlobal;
    auto &e = *s.dataEnvrn;
    if (p.contains("zone_average")) v.zone_average = real(p.at("zone_average"));
    if (p.contains("system_average")) v.system_average = real(p.at("system_average"));
    if (p.contains("system_energy")) v.system_energy = real(p.at("system_energy"));
    if (p.contains("system_integer")) v.system_integer = p.at("system_integer").get<int>();
    if (p.contains("zone_sum_integer")) v.zone_sum_integer = p.at("zone_sum_integer").get<int>();
    if (p.contains("zone_hours")) g.TimeStepZone = real(p.at("zone_hours"));
    if (p.contains("system_hours")) h.TimeStepSys = real(p.at("system_hours"));
    if (p.contains("system_seconds")) h.TimeStepSysSec = real(p.at("system_seconds"));
    if (p.contains("hour")) g.HourOfDay = p.at("hour").get<int>();
    if (p.contains("timestep")) g.TimeStep = p.at("timestep").get<int>();
    if (p.contains("day_of_sim")) {
        g.DayOfSim = p.at("day_of_sim").get<int>();
        g.DayOfSimChr = std::to_string(g.DayOfSim);
    }
    if (p.contains("calendar_year")) {
        g.CalendarYear = p.at("calendar_year").get<int>();
        g.CalendarYearChr = std::to_string(g.CalendarYear);
    }
    if (p.contains("environment_days")) g.NumOfDayInEnvrn = p.at("environment_days").get<int>();
    if (p.contains("month")) e.Month = p.at("month").get<int>();
    if (p.contains("day_of_month")) e.DayOfMonth = p.at("day_of_month").get<int>();
    if (p.contains("day_of_week")) e.DayOfWeek = p.at("day_of_week").get<int>();
    if (p.contains("holiday")) e.HolidayIndex = p.at("holiday").get<int>();
    if (p.contains("dst")) e.DSTIndicator = p.at("dst").get<int>();
    if (p.contains("warmup")) g.WarmupFlag = p.at("warmup").get<bool>();
    if (p.contains("end_hour")) g.EndHourFlag = p.at("end_hour").get<bool>();
    if (p.contains("end_day")) g.EndDayFlag = p.at("end_day").get<bool>();
    if (p.contains("end_environment")) g.EndEnvrnFlag = p.at("end_environment").get<bool>();
    if (p.contains("end_month")) e.EndMonthFlag = p.at("end_month").get<bool>();
    if (p.contains("end_year")) e.EndYearFlag = p.at("end_year").get<bool>();
    require(g.MinutesInTimeStep > 0 && g.HourOfDay >= 1 && g.HourOfDay <= 24, "P4 actual reporting clock input bounds");
    require(e.Month >= 1 && e.Month <= 12 && e.DayOfMonth >= 1 && e.DayOfMonth <= 31, "P4 actual calendar input bounds");
    require(e.DayOfWeek >= 1 && e.DayOfWeek <= 7 && e.HolidayIndex >= 0 && e.HolidayIndex < 13, "P4 actual day-type bounds");
    require(g.TimeStepZone > 0.0 && h.TimeStepSys > 0.0, "P4 positive actual bound timestep values");
}

json run_case(json const &input)
{
    auto factory = PurchasedAirDetail::make_factory(input.at("factory"));
    auto values = std::make_unique<Values>();
    auto &s = *factory.state;
    auto &o = *s.dataOutputProcessor;
    require(o.outVars.empty() && o.ddOutVars.empty() && o.meters.empty(), "P4 real factory has no output registration producer yet");
    require(o.GetOutputInputFlag, "P4 real first request getter latch");
    require(o.TimeValue[(int)OP::TimeStepType::Zone].TimeStep == nullptr &&
            o.TimeValue[(int)OP::TimeStepType::System].TimeStep == nullptr, "P4 real unbound constructor timestep pointers");
    json out{{"name", input.at("name")}, {"origin", input.at("origin")}, {"initial", snapshot(factory, *values)},
             {"setup", json::array()}, {"steps", json::array()}};
    auto setup_call = [&](char const *name, auto &&call) {
        json event{{"operation", name}, {"entry", snapshot(factory, *values)}};
        call();
        event["exit"] = snapshot(factory, *values);
        out["setup"].push_back(event);
    };
    setup_call("SetupTimePointers.Zone", [&] { OP::SetupTimePointers(s, OP::TimeStepType::Zone, s.dataGlobal->TimeStepZone); });
    setup_call("SetupTimePointers.System", [&] { OP::SetupTimePointers(s, OP::TimeStepType::System, s.dataHVACGlobal->TimeStepSys); });
    setup_call("GetReportVariableInput", [&] { OP::GetReportVariableInput(s); });
    std::string const key = "P4 OWNER";
    setup_call("SetupOutputVariable.ZoneAverage", [&] {
        SetupOutputVariable(s, "P4 Zone Average", Constant::Units::C, values->zone_average,
                            OP::TimeStepType::Zone, OP::StoreType::Average, key);
    });
    setup_call("SetupOutputVariable.SystemAverage", [&] {
        SetupOutputVariable(s, "P4 System Average", Constant::Units::C, values->system_average,
                            OP::TimeStepType::System, OP::StoreType::Average, key);
    });
    setup_call("SetupOutputVariable.SystemEnergy", [&] {
        SetupOutputVariable(s, "P4 System Energy", Constant::Units::J, values->system_energy,
                            OP::TimeStepType::System, OP::StoreType::Sum, key, Constant::eResource::Electricity,
                            OP::Group::HVAC, OP::EndUseCat::Heating, "General", "", 2, 3);
    });
    setup_call("SetupOutputVariable.SystemInteger", [&] {
        SetupOutputVariable(s, "P4 System Integer", Constant::Units::None, values->system_integer,
                            OP::TimeStepType::System, OP::StoreType::Average, key);
    });
    setup_call("SetupOutputVariable.ZoneIntegerSum", [&] {
        SetupOutputVariable(s, "P4 Zone Sum Integer", Constant::Units::None, values->zone_sum_integer,
                            OP::TimeStepType::Zone, OP::StoreType::Sum, key);
    });
    setup_call("UpdateMeterReporting", [&] { UpdateMeterReporting(s); });
    require(o.outVars.size() == 35, "five genuine lvalues requested at all seven frequencies");
    require(!o.meters.empty() && o.meterValues.size() == o.meters.size(), "real metering setup and storage extent");
    std::size_t ordinal = 0;
    for (auto const &step : input.at("steps")) {
        apply_inputs(s, *values, step.at("inputs"));
        std::string operation = step.at("operation").get<std::string>();
        json record{{"ordinal", ++ordinal}, {"name", step.at("name")}, {"operation", operation},
                    {"named_inputs", step.at("inputs")}, {"entry", snapshot(factory, *values)}};
        if (operation == "system") UpdateDataandReport(s, OP::TimeStepType::System);
        else if (operation == "zone") UpdateDataandReport(s, OP::TimeStepType::Zone);
        else if (operation == "warmup_reset") OP::ResetAccumulationWhenWarmupComplete(s);
        else throw std::runtime_error("unknown complete P4 operation");
        record["exit"] = snapshot(factory, *values);
        out["steps"].push_back(record);
    }
    out["calls"] = ordinal;
    return out;
}
} // namespace NativeGapBatch::OutputProcessorDetail

namespace NativeGapBatch {
nlohmann::json run_output_processor_batch(nlohmann::json const &input)
{
    PurchasedAirDetail::require(input.at("schema") == "src06-output-processor-gap-input.v1", "P4 named input schema");
    nlohmann::json out{{"schema", "src06-output-processor-full-method-batch-output.v1"}, {"cases", nlohmann::json::array()}};
    for (auto const &item : input.at("cases")) out["cases"].push_back(OutputProcessorDetail::run_case(item));
    return out;
}
} // namespace NativeGapBatch

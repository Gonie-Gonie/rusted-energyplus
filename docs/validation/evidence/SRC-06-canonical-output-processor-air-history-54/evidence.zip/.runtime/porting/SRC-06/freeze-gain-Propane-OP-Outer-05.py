"""Freeze a private real Propane/IHG OutputProcessor closure for independent peer.
No compiler, Native execution, or canonical mutation.
"""
from pathlib import Path
import copy, difflib, hashlib, json, re, subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'source-OtherEquipment-Propane-OP-draft-Outer-05'
N = R / '.reference/energyplus-src/26.1.0'
NC = '6f2e40d10250a105b49966baa24d843711e61048'

def ref(p):
    p = p.resolve(); b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def checked(v):
    p = R / v['path']; assert ref(p) == v; return p

def save(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(v, indent=2, ensure_ascii=False)+'\n').encode('utf-8'))
    return ref(p)

def diff(p, a, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True), b.decode().splitlines(True), fromfile='preserved', tofile='context-checked05')).encode())
    return ref(p)

def main():
    assert not O.exists(); O.mkdir()
    prior = D / 'source-OtherEquipment-Propane-OP-draft-Outer-04/draft.json'
    old = json.loads(prior.read_bytes()); new = copy.deepcopy(old)
    files = []; changes = []; overlay = {}
    for row in old['files']:
        cp = row['canonical_path']; a = checked(row['proposed']).read_bytes(); b = a
        if cp.endswith('/internal_heat_gains_input/output.rs'):
            x = b'if row.fuel != super::SourceOtherFuel::None\n                    && row.fuel != super::SourceOtherFuel::Invalid\n'
            assert b.count(x) == 1
            b = b.replace(x, x + b'                    && row.fuel != super::SourceOtherFuel::Propane\n')
            b = b.replace(b'//! Reached None-fuel IHG declarations on the existing OutputProcessor owner.', b'//! Ordered None/Propane IHG declarations on the existing OutputProcessor owner.')
        if cp.endswith('/source_output_registration/general_real.rs'):
            first = b.splitlines(keepends=True)[0]
            b = b.replace(first, b'//! Real SetupOutputVariable with actual Zone/System and energy meters.\n', 1)
        formatted = subprocess.run(['rustfmt', '--edition', '2021', '--config', 'skip_children=true', '--emit', 'stdout'], input=b, capture_output=True)
        assert formatted.returncode == 0, (cp, formatted.stderr)
        b = formatted.stdout
        p = O / 'proposed' / cp; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
        original = b'' if row.get('before') is None else checked(row['before']).read_bytes()
        # These are logical before files, not a claim that an unrelated live WIP
        # compiler snapshot has been sealed. A later Root application joins it.
        nr = copy.deepcopy(row); nr['proposed'] = ref(p)
        nr['diffs'] = {'forward': diff(O/'diffs'/f'{cp}.forward.diff', original, b), 'inverse': diff(O/'diffs'/f'{cp}.inverse.diff', b, original)}
        nr['Source_only_parse'] = {'exit_code': 0, 'qualification': 'rustfmt stdout --edition2021 skip_children=true is proposed bytes; syntax only, no typecheck'}
        files.append(nr); overlay[cp] = b
        changes.append({'canonical_path': cp, 'whole_equal04': a == b, 'forward': diff(O/'correction-diffs'/f'{cp}.forward.diff', a, b), 'inverse': diff(O/'correction-diffs'/f'{cp}.inverse.diff', b, a)})
    new['files'] = files
    new['preserved_unaccepted_04'] = ref(prior)
    new['last_contextual_correction'] = {'finding': 'The old non-None/Invalid fallback still rejected Propane after its two genuine declarations. Exclude the now-implemented Propane enum from that fallback; other fuels remain the actual typed operation boundary.', 'changes': changes}
    new['scope'][2] = 'Propane resource5/InteriorEquipment enduse4/SpaceType group4, same actual EndUseCategory SpaceType arrays/count/max; ten ordered AddMeter calls when all Building/Zone/SpaceType/subcategory arguments are present (not a hardcoded count in production).'
    new['pending'] = ['Independent full Native/Source/member/borrow peer.', 'Root contextual compile and eventual actual Native-paired Exterior group comparison.', 'Genuine tiny-IDF Source factory/beam/IHG cohort is separate and not claimed complete by this production leaf.']
    new['honest_boundaries'] = ['Unrepresented fuel lookup/invalid/Water diagnostics stop at that exact getter operation; no fuel is silently converted to None.', 'Positive requested input-stage dictionary emission has no actual ESO/SQL/RF dictionary owner in this caller and stops at its first dictionary write after Native-ordered retained writes. No fake sink or no-op host is created.', 'Existing unmetered Zone/Space totals and generic Other outputs keep the existing positive requested registration boundary; this leaf fully binds the two object Propane rate/energy fields only.', 'Old Heating/Cooling-specific energy-transfer helper explicitly rejects InteriorEquipment; the actual general-meter route handles it.', 'Finite CON01 production admission and policies remain unchanged; no full new-input production-admission claim.']

    # Direct, frozen Native authority. Preserve bytes and genuine Git identity.
    authorities = []
    spec = [
        ('src/EnergyPlus/InternalHeatGains.cc', [(1795,1935),(5427,5465),(5529,5541),(5542,5650),(5651,5770)]),
        ('src/EnergyPlus/OutputProcessor.cc', [(111,251),(1360,1610),(3003,3144)]),
        ('src/EnergyPlus/OutputProcessor.hh', [(169,241),(354,419)]),
        ('src/EnergyPlus/DataGlobalConstants.hh', [(64,98),(145,240),(337,370)]),
        ('src/EnergyPlus/DataHeatBalance.hh', [(445,480),(650,678),(861,958),(1619,1695)]),
    ]
    for cp, ranges in spec:
        p = N / cp; b = p.read_bytes()
        git = subprocess.run(['git','-C',str(N),'show',f'{NC}:{cp}'], capture_output=True, check=True).stdout
        assert b == git, cp
        q = O / 'Native-wholes' / cp; q.parent.mkdir(parents=True, exist_ok=True); q.write_bytes(b)
        lines = b.splitlines(keepends=True); extents = []
        for first,last in ranges:
            e = O/'Native-extents'/f'{p.name}.{first}-{last}.txt'; e.parent.mkdir(parents=True, exist_ok=True); e.write_bytes(b''.join(lines[first-1:last]))
            extents.append({'first': first, 'last': last, 'source': ref(e), 'literal_slice_of_whole': True})
        authorities.append({'canonical_path':cp,'whole':ref(q),'pinned_Git_whole_equal':True,'extents':extents})
    new['Native_commit'] = NC; new['Native_authorities'] = authorities
    new['Native_readset'] = ['InternalHeatGains actual OtherEquipment getter/fuel lists/negative design-level errors and Rate-before-Energy object plus Zone/Space total output order.', 'OutputProcessor real SetupOutputVariable/shared prefix/retained Which, AddMeter/reused map, ten optional AttachMeters requests, EndUseCategory subcategory/SpaceType and report-ID order; existing unchanged shared portions retain their original scope.', 'Actual enums: Propane fuel/resource5, InteriorEquipment4, Building0/Zone3/SpaceType4; Propane J uses default OtherJ0, not Gas.', 'DataHeatBalance same Zone/Space fuel lists and seven rates/six energies and ZoneReportVars arrays; no new numeric owner/cache.']

    contexts = []
    for cp in [
        'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs',
        'crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs',
        'crates/ep_runtime/src/heat_balance/source_output_registration/meter_request_input/details.rs',
        'crates/ep_runtime/src/heat_balance/source_output_registration/internal_gain_target.rs',
        'crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/timestep.rs',
        'crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/report.rs',
    ]:
        if cp in overlay:
            src = next(r['proposed'] for r in files if r['canonical_path']==cp)
        elif (R/cp).exists():
            p=O/'concrete-contexts'/cp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/cp).read_bytes());src=ref(p)
        else:
            continue
        contexts.append({'canonical_path':cp,'whole':src})
    new['concrete_same_owner_contexts'] = contexts
    new['member_and_borrow_checks'] = [
        'SelectedInternalHeatGains.allocations.other_equipment and SourceOtherEquipment.rates[0]/energies[0] are pub(crate); the new same-owner resolver returns field references, not scalar snapshots.',
        'TimeStepKind actual declaration is source_output_registration; SelectedZoneData.multiplier/list_multiplier/name and actual Space.space_type/other_equipment_fuels exist with crate visibility.',
        'OutputProcessor actual fields are max_num_end_use_space_types and EndUseCategory.num_space_types/space_type_names; new lists follow count/redimension/assignment/max ordering.',
        'Temporary names and ordered fuel-ID lists release Zone/Space immutable borrows before whole mutable getter-output calls; rate/energy/multipliers are never cached in an alternate owner.',
        'SourceOutputDictionaryHost is object safe; shared dictionary method accepts ?Sized, original public setup method keeps exactly its old API and forwards Some(actual host), IHG-specific method forwards genuine None.',
        'Actual SourceHvacOwners.gains exists; all three live view constructions borrow that same owner alongside disjoint equipment/schedules/registration. Partial view aggregators explicitly reject an owner they do not borrow.',
    ]

    patterns = [r'SourceOtherFuel::',r'SourceMeter(?:Resource|Group|EndUse)::',r'SourceRealOutputTarget::',r'LiveRead(?:View|Fields)\s*\{',r'setup_bound_general_real',r'finish_bound_general_real_registration',r'write_real_report_dictionary']
    census=[]
    for p in sorted((R/'crates').rglob('*.rs')):
        cp=p.relative_to(R).as_posix();b=overlay.get(cp,p.read_bytes())
        for number,line in enumerate(b.decode().splitlines(),1):
            if any(re.search(pattern,line) for pattern in patterns):census.append({'canonical_path':cp,'line':number,'text':line})
    for cp,b in overlay.items():
        if (R/cp).exists():continue
        for number,line in enumerate(b.decode().splitlines(),1):
            if any(re.search(pattern,line) for pattern in patterns):census.append({'canonical_path':cp,'line':number,'text':line})
    new['whole_crates_overlay_API_census'] = save(O/'whole-crates-API-census.json',{'scope':'all current crates/**/*.rs plus these14 proposed wholes; no claim of final compiler-plan seal','patterns':patterns,'matches':census})
    assert new['Sources']==14 and new['existing']==13 and new['new']==1
    new['author_Source']=ref(Path(__file__))
    print(json.dumps({'draft':save(O/'draft.json',new),'api_matches':len(census)}))

if __name__=='__main__': main()

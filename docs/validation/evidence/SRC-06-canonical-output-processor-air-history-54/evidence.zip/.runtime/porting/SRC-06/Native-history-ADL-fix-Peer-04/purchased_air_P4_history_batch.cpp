// Private P1 full-function caller. No copied scientific body or expected state.
#include "native_gap_batches.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataErrorTracking.hh>
#include <EnergyPlus/DataContaminantBalance.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataHeatBalFanSys.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataLoopNode.hh>
#include <EnergyPlus/DataSizing.hh>
#include <EnergyPlus/DataStringGlobals.hh>
#include <EnergyPlus/DataZoneEnergyDemands.hh>
#include <EnergyPlus/DataZoneEquipment.hh>
#include <EnergyPlus/InputProcessing/InputProcessor.hh>
#include <EnergyPlus/HeatBalanceManager.hh>
#include <EnergyPlus/ZoneEquipmentManager.hh>
#include <EnergyPlus/ZoneTempPredictorCorrector.hh>
#include <EnergyPlus/SystemAvailabilityManager.hh>
#include <EnergyPlus/SimulationManager.hh>
#include <EnergyPlus/PurchasedAirManager.hh>
#include <EnergyPlus/ScheduleManager.hh>
#include <EnergyPlus/Psychrometrics.hh>
#include <EnergyPlus/OutputProcessor.hh>
#include <EnergyPlus/OutputReportPredefined.hh>
#include <EnergyPlus/ReportCoilSelection.hh>
#include <EnergyPlus/SQLiteProcedures.hh>
#include <EnergyPlus/UtilityRoutines.hh>
#include <EnergyPlus/IOFiles.hh>
#include <nlohmann/json.hpp>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
namespace NativeGapBatch::PurchasedAirDetail {
using json=nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
void require(bool value,char const *message){if(!value)throw std::runtime_error(message);}
std::uint64_t bits(double v){std::uint64_t b;std::memcpy(&b,&v,sizeof b);return b;}
double from_bits(std::uint64_t b){double out;std::memcpy(&out,&b,sizeof out);return out;}
json number(double v){require(std::isfinite(v),"finite real Native unit scalar");std::ostringstream s;s<<std::hex<<std::setfill('0')<<std::setw(16)<<bits(v);return json{{"value_bits",s.str()}};}
double real(json const &v){auto text=v.at("value_bits").get<std::string>();require(v.size()==1&&text.size()==16,"raw16hex input");std::uint64_t b=0;for(char c:text){require((c>='0'&&c<='9')||(c>='a'&&c<='f'),"hex input");b=(b<<4)|static_cast<unsigned>(c<='9'?c-'0':c-'a'+10);}double out;std::memcpy(&out,&b,sizeof out);require(std::isfinite(out),"finite input");return out;}
template<class A> json shape(A const&a){json out{{"allocated",a.allocated()},{"size",a.size()}};if constexpr(requires{a.l();a.u();}){out["lower"]=a.l();out["upper"]=a.u();}return out;}
template<class A> json integer_array(A const&a){auto out=shape(a);out["items"]=json::array();for(std::size_t i=1;i<=a.size();++i)out["items"].push_back(a(i));return out;}
json zone_row(DataSizing::ZoneEqSizingData const&row){json out;
    out["AirVolFlow"]=number(row.AirVolFlow);
    out["MaxHWVolFlow"]=number(row.MaxHWVolFlow);
    out["MaxCWVolFlow"]=number(row.MaxCWVolFlow);
    out["OAVolFlow"]=number(row.OAVolFlow);
    out["ATMixerVolFlow"]=number(row.ATMixerVolFlow);
    out["ATMixerCoolPriDryBulb"]=number(row.ATMixerCoolPriDryBulb);
    out["ATMixerCoolPriHumRat"]=number(row.ATMixerCoolPriHumRat);
    out["ATMixerHeatPriDryBulb"]=number(row.ATMixerHeatPriDryBulb);
    out["ATMixerHeatPriHumRat"]=number(row.ATMixerHeatPriHumRat);
    out["DesCoolingLoad"]=number(row.DesCoolingLoad);
    out["DesHeatingLoad"]=number(row.DesHeatingLoad);
    out["CoolingAirVolFlow"]=number(row.CoolingAirVolFlow);
    out["HeatingAirVolFlow"]=number(row.HeatingAirVolFlow);
    out["SystemAirVolFlow"]=number(row.SystemAirVolFlow);
    out["AirFlow"]=row.AirFlow;
    out["CoolingAirFlow"]=row.CoolingAirFlow;
    out["HeatingAirFlow"]=row.HeatingAirFlow;
    out["SystemAirFlow"]=row.SystemAirFlow;
    out["Capacity"]=row.Capacity;
    out["CoolingCapacity"]=row.CoolingCapacity;
    out["HeatingCapacity"]=row.HeatingCapacity;
    out["SystemCapacity"]=row.SystemCapacity;
    out["DesignSizeFromParent"]=row.DesignSizeFromParent;
    out["HVACSizingIndex"]=static_cast<int>(row.HVACSizingIndex);
    out["SizingMethod"]=integer_array(row.SizingMethod);out["CapSizingMethod"]=integer_array(row.CapSizingMethod);return out;
}
template<class A>json zone_array(A const&a){auto out=shape(a);out["items"]=json::array();for(std::size_t i=1;i<=a.size();++i)out["items"].push_back(zone_row(a(i)));return out;}
json globals(EnergyPlusData const&s){json out;
    out["CurOASysNum"]=static_cast<int>(s.dataSize->CurOASysNum);
    out["CurDuctType"]=static_cast<int>(s.dataSize->CurDuctType);
    out["TermUnitSingDuct"]=s.dataSize->TermUnitSingDuct;
    out["TermUnitPIU"]=s.dataSize->TermUnitPIU;
    out["TermUnitIU"]=s.dataSize->TermUnitIU;
    out["ZoneEqFanCoil"]=s.dataSize->ZoneEqFanCoil;
    out["ZoneEqUnitHeater"]=s.dataSize->ZoneEqUnitHeater;
    out["ZoneEqUnitVent"]=s.dataSize->ZoneEqUnitVent;
    out["ZoneEqVentedSlab"]=s.dataSize->ZoneEqVentedSlab;
    out["ZoneSizingInput"]=shape(s.dataSize->ZoneSizingInput);
    out["FinalZoneSizing"]=shape(s.dataSize->FinalZoneSizing);
    out["TermUnitFinalZoneSizing"]=shape(s.dataSize->TermUnitFinalZoneSizing);
    out["SysSizInput"]=shape(s.dataSize->SysSizInput);
    out["FinalSysSizing"]=shape(s.dataSize->FinalSysSizing);
    out["PlantSizData"]=shape(s.dataSize->PlantSizData);
    out["DataEMSOverrideON"]=s.dataSize->DataEMSOverrideON;
    out["DataEMSOverride"]=number(s.dataSize->DataEMSOverride);
    out["DataAutosizable"]=s.dataSize->DataAutosizable;
    out["DataConstantUsedForSizing"]=number(s.dataSize->DataConstantUsedForSizing);
    out["DataFractionUsedForSizing"]=number(s.dataSize->DataFractionUsedForSizing);
    out["DataFanIndex"]=static_cast<int>(s.dataSize->DataFanIndex);
    out["DataFanType"]=static_cast<int>(s.dataSize->DataFanType);
    out["DataPltSizHeatNum"]=static_cast<int>(s.dataSize->DataPltSizHeatNum);
    out["DataWaterLoopNum"]=static_cast<int>(s.dataSize->DataWaterLoopNum);
    out["DataPltSizCoolNum"]=static_cast<int>(s.dataSize->DataPltSizCoolNum);
    out["DataWaterCoilSizHeatDeltaT"]=number(s.dataSize->DataWaterCoilSizHeatDeltaT);
    out["DataWaterCoilSizCoolDeltaT"]=number(s.dataSize->DataWaterCoilSizCoolDeltaT);
    out["DataCapacityUsedForSizing"]=number(s.dataSize->DataCapacityUsedForSizing);
    out["DataHeatSizeRatio"]=number(s.dataSize->DataHeatSizeRatio);
    out["DataAirFlowUsedForSizing"]=number(s.dataSize->DataAirFlowUsedForSizing);
    out["DataDesInletAirTemp"]=number(s.dataSize->DataDesInletAirTemp);
    out["DataDesAccountForFanHeat"]=s.dataSize->DataDesAccountForFanHeat;
    out["DataFanPlacement"]=static_cast<int>(s.dataSize->DataFanPlacement);
    out["DataDesInletAirHumRat"]=number(s.dataSize->DataDesInletAirHumRat);
    out["DataDesOutletAirHumRat"]=number(s.dataSize->DataDesOutletAirHumRat);
    out["DataDesOutletAirTemp"]=number(s.dataSize->DataDesOutletAirTemp);
    out["DataDesInletWaterTemp"]=number(s.dataSize->DataDesInletWaterTemp);
    out["DataFlowUsedForSizing"]=number(s.dataSize->DataFlowUsedForSizing);
    out["DataWaterFlowUsedForSizing"]=number(s.dataSize->DataWaterFlowUsedForSizing);
    out["DataSizingFraction"]=number(s.dataSize->DataSizingFraction);
    out["DataDXSpeedNum"]=static_cast<int>(s.dataSize->DataDXSpeedNum);
    out["DataDesicRegCoil"]=s.dataSize->DataDesicRegCoil;
    out["DataZoneUsedForSizing"]=static_cast<int>(s.dataSize->DataZoneUsedForSizing);
    out["DataDesicDehumNum"]=static_cast<int>(s.dataSize->DataDesicDehumNum);
    out["DataNomCapInpMeth"]=s.dataSize->DataNomCapInpMeth;
    out["DataCoilNum"]=static_cast<int>(s.dataSize->DataCoilNum);
    out["DataFanOp"]=static_cast<int>(s.dataSize->DataFanOp);
    out["DataDesignCoilCapacity"]=number(s.dataSize->DataDesignCoilCapacity);
    out["DataErrorsFound"]=s.dataSize->DataErrorsFound;
    out["DataBypassFrac"]=number(s.dataSize->DataBypassFrac);
    out["DataIsDXCoil"]=s.dataSize->DataIsDXCoil;
    out["DataNonZoneNonAirloopValue"]=number(s.dataSize->DataNonZoneNonAirloopValue);
    out["DataDXCoolsLowSpeedsAutozize"]=s.dataSize->DataDXCoolsLowSpeedsAutozize;
    out["DataScalableSizingON"]=s.dataSize->DataScalableSizingON;
    out["DataScalableCapSizingON"]=s.dataSize->DataScalableCapSizingON;
    out["HRFlowSizingFlag"]=s.dataSize->HRFlowSizingFlag;
    out["DataFracOfAutosizedCoolingAirflow"]=number(s.dataSize->DataFracOfAutosizedCoolingAirflow);
    out["DataFracOfAutosizedHeatingAirflow"]=number(s.dataSize->DataFracOfAutosizedHeatingAirflow);
    out["DataFlowPerCoolingCapacity"]=number(s.dataSize->DataFlowPerCoolingCapacity);
    out["DataAutosizedCoolingCapacity"]=number(s.dataSize->DataAutosizedCoolingCapacity);
    out["DataFlowPerHeatingCapacity"]=number(s.dataSize->DataFlowPerHeatingCapacity);
    out["DataAutosizedHeatingCapacity"]=number(s.dataSize->DataAutosizedHeatingCapacity);
    out["DataCoilSizingAirInTemp"]=number(s.dataSize->DataCoilSizingAirInTemp);
    out["DataCoilSizingAirInHumRat"]=number(s.dataSize->DataCoilSizingAirInHumRat);
    out["DataCoilSizingAirOutTemp"]=number(s.dataSize->DataCoilSizingAirOutTemp);
    out["DataCoilSizingAirOutHumRat"]=number(s.dataSize->DataCoilSizingAirOutHumRat);
    out["DataCoilSizingFanCoolLoad"]=number(s.dataSize->DataCoilSizingFanCoolLoad);
    out["DataCoilSizingCapFT"]=number(s.dataSize->DataCoilSizingCapFT);
    out["DataTotCapCurveIndex"]=static_cast<int>(s.dataSize->DataTotCapCurveIndex);
    out["DataTotCapCurveValue"]=number(s.dataSize->DataTotCapCurveValue);
    out["DataFracOfAutosizedCoolingCapacity"]=number(s.dataSize->DataFracOfAutosizedCoolingCapacity);
    out["DataFracOfAutosizedHeatingCapacity"]=number(s.dataSize->DataFracOfAutosizedHeatingCapacity);
    out["DataCoilIsSuppHeater"]=s.dataSize->DataCoilIsSuppHeater;
    out["SuppHeatCap"]=number(s.dataSize->SuppHeatCap);
    out["UnitaryHeatCap"]=number(s.dataSize->UnitaryHeatCap);
    out["DataCoolCoilType"]=static_cast<int>(s.dataSize->DataCoolCoilType);
    out["DataCoolCoilIndex"]=static_cast<int>(s.dataSize->DataCoolCoilIndex);
    out["ZoneHVACSizing"]=shape(s.dataSize->ZoneHVACSizing);
    out["DataZoneNumber"]=static_cast<int>(s.dataSize->DataZoneNumber);
    out["AutoVsHardSizingThreshold"]=number(s.dataSize->AutoVsHardSizingThreshold);
    out["SysSizingRunDone"]=s.dataSize->SysSizingRunDone;
    out["ZoneSizingRunDone"]=s.dataSize->ZoneSizingRunDone;
    out["CurSysNum"]=static_cast<int>(s.dataSize->CurSysNum);
    out["CurZoneEqNum"]=static_cast<int>(s.dataSize->CurZoneEqNum);
    out["CurTermUnitSizingNum"]=static_cast<int>(s.dataSize->CurTermUnitSizingNum);
    out["NumSysSizInput"]=static_cast<int>(s.dataSize->NumSysSizInput);
    out["NumZoneSizingInput"]=static_cast<int>(s.dataSize->NumZoneSizingInput);
    out["UnitarySysEqSizing"]=zone_array(s.dataSize->UnitarySysEqSizing);
    out["OASysEqSizing"]=zone_array(s.dataSize->OASysEqSizing);
    out["TermUnitSizing"]=shape(s.dataSize->TermUnitSizing);
    out["ZoneEqSizing"]=zone_array(s.dataSize->ZoneEqSizing);
    out["ZoneCoolingOnlyFan"]=s.dataSize->ZoneCoolingOnlyFan;
    out["ZoneHeatingOnlyFan"]=s.dataSize->ZoneHeatingOnlyFan;
    out["DataCoolCoilCap"]=number(s.dataSize->DataCoolCoilCap);
 out["StdRhoAir"]=number(s.dataEnvrn->StdRhoAir);out["isEpJSON"]=s.dataGlobal->isEpJSON;out["DoZoneSizing"]=s.dataGlobal->DoZoneSizing;out["DoSystemSizing"]=s.dataGlobal->DoSystemSizing;out["DisplayExtraWarnings"]=s.dataGlobal->DisplayExtraWarnings;out["NumPrimaryAirSys"]=s.dataHVACGlobal->NumPrimaryAirSys;return out;
}
json reports(EnergyPlusData&s){json out{{"oneTimeCompRptHeaderFlag",s.dataEnvrn->oneTimeCompRptHeaderFlag},{"eio",s.files.eio.get_output()},{"sqlite_present",bool(s.dataSQLiteProcedures->sqlite)}};
 auto const&owner=*s.dataOutRptPredefined;out["sizeCompSizeTableEntry"]=owner.sizeCompSizeTableEntry;out["numCompSizeTableEntry"]=owner.numCompSizeTableEntry;out["CompSizeTableEntry"]=shape(owner.CompSizeTableEntry);auto&items=out["CompSizeTableEntry"]["items"]=json::array();
 for(std::size_t i=1;i<=owner.CompSizeTableEntry.size();++i){auto const&r=owner.CompSizeTableEntry(i);items.push_back(json{{"typeField",r.typeField},{"nameField",r.nameField},{"description",r.description},{"valField",number(r.valField)},{"strField",r.strField},{"active",r.active},{"written",r.written}});}return out;
}

json pointer(void const*p){std::ostringstream out;out<<p;return p?json(out.str()):json(nullptr);}
json schedule_pointer(EnergyPlusData const&s,Sched::Schedule const*p){
    if(!p)return nullptr;
    json out{{"address",pointer(p)},{"Name",p->Name},{"Num",p->Num},{"currentVal",number(p->currentVal)},
             {"EMSActuatedOn",p->EMSActuatedOn},{"EMSVal",number(p->EMSVal)},{"isUsed",p->isUsed}};
    json matches=json::array();
    for(std::size_t i=0;i<s.dataSched->schedules.size();++i)if(s.dataSched->schedules[i]==p)matches.push_back(i);
    out["same_actual_schedule_owner_ordinals_zero_based"]=matches;return out;
}
json unit(EnergyPlusData const&s,PurchasedAirManager::ZonePurchasedAir const&row){json out;
    out["cObjectName"]=row.cObjectName;
    out["Name"]=row.Name;
    out["availSched"]=schedule_pointer(s,row.availSched);
    out["ZoneSupplyAirNodeNum"]=row.ZoneSupplyAirNodeNum;
    out["ZoneExhaustAirNodeNum"]=row.ZoneExhaustAirNodeNum;
    out["PlenumExhaustAirNodeNum"]=row.PlenumExhaustAirNodeNum;
    out["ReturnPlenumIndex"]=row.ReturnPlenumIndex;
    out["PurchAirArrayIndex"]=row.PurchAirArrayIndex;
    out["ReturnPlenumName"]=row.ReturnPlenumName;
    out["ZoneRecircAirNodeNum"]=row.ZoneRecircAirNodeNum;
    out["MaxHeatSuppAirTemp"]=number(row.MaxHeatSuppAirTemp);
    out["MinCoolSuppAirTemp"]=number(row.MinCoolSuppAirTemp);
    out["MaxHeatSuppAirHumRat"]=number(row.MaxHeatSuppAirHumRat);
    out["MinCoolSuppAirHumRat"]=number(row.MinCoolSuppAirHumRat);
    out["HeatingLimit"]=static_cast<int>(row.HeatingLimit);
    out["MaxHeatVolFlowRate"]=number(row.MaxHeatVolFlowRate);
    out["MaxHeatSensCap"]=number(row.MaxHeatSensCap);
    out["CoolingLimit"]=static_cast<int>(row.CoolingLimit);
    out["MaxCoolVolFlowRate"]=number(row.MaxCoolVolFlowRate);
    out["MaxCoolTotCap"]=number(row.MaxCoolTotCap);
    out["heatAvailSched"]=schedule_pointer(s,row.heatAvailSched);
    out["coolAvailSched"]=schedule_pointer(s,row.coolAvailSched);
    out["DehumidCtrlType"]=static_cast<int>(row.DehumidCtrlType);
    out["CoolSHR"]=number(row.CoolSHR);
    out["HumidCtrlType"]=static_cast<int>(row.HumidCtrlType);
    out["OARequirementsPtr"]=row.OARequirementsPtr;
    out["DCVType"]=static_cast<int>(row.DCVType);
    out["EconomizerType"]=static_cast<int>(row.EconomizerType);
    out["OutdoorAir"]=row.OutdoorAir;
    out["OutdoorAirNodeNum"]=row.OutdoorAirNodeNum;
    out["HtRecType"]=static_cast<int>(row.HtRecType);
    out["HtRecSenEff"]=number(row.HtRecSenEff);
    out["HtRecLatEff"]=number(row.HtRecLatEff);
    out["oaFlowFracSched"]=schedule_pointer(s,row.oaFlowFracSched);
    out["MaxHeatMassFlowRate"]=number(row.MaxHeatMassFlowRate);
    out["MaxCoolMassFlowRate"]=number(row.MaxCoolMassFlowRate);
    out["EMSOverrideMdotOn"]=row.EMSOverrideMdotOn;
    out["EMSValueMassFlowRate"]=number(row.EMSValueMassFlowRate);
    out["EMSOverrideOAMdotOn"]=row.EMSOverrideOAMdotOn;
    out["EMSValueOAMassFlowRate"]=number(row.EMSValueOAMassFlowRate);
    out["EMSOverrideSupplyTempOn"]=row.EMSOverrideSupplyTempOn;
    out["EMSValueSupplyTemp"]=number(row.EMSValueSupplyTemp);
    out["EMSOverrideSupplyHumRatOn"]=row.EMSOverrideSupplyHumRatOn;
    out["EMSValueSupplyHumRat"]=number(row.EMSValueSupplyHumRat);
    out["MinOAMassFlowRate"]=number(row.MinOAMassFlowRate);
    out["OutdoorAirMassFlowRate"]=number(row.OutdoorAirMassFlowRate);
    out["OutdoorAirVolFlowRateStdRho"]=number(row.OutdoorAirVolFlowRateStdRho);
    out["SupplyAirMassFlowRate"]=number(row.SupplyAirMassFlowRate);
    out["SupplyAirVolFlowRateStdRho"]=number(row.SupplyAirVolFlowRateStdRho);
    out["HtRecSenOutput"]=number(row.HtRecSenOutput);
    out["HtRecLatOutput"]=number(row.HtRecLatOutput);
    out["OASenOutput"]=number(row.OASenOutput);
    out["OALatOutput"]=number(row.OALatOutput);
    out["SenOutputToZone"]=number(row.SenOutputToZone);
    out["LatOutputToZone"]=number(row.LatOutputToZone);
    out["SenCoilLoad"]=number(row.SenCoilLoad);
    out["LatCoilLoad"]=number(row.LatCoilLoad);
    out["OAFlowMaxCoolOutputError"]=row.OAFlowMaxCoolOutputError;
    out["OAFlowMaxHeatOutputError"]=row.OAFlowMaxHeatOutputError;
    out["SaturationOutputError"]=row.SaturationOutputError;
    out["OAFlowMaxCoolOutputIndex"]=row.OAFlowMaxCoolOutputIndex;
    out["OAFlowMaxHeatOutputIndex"]=row.OAFlowMaxHeatOutputIndex;
    out["SaturationOutputIndex"]=row.SaturationOutputIndex;
    out["availStatus"]=static_cast<int>(row.availStatus);
    out["CoolErrIndex"]=row.CoolErrIndex;
    out["HeatErrIndex"]=row.HeatErrIndex;
    out["SenHeatEnergy"]=number(row.SenHeatEnergy);
    out["LatHeatEnergy"]=number(row.LatHeatEnergy);
    out["TotHeatEnergy"]=number(row.TotHeatEnergy);
    out["SenCoolEnergy"]=number(row.SenCoolEnergy);
    out["LatCoolEnergy"]=number(row.LatCoolEnergy);
    out["TotCoolEnergy"]=number(row.TotCoolEnergy);
    out["ZoneSenHeatEnergy"]=number(row.ZoneSenHeatEnergy);
    out["ZoneLatHeatEnergy"]=number(row.ZoneLatHeatEnergy);
    out["ZoneTotHeatEnergy"]=number(row.ZoneTotHeatEnergy);
    out["ZoneSenCoolEnergy"]=number(row.ZoneSenCoolEnergy);
    out["ZoneLatCoolEnergy"]=number(row.ZoneLatCoolEnergy);
    out["ZoneTotCoolEnergy"]=number(row.ZoneTotCoolEnergy);
    out["OASenHeatEnergy"]=number(row.OASenHeatEnergy);
    out["OALatHeatEnergy"]=number(row.OALatHeatEnergy);
    out["OATotHeatEnergy"]=number(row.OATotHeatEnergy);
    out["OASenCoolEnergy"]=number(row.OASenCoolEnergy);
    out["OALatCoolEnergy"]=number(row.OALatCoolEnergy);
    out["OATotCoolEnergy"]=number(row.OATotCoolEnergy);
    out["HtRecSenHeatEnergy"]=number(row.HtRecSenHeatEnergy);
    out["HtRecLatHeatEnergy"]=number(row.HtRecLatHeatEnergy);
    out["HtRecTotHeatEnergy"]=number(row.HtRecTotHeatEnergy);
    out["HtRecSenCoolEnergy"]=number(row.HtRecSenCoolEnergy);
    out["HtRecLatCoolEnergy"]=number(row.HtRecLatCoolEnergy);
    out["HtRecTotCoolEnergy"]=number(row.HtRecTotCoolEnergy);
    out["SenHeatRate"]=number(row.SenHeatRate);
    out["LatHeatRate"]=number(row.LatHeatRate);
    out["TotHeatRate"]=number(row.TotHeatRate);
    out["SenCoolRate"]=number(row.SenCoolRate);
    out["LatCoolRate"]=number(row.LatCoolRate);
    out["TotCoolRate"]=number(row.TotCoolRate);
    out["ZoneSenHeatRate"]=number(row.ZoneSenHeatRate);
    out["ZoneLatHeatRate"]=number(row.ZoneLatHeatRate);
    out["ZoneTotHeatRate"]=number(row.ZoneTotHeatRate);
    out["ZoneSenCoolRate"]=number(row.ZoneSenCoolRate);
    out["ZoneLatCoolRate"]=number(row.ZoneLatCoolRate);
    out["ZoneTotCoolRate"]=number(row.ZoneTotCoolRate);
    out["OASenHeatRate"]=number(row.OASenHeatRate);
    out["OALatHeatRate"]=number(row.OALatHeatRate);
    out["OATotHeatRate"]=number(row.OATotHeatRate);
    out["OASenCoolRate"]=number(row.OASenCoolRate);
    out["OALatCoolRate"]=number(row.OALatCoolRate);
    out["OATotCoolRate"]=number(row.OATotCoolRate);
    out["HtRecSenHeatRate"]=number(row.HtRecSenHeatRate);
    out["HtRecLatHeatRate"]=number(row.HtRecLatHeatRate);
    out["HtRecTotHeatRate"]=number(row.HtRecTotHeatRate);
    out["HtRecSenCoolRate"]=number(row.HtRecSenCoolRate);
    out["HtRecLatCoolRate"]=number(row.HtRecLatCoolRate);
    out["HtRecTotCoolRate"]=number(row.HtRecTotCoolRate);
    out["TimeEconoActive"]=number(row.TimeEconoActive);
    out["TimeHtRecActive"]=number(row.TimeHtRecActive);
    out["ZonePtr"]=row.ZonePtr;
    out["HVACSizingIndex"]=row.HVACSizingIndex;
    out["SupplyTemp"]=number(row.SupplyTemp);
    out["SupplyHumRat"]=number(row.SupplyHumRat);
    out["MixedAirTemp"]=number(row.MixedAirTemp);
    out["MixedAirHumRat"]=number(row.MixedAirHumRat);
    out["heatFuelEffSched"]=schedule_pointer(s,row.heatFuelEffSched);
    out["coolFuelEffSched"]=schedule_pointer(s,row.coolFuelEffSched);
    out["ZoneTotHeatFuelRate"]=number(row.ZoneTotHeatFuelRate);
    out["ZoneTotCoolFuelRate"]=number(row.ZoneTotCoolFuelRate);
    out["ZoneTotHeatFuelEnergy"]=number(row.ZoneTotHeatFuelEnergy);
    out["ZoneTotCoolFuelEnergy"]=number(row.ZoneTotCoolFuelEnergy);
    out["TotHeatFuelRate"]=number(row.TotHeatFuelRate);
    out["TotCoolFuelRate"]=number(row.TotCoolFuelRate);
    out["TotHeatFuelEnergy"]=number(row.TotHeatFuelEnergy);
    out["TotCoolFuelEnergy"]=number(row.TotCoolFuelEnergy);
    out["heatingFuelType"]=static_cast<int>(row.heatingFuelType);
    out["coolingFuelType"]=static_cast<int>(row.coolingFuelType);
    out["address"]=pointer(&row);return out;
}

template<class A>json strings(A const&a){auto out=shape(a);out["items"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i)out["items"].push_back(a(i));return out;}
template<class A>json booleans(A const&a){auto out=shape(a);out["items"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i)out["items"].push_back(bool(a(i)));return out;}
json manager(EnergyPlusData const&s){auto const&m=*s.dataPurchasedAirMgr;json out;
    out["NumPurchAir"]=m.NumPurchAir;out["NumPlenumArrays"]=m.NumPlenumArrays;out["GetPurchAirInputFlag"]=m.GetPurchAirInputFlag;
    out["CheckEquipName"]=booleans(m.CheckEquipName);out["PurchAir"]=shape(m.PurchAir);out["PurchAir"]["items"]=json::array();
    if(m.PurchAir.allocated())for(int i=m.PurchAir.l();i<=m.PurchAir.u();++i)out["PurchAir"]["items"].push_back(unit(s,m.PurchAir(i)));
    out["PurchAirNumericFields"]=shape(m.PurchAirNumericFields);out["PurchAirNumericFields"]["items"]=json::array();
    if(m.PurchAirNumericFields.allocated())for(int i=m.PurchAirNumericFields.l();i<=m.PurchAirNumericFields.u();++i)out["PurchAirNumericFields"]["items"].push_back(strings(m.PurchAirNumericFields(i).FieldNames));
    auto plenum=[&](auto const&a){auto v=shape(a);v["items"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i){auto const&r=a(i);v["items"].push_back(json{{"NumPurchAir",r.NumPurchAir},{"ReturnPlenumIndex",r.ReturnPlenumIndex},{"PurchAirArray",integer_array(r.PurchAirArray)},{"IsSimulated",booleans(r.IsSimulated)}});}return v;};
    out["PurchAirPlenumArrays"]=plenum(m.PurchAirPlenumArrays);out["InitPurchasedAirMyOneTimeFlag"]=m.InitPurchasedAirMyOneTimeFlag;
    out["InitPurchasedAirZoneEquipmentListChecked"]=m.InitPurchasedAirZoneEquipmentListChecked;
    out["InitPurchasedAirMyEnvrnFlag"]=booleans(m.InitPurchasedAirMyEnvrnFlag);out["InitPurchasedAirMySizeFlag"]=booleans(m.InitPurchasedAirMySizeFlag);
    out["InitPurchasedAirOneTimeUnitInitsDone"]=booleans(m.InitPurchasedAirOneTimeUnitInitsDone);out["TempPurchAirPlenumArrays"]=plenum(m.TempPurchAirPlenumArrays);
    return out;
}
json node(EnergyPlusData const&s,Node::NodeData const&row){json out;
    out["fluidType"]=static_cast<int>(row.fluidType);
    out["FluidIndex"]=row.FluidIndex;
    out["Temp"]=number(row.Temp);
    out["TempMin"]=number(row.TempMin);
    out["TempMax"]=number(row.TempMax);
    out["TempSetPoint"]=number(row.TempSetPoint);
    out["TempLastTimestep"]=number(row.TempLastTimestep);
    out["MassFlowRateRequest"]=number(row.MassFlowRateRequest);
    out["MassFlowRate"]=number(row.MassFlowRate);
    out["MassFlowRateMin"]=number(row.MassFlowRateMin);
    out["MassFlowRateMax"]=number(row.MassFlowRateMax);
    out["MassFlowRateMinAvail"]=number(row.MassFlowRateMinAvail);
    out["MassFlowRateMaxAvail"]=number(row.MassFlowRateMaxAvail);
    out["MassFlowRateSetPoint"]=number(row.MassFlowRateSetPoint);
    out["Quality"]=number(row.Quality);
    out["Press"]=number(row.Press);
    out["Enthalpy"]=number(row.Enthalpy);
    out["EnthalpyLastTimestep"]=number(row.EnthalpyLastTimestep);
    out["HumRat"]=number(row.HumRat);
    out["HumRatMin"]=number(row.HumRatMin);
    out["HumRatMax"]=number(row.HumRatMax);
    out["HumRatSetPoint"]=number(row.HumRatSetPoint);
    out["TempSetPointHi"]=number(row.TempSetPointHi);
    out["TempSetPointLo"]=number(row.TempSetPointLo);
    out["Height"]=number(row.Height);
    out["IsLocalNode"]=row.IsLocalNode;
    out["OutAirDryBulb"]=number(row.OutAirDryBulb);
    out["EMSOverrideOutAirDryBulb"]=row.EMSOverrideOutAirDryBulb;
    out["EMSValueForOutAirDryBulb"]=number(row.EMSValueForOutAirDryBulb);
    out["OutAirWetBulb"]=number(row.OutAirWetBulb);
    out["EMSOverrideOutAirWetBulb"]=row.EMSOverrideOutAirWetBulb;
    out["EMSValueForOutAirWetBulb"]=number(row.EMSValueForOutAirWetBulb);
    out["OutAirWindSpeed"]=number(row.OutAirWindSpeed);
    out["EMSOverrideOutAirWindSpeed"]=row.EMSOverrideOutAirWindSpeed;
    out["EMSValueForOutAirWindSpeed"]=number(row.EMSValueForOutAirWindSpeed);
    out["OutAirWindDir"]=number(row.OutAirWindDir);
    out["EMSOverrideOutAirWindDir"]=row.EMSOverrideOutAirWindDir;
    out["EMSValueForOutAirWindDir"]=number(row.EMSValueForOutAirWindDir);
    out["CO2"]=number(row.CO2);
    out["CO2SetPoint"]=number(row.CO2SetPoint);
    out["GenContam"]=number(row.GenContam);
    out["GenContamSetPoint"]=number(row.GenContamSetPoint);
    out["SPMNodeWetBulbRepReq"]=row.SPMNodeWetBulbRepReq;
    out["plantNodeErrorMsgIssued"]=row.plantNodeErrorMsgIssued;
    out["outAirDryBulbSched"]=schedule_pointer(s,row.outAirDryBulbSched);
    out["outAirWetBulbSched"]=schedule_pointer(s,row.outAirWetBulbSched);
    out["outAirWindSpeedSched"]=schedule_pointer(s,row.outAirWindSpeedSched);
    out["outAirWindDirSched"]=schedule_pointer(s,row.outAirWindDirSched);
    out["address"]=pointer(&row);return out;
}

json nodes(EnergyPlusData const&s){auto const&n=*s.dataLoopNodes;json out{{"NodeID",strings(n.NodeID)},{"Node",shape(n.Node)}};out["Node"]["items"]=json::array();for(std::size_t i=1;i<=n.Node.size();++i)out["Node"]["items"].push_back(node(s,n.Node(i)));return out;}
json real_member_matches(EnergyPlusData const&s,Real64 const*ptr){json out=json::array();auto const&a=s.dataPurchasedAirMgr->PurchAir;if(a.allocated())for(int i=a.l();i<=a.u();++i){auto const&row=a(i);
    if(ptr==&row.MaxHeatSuppAirTemp)out.push_back(json{{"unit",i},{"member","MaxHeatSuppAirTemp"}});
    if(ptr==&row.MinCoolSuppAirTemp)out.push_back(json{{"unit",i},{"member","MinCoolSuppAirTemp"}});
    if(ptr==&row.MaxHeatSuppAirHumRat)out.push_back(json{{"unit",i},{"member","MaxHeatSuppAirHumRat"}});
    if(ptr==&row.MinCoolSuppAirHumRat)out.push_back(json{{"unit",i},{"member","MinCoolSuppAirHumRat"}});
    if(ptr==&row.MaxHeatVolFlowRate)out.push_back(json{{"unit",i},{"member","MaxHeatVolFlowRate"}});
    if(ptr==&row.MaxHeatSensCap)out.push_back(json{{"unit",i},{"member","MaxHeatSensCap"}});
    if(ptr==&row.MaxCoolVolFlowRate)out.push_back(json{{"unit",i},{"member","MaxCoolVolFlowRate"}});
    if(ptr==&row.MaxCoolTotCap)out.push_back(json{{"unit",i},{"member","MaxCoolTotCap"}});
    if(ptr==&row.CoolSHR)out.push_back(json{{"unit",i},{"member","CoolSHR"}});
    if(ptr==&row.HtRecSenEff)out.push_back(json{{"unit",i},{"member","HtRecSenEff"}});
    if(ptr==&row.HtRecLatEff)out.push_back(json{{"unit",i},{"member","HtRecLatEff"}});
    if(ptr==&row.MaxHeatMassFlowRate)out.push_back(json{{"unit",i},{"member","MaxHeatMassFlowRate"}});
    if(ptr==&row.MaxCoolMassFlowRate)out.push_back(json{{"unit",i},{"member","MaxCoolMassFlowRate"}});
    if(ptr==&row.EMSValueMassFlowRate)out.push_back(json{{"unit",i},{"member","EMSValueMassFlowRate"}});
    if(ptr==&row.EMSValueOAMassFlowRate)out.push_back(json{{"unit",i},{"member","EMSValueOAMassFlowRate"}});
    if(ptr==&row.EMSValueSupplyTemp)out.push_back(json{{"unit",i},{"member","EMSValueSupplyTemp"}});
    if(ptr==&row.EMSValueSupplyHumRat)out.push_back(json{{"unit",i},{"member","EMSValueSupplyHumRat"}});
    if(ptr==&row.MinOAMassFlowRate)out.push_back(json{{"unit",i},{"member","MinOAMassFlowRate"}});
    if(ptr==&row.OutdoorAirMassFlowRate)out.push_back(json{{"unit",i},{"member","OutdoorAirMassFlowRate"}});
    if(ptr==&row.OutdoorAirVolFlowRateStdRho)out.push_back(json{{"unit",i},{"member","OutdoorAirVolFlowRateStdRho"}});
    if(ptr==&row.SupplyAirMassFlowRate)out.push_back(json{{"unit",i},{"member","SupplyAirMassFlowRate"}});
    if(ptr==&row.SupplyAirVolFlowRateStdRho)out.push_back(json{{"unit",i},{"member","SupplyAirVolFlowRateStdRho"}});
    if(ptr==&row.HtRecSenOutput)out.push_back(json{{"unit",i},{"member","HtRecSenOutput"}});
    if(ptr==&row.HtRecLatOutput)out.push_back(json{{"unit",i},{"member","HtRecLatOutput"}});
    if(ptr==&row.OASenOutput)out.push_back(json{{"unit",i},{"member","OASenOutput"}});
    if(ptr==&row.OALatOutput)out.push_back(json{{"unit",i},{"member","OALatOutput"}});
    if(ptr==&row.SenOutputToZone)out.push_back(json{{"unit",i},{"member","SenOutputToZone"}});
    if(ptr==&row.LatOutputToZone)out.push_back(json{{"unit",i},{"member","LatOutputToZone"}});
    if(ptr==&row.SenCoilLoad)out.push_back(json{{"unit",i},{"member","SenCoilLoad"}});
    if(ptr==&row.LatCoilLoad)out.push_back(json{{"unit",i},{"member","LatCoilLoad"}});
    if(ptr==&row.SenHeatEnergy)out.push_back(json{{"unit",i},{"member","SenHeatEnergy"}});
    if(ptr==&row.LatHeatEnergy)out.push_back(json{{"unit",i},{"member","LatHeatEnergy"}});
    if(ptr==&row.TotHeatEnergy)out.push_back(json{{"unit",i},{"member","TotHeatEnergy"}});
    if(ptr==&row.SenCoolEnergy)out.push_back(json{{"unit",i},{"member","SenCoolEnergy"}});
    if(ptr==&row.LatCoolEnergy)out.push_back(json{{"unit",i},{"member","LatCoolEnergy"}});
    if(ptr==&row.TotCoolEnergy)out.push_back(json{{"unit",i},{"member","TotCoolEnergy"}});
    if(ptr==&row.ZoneSenHeatEnergy)out.push_back(json{{"unit",i},{"member","ZoneSenHeatEnergy"}});
    if(ptr==&row.ZoneLatHeatEnergy)out.push_back(json{{"unit",i},{"member","ZoneLatHeatEnergy"}});
    if(ptr==&row.ZoneTotHeatEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotHeatEnergy"}});
    if(ptr==&row.ZoneSenCoolEnergy)out.push_back(json{{"unit",i},{"member","ZoneSenCoolEnergy"}});
    if(ptr==&row.ZoneLatCoolEnergy)out.push_back(json{{"unit",i},{"member","ZoneLatCoolEnergy"}});
    if(ptr==&row.ZoneTotCoolEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotCoolEnergy"}});
    if(ptr==&row.OASenHeatEnergy)out.push_back(json{{"unit",i},{"member","OASenHeatEnergy"}});
    if(ptr==&row.OALatHeatEnergy)out.push_back(json{{"unit",i},{"member","OALatHeatEnergy"}});
    if(ptr==&row.OATotHeatEnergy)out.push_back(json{{"unit",i},{"member","OATotHeatEnergy"}});
    if(ptr==&row.OASenCoolEnergy)out.push_back(json{{"unit",i},{"member","OASenCoolEnergy"}});
    if(ptr==&row.OALatCoolEnergy)out.push_back(json{{"unit",i},{"member","OALatCoolEnergy"}});
    if(ptr==&row.OATotCoolEnergy)out.push_back(json{{"unit",i},{"member","OATotCoolEnergy"}});
    if(ptr==&row.HtRecSenHeatEnergy)out.push_back(json{{"unit",i},{"member","HtRecSenHeatEnergy"}});
    if(ptr==&row.HtRecLatHeatEnergy)out.push_back(json{{"unit",i},{"member","HtRecLatHeatEnergy"}});
    if(ptr==&row.HtRecTotHeatEnergy)out.push_back(json{{"unit",i},{"member","HtRecTotHeatEnergy"}});
    if(ptr==&row.HtRecSenCoolEnergy)out.push_back(json{{"unit",i},{"member","HtRecSenCoolEnergy"}});
    if(ptr==&row.HtRecLatCoolEnergy)out.push_back(json{{"unit",i},{"member","HtRecLatCoolEnergy"}});
    if(ptr==&row.HtRecTotCoolEnergy)out.push_back(json{{"unit",i},{"member","HtRecTotCoolEnergy"}});
    if(ptr==&row.SenHeatRate)out.push_back(json{{"unit",i},{"member","SenHeatRate"}});
    if(ptr==&row.LatHeatRate)out.push_back(json{{"unit",i},{"member","LatHeatRate"}});
    if(ptr==&row.TotHeatRate)out.push_back(json{{"unit",i},{"member","TotHeatRate"}});
    if(ptr==&row.SenCoolRate)out.push_back(json{{"unit",i},{"member","SenCoolRate"}});
    if(ptr==&row.LatCoolRate)out.push_back(json{{"unit",i},{"member","LatCoolRate"}});
    if(ptr==&row.TotCoolRate)out.push_back(json{{"unit",i},{"member","TotCoolRate"}});
    if(ptr==&row.ZoneSenHeatRate)out.push_back(json{{"unit",i},{"member","ZoneSenHeatRate"}});
    if(ptr==&row.ZoneLatHeatRate)out.push_back(json{{"unit",i},{"member","ZoneLatHeatRate"}});
    if(ptr==&row.ZoneTotHeatRate)out.push_back(json{{"unit",i},{"member","ZoneTotHeatRate"}});
    if(ptr==&row.ZoneSenCoolRate)out.push_back(json{{"unit",i},{"member","ZoneSenCoolRate"}});
    if(ptr==&row.ZoneLatCoolRate)out.push_back(json{{"unit",i},{"member","ZoneLatCoolRate"}});
    if(ptr==&row.ZoneTotCoolRate)out.push_back(json{{"unit",i},{"member","ZoneTotCoolRate"}});
    if(ptr==&row.OASenHeatRate)out.push_back(json{{"unit",i},{"member","OASenHeatRate"}});
    if(ptr==&row.OALatHeatRate)out.push_back(json{{"unit",i},{"member","OALatHeatRate"}});
    if(ptr==&row.OATotHeatRate)out.push_back(json{{"unit",i},{"member","OATotHeatRate"}});
    if(ptr==&row.OASenCoolRate)out.push_back(json{{"unit",i},{"member","OASenCoolRate"}});
    if(ptr==&row.OALatCoolRate)out.push_back(json{{"unit",i},{"member","OALatCoolRate"}});
    if(ptr==&row.OATotCoolRate)out.push_back(json{{"unit",i},{"member","OATotCoolRate"}});
    if(ptr==&row.HtRecSenHeatRate)out.push_back(json{{"unit",i},{"member","HtRecSenHeatRate"}});
    if(ptr==&row.HtRecLatHeatRate)out.push_back(json{{"unit",i},{"member","HtRecLatHeatRate"}});
    if(ptr==&row.HtRecTotHeatRate)out.push_back(json{{"unit",i},{"member","HtRecTotHeatRate"}});
    if(ptr==&row.HtRecSenCoolRate)out.push_back(json{{"unit",i},{"member","HtRecSenCoolRate"}});
    if(ptr==&row.HtRecLatCoolRate)out.push_back(json{{"unit",i},{"member","HtRecLatCoolRate"}});
    if(ptr==&row.HtRecTotCoolRate)out.push_back(json{{"unit",i},{"member","HtRecTotCoolRate"}});
    if(ptr==&row.TimeEconoActive)out.push_back(json{{"unit",i},{"member","TimeEconoActive"}});
    if(ptr==&row.TimeHtRecActive)out.push_back(json{{"unit",i},{"member","TimeHtRecActive"}});
    if(ptr==&row.SupplyTemp)out.push_back(json{{"unit",i},{"member","SupplyTemp"}});
    if(ptr==&row.SupplyHumRat)out.push_back(json{{"unit",i},{"member","SupplyHumRat"}});
    if(ptr==&row.MixedAirTemp)out.push_back(json{{"unit",i},{"member","MixedAirTemp"}});
    if(ptr==&row.MixedAirHumRat)out.push_back(json{{"unit",i},{"member","MixedAirHumRat"}});
    if(ptr==&row.ZoneTotHeatFuelRate)out.push_back(json{{"unit",i},{"member","ZoneTotHeatFuelRate"}});
    if(ptr==&row.ZoneTotCoolFuelRate)out.push_back(json{{"unit",i},{"member","ZoneTotCoolFuelRate"}});
    if(ptr==&row.ZoneTotHeatFuelEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotHeatFuelEnergy"}});
    if(ptr==&row.ZoneTotCoolFuelEnergy)out.push_back(json{{"unit",i},{"member","ZoneTotCoolFuelEnergy"}});
    if(ptr==&row.TotHeatFuelRate)out.push_back(json{{"unit",i},{"member","TotHeatFuelRate"}});
    if(ptr==&row.TotCoolFuelRate)out.push_back(json{{"unit",i},{"member","TotCoolFuelRate"}});
    if(ptr==&row.TotHeatFuelEnergy)out.push_back(json{{"unit",i},{"member","TotHeatFuelEnergy"}});
    if(ptr==&row.TotCoolFuelEnergy)out.push_back(json{{"unit",i},{"member","TotCoolFuelEnergy"}});

}return out;}
json int_member_matches(EnergyPlusData const&s,int const*ptr){json out=json::array();auto const&a=s.dataPurchasedAirMgr->PurchAir;if(a.allocated())for(int i=a.l();i<=a.u();++i)if(static_cast<void const*>(ptr)==static_cast<void const*>(&a(i).availStatus))out.push_back(json{{"unit",i},{"member","availStatus"}});return out;}
json registration(EnergyPlusData const&s){json out{{"dictionary",json::array()},{"live",json::array()},{"meters",json::array()}};
    for(auto const*d:s.dataOutputProcessor->ddOutVars)out["dictionary"].push_back(json{{"name",d->name},{"units",static_cast<int>(d->units)},{"timeStepType",static_cast<int>(d->timeStepType)},{"storeType",static_cast<int>(d->storeType)},{"variableType",static_cast<int>(d->variableType)},{"keyOutVarNums",d->keyOutVarNums}});
    for(auto const*v:s.dataOutputProcessor->outVars){json row{{"name",v->name},{"key",v->key},{"units",static_cast<int>(v->units)},{"timeStepType",static_cast<int>(v->timeStepType)},{"storeType",static_cast<int>(v->storeType)},{"freq",static_cast<int>(v->freq)},{"meterNums",v->meterNums},{"owner_address",pointer(v)}};
        if(auto const*r=dynamic_cast<OutputProcessor::OutVarReal const*>(v)){row["Which"]=pointer(r->Which);row["same_unit_field"]=real_member_matches(s,r->Which);row["live_value"]=r->Which?number(*r->Which):json(nullptr);}
        else if(auto const*i=dynamic_cast<OutputProcessor::OutVarInt const*>(v)){row["Which"]=pointer(i->Which);row["same_unit_field"]=int_member_matches(s,i->Which);if(!row["same_unit_field"].empty()){int u=row["same_unit_field"][0]["unit"];row["live_value"]=static_cast<int>(s.dataPurchasedAirMgr->PurchAir(u).availStatus);}else row["live_value"]=i->Which?json(*i->Which):json(nullptr);}
        out["live"].push_back(row);
    }
    for(auto const*m:s.dataOutputProcessor->meters)out["meters"].push_back(json{{"Name",m->Name},{"type",static_cast<int>(m->type)},{"resource",static_cast<int>(m->resource)},{"endUseCat",static_cast<int>(m->endUseCat)},{"group",static_cast<int>(m->group)},{"units",static_cast<int>(m->units)},{"srcVarNums",m->srcVarNums},{"srcMeterNums",m->srcMeterNums},{"CurTSValue",number(m->CurTSValue)}});
    return out;
}
json errors(EnergyPlusData const&s,std::ostringstream const&error){auto const&e=*s.dataErrTracking;return json{{"text",error.str()},{"TotalWarningErrors",e.TotalWarningErrors},{"TotalSevereErrors",e.TotalSevereErrors},{"TotalWarningErrorsDuringWarmup",e.TotalWarningErrorsDuringWarmup},{"TotalSevereErrorsDuringWarmup",e.TotalSevereErrorsDuringWarmup},{"TotalWarningErrorsDuringSizing",e.TotalWarningErrorsDuringSizing},{"TotalSevereErrorsDuringSizing",e.TotalSevereErrorsDuringSizing},{"NumRecurringErrors",e.NumRecurringErrors},{"RecurringErrors",shape(e.RecurringErrors)},{"MatchCounts",integer_array(e.MatchCounts)}};}
json context(EnergyPlusData const&s,int zone,int list,int equipment){auto const&c=s.dataZoneEquip->ZoneEquipConfig(zone);auto const&l=s.dataZoneEquip->ZoneEquipList(list);auto const&d=s.dataZoneEnergyDemand->ZoneSysEnergyDemand(zone);auto const&w=s.dataZoneEnergyDemand->ZoneSysMoistureDemand(zone);auto const&h=*s.dataHVACGlobal;auto const&g=*s.dataGlobal;
    json out{{"state_address",pointer(&s)},{"zone",zone},{"list",list},{"equipment",equipment},{"CompIndex",l.EquipIndex(equipment)},
    {"config",json{{"address",pointer(&c)},{"ZoneName",c.ZoneName},{"IsControlled",c.IsControlled},{"ZoneNode",c.ZoneNode},{"EquipListIndex",c.EquipListIndex},{"InletNode",integer_array(c.InletNode)},{"ReturnNode",integer_array(c.ReturnNode)},{"ExhaustNode",integer_array(c.ExhaustNode)}}},
    {"demand",json{{"address",pointer(&d)},{"RemainingOutputRequired",number(d.RemainingOutputRequired)},{"RemainingOutputReqToHeatSP",number(d.RemainingOutputReqToHeatSP)},{"RemainingOutputReqToCoolSP",number(d.RemainingOutputReqToCoolSP)},{"SequencedOutputRequired",shape(d.SequencedOutputRequired)},{"SequencedOutputRequiredToHeatingSP",shape(d.SequencedOutputRequiredToHeatingSP)},{"SequencedOutputRequiredToCoolingSP",shape(d.SequencedOutputRequiredToCoolingSP)}}},
    {"moisture",json{{"address",pointer(&w)},{"RemainingOutputReqToHumidSP",number(w.RemainingOutputReqToHumidSP)},{"RemainingOutputReqToDehumidSP",number(w.RemainingOutputReqToDehumidSP)},{"SequencedOutputRequired",shape(w.SequencedOutputRequired)},{"SequencedOutputRequiredToHumidSP",shape(w.SequencedOutputRequiredToHumidSP)},{"SequencedOutputRequiredToDehumidSP",shape(w.SequencedOutputRequiredToDehumidSP)}}},
    {"TimeStepSys",number(h.TimeStepSys)},{"TimeStepSysSec",number(h.TimeStepSysSec)},{"HourOfDay",g.HourOfDay},{"TimeStep",g.TimeStep},{"BeginEnvrnFlag",g.BeginEnvrnFlag},{"SysSizingCalc",g.SysSizingCalc},{"WarmupFlag",g.WarmupFlag},
    {"TempControlType",static_cast<int>(s.dataHeatBalFanSys->TempControlType(zone))},{"setptLo",number(s.dataHeatBalFanSys->zoneTstatSetpts(zone).setptLo)},{"setptHi",number(s.dataHeatBalFanSys->zoneTstatSetpts(zone).setptHi)},
    {"airHumRat",number(s.dataZoneTempPredictorCorrector->zoneHeatBalance(zone).airHumRat)},{"StdRhoAir",number(s.dataEnvrn->StdRhoAir)},{"OutBaroPress",number(s.dataEnvrn->OutBaroPress)},{"OutHumRat",number(s.dataEnvrn->OutHumRat)},
    {"DayOfYear_Schedule",s.dataEnvrn->DayOfYear_Schedule},{"DayOfWeek",s.dataEnvrn->DayOfWeek},{"DSTIndicator",s.dataEnvrn->DSTIndicator},{"HolidayIndex",s.dataEnvrn->HolidayIndex},
    {"CO2Simulation",s.dataContaminantBalance->Contaminant.CO2Simulation},{"GenericContamSimulation",s.dataContaminantBalance->Contaminant.GenericContamSimulation},
    {"GetZoneEquipmentInputFlag",s.dataZoneEquipmentManager->GetZoneEquipmentInputFlag},{"ZoneEquipInputsFilled",s.dataZoneEquip->ZoneEquipInputsFilled},{"InitZoneEquipmentOneTimeFlag",s.dataZoneEquipmentManager->InitZoneEquipmentOneTimeFlag},{"InitZoneEquipmentEnvrnFlag",s.dataZoneEquipmentManager->InitZoneEquipmentEnvrnFlag},{"GetAvailMgrInputFlag",s.dataAvail->GetAvailMgrInputFlag}};
    out["availability_allocated"]=s.dataAvail->ZoneComp.allocated();if(s.dataAvail->ZoneComp.allocated()){auto const&a=s.dataAvail->ZoneComp(DataZoneEquipment::ZoneEquipType::PurchasedAir);out["availability"]=json{{"TotalNumComp",a.TotalNumComp},{"rows",shape(a.ZoneCompAvailMgrs)}};if(a.ZoneCompAvailMgrs.allocated())for(int i=a.ZoneCompAvailMgrs.l();i<=a.ZoneCompAvailMgrs.u();++i){auto const&r=a.ZoneCompAvailMgrs(i);out["availability"]["items"].push_back(json{{"address",pointer(&r)},{"NumAvailManagers",r.NumAvailManagers},{"availStatus",static_cast<int>(r.availStatus)},{"ZoneNum",r.ZoneNum}});}}
    return out;
}
struct Factory {
    std::unique_ptr<EnergyPlusData> state;
    std::ostringstream *error=nullptr;
    int zone=0,list=0,equipment=0;
    double sensible=0.0,moisture=0.0;
};
Factory make_factory(json const&input){Factory out;out.state=std::make_unique<EnergyPlusData>();auto&s=*out.state;
    s.files.eio.open_as_stringstream();s.files.eso.open_as_stringstream();s.files.mtr.open_as_stringstream();s.files.audit.open_as_stringstream();s.files.bnd.open_as_stringstream();s.files.debug.open_as_stringstream();s.files.mtd.open_as_stringstream();s.files.edd.open_as_stringstream();
    auto error=std::make_unique<std::ostringstream>();out.error=error.get();s.files.err_stream=std::move(error);
    s.init_constant_state(s);createCoilSelectionReportObj(s);
    s.dataStrGlobals->inputFilePath=input.at("input_file").get<std::string>();
    s.dataInputProcessing->inputProcessor->processInput(s);SimulationManager::PostIPProcessing(s);s.init_state(s);
    bool found_error=false;HeatBalanceManager::GetZoneData(s,found_error);require(!found_error,"actual GetZoneData error");ZoneEquipmentManager::GetZoneEquipment(s);
    require(s.dataGlobal->NumOfZones>0,"genuine positive zone count");
    for(int z=1;z<=s.dataGlobal->NumOfZones;++z){auto const&c=s.dataZoneEquip->ZoneEquipConfig(z);if(!c.IsControlled)continue;auto list=c.EquipListIndex;require(list>0,"getter-produced EquipListIndex");auto const&l=s.dataZoneEquip->ZoneEquipList(list);for(int i=1;i<=l.NumOfEquipTypes;++i)if(l.EquipType(i)==DataZoneEquipment::ZoneEquipType::PurchasedAir){require(out.zone==0,"unit factory selects unique actual PurchasedAir component");out.zone=z;out.list=list;out.equipment=i;}}
    require(out.zone>0,"actual PurchasedAir binding exists");
    // These are genuine class allocations for the narrow caller unit, with
    // extents produced by the real Zone getter, not fabricated count/ready flags.
    s.dataZoneEnergyDemand->ZoneSysEnergyDemand.allocate(s.dataGlobal->NumOfZones);s.dataZoneEnergyDemand->ZoneSysMoistureDemand.allocate(s.dataGlobal->NumOfZones);
    s.dataZoneTempPredictorCorrector->zoneHeatBalance.allocate(s.dataGlobal->NumOfZones);s.dataHeatBalFanSys->zoneTstatSetpts.allocate(s.dataGlobal->NumOfZones);s.dataHeatBalFanSys->TempControlType.allocate(s.dataGlobal->NumOfZones);
    Avail::ManageSystemAvailability(s); // genuine first flag -> full input -> flagfalse/return
    ZoneEquipmentManager::InitZoneEquipment(s,true);OutputReportPredefined::SetPredefinedTables(s);
    s.dataSize->CurZoneEqNum=out.zone; // same actual native caller assignment before Sim
    return out;
}
void apply_phase_inputs(Factory&f,json const&input){auto&s=*f.state;
    // Actual caller phase INPUTS before the genuine InitZoneEquipment prefix.
    if(input.contains("begin_environment"))s.dataGlobal->BeginEnvrnFlag=input.at("begin_environment").get<bool>();
    if(input.contains("std_rho"))s.dataEnvrn->StdRhoAir=real(input.at("std_rho"));
    if(input.contains("pressure"))s.dataEnvrn->OutBaroPress=real(input.at("pressure"));
    if(input.contains("system_hours"))s.dataHVACGlobal->TimeStepSys=real(input.at("system_hours"));
    if(input.contains("system_seconds"))s.dataHVACGlobal->TimeStepSysSec=real(input.at("system_seconds"));
    if(input.contains("hour"))s.dataGlobal->HourOfDay=input.at("hour").get<int>();
    if(input.contains("timestep"))s.dataGlobal->TimeStep=input.at("timestep").get<int>();
    if(input.contains("day_of_year"))s.dataEnvrn->DayOfYear_Schedule=input.at("day_of_year").get<int>();
    if(input.contains("day_of_week"))s.dataEnvrn->DayOfWeek=input.at("day_of_week").get<int>();
    if(input.contains("dst"))s.dataEnvrn->DSTIndicator=input.at("dst").get<int>();
    if(input.contains("warmup"))s.dataGlobal->WarmupFlag=input.at("warmup").get<bool>();
}
void apply_inputs(Factory&f,json const&input){auto&s=*f.state;auto z=f.zone;
    // Explicit named physical/demand INPUTS at the narrow Sim caller boundary.
    // No PurchasedAir output/result fields or computed current-operation answers.
    if(input.contains("heat_demand"))s.dataZoneEnergyDemand->ZoneSysEnergyDemand(z).RemainingOutputReqToHeatSP=real(input.at("heat_demand"));
    if(input.contains("cool_demand"))s.dataZoneEnergyDemand->ZoneSysEnergyDemand(z).RemainingOutputReqToCoolSP=real(input.at("cool_demand"));
    if(input.contains("thermostat_low"))s.dataHeatBalFanSys->zoneTstatSetpts(z).setptLo=real(input.at("thermostat_low"));
    if(input.contains("thermostat_high"))s.dataHeatBalFanSys->zoneTstatSetpts(z).setptHi=real(input.at("thermostat_high"));
    if(input.contains("control_type")){int value=input.at("control_type");require(value>=0&&value<(int)HVAC::SetptType::Num,"named control enum domain");s.dataHeatBalFanSys->TempControlType(z)=static_cast<HVAC::SetptType>(value);}
    auto const&c=s.dataZoneEquip->ZoneEquipConfig(z);require(c.ZoneNode>0,"actual Config ZoneNode");
    if(input.contains("zone_temp"))s.dataLoopNodes->Node(c.ZoneNode).Temp=real(input.at("zone_temp"));
    if(input.contains("zone_humidity")){auto value=real(input.at("zone_humidity"));s.dataLoopNodes->Node(c.ZoneNode).HumRat=value;s.dataZoneTempPredictorCorrector->zoneHeatBalance(z).airHumRat=value;}
    if(input.contains("zone_temp")||input.contains("zone_humidity")){auto&n=s.dataLoopNodes->Node(c.ZoneNode);n.Enthalpy=Psychrometrics::PsyHFnTdbW(n.Temp,n.HumRat);}
    // A single actual return node is a checked property of this raw unit input,
    // never a substituted Node ordinal. Native Init will select it itself.
    require(c.NumReturnNodes==1,"finite input has one actual return node");int r=c.ReturnNode(1);require(r>0,"actual return ordinal");
    if(input.contains("return_temp"))s.dataLoopNodes->Node(r).Temp=real(input.at("return_temp"));
    if(input.contains("return_humidity"))s.dataLoopNodes->Node(r).HumRat=real(input.at("return_humidity"));
    if(input.contains("return_temp")||input.contains("return_humidity")){auto&n=s.dataLoopNodes->Node(r);n.Enthalpy=Psychrometrics::PsyHFnTdbW(n.Temp,n.HumRat);}
    Sched::UpdateScheduleVals(s); // actual current values; no observer getter/Psy call
}
json snapshot(Factory&f){auto&s=*f.state;return json{{"manager",manager(s)},{"nodes",nodes(s)},{"context",context(s,f.zone,f.list,f.equipment)},{"sizing",globals(s)},{"reports",reports(s)},{"registration",registration(s)},{"errors",errors(s,*f.error)},{"returned_sensible",number(f.sensible)},{"returned_moisture",number(f.moisture)}};}
} // namespace NativeGapBatch::PurchasedAirDetail

namespace NativeGapBatch {
nlohmann::json run_purchased_air_batch(nlohmann::json const&named_inputs){using namespace PurchasedAirDetail;
    require(named_inputs.at("schema")=="src06-purchased-air-full-function-batch-input.v1","P1 input schema");json out{{"schema","src06-purchased-air-full-function-batch-output.v1"},{"cases",json::array()}};
    for(auto const&definition:named_inputs.at("factories")){
        auto factory=make_factory(definition);auto&s=*factory.state;json result{{"factory",definition.at("name")},{"origin",definition.at("origin")},{"setup",snapshot(factory)},{"steps",json::array()}};
        std::size_t ordinal=0;
        for(auto const&step:definition.at("steps")){
            ++ordinal;auto operation=step.at("operation").get<std::string>();bool first=step.value("first_hvac_iteration",false);
            apply_phase_inputs(factory,step.at("inputs"));
            json prefix=nullptr;
            if(operation=="simulate"){
                prefix=json{{"entry",snapshot(factory)}};
                ZoneEquipmentManager::InitZoneEquipment(s,first);
                prefix["exit"]=snapshot(factory);
            }
            apply_inputs(factory,step.at("inputs"));json record{{"name",step.at("name")},{"ordinal",ordinal},{"operation",step.at("operation")},{"named_inputs",step.at("inputs")},{"actual_caller_InitZoneEquipment_prefix",prefix},{"entry",snapshot(factory)}};
            auto&list=s.dataZoneEquip->ZoneEquipList(factory.list);auto const&actual_name=list.EquipName(factory.equipment);std::string name=step.value("name_argument",actual_name);int&index=list.EquipIndex(factory.equipment);std::string error;
            try {
                if(operation=="simulate")PurchasedAirManager::SimPurchasedAir(s,name,factory.sensible,factory.moisture,first,factory.zone,index);
                else if(operation=="init")PurchasedAirManager::InitPurchasedAir(s,index,factory.zone);
                else if(operation=="calc")PurchasedAirManager::CalcPurchAirLoads(s,index,factory.sensible,factory.moisture,factory.zone);
                else if(operation=="update")PurchasedAirManager::UpdatePurchasedAir(s,index,first);
                else if(operation=="report")PurchasedAirManager::ReportPurchasedAir(s,index);
                else throw std::runtime_error("unknown full-function operation");
            }catch(std::exception const&e){error=e.what();}
            record["exception"]=error.empty()?json(nullptr):json(error);record["exit"]=snapshot(factory);result["steps"].push_back(record);
            auto expected=step.value("expected_control_outcome",std::string("normal"));require((expected=="normal"&&error.empty())||(expected=="exception"&&!error.empty()),"full Native call did not reach named control outcome");
        }
        out["cases"].push_back(result);
    }
    out["no_existing59_2336_471_suite_reexecuted"]=true;return out;
}
} // namespace NativeGapBatch

// P4 is appended after the complete accepted P1 TU, without changing its bytes.
// Only original full OutputProcessor methods produce report/meter state.
#include <EnergyPlus/ResultsFramework.hh>
#include <EnergyPlus/DataOutputs.hh>
#include <vector>

namespace NativeGapBatch::OutputProcessorDetail {
using json = nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
namespace OP = EnergyPlus::OutputProcessor;
using PurchasedAirDetail::number;
using PurchasedAirDetail::pointer;
using PurchasedAirDetail::real;
using PurchasedAirDetail::require;

struct Values {
    Real64 zone_average = 0.0;
    Real64 system_average = 0.0;
    Real64 system_energy = 0.0;
    int system_integer = 0;
    int zone_sum_integer = 0;
};

// Public ResultsFramework JSON is an actual read-only observation. Convert
// every binary64 leaf to raw bits; retain true integral/string/null types.
json raw_json(json const &value)
{
    if (value.is_number_float()) return number(value.get<double>());
    if (value.is_array()) {
        json out = json::array();
        for (auto const &item : value) out.push_back(raw_json(item));
        return out;
    }
    if (value.is_object()) {
        json out = json::object();
        for (auto it = value.begin(); it != value.end(); ++it) out[it.key()] = raw_json(it.value());
        return out;
    }
    return value;
}

json period(OP::MeterPeriod const &p)
{
    return json{{"Value", number(p.Value)}, {"MaxVal", number(p.MaxVal)}, {"MaxValDate", p.MaxValDate},
                {"MinVal", number(p.MinVal)}, {"MinValDate", p.MinValDate}, {"Rpt", p.Rpt}, {"RptFO", p.RptFO},
                {"RptNum", p.RptNum}, {"accRpt", p.accRpt}, {"accRptFO", p.accRptFO}, {"accRptNum", p.accRptNum}};
}

json frame(ResultsFramework::DataFrame const &f)
{
    require(!f.beginningOfInterval, "P4 normal frame format: beginningOfInterval=false");
    return json{{"address", pointer(&f)}, {"enabled", f.dataFrameEnabled()}, {"scanned", f.variablesScanned()},
                {"iso8601", f.iso8601}, {"beginningOfInterval", f.beginningOfInterval}, {"json", raw_json(f.getJSON())}};
}

json frames(EnergyPlusData const &s)
{
    auto const &r = *s.dataResultsFramework->resultsFramework;
    json out{{"owner_address", pointer(&r)}, {"timeSeriesEnabled", r.timeSeriesEnabled()},
             {"timeSeriesAndTabularEnabled", r.timeSeriesAndTabularEnabled()}, {"JSONEnabled", r.JSONEnabled()},
             {"CBOREnabled", r.CBOREnabled()}, {"MsgPackEnabled", r.MsgPackEnabled()}, {"RDD", r.RDD}, {"MDD", r.MDD},
             {"detailed", json::array()}, {"frequency", json::array()}, {"meters", json::array()}};
    require(!r.timeSeriesEnabled(), "P4 disabled variable-frame domain must come from real input/defaults");
    for (auto const &f : r.detailedTSData) out["detailed"].push_back(frame(f));
    for (auto const &f : r.freqTSData) out["frequency"].push_back(frame(f));
    for (auto const &f : r.Meters) {
        // MeterDataFrame owns a separate meterMap. Observe its real derived
        // whole JSON rather than interpreting the empty base variableMap.
        require(!f.beginningOfInterval, "P4 normal meter-frame format");
        out["meters"].push_back(json{{"address", pointer(&f)}, {"enabled", f.dataFrameEnabled()},
            {"scanned", f.variablesScanned()}, {"iso8601", f.iso8601}, {"beginningOfInterval", f.beginningOfInterval},
            {"whole", raw_json(f.getJSON(false))}, {"without_meter_file_only", raw_json(f.getJSON(true))}});
    }
    return out;
}

json sample_values(Values const &v)
{
    return json{{"zone_average", number(v.zone_average)}, {"system_average", number(v.system_average)},
                {"system_energy", number(v.system_energy)}, {"system_integer", v.system_integer}, {"zone_sum_integer", v.zone_sum_integer},
                {"addresses", {{"zone_average", pointer(&v.zone_average)}, {"system_average", pointer(&v.system_average)},
                               {"system_energy", pointer(&v.system_energy)}, {"system_integer", pointer(&v.system_integer)},
                               {"zone_sum_integer", pointer(&v.zone_sum_integer)}}}};
}

json outvar(OP::OutVar const &v, Values const &values)
{
    json out{{"address", pointer(&v)}, {"ddVarNum", v.ddVarNum}, {"varType", static_cast<int>(v.varType)},
        {"timeStepType", static_cast<int>(v.timeStepType)}, {"storeType", static_cast<int>(v.storeType)},
        {"Value", number(v.Value)}, {"TSValue", number(v.TSValue)}, {"EITSValue", number(v.EITSValue)},
        {"StoreValue", number(v.StoreValue)}, {"NumStored", number(v.NumStored)}, {"Stored", v.Stored},
        {"Report", v.Report}, {"tsStored", v.tsStored}, {"thisTSStored", v.thisTSStored}, {"thisTSCount", v.thisTSCount},
        {"freq", static_cast<int>(v.freq)}, {"MaxValue", number(v.MaxValue)}, {"MinValue", number(v.MinValue)},
        {"maxValueDate", v.maxValueDate}, {"minValueDate", v.minValueDate}, {"ReportID", v.ReportID},
        {"sched", pointer(v.sched)}, {"ZoneMult", v.ZoneMult}, {"ZoneListMult", v.ZoneListMult},
        {"keyColonName", v.keyColonName}, {"keyColonNameUC", v.keyColonNameUC}, {"name", v.name}, {"nameUC", v.nameUC},
        {"key", v.key}, {"keyUC", v.keyUC}, {"units", static_cast<int>(v.units)}, {"unitNameCustomEMS", v.unitNameCustomEMS},
        {"indexGroup", v.indexGroup}, {"indexGroupKey", v.indexGroupKey}, {"meterNums", v.meterNums}};
    require(v.sched == nullptr, "P4 unscheduled requests are real input facts");
    if (auto const *r = dynamic_cast<OP::OutVarReal const *>(&v)) {
        require(r->Which != nullptr, "actual real Which");
        out["Which"] = pointer(r->Which);
        out["live_value"] = number(*r->Which);
        if (r->Which == &values.zone_average) out["same_named_lvalue"] = "zone_average";
        else if (r->Which == &values.system_average) out["same_named_lvalue"] = "system_average";
        else if (r->Which == &values.system_energy) out["same_named_lvalue"] = "system_energy";
        else throw std::runtime_error("unexpected genuine real Which");
    } else if (auto const *i = dynamic_cast<OP::OutVarInt const *>(&v)) {
        require(i->Which == &values.system_integer || i->Which == &values.zone_sum_integer, "actual integer Which identity");
        out["Which"] = pointer(i->Which);
        out["live_value"] = *i->Which;
        out["same_named_lvalue"] = i->Which == &values.system_integer ? "system_integer" : "zone_sum_integer";
    } else throw std::runtime_error("unexpected actual OutVar discriminator");
    return out;
}

json output_state(EnergyPlusData const &s, Values const &values)
{
    auto const &o = *s.dataOutputProcessor;
    json out{{"owner_address", pointer(&o)}, {"NumVariablesForOutput", o.NumVariablesForOutput},
        {"MaxVariablesForOutput", o.MaxVariablesForOutput}, {"NumTotalRVariable", o.NumTotalRVariable},
        {"NumOfRVariable", o.NumOfRVariable}, {"NumOfRVariable_Setup", o.NumOfRVariable_Setup},
        {"NumOfRVariable_Sum", o.NumOfRVariable_Sum}, {"NumOfRVariable_Meter", o.NumOfRVariable_Meter},
        {"NumOfIVariable", o.NumOfIVariable}, {"NumOfIVariable_Setup", o.NumOfIVariable_Setup},
        {"NumTotalIVariable", o.NumTotalIVariable}, {"NumOfIVariable_Sum", o.NumOfIVariable_Sum},
        {"OutputInitialized", o.OutputInitialized}, {"ProduceReportVDD", static_cast<int>(o.ProduceReportVDD)},
        {"NumHoursInMonth", o.NumHoursInMonth}, {"NumHoursInSim", o.NumHoursInSim},
        {"freqStampReportNums", o.freqStampReportNums}, {"freqTrackingVariables", o.freqTrackingVariables},
        {"TimeStepZoneSec", number(o.TimeStepZoneSec)}, {"ErrorsLogged", o.ErrorsLogged}, {"isFinalYear", o.isFinalYear},
        {"GetOutputInputFlag", o.GetOutputInputFlag}, {"minimumReportFreq", static_cast<int>(o.minimumReportFreq)},
        {"ReportNumberCounter", o.ReportNumberCounter}, {"LHourP", o.LHourP}, {"LStartMin", number(o.LStartMin)},
        {"LEndMin", number(o.LEndMin)}, {"GetMeterIndexFirstCall", o.GetMeterIndexFirstCall}, {"InitFlag", o.InitFlag},
        {"Rept", o.Rept}, {"OpaqSurfWarned", o.OpaqSurfWarned}, {"MaxNumSubcategories", o.MaxNumSubcategories},
        {"maxNumEndUseSpaceTypes", o.maxNumEndUseSpaceTypes}, {"ddOutVarMap", o.ddOutVarMap}, {"meterMap", o.meterMap},
        {"apiVarRequests_size", o.apiVarRequests.size()}, {"time_values", json::array()}, {"outVars", json::array()},
        {"ddOutVars", json::array()}, {"reqVars", json::array()}, {"meters", json::array()}, {"meterValues", json::array()}};
    require(o.apiVarRequests.empty(), "P4 no positive API request producer");
    for (int i = 0; i < static_cast<int>(OP::TimeStepType::Num); ++i) {
        auto const &t = o.TimeValue[i];
        out["time_values"].push_back(json{{"address", pointer(&t)}, {"TimeStep", pointer(t.TimeStep)},
            {"value", t.TimeStep ? number(*t.TimeStep) : json(nullptr)}, {"CurMinute", number(t.CurMinute)},
            {"is_actual_zone_pointer", t.TimeStep == &s.dataGlobal->TimeStepZone},
            {"is_actual_system_pointer", t.TimeStep == &s.dataHVACGlobal->TimeStepSys}});
    }
    for (auto const *v : o.outVars) out["outVars"].push_back(outvar(*v, values));
    for (auto const *d : o.ddOutVars) out["ddOutVars"].push_back(json{{"address", pointer(d)}, {"name", d->name},
        {"timeStepType", static_cast<int>(d->timeStepType)}, {"storeType", static_cast<int>(d->storeType)},
        {"variableType", static_cast<int>(d->variableType)}, {"Next", d->Next}, {"ReportedOnDDFile", d->ReportedOnDDFile},
        {"units", static_cast<int>(d->units)}, {"unitNameCustomEMS", d->unitNameCustomEMS}, {"keyOutVarNums", d->keyOutVarNums}});
    for (auto const *r : o.reqVars) out["reqVars"].push_back(json{{"address", pointer(r)}, {"key", r->key}, {"name", r->name},
        {"freq", static_cast<int>(r->freq)}, {"sched", pointer(r->sched)}, {"Used", r->Used},
        {"is_simple_string", r->is_simple_string}, {"case_insensitive_pattern_present", bool(r->case_insensitive_pattern)}});
    for (auto const *m : o.meters) {
        require(m->type == OP::MeterType::Normal, "P4 only actual generated normal meters");
        json v{{"address", pointer(m)}, {"Name", m->Name}, {"type", static_cast<int>(m->type)},
            {"resource", static_cast<int>(m->resource)}, {"endUseCat", static_cast<int>(m->endUseCat)}, {"EndUseSub", m->EndUseSub},
            {"group", static_cast<int>(m->group)}, {"units", static_cast<int>(m->units)},
            {"RT_forIPUnits", static_cast<int>(m->RT_forIPUnits)}, {"CurTSValue", number(m->CurTSValue)},
            {"indexGroup", m->indexGroup}, {"dstMeterNums", m->dstMeterNums}, {"decMeterNum", m->decMeterNum},
            {"srcVarNums", m->srcVarNums}, {"srcMeterNums", m->srcMeterNums}, {"periods", json::array()},
            {"periodLastSM", period(m->periodLastSM)}, {"periodFinYrSM", period(m->periodFinYrSM)}};
        for (auto const &p : m->periods) v["periods"].push_back(period(p));
        out["meters"].push_back(v);
    }
    for (double v : o.meterValues) out["meterValues"].push_back(number(v));
    json enduse = PurchasedAirDetail::shape(o.EndUseCategory);
    enduse["items"] = json::array();
    for (std::size_t i = 1; i <= o.EndUseCategory.size(); ++i) {
        auto const &v = o.EndUseCategory(i);
        enduse["items"].push_back(json{{"Name", v.Name}, {"DisplayName", v.DisplayName},
            {"NumSubcategories", v.NumSubcategories}, {"SubcategoryName", PurchasedAirDetail::strings(v.SubcategoryName)},
            {"numSpaceTypes", v.numSpaceTypes}, {"spaceTypeName", PurchasedAirDetail::strings(v.spaceTypeName)}});
    }
    out["EndUseCategory"] = enduse;
    // o.stamp is an uninitialized legacy character buffer, never serialized.
    return out;
}

json context(EnergyPlusData const &s)
{
    auto const &g = *s.dataGlobal;
    auto const &h = *s.dataHVACGlobal;
    auto const &e = *s.dataEnvrn;
    json prescan = json::array();
    for (auto const &[name, keys] : s.dataOutput->OutputVariablesForSimulation) {
        json items = json::array();
        for (auto const &[key, v] : keys) items.push_back(json{{"map_key", key}, {"key", v.key}, {"variableName", v.variableName},
            {"is_simple_string", v.is_simple_string}, {"pattern_present", bool(v.pattern)},
            {"case_insensitive_pattern_present", bool(v.case_insensitive_pattern)}});
        prescan.push_back(json{{"map_name", name}, {"keys", items}});
    }
    return json{{"state_address", pointer(&s)}, {"global_address", pointer(&g)}, {"hvac_address", pointer(&h)},
        {"environment_address", pointer(&e)}, {"TimeStepZone", number(g.TimeStepZone)}, {"TimeStepSys", number(h.TimeStepSys)},
        {"TimeStepSysSec", number(h.TimeStepSysSec)}, {"MinutesInTimeStep", g.MinutesInTimeStep}, {"TimeStep", g.TimeStep},
        {"TimeStepsInHour", g.TimeStepsInHour}, {"HourOfDay", g.HourOfDay}, {"DayOfSim", g.DayOfSim},
        {"DayOfSimChr", g.DayOfSimChr}, {"CalendarYear", g.CalendarYear}, {"CalendarYearChr", g.CalendarYearChr},
        {"NumOfDayInEnvrn", g.NumOfDayInEnvrn}, {"WarmupFlag", g.WarmupFlag}, {"EndHourFlag", g.EndHourFlag},
        {"EndDayFlag", g.EndDayFlag}, {"EndEnvrnFlag", g.EndEnvrnFlag}, {"Month", e.Month}, {"DayOfMonth", e.DayOfMonth},
        {"DayOfWeek", e.DayOfWeek}, {"HolidayIndex", e.HolidayIndex}, {"DSTIndicator", e.DSTIndicator},
        {"EndMonthFlag", e.EndMonthFlag}, {"EndYearFlag", e.EndYearFlag}, {"StdOutputRecordCount", g.StdOutputRecordCount},
        {"StdMeterRecordCount", g.StdMeterRecordCount}, {"sqlite_present", bool(s.dataSQLiteProcedures->sqlite)},
        {"prescan_address", pointer(s.dataOutput.get())}, {"NumConsideredOutputVariables", s.dataOutput->NumConsideredOutputVariables},
        {"MaxConsideredOutputVariables", s.dataOutput->MaxConsideredOutputVariables}, {"prescan", prescan}};
}

json snapshot(PurchasedAirDetail::Factory &factory, Values const &values)
{
    auto &s = *factory.state;
    require(!s.dataSQLiteProcedures->sqlite, "P4 actual null SQLite constructor domain");
    return json{{"context", context(s)}, {"named_lvalues", sample_values(values)},
        {"output_processor", output_state(s, values)}, {"results_framework", frames(s)},
        {"streams", {{"eso", s.files.eso.get_output()}, {"mtr", s.files.mtr.get_output()},
                     {"eio", s.files.eio.get_output()}, {"mtd", s.files.mtd.get_output()}}},
        {"errors", PurchasedAirDetail::errors(s, *factory.error)}};
}

void apply_inputs(EnergyPlusData &s, Values &v, json const &p)
{
    require(p.is_object(), "P4 named caller-input object");
    constexpr std::string_view keys[] = {"zone_average", "system_average", "system_energy", "system_integer", "zone_sum_integer",
        "zone_hours", "system_hours", "system_seconds", "hour", "timestep", "day_of_sim", "calendar_year", "environment_days",
        "month", "day_of_month", "day_of_week", "holiday", "dst", "warmup", "end_hour", "end_day", "end_environment", "end_month", "end_year"};
    for (auto it = p.begin(); it != p.end(); ++it) {
        bool allowed = false;
        for (auto key : keys) if (it.key() == key) allowed = true;
        require(allowed, "P4 accepts only explicit caller/Which inputs, never report or meter answers");
    }
    auto &g = *s.dataGlobal;
    auto &h = *s.dataHVACGlobal;
    auto &e = *s.dataEnvrn;
    if (p.contains("zone_average")) v.zone_average = real(p.at("zone_average"));
    if (p.contains("system_average")) v.system_average = real(p.at("system_average"));
    if (p.contains("system_energy")) v.system_energy = real(p.at("system_energy"));
    if (p.contains("system_integer")) v.system_integer = p.at("system_integer").get<int>();
    if (p.contains("zone_sum_integer")) v.zone_sum_integer = p.at("zone_sum_integer").get<int>();
    if (p.contains("zone_hours")) g.TimeStepZone = real(p.at("zone_hours"));
    if (p.contains("system_hours")) h.TimeStepSys = real(p.at("system_hours"));
    if (p.contains("system_seconds")) h.TimeStepSysSec = real(p.at("system_seconds"));
    if (p.contains("hour")) g.HourOfDay = p.at("hour").get<int>();
    if (p.contains("timestep")) g.TimeStep = p.at("timestep").get<int>();
    if (p.contains("day_of_sim")) {
        g.DayOfSim = p.at("day_of_sim").get<int>();
        g.DayOfSimChr = std::to_string(g.DayOfSim);
    }
    if (p.contains("calendar_year")) {
        g.CalendarYear = p.at("calendar_year").get<int>();
        g.CalendarYearChr = std::to_string(g.CalendarYear);
    }
    if (p.contains("environment_days")) g.NumOfDayInEnvrn = p.at("environment_days").get<int>();
    if (p.contains("month")) e.Month = p.at("month").get<int>();
    if (p.contains("day_of_month")) e.DayOfMonth = p.at("day_of_month").get<int>();
    if (p.contains("day_of_week")) e.DayOfWeek = p.at("day_of_week").get<int>();
    if (p.contains("holiday")) e.HolidayIndex = p.at("holiday").get<int>();
    if (p.contains("dst")) e.DSTIndicator = p.at("dst").get<int>();
    if (p.contains("warmup")) g.WarmupFlag = p.at("warmup").get<bool>();
    if (p.contains("end_hour")) g.EndHourFlag = p.at("end_hour").get<bool>();
    if (p.contains("end_day")) g.EndDayFlag = p.at("end_day").get<bool>();
    if (p.contains("end_environment")) g.EndEnvrnFlag = p.at("end_environment").get<bool>();
    if (p.contains("end_month")) e.EndMonthFlag = p.at("end_month").get<bool>();
    if (p.contains("end_year")) e.EndYearFlag = p.at("end_year").get<bool>();
    require(g.MinutesInTimeStep > 0 && g.HourOfDay >= 1 && g.HourOfDay <= 24, "P4 actual reporting clock input bounds");
    require(e.Month >= 1 && e.Month <= 12 && e.DayOfMonth >= 1 && e.DayOfMonth <= 31, "P4 actual calendar input bounds");
    require(e.DayOfWeek >= 1 && e.DayOfWeek <= 7 && e.HolidayIndex >= 0 && e.HolidayIndex < 13, "P4 actual day-type bounds");
    require(g.TimeStepZone > 0.0 && h.TimeStepSys > 0.0, "P4 positive actual bound timestep values");
}

json run_case(json const &input)
{
    auto factory = PurchasedAirDetail::make_factory(input.at("factory"));
    auto values = std::make_unique<Values>();
    auto &s = *factory.state;
    auto &o = *s.dataOutputProcessor;
    require(o.outVars.empty() && o.ddOutVars.empty() && o.meters.empty(), "P4 real factory has no output registration producer yet");
    require(o.GetOutputInputFlag, "P4 real first request getter latch");
    require(o.TimeValue[(int)OP::TimeStepType::Zone].TimeStep == nullptr &&
            o.TimeValue[(int)OP::TimeStepType::System].TimeStep == nullptr, "P4 real unbound constructor timestep pointers");
    json out{{"name", input.at("name")}, {"origin", input.at("origin")}, {"initial", snapshot(factory, *values)},
             {"setup", json::array()}, {"steps", json::array()}};
    auto setup_call = [&](char const *name, auto &&call) {
        json event{{"operation", name}, {"entry", snapshot(factory, *values)}};
        call();
        event["exit"] = snapshot(factory, *values);
        out["setup"].push_back(event);
    };
    setup_call("SetupTimePointers.Zone", [&] { OP::SetupTimePointers(s, OP::TimeStepType::Zone, s.dataGlobal->TimeStepZone); });
    setup_call("SetupTimePointers.System", [&] { OP::SetupTimePointers(s, OP::TimeStepType::System, s.dataHVACGlobal->TimeStepSys); });
    setup_call("GetReportVariableInput", [&] { OP::GetReportVariableInput(s); });
    std::string const key = "P4 OWNER";
    setup_call("SetupOutputVariable.ZoneAverage", [&] {
        SetupOutputVariable(s, "P4 Zone Average", Constant::Units::C, values->zone_average,
                            OP::TimeStepType::Zone, OP::StoreType::Average, key);
    });
    setup_call("SetupOutputVariable.SystemAverage", [&] {
        SetupOutputVariable(s, "P4 System Average", Constant::Units::C, values->system_average,
                            OP::TimeStepType::System, OP::StoreType::Average, key);
    });
    setup_call("SetupOutputVariable.SystemEnergy", [&] {
        SetupOutputVariable(s, "P4 System Energy", Constant::Units::J, values->system_energy,
                            OP::TimeStepType::System, OP::StoreType::Sum, key, Constant::eResource::Electricity,
                            OP::Group::HVAC, OP::EndUseCat::Heating, "General", "", 2, 3);
    });
    setup_call("SetupOutputVariable.SystemInteger", [&] {
        SetupOutputVariable(s, "P4 System Integer", Constant::Units::None, values->system_integer,
                            OP::TimeStepType::System, OP::StoreType::Average, key);
    });
    setup_call("SetupOutputVariable.ZoneIntegerSum", [&] {
        SetupOutputVariable(s, "P4 Zone Sum Integer", Constant::Units::None, values->zone_sum_integer,
                            OP::TimeStepType::Zone, OP::StoreType::Sum, key);
    });
    setup_call("UpdateMeterReporting", [&] { UpdateMeterReporting(s); });
    require(o.outVars.size() == 35, "five genuine lvalues requested at all seven frequencies");
    require(!o.meters.empty() && o.meterValues.size() == o.meters.size(), "real metering setup and storage extent");
    std::size_t ordinal = 0;
    for (auto const &step : input.at("steps")) {
        apply_inputs(s, *values, step.at("inputs"));
        std::string operation = step.at("operation").get<std::string>();
        json record{{"ordinal", ++ordinal}, {"name", step.at("name")}, {"operation", operation},
                    {"named_inputs", step.at("inputs")}, {"entry", snapshot(factory, *values)}};
        if (operation == "system") UpdateDataandReport(s, OP::TimeStepType::System);
        else if (operation == "zone") UpdateDataandReport(s, OP::TimeStepType::Zone);
        else if (operation == "warmup_reset") OP::ResetAccumulationWhenWarmupComplete(s);
        else throw std::runtime_error("unknown complete P4 operation");
        record["exit"] = snapshot(factory, *values);
        out["steps"].push_back(record);
    }
    out["calls"] = ordinal;
    return out;
}
} // namespace NativeGapBatch::OutputProcessorDetail

namespace NativeGapBatch {
nlohmann::json run_output_processor_batch(nlohmann::json const &input)
{
    PurchasedAirDetail::require(input.at("schema") == "src06-output-processor-gap-input.v1", "P4 named input schema");
    nlohmann::json out{{"schema", "src06-output-processor-full-method-batch-output.v1"}, {"cases", nlohmann::json::array()}};
    for (auto const &item : input.at("cases")) out["cases"].push_back(OutputProcessorDetail::run_case(item));
    return out;
}
} // namespace NativeGapBatch

// Future gap-only air-history caller. Accepted P1 prefix remains byte-identical.
#include <EnergyPlus/HeatBalanceAirManager.hh>
#include <EnergyPlus/DataRoomAirModel.hh>

namespace NativeGapBatch::AirHistoryDetail {
using json=nlohmann::json;
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
using PurchasedAirDetail::require;
using PurchasedAirDetail::number;
using PurchasedAirDetail::pointer;
using PurchasedAirDetail::real;

json air(ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData const &a) {
    json out{{"address",pointer(&a)},{"hmThermalMassMultErrIndex",a.hmThermalMassMultErrIndex}};
    out["MAT"]=number(a.MAT);
    out["MRT"]=number(a.MRT);
    out["ZTAV"]=number(a.ZTAV);
    out["ZT"]=number(a.ZT);
    out["ZTAVComf"]=number(a.ZTAVComf);
    out["XMPT"]=number(a.XMPT);
    out["TMX"]=number(a.TMX);
    out["TM2"]=number(a.TM2);
    out["T1"]=number(a.T1);
    out["airHumRat"]=number(a.airHumRat);
    out["airHumRatAvg"]=number(a.airHumRatAvg);
    out["airHumRatTemp"]=number(a.airHumRatTemp);
    out["airHumRatAvgComf"]=number(a.airHumRatAvgComf);
    out["WTimeMinusP"]=number(a.WTimeMinusP);
    out["WMX"]=number(a.WMX);
    out["WM2"]=number(a.WM2);
    out["W1"]=number(a.W1);
    out["SumIntGain"]=number(a.SumIntGain);
    out["SumHA"]=number(a.SumHA);
    out["SumHATsurf"]=number(a.SumHATsurf);
    out["SumHATref"]=number(a.SumHATref);
    out["SumMCp"]=number(a.SumMCp);
    out["SumMCpT"]=number(a.SumMCpT);
    out["SumSysMCp"]=number(a.SumSysMCp);
    out["SumSysMCpT"]=number(a.SumSysMCpT);
    out["SumIntGainExceptPeople"]=number(a.SumIntGainExceptPeople);
    out["SumHmAW"]=number(a.SumHmAW);
    out["SumHmARa"]=number(a.SumHmARa);
    out["SumHmARaW"]=number(a.SumHmARaW);
    out["SumHmARaZ"]=number(a.SumHmARaZ);
    out["TempDepCoef"]=number(a.TempDepCoef);
    out["TempIndCoef"]=number(a.TempIndCoef);
    out["TempHistoryTerm"]=number(a.TempHistoryTerm);
    out["MCPI"]=number(a.MCPI);
    out["MCPTI"]=number(a.MCPTI);
    out["MCPV"]=number(a.MCPV);
    out["MCPTV"]=number(a.MCPTV);
    out["MCPM"]=number(a.MCPM);
    out["MCPTM"]=number(a.MCPTM);
    out["MCPE"]=number(a.MCPE);
    out["EAMFL"]=number(a.EAMFL);
    out["EAMFLxHumRat"]=number(a.EAMFLxHumRat);
    out["MCPTE"]=number(a.MCPTE);
    out["MCPC"]=number(a.MCPC);
    out["CTMFL"]=number(a.CTMFL);
    out["MCPTC"]=number(a.MCPTC);
    out["ThermChimAMFL"]=number(a.ThermChimAMFL);
    out["MCPTThermChim"]=number(a.MCPTThermChim);
    out["MCPThermChim"]=number(a.MCPThermChim);
    out["latentGain"]=number(a.latentGain);
    out["latentGainExceptPeople"]=number(a.latentGainExceptPeople);
    out["OAMFL"]=number(a.OAMFL);
    out["VAMFL"]=number(a.VAMFL);
    out["NonAirSystemResponse"]=number(a.NonAirSystemResponse);
    out["SysDepZoneLoads"]=number(a.SysDepZoneLoads);
    out["SysDepZoneLoadsLagged"]=number(a.SysDepZoneLoadsLagged);
    out["MDotCPOA"]=number(a.MDotCPOA);
    out["MDotOA"]=number(a.MDotOA);
    out["MixingMAT"]=number(a.MixingMAT);
    out["MixingHumRat"]=number(a.MixingHumRat);
    out["MixingMassFlowZone"]=number(a.MixingMassFlowZone);
    out["MixingMassFlowXHumRat"]=number(a.MixingMassFlowXHumRat);
    out["setPointLast"]=number(a.setPointLast);
    out["tempIndLoad"]=number(a.tempIndLoad);
    out["tempDepLoad"]=number(a.tempDepLoad);
    out["airRelHum"]=number(a.airRelHum);
    out["AirPowerCap"]=number(a.AirPowerCap);
    out["XMAT"]=json::array();for(double value:a.XMAT)out["XMAT"].push_back(number(value));
    out["DSXMAT"]=json::array();for(double value:a.DSXMAT)out["DSXMAT"].push_back(number(value));
    out["WPrevZoneTS"]=json::array();for(double value:a.WPrevZoneTS)out["WPrevZoneTS"].push_back(number(value));
    out["DSWPrevZoneTS"]=json::array();for(double value:a.DSWPrevZoneTS)out["DSWPrevZoneTS"].push_back(number(value));
    out["ZTM"]=json::array();for(double value:a.ZTM)out["ZTM"].push_back(number(value));
    out["WPrevZoneTSTemp"]=json::array();for(double value:a.WPrevZoneTSTemp)out["WPrevZoneTSTemp"].push_back(number(value));
    return out;
}

json state(PurchasedAirDetail::Factory &factory) {
    auto &s=*factory.state;
    auto const &zones=s.dataZoneTempPredictorCorrector->zoneHeatBalance;
    auto const &spaces=s.dataZoneTempPredictorCorrector->spaceHeatBalance;
    auto const &models=s.dataRoomAir->AirModel;
    json zone_rows=PurchasedAirDetail::shape(zones);zone_rows["items"]=json::array();
    for(std::size_t i=1;i<=zones.size();++i)zone_rows["items"].push_back(air(zones(i)));
    json space_rows=PurchasedAirDetail::shape(spaces);space_rows["items"]=json::array();
    for(std::size_t i=1;i<=spaces.size();++i)space_rows["items"].push_back(air(spaces(i)));
    json model_rows=PurchasedAirDetail::shape(models);model_rows["items"]=json::array();
    for(std::size_t i=1;i<=models.size();++i){auto const &m=models(i);model_rows["items"].push_back(json{
        {"address",pointer(&m)},{"Name",m.Name},{"ZoneName",m.ZoneName},{"ZonePtr",m.ZonePtr},
        {"AirModel",static_cast<int>(m.AirModel)},{"TempCoupleScheme",static_cast<int>(m.TempCoupleScheme)},
        {"SimAirModel",m.SimAirModel}});}
    json zone_metadata=json::array();
    for(int i=1;i<=s.dataGlobal->NumOfZones;++i){auto const &z=s.dataHeatBal->Zone(i);zone_metadata.push_back(json{
        {"address",pointer(&z)},{"ordinal",i},{"Name",z.Name},{"Multiplier",z.Multiplier},{"ListMultiplier",z.ListMultiplier},
        {"spaceIndexes",z.spaceIndexes}});}
    return json{{"P1_owners",PurchasedAirDetail::snapshot(factory)},
        {"zoneHeatBalance",zone_rows},{"spaceHeatBalance",space_rows},{"AirModel",model_rows},
        {"anyNonMixingRoomAirModel",s.dataRoomAir->anyNonMixingRoomAirModel},
        {"GetAirModelData",s.dataRoomAir->GetAirModelData},
        {"doSpaceHeatBalance",s.dataHeatBal->doSpaceHeatBalance},
        {"doSpaceHeatBalanceSimulation",s.dataHeatBal->doSpaceHeatBalanceSimulation},
        {"doSpaceHeatBalanceSizing",s.dataHeatBal->doSpaceHeatBalanceSizing},
        {"ZoneAirSolutionAlgo",static_cast<int>(s.dataHeatBal->ZoneAirSolutionAlgo)},
        {"NumOfZones",s.dataGlobal->NumOfZones},{"Zone_metadata",zone_metadata},
        {"RoomAir_owner_address",pointer(s.dataRoomAir.get())},
        {"predictor_owner_address",pointer(s.dataZoneTempPredictorCorrector.get())}};
}

void apply_inputs(PurchasedAirDetail::Factory &factory,json const &input) {
    auto &s=*factory.state;
    require(input.is_object(),"history primary caller input object");
    constexpr std::string_view allowed[]={"MAT","ZT","ZTAV","airHumRatAvg","airHumRatTemp","pressure"};
    for(auto it=input.begin();it!=input.end();++it){bool found=false;for(auto key:allowed)if(key==it.key())found=true;
        require(found,"history accepts only external air/pressure inputs, never histories or computed answers");}
    auto &a=s.dataZoneTempPredictorCorrector->zoneHeatBalance(factory.zone);
    if(input.contains("MAT"))a.MAT=real(input.at("MAT"));
    if(input.contains("ZT"))a.ZT=real(input.at("ZT"));
    if(input.contains("ZTAV"))a.ZTAV=real(input.at("ZTAV"));
    if(input.contains("airHumRatAvg"))a.airHumRatAvg=real(input.at("airHumRatAvg"));
    if(input.contains("airHumRatTemp"))a.airHumRatTemp=real(input.at("airHumRatTemp"));
    if(input.contains("pressure"))s.dataEnvrn->OutBaroPress=real(input.at("pressure"));
}

json run_case(json const &input) {
    auto factory=PurchasedAirDetail::make_factory(input.at("factory"));auto &s=*factory.state;
    require(!s.dataRoomAir->AirModel.allocated(),"real P1 factory precedes RoomAir getter");
    json out{{"name",input.at("name")},{"origin",input.at("origin")},
        {"before_real_RoomAir_getter",state(factory)},{"steps",json::array()}};
    bool errors=false;
    HeatBalanceAirManager::GetRoomAirModelParameters(s,errors);
    require(!errors,"actual RoomAir input getter succeeds");
    require(s.dataRoomAir->AirModel.allocated() && static_cast<int>(s.dataRoomAir->AirModel.size())==s.dataGlobal->NumOfZones,"real getter model allocation");
    require(!s.dataRoomAir->anyNonMixingRoomAirModel && !s.dataHeatBal->doSpaceHeatBalance,"actual finite mixed zone branch");
    require(s.dataHeatBal->ZoneAirSolutionAlgo==DataHeatBalance::SolutionAlgo::ThirdOrder,"actual finite ThirdOrder branch");
    for(auto const &m:s.dataRoomAir->AirModel)require(m.AirModel==RoomAir::RoomAirModel::Mixing,"actual getter mixing row");
    out["after_real_RoomAir_getter"]=state(factory);
    std::size_t ordinal=0;
    for(auto const &step:input.at("steps")){
        AirHistoryDetail::apply_inputs(factory,step.at("inputs"));auto operation=step.at("operation").get<std::string>();
        json record{{"ordinal",++ordinal},{"name",step.at("name")},{"operation",operation},
            {"named_inputs",step.at("inputs")},{"entry",state(factory)}};
        if(operation=="push_zone")ZoneTempPredictorCorrector::PushZoneTimestepHistories(s);
        else if(operation=="push_system")ZoneTempPredictorCorrector::PushSystemTimestepHistories(s);
        else if(operation=="revert_zone")ZoneTempPredictorCorrector::RevertZoneTimestepHistories(s);
        else throw std::runtime_error("unknown original full history operation");
        record["exit"]=state(factory);out["steps"].push_back(record);
    }
    require(ordinal==10,"all accepted/trial/revert/retry operations retained");
    return out;
}
} // namespace NativeGapBatch::AirHistoryDetail
namespace NativeGapBatch {
nlohmann::json run_air_history_batch(nlohmann::json const &input) {
    PurchasedAirDetail::require(input.at("schema")=="src06-air-history-original-core-input.v1","history schema");
    nlohmann::json out{{"schema","src06-air-history-original-core-output.v1"},{"cases",nlohmann::json::array()}};
    for(auto const &item:input.at("cases"))out["cases"].push_back(AirHistoryDetail::run_case(item));
    return out;
}
} // namespace NativeGapBatch

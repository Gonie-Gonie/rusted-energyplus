"""Close finite Native compile-failure/correction sources; no scientific/source change."""
from pathlib import Path
import copy,hashlib,json,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OLD=D/'P4-history-publication-draft-Peer-54';O=D/'P4-history-publication-draft-Peer-54-03'
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix()if p.is_relative_to(R)else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert ref(p)==v;return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();original=read(OLD/'manifest.json');oldwhite=read(checked(original['finite_whitelist']));rows={x['source']['path']:copy.deepcopy(x)for x in oldwhite['entries']}
 def add(v,purpose):
  p=checked(v);assert p.suffix.lower()not in ['.zip','.exe','.dll','.obj','.a','.map','.rlib','.rmeta'];assert'source-objects'not in p.as_posix()and'frozen-environment'not in p.name
  a=ref(p)
  if a['path']in rows:assert rows[a['path']]['source']==a;return
  rows[a['path']]=dict(source=a,archive_path=a['path']if p.is_relative_to(R)else'external-metadata/'+a['sha256']+'/'+p.name,purposes=[purpose])
 failed=read(D/'original-core-gap-batch-build-Root-05/native-build.json')
 for command in failed['compiles']:
  add(command,'Actual retained Native failed build command receipt');doc=read(checked(command))
  for k in ['stdout','stderr']:add(doc[k],'Actual retained Native failed build complete log')
 corr=read(D/'Native-history-ADL-fix-Peer-04/correction.json')
 for k in ['before_fragment','proposed_fragment','before_combined','proposed_combined','author_Source']:add(corr[k],'Exact history ADL correction original/proposed source')
 for pair in corr['diffs'].values():
  for v in pair.values():add(v,'Exact history ADL correction forward/inverse')
 p4=read(D/'output-processor-Native-P4-draft-Audit-01/draft.json');add(p4['appended_P4_only_fragment'],'Original full P4 appended method caller')
 add(ref(Path(__file__)),'Finite-publication only Native closure extension author')
 total=sum(x['source']['bytes']for x in rows.values());assert total<110*1024*1024
 white=save(O/'finite-whitelist.json',dict(schema='src06-P4-history54-finite-whitelist.v2',entries=sorted(rows.values(),key=lambda x:x['source']['path']),uncompressed_bytes=total,exclusions=oldwhite['exclusions'],original_finite_whitelist=original['finite_whitelist'],author_Source=ref(Path(__file__))))
 archive=O/'evidence.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for row in sorted(rows.values(),key=lambda x:x['archive_path']):
   info=zipfile.ZipInfo(row['archive_path'],date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,checked(row['source']).read_bytes())
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and set(z.namelist())=={x['archive_path']for x in rows.values()}
  for row in rows.values():b=z.read(row['archive_path']);assert len(b)==row['source']['bytes']and hashlib.sha256(b).hexdigest()==row['source']['sha256']
 oldtemplate=read(checked(original['template']));new=copy.deepcopy(oldtemplate);new.update(schema='src06-P4-history54-private-publication-template.v2',finite_archive=ref(archive),finite_whitelist=white,author_Source=ref(Path(__file__)))
 assert new['summary']==oldtemplate['summary']
 template=save(O/'template.json',new);closure=save(O/'finite-Native-closure.json',dict(schema='src06-P4-history54-finite-closure-only.v1',original_preparation=ref(OLD/'manifest.json'),original_entries=len(oldwhite['entries']),current_entries=len(rows),all_original_entries_whole_unchanged=True,only_additions=[v['source']for k,v in sorted(rows.items())if k not in{x['source']['path']for x in oldwhite['entries']}],scientific_summary_and_claims_exact=True,no_original_zip_recursion=True))
 manifest=save(O/'manifest.json',dict(schema='src06-P4-history54-private-publication-preparation.v2',status='READY_PRIVATE_NO_PUBLICATION',template=template,archive=ref(archive),finite_whitelist=white,finite_entries=len(rows),uncompressed_bytes=total,all_ZIP_CRC_size_SHA_checked=True,actual_review=original['actual_review'],prior_shared_body_impact_bridge=original['prior_shared_body_impact_bridge'],curated_doc_suggestions=original['curated_doc_suggestions'],original_preparation=ref(OLD/'manifest.json'),finite_closure_only=closure,canonical_docs_Source_Git_Cargo_or_Native_mutations=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,template=template,archive=ref(archive),whitelist=white,entries=len(rows),uncompressed_bytes=total,closure=closure)))
if __name__=='__main__':main()

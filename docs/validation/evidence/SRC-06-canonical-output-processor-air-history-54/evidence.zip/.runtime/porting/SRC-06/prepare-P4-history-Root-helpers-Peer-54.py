"""Freeze/read-only preflight of Root54 helpers; never applies Sources or runs Cargo."""
from pathlib import Path
import ast,difflib,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'P4-history-Root-helpers-ready-Peer-54'
def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 h=load(D/'gap-P4-history-guards-Peer-54.py','Root54_helpers_readonly');g=h.g
 g.need(not O.exists(),'Fresh immutable Root54 helper preparation');O.mkdir()
 def save(path,value):
  path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n');return g.ref(path)
 draft_ref=g.ref(D/'source-Propane-P4-history-coherent-draft-Peer-01/draft.json');draft=g.read(g.checked(draft_ref))
 script_names=['gap-P4-history-guards-Peer-54.py','apply-P4-history-gap-batch-Root-54.py','launch-P4-history-gap-batch-Root-54.py']
 parents=[None,'apply-Source-gap-batch-Root-50.py','launch-Source-gap-batch-Root-50.py'];delta=[];apply=g.literal()
 for name,parent in zip(script_names,parents):
  path=D/name;new=path.read_bytes();ast.parse(new.decode('utf-8'));g.need(b'\r' not in new,'New helper LF bytes')
  old=(D/parent).read_bytes() if parent else b'';diffs={}
  for kind,a,b in [('forward',old,new),('inverse',new,old)]:
   p=O/(name+'.'+kind+'.diff');p.write_text(''.join(difflib.unified_diff(a.decode('utf-8').splitlines(keepends=True),b.decode('utf-8').splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');g.need(apply(a,p.read_bytes())==b,'Full helper literal '+kind);diffs[kind]=g.ref(p)
  delta.append(dict(before=g.ref(D/parent) if parent else None,proposed=g.ref(path),diffs=diffs,syntax_only=True))
 delta_ref=save(O/'helper-full-parent-forward-inverse.json',dict(schema='src06-Root54-helper-full-parent-deltas.v1',files=delta,literal_applications=6,Python_syntax_parses=3,execution=False))
 p=dict(schema='src06-P4-history-Root54-preparation.v1',status='READY_FOR_ROOT_ONE_APPLICATION_TWO_SELECTED_GROUPS',base_HEAD=draft['base_HEAD'],draft=draft_ref,
  joint_independent_peer=g.ref(D/'Root-P4-history-union-independent-review-01/review.json'),history_independent_peer=g.ref(D/'Peer-Source-air-history-review-Audit-01/review.json'),original_P4_Source_peer=g.ref(D/'Root-Source-P4-scaffold-independent-review-01/review.json'),
  P4_fixture_proof=g.ref(D/'source-output-processor-runtime-fixture-Audit-01/projection.json'),history_fixture_proof=g.ref(D/'source-air-history-runtime-fixture-Peer-01/projection.json'),
  prior_compiler_plan=draft['prior_complete_compiler_Source_plan'],complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'],
  guard_Source=g.ref(D/script_names[0]),application_Source=g.ref(D/script_names[1]),launch_Source=g.ref(D/script_names[2]),environment_guard=g.ref(D/'hard-size-command-guards-Peer-43.py'),record_command_Source=g.ref(R/'tools/porting/record_command.py'),
  inherited_guard_dependencies=[g.ref(D/x)for x in ['apply-Source-gap-batch-Root-50.py','apply-purchased-air-gap-cohort-Root-P1.py','seal-compact-annual-daygroup-helper-Peer-01.py']],helper_full_deltas=delta_ref,
  expected_before=dict(compiler_inputs=4534,Rust_sources=4521),expected_after=dict(compiler_inputs=4538,Rust_sources=4525,Source_files=21,existing=17,new=4),
  exact_application_receipt_path='.runtime/porting/SRC-06/Root-Propane-P4-history-application-54/receipt.json',selected_groups_in_order=['output_processor','air_history'],
  focused_command_outputs=['.runtime/porting/SRC-06/canonical-source-gap-batch-'+x+'-Root-54'for x in ['output_processor','air_history']],
  historical_pending_fields_resolution='Original21/20 drafts remain immutable with contemporaneous pending labels. This READY binds the actual later RootP4 Source peer, full history peer and accepted actual P4/history fixtures; no historical execution claim is rewritten.',
  qualifications=['One Root-only application then two fresh selected process-main groups. No prior P1/Surface/2336/471/59/P2 body replay.','No Source numerical PASS is claimed by this preparation. Native P4/history results are genuine actual outputs and remain expected-only external fixtures.','Production Propane/IHG extension is carried with its independent semantic peer; these focused operations do not certify whole annual endrun or IHG producer coverage.'],canonical_Cargo_Native_or_test_execution=False,author_Source=g.ref(Path(__file__)))
 pr=save(O/'prepared.json',p);_,pp,dd,union=h.prepared(pr['path']+'#'+pr['sha256']);h.current_head(p['base_HEAD'])
 g.need(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'Current committed clean Source53 parent')
 old=g.read(g.checked(p['prior_compiler_plan']));oldrows={x['path']:x for x in old['entries']};g.need((old['inputs'],old['Rust_sources'],len(oldrows))==(4534,4521,4534),'Before complete plan counts');g.exact(oldrows)
 final=g.read(g.checked(p['complete_compiler_plan']));rows={x['path']:x for x in final['entries']};g.need((final['compiler_inputs'],final['Rust_sources'],len(rows))==(4538,4525,4538),'After complete plan counts')
 overlay={name:(x['final_sha256'],x['final_bytes'])for name,x in oldrows.items()}
 for f in dd['files']:
  name=f['canonical_path'];before=g.checked(f['before']).read_bytes() if f['before'] else b'';after=g.checked(f['proposed']).read_bytes();g.need((R/name).exists()==bool(f['before']),'Target exact existence '+name)
  if f['before']:g.need((R/name).read_bytes()==before and subprocess.check_output(['git','show','HEAD:'+name],cwd=R)==before,'Selected current/Git parent '+name)
  g.need(apply(before,g.checked(f['diffs']['forward']).read_bytes())==after and apply(after,g.checked(f['diffs']['inverse']).read_bytes())==before,'Selected42 whole literal applications '+name);overlay[name]=(f['proposed']['sha256'],f['proposed']['bytes'])
 g.need(overlay=={name:(x['final_sha256'],x['final_bytes'])for name,x in rows.items()},'Entire final plan is exact selected21 overlay')
 fixture_map,protected=h.fixtures(pp,dd,union);g.need(set(fixture_map)=={'purchased_air','surface','output_processor','air_history'},'All four external fixtures protected')
 preflight=save(O/'read-only-preflight.json',dict(schema='src06-Root54-readonly-helper-preflight.v1',accepted=True,findings=[],prepared=pr,current4534_compiler_inputs_exact=True,selected17_Git_and_live_exact=True,all42_selected_literal_applications_exact=True,final4538_plan_exact_overlay=True,four_runtime_fixtures=fixture_map,protected_refs=len(protected),helper_literal_applications=6,Python_syntax_parses=3,canonical_Cargo_Native_or_test_execution=False))
 print(json.dumps(dict(prepared=pr,preflight=preflight,helper_deltas=delta_ref,guard=p['guard_Source'],application=p['application_Source'],launch=p['launch_Source'])))
if __name__=='__main__':main()

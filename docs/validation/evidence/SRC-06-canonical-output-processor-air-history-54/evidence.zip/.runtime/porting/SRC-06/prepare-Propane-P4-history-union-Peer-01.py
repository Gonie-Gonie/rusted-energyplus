"""Private exact accepted20 plus history3 composition; no canonical writes/tests."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Propane-P4-history-coherent-draft-Peer-01'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();union_path=D/'source-Propane-P4-coherent-draft-Audit-01/draft.json';union=read(union_path);history_path=D/'source-air-history-gap-scaffold-Peer-01/draft.json';history=read(history_path)
 peer_path=D/'Root-Propane-P4-union-independent-review-02/review.json';peer=read(peer_path);assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==ref(union_path)
 parent_ref=history['prior_compiler_plan'];assert parent_ref==union['prior_complete_compiler_Source_plan'];parent=read(checked(parent_ref));pr={x['path']:x for x in parent['entries']};assert len(pr)==4534
 for name,row in pr.items():a=ref(R/name);assert(a['sha256'],a['bytes'])==(row['final_sha256'],row['final_bytes']),name
 u={x['canonical_path']:x for x in union['files']};h={x['canonical_path']:x for x in history['files']};overlap=set(u)&set(h);assert len(u)==20 and len(h)==3 and len(overlap)==2
 parent_name='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs';root_name='crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs';assert overlap=={parent_name,root_name}
 materials={};proof=[]
 for name in sorted(set(u)|set(h)):
  if name not in overlap:materials[name]=checked((u.get(name)or h[name])['proposed']).read_bytes();continue
  base=(R/name).read_bytes();a=checked(u[name]['proposed']).read_bytes();b=checked(h[name]['proposed']).read_bytes()
  if name==parent_name:
   p4_hook=b'\nmod output_processor;\n';history_hook=b'\nmod air_history;\n';assert a==base+p4_hook and b==base+history_hook
   joined=a+history_hook;assert joined.replace(history_hook,b'',1)==a and joined.replace(p4_hook,b'',1)==b
  else:
   old=b'"purchased_air"|"surface"|"exterior"';p4=old+b'|"output_processor"';hist=old+b'|"air_history"';both=p4+b'|"air_history"'
   history_branch=b'        "air_history"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_air_history_cohort(&fixture),\n'
   p4_branch=b'        "output_processor"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_output_processor_cohort(&fixture),\n';surface=b'        "surface"=>surface::run(&fixture),\n'
   assert a.count(p4)==1 and a.count(surface)==1;joined=a.replace(p4,both).replace(surface,surface+history_branch)
   assert joined.replace(both,p4).replace(history_branch,b'',1)==a
   assert joined.replace(both,hist).replace(p4_branch,b'',1)==b
   assert a.replace(p4,old).replace(p4_branch,b'',1)==base and b.replace(hist,old).replace(history_branch,b'',1)==base
  materials[name]=joined;proof.append(dict(canonical_path=name,parent=ref(R/name),reviewed_P4=u[name]['proposed'],reviewed_history=h[name]['proposed'],removing_history_delta_recovers_entire_P4_whole=True,removing_P4_delta_recovers_entire_history_whole=True,all_old_functions_and_selected_P1_Surface_branches_whole_unchanged=True))
 files=[]
 for at,(name,content)in enumerate(sorted(materials.items()),1):
  target=O/'proposed'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content);before=None;a=b''
  if name in pr:
   a=(R/name).read_bytes();bp=O/'before'/name;bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(a);before=ref(bp);assert subprocess.check_output(['git','show','HEAD:'+name],cwd=R)==a
  else:assert not (R/name).exists()
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=content,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
  so=O/'syntax'/(str(at)+'.stdout.rs');so.parent.mkdir(exist_ok=True);se=so.with_suffix('.stderr');so.write_bytes(parse.stdout);se.write_bytes(parse.stderr)
  row=dict(canonical_path=name,before_absent=before is None,before=before,proposed=ref(target),Source_only_parse=dict(exit_code=0,stdout=ref(so),stderr=ref(se),qualification='Fresh syntax only, not contextual compilation'))
  row['diffs']={}
  for key,x,y in [('forward',a,content),('inverse',content,a)]:
   p=O/'diffs'/(str(at)+'.'+key+'.diff');p.parent.mkdir(exist_ok=True);p.write_text(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');row['diffs'][key]=ref(p)
  files.append(row)
 assert len(files)==21 and sum(x['before_absent']for x in files)==4
 for name in set(u)-overlap:assert materials[name]==checked(u[name]['proposed']).read_bytes()
 for name in set(h)-overlap:assert materials[name]==checked(h[name]['proposed']).read_bytes()
 plan=copy.deepcopy(read(checked(union['complete_proposed_compiler_Source_plan'])));entry={x['path']:x for x in plan['entries']}
 for f in files:
  name=f['canonical_path'];row=entry.get(name)
  if row is None:row=dict(path=name,origin='new cfg-only full history adapter');plan['entries'].append(row)
  row.update(source=f['proposed'],final_sha256=f['proposed']['sha256'],final_bytes=f['proposed']['bytes'])
 plan['entries'].sort(key=lambda x:x['path']);assert len(plan['entries'])==4538
 plan.update(schema='src06-Propane-P4-history-complete-private-overlay.v1',compiler_inputs=4538,Rust_sources=4525,selected=21,existing=17,new=4,prior_complete_compiler_Source_plan=parent_ref,expected_fixture_absent=False,expected_P4_fixture_pending=True,history_fixture_external=ref(D/'source-air-history-runtime-fixture-Peer-01/fixture.json'))
 pp=save(O/'complete-proposed-compiler-Source-plan.json',plan);shared=save(O/'literal-two-hook-union-proof.json',dict(schema='src06-private-P4-history-two-shared-hook-composition.v1',shared=proof,all_other18_union_wholes_and_one_history_child_whole_identical=True,full_old_P1_Parent_prefix_unchanged=True,shared_selector_branches_only=True,expected_or_numeric_state_seeded=False))
 draft=save(O/'draft.json',dict(schema='src06-Propane-P4-history-coherent-private-draft.v1',status='FROZEN_PRIVATE_WAIT_HISTORY_FULL_PEER_AND_ACTUAL_P4_EXPECTED_FIXTURE',base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),files=files,Source_count=21,existing=17,new=4,literal_applications=42,fresh_Source_only_parses=21,prior_complete_compiler_Source_plan=parent_ref,complete_proposed_compiler_Source_plan=pp,
  accepted_Propane_P4_union=ref(union_path),independent_Propane_P4_union_peer=ref(peer_path),original_production_peer=union['independent_production_peer'],original_P4_Source_peer=union['P4_independent_Source_peer'],history_scaffold=ref(history_path),history_full_semantic_peer='WAIT_RESP_FULL_HISTORY_PEER',literal_shared_hook_union=shared,history_actual_Native=history['actual_Native_history'],history_runtime_fixture=ref(D/'source-air-history-runtime-fixture-Peer-01/fixture.json'),history_fixture_projection=ref(D/'source-air-history-runtime-fixture-Peer-01/projection.json'),
  qualifications=['Only literal shared mod/selector/branch composition; all independent scientific/production scopes remain separately qualified.','P4 actual Native output/fixture and Source contextual/runtime scientific checks still pending. History actual Native40calls admitted, Source replay not executed.','Root will perform one coherent canonical application/compile then only selectedOP/history comparisons; priorP1/Surface/2336/471/59/P2body comparisons are not rerun.'],canonical_Cargo_Native_or_test_execution=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(draft=draft,plan=pp,shared_proof=shared,Source_count=21,existing=17,new=4)))
if __name__=='__main__':main()

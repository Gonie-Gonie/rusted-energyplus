"""Private finite Source54 evidence/archive/template; no canonical/docs/Git writes."""
from pathlib import Path
import difflib,hashlib,json,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'P4-history-publication-draft-Peer-54'
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix()if p.is_relative_to(R)else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256']and a['bytes']==v.get('bytes',v.get('size_bytes',a['bytes']));return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();actual_path=D/'Root-Source-P4-history-actual-review-54/review.json';actual=read(actual_path);assert ref(actual_path)['sha256']=='027391ad8d8b5f4bb2940390dfe774006f37c11623f38df161db9876ece34719'
 assert actual['accepted']and not actual['findings']and(actual['full_calls'],actual['Source_exact_raw_bit_state_observations'])==(78,57553)
 app=read(checked(actual['application']));prepared=read(checked(actual['prepared']));draft=read(checked(prepared['draft']));union=read(checked(draft['accepted_Propane_P4_union']));history=read(checked(draft['history_scaffold']));p4=read(checked(union['original_P4_scaffold']));production=read(checked(union['original_production_draft']));plan=read(checked(actual['complete_compiler_plan']));current={x['path']:x for x in plan['entries']};assert len(current)==4538
 rows={}
 def add(v,purpose):
  p=checked(v);a=ref(p);assert p.is_file()and p.suffix.lower()not in ['.zip','.exe','.dll','.obj','.a','.map','.rlib','.rmeta']and a['bytes']<32*1024*1024
  assert 'source-objects'not in p.as_posix()and 'frozen-environment'not in p.name.casefold()and not p.name.endswith('.observation.json')
  if p.suffix.lower()=='.json':
   value=read(p);assert not isinstance(value,dict)or not any(k in value for k in ['full_explicit_environment','environment'])
  name=a['path'];arc=name if p.is_relative_to(R)else'external-metadata/'+a['sha256']+'/'+p.name
  if name in rows:assert rows[name]['source']==a;rows[name]['purposes']=sorted(set(rows[name]['purposes']+[purpose]))
  else:rows[name]=dict(source=a,archive_path=arc,purposes=[purpose])
 def file(p,purpose):add(ref(p),purpose)
 def refs(v,purpose):
  # Traverse only an explicitly selected in-memory field. Never recursively open referenced documents.
  if isinstance(v,dict):
   if 'path'in v and'sha256'in v:add(v,purpose)
   else:
    for x in v.values():refs(x,purpose)
  elif isinstance(v,list):
   for x in v:refs(x,purpose)
 for p in [actual_path,Path(__file__),D/'check-Source-P4-history-actual-Root-54.py',D/'check-Source-P4-history-actual-Root-54-02.py']:
  file(p,'Accepted actual review/checker plus preserved metadata-only checker precheck')
 for k in ['application','prepared','complete_compiler_plan','original_Propane_production_peer','joint_independent_peer','history_independent_peer','P4_independent_peer','inherited_environment_guard','record_command_Source','Source_launch']:add(actual[k],'Actual current application/full plan/independent scopes/helpers')
 for k in ['draft','prior_compiler_plan','guard_Source','application_Source','launch_Source','history_fixture_proof','P4_fixture_proof','helper_full_deltas','author_Source']:add(prepared[k],'Root54 preparation/helpers/exact fixture provenance')
 refs(prepared['inherited_guard_dependencies'],'Exact inherited guard function Sources')
 helper_delta=read(checked(prepared['helper_full_deltas']));refs(helper_delta['files'],'Full accepted helper parent/forward/inverse deltas')
 file(D/'P4-history-Root-helpers-ready-Peer-54/read-only-preflight.json','Read-only complete-parent/overlay/helper/fixture preflight')
 for k in ['accepted_Propane_P4_union','independent_Propane_P4_union_peer','history_scaffold','literal_shared_hook_union','author_Source']:add(draft[k],'Exact21 composition and original20/history3 scopes')
 for k in ['original_production_draft','independent_production_peer','original_P4_scaffold','literal_shared_file_union','complete_proposed_compiler_Source_plan','author_Source']:add(union[k],'Original20 composition/production/P4 scopes')
 assert len(draft['files'])==21
 for row in draft['files']:
  name=row['canonical_path'];a=ref(R/name);assert(a['sha256'],a['bytes'])==(current[name]['final_sha256'],current[name]['final_bytes']);add(a,'Current selected21 Source whole');refs(row,'Selected21 exact before/proposed/forward/inverse and syntax provenance')
 for doc,label in [(history,'History3'),(p4,'P4 scaffold12'),(production,'Production Propane14')]:
  for key in ['author_Source','observation_coverage','whole_target_API_census','primary_input_projection_proof','input_only','owner_field_readset','field_readset','constructor_producer_ledger','integration_contract']:
   if key in doc:refs(doc[key],label+' bounded owner/input/readset/author')
  for authority in doc.get('Native_authorities',[]):
   add(authority['whole'],label+' pinned Native whole authority')
   for extent in authority.get('extents',[]):
    source=extent.get('source',extent.get('excerpt'))
    if source:add(source,label+' strict Native readset extent')
 # One copy of each new whole fixture; these already contain entire Native output.
 # The prior public53 package retains old P1/Surface fixtures, which are guarded here but not duplicated.
 for result in actual['groups']:
  for k in ['actual_Source_receipt','actual_Native_receipt','external_fixture','fixture_projection']:add(result[k],'Actual selected scientific group/whole runtime fixture')
  refs(result['logs'],'Actual complete Source stdout/stderr');refs(result['fixture_before_after_guards'],'All-four external fixture custody before/after')
  proof=read(checked(result['fixture_projection']))
  for k in ['exact_Native_named_inputs','exact_Source_primary_input_projection','Source_primary_input_proof','authentic_Source_raw_ingress','Source_ingress_transport_proof','author_Source']:
   if k in proof:add(proof[k],'Whole declared primary inputs/true raw input bridge/projection author')
  native=read(checked(result['actual_Native_receipt']));add(native['actual_build'],'Accepted original-core actual build metadata');add(native['reviewed_manifest'],'Exact selected Native recipe metadata')
  for k in ['stdout','stderr','Native_before','Native_after','actual_child_modules','author_Source']:
   if k in native:refs(native[k],'Actual Native logs/PID-DLL gate/custody metadata')
 # Explicit relevant Native failure/correction history, never inferred Source failures.
 failures=[]
 for path in ['original-core-gap-batch-run-Root-06-output_processor/receipt.json','original-core-gap-batch-build-Root-05/native-build.json']:
  rr=ref(D/path);add(rr,'Preserved actual Native guard/ADL compiler failure');doc=read(checked(rr));failures.append(rr)
  for k in ['stdout','stderr','compile_commands','commands','receipts']:
   if k in doc:
    # Failed build command metadata may point to object/core witnesses; select only real log/receipt references below.
    if k in ['stdout','stderr']:refs(doc[k],'Preserved actual Native failure log')
  if 'compile_commands'in doc:
   for command in doc['compile_commands']:
    if isinstance(command,dict):
     for k in ['receipt','stdout','stderr']:
      if k in command:refs(command[k],'Preserved failed Native compile command/log')
 for path in ['Native-P4-genuine-factory-guard-draft-Audit-02/draft.json','Root-Native-P4-real-factory-guard-independent-review-02/review.json','Native-history-ADL-fix-Peer-04/correction.json','Root-Native-history-ADL-independent-review-05/review.json','air-history-Native-gap-draft-Peer-02/draft.json','Peer-air-history-Native-review-Audit-02/review.json','output-processor-Native-P4-draft-Audit-01/draft.json','Peer-output-processor-Native-P4-review-01/review.json']:
  file(D/path,'Independently reviewed original Native full methods/corrections')
 guardfix=read(D/'Native-P4-genuine-factory-guard-draft-Audit-02/draft.json')
 for k in ['before','proposed','forward_diff','inverse_diff','correction_proof','author_Source']:add(guardfix[k],'Actual P4 guard-only correction whole/inverse')
 nat_hist=read(D/'air-history-Native-gap-draft-Peer-02/draft.json')
 for k in ['appended_fragment','accepted_P1_prefix','P1_full_caller_draft','P1_independent_peer','author_Source']:
  if k in nat_hist:add(nat_hist[k],'Actual history/P1 factory and inherited helper declaration lineage')
 oldP4=read(D/'output-processor-Native-P4-draft-Audit-01/draft.json')
 for key,value in oldP4.items():
  if key in ['appended_fragment','fragment','proposed_combined_TU','Source','named_inputs','author_Source','common_header','common_main']:refs(value,'Original P4 methods/input/constructor declarations')
 for authority in oldP4.get('Native_authorities',[]):
  add(authority['whole'],'P4 original-core pinned Native authority')
  for e in authority.get('extents',[]):
   if e.get('source',e.get('excerpt')):add(e.get('source',e.get('excerpt')),'P4 original-core exact function extent')
 # Exact shared-body bridge only: not a P1/Surface replay or same-binary certificate.
 oldplan=read(checked(prepared['prior_compiler_plan']));oldrows={x['path']:x for x in oldplan['entries']};name='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs';frow=next(x for x in draft['files']if x['canonical_path']==name);before=checked(frow['before']).read_bytes();after=checked(frow['proposed']).read_bytes();assert before+ b'\nmod output_processor;\n\nmod air_history;\n'==after
 assert(ref(checked(frow['before']))['sha256'],len(before))==(oldrows[name]['final_sha256'],oldrows[name]['final_bytes'])
 surface=read(D/'source-surface-adapter-draft-Outer-03/draft.json');surface_wholes=[]
 for row in surface['Sources']:
  name=row['canonical_path'];a=ref(R/name);assert a['sha256']==row['proposed']['sha256'];surface_wholes.append(a)
 bridge=save(O/'prior-shared-body-impact-bridge.json',dict(schema='src06-Source54-prior-body-only-impact-bridge.v1',prior_actual=ref(D/'Root-source-gap-batch-actual-review-53/review.json'),prior_plan=prepared['prior_compiler_plan'],current_plan=actual['complete_compiler_plan'],P1_body=frow['before'],new_P1_mod_suffixes_only=['mod output_processor;','mod air_history;'],P1_entire_prior_body_prefix_exact=True,Surface13_whole_exact=surface_wholes,shared_root_two_hook_proof=draft['literal_shared_hook_union'],P1_Surface_compiler_or_scientific_reexecution=False,current_same_binary_P1_Surface_claim=False,qualification='Exact unchanged Source bodies/Surface wholes plus separately authenticated selected root-hook composition only. Production/shared OP edits are separately reviewed; no new P1/Surface numerical result is manufactured.'))
 add(bridge,'Explicit prior shared-body impact bridge only');file(D/'Root-source-gap-batch-actual-review-53/review.json','Historical P1/Surface actual scope, no54 replay')
 total=sum(x['source']['bytes']for x in rows.values());assert total<110*1024*1024
 whitelist=save(O/'finite-whitelist.json',dict(schema='src06-P4-history54-finite-whitelist.v1',entries=sorted(rows.values(),key=lambda x:x['source']['path']),uncompressed_bytes=total,exclusions=['Old compiler snapshot ledgers/Source trees/source-objects and recursive prior evidence ZIPs','Core/static archives/objects/binaries/DLLs/maps and full frozen environment values','Duplicate Native P4/history raw JSON: entire outputs are already losslessly retained in the two runtime fixtures','Duplicate old P1/Surface fixtures retained by public53; all four are independently guarded in actual54','Future multiplier2/warmup/Exterior Source expected results or unexecuted claims'],author_Source=ref(Path(__file__))))
 archive=O/'evidence.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for row in sorted(rows.values(),key=lambda x:x['archive_path']):
   info=zipfile.ZipInfo(row['archive_path'],date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,checked(row['source']).read_bytes())
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and set(z.namelist())=={x['archive_path']for x in rows.values()}
  for row in rows.values():b=z.read(row['archive_path']);assert len(b)==row['source']['bytes']and hashlib.sha256(b).hexdigest()==row['source']['sha256']
 suggestions=save(O/'curated-doc-suggestions.json',dict(policy='Compact current-state replacements and scoped card facts only. Root owns exact current UTF8 docs/canonical mutation; no gate promotion or chronological Source-chain dump.',README_current_rows=[dict(scope='OutputProcessor direct scientific unit',fact='Nine genuine setup calls and38 retained System/Zone/reset operations pass34,321 strict Source state raw-bit observations across95 snapshots. Native whole output has34,470 finite values; named inputs/representation exclusions are separately qualified.'),dict(scope='Retained mixed-zone air histories',fact='Four getter-created owner lifetimes and40 full pushZone/pushSystem/revert operations pass23,232 strict state raw-bit observations across88 snapshots. Histories are never injected/reset between declared operations.')],revised_open_work='Remaining work includes multiplier2 full Predict/Correct validation, normal warmup-to-RunPeriod/full surface-parent handoff, positive solar/internal-gain Source producer equivalence, and final same-Source15-case/ownJSONCSV closure. The completed P4/history scopes do not repeat prior P1/Surface/2336/471/59/P2 bodies.',production_qualification='None/Propane production routing is independently semantically reviewed and integrated; positive Propane/IHG numerical PASS remains pending the separately scoped Exterior Source cohort.',prior_proof_qualification='P1/Surface53 results remain historical. Source54 records an exact unchanged-body/hook impact bridge, not a new P1/Surface run or same-binary PASS.',gates='A14/54 and B14/64 unchanged.',evidence_link='evidence/SRC-06-canonical-output-processor-air-history-54/summary.json'))
 template=save(O/'template.json',dict(schema='src06-P4-history54-private-publication-template.v1',status='READY_PRIVATE_FOR_ROOT_CURATED_PUBLICATION',public_directory='energyplus_porting_plan/evidence/SRC-06-canonical-output-processor-air-history-54',base_HEAD=actual['base_HEAD'],actual_review=ref(actual_path),complete_compiler_plan=actual['complete_compiler_plan'],finite_archive=ref(archive),finite_whitelist=whitelist,curated_doc_suggestions=suggestions,
  summary=dict(accepted=True,findings=[],compiler_inputs=4538,Rust_sources=4525,selected_Source_files=21,existing=17,new=4,full_operations=78,original_P4_setup_calls=9,P4_full_operations=38,history_full_operations=40,Source_exact_state_raw_bits=57553,P4_Source_exact_state_raw_bits=34321,history_Source_exact_state_raw_bits=23232,Native_entire_output_finite_f64=57822,P4_Native_entire_output_finite_f64=34470,history_Native_entire_output_finite_f64=23352,denominators_distinct=True,observed_state_snapshots=183,accepted_selected_Cargo_invocations=2,both_groups_same_recorded_Source_snapshot=True,all_four_external_fixtures_stable=True,actual_groups=actual['groups'],relevant_preserved_Native_failures=failures,original_metadata_only_checker=ref(D/'check-Source-P4-history-actual-Root-54.py'),accepted_checker=actual['author_Source'],prior_shared_body_impact_bridge=bridge,positive_Propane_IHG_numerical_PASS=False,new_P1_Surface_numerical_PASS=False,private_cache_state_observed=False,new_normal_CLI_or_engine_runs=0,prior_scientific_bodies_rerun=False,gates_changed=False),
  publication_contract='Root alone verifies full4538/staged bytes and all finite archive CRC/SHA/size, copies evidence, writes compact current summary/docs, runs docsQA, commits/pushes. This author writes ignored private artifacts only.',author_Source=ref(Path(__file__))))
 manifest=save(O/'manifest.json',dict(schema='src06-P4-history54-private-publication-preparation.v1',status='READY_PRIVATE_NO_PUBLICATION',template=template,archive=ref(archive),finite_whitelist=whitelist,finite_entries=len(rows),uncompressed_bytes=total,all_ZIP_CRC_size_SHA_checked=True,actual_review=ref(actual_path),prior_shared_body_impact_bridge=bridge,curated_doc_suggestions=suggestions,canonical_docs_Source_Git_Cargo_or_Native_mutations=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,template=template,archive=ref(archive),whitelist=whitelist,entries=len(rows),uncompressed_bytes=total,suggestions=suggestions)))
if __name__=='__main__':main()

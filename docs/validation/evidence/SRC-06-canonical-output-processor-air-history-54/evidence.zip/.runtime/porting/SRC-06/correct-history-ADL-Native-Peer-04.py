"""Private one-name qualification after actual compiler ADL ambiguity; no execution."""
from pathlib import Path
import copy,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Native-history-ADL-fix-Peer-04'
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();assert ref(p)==v;return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir()
 old_path=D/'P4-history-Exterior-Native-driver-draft-Peer-03/draft.json';old=read(old_path)
 history=read(checked(old['history_draft']));before=checked(history['appended_fragment']).read_bytes()
 needle=b'        apply_inputs(factory,step.at("inputs"));auto operation='
 change=b'        AirHistoryDetail::apply_inputs(factory,step.at("inputs"));auto operation='
 assert before.count(needle)==1;after=before.replace(needle,change);assert after.replace(change,needle)==before
 fragment=O/'air_history_fragment.cpp';fragment.write_bytes(after)
 combined_before=checked(old['combined_TU']).read_bytes();assert combined_before.endswith(before)
 combined=O/'purchased_air_P4_history_batch.cpp';combined.write_bytes(combined_before[:-len(before)]+after)
 diffs={}
 for name,a,b in [('fragment',before,after),('combined',combined_before,combined.read_bytes())]:
  diffs[name]={}
  for key,x,y in [('forward',a,b),('inverse',b,a)]:
   p=O/(name+'.'+key+'.diff');p.write_text(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile=name+'03',tofile=name+'04')),encoding='utf-8',newline='\n');diffs[name][key]=ref(p)
 p=copy.deepcopy(old)
 relocations=[]
 for row in p['driver_files']:
  pre=row['proposed'];target=O/checked(pre).name;target.write_bytes(checked(pre).read_bytes());row['proposed']=ref(target);relocations.append(dict(before=pre,proposed=row['proposed'],whole_exact=True))
 p['preserved_driver03']=ref(old_path);p['combined_TU']=ref(combined);p['exact_appended_fragments'][-1]=ref(fragment)
 p['fragments_offsets'][-1]['bytes']=len(after)
 failed_path=D/'original-core-gap-batch-build-Root-05/native-build.json';failed=read(failed_path)
 assert not failed['accepted'] and failed['Native_bytes_match_before_and_after'] and failed['actual_caller_compile_invocations']==2 and failed['actual_link_invocations']==0
 correction=save(O/'correction.json',dict(schema='src06-one-qualified-call-Native-history-ADL-correction.v1',status='FROZEN_ROOT_NARROW_INDEPENDENT_PEER_PENDING',
  actual_failed_build=ref(failed_path),original_driver=ref(old_path),original_history_draft=old['history_draft'],original_history_full_peer=old['history_independent_peer'],
  before_fragment=history['appended_fragment'],proposed_fragment=ref(fragment),before_combined=old['combined_TU'],proposed_combined=ref(combined),diffs=diffs,
  old_ambiguous_call='apply_inputs(factory, step.inputs)',new_explicit_same_function='AirHistoryDetail::apply_inputs(factory, step.inputs)',
  no_function_body_argument_input_math_FP_or_cache_change=True,entire_P1_and_P4_prefix_whole_unchanged=True,
  main_header_relocations_only=relocations,External_CPP_and_named_inputs_unchanged=[old['Exterior_Source'],old['named_inputs']],
  reasoning='Factory is declared in PurchasedAirDetail. Unqualified lookup finds the intended history apply_inputs plus same-signature PurchasedAirDetail candidate through argument-dependent lookup. Explicit qualification selects the already intended existing function with identical argument expressions.',
  no_compiler_Native_Cargo_or_canonical_execution=True,author_Source=ref(Path(__file__))))
 p['history_compile_correction']=correction;p['history_compile_correction_peer']='WAIT_ROOT_INDEPENDENT_ADL_PEER';p['status']='SOURCE_ONLY_ONE_ADL_QUALIFIER_WAIT_ROOT_PEER'
 p['path_only_whole_CPP_relocations']=relocations;p['metadata_correction']='One actual compiler ADL ambiguity corrected by qualifying the same existing history function. Main/header whole-exact copied beside corrected TU for true common-header resolution. Other bodies, namedinputs and Exterior are unchanged.'
 p['correction_author_Source']=ref(Path(__file__))
 draft=save(O/'draft.json',p);print(json.dumps(dict(draft=draft,correction=correction,fragment=ref(fragment),combined=ref(combined))))
if __name__=='__main__':main()

"""Metadata-only publisher successor for truthful original application custody."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'publish-purchased-air-calculation-checkpoint-Audit-27.py'
NEW=D/'publish-purchased-air-calculation-checkpoint-Audit-27-02.py'
P=D/'purchased-air-calculation-publication-prepared-Audit-27'
O=D/'purchased-air-calculation-publication-prepared-Audit-27-02'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
assert ref(OLD)['sha256']=='5c31d633e0089ea4b4080f8fd76d2ddd34d4ca4580b93da2415dfe79af243c4e'
assert not O.exists() and not NEW.exists()
old=OLD.read_text(encoding='utf-8');body=old
for before,after in [
    ("READY = D/'purchased-air-calculation-publication-prepared-Audit-27'","READY = D/'purchased-air-calculation-publication-prepared-Audit-27-02'"),
    ("BACK = D/'purchased-air-calculation-publication-readback-Audit-27'","BACK = D/'purchased-air-calculation-publication-readback-Audit-27-02'"),
    ("    for key,run in zip(['actual_B','actual_A24'],runs):", "    for key in ['original_application_receipt','original_application_author_Source']:\n        add(checked(application[key]))\n    for key,run in zip(['actual_B','actual_A24'],runs):"),
]:
    assert body.count(before)==1,before;body=body.replace(before,after,1)
ast.parse(body);NEW.write_text(body,encoding='utf-8',newline='\n');O.mkdir()
template=json.loads((P/'publication-template.json').read_bytes());template['publisher_Source']=ref(NEW)
template['publisher_parent_Source']=ref(OLD)
template['Root_custody_at_publish']+=' The correctly labelled aggregate authenticates the original suffix26 application receipt and its actual writer Source; archive both original refs plus the read-only label/readback checker. No Source reapplication is implied.'
extras=[ref(OLD),ref(P/'publication-template.json'),ref(P/'publisher-parent-bridge.json'),ref(Path(__file__)),ref(NEW)]
items={x['path']:x for x in template['finite_archive_inputs']}
for row in extras:items[row['path']]=row
template['finite_archive_inputs']=[x for _,x in sorted(items.items())]
template['finite_archive_input_count']=len(items);template['finite_archive_input_bytes']=sum(x['bytes'] for x in items.values())
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
diffs={}
for name,a,b in [('forward',old.encode(),body.encode()),('inverse',body.encode(),old.encode())]:
    delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode()
    assert ns['apply_literal'](a,delta)==b
    p=O/(name+'.diff');p.write_bytes(delta);diffs[name]=ref(p)
(O/'publication-template.json').write_text(json.dumps(template,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
proof={'parent':ref(OLD),'successor':ref(NEW),'literal_applications':2,'changes':diffs,
    'scope':'Only READY/readback paths and exact two original-application references added to dynamic archive handling. All Source/plan/peer/base/actual policies/docs appends unchanged.',
    'original_template':ref(P/'publication-template.json'),'successor_template':ref(O/'publication-template.json'),
    'publisher_executed':False,'canonical_mutations':False}
(O/'publisher-parent-bridge.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'publisher':ref(NEW),'template':ref(O/'publication-template.json'),'bridge':ref(O/'publisher-parent-bridge.json')}))

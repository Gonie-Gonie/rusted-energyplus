from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
N=R/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
O=D/'source-purchased-air-calculation-held-Audit-27'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
    p=R/x['path'];assert ref(p)['sha256']==x['sha256'],x
    if 'bytes' in x:assert ref(p)['bytes']==x['bytes'],x
    return p
def load(path,sha):
    p=R/path;assert ref(p)['sha256']==sha;return p,json.loads(p.read_bytes())
def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],check=True,capture_output=True).stdout
def save(name,b):
    p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def contains(x,target):
    if isinstance(x,dict):return x==target or any(contains(y,target) for y in x.values())
    if isinstance(x,list):return any(contains(y,target) for y in x)
    return False
a=argparse.ArgumentParser();a.add_argument('--base-head',required=True);a.add_argument('--peer-path',required=True);a.add_argument('--peer-sha',required=True);args=a.parse_args()
assert git(R,'rev-parse','HEAD').decode().strip()==args.base_head=='815d809cf00a3f12dd8f71337f33af770d350dca'
assert git(R,'rev-parse','origin/main').decode().strip()==args.base_head
assert not git(R,'status','--porcelain=v1').strip()
assert not O.exists()
draft_path,draft=load('.runtime/porting/SRC-06/source-purchased-air-calculation-draft-Audit-27-02/draft.json','f4019b990d4b649ad71d6cf7c7a39bcb6248a25718c111b09b5fe5ad138d410a')
peer_path,peer=load(args.peer_path,args.peer_sha)
assert peer['accepted'] and not peer['findings'] and contains(peer,ref(draft_path))
parent_path,parent=load('.runtime/porting/SRC-06/source-purchased-air-initialization-held-Peer-26/manifest.json','021f6a42a1bbed1b9d54f4bc5681ea02a71916f7603ecfec41d0ad787247e45e')
actual_path=R/'.runtime/porting/SRC-06/Root-source-purchased-air-initialization-actual-review-26/review.json'
assert ref(actual_path)['sha256']=='20ef76c66bf03b8bc531f20b1aa3050db02179fb5a51d39ee0e802e8f9c3e5e4'
actual=json.loads(actual_path.read_bytes());assert actual['accepted'] and not actual['findings'] and actual['producer']==ref(parent_path)
assert actual['B_frontier']=='GetHeatBalanceInput: actual PurchasedAir CalcPurchAirLoads203'
plan_path=auth(actual['complete_compiler_plan']);plan=json.loads(plan_path.read_bytes())
assert ref(plan_path)['sha256']=='dcbaadd6163378bc2d06959ff9c956948c21db9476b13d47d7fe68214e9ea8da'
assert plan['inputs']==4501 and plan['Rust_sources']==4488
receipts={}
for label,key,code in [('B-NOLIMIT-24H','actual_B',6),('A-24H','actual_A24',0)]:
    p=auth(actual[key]);receipt=json.loads(p.read_bytes());assert receipt['exit_code']==code and receipt['source_bytes_match_before_and_after']
    receipts[label]={'receipt':ref(p),'exit_code':code,'snapshot':receipt['source_snapshot']}
assert receipts['B-NOLIMIT-24H']['snapshot']==receipts['A-24H']['snapshot']
snapshot_path=auth(receipts['B-NOLIMIT-24H']['snapshot']);snapshot=json.loads(snapshot_path.read_bytes())
archives={x['historical_path']:x['archive'] for x in snapshot['files']}
entries={x['path']:copy.deepcopy(x) for x in plan['entries']};assert len(entries)==4501 and set(entries)==set(archives)
readback=[]
for name,row in entries.items():
    raw=auth(archives[name]).read_bytes()
    assert raw==auth(row['source']).read_bytes()==(R/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['final_sha256'] and len(raw)==row['final_bytes']
    readback.append({'path':name,'actual_archive':archives[name],'sha256':row['final_sha256'],'bytes':len(raw),'archive_live_plan_exact':True})
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];logical={}
for i,row in enumerate(draft['files'],1):
    name=row['canonical_path'];new=auth(row['proposed']).read_bytes();before=auth(row['before']).read_bytes() if row['before'] else b''
    if before:assert before==auth(archives[name]).read_bytes()==(R/name).read_bytes()==git(R,'show',args.base_head+':'+name)
    else:assert name not in entries and not (R/name).exists()
    assert ns['apply_literal'](before,auth(row['forward']).read_bytes())==new
    assert ns['apply_literal'](new,auth(row['inverse']).read_bytes())==before
    parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R)
    assert parsed.returncode==0,parsed.stderr
    proposal=save('proposed/'+name,new)
    files.append({'canonical_path':name,'before_absent':not bool(before),'before':save('before/'+name,before) if before else None,
        'actual_parent_archive':archives.get(name),'proposed':proposal,'literal_inverse':save('literal-inverse/'+name,before),
        'forward_diff':save(f'diffs/{i:02}-forward.diff',auth(row['forward']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',auth(row['inverse']).read_bytes()),
        'literal_origin_whole':row['proposed'],'before_whole_Git_exact_at_base':bool(before),
        'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',parsed.stdout),'stderr':save(f'parse/{i:02}.stderr',parsed.stderr)}})
    entries[name]={'path':name,'final_sha256':proposal['sha256'],'final_bytes':proposal['bytes'],'source':proposal,'origin':'whole accepted Source27 draft02 proposal; no semantic rewrite'}
    logical[name]=new.decode()
assert len(files)==3 and sum(x['before_absent'] for x in files)==1
assert len(entries)==4502 and sum(x.endswith('.rs') for x in entries)==4489
api=[]
needles=['simulate_source_purchased_air','calculate_source_purchased_air','update_source_purchased_air','report_source_purchased_air','SourcePurchasedAirCalcOwners']
for name,row in sorted(entries.items()):
    if not name.endswith('.rs'):continue
    text=logical.get(name)
    if text is None:text=auth(row['source']).read_text(encoding='utf-8')
    hits=[{'line':i,'terms':[x for x in needles if x in line]} for i,line in enumerate(text.splitlines(),1) if any(x in line for x in needles)]
    if hits:api.append({'path':name,'ordered_hits':hits})
assert {x['path'] for x in api}=={x['canonical_path'] for x in files}
cohort=[x for x in entries if '/prediction/' in x and ('native_cohort' in x or '/fixtures/' in x)]
assert len(cohort)==2
cohort.append('crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs')
assert all(entries[x]==next(y for y in plan['entries'] if y['path']==x) for x in cohort)
readonly_path=auth(draft['read_only_plan']);readonly=json.loads(readonly_path.read_bytes());native=[]
for authority in readonly['Native_authorities']:
    name=authority['Native_path'];raw=auth(authority['whole']).read_bytes()
    assert raw==git(N,'show',PIN+':'+name)==(N/name).read_bytes()
    lines=raw.splitlines(keepends=True);extents=[]
    for extent in authority['extents']:
        assert b''.join(lines[extent['first']-1:extent['last']])==auth(extent['source']).read_bytes()
        extents.append(extent)
    if name=='src/EnergyPlus/PurchasedAirManager.cc':
        extents.append({'first':120,'last':128,'source':save('Native-extents/PurchasedAirManager.cc.120-128.txt',b''.join(lines[119:128]))})
    if name=='src/EnergyPlus/DataHVACGlobals.hh':
        extents.append({'first':112,'last':122,'source':save('Native-extents/DataHVACGlobals.hh.112-122.txt',b''.join(lines[111:122]))})
    native.append({'Native_path':name,'whole':authority['whole'],'extents':extents,'pinned_Git_exact':True})
name='src/EnergyPlus/DataZoneEquipment.hh';raw=(N/name).read_bytes();assert raw==git(N,'show',PIN+':'+name)
native.append({'Native_path':name,'whole':save('Native/'+name,raw),'extents':[{'first':108,'last':139,'source':save('Native-extents/DataZoneEquipment.hh.108-139.txt',b''.join(raw.splitlines(keepends=True)[107:139]))}],'pinned_Git_exact':True})
context_names=['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/owners.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/management/availability.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/demand.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs',
    'crates/ep_runtime/src/heat_balance/selected_schedule_manager/report.rs','crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs',
    'crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs','crates/ep_runtime/src/psychrometrics.rs','crates/ep_runtime/src/psychrometrics/source_access.rs',
    'crates/ep_runtime/src/psychrometrics/psy02_state.rs','crates/ep_runtime/src/weather/day/context.rs']
contexts=[]
for name in context_names:
    if name=='crates/ep_runtime/src/weather/day/context.rs':name='crates/ep_runtime/src/weather_day/context.rs'
    raw=auth(archives[name]).read_bytes();assert raw==(R/name).read_bytes()==git(R,'show',args.base_head+':'+name)
    contexts.append({'canonical_path':name,'whole':{**archives[name],'bytes':len(raw)},'actual_archive_and_selected_Git_exact':True})
final_plan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-Source27-compiler-input-plan.v1','base_HEAD':args.base_head,
    'actual26_parent_snapshot':ref(snapshot_path),'prior_plan':ref(plan_path),'inputs':4502,'Rust_sources':4489,
    'entries':[entries[x] for x in sorted(entries)],'selected3_exact_draft02':True,'three_existing_cohort_Sources_unchanged':True})
manifest={'schema':'src06-held-coherent-purchased-air-calculation.v1','status':'HELD Source27 on clean committed actual26; no Source27 execution/completion claim',
    'base_HEAD':args.base_head,'accepted26_actual_review':ref(actual_path),'parent_producer':ref(parent_path),'actual_parent_receipts':receipts,
    'actual_parent_snapshot':ref(snapshot_path),'prior_complete_compiler_Source_plan':ref(plan_path),'complete_final_compiler_Source_plan':final_plan,
    'compiler_inputs':4502,'Rust_sources':4489,'original_draft02':ref(draft_path),'independent_full_semantic_peer':ref(peer_path),'files':files,
    'existing_Source_files':2,'new_Source_files':1,'selected_Source_files':3,'literal_applications':6,'Source_only_parses':3,
    'all3_proposals_whole_unchanged_from_reviewed_draft02':True,'full4501_parent_readback':dump('actual26-parent-full-readback.json',readback),
    'whole4489_Rust_API_census':dump('API-census.json',{'Rust_sources_examined':4489,'all_crates_runtime_tests_included':True,'hits':api,'sole_real_management_caller':True,'new_tests':0}),
    'Native_commit':PIN,'Native_authorities':native,'concrete_same_owner_contexts':contexts,
    'read_only_plan':ref(readonly_path),'Tsat_call_boundary_correction':ref(D/'source-purchased-air-calculation-draft-Audit-27-02/Tsat-boundary-correction.json'),
    'independent_disjoint_psych_transport_peer':ref(load('.runtime/porting/SRC-06/Peer-purchased-air-psych-transport-review-27-02/review.json','21d0bd0799b19ea9cf4f3c89acf1d0b7bdedc98f256f783290637dc31111f210')[0]),
    'operation_order':['Real Init201 then Calc203 then Update205 then Report207 on sole retained unit.',
        'Actual demand/availability/schedules; NoOA Min/Mixed children; lazy normalCp cache and Fmath grouping; true Node writes and returned Sys/Moist caller cells.',
        'Report retains same live unit rates/28 energy assignment order and actual schedule/current HVAC timestep operands. No early output snapshots.'],
    'scope':'NoOA/HumNone cooling, heating and deadband including four limit-type Calc branches; real off/zero-flow and same physical Node/contaminant branches. Source26 positive sizing operations may still stop before these Calc branches. No all12 or internal Native-paired numerical validation claim.',
    'remaining_scope':draft['remaining_boundaries'],
    'validation_policy':'Root alone runs actual production B then A24; no current test/profile/Native rerun or new test required by routing/body implementation. Inherited25 Raw test and prior1168 Native cohort remain separate historical evidence only.',
    'new_test_bodies':0,'Cargo_main_tests_or_Native_mutations':False,'author_Source':ref(Path(__file__))}
p=O/'manifest.json';p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

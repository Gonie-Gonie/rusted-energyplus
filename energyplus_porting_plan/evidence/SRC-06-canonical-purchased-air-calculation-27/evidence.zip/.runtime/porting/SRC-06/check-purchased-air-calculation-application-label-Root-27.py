from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-purchased-air-calculation-application-27';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];assert ref(p)['sha256']==v['sha256'];return p.read_bytes()
p=D/'Root-purchased-air-calculation-application-26/receipt.json';original=ref(p);assert original['sha256']=='5216bf3b91c2995001e829ebda94a5bc6ef3b3a8e21068cf27b83d560b31f249'
a=json.loads(checked(original));assert a['accepted'] and a['final_inputs']==4502 and len(a['selected'])==3
checked(a['author_Source']);plan=json.loads(checked(a['complete_compiler_plan']))
for row in plan['entries']:assert (R/row['path']).read_bytes()==checked(row['source'])
a['original_application_receipt']=original;a['original_application_author_Source']=a['author_Source'];a['author_Source']=ref(Path(__file__).resolve())
a['receipt_label_correction']='Original application27 successfully applied exact3 Sources but its output-directory suffix retained26. Original receipt and author preserved unchanged; this read-only4502-input readback gives correct27 label. No Source reapplication or mutation.'
O.mkdir();p=O/'receipt.json';p.write_text(json.dumps(a,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

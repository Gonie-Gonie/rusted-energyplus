"""Prepare only a literal successor of accepted26 publisher; no canonical writes."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OUT=D/'purchased-air-calculation-publication-prepared-Audit-27'
OLD=D/'publish-purchased-air-initialization-checkpoint-Peer-26.py'
NEW=D/'publish-purchased-air-calculation-checkpoint-Audit-27.py'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def check(x):
    p=R/x['path'];assert ref(p)['sha256']==x['sha256'] and ref(p)['bytes']==x.get('bytes',x.get('size_bytes',ref(p)['bytes']));return p
def load(x):return json.loads(check(x).read_bytes())
def save(name,x):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return ref(p)
assert not OUT.exists() and not NEW.exists()
assert ref(OLD)['sha256']=='7890f7374ca596cf7b97bcf61a1d0aed76b3a376ef4972e6d6c74c5d3e9b87b7'
producer_ref=ref(D/'source-purchased-air-calculation-held-Audit-27/manifest.json')
assert producer_ref['sha256']=='374687ab7da0eb31a26f73a8219a9f50698bf6e61e55663d26c642b559253b40'
producer=load(producer_ref);peer_ref=producer['independent_full_semantic_peer'];peer=load(peer_ref)
assert peer['accepted'] and not peer['findings']
parent_actual_ref=producer['accepted26_actual_review'];parent_actual=load(parent_actual_ref)
assert parent_actual['accepted'] and parent_actual['actual_test_bodies_executed']==0
parent_producer=load(producer['parent_producer']);accepted25_ref=parent_producer['accepted25_actual_review'];accepted25=load(accepted25_ref)
test_ref=accepted25['raw_metadata_focused_test'];assert load(test_ref)['exit_code']==0
previous_ref=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-purchased-air-initialization-26/summary.json')
previous=load(previous_ref);assert (previous['A'],previous['B'])==('14/54','14/64')
old=OLD.read_text(encoding='utf-8');body=old
replacements=[
 ('checkpoint26','checkpoint27'),
 ('purchased-air-initialization-publication-prepared-Peer-26','purchased-air-calculation-publication-prepared-Audit-27'),
 ('SRC-06-canonical-purchased-air-initialization-26','SRC-06-canonical-purchased-air-calculation-27'),
 ('purchased-air-initialization-publication-readback-Peer-26','purchased-air-calculation-publication-readback-Audit-27'),
 ('f8a5000d34f616b64dca7493fd8334ac2fc8f475','815d809cf00a3f12dd8f71337f33af770d350dca'),
 ('(4501,4488)','(4502,4489)'),
 ("len(producer['files']) == 4 and producer['existing_Source_files'] == 3", "len(producer['files']) == 3 and producer['existing_Source_files'] == 2"),
 ('all4_proposals_whole_unchanged_from_reviewed_draft02','all3_proposals_whole_unchanged_from_reviewed_draft02'),
 ('Root-source-purchased-air-initialization-actual-review-26','Root-source-purchased-air-calculation-actual-review-27'),
 ('same4501_archived_inputs_exact_final_plan','same4502_archived_inputs_exact_final_plan'),
 ('selected4_final_sources_exact','selected3_final_sources_exact'),
 ('whole_JSON_equal25_after_exactly_two_owned_path_field_bridges','whole_JSON_equal26_after_exactly_two_owned_path_field_bridges'),
 ('full_runtime_equal25_after_two_owned_path_bridges','full_runtime_equal26_after_two_owned_path_bridges'),
 ('it is not a26 execution','it is not a27 execution'),
 ('== 4501 and set(index)==set(observed)','== 4502 and set(index)==set(observed)'),
 ('canonical-source-purchased-air-initialization-B-NOLIMIT-24H-Root-26','canonical-source-purchased-air-calculation-B-NOLIMIT-24H-Root-27'),
 ('canonical-source-purchased-air-initialization-A-24H-Root-26','canonical-source-purchased-air-calculation-A-24H-Root-27'),
 ('src06-canonical26-finite-evidence-archive.v1','src06-canonical27-finite-evidence-archive.v1'),
 ('4 coherent PurchasedAir initialization Sources','3 coherent PurchasedAir Calc/Update/Report Sources'),
 ('src06-canonical-purchased-air-initialization.v1','src06-canonical-purchased-air-calculation.v1'),
 ('Genuine Source PurchasedAir initialization; B incomplete at actual frontier','Genuine Source PurchasedAir Calc/Update/Report; B incomplete at actual frontier'),
 ("'accepted25_proof':actual['accepted25_full5352_proof']","'accepted26_proof':actual['accepted26_full5352_proof']"),
 ('physical_files_whole_equal25','physical_files_whole_equal26'),
 ('whole_physical_streams_equal25','whole_physical_streams_equal26'),
 ('CSV_files_whole_equal25','CSV_files_whole_equal26'),
 ('whole_CSV_equal25','whole_CSV_equal26'),
 ('Proof transfer from accepted25','Proof transfer from accepted26'),
 ('positive PurchasedAir initialization Native state equivalence','positive PurchasedAir numerical Native state equivalence'),
 ('canonical_purchased_air_initialization_26','canonical_purchased_air_calculation_27'),
 ]
for before,after in replacements:
    assert before in body,before
    body=body.replace(before,after)
line=next(x for x in body.splitlines() if x.lstrip().startswith("append='\\n\\n[Source"))
body=body.replace(line,"        append='\\n\\n[Source IdealLoads 계산·갱신·보고 검증]('+link+'). '+text+'\\n'",1)
ast.parse(body);assert '\ufffd' not in body
NEW.write_text(body,encoding='utf-8',newline='\n');OUT.mkdir()
inputs={}
def add(x):
    p=check(x);assert p.suffix.lower()!='.zip';value=ref(p)
    assert value['path'] not in inputs or inputs[value['path']]==value
    inputs[value['path']]=value
for x in [producer_ref,producer['complete_final_compiler_Source_plan'],producer['full4501_parent_readback'],producer['whole4489_Rust_API_census'],
          producer['original_draft02'],producer['author_Source'],peer_ref,peer['author_Source'],producer['independent_disjoint_psych_transport_peer'],
          producer['read_only_plan'],producer['Tsat_call_boundary_correction'],parent_actual_ref,accepted25_ref,test_ref,previous_ref,ref(OLD),ref(NEW),ref(Path(__file__))]:add(x)
for row in producer['files']:
    for key in ('before','proposed','literal_inverse','forward_diff','inverse_diff'):
        if row[key]:add(row[key])
    for key in ('stdout','stderr'):add(row['Source_only_parse'][key])
for row in producer['Native_authorities']:
    add(row['whole'])
    for extent in row['extents']:add(extent['source'])
for row in producer['concrete_same_owner_contexts']:add(row['whole'])
template={'schema':'src06-held-canonical27-publication-template.v1','status':'HELD_FOR_ROOT_ACTUAL27_AND_FULL_READ',
    'base_HEAD':producer['base_HEAD'],'producer':producer_ref,'complete_plan':producer['complete_final_compiler_Source_plan'],
    'accepted_independent_peer':peer_ref,'accepted26_actual_review':parent_actual_ref,'accepted25_actual_review':accepted25_ref,
    'inherited25_raw_metadata_test':test_ref,'previous_checkpoint':previous_ref,'publisher_Source':ref(NEW),'publisher_parent_Source':ref(OLD),
    'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-purchased-air-calculation-actual-review-27/review.json',
    'pending_Root_custody':{'application':'.runtime/porting/SRC-06/Root-purchased-air-calculation-application-27/receipt.json',
        'actual_review_sha256':'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source':'.runtime/porting/SRC-06/check-source-purchased-air-calculation-actual-Root-27.py',
        'launcher_Source':'.runtime/porting/SRC-06/launch-purchased-air-calculation-Root-27.py',
        'B_CLI':'.runtime/porting/SRC-06/canonical-source-purchased-air-calculation-B-NOLIMIT-24H-command-Root-27/receipt.json',
        'A24_CLI':'.runtime/porting/SRC-06/canonical-source-purchased-air-calculation-A-24H-command-Root-27/receipt.json'},
    'Root_custody_at_publish':'Byte-authenticate actual aggregate/application, their author Sources, launcher and both actual CLI receipts/artifacts at publication. No assumed frontier or positive execution claim from static Source.',
    'summary_template':{'A':'14/54','B':'14/64','changed_Rust_sources':3,'existing_Rust_sources':2,'new_Rust_sources':1,
        'new_test_functions':0,'actual_test_bodies_executed':0,
        'focused_validation_policy':'Actual production B then A24 only. Inherited25 RawModel test is historical evidence, not checkpoint27 execution. No unrelated test/profile, repeated cohort, new test or alltargets.',
        'scope':'Same retained PurchasedAir/physical Node Calc, Update and Report operations: actual availability/demand/schedules, NoOA/HumNone four limit-type Calc branches, normal shared psychrometric cache, true returned sensible/moisture cells and live reporting fields. Positive property diagnostic/OA/humidity/plenum and post-callee operations remain explicit boundaries; positive Source26 sizing variants, all12, internal-state numerical equivalence and fullB completion are unclaimed.',
        'full_B_or_finite15_completion_claim':False,'Native_harness_runtime_or_unit_equivalence_claim':False,'gate_changes':False,'policy_changes':False},
    'doc_appends':{
        'CHECKLIST.md':'IdealLoads 계산·갱신·보고 경로를 같은 실제 소유자에 연결했습니다. 관측된 중단 지점과 A24 회귀 결과는 연결된 증거에 기록합니다.',
        'STATE_CONTRACTS.md':'반환되는 현열·수분 출력과 Node 상태는 실제 PurchasedAir 계산에서 쓰며, 보고 필드는 같은 보유 유닛에서 갱신합니다. 심리계산 진단 등 미구현 경계는 명시적으로 유지합니다.',
        'cards/SRC-06.md':'IdealLoads Calc·Update·Report 실행 결과를 기록합니다. B의 실제 경계는 `{{actual_B_frontier}}`이며, 전체 B 및 내부 Native 수치 동등성 완료를 주장하지 않습니다.'},
    'finite_archive_inputs':[x for _,x in sorted(inputs.items())],'finite_archive_input_count':len(inputs),'finite_archive_input_bytes':sum(x['bytes'] for x in inputs.values()),
    'publisher_executed':False,'canonical_docs_mutations':False,'Cargo_tests_Native_executed':False,'gate_changes':False}
template_ref=save('publication-template.json',template)
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
diffs={}
for name,a,b in [('forward',old.encode(),body.encode()),('inverse',body.encode(),old.encode())]:
    delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode()
    assert ns['apply_literal'](a,delta)==b
    p=OUT/(name+'.diff');p.write_bytes(delta);diffs[name]=ref(p)
bridge=save('publisher-parent-bridge.json',{'parent':ref(OLD),'successor':ref(NEW),'literal_applications':2,'changes':diffs,
    'scope':'Accepted26 two-CLI/zero-test archive/docs engine, with27 paths/base4502/3Sources and authentic26 A24 proof transfer. Distinct three concise UTF8 appends and one existing SRC06 key, gates unchanged. Inherited25 Raw test remains historical only.',
    'publisher_executed':False,'canonical_mutations':False,'actual27_pending':True})
print(json.dumps({'publisher':ref(NEW),'template':template_ref,'parent_bridge':bridge}))

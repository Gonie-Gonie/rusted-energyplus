from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-purchased-air-initialization-B-NOLIMIT-24H-command-Root-26/receipt.json','79e39bbdb28d7bfc9b4d533423ad76966ffe10810fd10c99f6233821f47ba1e8'),
 'A24':('canonical-source-purchased-air-initialization-A-24H-command-Root-26/receipt.json','f10e5ab2aee63ab8bd8a45c5416938df17e92c08d7f389b55d3863dc9e37fbea'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-purchased-air-calculation-'+case+'-command-Root-27'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-purchased-air-calculation-'+case+'-Root-27/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

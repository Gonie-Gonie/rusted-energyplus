"""Independent full Source27 finite NoOA calculation/update/report review."""
from pathlib import Path
import ast, hashlib, json, re, subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'Outer-purchased-air-calculation-Source-review-27-02'
N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def load(r):return json.loads(checked(r))
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def main():
 assert not O.exists()
 packet=ref(D/'source-purchased-air-calculation-draft-Audit-27-02/draft.json')
 assert packet['sha256']=='f4019b990d4b649ad71d6cf7c7a39bcb6248a25718c111b09b5fe5ad138d410a'
 m=load(packet);parent=load(m['logical_parent']);plan=load(parent['complete_final_compiler_Source_plan'])
 entries={r['path']:r for r in plan['entries']};assert len(entries)==4501
 psy_ref=ref(D/'Peer-purchased-air-psych-transport-review-27-02/review.json')
 assert psy_ref['sha256']=='21d0bd0799b19ea9cf4f3c89acf1d0b7bdedc98f256f783290637dc31111f210'
 psy=load(psy_ref)
 assert 'ACCEPTED' in str(psy.get('status','')) or psy.get('accepted') is True
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'))
 fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re}
 exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
 files=[];selected={}
 for i,row in enumerate(m['files'],1):
  path=row['canonical_path'];before=b'' if row['before'] is None else checked(row['before']);after=checked(row['proposed'])
  if row['before'] is None:assert path not in entries and not (R/path).exists()
  else:assert before==checked(entries[path]['source'])==(R/path).read_bytes()
  assert ns['apply'](before,checked(row['forward']))==after and ns['apply'](after,checked(row['inverse']))==before
  added='\n'.join(x[1:] for x in checked(row['forward']).decode('utf-8').splitlines() if x.startswith('+') and not x.startswith('+++'))
  assert not re.search(r'\.(unwrap|expect)\s*\(|\b(panic|todo|unimplemented|unreachable)!|#\[(test|ignore)',added)
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True)
  assert parse.returncode==0
  files.append(dict(canonical_path=path,before=row['before'],proposed=row['proposed'],two_literal_applications_exact=True,
   fresh_Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',parse.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',parse.stderr))))
  selected[path]=after
 assert len(files)==3 and m['old']==2 and m['new']==1 and m['new_tests']==0
 correction_ref=ref(D/'source-purchased-air-calculation-draft-Audit-27-02/Tsat-boundary-correction.json');correction=load(correction_ref)
 initial=load(correction['initial_draft'])
 a=checked(correction['before']).decode('utf-8');b=checked(correction['proposed']).decode('utf-8')
 assert a.count(correction['exact_single_before_literal'])==1 and b.count(correction['exact_single_after_literal'])==1
 assert a.replace(correction['exact_single_before_literal'],correction['exact_single_after_literal'],1)==b
 assert b.replace(correction['exact_single_after_literal'],correction['exact_single_before_literal'],1)==a
 for r in initial['files'][:2]:assert checked(r['proposed'])==selected[r['canonical_path']]
 calc_path='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/calculation.rs'
 calc=selected[calc_path].decode('utf-8');assert b==calc
 readonly=load(m['read_only_plan']);assert readonly['Native_commit']==PIN
 Native=[]
 for r in readonly['Native_authorities']:
  raw=checked(r['whole']);assert raw==subprocess.check_output(['git','show',PIN+':'+r['Native_path']],cwd=N)
  for e in r['extents']:assert checked(e['source'])==b''.join(raw.splitlines(keepends=True)[e['first']-1:e['last']])
  Native.append(r)
 # Independently compare every ReportPurchasedAir member assignment in order.
 owner_path='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/owners.rs'
 owner=checked(entries[owner_path]['source']).decode('utf-8')
 mapping={native:rust for rust,native in re.findall(r'pub\(crate\)\s+(\w+)\s*:[^\n]+// Native (\w+)',owner)}
 cc=next(checked(r['whole']).decode('utf-8') for r in Native if r['Native_path']=='src/EnergyPlus/PurchasedAirManager.cc')
 report_native=cc[cc.index('void ReportPurchasedAir('):cc.index('void InitializePlenumArrays(')]
 report_source=calc[calc.index('pub(super) fn report_source_purchased_air'):]
 native_assignments=re.findall(r'PurchAir\.(\w+)\s*=\s*([^;]+);',report_native)
 source_assignments=re.findall(r'unit\.(\w+)\s*=\s*([^;]+);',report_source)
 def norm(x):
  x=re.sub(r'PurchAir\.(\w+)',lambda z:'unit.'+mapping[z[1]],x).replace('TimeStepSysSec','seconds').replace('heatFuelEffValue','heating_efficiency').replace('coolFuelEffValue','cooling_efficiency').replace('std::abs','abs')
  x=re.sub(r'min\(([^()]+)\)\.abs\(\)',r'abs(min(\1))',x)
  return re.sub(r'\s+','',x)
 assert len(native_assignments)==len(source_assignments)==60
 reports=[]
 for (field,expr),(source_field,source_expr) in zip(native_assignments,source_assignments):
  assert (mapping[field],norm(expr))==(source_field,norm(source_expr))
  reports.append(dict(Native_member=field,Source_member=source_field,normalized_expression=norm(expr)))
 # Whole crates API/owner construction census, including runtime tests.
 patterns=['simulate_source_purchased_air','calculate_source_purchased_air','update_source_purchased_air','report_source_purchased_air','SourcePurchasedAirCalcOwners']
 census=[];count=0
 for path in sorted(set(entries)|set(selected)):
  if not path.startswith('crates/') or not path.endswith('.rs'):continue
  raw=selected[path] if path in selected else checked(entries[path]['source']);count+=1
  body=raw.decode('utf-8');hits=[dict(line=i,text=line) for i,line in enumerate(body.splitlines(),1) if any(x in line for x in patterns)]
  if hits:census.append(dict(path=path,sha256=sha(raw),bytes=len(raw),hits=hits))
 assert count==4489 and len(census)==3
 context_names=[owner_path,'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_equipment/management/availability.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/demand.rs',
  'crates/ep_runtime/src/heat_balance/selected_schedule_manager/report.rs',
  'crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs',
  'crates/ep_runtime/src/weather_day/context.rs']
 contexts=[]
 for path in context_names:
  assert path in entries,path
  raw=checked(entries[path]['source']);assert raw==(R/path).read_bytes()
  contexts.append(dict(canonical_path=path,whole=entries[path]['source']))
 # Inputs are descriptive authority, never imported into production.
 assert len(readonly['finite_B_input_inventory'])==12
 for r in readonly['finite_B_input_inventory']:checked(r['input'])
 result=dict(schema='src06-independent-Source27-finite-NoOA-calculation-review.v1',accepted=True,findings=[],reviewed_packet=packet,
  scope='Full3 Source02 Native finite NoOA/HumNone Calc, Update/Report and live caller review; property/cache transport has disjoint independent peer.',
  logical_parent=m['logical_parent'],files=files,literal_applications=6,fresh_Source_only_parses=3,
  Native_commit=PIN,Native_wholes=Native,Native_whole_count=len(Native),strict_Native_extents=sum(len(r['extents']) for r in Native),
  concrete_owner_contexts=contexts,independent_psych_transport_peer=psy_ref,Tsat_finding_correction=correction_ref,
  original_draft_rejected_for_unrepresented_Tsat_diagnostics=correction['initial_draft'],
  formula_review=[
   'Real unit/Config/supply/zone/recirc ordinals and same physical Node owner. Exact initial persistent resets and caller Sys/Moist zeroes; retained demand RemainingHeat/CoolSP before availability type12 index11/zone/status writes and ordered unit/heat/cool Schedule reads.',
   'NoOA child genuinely writes0 minimum OA; actual EMS overrides remain at their Native locations. Cooling >=QCoolSP vs Heating <QHeatSP and exact TempControlType enum1/2; no eager property evaluation or compatibility solver.',
   'All4 limit predicates, zero-capacity behavior, actual left-associative Q/Cp/delta and Q/(Cp*flow), max5 native2/2/1 strict-comparison tree, >0 maxflow clip, <=1e-30 zeroing, same recirc MixedAir and zero heat recovery writes.',
   'Cooling sensible/total capacity >= vs > and heating > comparisons preserved. Actual HumNone/constant-cool branch, saturation/property call order, repeated Cp call even when its local is unused, current-coil loads, availability corrections and true sensible/moisture output units/assignments exact.',
   'No-flow and unit-off are distinct Native branches with exact persisted fields and Node copy/write order. Standard-density reporting and recirc/plenum tail MassFlow writes use same physical ordinals; no blanket134-member reset.',
   'Positive plenum Update writes same IsSimulated then actual all-test and stops genuine SimAirZonePlenum; no-return-plenum route returns. Report all60 ordered assignments/expression structures independently matched, same live fuel Schedule fallbacks, HVAC seconds, rates and28energy writes.'],
  Report60_assignment_ledger=reports,whole_crates_API_census=dict(Rust_sources=count,patterns=patterns,files=census),
  callsite='Actual mutable management SysOutputProvided/MoistOutputProvided cells pass through same Sim -> Init -> Calc -> Update -> Report. Caller stops at genuine Config/output-distribution4084 after successful callee; no fabricated zero response, copied result DTO, alternate owner/cache or production Native operand.',
  explicit_boundaries=['Positive OA-design-spec/humidity operation branches remain unavailable at actual unrepresented operation; no domain widening claimed.',
   'WFromH and corrected TsatHPb are honest whole-property-call boundaries, not silent diagnostic clamps/solver substitutes.',
   'WFromRh rawtemperature admissibility guard is conservative; no complete cached-representative/tag/warmup/CalledFrom diagnostic equivalence claim outside admitted normal domain.',
   'Earlier Source26 positive Flow/Capacity/Both real Sizer calls remain boundaries. Four calculation limit-code routes are reviewed, but admission/execution of all12 B cases is NOT claimed.'],
  validation_pending='Final27 immutable compiler-plan/base join and Root actual B/A execution remain required. No new tests, numerical cohort, full parent predictor/cache/corrector20 or completed B claim.',
  main_Cargo_tests_Native_or_publication_mutations=False,author_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'review.json',(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))))
if __name__=='__main__':main()

from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-combined-Zone-Node-preflight-14';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b)),v['path'];return b
def auth(n,s):
 p=D/n;assert ref(p)['sha256']==s;return ref(p),json.loads(p.read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='392134441c3b9db53951de8b245ca910b39e7625' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
nr,node=auth('source-Node-input-held-Outer-02/manifest.json','701eedb5224e6cb7811840cf331b0ce6eddcd45e70edc6287d3bcf9fb4493d41')
lr,lookup=auth('source-nominal-controlled-Zone-lookup-held-Peer-03/manifest.json','43068c478d9795f4b06346a973b0217bfbb40c798f6a9012bc4d6ebb6831ec8d')
assert node['base_HEAD']==head and lookup['base_HEAD']=='b82d16be8a96e854391636c615ddc07317a45d1f'
parent=json.loads(checked(node['actual_parent_snapshot']));parents={v['historical_path']:v for v in parent['files']}
inventory={p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4478 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and len((R/n).read_bytes())==v['size_bytes']
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
selected={};new=set();newtests=0
for mr,m in [(nr,node),(lr,lookup)]:
 for f in m['files']:
  n=f['canonical_path'];assert n not in selected;a,b=checked(f['before']),checked(f['proposed']);assert checked(f['literal_inverse'])==a
  assert apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
  if f.get('before_absent',False):assert not(R/n).exists() and a==b'';new.add(n)
  else:
   assert (R/n).read_bytes()==a==subprocess.check_output(['git','show',head+':'+n],cwd=R)==subprocess.check_output(['git','show','b82d16be8a96e854391636c615ddc07317a45d1f:'+n],cwd=R)
   assert a==checked(parents[n]['archive']) and (R/n).stat().st_nlink==1
  newtests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=dict(before=f['before'],proposed=f['proposed'],before_absent=f.get('before_absent',False),packet=mr)
assert len(selected)==7 and len(new)==2 and newtests==0
native=R/'.reference/energyplus-src/26.1.0';revision='6f2e40d10250a105b49966baa24d843711e61048'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip()==revision
for v in node['Native_wholes']:assert checked(v['frozen_whole'])==subprocess.check_output(['git','show',revision+':'+v['Native_path']],cwd=native)
for v in node['Native_literal_extents']:assert b''.join(checked(v['whole_source']).splitlines(keepends=True)[v['first_line']-1:v['last_line']])==checked(v['literal_excerpt'])
for v in lookup['Native']:
 b=(native/v['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==v['whole_sha256'] and len(b)==v['whole_bytes'];assert b==subprocess.check_output(['git','show',revision+':'+v['path']],cwd=native)
 for x in v['extents']:assert b''.join(b.splitlines(keepends=True)[x['first_line']-1:x['last_line']])==checked(x['strict_extent'])
for k in ['constructor_correspondence','integration_contract','order_correction']:checked(node[k])
plan=json.loads(checked(node['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4480
for n,v in rows.items():
 b=checked(v['source']);assert len(b)==v['final_bytes'] and hashlib.sha256(b).hexdigest()==v['final_sha256']
 if n in selected:
  proposed=selected[n]['proposed'];b=checked(proposed);v.update(source=proposed,final_sha256=hashlib.sha256(b).hexdigest(),final_bytes=len(b),origin='Root combined genuine Zone lookup and Node inputs')
 else:assert b==(R/n).read_bytes()
plan['composed_packets']=[nr,lr];plan['selected']=selected
O.mkdir();p=O/'complete-final-compiler-Source-plan.json';p.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8',newline='\n');planref=ref(p)
p=O/'review.json';p.write_text(json.dumps(dict(accepted=True,findings=[],base_HEAD=head,node_manifest=nr,nominal_lookup_manifest=lr,complete_compiler_plan=planref,all4478_parent_archive_live_equal=True,all4480_proposed_inputs_rehashed=True,selected_Rust=7,new_Rust=2,literal_applications=14,new_test_bodies=0,semantic_review='Root read all7changes and both newNode modules against pinnedNative constructors/Assign/GetNodeLists/Zone field lookup. Same owners; NodeID0Undefined/48fields/first-growth-reference order and Native counters independent; real field lookup/null insertion; conservative multi-object ordinal boundaries correct. Existing owner test retains allocation-counter independence.',independent_peers_pending_application=True,Cargo_Native_or_tests_executed=False,main_mutations=0,author_Source=ref(Path(__file__).resolve())),indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)));print(json.dumps(planref))

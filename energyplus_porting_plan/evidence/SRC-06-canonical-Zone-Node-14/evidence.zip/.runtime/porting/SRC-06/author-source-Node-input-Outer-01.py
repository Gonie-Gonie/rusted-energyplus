from pathlib import Path
import hashlib,json,subprocess
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'source-Node-input-draft-Outer-01';H='crates/ep_runtime/src/heat_balance/'
HEAD='b82d16be8a96e854391636c615ddc07317a45d1f'
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def old(n):
 p=R/n;z=p.read_bytes();assert z==subprocess.check_output(['git','show',HEAD+':'+n],cwd=R)
 q=D/'parent'/n;q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==z
 else:q.write_bytes(z)
 return z.decode()
def put(n,t):
 p=D/'proposed'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.encode())
n=H+'ordinary_equipment.rs';s=old(n)
s=s.replace('mod source_input;','mod source_input;\nmod source_nodes;\nmod source_node_lists;')
s=s.replace('use crate::node::NodeStateStore;','use source_nodes::{SourceNodeData, SourceNodeSetpointCheck};\nuse source_node_lists::SourceNodeList;')
s=s.replace('    /// Independent of counters and diagnostic typed-node projection length.\n    physical: Option<NodeStateStore>,','    /// Genuine DataLoopNode.Node storage, independent of native counters.\n    physical: Option<Vec<SourceNodeData>>,\n    /// Native NodeID has lower bound0; only index0 is Undefined.\n    node_ids: Option<Vec<String>>,\n    default_node_values: SourceNodeData,\n    node_setpoint_checks: Option<Vec<SourceNodeSetpointCheck>>,')
s=s.replace('    node_lists: Option<Vec<()>>,','    node_lists: Option<Vec<SourceNodeList>>,')
s=s.replace('            physical: None,','            physical: None,\n            node_ids: None,\n            default_node_values: SourceNodeData::default(),\n            node_setpoint_checks: None,')
put(n,s)
n=H+'ordinary_equipment/source_input.rs';s=old(n)
early='''        if controlled_zones != 0 || controlled_spaces != 0 || self.number_of_equipment_lists != 0 {
            return Err(Unavailable::Input(
                "positive controlled equipment input".into(),
            ));
        }
'''
assert s.count(early)==1;s=s.replace(early,'')
anchor='''        self.nodes
            .init_unique_check_source("ZoneHVAC:EquipmentConnections", input)?;
        // All controlled/space/term-unit/duplicate loops are genuinely empty.
'''
replacement='''        // Native281-297 diagnostics precede InitUniqueNodeCheck and node input.
        if self.number_of_equipment_lists != controlled_zones {
            return Err(Unavailable::Input("actual GetZoneEquipmentData282 equipment-list/count severe diagnostic".into()));
        }
        if controlled_zones > num_zones {
            return Err(Unavailable::Input("actual GetZoneEquipmentData292 controlled-zone/count severe diagnostic".into()));
        }
        self.nodes
            .init_unique_check_source("ZoneHVAC:EquipmentConnections", input)?;
        let _overall_equipment_count = 0_i32;
        let _local_term_unit_sizing_counter = 0_i32;
        // The genuine NodeList producer has returned. Stop at the first real
        // unported controlled-zone getObjectItem, before any copied zone flags.
        if controlled_zones > 0 {
            return Err(Unavailable::Input("actual GetZoneEquipmentData308 ZoneHVAC:EquipmentConnections getObjectItem".into()));
        }
        if controlled_spaces > 0 {
            if !space_simulation {
                return Err(Unavailable::Input("actual GetZoneEquipmentData361 ignored-controlled-space warning diagnostic".into()));
            }
            return Err(Unavailable::Input("actual GetZoneEquipmentData369 controlled-space getObjectItem".into()));
        }
        // All controlled/space/term-unit/duplicate loops are genuinely empty.
'''
assert s.count(anchor)==1;s=s.replace(anchor,replacement)
start=s.index('            let counts = definition(input, "NodeList")?;',s.index('impl NodeOwner'))
end=s.index('            self.get_input = false;',start)
s=s[:start]+'''            let mut errors_found = false;
            self.get_source_node_lists_input(input, &mut errors_found)?;
'''+s[end:]
put(n,s)
n=H+'ordinary_equipment_tests.rs';s=old(n)
assert s.count('NodeStateStore::len')==1;s=s.replace('NodeStateStore::len','Vec::len')
needle='''    owner.nodes.physical = Some(NodeStateStore {
        air_nodes: Vec::new(),
    });'''
assert s.count(needle)==1;s=s.replace(needle,'''    owner.nodes.physical = Some(vec![SourceNodeData::default()]);
    assert_eq!(owner.nodes.physical.as_ref().map_or(0, Vec::len), 1);''')
put(n,s)
print(json.dumps(dict(draft=str(D),existing_proposals=3,main_mutations=0)))

"""Independent five-Source Node producer peer. No main, Cargo or tests."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R/'.runtime/porting/SRC-06'
N = R/'.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
O = D/'Peer-genuine-Node-input-Source-review-02'
assert not O.exists()
O.mkdir()

def ref(p):
    b = p.read_bytes()
    return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}

def check(r):
    p = R/r['path']
    a = ref(p)
    assert a['sha256'] == r['sha256'] and a['bytes'] == r.get('bytes',a['bytes']), r
    return p

def load(r): return json.loads(check(r).read_bytes())
def put(name,b):
    p = O/name
    assert not p.exists()
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(b)
    return ref(p)

literal_ast = next(n for n in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal')
ns={'re':re}
exec(compile(ast.Module(body=[literal_ast],type_ignores=[]),'<own-literal-apply>','exec'),ns)
apply_literal=ns['apply_literal']
mref={'path':'.runtime/porting/SRC-06/source-Node-input-held-Outer-02/manifest.json','sha256':'701eedb5224e6cb7811840cf331b0ce6eddcd45e70edc6287d3bcf9fb4493d41','bytes':29237}
m=load(mref)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==m['base_HEAD']=='392134441c3b9db53951de8b245ca910b39e7625'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R)
actual=load(m['actual_B_frontier_receipt'])
assert actual['exit_code']==6 and actual['source_bytes_match_before_and_after']
assert actual['source_snapshot']['sha256']==m['actual_parent_snapshot']['sha256']
snapshot=load(m['actual_parent_snapshot'])
observed={r['historical_path']:r for r in snapshot['files']}
assert len(observed)==4478
diagnostics=check(m['actual_B_earlier_nominal_frontier_diagnostics']).read_text(encoding='utf-8')
assert 'GetHeatBalanceInput: positive nominal controlled Zone lookup' in diagnostics
load(m['Native_plan'])
contract=load(m['integration_contract'])
assert 'EARLIER' in contract['actual13_frontier_qualification'] and 'greater than1' in contract['raw_input']

file_rows=[]
texts={}
for i,row in enumerate(m['files'],1):
    p=row['canonical_path']
    before=check(row['before']).read_bytes()
    proposed=check(row['proposed']).read_bytes()
    texts[p]=proposed.decode()
    assert apply_literal(before,check(row['forward_diff']).read_bytes())==proposed
    assert apply_literal(proposed,check(row['inverse_diff']).read_bytes())==before==check(row['literal_inverse']).read_bytes()
    if row['before_absent']:
        assert before==b'' and p not in observed and not (R/p).exists()
        assert subprocess.run(['git','cat-file','-e',head+':'+p],cwd=R,capture_output=True).returncode!=0
    else:
        assert before==check(row['before']).read_bytes()==check(observed[p]['archive']).read_bytes()==(R/p).read_bytes()
        for rev in [head,m['historical_unchanged_selected_revision']]:
            assert before==subprocess.check_output(['git','show',rev+':'+p],cwd=R)
    authored=row['Source_only_parse']
    assert authored['exit_code']==0 and check(authored['stderr']).read_bytes()==b''
    check(authored['stdout'])
    parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,capture_output=True,cwd=R)
    assert parsed.returncode==0 and parsed.stderr==b''
    file_rows.append({'path':p,'before_absent':row['before_absent'],'before':row['before'],'proposed':row['proposed'],'two_literal_applications':True,'whole_inverse_exact':True,'Git392134_b82_actual13_live_bridge_exact':not row['before_absent'],'independent_parse':{'exit_code':0,'stdout':put(f'parse/{i:02d}.stdout',parsed.stdout),'stderr':put(f'parse/{i:02d}.stderr',parsed.stderr)}})

old=load(m['supersedes'])
correction=load(m['order_correction'])
assert correction['supersedes']==m['supersedes']
oldfiles={r['canonical_path']:r for r in old['files']}
for row in m['files']:
    if row['canonical_path'].endswith('/source_node_lists.rs'): continue
    assert check(row['proposed']).read_bytes()==check(oldfiles[row['canonical_path']]['proposed']).read_bytes()
fix=correction['changed'][0]
assert apply_literal(check(fix['Source01']).read_bytes(),check(fix['forward']).read_bytes())==check(fix['Source02']).read_bytes()
assert apply_literal(check(fix['Source02']).read_bytes(),check(fix['inverse']).read_bytes())==check(fix['Source01']).read_bytes()
orderpath=R/correction['order_authority']['path']
assert ref(orderpath)==correction['order_authority']
target_section=orderpath.read_text(encoding='utf-8').split('pub const IDF_ORDER_TARGETS:')[1].split('];',1)[0]
assert '"NodeList"' not in target_section

native={}
for row in m['Native_wholes']:
    b=check(row['frozen_whole']).read_bytes()
    assert row['revision']==PIN and b==subprocess.check_output(['git','show',PIN+':'+row['Native_path']],cwd=N)==(N/row['Native_path']).read_bytes()
    native[row['Native_path']]=b
for row in m['Native_literal_extents']:
    whole=check(row['whole_source']).read_bytes()
    assert whole==native[row['Native_path']]
    assert b''.join(whole.splitlines(keepends=True)[row['first_line']-1:row['last_line']])==check(row['literal_excerpt']).read_bytes()

P='crates/ep_runtime/src/heat_balance/'
nodes=texts[P+'ordinary_equipment/source_nodes.rs']
lists=texts[P+'ordinary_equipment/source_node_lists.rs']
owner=texts[P+'ordinary_equipment.rs']
caller=texts[P+'ordinary_equipment/source_input.rs']
test=texts[P+'ordinary_equipment_tests.rs']
node_hh=native['src/EnergyPlus/DataLoopNode.hh'].decode()
native_block=node_hh.split('    struct NodeData\n',1)[1].split('    struct MoreNodeData',1)[0]
native_fields=re.findall(r'^\s*(FluidType|int|Real64|bool|Sched::Schedule\s*\*)\s*(\w+)\s*=\s*([^;]+);',native_block,re.M)
source_block=nodes.split('pub(super) struct SourceNodeData {',1)[1].split('\n}',1)[0]
source_fields=re.findall(r'^\s*pub\(super\) (\w+): ([^,]+),',source_block,re.M)
default_block=nodes.split('impl Default for SourceNodeData {',1)[1].split('/// Actual DataLoopNode.hh525',1)[0]
defaults=re.findall(r'^\s*(\w+): (.+),$',default_block,re.M)
assert len(native_fields)==len(source_fields)==len(defaults)==48
authored_ledger=load(m['constructor_correspondence'])
assert authored_ledger['field_count']==48
type_mapping={'FluidType':'SourceNodeFluidType','int':'i32','Real64':'f64','bool':'bool','Sched::Schedule *':'Option<SourceScheduleIndex>'}
literal_mapping={'FluidType::Blank':'SourceNodeFluidType::Blank','SensedNodeFlagValue':'-999.0','DataEnvironment::StdPressureSeaLevel':'101_325.0','nullptr':'None'}
constructor=[]
for (nt,nn,nv),(sn,st),(dn,dv),authored in zip(native_fields,source_fields,defaults,authored_ledger['ordered_fields'],strict=True):
    assert sn==dn==authored['Source_field'] and nn==authored['Native_field']
    assert st==type_mapping[nt] and dv==literal_mapping.get(nv,nv)
    constructor.append({'Native_field':nn,'Source_field':sn,'Native_type':nt,'Source_type':st,'Native_constructor':nv,'Source_constructor':dv})
assert 'constexpr Real64 SensedNodeFlagValue(-999.0)' in node_hh or 'SensedNodeFlagValue = -999.0' in node_hh
assert re.search(r'StdPressureSeaLevel\s*\(101325\.0\)',native['src/EnergyPlus/DataEnvironment.hh'].decode())
constructor_ref=put('independent-48-field-constructor.json',(json.dumps(constructor,indent=2)+'\n').encode())
assert '[bool; 9]' in nodes and '#[derive(Clone, Debug, Default, PartialEq)]\npub(super) struct SourceNodeSetpointCheck' in nodes
assert 'physical: Option<Vec<SourceNodeData>>' in owner and 'NodeStateStore' not in owner
assert 'default_node_values: SourceNodeData::default(),' in owner and 'physical: None,' in owner
assert 'if entry == name { found = Some(number); break; }' in nodes
assert nodes.index('*reference = reference.checked_add(1)') < nodes.index('if fluid_type != SourceNodeFluidType::Blank')
assert 'self.node_ids = Some(vec![String::new(); 2]);' in nodes and 'names[0] = "Undefined".into();' in nodes
assert 'row.fluid_type == SourceNodeFluidType::Blank' in nodes
first=nodes.split('self.physical = Some(vec![SourceNodeData::default()]);',1)[1]
assert first.index('?.fluid_type = fluid_type;') < first.index('self.number_of_nodes = 1;') < first.index('self.node_ids =') < first.index('self.node_references =') < first.index('self.marked_nodes =') < first.index('self.node_setpoint_checks =') < first.index('self.number_of_unique_node_names = 1;')
growth=nodes.split('// Native redimension order711-715, preserving every prior row.',1)[1].split('return Ok(self.number_of_unique_node_names);',1)[0]
assert [growth.index(s) for s in ['self.physical','self.node_ids','self.node_references','self.marked_nodes','self.node_setpoint_checks']]==sorted(growth.index(s) for s in ['self.physical','self.node_ids','self.node_references','self.marked_nodes','self.node_setpoint_checks'])
assert lists.index('self.node_lists = Some(') < lists.index('if self.number_of_node_lists > 1') < lists.index('input.source_raw_object_names') < lists.index('input.mark_object_as_used')
assert lists.index('alphas.fill(String::new()); numbers.fill(0.0);') < lists.index('input.mark_object_as_used')
assert 'SourceNodeFluidType::Blank, &mut local_errors_found' in lists and '.eq_ignore_ascii_case(&row.name)' in lists
assert caller.index('let controlled_zones =') < caller.index('let node = definition(') < caller.index('.init_unique_check_source(') < caller.index('if controlled_zones > 0')
assert caller.index('self.get_source_node_lists_input(input, &mut errors_found)?;') < caller.index('self.get_input = false;')
assert test.count('#[test]')==1==check(oldfiles[P+'ordinary_equipment_tests.rs']['before']).read_text(encoding='utf-8').count('#[test]')
assert 'Some(vec![SourceNodeData::default()])' in test and 'assert_eq!(owner.nodes.number_of_nodes, 0);' in test

contexts=[]
for p in [P+'selected_input_processor.rs',P+'selected_input_processor/input_statistics.rs',P+'ordinary_equipment/source_marked_nodes.rs',P+'ordinary_equipment/source_reset.rs',P+'ordinary_equipment/source_setup_reporting.rs',P+'ordinary_equipment/node_reporting.rs','crates/ep_raw_model/src/idf_order.rs','crates/ep_raw_model/src/lib.rs']:
    b=check(observed[p]['archive']).read_bytes()
    assert b==(R/p).read_bytes()==subprocess.check_output(['git','show',head+':'+p],cwd=R)
    contexts.append({'path':p,'actual13_archive':observed[p]['archive'],'whole_current_Git_equal':True})
plan=load(m['complete_final_compiler_Source_plan'])
entries={r['path']:r for r in plan['entries']}
assert len(entries)==plan['inputs']==4480 and plan['Rust_sources']==4467
assert set(entries)==set(observed)|{r['canonical_path'] for r in m['files'] if r['before_absent']}
selected={r['canonical_path']:r for r in m['files']}
for p,e in entries.items():
    if p in selected:
        row=selected[p]
        assert (e['final_sha256'],e['final_bytes'])==(row['proposed']['sha256'],row['proposed']['bytes'])
        assert check(e['source']).read_bytes()==check(row['proposed']).read_bytes()
    else:
        assert (e['final_sha256'],e['final_bytes'])==(observed[p]['archive']['sha256'],observed[p]['size_bytes'])
        assert e['source']['sha256']==observed[p]['archive']['sha256']
check(m['author_Source']); check(m['sealer_Source'])
review={
    'schema':'src06-genuine-Node-input-independent-Source-review.v1','status':'accepted','accepted':True,'findings':[],
    'packet':mref,'superseded_packet':m['supersedes'],'order_correction':m['order_correction'],
    'scope':'Independent full five-Source review against pinned whole Native and narrow exact parent bridges; Node-only plan metadata comparison, not a full4480 Source reread. Actual execution remains Root-owned and pending.',
    'base_HEAD':head,'actual13_earlier_nominal_frontier':m['actual_B_frontier_receipt'],'actual13_snapshot':m['actual_parent_snapshot'],
    'files':file_rows,'literal_applications':10,'additional_correction_literal_applications':2,'whole_parent_recoveries':3,'new_source_empty_recoveries':2,'independent_parse_exits':[0]*5,
    'Native_wholes_verified_against_pinned_Git_and_current':m['Native_wholes'],'Native_strict_extents_verified':m['Native_literal_extents'],
    'constructor48':constructor_ref,'unchanged_contexts':contexts,
    'complete_Node_only_plan':m['complete_final_compiler_Source_plan'],
    'plan_comparison':{'parent_inputs':4478,'final_inputs':4480,'final_Rust':4467,'existing_changes':3,'new_sources':2,'all_other4475_parent_metadata_equal':True,'Root_full_rehash_required':True,'nominal_lookup03_not_silently_joined':True},
    'resolved_finding':'Source01 generic NodeList IDF-order claim was unsupported because IDF_ORDER_TARGETS omits this family. Source02 explicitly stops multi-list before the first getter/unused erase, after true counts/list allocation/name clears. Finite sole-list ordinal/member sequence unchanged.',
    'semantic_review':[
        'Sole existing NodeOwner physical payload is replaced by all48 genuine NodeData fields; diagnostic NodeStateStore is removed from this owner. Native DefaultNodeValues exists before physical array allocation. No typed node vector or duplicate physical state is substituted.',
        'All48 types/order/constructors independently extracted and matched, including Blank fluid, seven -999 sensed values, sea-level101325 pressure, height-1, four null schedules and all false/zero flags; same SourceScheduleIndex is used only for future genuine schedule pointers.',
        'First Assign allocation/writer order and growth redimension order preserve Native Node/NodeID/NodeRef/Marked/9-flag Setpoint arrays and independent counters. NodeID0 alone becomes Undefined; definition ref0 and pre-fluid-check existing-name ref increment are exact. Case-sensitive FindItemInList and Blank promotion retained. Diagnostics remain typed at first unported operation.',
        'Actual NodeList query uses existing IP schema/counts/raw fields and one retained list identity, actual unused erase, local resets/uppercase projection, member array order and real Assign Blank calls. No fake positive count, fresh node open/reset, fixture-value producer or typed graph names are inserted.',
        'Existing equipment counts/definition maxima/local allocations/gains/config/list/availability reserve precede real diagnostic bounds and InitUnique. Its actual NodeList producer returns before get_input=false and genuine uniqueness context. Positive controlled-zone getObjectItem then stops honestly; no controlled flag or equipment readiness is fabricated.',
        'Only one existing test is adapted to the genuine payload/Vec length, retaining independent physical-allocation-vs-counter assertion; no new test body or Native positive runtime conformance claim. Positive reset/reporting/setpoint consumers remain explicit existing boundaries.'
    ],
    'qualifications':['Successful finite raw string/member domain only; malformed JSON/numeric alphas and warning/severe diagnostic branches remain typed unavailable, with preceding genuine mutations retained.','Node02 follows an actual13 earlier nominal Zone stop, so no Node runtime success is inferred. Root must join separately reviewed nominal lookup03, fully rehash/compile, and observe actual B and A24.'],
    'main_mutations':0,'Cargo_Native_or_tests_executed':False,'reviewer_Source':ref(Path(__file__))
}
out=O/'review.json'
out.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(ref(out)))

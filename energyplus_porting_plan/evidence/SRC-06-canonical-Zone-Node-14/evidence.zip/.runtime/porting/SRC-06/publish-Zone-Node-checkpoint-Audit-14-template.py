"""Root-only finite checkpoint14 publisher; no Cargo/tests/Native execution.

Requires actual check, one existing owner test, B/A24 and accepted Root review.
Only selected7Source bytes are reread; Root owns complete4480 snapshot proof.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
READY=D/'Zone-Node-publication-prepared-Audit-14'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-Zone-Node-14'
BACK=D/'Zone-Node-publication-readback-Audit-14'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R.resolve()).as_posix(),sha256=digest(p),bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();p.relative_to(R.resolve())
 assert digest(p)==v['sha256'] and p.stat().st_size==v.get('bytes',v.get('size_bytes',p.stat().st_size)),v['path'];return p
def load(p):return json.loads(p.read_bytes())
def accepted(p):
 v=load(p);assert (v.get('accepted') is True or v.get('status')=='accepted') and not v.get('findings',[]),p;return v
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(args):
 assert args.publish and not PUBLIC.exists() and not BACK.exists()
 dp=READY/'publication-template.json';draft=load(dp)
 assert draft['status']=='HELD_PENDING_ACTUAL_RECEIPTS'
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 assert head==draft['base_HEAD']=='392134441c3b9db53951de8b245ca910b39e7625'
 pp=checked(draft['complete_plan']);plan=load(pp)
 assert plan['inputs']==4480 and plan['Rust_sources']==4467 and len(plan['selected'])==7
 assert ref(pp)['sha256']=='7dd9c7cc8c2d70b069404a835c508d41d9c8913289479e56110ce596628bbca6'
 fixture=checked(draft['existing_test_JSON_fixture'])
 assert fixture.read_bytes()==subprocess.check_output(['git','show',head+':'+draft['existing_test_JSON_fixture']['path']],cwd=R)
 for r in draft['independent_peers']:accepted(checked(r))
 vp=(R/args.validation_refs).resolve();vp.relative_to(R.resolve());v=load(vp)
 assert set(v)=={'Root_actual_review','check','test','B_CLI','A24_CLI','B_summary','B_diagnostics','A24_summary','A24_diagnostics'}
 rp=checked(v['Root_actual_review']);root=accepted(rp);assert ref(rp)==draft['actual_review']
 assert root['same4480_archived_inputs_exact_final_plan'] and root['selected7_final_sources_exact']
 assert root['first_B_core_fresh_false'] and root['A24_same_core_reused_fresh_true']
 assert root['actual_test_bodies_executed']==1 and root['new_test_bodies']==0
 assert root['existing_test_fixture_separately_Git_bound']==draft['existing_test_JSON_fixture']
 assert root['B_preceding_nominal_NodeList_Assign_InitUnique_returned'] and not root['B_runtime_or_fallback_results']
 assert root['original_tolerance_RMSE_5352_proof_transferred'] and root['policy_changes']==root['gate_changes']==0
 assert (root['transferred_reported_series'],root['transferred_JSON_CSV_scalar_roundtrips'],root['table_lines'],root['table_clock_metadata_changes'])==(58,5352,19312,30)
 assert root['whole_JSON_equal13_after_exactly_two_owned_path_field_bridges'] and root['full_runtime_equal13_after_two_owned_path_bridges']
 assert len(root['whole_physical_streams_equal13'])==7 and len(root['whole_CSV_equal13'])==2
 for r in draft['producer_packets']+draft['independent_peers']+[draft['complete_plan'],draft['existing_test_JSON_fixture']]+[v[k] for k in ['check','test','B_CLI','A24_CLI']]:assert contains(root,r),r['path']
 receipts=[load(checked(v[k])) for k in ['check','test','B_CLI','A24_CLI']]
 assert [x['exit_code'] for x in receipts]==[0,0,6,0]
 for x in receipts:assert x['launch_error'] is None and x['source_bytes_match_before_and_after'] and Path(x['cwd']).resolve()==R.resolve()
 assert all(x['source_snapshot']==receipts[0]['source_snapshot'] for x in receipts)
 assert '--all-targets' in receipts[0]['command'] and '--workspace' in receipts[0]['command']
 test_name='actual_native_get_equipment_pair_and_input_owner_transitions'
 assert 'test' in receipts[1]['command'] and any(test_name in arg for arg in receipts[1]['command'])
 assert 'test result: ok. 1 passed; 0 failed;' in checked(receipts[1]['stdout']).read_text(encoding='utf-8')
 for x,scope in zip(receipts[2:],['B','A']):
  c=x['command'];assert c[c.index('--porting-scope')+1]==scope and not {'--oracle-baseline','--compare-oracle'}&set(c)
 bs=load(checked(v['B_summary']));bd=load(checked(v['B_diagnostics']));asum=load(checked(v['A24_summary']));ad=load(checked(v['A24_diagnostics']))
 assert bs['exit_code']==6 and bs['rust_runtime'] is None
 errors=[x['message'] for x in bd['diagnostics'] if x['code']=='RuntimeConvergenceFailure']
 assert len(errors)==1 and errors[0]==draft['actual_B_frontier']
 assert asum['exit_code']==0 and asum['rust_runtime'] is not None and not any(x['code']=='RuntimeConvergenceFailure' for x in ad['diagnostics'])
 idx={x['path']:x for x in plan['entries']};snapshot=load(checked(receipts[0]['source_snapshot']))
 observed={x['historical_path']:x for x in snapshot['files']};assert set(observed)==set(idx)
 for n,x in plan['selected'].items():
  p=R/n;row=idx[n];assert digest(p)==row['final_sha256'] and p.stat().st_size==row['final_bytes']
  assert p.read_bytes()==checked(x['proposed']).read_bytes() and digest(checked(observed[n]['archive']))==row['final_sha256']
 base=R/'energyplus_porting_plan';names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']
 docs={n:(base/n).read_bytes() for n in names};pf=base/'plan.json';before=pf.read_bytes();beforev=json.loads(before)
 for n,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R) and '\ufffd' not in b.decode('utf-8','strict')
 assert before==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
 previous=load(checked(draft['previous_checkpoint']));assert (previous['A'],previous['B'])==('14/54','14/64')
 files={}
 def add(p):
  p=p.resolve();r=ref(p);n=r['path'];assert p.suffix.lower()!='.zip'
  assert n not in files or files[n]['ref']==r;files[n]=dict(path=p,ref=r)
 for r in draft['finite_archive_inputs']:add(checked(r))
 for p in [Path(__file__),dp,vp,rp]:add(p)
 for r in v.values():add(checked(r))
 for x in receipts:
  for k in ['stdout','stderr','source_snapshot']:add(checked(x[k]))
 for r in root.get('publication_artifacts',[]):add(checked(r))
 for n in plan['selected']:add(R/n)
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(before)
 for n,b in docs.items():p=BACK/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 zp=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,r in sorted(files.items()):assert ref(r['path'])==r['ref'];z.write(r['path'],arcname=n)
 with zipfile.ZipFile(zp) as z:
  assert z.testzip() is None and set(z.namelist())==set(files)
  for n,r in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==r['ref']['sha256']
 inventory=PUBLIC/'manifest.json';inventory.write_bytes((json.dumps(dict(schema='src06-canonical14-finite-evidence-archive.v1',archive=ref(zp),entries=[x['ref'] for n,x in sorted(files.items())],scope='Corrected nominal03/Node02 proposals, independent peers and final7Source plan plus four actual command receipts/Root accepted readback. Existing owner-test included JSON is bound separately to Git/current because rs-only recorder omits it. No Native simulation/cohort data replay, annual JSON/CSV or historical ZIP recursion.',full_transitive_rebuild_archive_claim=False),indent=2)+'\n').encode())
 summary=dict(draft['summary_template']);summary.update(schema='src06-canonical-Zone-Node.v1',status='Genuine nominal-controlled field lookup and retained Node input, existing owner test passed; B remains incomplete at exact actual operation',canonical_check=v['check'],canonical_existing_owner_test=v['test'],canonical_B_CLI=v['B_CLI'],canonical_A24_CLI=v['A24_CLI'],Root_actual_review=ref(rp),actual_B_incomplete_boundary=errors[0],actual_B_completed=False,B_preceding_nominal_NodeList_Assign_InitUnique_returned=True,canonical_A24_completed_Source_run=True,new_test_functions=0,A24_original_tolerance_and_roundtrip_proof_transferred=dict(series=58,samples=5352,unchanged_policy=root['unchanged_original_tolerance_policy'],accepted13_proof=root['accepted13_full5352_proof'],physical_files_whole_equal13=7,CSV_files_whole_equal13=2,table_lines=19312,only30_clock_line_changes_versus13=True,scope='Reported results proof transfer from accepted13; no new Native/72h/annual run or internal-state equivalence claim.'),actual_A_state_correction=root['explicit_A_state_correction'],validation_refs=ref(vp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json';sp.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 texts={
  'CHECKLIST.md':draft['doc_checklist'],
  'STATE_CONTRACTS.md':'Zone 제어 여부는 같은 InputProcessor의 실제 필드 조회로 설정하며, 알려진 부재 연결 유형에는 Native와 같은 Null을 삽입합니다. Node의 실제 개수·할당·NodeID0/Undefined·첫 확장 순서를 보존하고, 검증되지 않은 다중 IDF 순서는 명시적으로 중단합니다.',
  'cards/SRC-06.md':draft['doc_card']}
 rel='evidence/SRC-06-canonical-Zone-Node-14/summary.json'
 for n,b in docs.items():
  p=base/n;assert p.read_bytes()==b;link='../'+rel if n.startswith('cards/') else rel
  p.write_bytes(b+('\n\n[Source Zone·Node 입력 검증]('+link+'). '+texts[n]+'\n').encode())
 after=json.loads(before);task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_Zone_Node_14';assert key not in task
 task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=digest(sp),size_bytes=sp.stat().st_size)
 inverse=json.loads(json.dumps(after));del next(x for x in inverse['tasks'] if x['id']=='SRC-06')[key]
 assert inverse==beforev and pf.read_bytes()==before;pf.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),Git_mutated=False,Cargo_tests_Native_executed=False,gate_changes=False)
 p=BACK/'publication-readback.json';p.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--validation-refs',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

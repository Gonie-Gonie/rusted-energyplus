from pathlib import Path
import argparse,ast,difflib,hashlib,json,re,subprocess
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'source-Node-input-draft-Outer-01';O=B/'source-Node-input-held-Outer-02';N=R/'.reference/energyplus-src/26.1.0'
P=argparse.ArgumentParser();P.add_argument('--head',required=True);P.add_argument('--B-receipt',required=True);args=P.parse_args()
assert not O.exists();HIST='b82d16be8a96e854391636c615ddc07317a45d1f';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(x):
 p=R/x['path'];a=ref(p);assert a['sha256']==x['sha256'] and a['bytes']==x.get('bytes',a['bytes']);return p
def load(p):return json.loads(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==args.head
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=R)
receipt_path=R/args.B_receipt;receipt=load(receipt_path)
assert receipt['exit_code']==6 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
assert ref(receipt_path)['sha256']=='3144d1544002b39678eda01ff8e3df4612fcc9a1c24bbe011564455e3f7abc59'
diagnostics_path=R/'.runtime/porting/SRC-06/canonical-source-compact-B-NOLIMIT-24H-Root-13/output/diagnostics.json'
assert Path(receipt['command'][receipt['command'].index('--output-dir')+1]).resolve()==diagnostics_path.parent.resolve()
assert 'positive nominal controlled Zone lookup' in diagnostics_path.read_text(encoding='utf8')
snapshot=get(receipt['source_snapshot']);snap=load(snapshot);before={x['historical_path']:x for x in snap['files']};assert len(before)==4478
planpath=B/'source-controlled-equipment-Node-owner-plan-Peer-01/plan.json';assert ref(planpath)['sha256']=='6d5341233d8ab64c318133d8de9bbb0adf2b2f92170eba61f69ecb0eeea7e9aa';plan=load(planpath)
proposed={p.relative_to(D/'proposed').as_posix():p.read_bytes() for p in sorted((D/'proposed').rglob('*.rs'))};assert len(proposed)==5
assert sum(z.count(b'#[test]') for z in proposed.values())==1
for n,z in proposed.items():
 if n.endswith('_tests.rs'):continue
 assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unreachable|unimplemented)!',z)
 assert b'ZONE ONE INLET' not in z and b'ZONE ONE INLETS' not in z
S=(B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8');F=next(n for n in ast.parse(S).body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal');G={'re':re};exec(compile(ast.Module(body=[F],type_ignores=[]),'<whole-literal-applier>','exec'),G)
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==PIN
wholes=[]
for row in plan['Native_wholes']:
 z=get(row['frozen_whole']).read_bytes();assert z==subprocess.check_output(['git','-C',str(N),'show',PIN+':'+row['Native_path']]);wholes.append(row)
O.mkdir()
def put(n,z):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);return ref(p)
def doc(n,v):return put(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
for name in ['src/EnergyPlus/UtilityRoutines.cc','src/EnergyPlus/InputProcessing/InputProcessor.cc','src/EnergyPlus/DataHVACGlobals.hh']:
 z=(N/name).read_bytes();assert z==subprocess.check_output(['git','-C',str(N),'show',PIN+':'+name]);wholes.append(dict(Native_path=name,revision=PIN,whole_Git_equal=True,frozen_whole=put('Original-Git/'+name,z)))
by_native={x['Native_path']:x for x in wholes};extents=[]
for name,a,b,label in [
 ('src/EnergyPlus/DataLoopNode.hh',66,100,'FluidType/ConnectionType/SensedNodeFlagValue'),
 ('src/EnergyPlus/DataLoopNode.hh',439,500,'Whole NodeData48fields and constructors'),
 ('src/EnergyPlus/DataLoopNode.hh',515,530,'Whole MarkedNodeData and NodeSetpointCheckData'),
 ('src/EnergyPlus/DataLoopNode.hh',532,545,'LoopNodeData Node/NodeID/DefaultNodeValues owner'),
 ('src/EnergyPlus/DataHVACGlobals.hh',69,82,'Whole CtrlVarType enum9'),
 ('src/EnergyPlus/UtilityRoutines.cc',175,217,'Both case-sensitive FindItemInList overloads'),
 ('src/EnergyPlus/InputProcessing/InputProcessor.cc',745,891,'findMaxFields and alpha value setter operand order'),
 ('src/EnergyPlus/InputProcessing/InputProcessor.cc',932,1118,'Whole getObjectItem resets/name/unused/extensible reads'),
 ('src/EnergyPlus/NodeInputManager.cc',516,648,'Whole GetNodeListsInput'),
 ('src/EnergyPlus/NodeInputManager.cc',650,743,'Whole AssignNodeNumber'),
 ('src/EnergyPlus/NodeInputManager.cc',805,844,'Whole InitUniqueNodeCheck'),
 ('src/EnergyPlus/DataZoneEquipment.cc',224,307,'Counts/allocations/diagnostics/InitUnique before controlled getter')]:
 whole=by_native[name]['frozen_whole'];z=b''.join(get(whole).read_bytes().splitlines(True)[a-1:b]);extents.append(dict(Native_path=name,first_line=a,last_line=b,purpose=label,whole_source=whole,literal_excerpt=put(f'Native/{name.replace("/","_")}.L{a}-{b}.txt',z)))
files=[];bridges=[]
for i,(name,new) in enumerate(proposed.items(),1):
 q=subprocess.run(['git','show',args.head+':'+name],cwd=R,capture_output=True);old=q.stdout;absent=q.returncode==128
 assert absent or q.returncode==0
 if absent:assert not old and name not in before and not (R/name).exists()
 else:
  historical=subprocess.check_output(['git','show',HIST+':'+name],cwd=R)
  archived=get(before[name]['archive']).read_bytes()
  assert old==historical==archived==(D/'parent'/name).read_bytes()==(R/name).read_bytes()
  bridges.append(dict(path=name,current_Git_revision=args.head,historical_Git_revision=HIST,actual_parent_archive=before[name]['archive'],whole_equality=True))
 row=dict(canonical_path=name,before_absent=absent,before=put('before/'+name,old),proposed=put('proposed/'+name,new),literal_inverse=put('literal-inverse/'+name,old))
 for key,a,b in [('forward_diff',old,new),('inverse_diff',new,old)]:
  diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='before/'+name,tofile='proposed/'+name,n=3)).encode();assert G['apply_literal'](a,diff)==b;row[key]=put(f'diffs/{i:02}-{key}.diff',diff)
 v=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R);assert v.returncode==0,(name,v.stderr)
 row['Source_only_parse']=dict(exit_code=0,stdout=put(f'parse/{i:02}.stdout',v.stdout),stderr=put(f'parse/{i:02}.stderr',v.stderr));files.append(row)
assert sum(x['before_absent'] for x in files)==2
# Ordered constructor correspondence is checked against both actual whole files.
native=get(by_native['src/EnergyPlus/DataLoopNode.hh']['frozen_whole']).read_text(encoding='utf8');native=native[native.index('    struct NodeData'):native.index('    struct MoreNodeData')]
nf=[m.groups() for m in re.finditer(r'^\s*(FluidType|int|Real64|bool|Sched::Schedule \*)\s*(\w+)\s*=\s*([^;]+);',native,re.M)]
code=proposed['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs'].decode();body=code[code.index('pub(super) struct SourceNodeData'):code.index('impl Default for SourceNodeData')];sf=re.findall(r'pub\(super\)\s+(\w+):\s*([^,\n]+)',body)
ctor=code[code.index('impl Default for SourceNodeData'):code.index('/// Actual DataLoopNode.hh525')];sv=re.findall(r'^\s+(\w+): ([^,\n]+),',ctor,re.M);assert len(nf)==len(sf)==len(sv)==48
rows=[]
values={'FluidType::Blank':'SourceNodeFluidType::Blank','SensedNodeFlagValue':'-999.0','DataEnvironment::StdPressureSeaLevel':'101_325.0','nullptr':'None'}
for (nt,nn,nv),(sn,st),(vn,vv) in zip(nf,sf,sv):
 assert sn==vn and vv==values.get(nv,nv)
 assert st=={'FluidType':'SourceNodeFluidType','int':'i32','Real64':'f64','bool':'bool','Sched::Schedule *':'Option<SourceScheduleIndex>'}[nt]
 rows.append(dict(Native_field=nn,Native_type=nt,Native_constructor=nv,Source_field=sn,Source_type=st,Source_constructor=vv))
constructors=doc('Node-constructor-correspondence.json',dict(field_count=48,ordered_fields=rows,Native_sentinel=-999.0,Native_sea_level_pressure=101325.0,DefaultNodeValues='Full same-owner constructed record exists before physical allocation; no weather or typed NodeStateStore seeding.',setpoint_check='needsSetpointChecking false and nine actual CtrlVarType slots false.',NodeID='Only NodeID includes index0; first Assign writes Undefined. Physical/NodeRef/Marked/Setpoint vectors retain Native ordinal minus1 addressing.'))
entries=[];by={x['canonical_path']:x for x in files}
for name,row in sorted(before.items()):
 final=by[name]['proposed'] if name in by else dict(path=row['archive']['path'],sha256=row['archive']['sha256'],bytes=row['size_bytes'])
 entries.append(dict(path=name,final_sha256=final['sha256'],final_bytes=final['bytes'],source=final,origin='held Node proposal' if name in by else 'actual13 archived parent'))
for name,row in sorted(by.items()):
 if name not in before:
  final=row['proposed'];entries.append(dict(path=name,final_sha256=final['sha256'],final_bytes=final['bytes'],source=final,origin='new held Node Source'))
assert len(entries)==4480 and sum(x['path'].endswith('.rs') for x in entries)==4467
complete=doc('complete-final-compiler-Source-plan.json',dict(base_HEAD=args.head,parent_actual_snapshot=ref(snapshot),entries=sorted(entries,key=lambda x:x['path']),inputs=4480,Rust_sources=4467,Root_independent_rehash_required=True))
contract=doc('integration-contract.json',dict(scope='Genuine same-owner NodeList/AssignNodeNumber/InitUnique valid input path only; no controlled-zone or equipment producer success claim.',actual13_frontier_qualification='Actual13 B3144d154 stops EARLIER at positive nominal controlled Zone lookup. It does not prove execution of equipment counts,InitUnique,NodeList or any Node write. This held Node path remains predicted/pending until Root composes the separate genuine nominal lookup and executes it.',counts_and_order='At the future actual call:3counts first; getter-local maxima/allocations/gains/config/list/availability/reserve then real list-count/zone-count diagnostic bounds. InitUnique calls genuine NodeList getter before actual first controlled getObjectItem typed stop.',owners='Existing NodeOwner.physical payload replaced with full48-field Native NodeData Vec; same count writers,NodeID/NodeRef/Marked/Setpoint/DefaultNodeValues. No diagnostic store retained and no typed model identity/cache/new manager. Existing BranchNodeConnections,SelectedZoneData and SelectedSizingManager remain untouched until their real positive consumers are ported.',assign='Literal case-sensitive FindItemInList. Existing-name increments NodeRef before fluid checks/promotion. First/growth allocation and new-row writers follow Native order; old rows preserved,NodeID0 Undefined,reference0 at definition.',raw_input='Same actual retained IP,single NodeList getter ordinal and original member-array order,actual unused erase,local alpha/numeric resets and uppercase alpha projection. NodeList has no IDF declaration overlay; actual count greater than1 stops after native list allocations/count/name-clear writes and before any getter/unused erase. No generic multi-list IDF order claim or fixture values/counts/names hardcoded into producer.',boundaries='Node/list diagnostic warnings/severe paths are typed unavailable at their first unported diagnostic; caller flags are not fabricated. Later controlled-zone/space getter,positive reset/reporting/setpoint validation remain honest stops. No guard-only successful positive route.',existing_test='Only existing test actual_native_get_equipment_pair_and_input_owner_transitions is adapted from diagnostic payload to one genuine default Node row/Vec length; its real allocation-vs-independent-counter assertion remains. Zero new #[test],no new mathematical code/test.',combined_plan='This full4480 plan is the Node-only successor over the actual13 snapshot. Root must explicitly join the separately held nominal-controlled Zone lookup proposals; they are not silently included or claimed by this Node packet.',required_next='Independent full Source peer then Root combined preflight/alltargets/existing applicable test as needed/actual B frontier and A24 regression; no author Cargo/Native/test execution.',main_mutations=0,Native_answer_production_inputs=False,B_completion_claim=False))
predecessor=B/'source-Node-input-held-Outer-01/manifest.json';assert ref(predecessor)['sha256']=='6a3a8f39f174f1db90288ce43336519c468a854f1d5c3e914c73d24356f02800'
prior=load(predecessor);changed=[]
for row in files:
 name=row['canonical_path'];oldrow=next(x for x in prior['files'] if x['canonical_path']==name);a=get(oldrow['proposed']).read_bytes();b=get(row['proposed']).read_bytes()
 if a==b:continue
 assert name.endswith('/source_node_lists.rs')
 evidence=dict(canonical_path=name,Source01=oldrow['proposed'],Source02=row['proposed'])
 for key,left,right in [('forward',a,b),('inverse',b,a)]:
  diff=''.join(difflib.unified_diff(left.decode().splitlines(True),right.decode().splitlines(True),fromfile='Source01/'+name,tofile='Source02/'+name,n=3)).encode();assert G['apply_literal'](left,diff)==right;evidence[key]=put('correction-'+key+'.diff',diff)
 changed.append(evidence)
assert len(changed)==1
correction=doc('correction-proof.json',dict(supersedes=ref(predecessor),reason='Source01 incorrectly claimed generic NodeList IDF ordinal from raw map order; NodeList is absent from IDF_ORDER_TARGETS. FiniteB sole list is exact, multi-list is now an explicit typed boundary after genuine arrays/counts/name-clears and before getter/unused erasure.',changed=changed,all_other_proposals_whole_identical=True,additional_literal_applications=2,finite_one_list_semantics_unchanged=True,order_authority=ref(R/'crates/ep_raw_model/src/idf_order.rs')))
manifest=doc('manifest.json',dict(schema='src06-held-genuine-NodeList-AssignNodeNumber-owner.v1',status='HELD Source only; Root application/compilation/actual pending',supersedes=ref(predecessor),order_correction=correction,base_HEAD=args.head,historical_unchanged_selected_revision=HIST,actual_B_frontier_receipt=ref(receipt_path),actual_B_earlier_nominal_frontier_diagnostics=ref(diagnostics_path),actual_parent_snapshot=ref(snapshot),precise_selected_file_bridges=bridges,files=files,existing_Source_files=3,new_Source_files=2,literal_applications=10,Source_only_parses=5,complete_final_compiler_Source_plan=complete,constructor_correspondence=constructors,integration_contract=contract,Native_plan=ref(planpath),Native_commit=PIN,Native_wholes=wholes,Native_literal_extents=extents,existing_test_bodies_preserved=1,new_test_bodies=0,main_mutations=0,Cargo_Native_or_tests_executed=False,physics_or_tolerance_changes=False,B_completion_claim=False,author_Source=ref(B/'author-source-Node-input-Outer-01.py'),sealer_Source=ref(Path(__file__))))
print(json.dumps(manifest))

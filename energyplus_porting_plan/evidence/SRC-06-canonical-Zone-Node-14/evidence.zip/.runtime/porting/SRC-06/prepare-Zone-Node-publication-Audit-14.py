from pathlib import Path
import ast,hashlib,json,sys
sys.stdout.reconfigure(encoding='utf-8')
R=Path.cwd();D=Path('.runtime/porting/SRC-06');READY=D/'Zone-Node-publication-prepared-Audit-14'
READY.mkdir(exist_ok=True)
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
inputs={}
def add(p):
 r=ref(p);assert Path(p).suffix.lower()!='.zip';inputs[r['path']]=r
def addref(r):
 a=ref(r['path']);assert a['sha256']==r['sha256'] and a['bytes']==r.get('bytes',r.get('size_bytes',a['bytes']));add(r['path'])
preflight=D/'Root-combined-Zone-Node-preflight-14/review.json';pre=json.loads(preflight.read_bytes())
assert ref(preflight)['sha256']=='210c08a9185805015d8ee4f7351b30318f92d9b32fa44d0016891fba56cdf9fa'
planref=pre['complete_compiler_plan'];assert planref['sha256']=='7dd9c7cc8c2d70b069404a835c508d41d9c8913289479e56110ce596628bbca6'
plan=json.loads(Path(planref['path']).read_bytes());assert plan['inputs']==4480 and len(plan['selected'])==7
packets=[pre['node_manifest'],pre['nominal_lookup_manifest']]
peers=[ref(D/'Peer-genuine-Node-input-Source-review-02/review.json'),ref(D/'Audit-nominal-controlled-Zone-lookup-Source-review-01/review.json')]
assert [r['sha256'] for r in peers]==['0e94110b17aac5dcf9d5f3d9e1dcd01475c3870f063526f97115ac1572e97e16','90ccf29cb9532505e095298d37c560e94e830beb58d45a4eda711a6b0d814348']
add(preflight);addref(pre['author_Source']);addref(planref);add(D/'Root-combined-Zone-Node-application-14/receipt.json')
for r in peers:
 addref(r);review=json.loads(Path(r['path']).read_bytes())
 for key in ['author_Source','reviewer_Source']:
  if key in review:addref(review[key])
for r in packets:
 addref(r);m=json.loads(Path(r['path']).read_bytes());addref(m['author_Source'])
 if 'sealer_Source' in m:addref(m['sealer_Source'])
 for f in m['files']:
  for key in ['before','proposed','forward_diff','inverse_diff']:addref(f[key])
 if 'Native_literal_extents' in m:
  for e in m['Native_literal_extents']:addref(e['literal_excerpt'])
 if 'Native' in m:
  for n in m['Native']:
   for e in n['extents']:addref(e['strict_extent'])
 for key in ['constructor_correspondence','integration_contract']:
  if key in m:addref(m[key])
fixture=Path('crates/ep_runtime/src/heat_balance/fixtures/ordinary_equipment_native_selected.json');add(fixture)
previous=Path('energyplus_porting_plan/evidence/SRC-06-canonical-compact-schedules-13/summary.json');add(previous)
publisher=D/'publish-Zone-Node-checkpoint-Audit-14-template.py';ast.parse(publisher.read_text(encoding='utf-8'));add(publisher);add(Path(__file__).relative_to(R))
template=dict(schema='src06-held-canonical14-publication-template.v1',status='HELD_PENDING_ACTUAL_RECEIPTS',base_HEAD=plan['base_HEAD'],complete_plan=planref,producer_packets=packets,independent_peers=peers,preflight=ref(preflight),application=ref(D/'Root-combined-Zone-Node-application-14/receipt.json'),existing_test_JSON_fixture=ref(fixture),previous_checkpoint=ref(previous),publisher_Source=ref(publisher),summary_template=dict(A='14/54',B='14/64',changed_Rust_sources=7,new_Rust_sources=2,new_test_functions=0,existing_test='actual_native_get_equipment_pair_and_input_owner_transitions',test_scope='One existing Native uncontrolled pair7 plus actual input/owner transition assertions. This is not positive-Node Native paired validation or an eight-case all-pass claim.',existing_included_JSON_fixture=ref(fixture),fixture_snapshot_scope='Existing recorder captures rs/Cargo only; included tracked JSON bytes are bound separately to Git/current and archived directly. No recorder change.',producer_packets=packets,independent_peers=peers,complete_compiler_plan=planref,full_B_or_finite15_completion_claim=False,gate_changes=False,scope='Genuine same-IP nominal-controlled raw field query/null side effect; retained Native Node defaults/counters/first growth/GetNodeLists. Corrected single-object IDF ordinal domains; positive unrepresented branches stop explicitly.'),targets=['energyplus_porting_plan/evidence/SRC-06-canonical-Zone-Node-14/summary.json','energyplus_porting_plan/evidence/SRC-06-canonical-Zone-Node-14/manifest.json','energyplus_porting_plan/evidence/SRC-06-canonical-Zone-Node-14/evidence.zip'],append_existing_docs=['energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/cards/SRC-06.md'],plan_add_only='SRC-06.canonical_Zone_Node_14',actual_review=None,actual_B_frontier=None,doc_checklist=None,doc_card=None,publisher_executed=False,canonical_docs_mutations=False,Cargo_tests_Native_executed=False,gate_changes=False,author_Source=ref(Path(__file__).relative_to(R)))
actual_path=D/'Root-source-Zone-Node-actual-review-14/review.json'
if actual_path.exists():
 actual=json.loads(actual_path.read_bytes());assert actual['accepted'] is True and not actual['findings']
 assert ref(actual_path)['sha256']=='141d461e0070e3eb5c38fa0d5585f7dd4cb58c4141f91de637bc28dfefb131a8'
 add(actual_path)
 if 'author_Source' in actual:addref(actual['author_Source'])
 addref(actual['accepted13_full5352_proof']);addref(actual['unchanged_original_tolerance_policy'])
 addref(actual['comparison_helper_Source'])
 template['actual_review']=ref(actual_path)
 template['actual_B_frontier']=actual['B_frontier']
 template['doc_checklist']='Zone·Node 입력 경로의 기존 소유자 테스트와 A-24H 회귀를 통과했습니다. B는 장비 연결 입력 조회에서 미완료이며 A14/54·B14/64 게이트는 유지합니다.'
 template['doc_card']='같은 입력 소유자의 제어 Zone 조회와 NodeList·Assign·InitUnique 경로를 연결했습니다. 기존 Native 비제어 입력 1쌍(pair7)·소유자 전이 테스트 및 A-24H 회귀를 통과했고 5,352개 보고값의 기존 검증도 유지했습니다. B는 GetZoneEquipmentData308의 EquipmentConnections getObjectItem에서 중단합니다. 입력된 Node의 Native 상태 대조와 후속 B 장비 포팅은 남아 있으며 A14/54·B14/64 게이트는 유지합니다.'
 validation=dict(Root_actual_review=ref(actual_path),check=actual['actual_check'],test=actual['actual_owner_test'],B_CLI=actual['actual_B'],A24_CLI=actual['actual_A24'])
 for label,run in [('B','canonical-source-Zone-Node-B-NOLIMIT-24H-Root-14'),('A24','canonical-source-Zone-Node-A-24H-Root-14')]:
  for suffix,name in [('summary','run-summary.json'),('diagnostics','diagnostics.json')]:
   target=D/run/'output'/name;r=ref(target);assert r in actual['publication_artifacts'];validation[label+'_'+suffix]=r
 (READY/'validation-refs.json').write_bytes((json.dumps(validation,indent=2)+'\n').encode())
template.update(finite_archive_inputs=[r for n,r in sorted(inputs.items())],finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(r['bytes'] for r in inputs.values()))
p=READY/'publication-template.json';p.write_bytes((json.dumps(template,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(template=ref(p),publisher=ref(publisher),archive_inputs=len(inputs),raw_bytes=template['finite_archive_input_bytes']),indent=2))

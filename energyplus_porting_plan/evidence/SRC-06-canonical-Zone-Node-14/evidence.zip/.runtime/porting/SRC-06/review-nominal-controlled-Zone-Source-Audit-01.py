from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
MP=Path('.runtime/porting/SRC-06/source-nominal-controlled-Zone-lookup-held-Peer-03/manifest.json')
OUT=Path('.runtime/porting/SRC-06/Audit-nominal-controlled-Zone-lookup-Source-review-01')
assert not OUT.exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.as_posix(),sha256=sha(b),bytes=len(b))
assert ref(MP)['sha256']=='43068c478d9795f4b06346a973b0217bfbb40c798f6a9012bc4d6ebb6831ec8d'
m=json.loads(MP.read_bytes());BASE=m['base_HEAD']
assert BASE=='b82d16be8a96e854391636c615ddc07317a45d1f'
refs={}
def auth(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   b=Path(v['path']).read_bytes();assert sha(b)==v['sha256'],v['path']
   if 'bytes' in v:assert len(b)==v['bytes']
   refs[v['path']]=sha(b)
  for x in v.values():auth(x)
 elif isinstance(v,list):
  for x in v:auth(x)
auth(m)
s=Path('.runtime/porting/SRC-06/review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8')
node=next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name=='apply')
ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'literal_whole_apply','exec'),ns)
snapshot=json.loads(Path(m['actual13_snapshot']['path']).read_bytes())
actual={r['historical_path']:r for r in snapshot['files']}
plan=json.loads(Path(m['parent_final_compiler_plan']['path']).read_bytes())
planned={r['path']:r for r in plan['entries']}
assert len(actual)==len(planned)==4478
assert set(actual)==set(planned)
for p,r in actual.items():assert r['archive']['sha256']==planned[p]['final_sha256'] and r['size_bytes']==planned[p]['final_bytes']
selected=[]
for f in m['files']:
 p=f['canonical_path'];before=Path(f['before']['path']).read_bytes();after=Path(f['proposed']['path']).read_bytes()
 assert before==Path(p).read_bytes()==Path(f['actual13_archive']['path']).read_bytes()
 assert before==subprocess.check_output(['git','show',BASE+':'+p])
 assert before==subprocess.check_output(['git','show','HEAD:'+p])
 assert sha(before)==actual[p]['archive']['sha256']
 assert ns['apply'](before,Path(f['forward_diff']['path']).read_bytes())==after
 assert ns['apply'](after,Path(f['inverse_diff']['path']).read_bytes())==before
 assert Path(f['literal_inverse']['path']).read_bytes()==before
 r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True)
 assert r.returncode==0 and not r.stderr and r.stdout==Path(f['parse']['stdout']['path']).read_bytes()
 selected.append(dict(path=p,before_sha256=sha(before),after_sha256=sha(after),fresh_parse_exit=0))
for row in m['context']:
 p=row['canonical_path'];b=Path(row['frozen']['path']).read_bytes()
 assert b==Path(row['actual13_archive']['path']).read_bytes()==Path(p).read_bytes()
 assert b==subprocess.check_output(['git','show',BASE+':'+p])
 assert sha(b)==actual[p]['archive']['sha256']
N=Path('.reference/energyplus-src/26.1.0');PIN='6f2e40d10250a105b49966baa24d843711e61048'
extent_count=0
for row in m['Native']:
 assert row['pinned_revision']==PIN
 b=(N/row['path']).read_bytes();assert sha(b)==row['whole_sha256'] and len(b)==row['whole_bytes']
 assert b==subprocess.check_output(['git','-C',str(N),'show',PIN+':'+row['path']])
 for e in row['extents']:
  excerpt=b''.join(b.splitlines(True)[e['first_line']-1:e['last_line']])
  assert excerpt==Path(e['strict_extent']['path']).read_bytes();extent_count+=1
stats=next(Path(f['proposed']['path']).read_text(encoding='utf-8') for f in m['files'] if f['canonical_path'].endswith('input_statistics.rs'))
body=stats[stats.index('    pub(crate) fn get_object_item_num_by_field('):stats.index('    /// Actual Native322 child')]
assert 'raw.object_order' not in body
assert 'if !source_is_epjson && objects.len() != 1' in body
assert body.index('value.eq_ignore_ascii_case(object_name)')<body.index('objects.len() != 1')
assert '.or_insert(SourceInputFamily::Null)' in body
assert not any(word in body for word in ['mark_object_as_used(', 'get_num_objects_found(', 'shortcut', '#[test]'])
assert not re.search(r'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)!',body)
zone=next(Path(f['proposed']['path']).read_text(encoding='utf-8') for f in m['files'] if f['canonical_path'].endswith('/zone.rs'))
assert 'zone.is_nominal_controlled = owners.input.get_object_item_num_by_field(' in zone
assert 'raw.source_is_epjson,' in zone and '))? > 0;' in zone
assert zone.index('zone.is_nominal_controlled = owners.input.get_object_item_num_by_field(')<zone.index('owners.shortcut.current_module_object = "ZoneList"')
raw_path=Path('.runtime/porting/SRC-06/canonical-source-compact-B-NOLIMIT-24H-Root-13/output/input/converted.epJSON')
raw=json.loads(raw_path.read_bytes());connections=raw['ZoneHVAC:EquipmentConnections'];assert len(connections)==1 and len(raw['Zone'])==1
zone_name=next(iter(raw['Zone']));assert zone_name.isascii()
connection=next(iter(connections.values()));assert isinstance(connection['zone_name'],str) and connection['zone_name'].isascii() and connection['zone_name'].upper()==zone_name.upper()
review=dict(schema='src06-nominal-controlled-Zone-independent-Source-review.v1',status='accepted',findings=[],packet=ref(MP),reviewer_Source=ref(Path('.runtime/porting/SRC-06/review-nominal-controlled-Zone-Source-Audit-01.py')),selected=selected,literal_applications=4,fresh_parse_exits=[0,0],context_wholes=6,Native_pinned_Git_wholes=4,Native_strict_extents=extent_count,parent_actual_snapshot_metadata_entries=4478,parent_snapshot_scope='Metadata equality to accepted final13 plan only; selected2 and6context archive/live/Git bytes independently authenticated. No redundant full4478 file rehash.',actual_B_raw=ref(raw_path),source_review=dict(query='Native field overload: represented case-insensitive schema identity, unknown-1; same-IP known-absent operator[] insertsNull, null/empty0. Original retained raw statistics fields, unused usage and shortcut state are untouched.',match='Lexical raw JSON object traversal and exact field-name lookup; missing fields skipped. Real string values compare using finite actual ASCII Native uppercasing semantics. Non-string/null at a present field remains typed unavailable instead of silently skipped. First matching JSON object is selected.',loader='Direct epJSON returns actual one-based JSON ordinal. Matched IDF admits exactly one object, where genuine getIDFObjNum is identity1; matched multi-object IDF stops before unsupported order conversion. Missing match returns0 without that conversion. Does not infer IDF order from unvalidated RawModel lexical fallback.',finding_resolution='Earlier02 generic IDF-order conversion finding is resolved by immutable03 matched-positive multi-object guard;02 is preserved, not accepted. Current RawModel targets/ordered_instances and SourceB projection were independently read and authenticated.',consumer='Finite actual B has exactly one ASCII-named Zone and one real connection whose raw zone_name matches. Same existing Zone.is_nominal_controlled receives query>0 before unchanged ZoneList/Group/local-environment continuation. No typed model/equipment/Node lookup, count-zero substitution or extra owner is used.',A_state='Known absent EquipmentConnections now retains real familyNull in existing InputProcessor, correcting the prior absent-family state omission; no unchanged-state claim or alternate boolean shortcut.',scope='Selected finite one-Zone/ASCII path and represented direct epJSON ordinals only. Full controlled-equipment/Node processing and actual next runtime frontier remain pending Root integration.'),nonblocking_notes=['After removing invalid order use, helper still binds unused loop name. This may emit an unused-variable warning; workspace does not deny that warning. Author and Root were informed; no further packet requested solely for it.'],main_mutations=False,Cargo_Native_or_tests_executed=False,new_tests=0)
OUT.mkdir();p=OUT/'review.json';p.write_bytes((json.dumps(review,indent=2)+'\n').encode());print(json.dumps(ref(p),indent=2))

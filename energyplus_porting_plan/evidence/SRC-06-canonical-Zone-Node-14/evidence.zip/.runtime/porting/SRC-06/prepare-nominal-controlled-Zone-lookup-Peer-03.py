"""Genuine field lookup on the retained IP; isolated HELD Sources only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'source-nominal-controlled-Zone-lookup-held-Peer-03'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
BASE = 'b82d16be8a96e854391636c615ddc07317a45d1f'
assert not O.exists()
O.mkdir()

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def check(r):
    p = R / r['path']
    a = ref(p)
    assert a['sha256'] == r['sha256'] and a['bytes'] == r.get('bytes', a['bytes']), r
    return p

def put(name, b):
    p = O / name
    assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return ref(p)

def doc(name, obj):
    return put(name, (json.dumps(obj, ensure_ascii=False, indent=2)+'\n').encode())

node = next(n for n in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(n, ast.FunctionDef) and n.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal-apply>', 'exec'), ns)

receipt_path = D/'canonical-source-compact-B-NOLIMIT-24H-command-Root-13/receipt.json'
actual = ref(receipt_path)
assert actual['sha256'].startswith('3144d154')
receipt = json.loads(receipt_path.read_bytes())
assert receipt['exit_code'] == 6 and receipt['source_bytes_match_before_and_after']
snapshot = json.loads(check(receipt['source_snapshot']).read_bytes())
assert len(snapshot['files']) == 4478
observed = {r['historical_path']: r for r in snapshot['files']}
plan_ref = {'path': '.runtime/porting/SRC-06/source-compact-compile-fix-held-Root-13/complete-final-compiler-Source-plan.json', 'sha256': '987d93621db9510f3f9dd1dd5c1f150262c74df282c184c4b60cec9aacb0871a', 'bytes': 2502682}
plan = json.loads(check(plan_ref).read_bytes())
assert plan['inputs'] == 4478 and plan['Rust_sources'] == 4465
assert {e['path']: (e['final_sha256'], e['final_bytes']) for e in plan['entries']} == {p: (r['archive']['sha256'], r['size_bytes']) for p, r in observed.items()}
diagnostic = R/'.runtime/porting/SRC-06/canonical-source-compact-B-NOLIMIT-24H-Root-13/output/diagnostics.json'
assert 'GetHeatBalanceInput: positive nominal controlled Zone lookup' in diagnostic.read_text(encoding='utf-8')

zone_path = 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone.rs'
ip_path = 'crates/ep_runtime/src/heat_balance/selected_input_processor/input_statistics.rs'
before_zone = subprocess.check_output(['git', 'show', BASE+':'+zone_path], cwd=R)
before_ip = subprocess.check_output(['git', 'show', BASE+':'+ip_path], cwd=R)
for p, b in [(zone_path, before_zone), (ip_path, before_ip)]:
    assert b == check(observed[p]['archive']).read_bytes() == (R/p).read_bytes()

old_zone = '''        // Actual getObjectItemNum(field="zone_name") has no positive candidate
        // in this admitted family. Do not replace it with a mutating query.
        if owners.input.family("ZoneHVAC:EquipmentConnections").is_some_and(|family| matches!(family, super::super::selected_input_processor::SourceInputFamily::Objects(rows) if !rows.is_empty())) {
            return Err(HeatBalanceInputError::Unavailable("positive nominal controlled Zone lookup"));
        }
        if let Some(zones) = self.zones.as_mut() {
            for zone in zones {
                zone.is_nominal_controlled = false;
            }
        }
'''
new_zone = '''        // Native GetZoneData1903: query the actual raw connection field for
        // each retained Zone; this does not consume the equipment object.
        if let Some(zones) = self.zones.as_mut() {
            for zone in zones {
                zone.is_nominal_controlled = owners.input.get_object_item_num_by_field(
                    "ZoneHVAC:EquipmentConnections",
                    "zone_name",
                    &zone.name,
                    raw.source_is_epjson,
                ).map_err(|_| HeatBalanceInputError::Unavailable(
                    "actual nominal controlled Zone raw field lookup",
                ))? > 0;
            }
        }
'''
anchor = '''    /// Actual Native322 child, after the six real shared shortcut allocations.
'''
helper = '''    /// Native getObjectItemNum1298 field overload on the same retained IP.
    /// Known absent families acquire the actual epJSON operator[] null; raw
    /// operands, object usage, shared arguments and defaults remain untouched.
    /// Direct epJSON retains JSON ordinals. A positive IDF match is admitted
    /// only for one object, where getIDFObjNum is the exact identity conversion.
    pub(crate) fn get_object_item_num_by_field(
        &mut self, object_type: &str, field: &str, object_name: &str,
        source_is_epjson: bool,
    ) -> Result<i32, SelectedInputUnavailable> {
        let Ok(canonical) = self.canonical_type(object_type) else { return Ok(-1); };
        match self.families.entry(canonical.clone()).or_insert(SourceInputFamily::Null) {
            SourceInputFamily::Null => return Ok(0),
            SourceInputFamily::Objects(objects) if objects.is_empty() => return Ok(0),
            SourceInputFamily::Objects(_) => {}
        }
        let raw = self.statistics_input.as_ref().ok_or(SelectedInputUnavailable::Association)?;
        let objects = raw.objects.get(&canonical).ok_or(SelectedInputUnavailable::Association)?;
        // Native JSON map traversal precedes getIDFObjNum: duplicate field
        // values select the first lexical object, not the first IDF object.
        for (json_index, (name, fields)) in objects.iter().enumerate() {
            let Some(value) = fields.get(field) else { continue; };
            let SourceInputStatisticsValue::String(value) = value else {
                return Err(SelectedInputUnavailable::Association);
            };
            if value.eq_ignore_ascii_case(object_name) {
                // EquipmentConnections has no validated IDF-order overlay.
                // Its actual finite single-object domain has ordinal 1 in
                // both orders; multi-object IDF conversion stays unavailable.
                if !source_is_epjson && objects.len() != 1 {
                    return Err(SelectedInputUnavailable::Association);
                }
                let index = json_index;
                return i32::try_from(index.checked_add(1).ok_or(SelectedInputUnavailable::Size)?)
                    .map_err(|_| SelectedInputUnavailable::Size);
            }
        }
        Ok(0)
    }

'''
assert before_zone.decode().count(old_zone) == 1 and before_ip.decode().count(anchor) == 1
proposed_zone = before_zone.decode().replace(old_zone, new_zone, 1).encode()
proposed_ip = before_ip.decode().replace(anchor, helper+anchor, 1).encode()

files = []
for i, (p, before, proposed) in enumerate([(zone_path, before_zone, proposed_zone), (ip_path, before_ip, proposed_ip)], 1):
    before_ref = put('before/'+p, before)
    after_ref = put('proposed/'+p, proposed)
    fd = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), proposed.decode().splitlines(keepends=True), fromfile=p, tofile=p)).encode()
    inv = ''.join(difflib.unified_diff(proposed.decode().splitlines(keepends=True), before.decode().splitlines(keepends=True), fromfile=p, tofile=p)).encode()
    assert ns['apply_literal'](before, fd) == proposed
    assert ns['apply_literal'](proposed, inv) == before
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=proposed, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and parsed.stderr == b''
    files.append({'canonical_path': p, 'before': before_ref, 'proposed': after_ref, 'actual13_archive': observed[p]['archive'], 'Git_b82_and_current_whole_equal_before': True, 'forward_diff': put(f'diffs/{i:02d}-forward.diff', fd), 'inverse_diff': put(f'diffs/{i:02d}-inverse.diff', inv), 'literal_inverse': put('literal-inverse/'+p, before), 'parse': {'exit_code': 0, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})

native = []
for path, extents in [
    ('src/EnergyPlus/HeatBalanceManager.cc', [(1903,1911)]),
    ('src/EnergyPlus/InputProcessing/InputProcessor.cc', [(114,125),(1122,1165),(1298,1341)]),
    ('src/EnergyPlus/UtilityRoutines.hh', [(600,627)]),
    ('src/EnergyPlus/DataGlobals.hh', [(88,97)]),
]:
    b = subprocess.check_output(['git', 'show', PIN+':'+path], cwd=N)
    assert b == (N/path).read_bytes()
    entry = {'path': path, 'pinned_revision': PIN, 'whole_sha256': hashlib.sha256(b).hexdigest(), 'whole_bytes': len(b), 'extents': []}
    lines = b.splitlines(keepends=True)
    for first, last in extents:
        excerpt = b''.join(lines[first-1:last])
        entry['extents'].append({'first_line': first, 'last_line': last, 'strict_extent': put(f'Native/{Path(path).name}-{first}-{last}.txt', excerpt)})
    native.append(entry)

context = []
for p in ['crates/ep_runtime/src/heat_balance/selected_input_processor.rs', 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/input.rs', 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs', 'crates/ep_raw_model/src/lib.rs', 'crates/ep_raw_model/src/idf_order.rs', 'crates/ep_run/src/ordinary_input_processor/input_statistics.rs']:
    b = check(observed[p]['archive']).read_bytes()
    assert b == (R/p).read_bytes() == subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
    context.append({'canonical_path':p,'actual13_archive':observed[p]['archive'],'frozen':put('context/'+p,b)})

manifest = {
    'schema':'src06-nominal-controlled-Zone-raw-field-lookup-held.v1',
    'base_HEAD': BASE, 'actual13_B_receipt':actual, 'actual13_snapshot':receipt['source_snapshot'],
    'actual_frontier': 'GetHeatBalanceInput: positive nominal controlled Zone lookup',
    'parent_final_compiler_plan': plan_ref, 'parent_plan_entries_equal_actual13_snapshot_metadata':True,
    'scope':'Genuine Native GetZoneData1903 per-Zone field lookup and exact same-owner isNominalControlled assignment, including known-absent null insertion, exact epJSON ordinal and exact finite single-object IDF identity conversion. No controlled equipment/Node completion claim.',
    'files': files, 'selected_existing_sources':2, 'new_sources':0, 'literal_applications':4, 'whole_parent_recoveries':2, 'parse_exits':[0,0],
    'Native':native,'context':context,
    'owner_and_semantics':[
        'The existing sole SelectedInputProcessor keeps both family presence/null and retained original raw fields/order; no new cache, projection or counter is added.',
        'Schema family lookup is case-insensitive in the represented definition closure; absent schema returns -1. Known absent epJSON family inserts Null on the same families owner; existing null/empty returns0. Original statistics_input raw maps remain pre-query operands.',
        'Raw object traversal is lexical JSON key order. Field lookup is exact-case and absent fields are skipped; existing non-string/null fields retain an explicit typed representability error instead of being silently skipped. String values compare with ASCII case semantics used by the finite Native inputs.',
        'A found first lexical raw object returns its one-based JSON ordinal for the actual epJSON loader. A positive IDF lookup is admitted only for one raw object, where the Native getIDFObjNum sort conversion is identically ordinal1. Missing matches still return0 without an IDF-order read. Positive multi-object IDF conversion remains typed unavailable: RawModel IDF_ORDER_TARGETS does not include EquipmentConnections, so its retained effective order would otherwise be lexical fallback.',
        'No getObjectItem, getNumObjectsFound, shortcut mutation, unused-input erasure or typed equipment lookup occurs. The only new persistent input side effect is Native known-absent null insertion. This corrects the prior A-state omission when its connection family was absent.',
        'After all existing ProcessZoneData iterations and output registration, the existing Zone rows receive the exact >0 result before the unchanged ZoneList/Group/local-environment statements.'
    ],
    'expected_after_lookup':'B continues toward genuine controlled-equipment/Node processing; the exact next runtime frontier is pending Root execution.',
    'supersedes':{'packet':ref(D/'source-nominal-controlled-Zone-lookup-held-Peer-02/manifest.json'),'reason':'Independent peer found that EquipmentConnections is not an IDF_ORDER_TARGET. Packet02 actual one-object B result is correct, but its generic retained IDF-order claim was unsupported. Packet03 removes that conversion claim and uses an explicit positive multi-object IDF boundary; no failed02 execution occurred.'},
    'main_mutations':0,'Cargo_Native_or_tests_executed':False,'new_test_bodies':0,
    'author_Source':ref(Path(__file__)),
}
mr = doc('manifest.json',manifest)
print(json.dumps(mr))

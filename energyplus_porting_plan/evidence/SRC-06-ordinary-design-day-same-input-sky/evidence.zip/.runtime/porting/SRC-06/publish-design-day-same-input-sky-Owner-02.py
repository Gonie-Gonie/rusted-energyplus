"""Root-only execution: finite actual same-input sky results; never run a target."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

ROOT = Path.cwd()
BASE = ROOT / '.runtime/porting/SRC-06'
OUT = ROOT / 'energyplus_porting_plan/evidence/SRC-06-ordinary-design-day-same-input-sky'
INITIAL = BASE / 'ordinary-design-day-same-input-sky-assembly-01/manifest.json'
INITIAL_SHA = '370b1b4c9f41a260cf316cb419ae5b4672d24f61d30f5600dd81e8ce013e0943'
CARGO = 'C:/Users/GonieGonie/.cargo/bin/cargo.exe'
TEST = 'warmup_hooks_copy_current_first_day_without_reading_or_prefetching'
COMMANDS = {
    'fmt': [CARGO, 'fmt', '--all', '--', '--check'],
    'quality': ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'scripts/quality/source-quality-gate.ps1'],
    'clippy': [CARGO, 'clippy', '-p', 'ep_runtime', '--all-targets', '--', '-D', 'warnings'],
    'tests': [CARGO, 'test', '-p', 'ep_runtime', '--lib', '--', 'weather::day::sky::tests::', TEST, '--nocapture'],
}

def load(path):
    return json.loads(path.read_bytes())

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8'))

def inside(value):
    path = (ROOT / value['path']).resolve()
    assert path.is_relative_to(ROOT.resolve()) and path.is_file(), value
    actual = ref(path)
    assert actual['sha256'] == value['sha256']
    assert actual['size_bytes'] == value.get('size_bytes', value.get('bytes', actual['size_bytes']))
    return path

parser = argparse.ArgumentParser()
parser.add_argument('--inputs', required=True, help='Root-authored actual reference packet, never inferred filenames')
args = parser.parse_args()
packet_path = Path(args.inputs).resolve()
assert packet_path.is_relative_to(ROOT.resolve())
packet = load(packet_path)
assert not OUT.exists(), 'fresh publication only'
artifacts = {}

def add(path):
    value = ref(path)
    artifacts[value['path']] = value
    return value

def checked(value):
    path = inside(value)
    add(path)
    return path

add(packet_path)
add(Path(__file__).resolve())
assert ref(INITIAL)['sha256'] == INITIAL_SHA
add(INITIAL)
initial = load(INITIAL)
assembly_path = checked(packet['final_assembly'])
assembly = load(assembly_path)
assert len(assembly['files']) == len(initial['files']) == 3
assert assembly['new_test_bodies'] == 0 and assembly['gates_updated'] is False
for row in initial['files']:
    for key in ['before', 'accepted_proposal', 'after', 'complete_actual_diff', 'held_to_actual_diff']:
        checked(row[key])
for row in assembly['files']:
    for key in ['before', 'accepted_proposal', 'after', 'complete_actual_diff', 'held_to_actual_diff']:
        checked(row[key])
    assert ref(ROOT / row['canonical_path']) == row['canonical']
    add(ROOT / row['canonical_path'])
old = {row['canonical_path']: inside(row['after']).read_bytes() for row in initial['files']}
new = {row['canonical_path']: inside(row['after']).read_bytes() for row in assembly['files']}
test_path = 'crates/ep_runtime/src/weather_day/design_day_native_tests.rs'
assert set(old) == set(new)
for path in old:
    if path == test_path:
        assert old[path].count(b'super::sky::initialize_design_day_sky') == 1
        assert new[path] == old[path].replace(b'super::sky::initialize_design_day_sky', b'super::super::sky::initialize_design_day_sky', 1)
    else:
        assert new[path] == old[path], 'production extraction must remain unchanged'

for key in ['actual_application_review', 'correction', 'correction_review']:
    path = checked(packet[key])
    if key.endswith('review'):
        assert load(path)['accepted'] is True
    if key == 'actual_application_review':
        assert load(path)['actual_assembly'] == ref(assembly_path)
        assert ref(path)['sha256'] == 'f9fe61fb45389bd16b54ec54c198975670a564561651b7398520244f3bb34343'
initial_application_review = BASE / 'Header-design-day-same-input-sky-application-review-01/review.json'
assert ref(initial_application_review)['sha256'] == '4d03dcdc044e4e361ed62ff4142ff8c1e030ff6178f82e5a3589e018e6acb34b'
add(initial_application_review)
checked(assembly['apply'])
held_path = checked(initial['accepted_packet'])
held = load(held_path)
checked(initial['independent_Source_review'])
checked(held['author'])
checked(held['README'])
checked(held['audit'])
for row in held['direct_Original_ranges']:
    checked(row['literal'])
fixture_path = checked(held['actual_immutable_fixture'])
fixture = load(fixture_path)
assert fixture['schema'] == 'src06-actual-design-day-weather-fixture.v1'
events = fixture['design_day_manage_weather_returns']
assert len(events) == 6
expected = {}
for event in events:
    ordinal = event['actual_setup_call_ordinal']
    rows = event['weather']['wvarsHrTsToday']['rows']
    assert len(rows) == 96
    for row in rows:
        key = (ordinal, row['hour'], row['timestep'])
        assert key not in expected
        value = row['value']
        assert int(value['OpaqueSkyCover']['value_bits'], 16) == 0
        expected[key] = {field: value[field]['value_bits'].lower() for field in ['OutDryBulbTemp', 'OutDewPointTemp', 'OutRelHum', 'OpaqueSkyCover', 'HorizIRSky', 'SkyTemp']}
assert len(expected) == 576

def receipt(value):
    path = checked(value)
    data = load(path)
    assert data['launch_error'] is None and data['source_bytes_match_before_and_after'] is True
    for key in ['stdout', 'stderr', 'source_snapshot']:
        checked(data[key])
    checked(data['executed_launcher']['archive'])
    return data

qa = {}
for role, command in COMMANDS.items():
    value = receipt(packet['QA'][role])
    assert value['command'] == command
    if role != 'tests':
        assert value['exit_code'] == 0
    qa[role] = value
final_source = qa['tests']['source_snapshot']
for role in ['fmt', 'clippy']:
    assert qa[role]['source_snapshot'] == final_source
source_files = {row['historical_path']: row for row in load(inside(final_source))['files']}
for row in assembly['files']:
    source_row = source_files[row['canonical_path']]
    assert source_row['archive']['sha256'] == row['after']['sha256'] and source_row['size_bytes'] == row['after']['size_bytes']
    checked(source_row['archive'])
quality_source = qa['quality']['source_snapshot']
assert quality_source != final_source
quality_rows = {row['historical_path']: row for row in load(inside(quality_source))['files']}
assert set(quality_rows) == set(source_files)
for path in quality_rows:
    if path != test_path:
        assert quality_rows[path] == source_files[path]
for path, data in old.items():
    assert quality_rows[path]['archive']['sha256'] == hashlib.sha256(data).hexdigest()
quality_script = ROOT / 'scripts/quality/source-quality-gate.ps1'
quality_literal = BASE / 'ordinary-design-day-same-input-sky-publication-prep-02/Source/quality-script.at-5932.ps1'
assert ref(quality_literal)['sha256'] == '7338bd4b9fba9c5ac746649e3bfba625ad0582584b2eb03449b2c4f53dcff227'
assert quality_script.read_bytes() == quality_literal.read_bytes()
add(quality_script)
add(quality_literal)
quality_qualification = 'Actual quality01 Source precedes the one-line test-only module-path correction. Both production files are whole-byte unchanged; the corrected *_tests.rs file is outside the production source-quality scan. This receipt is not relabelled final Source. The separate PowerShell script is raw-byte equal to Git5932; its historical executed bytes were not captured by the Rust-only Source index.'
historical_compile = receipt(packet['historical_clippy01'])
assert historical_compile['command'] == COMMANDS['clippy'] and historical_compile['exit_code'] == 101
assert historical_compile['source_snapshot'] == quality_source
compile_log = inside(historical_compile['stderr']).read_text(encoding='utf8')
assert 'E0433' in compile_log and 'sky' in compile_log

stdout = inside(qa['tests']['stdout']).read_text(encoding='utf8')
stderr = inside(qa['tests']['stderr']).read_text(encoding='utf8')
text = stdout + '\n' + stderr
groups = [tuple(map(int, row)) for row in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)]
pattern = r'DD same-input sky call(\d+) hour(\d+) ts(\d+) (HorizIRSky|SkyTemp): Rust ([0-9a-f]{16}), Native ([0-9a-f]{16})'
differences, seen = [], set()
for call, hour, timestep, field, actual, native in re.findall(pattern, text):
    key = (int(call), int(hour), int(timestep))
    identity = (*key, field)
    assert identity not in seen and key in expected
    seen.add(identity)
    assert native == expected[key][field] and actual != native
    differences.append({'call': key[0], 'hour': key[1], 'timestep': key[2], 'field': field, 'Rust_bits': actual, 'Native_bits': native, 'captured_input_bits': {name: expected[key][name] for name in ['OutDryBulbTemp', 'OutDewPointTemp', 'OutRelHum', 'OpaqueSkyCover']}})
if qa['tests']['exit_code'] == 0:
    assert groups == [(5, 0, 0)] and not differences
    result = 'PASS: all captured same-input IR/Sky outputs match exact bits'
else:
    assert qa['tests']['exit_code'] == 101 and groups == [(4, 1, 0)]
    messages = re.findall(r'DD same-input sky strict bits: (\d+) differences across (\d+) outputs;', text)
    assert messages == [(str(len(differences)), '1152')] and differences
    result = 'FAIL: captured same-input IR/Sky strict residuals retained'

historical_summary_path = ROOT / 'energyplus_porting_plan/evidence/SRC-06-ordinary-design-day-weather/summary.json'
historical_summary = load(historical_summary_path)
add(historical_summary_path)
assert historical_summary['comparison_scope']['strict_diagnostic_difference_fields'] == 9
assert len(historical_summary['comparison_scope']['unpaired_computed_fields']) == 8
historical_strict = receipt(historical_summary['retained_strict_bit_failure'])
assert historical_strict['exit_code'] == 101
plan_path, card_path = ROOT / 'energyplus_porting_plan/plan.json', ROOT / 'energyplus_porting_plan/cards/SRC-06.md'
plan, card = load(plan_path), card_path.read_text(encoding='utf8')
task = next(row for row in plan['tasks'] if row['id'] == 'SRC-06')
key = 'actual_selected_ordinary_design_day_same_input_sky'
assert key not in task and card.count('아래 24개 요약') == 1
assert all(task[field] == '미확인' for field in ['scope_review', 'unit_gate', 'integration_gate', 'production_gate'])

OUT.mkdir()
archive_path = OUT / 'evidence.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(artifacts):
        archive.write(ROOT / name, name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(artifacts)
    for name in archive.namelist():
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == artifacts[name]['sha256'] and len(data) == artifacts[name]['size_bytes']
write(OUT / 'manifest.json', {'schema': 'src06-DD-same-input-sky-evidence.v1', 'artifacts': list(artifacts.values()), 'archive': ref(archive_path), 'archive_member_count': len(artifacts), 'Source_snapshot': final_source, 'gates_updated': False, 'scope': 'Three changed sources, saved bases/proposals/full diffs, direct Original literals, one genuine finite fixture, audit/reviews and actual four-role QA logs/indexes. Historical compile and strict DD failure retained. No recursive archives, full Source payload or Native binaries/maps/raw capture.'})
summary = {'schema': 'src06-DD-same-input-sky-summary.v1', 'status': result, 'Source_snapshot': final_source, 'actual_assembly': ref(assembly_path), 'actual_QA': packet['QA'], 'historical_compile_failure': packet['historical_clippy01'], 'quality_Source_qualification': quality_qualification, 'combined_existing_tests': {'passed': groups[0][0], 'failed': groups[0][1], 'ignored': groups[0][2], 'new_bodies': 0, 'new_binaries': 0}, 'same_input_replay': {'selected_calls': 6, 'slots_per_call': 96, 'retained_slot_observations': 576, 'environment_slot_identities': 192, 'outputs_compared': 1152, 'fields': ['HorizIRSky', 'SkyTemp'], 'input_fields': ['OutDryBulbTemp', 'OutDewPointTemp', 'OutRelHum', 'OpaqueSkyCover'], 'actual_immutable_fixture': held['actual_immutable_fixture'], 'strict_bit_difference_count': len(differences), 'complete_strict_differences': differences, 'new_tolerance_added': False, 'numerical_PASS': qa['tests']['exit_code'] == 0}, 'interpretation': 'The replay substitutes captured true Native slot input bits into the production-consumed private ClarkAllen/sky helper. It localizes this two-output calculation only; Native endpoints are never production inputs. Failure does not establish a libm/provider or Source cause. Success does not pair upstream psychrometric/cache histories or the ordinary producer inputs.', 'whole_DD_scope_unchanged': {'historical_summary': ref(historical_summary_path), 'strict_diagnostic': historical_summary['retained_strict_bit_failure'], 'strict_difference_fields': 9, 'strict_maximum_absolute_difference': 2.2737367544323206e-13, 'computed_fields_still_UNPAIRED_as_whole_DD_outputs': historical_summary['comparison_scope']['unpaired_computed_fields']}, 'limitations': ['Actual rain-free ClarkAllen branch and captured OSky=+0 only; clear-sky solar intermediate operands and positive current solar remain separate pending observations.', 'Full Setup/HB/HVAC and all four gates remain unverified; A14/54 and B14/64 unchanged.', 'No new Native run, A/CLI/CI repeat, test body/binary or numerical tolerance.'], 'manifest': ref(OUT / 'manifest.json'), 'archive': ref(archive_path), 'gates_updated': False}
write(OUT / 'summary.json', summary)
task[key] = ref(OUT / 'summary.json')
write(plan_path, plan)
needle = '\n기존 Weather03·absent site/station'
section = '\n## 이력과 증거 보존'
assert card.count(needle) == card.count(section) == 1
short = '1,152 strict bits 일치' if not differences else f'1,152 출력 중 {len(differences)} strict 차이 보존'
card = card.replace('아래 24개 요약', '아래 25개 요약').replace(needle, '| DD 같은 입력 sky 계산 | [요약](../evidence/SRC-06-ordinary-design-day-same-input-sky/summary.json) · [색인](../evidence/SRC-06-ordinary-design-day-same-input-sky/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-design-day-same-input-sky/evidence.zip) | 실제 여섯 호출·576 slot의 캡처된 DB/DP/RH/opaque-cover 입력으로 IR/Sky 두 출력 ' + short + '. whole-DD 9 strict 차이·8 UNPAIRED와 모든 gate는 그대로. |\n' + needle)
card = card.replace(section, '\n## DD 같은 입력 sky 계산 단위의 QA\n\n실제 Source `' + final_source['sha256'] + '`에서 기존 sky4+lifecycle1 결과는 **' + str(groups[0][0]) + ' passed / ' + str(groups[0][1]) + ' failed / ' + str(groups[0][2]) + ' ignored**다. ' + short + '이며 실패의 원인을 추정하거나 whole-DD 수치 PASS로 확대하지 않는다. fmt와 영향받는 ep_runtime all-target Clippy는 실제 최종 Source에 고정하고, quality01은 production 두 파일 전체 동일·test-only 한 줄 수정의 명시적 범위로 재사용했다. 앞선 Clippy01 E0433=101과 역사적 whole-DD strict 실패는 별도 보존한다. 새 Native·A/CLI/CI 실행이나 새 tolerance는 없다.\n' + section)
card_path.write_bytes(card.encode('utf8'))
print(json.dumps({'summary': ref(OUT / 'summary.json'), 'manifest': ref(OUT / 'manifest.json'), 'archive': ref(archive_path), 'members': len(artifacts), 'result': result, 'strict_differences': len(differences)}, ensure_ascii=False))

# HELD same-input DesignDay sky replay

This packet is unexecuted Source. It changes three existing files and adds no test body, binary, fixture, tolerance, or expected production values.

The actual selected DD producer's emissivity -> IR write -> Sky write is extracted into one consumed weather-day-private helper. The constants resolve to exactly the previous 273.15 and 5.6697e-8; both multiplication grouping and sqrt(sqrt) remain literal. No formula correction or provider cause has been established. The original weather-file sentinel path is untouched.

The existing lifecycle test's existing Native comparison helper replays all six actual complete96-slot carriers (576 observations/1152 output comparisons). Each scratch slot receives only actual Native DB/DP/RH input bits; actual opaque cover0 is checked against real captured ClarkAllen and rain=false owners and passed separately. Only the actual helper writes IR/Sky. All strict output-bit differences are printed and then fail the same existing test. No epsilon/fallback/gate change exists. A failure is expected to remain visible if identical-input math still differs; this packet does not predict its result.

The immutable whole-weather strict diagnostic remains FAIL; the previous scoped comparisons and five inherited PSY bounds remain byte-preserved apart from this additional strict same-input requirement. A passing isolated replay would certify only these captured DB/DP/opaque -> IR/Sky pairs, not upstream DP/RH, ESky as an independently observed intermediate, full DD numerics, libm/provider cause, Setup, HVAC, or gates.

Clear-sky A/B/C/AVSC/SUNCOS.z are absent from the old fixture and remain a separate pending passive-observation prerequisite. All selected Current calls are nighttime, so positive ground-solar math is not paired by this packet. No Native endpoint is generated or altered.

Application and any future target execution belong to Root after independent Source review and the current World QA closure. The exact selected before files are pinned independently of the changing global worktree. Full raw before/proposed/diffs and substitution inverses accompany the packet.

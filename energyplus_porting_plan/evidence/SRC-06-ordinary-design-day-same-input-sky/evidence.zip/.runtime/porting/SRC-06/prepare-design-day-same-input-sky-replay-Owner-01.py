"""Author a held consumed DD sky helper/replay; never edits canonical files."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-design-day-same-input-sky-prep-01'
AUDIT = ROOT / '.runtime/porting/SRC-06/Owner-ordinary-design-day-numerical-audit-01/audit.json'


def ref(path):
    p = ROOT / path
    data = p.read_bytes()
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return ref(path)


def replace_once(text, before, after):
    assert text.count(before) == 1, before[:120]
    return text.replace(before, after, 1)


assert not OUT.exists(), 'fresh output only'
OUT.mkdir(parents=True)
audit = json.loads(AUDIT.read_text(encoding='utf-8'))
assert ref(AUDIT)['sha256'] == 'd72f0ef13c23284c380d00d3d495f034c8674aba84e2a2405d28a55263f420a8'
files = []
paths = [
    'crates/ep_runtime/src/weather_day/sky.rs',
    'crates/ep_runtime/src/weather_day/design_day/producer.rs',
    'crates/ep_runtime/src/weather_day/design_day_native_tests.rs',
]
changes = {}
before_sky = (ROOT / paths[0]).read_text(encoding='utf-8')
sky_helper = '''/// Writes the actual selected DesignDay sky fields in Source assignment order.
/// The caller supplies the real slot and SetUpDesignDay's opaque-cover local.
pub(super) fn initialize_design_day_sky(slot: &mut super::WeatherVars, opaque_sky_cover: f64) {
    let emissivity = default_clark_allen_sky_emissivity(
        opaque_sky_cover,
        slot.out_dry_bulb_temp,
        slot.out_dew_point_temp,
        slot.out_rel_hum * 0.01,
    );
    let kelvin = slot.out_dry_bulb_temp + KELVIN;
    let squared = kelvin * kelvin;
    slot.horiz_ir_sky = emissivity * STEFAN_BOLTZMANN * (squared * squared);
    slot.sky_temp = kelvin * emissivity.sqrt().sqrt() - KELVIN;
}

'''
changes[paths[0]] = replace_once(before_sky, '#[cfg(test)]\nmod tests {', sky_helper + '#[cfg(test)]\nmod tests {')
before_producer = (ROOT / paths[1]).read_text(encoding='utf-8')
old = '''                let emissivity = super::super::sky::default_clark_allen_sky_emissivity(
                    opaque_sky,
                    slot.out_dry_bulb_temp,
                    slot.out_dew_point_temp,
                    slot.out_rel_hum * 0.01,
                );
                let kelvin = slot.out_dry_bulb_temp + 273.15;
                let squared = kelvin * kelvin;
                slot.horiz_ir_sky = emissivity * 5.6697e-8 * (squared * squared);
                slot.sky_temp = kelvin * emissivity.sqrt().sqrt() - 273.15;
'''
changes[paths[1]] = replace_once(before_producer, old, '                super::super::sky::initialize_design_day_sky(slot, opaque_sky);\n')
before_test = (ROOT / paths[2]).read_text(encoding='utf-8')
new = replace_once(before_test, '    let mut initialized_years = [0; 2];\n', '''    let mut initialized_years = [0; 2];
    let mut same_input_sky_slots = 0;
    let mut same_input_sky_differences = Vec::new();
''')
block = '''            // Isolate the actual DD sky producer from upstream PSY differences.
            // These are complete captured Native slot operands, never expected
            // values seeded into production. All six actual repeated carriers
            // remain separate; neither the fixture nor Native output is changed.
            let native_weather = &native["weather"];
            assert_eq!(
                native_weather["Environment"]["rows"][environment - 1]["value"]["skyTempModel"],
                0,
                "actual ClarkAllen owner"
            );
            assert_eq!(
                native_weather["DesDayInput"]["rows"][environment - 1]["value"]["RainInd"],
                0,
                "actual OSky=0 Source branch"
            );
            for row in native_weather["wvarsHrTsToday"]["rows"]
                .as_array()
                .ok_or("actual DD sky operand rows")?
            {
                let value = &row["value"];
                let captured = |field: &str| -> Result<f64, Box<dyn std::error::Error>> {
                    Ok(f64::from_bits(u64::from_str_radix(
                        value[field]["value_bits"]
                            .as_str()
                            .ok_or("actual DD sky operand bits")?,
                        16,
                    )?))
                };
                let mut slot = super::WeatherVars {
                    out_dry_bulb_temp: captured("OutDryBulbTemp")?,
                    out_dew_point_temp: captured("OutDewPointTemp")?,
                    out_rel_hum: captured("OutRelHum")?,
                    ..Default::default()
                };
                let opaque_sky_cover = captured("OpaqueSkyCover")?;
                assert_eq!(opaque_sky_cover.to_bits(), 0.0_f64.to_bits());
                super::sky::initialize_design_day_sky(&mut slot, opaque_sky_cover);
                same_input_sky_slots += 1;
                for (field, actual) in [
                    ("HorizIRSky", slot.horiz_ir_sky),
                    ("SkyTemp", slot.sky_temp),
                ] {
                    let expected = captured(field)?;
                    assert!(actual.is_finite() && expected.is_finite());
                    if actual.to_bits() != expected.to_bits() {
                        same_input_sky_differences.push((
                            ordinal,
                            row["hour"].as_u64().ok_or("actual sky hour")?,
                            row["timestep"].as_u64().ok_or("actual sky timestep")?,
                            field,
                            actual.to_bits(),
                            expected.to_bits(),
                        ));
                    }
                }
            }
'''
new = replace_once(new, '            state::site_and_solar(&snapshot.state, native, -7.0)?;\n', '            state::site_and_solar(&snapshot.state, native, -7.0)?;\n' + block)
tail = '''    assert_eq!(same_input_sky_slots, 6 * 96);
    for (call, hour, timestep, field, actual, expected) in &same_input_sky_differences {
        eprintln!(
            "DD same-input sky call{call} hour{hour} ts{timestep} {field}: Rust {actual:016x}, Native {expected:016x}"
        );
    }
    assert!(
        same_input_sky_differences.is_empty(),
        "DD same-input sky strict bits: {} differences across {} outputs; no numerical PASS or cause attribution on failure",
        same_input_sky_differences.len(),
        same_input_sky_slots * 2
    );
'''
new = replace_once(new, '    // The immutable strict-bit diagnostic remains FAIL.', tail + '    // The immutable strict-bit diagnostic remains FAIL.')
changes[paths[2]] = new

for index, path in enumerate(paths):
    before = (ROOT / path).read_bytes()
    proposal = changes[path].encode('utf-8')
    source = before.decode('utf-8').replace('\r\n', '\n')
    # Whole proposed source inverses are checked by undoing each exact authored
    # substitution in reverse below, on the explicit LF text basis.
    before_ref = put(OUT / 'before' / path, before)
    proposal_ref = put(OUT / 'proposed' / path, proposal)
    diff = ''.join(difflib.unified_diff(source.splitlines(keepends=True), changes[path].splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path))
    diff_ref = put(OUT / 'diffs' / f'{index:02}.complete.diff', diff.encode('utf-8'))
    assert (ROOT / path).read_bytes() == before
    assert source.count('#[test]') == changes[path].count('#[test]')
    files.append({'canonical_path': path, 'before': before_ref, 'proposal': proposal_ref, 'complete_diff': diff_ref, 'diff_basis': 'LF-normalized UTF-8 source; raw before bytes separately pinned'})

assert changes[paths[0]].replace(sky_helper, '', 1) == before_sky
assert changes[paths[1]].replace('                super::super::sky::initialize_design_day_sky(slot, opaque_sky);\n', old, 1) == before_producer
inverse = changes[paths[2]].replace(tail, '', 1).replace(block, '', 1).replace('    let mut same_input_sky_slots = 0;\n    let mut same_input_sky_differences = Vec::new();\n', '', 1)
assert inverse == before_test
assert before_test.count('#[test]') == changes[paths[2]].count('#[test]') == 0

readme = '''# HELD same-input DesignDay sky replay

This packet is unexecuted Source. It changes three existing files and adds no test body, binary, fixture, tolerance, or expected production values.

The actual selected DD producer's emissivity -> IR write -> Sky write is extracted into one consumed weather-day-private helper. The constants resolve to exactly the previous 273.15 and 5.6697e-8; both multiplication grouping and sqrt(sqrt) remain literal. No formula correction or provider cause has been established. The original weather-file sentinel path is untouched.

The existing lifecycle test's existing Native comparison helper replays all six actual complete96-slot carriers (576 observations/1152 output comparisons). Each scratch slot receives only actual Native DB/DP/RH input bits; actual opaque cover0 is checked against real captured ClarkAllen and rain=false owners and passed separately. Only the actual helper writes IR/Sky. All strict output-bit differences are printed and then fail the same existing test. No epsilon/fallback/gate change exists. A failure is expected to remain visible if identical-input math still differs; this packet does not predict its result.

The immutable whole-weather strict diagnostic remains FAIL; the previous scoped comparisons and five inherited PSY bounds remain byte-preserved apart from this additional strict same-input requirement. A passing isolated replay would certify only these captured DB/DP/opaque -> IR/Sky pairs, not upstream DP/RH, ESky as an independently observed intermediate, full DD numerics, libm/provider cause, Setup, HVAC, or gates.

Clear-sky A/B/C/AVSC/SUNCOS.z are absent from the old fixture and remain a separate pending passive-observation prerequisite. All selected Current calls are nighttime, so positive ground-solar math is not paired by this packet. No Native endpoint is generated or altered.

Application and any future target execution belong to Root after independent Source review and the current World QA closure. The exact selected before files are pinned independently of the changing global worktree. Full raw before/proposed/diffs and substitution inverses accompany the packet.
'''
readme_ref = put(OUT / 'README.md', readme.encode('utf-8'))
manifest = {
    'schema': 'src06-design-day-same-input-sky-Source-prep.v1',
    'status': 'HELD Source only; unexecuted strict numerical result unknown',
    'author': ref(Path(__file__)), 'README': readme_ref,
    'current_git_head_at_preparation': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, check=True, text=True, capture_output=True).stdout.strip(),
    'global_worktree_or_current_Source_equality_claimed': False,
    'files': files, 'audit': ref(AUDIT), 'actual_immutable_fixture': audit['fixture'],
    'direct_Original_ranges': [item for item in audit['Original_ranges'] if (item['original_path'], item['first_line']) in {('src/EnergyPlus/WeatherManager.cc', 3200), ('src/EnergyPlus/WeatherManager.cc', 3795), ('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh', 1080), ('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh', 1141)}],
    'inverse_checks': 'All three whole LF-normalized sources restored by exact inverse; raw canonical before bytes preserved unchanged',
    'actual_test_bodies_added': 0, 'actual_test_binaries_added': 0,
    'Source_planned_replay_slots': 576, 'Source_planned_replay_outputs': 1152,
    'numerical_result': 'not executed; no PASS predicted', 'tolerance_added': False,
    'Native_run_or_expected_endpoint_generation': False, 'canonical_writes': False,
}
manifest_ref = put(OUT / 'manifest.json', (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(manifest_ref))

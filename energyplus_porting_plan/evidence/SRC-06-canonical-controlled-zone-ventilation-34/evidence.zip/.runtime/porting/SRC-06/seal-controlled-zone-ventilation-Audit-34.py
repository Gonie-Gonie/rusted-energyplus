from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048';HEAD='49a5a4482e9ad83aee31407fc60c6c2dd683cafb'
O=D/'source-controlled-zone-ventilation-held-Audit-34'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'],x
 assert v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes'])),x;return p
def load(name,sha):
 p=R/name;assert ref(p)['sha256']==sha;return p,json.loads(p.read_bytes())
def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True).stdout
def save(name,b):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def contains(x,row):
 return isinstance(x,dict) and ((x.get('path'),x.get('sha256'))==(row['path'],row['sha256']) or any(contains(v,row) for v in x.values())) or isinstance(x,list) and any(contains(v,row) for v in x)
a=argparse.ArgumentParser();a.add_argument('--peer-path',required=True);a.add_argument('--peer-sha',required=True);args=a.parse_args()
assert git(R,'rev-parse','HEAD').decode().strip()==git(R,'rev-parse','origin/main').decode().strip()==HEAD
assert not git(R,'status','--porcelain=v1').strip() and not O.exists()
dp,draft=load('.runtime/porting/SRC-06/source-controlled-zone-ventilation-draft-Audit-34/draft.json','ea5491ddaf776a783f0708984364e6b674d9a40144c0ebefaf7ccde6a7d33266')
pp,peer=load(args.peer_path,args.peer_sha);assert peer['accepted'] and not peer['findings'] and contains(peer,ref(dp))
ap,actual=load('.runtime/porting/SRC-06/Root-source-component-node-report-actual-review-33/review.json','c9b9aabda8147ebe2c9b8498600863e17855e1e40d01813c9b7ceb684b6ef39d')
assert actual['accepted'] and not actual['findings'] and actual['same4503_archived_inputs_exact_final_plan']
assert actual['B_frontier']=='GetHeatBalanceInput: actual controlled ZoneVentRepVars/ZoneEquipConfig.ZoneName1993\u20131994 before zone declarations'
prior_path=auth(actual['complete_compiler_plan']);prior=json.loads(prior_path.read_bytes());assert ref(prior_path)['sha256']=='7f41b4ee1c9f6af67263d8e44c80d59bcfd4c9fa5e59e4662af240138e272747'
entries={x['path']:copy.deepcopy(x) for x in prior['entries']};assert len(entries)==4503
bp=auth(actual['actual_B']);b=json.loads(bp.read_bytes());a24=json.loads(auth(actual['actual_A24']).read_bytes())
assert b['exit_code']==6 and a24['exit_code']==0 and b['source_snapshot']==a24['source_snapshot']
assert all(x['source_bytes_match_before_and_after'] and x['launch_error'] is None for x in (b,a24))
sp=auth(b['source_snapshot']);snapshot=json.loads(sp.read_bytes());archives={x['historical_path']:x for x in snapshot['files']};assert set(entries)==set(archives)
readback=[];raws={}
for name,row in entries.items():
 raw=auth(archives[name]['archive']).read_bytes();assert raw==auth(row['source']).read_bytes()==(R/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['final_sha256'] and len(raw)==row['final_bytes']
 readback.append({'path':name,'actual_archive':archives[name]['archive'],'sha256':row['final_sha256'],'bytes':len(raw),'archive_live_plan_exact':True});raws[name]=raw
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];logical={}
for i,row in enumerate(draft['files'],1):
 name=row['canonical_path'];before=auth(row['before']).read_bytes();proposed=auth(row['proposed']).read_bytes()
 assert before==raws[name]==git(R,'show',HEAD+':'+name)
 assert ns['apply_literal'](before,auth(row['forward_diff']).read_bytes())==proposed
 assert ns['apply_literal'](proposed,auth(row['inverse_diff']).read_bytes())==before
 parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,capture_output=True,cwd=R);assert parsed.returncode==0,parsed.stderr
 whole=save('proposed/'+name,proposed)
 files.append({'canonical_path':name,'before_absent':False,'before':save('before/'+name,before),'actual_parent_archive':archives[name]['archive'],
  'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}-forward.diff',auth(row['forward_diff']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',auth(row['inverse_diff']).read_bytes()),
  'literal_origin_whole':row['proposed'],'before_whole_Git_exact_at_base':True,'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',parsed.stdout),'stderr':save(f'parse/{i:02}.stderr',parsed.stderr)}})
 entries[name]={'path':name,'final_sha256':whole['sha256'],'final_bytes':whole['bytes'],'source':whole,'origin':'whole accepted immutable Source34 ventilation draft; no semantic rewrite'};logical[name]=proposed
assert len(files)==5 and len(entries)==4503 and sum(x.endswith('.rs') for x in entries)==4490
needles=['SourceSystemReportsOutputField','SourceZoneVentReportOutputField','Field::Zone {','register_source_zone_ventilation_output','source_zone_equipment_config','fn zone_name(','SourceOutputUnits::M3','SourceOutputUnits::Ach','Target::SystemReports','T::SystemReports','SourceRealOutputTarget::SystemReports']
api=[]
for name,row in sorted(entries.items()):
 if not name.endswith('.rs'):continue
 raw=logical.get(name,raws[name]);text=raw.decode('utf8');hits=[{'line':i,'terms':[n for n in needles if n in line]} for i,line in enumerate(text.splitlines(),1) if any(n in line for n in needles)]
 if hits:api.append({'path':name,'ordered_hits':hits,'final_sha256':row['final_sha256']})
# This existing top-level target is already routed by every relevant live view;
# no unrelated target discriminator/owner or cache copy is introduced.
for name in ['crates/ep_runtime/src/heat_balance/source_output_registration/air_target.rs','crates/ep_runtime/src/heat_balance/source_output_registration/facility_target.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/remaining.rs']:
 assert b'self.system_reports.real_output(target)' in raws[name]
preserved=[]
for name in ['crates/ep_runtime/Cargo.toml','crates/ep_runtime/src/lib.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/native_cohort.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/fixtures/native_prediction_b.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/surface.rs']:
 assert entries[name]==next(x for x in prior['entries'] if x['path']==name);preserved.append({'path':name,'whole':entries[name]['source']})
equipment='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';token=b'    pub(crate) fn restore_native_cohort_node('
assert raws[equipment].count(token)==logical[equipment].count(token)==1
assert raws[equipment][raws[equipment].index(token):]==logical[equipment][logical[equipment].index(token):]
native=[]
for x in draft['Native_authorities']:
 name=x['Native_path'];raw=auth(x['whole']).read_bytes();assert raw==git(N,'show',PIN+':'+name)==(N/name).read_bytes();lines=raw.splitlines(keepends=True);extents=[]
 for e in x['extents']:
  assert b''.join(lines[e['first']-1:e['last']])==auth(e['source']).read_bytes();extents.append(e)
 extra={'src/EnergyPlus/DataZoneEquipment.hh':[(305,382)]}.get(name,[])
 for first,last in extra:extents.append({'first':first,'last':last,'source':save('Native-extents/'+Path(name).name+f'.{first}-{last}.txt',b''.join(lines[first-1:last]))})
 native.append({'Native_path':name,'whole':x['whole'],'extents':extents,'pinned_Git_exact':True})
name='src/EnergyPlus/DataZoneEquipment.cc';raw=(N/name).read_bytes();assert raw==git(N,'show',PIN+':'+name);lines=raw.splitlines(keepends=True)
native.append({'Native_path':name,'whole':save('Native-whole/'+Path(name).name,raw),'extents':[{'first':820,'last':842,'source':save('Native-extents/'+Path(name).name+'.820-842.txt',b''.join(lines[819:842]))}],'pinned_Git_exact':True})
contexts=[]
for c in draft['concrete_same_owner_contexts']:
 name=c['canonical_path'];assert auth(c['whole']).read_bytes()==raws[name]
 contexts.append({'canonical_path':name,'whole':{**archives[name]['archive'],'bytes':len(raws[name])},'actual33_archive_and_live_exact':True})
for name in ['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_controlled_equipment.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_equipment_types.rs']:
 contexts.append({'canonical_path':name,'whole':{**archives[name]['archive'],'bytes':len(raws[name])},'actual33_archive_and_live_exact':True})
contract=json.loads(auth(draft['integration_contract']).read_bytes());assert len(contract['order'])==20
plan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-Source34-compiler-input-plan.v1','base_HEAD':HEAD,'actual33_parent_review':ref(ap),'actual33_parent_snapshot':ref(sp),'prior_plan':ref(prior_path),'inputs':4503,'Rust_sources':4490,'selected_existing':5,'entries':[entries[x] for x in sorted(entries)]})
manifest={'schema':'src06-held-controlled-zone-ventilation.v1','status':'HELD Source34 on clean committed actual33; no Source34 execution or completion claim','base_HEAD':HEAD,
 'accepted33_actual_review':ref(ap),'parent_producer':actual['producer'],'actual_parent_receipts':{'B':actual['actual_B'],'A24':actual['actual_A24']},'actual_parent_snapshot':ref(sp),'prior_complete_compiler_Source_plan':ref(prior_path),'complete_final_compiler_Source_plan':plan,
 'compiler_inputs':4503,'Rust_sources':4490,'original_draft':ref(dp),'independent_full_semantic_peer':ref(pp),'files':files,'existing_Source_files':5,'new_Source_files':0,'selected_Source_files':5,'literal_applications':10,'Source_only_parses':5,'all5_proposals_whole_unchanged_from_reviewed_draft':True,
 'full4503_parent_readback':dump('actual33-parent-full-readback.json',readback),'whole4490_Rust_API_census':dump('API-census.json',{'Rust_sources_examined':4490,'all_crates_runtime_tests_included':True,'needles':needles,'hits':api}),
 'Native_commit':PIN,'Native_authorities':native,'concrete_same_owner_contexts':contexts,'integration_contract':draft['integration_contract'],
 'existing_ZoneVent_ctor20_and_allocation_unchanged':True,'preserved_safe_cohort_Sources':preserved,'equipment_test_only_loader_suffix_unchanged':True,
 'scope':'Genuine controlled ZoneVentRepVars20 live indexed field bindings and Config.ZoneName/IsControlled; native first8 real VentLoadsReportEnabled guard then12 unconditional declarations, followed by unchanged facility4. True m3/ach units. Same sole retained report/registration/IP/backends; no DTO/current scalar cache or scientific calculations.',
 'remaining_scope':'Positive primary constructors and all existing positive CreateEnergyReportStructure2502/2663 and reporting children remain typed boundaries. No Source34 frontier, finite15/all12/internal numerical equivalence or fullB completion claim.',
 'validation_policy':'Root alone runs actual B then A24. No new tests or numerical formula changes, no redundant existing cohort/alltargets/annual reruns. Earlier successful safe-main1168+1168 remains unchanged historical evidence.',
 'new_test_bodies':0,'actual_test_bodies_executed':0,'Cargo_main_tests_or_Native_mutations':False,'author_Source':ref(Path(__file__))}
p=O/'manifest.json';p.write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'manifest':ref(p),'plan':plan}))

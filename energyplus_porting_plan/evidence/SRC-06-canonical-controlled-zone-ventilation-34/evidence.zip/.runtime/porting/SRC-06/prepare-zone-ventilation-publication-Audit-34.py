from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'publish-component-node-report-checkpoint-Outer-33-02.py';NEW=D/'publish-controlled-zone-ventilation-checkpoint-Audit-34.py'
O=D/'controlled-zone-ventilation-publication-prepared-Audit-34'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
assert not NEW.exists() and not O.exists();before=OLD.read_text(encoding='utf8');s=before
s=s.replace('Root-only engine33','Root-only engine34').replace('final nine-file','final five-file')
s=s.replace('component-node-report','controlled-zone-ventilation').replace('Outer-33','Audit-34').replace('ACTUAL33','ACTUAL34')
s=s.replace('controlled-zone-ventilation-33','controlled-zone-ventilation-34')
s=s.replace("producer['existing_Source_files']==9","producer['existing_Source_files']==5").replace('selected9_final_sources_exact','selected5_final_sources_exact')
s=s.replace(" for r in t['split_review_authorities'].values():accepted(r)"," accepted(t['independent_peer'])")
s=s.replace("t['accepted_cohort_parent_review']","t['accepted_parent_review']").replace("t['accepted_cohort_parent_plan']","t['accepted_parent_plan']")
s=s.replace("t['split_review_authorities']['Root_independent_combined_join']","t['independent_peer']")
s=s.replace("t['accepted31_actual_review']","t['accepted_parent_review']")
s=s.replace('equal31','equal33').replace('accepted31_full5352_proof','accepted33_full5352_proof')
s=s.replace('accepted31_proof','accepted33_proof').replace('Accepted31 A24 proof transfer','Accepted33 A24 proof transfer')
s=s.replace('Root-33/output','Root-34/output').replace('src06-canonical33-finite','src06-canonical34-finite')
s=s.replace('Nine existing production Sources','Five existing production Sources').replace('Parent cohort is separately attributed, not rerun by33.','The parent33 A24 proof is separately attributed; no cohort or new Native rerun by34.')
s=s.replace("status='Genuine Source component/Node report integration; actual B result recorded'","status='Genuine Source controlled-zone ventilation live output registration; actual B result recorded'")
s=s.replace("split_review_authorities=t['split_review_authorities']","independent_peer=t['independent_peer']")
s=s.replace("accepted_cohort_parent_review=t['accepted_parent_review'],accepted_cohort_parent_plan=t['accepted_parent_plan']","accepted_parent_review=t['accepted_parent_review'],accepted_parent_plan=t['accepted_parent_plan']")
s=s.replace(",B_Node_lifecycle_observation=actual['B_Node_lifecycle_observation']",'')
s=s.replace('[Source33 component/Node report]','[Source34 controlled-zone ventilation]')
s=s.replace('canonical_component_node_report_33','canonical_controlled_zone_ventilation_34').replace('actual_test_bodies_executed_by33','actual_test_bodies_executed_by34')
# Use a literal clone; all algorithm/publisher changes stay reviewable together.
assert "split_review_authorities" not in s and 'selected9' not in s and 'equal31' not in s
assert s.count("'HELD_READY_FOR_ROOT_ACTUAL34_AND_FULL_READ'")==1
ast.parse(s);NEW.write_bytes(s.encode());O.mkdir()
(O/'publisher-forward.diff').write_bytes(''.join(difflib.unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='accepted33-publisher02',tofile='Source34-publisher')).encode())
(O/'publisher-inverse.diff').write_bytes(''.join(difflib.unified_diff(s.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='Source34-publisher',tofile='accepted33-publisher02')).encode())
mp=D/'source-controlled-zone-ventilation-held-Audit-34/manifest.json';m=json.loads(mp.read_bytes());assert ref(mp)['sha256']=='95c7fad71826d0e3f6bef1cf86efd2a29a10aa5d973de99ebe3ac5db105e4085'
finite={}
def add(row):p=auth(row);finite[ref(p)['path']]=ref(p)
for row in [ref(mp),m['complete_final_compiler_Source_plan'],m['independent_full_semantic_peer'],m['original_draft'],m['author_Source'],
 m['accepted33_actual_review'],m['full4503_parent_readback'],m['whole4490_Rust_API_census'],m['integration_contract'],
 ref(Path(__file__)),ref(OLD),ref(O/'publisher-forward.diff'),ref(O/'publisher-inverse.diff')]:add(row)
for row in m['files']:
 for k in ('before','proposed','literal_inverse','forward_diff','inverse_diff'):add(row[k])
 for k in ('stdout','stderr'):add(row['Source_only_parse'][k])
for row in m['Native_authorities']:
 add(row['whole'])
 for e in row['extents']:add(e['source'])
for row in m['concrete_same_owner_contexts']:add(row['whole'])
prior=json.loads((R/'energyplus_porting_plan/plan.json').read_bytes());task=next(x for x in prior['tasks'] if x['id']=='SRC-06');previous=task['canonical_component_node_report_33'];add(previous)
t={'schema':'src06-controlled-zone-ventilation-publication-template.v1','status':'WAITING_FOR_ROOT_ACTUAL34_AND_FULL_READ',
 'base_HEAD':m['base_HEAD'],'publisher_Source':ref(NEW),'producer':ref(mp),'complete_plan':m['complete_final_compiler_Source_plan'],
 'independent_peer':m['independent_full_semantic_peer'],'accepted_parent_review':m['accepted33_actual_review'],'accepted_parent_plan':m['prior_complete_compiler_Source_plan'],
 'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-controlled-zone-ventilation-actual-review-34/review.json','previous_engine_checkpoint':previous,
 'finite_archive_inputs':list(finite.values()),
 'summary_template':{'A':'14/54','B':'14/64','gate_changes':False,'policy_changes':False,'selected_existing_production_Sources':5,'new_Source_files':0,
  'controlled_zone_output_declarations':20,'first8_conditional_on_real_VentLoadsReportEnabled':True,'remaining12_unconditional_per_controlled_zone':True,'following_facility_declarations_unchanged':4,
  'source_report_ctor20_unchanged':True,'real_Config_key_borrow_and_indexed_live_Which':True,'new_test_bodies':0,'actual_test_bodies_executed':0,
  'scope':'Controlled-zone ventilation registration uses the same retained ZoneVentRepVars owner and actual Config.ZoneName, native20 declarations in order, true m3/ach units; no scientific formulas or scalar output cache. Actual B frontier remains recorded, not inferred.',
  'qualification':'A24 original5352 proof is transferred through accepted33 current-run whole-file checks; safe-main predictor/corrector cohort remains inherited and unchanged, not rerun. No finite15/all12/card/fullB/internal-unit completion claim.'},
 'doc_appends':{
 'cards/SRC-06.md':'제어 구역의 실제 환기 보고 상태에 출력 20개를 Native 순서로 연결했다. 구역명과 보고값은 기존 소유자에서 직접 참조하며 앞 8개는 실제 VentLoadsReportEnabled를 따른다. B 실행 결과: `{{actual_B_result}}`. A24 회귀는 기존 5,352개 보고값 증거를 이어받고, 계산식 변경이나 테스트 추가는 없다.',
 'CHECKLIST.md':'제어 구역 환기 출력 등록 20개와 m3·ach 단위를 연결했다. B의 실제 다음 경계와 A24 증거는 연결된 요약에 기록한다. 게이트 수는 그대로다.',
 'STATE_CONTRACTS.md':'ZoneVentRepVars의 기존 20개 기본값과 할당을 유지한다. Config.ZoneName을 빌리고 같은 SystemReports 소유자의 구역 인덱스·필드로 매번 출력값을 해석한다. 보고값 복사본이나 새 계산 상태는 만들지 않는다.'}}
for text in t['doc_appends'].values():assert '\ufffd' not in text and '?' not in text
q=O/'publication-template.json';q.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'publisher':ref(NEW),'template':ref(q)}))

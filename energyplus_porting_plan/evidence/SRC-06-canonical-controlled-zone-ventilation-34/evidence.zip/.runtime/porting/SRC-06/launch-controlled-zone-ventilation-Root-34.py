from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={'B': ('canonical-source-component-node-report-B-NOLIMIT-24H-command-Root-33/receipt.json', 'b28ecbcca58a1c9ae9c5d305b1aa605241c03614f7e6bf507bb2a90e997aa5ed'), 'A24': ('canonical-source-component-node-report-A-24H-command-Root-33/receipt.json', 'd57cf5dda9b2b352726859b61c22aed7c6a19b0b0a6d79dc70917732ad159994')}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-controlled-zone-ventilation-'+case+'-command-Root-34'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-controlled-zone-ventilation-'+case+'-Root-34/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

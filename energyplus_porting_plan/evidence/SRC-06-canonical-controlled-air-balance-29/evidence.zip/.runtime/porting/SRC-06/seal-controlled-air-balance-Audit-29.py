from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048';HEAD='cb7149e19724bf1abc23d44be9ffce5838df36c3'
O=D/'source-controlled-air-balance-held-Audit-29'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
    p=R/x['path'];assert ref(p)['sha256']==x['sha256'],x
    if 'bytes' in x:assert ref(p)['bytes']==x['bytes'],x
    return p
def load(path,sha):
    p=R/path;assert ref(p)['sha256']==sha;return p,json.loads(p.read_bytes())
def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],check=True,capture_output=True).stdout
def save(name,b):
    p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def contains(x,target):
    return (isinstance(x,dict) and (x==target or any(contains(y,target) for y in x.values()))) or (isinstance(x,list) and any(contains(y,target) for y in x))
a=argparse.ArgumentParser();a.add_argument('--peer-path',required=True);a.add_argument('--peer-sha',required=True);args=a.parse_args()
assert git(R,'rev-parse','HEAD').decode().strip()==git(R,'rev-parse','origin/main').decode().strip()==HEAD
assert not git(R,'status','--porcelain=v1').strip() and not O.exists()
draft_path,draft=load('.runtime/porting/SRC-06/source-controlled-air-balance-draft-Audit-29-02/draft.json','f3cb01aae008d3edffe07a291039e0268a96a36643b1303879fb7a5c9a61a464')
peer_path,peer=load(args.peer_path,args.peer_sha);assert peer['accepted'] and not peer['findings'] and contains(peer,ref(draft_path))
mass_path,mass_peer=load('.runtime/porting/SRC-06/Peer-controlled-mass-return-Source-review-29-02/review.json','2bfd6c1c97dbcb71b06d271f5a0dce39f152f2fe118a673d744258db8ef2d616')
assert mass_peer['accepted'] and not mass_peer['findings'] and contains(mass_peer,ref(draft_path))
parent_path,parent=load('.runtime/porting/SRC-06/source-zone-equipment-output-held-Peer-28-02/manifest.json','c9ada9aed00f572069fd7d8848019bf3122ee588f189afabcfec6555624133ca')
actual_path,actual=load('.runtime/porting/SRC-06/Root-source-zone-equipment-output-actual-review-28/review.json','1241f905980f76fbf4fcfbd0dc6ab6a97d8990871d2508af7482e52c1fb9fabe')
assert actual['accepted'] and not actual['findings'] and actual['producer']==ref(parent_path)
assert actual['B_frontier']=='GetHeatBalanceInput: actual controlled MassConservation5022'
prior_plan_path=auth(actual['complete_compiler_plan']);prior_plan=json.loads(prior_plan_path.read_bytes())
assert ref(prior_plan_path)['sha256']=='5123652eedb9452475c5c91eea7ac01a3a839cf4d9e5279eba0005b0cb834156'
assert prior_plan['inputs']==4502 and prior_plan['Rust_sources']==4489
receipts={}
for label,key,code in [('B-NOLIMIT-24H','actual_B',6),('A-24H','actual_A24',0)]:
    p=auth(actual[key]);receipt=json.loads(p.read_bytes());assert receipt['exit_code']==code and receipt['source_bytes_match_before_and_after']
    receipts[label]={'receipt':ref(p),'exit_code':code,'snapshot':receipt['source_snapshot']}
assert receipts['B-NOLIMIT-24H']['snapshot']==receipts['A-24H']['snapshot']
snapshot_path=auth(receipts['B-NOLIMIT-24H']['snapshot']);snapshot=json.loads(snapshot_path.read_bytes())
archives={x['historical_path']:x['archive'] for x in snapshot['files']};entries={x['path']:copy.deepcopy(x) for x in prior_plan['entries']}
assert len(entries)==4502 and set(entries)==set(archives)
readback=[]
for name,x in entries.items():
    raw=auth(archives[name]).read_bytes();assert raw==auth(x['source']).read_bytes()==(R/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==x['final_sha256'] and len(raw)==x['final_bytes']
    readback.append({'path':name,'actual_archive':archives[name],'sha256':x['final_sha256'],'bytes':len(raw),'archive_live_plan_exact':True})
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];logical={}
for i,row in enumerate(draft['files'],1):
    name=row['canonical_path'];new=auth(row['proposed']).read_bytes();before=auth(row['before']).read_bytes() if row['before'] else b''
    if before:assert before==auth(archives[name]).read_bytes()==(R/name).read_bytes()==git(R,'show',HEAD+':'+name)
    else:assert name not in entries and not (R/name).exists()
    assert ns['apply_literal'](before,auth(row['forward_diff']).read_bytes())==new
    assert ns['apply_literal'](new,auth(row['inverse_diff']).read_bytes())==before
    parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R)
    assert parsed.returncode==0,parsed.stderr
    proposal=save('proposed/'+name,new)
    files.append({'canonical_path':name,'before_absent':not bool(before),'before':save('before/'+name,before) if before else None,
        'actual_parent_archive':archives.get(name),'proposed':proposal,'literal_inverse':save('literal-inverse/'+name,before),
        'forward_diff':save(f'diffs/{i:02}-forward.diff',auth(row['forward_diff']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',auth(row['inverse_diff']).read_bytes()),
        'literal_origin_whole':row['proposed'],'before_whole_Git_exact_at_base':bool(before),
        'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',parsed.stdout),'stderr':save(f'parse/{i:02}.stderr',parsed.stderr)}})
    entries[name]={'path':name,'final_sha256':proposal['sha256'],'final_bytes':proposal['bytes'],'source':proposal,'origin':'whole accepted Source29 coherent draft02 proposal; no semantic rewrite'}
    logical[name]=new.decode()
assert len(files)==4 and sum(x['before_absent'] for x in files)==1
assert len(entries)==4503 and sum(x.endswith('.rs') for x in entries)==4490
needles=['source_zone_return_air_convective_gain','source_zone_return_air_latent_gain','air_pattern_zone_info','air_balance::',
    'fn calculate_source_zone_mass_balance','fn calculate_source_zone_leaving_conditions','pub(super) fn mass_balance','pub(super) fn leaving_conditions']
api=[]
for name,row in sorted(entries.items()):
    if not name.endswith('.rs'):continue
    text=logical.get(name)
    if text is None:text=auth(row['source']).read_text(encoding='utf-8')
    hits=[{'line':i,'terms':[x for x in needles if x in line]} for i,line in enumerate(text.splitlines(),1) if any(x in line for x in needles)]
    if hits:api.append({'path':name,'ordered_hits':hits})
assert {x['path'] for x in api}=={x['canonical_path'] for x in files}
cohort=[x for x in entries if '/prediction/' in x and ('native_cohort' in x or '/fixtures/' in x)]
assert len(cohort)==2;cohort.append('crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs')
assert all(entries[x]==next(y for y in prior_plan['entries'] if y['path']==x) for x in cohort)
design_path=auth(draft['read_only_design']);design=json.loads(design_path.read_bytes());native=[]
for authority in design['Native_authorities']:
    name=authority['Native_path'];raw=auth(authority['whole']).read_bytes();assert raw==git(N,'show',PIN+':'+name)==(N/name).read_bytes()
    lines=raw.splitlines(keepends=True);extents=[]
    for e in authority['extents']:
        assert b''.join(lines[e['first']-1:e['last']])==auth(e['source']).read_bytes();extents.append(e)
    extra={'src/EnergyPlus/DataHeatBalance.hh':[(213,223)],'src/EnergyPlus/DataZoneEquipment.hh':[(192,202)]}.get(name,[])
    for first,last in extra:
        if not any(e['first']<=first and e['last']>=last for e in extents):
            extents.append({'first':first,'last':last,'source':save('Native-extents/'+Path(name).name+f'.{first}-{last}.txt',b''.join(lines[first-1:last]))})
    native.append({'Native_path':name,'whole':authority['whole'],'extents':extents,'pinned_Git_exact':True})
contexts=[]
for c in design['Source_contexts']:
    name=c['canonical_path'];raw=auth(archives[name]).read_bytes();assert raw==(R/name).read_bytes()==git(R,'show',HEAD+':'+name)
    contexts.append({'canonical_path':name,'whole':{**archives[name],'bytes':len(raw)},'actual_archive_and_selected_Git_exact':True})
final_plan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-Source29-compiler-input-plan.v1','base_HEAD':HEAD,
    'actual28_parent_snapshot':ref(snapshot_path),'prior_plan':ref(prior_plan_path),'inputs':4503,'Rust_sources':4490,
    'entries':[entries[x] for x in sorted(entries)],'selected4_exact_draft02':True,'three_existing_cohort_Sources_unchanged':True})
manifest={'schema':'src06-held-coherent-controlled-air-balance.v1','status':'HELD Source29 on clean committed actual28; no Source29 execution/completion claim',
    'base_HEAD':HEAD,'accepted28_actual_review':ref(actual_path),'parent_producer':ref(parent_path),'actual_parent_receipts':receipts,
    'actual_parent_snapshot':ref(snapshot_path),'prior_complete_compiler_Source_plan':ref(prior_plan_path),'complete_final_compiler_Source_plan':final_plan,
    'compiler_inputs':4503,'Rust_sources':4490,'original_draft02':ref(draft_path),'independent_full_semantic_peer':ref(peer_path),
    'independent_disjoint_mass_return_peer':ref(mass_path),'files':files,'existing_Source_files':3,'new_Source_files':1,'selected_Source_files':4,
    'literal_applications':8,'Source_only_parses':4,'all4_proposals_whole_unchanged_from_reviewed_draft02':True,
    'full4502_parent_readback':dump('actual28-parent-full-readback.json',readback),
    'whole4490_Rust_API_census':dump('API-census.json',{'Rust_sources_examined':4490,'all_crates_runtime_tests_included':True,'hits':api,'sole_real_management_callers':True,'new_tests':0}),
    'Native_commit':PIN,'Native_authorities':native,'concrete_same_owner_contexts':contexts,'read_only_design':ref(design_path),
    'operation_order':['Same Config/physical inlet flows then scheduled return flows, real MassConservation/fan flags and final return/warning traversal.',
        'Node-filtered cached return convection preserves per-space grouping; latent preserves direct ordered device reduction; same refrigeration credit and AirHB latentGain.',
        'Real NoHeatToReturnAir branches, Node T/P/W/H/contaminants and final existing initialize(o,zone,first)5541. No new numerical owner or scalar snapshots.'],
    'scope':'Finite zero-primary/no-mixing controlled mass/inlet/return/leaving closure. Actual flags/counts/schedules and allocated arrays select branches; both ordinary heat-to-return-air cases are represented. No all12/internal Native-paired numerical/fullB completion claim.',
    'remaining_scope':draft['remaining_boundaries'],
    'validation_policy':'Root alone runs actual B then A24. No new test body, unrelated profile or redundant alltargets. Inherited25 Raw metadata test and earlier1168 prediction cohort remain historical evidence only.',
    'new_test_bodies':0,'Cargo_main_tests_or_Native_mutations':False,'author_Source':ref(Path(__file__))}
p=O/'manifest.json';p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

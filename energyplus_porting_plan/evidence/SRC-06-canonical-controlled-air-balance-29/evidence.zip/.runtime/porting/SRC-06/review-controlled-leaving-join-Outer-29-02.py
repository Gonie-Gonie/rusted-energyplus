"""Independent29 leaving/gains/RoomAir and four-Source join, composing disjoint mass peer."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0';O=D/'Outer-controlled-air-balance-Source-review-29-02'
COMMIT='6f2e40d10250a105b49966baa24d843711e61048'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def load(r):return json.loads(checked(r))
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def main():
 assert not O.exists()
 pr=ref(D/'source-controlled-air-balance-draft-Audit-29-02/draft.json');assert pr['sha256']=='f3cb01aae008d3edffe07a291039e0268a96a36643b1303879fb7a5c9a61a464'
 m=load(pr);checked(m['author_Source']);assert m['Source_files']==4 and m['old']==3 and m['new']==1 and m['new_tests']==0
 massref=ref(D/'Peer-controlled-mass-return-Source-review-29-02/review.json');assert massref['sha256']=='2bfd6c1c97dbcb71b06d271f5a0dce39f152f2fe118a673d744258db8ef2d616'
 mass=load(massref);assert mass['accepted'] and not mass['findings'] and mass['reviewed_packet']==pr
 parent=load(m['logical_parent28']);assert parent['independent_full_semantic_peer']['sha256']=='9e432e32ed560e4e798e92afc2e196c6758ea551dd599dc0f37d4467983a2f88'
 plan=load(parent['complete_final_compiler_Source_plan']);entries={x['path']:x for x in plan['entries']};assert len(entries)==4502
 old=load(m['initial_three_Source_draft']);original={x['canonical_path']:checked(x['proposed']) for x in old['files']}
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
 files=[];selected={}
 for i,row in enumerate(m['files'],1):
  p=row['canonical_path'];before=b'' if row['before_absent'] else checked(row['before']);after=checked(row['proposed'])
  assert checked(row['literal_inverse'])==before
  if row['before_absent']:assert p not in entries and not (R/p).exists()
  else:assert before==checked(entries[p]['source'])==(R/p).read_bytes()
  if p in original:assert original[p]==after
  assert ns['apply'](before,checked(row['forward_diff']))==after and ns['apply'](after,checked(row['inverse_diff']))==before
  added='\n'.join(x[1:] for x in checked(row['forward_diff']).decode().splitlines() if x.startswith('+') and not x.startswith('+++'))
  assert not re.search(r'\.(unwrap|expect)\s*\(|\b(panic|todo|unimplemented|unreachable)!|#\[(test|ignore)',added)
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert q.returncode==0
  files.append(dict(canonical_path=p,before=row['before'],proposed=row['proposed'],parent28_whole_exact=not row['before_absent'],literal_forward_inverse_exact=True,whole_equal_initial_three_body_proposals=p in original,fresh_Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))))
  selected[p]=after
 management=next(v for k,v in selected.items() if k.endswith('/management.rs'))
 parent_management=checked(next(x['proposed'] for x in parent['files'] if x['canonical_path'].endswith('/management.rs')))
 assert parent_management==checked(m['files'][0]['before'])
 # Removing only these reviewed wrappers/module/call adjustment restores all28 bytes.
 a=management.index(b'    fn calculate_source_zone_mass_balance(');z=management.index(b'\n}\n',a)
 pa=parent_management.index(b'    fn calculate_source_zone_mass_balance(');pz=parent_management.index(b'\n}\n',pa)
 inverse=management[:a]+parent_management[pa:pz]+management[z:]
 inverse=inverse.replace(b'mod air_balance;\n',b'',1).replace(b'self.calculate_source_zone_leaving_conditions(first_hvac_iteration, o)?;',b'self.calculate_source_zone_leaving_conditions(o)?;',1)
 assert inverse==parent_management
 paths={
  'src/EnergyPlus/ZoneEquipmentManager.cc':[(5342,5543)],
  'src/EnergyPlus/InternalHeatGains.cc':[(8216,8255),(8506,8535)],
  'src/EnergyPlus/DataRoomAirModel.hh':[(635,650)],
  'src/EnergyPlus/RoomAirModelManager.cc':[(270,300)],
  'src/EnergyPlus/EPVector.hh':[(60,115),(125,157)],
  'src/EnergyPlus/DataHeatBalance.hh':[(1355,1373)],
  'src/EnergyPlus/DataHVACGlobals.hh':[(90,100)],
  'src/EnergyPlus/DataZoneEquipment.hh':[(190,205)],
  'src/EnergyPlus/Psychrometrics.hh':[(623,666),(679,716)],
 }
 native=[]
 for i,(p,spans) in enumerate(paths.items(),1):
  b=(N/p).read_bytes();assert b==subprocess.check_output(['git','show',COMMIT+':'+p],cwd=N)
  w=save(O/'Native'/f'{i:02}-{Path(p).name}',b);lines=b.splitlines(keepends=True);ext=[]
  for a,z in spans:ext.append(dict(first=a,last=z,source=save(O/'Native'/f'{i:02}-{a}-{z}.txt',b''.join(lines[a-1:z]))))
  native.append(dict(Native_path=p,whole=w,extents=ext))
 contexts=[]
 paths=['crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/management/output_required.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/devices.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/timestep/devices.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/getter.rs','crates/ep_runtime/src/psychrometrics.rs']
 for i,p in enumerate(paths,1):
  b=checked(entries[p]['source']);assert b==(R/p).read_bytes();contexts.append(dict(canonical_path=p,whole=save(O/'Source_context'/f'{i:02}-{Path(p).name}',b),parent28_exact=True))
 patterns=['source_zone_return_air_convective_gain','source_zone_return_air_latent_gain','air_pattern_zone_info','SourceRoomAir {','calculate_source_zone_leaving_conditions','calculate_source_zone_mass_balance','air_balance::mass_balance','air_balance::leaving_conditions']
 rust=subprocess.check_output(['rg','--files','crates','-g','*.rs'],cwd=R,text=True).splitlines();actual={Path(p).as_posix():(R/p).read_bytes() for p in rust};actual.update(selected)
 census=[]
 for p,b in sorted(actual.items()):
  lines=b.decode().splitlines();hits=[dict(line=i,text=s) for i,s in enumerate(lines,1) if any(t in s for t in patterns)]
  if hits:census.append(dict(path=p,sha256=sha(b),bytes=len(b),hits=hits))
 assert {x['path'] for x in census}==set(selected)
 air=next(v for k,v in selected.items() if k.endswith('/air_balance.rs'))
 assert air[:air.index(b'/// Native5342-5543')]==checked(mass['reviewed_mass_section'])
 result=dict(schema='src06-independent29-leaving-gains-RoomAir-coherent-join-review.v1',accepted=True,findings=[],reviewed_packet=pr,
  scope='Independent full leaving5342-5543/gains8216-8255+8506-8535/RoomAir constructor-writer and all4 Source literal/caller join. Mass4933-5283/inlet-return helper semantics compose the independently accepted disjoint Coil peer, not a duplicate numerical review.',
  disjoint_mass_return_peer=massref,logical_parent28=m['logical_parent28'],parent28_complete_plan=parent['complete_final_compiler_Source_plan'],files=files,literal_applications=8,fresh_Source_only_parses=4,
  original_three_body_wholes_unchanged=True,all_prior28_management_bytes_restored_by_exact_reviewed_join_inverse=True,
  Native_commit=COMMIT,Native_wholes=native,Native_whole_count=len(native),strict_Native_extents=sum(len(x['extents']) for x in native),Source_contexts=contexts,
  whole_crates_API_census=dict(Rust_sources=len(actual),patterns=patterns,files=census),
  leaving_proof=[
   'Actual SpaceHVAC simulation/not-sizing mixer traversal precedes all zone loops; current genuinely empty uninhabited rows do not fabricate mixer results. Actual controlled flag and return-node count guards precede same zone node, checked Native integer multiplier product, and AirHB borrow.',
   'Per actual ReturnNode/ReturnExhaust ordinal, filtered return convective gain is computed first. MassFlowRA is real ReturnNode.MassFlowRate divided by integer ZoneMult, then positive actual exhaust flow added unscaled. No mass/temperature mirror or presumed equal Node IDs.',
   'Actual space mixer-index branch and genuine same RoomAir EPVector allocation predicate precede zone temperature fallback. Allocated AirPattern branch stops at first unrepresented IsUsed read; positive window flag stops at actual surface/flow child. Three window local zeros are Native initializers only; positive window calculation is not claimed.',
   'NoHeatToReturnAir false evaluates real normal PsyCpAirFnW at same position even if mass is zero, preserving existing last-call cache. Window mixing arithmetic/heat fallback, return sensible gain division, strict upper60/lower-30 limits and SysDepZoneLoads increments retain grouping/write order. Exhaust Shared enum3 uses unbounded local TempRetAir exactly as Native, including post-limit behavior.',
   'NoHeatToReturnAir true or zero return flow writes actual zone node temperature. Pressure copy follows. Positive return flow/no-heat-false obtains actual latent gain before vaporization call, then writes zoneHumRat+gain/(H2OHtOfVap*MassFlowRA). Else actual humidity copied first, same credit[1] += credit[3] retained without clearing[3], then fresh filtered latent reduction and actual AirHB.latentGain +=.',
   'Same return node enthalpy uses existing normal floor-aware PsyHFnTdbW only after Temp/HumRat; optional CO2 then Generic copies retain real flags. Final original initialize(o,actualZone,FirstHVACIteration) resets current demand/deadband through genuine existing API; caller passes actual bool with mutable same owner. No arbitrary early return after Node updates.',
   'Temporary immutable scalar reads complete before writes and reborrow the same Nodes/Config/Zone/Gains/Air state; alias cases retain sequential actual reads. No added typed input cache, fake flow, duplicate model owner, approximation or tolerance change.'
  ],
  gains_proof=[
   'Convection exact ordered zone.spaceIndexes then per-space local0 accumulation then zone accumulation; device number_of_devices is real loop bound, skipzero preserved, filter actual ReturnNodeNum==0 or ==device.return_air_node, cached_rates[1] is genuine return-air convection pointer cache.',
   'Latent exact ONE sequential total over spaces/devices, same zero-device skip/filter, cached_rates[4] genuine return-air latent pointer cache. No regrouping into per-space subtotal; all current device cache writers and normal allocations retained.',
   'Normal Cp/H and pure vaporization formulas reuse accepted existing psychrometrics with same call order and operands; no new diagnostic/cache/property implementation. Native Shared=3, RetTempMax60, RetTempMin-30 and refrigeration [SenZone,LatZone,SenHVAC,LatHVAC] mapping authenticated.'
  ],
  RoomAir_proof=['Same existing SourceRoomAir gains only genuine AirPatternZoneInfo EPVector allocation state None. Native EPVector default m_allocated=false; DataRoomAirModel declaration and sole actual RoomAirModelManager295 allocation are pinned. Existing positive user-pattern Source getter returns before actual allocation; zero count returns before allocation in Native. No count/any_non_mixing proxy, inferred ready flag or fabricated row. Positive allocation contents remain typed boundary; constructor and whole-crates struct-literal census show no omitted caller update.'],
  final_join='Management differs from immutable28 only module hook, thin same-owner wrappers, real FirstHVAC bool and mutable leaving borrow; exact inverse restores all prior28 bytes including post-component/output/distribution/capacity helper. Other3 production proposals whole-identical original6311; accepted mass peer binds the same whole air_balance Source and exact prefix.',
  pending='Actual28 committed parent/full compiler snapshot and final29 complete overlay/custody seal, Root compiler/actual validation. No runtime/numerical/fullB/current-next-frontier claim from Source-only review.',new_tests=0,Cargo_main_Native_or_test_mutations=False,author_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'review.json',(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode())))
if __name__=='__main__':main()

"""Prepare Root-only29 publisher as literal successor of accepted28 engine."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'controlled-air-balance-publication-prepared-Audit-29'
OLD=D/'publish-zone-equipment-output-checkpoint-Peer-28.py'
NEW=D/'publish-controlled-air-balance-checkpoint-Audit-29.py'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
    p=R/x['path'];assert ref(p)['sha256']==x['sha256'] and ref(p)['bytes']==x.get('bytes',x.get('size_bytes',ref(p)['bytes']));return p
def load(x):return json.loads(auth(x).read_bytes())
def dump(name,x):
    p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return ref(p)
assert ref(OLD)['sha256']=='e35daa1a3beb4a70feb5a369b75877f1a4d4d32d170e77bbdcf7d32ea2ce01c4'
assert not O.exists() and not NEW.exists()
producer_ref=ref(D/'source-controlled-air-balance-held-Audit-29/manifest.json')
assert producer_ref['sha256']=='06b7d51e2dd42b4908b8e4a3ecf140f641fc0873aa28746231c002090a01065b'
producer=load(producer_ref);peer_ref=producer['independent_full_semantic_peer'];peer=load(peer_ref)
assert peer['accepted'] and not peer['findings']
previous_ref=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-zone-equipment-output-28/summary.json')
previous=load(previous_ref);assert (previous['A'],previous['B'])==('14/54','14/64')
accepted25_ref=ref(D/'Root-source-purchased-air-input-actual-review-25-02/review.json')
assert accepted25_ref['sha256']=='1bc1b45027a2a3a675e6dc16c12ce1e6fc1fe16076e66357a20044b6555402ca'
raw_test_ref=load(accepted25_ref)['raw_metadata_focused_test'];assert load(raw_test_ref)['exit_code']==0
old=OLD.read_text(encoding='utf-8');body=old
replacements=[
 ('checkpoint28','checkpoint29'),
 ('zone-equipment-output-publication-prepared-Peer-28','controlled-air-balance-publication-prepared-Audit-29'),
 ('SRC-06-canonical-zone-equipment-output-28','SRC-06-canonical-controlled-air-balance-29'),
 ('zone-equipment-output-publication-readback-Peer-28','controlled-air-balance-publication-readback-Audit-29'),
 ('d8fc400e4371114a98ed55fa4306aff01509c1ed','cb7149e19724bf1abc23d44be9ffce5838df36c3'),
 ('(4502,4489)','(4503,4490)'),
 ("len(producer['files']) == 3 and producer['existing_Source_files'] == 3 and producer['new_Source_files'] == 0",
  "len(producer['files']) == 4 and producer['existing_Source_files'] == 3 and producer['new_Source_files'] == 1"),
 ('all3_proposals_whole_unchanged_from_reviewed_draft02','all4_proposals_whole_unchanged_from_reviewed_draft02'),
 ('Root-source-zone-equipment-output-actual-review-28','Root-source-controlled-air-balance-actual-review-29'),
 ('same4502_archived_inputs_exact_final_plan','same4503_archived_inputs_exact_final_plan'),
 ('selected3_final_sources_exact','selected4_final_sources_exact'),
 ('whole_JSON_equal27_after_exactly_two_owned_path_field_bridges','whole_JSON_equal28_after_exactly_two_owned_path_field_bridges'),
 ('full_runtime_equal27_after_two_owned_path_bridges','full_runtime_equal28_after_two_owned_path_bridges'),
 ('== 4502 and set(index)==set(observed)','== 4503 and set(index)==set(observed)'),
 ('canonical-source-zone-equipment-output-B-NOLIMIT-24H-Root-28','canonical-source-controlled-air-balance-B-NOLIMIT-24H-Root-29'),
 ('canonical-source-zone-equipment-output-A-24H-Root-28','canonical-source-controlled-air-balance-A-24H-Root-29'),
 ('src06-canonical28-finite-evidence-archive.v1','src06-canonical29-finite-evidence-archive.v1'),
 ('3 coherent post-component output/demand/availability Sources','4 coherent controlled mass/return/leaving Sources'),
 ('src06-canonical-zone-equipment-output.v1','src06-canonical-controlled-air-balance.v1'),
 ('Genuine Source zone-equipment output and demand update; B incomplete at actual frontier','Genuine Source controlled mass and leaving conditions; B incomplete at actual frontier'),
 ("'accepted27_proof':actual['accepted27_full5352_proof']","'accepted28_proof':actual['accepted28_full5352_proof']"),
 ('physical_files_whole_equal27','physical_files_whole_equal28'),
 ('whole_physical_streams_equal27','whole_physical_streams_equal28'),
 ('CSV_files_whole_equal27','CSV_files_whole_equal28'),
 ('whole_CSV_equal27','whole_CSV_equal28'),
 ('Proof transfer from accepted27','Proof transfer from accepted28'),
 ('canonical_zone_equipment_output_28','canonical_controlled_air_balance_29'),
 ]
for before,after in replacements:
    assert before in body,before;body=body.replace(before,after)
anchor="    assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0"
body=body.replace(anchor,anchor+"\n    inherited25 = load(checked(template['accepted25_actual_review']))\n    assert inherited25['raw_metadata_focused_test'] == template['inherited25_raw_metadata_test']\n    inherited_test = load(checked(template['inherited25_raw_metadata_test']))\n    assert inherited_test['exit_code'] == 0 and inherited_test['source_bytes_match_before_and_after']",1)
anchor="                   B_Node_lifecycle_observation=actual['B_Node_lifecycle_observation'],"
body=body.replace(anchor,anchor+"\n                   inherited25_raw_metadata_test=template['inherited25_raw_metadata_test'],\n                   inherited25_raw_test_is_not_checkpoint29_execution=True,",1)
line=next(x for x in body.splitlines() if x.lstrip().startswith("append='\\n\\n[Source"))
body=body.replace(line,"        append='\\n\\n[Source 구역 질량 보존·리턴 공기 검증]('+link+'). '+text+'\\n'",1)
ast.parse(body);assert '\ufffd' not in body
NEW.write_text(body,encoding='utf-8',newline='\n');O.mkdir()
inputs={}
def add(x):
    p=auth(x);assert p.suffix.lower()!='.zip';value=ref(p)
    assert value['path'] not in inputs or inputs[value['path']]==value;inputs[value['path']]=value
for x in [producer_ref,producer['complete_final_compiler_Source_plan'],producer['full4502_parent_readback'],producer['whole4490_Rust_API_census'],
          producer['original_draft02'],producer['author_Source'],peer_ref,peer['author_Source'],producer['independent_disjoint_mass_return_peer'],
          producer['read_only_design'],producer['accepted28_actual_review'],accepted25_ref,raw_test_ref,previous_ref,ref(OLD),ref(NEW),ref(Path(__file__))]:add(x)
for row in producer['files']:
    for key in ('before','proposed','literal_inverse','forward_diff','inverse_diff'):
        if row[key]:add(row[key])
    for key in ('stdout','stderr'):add(row['Source_only_parse'][key])
for row in producer['Native_authorities']:
    add(row['whole'])
    for extent in row['extents']:add(extent['source'])
for row in producer['concrete_same_owner_contexts']:add(row['whole'])
template={'schema':'src06-held-canonical29-publication-template.v1','status':'HELD_FOR_ROOT_ACTUAL29_AND_FULL_READ',
    'base_HEAD':producer['base_HEAD'],'producer':producer_ref,'complete_plan':producer['complete_final_compiler_Source_plan'],
    'accepted_independent_peer':peer_ref,'accepted28_actual_review':producer['accepted28_actual_review'],
    'accepted25_actual_review':accepted25_ref,'inherited25_raw_metadata_test':raw_test_ref,
    'previous_checkpoint':previous_ref,'publisher_Source':ref(NEW),'publisher_parent_Source':ref(OLD),
    'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-controlled-air-balance-actual-review-29/review.json',
    'pending_Root_custody':{'application':'.runtime/porting/SRC-06/Root-controlled-air-balance-application-29/receipt.json',
        'actual_review_sha256':'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source':'.runtime/porting/SRC-06/check-source-controlled-air-balance-actual-Root-29.py',
        'launcher_Source':'.runtime/porting/SRC-06/launch-controlled-air-balance-Root-29.py',
        'B_CLI':'.runtime/porting/SRC-06/canonical-source-controlled-air-balance-B-NOLIMIT-24H-command-Root-29/receipt.json',
        'A24_CLI':'.runtime/porting/SRC-06/canonical-source-controlled-air-balance-A-24H-command-Root-29/receipt.json'},
    'Root_custody_at_publish':'Byte-authenticate actual aggregate/application, their author Sources, launcher and both actual CLI receipts/artifacts at publication. Actual observed boundary only; Source peer alone claims no execution.',
    'summary_template':{'A':'14/54','B':'14/64','changed_Rust_sources':4,'existing_Rust_sources':3,'new_Rust_sources':1,
        'new_test_functions':0,'actual_test_bodies_executed':0,
        'focused_validation_policy':'Actual production B then A24 only. Inherited25 RawModel test is historical evidence, not checkpoint29 execution. No unrelated profile, repeated cohort, new test or alltargets.',
        'scope':'Same controlled Config/physical Node/MassConservation mass, inlet/return and leaving operations; real schedule/fixed-flow arrays and return-node-filtered cached gains, refrigeration credit and demand reset. Same RoomAir allocation predicate. Actual flags/counts select finite branches; positive primary/mixing/exhaust/Space/window/allocatedRoomAir/diagnostic operations remain typed boundaries. All12/fullB/internal Native numerical equivalence unclaimed.',
        'full_B_or_finite15_completion_claim':False,'Native_harness_runtime_or_unit_equivalence_claim':False,'gate_changes':False,'policy_changes':False},
    'doc_appends':{
        'CHECKLIST.md':'제어 구역의 유입·리턴 유량과 리턴 공기 상태 계산을 실제 소유자에 연결했습니다. 실행 범위와 A24 결과는 연결된 증거에서 확인합니다.',
        'STATE_CONTRACTS.md':'Config·물리 Node·MassConservation과 기존 캐시 이득을 함께 사용합니다. 리턴 노드 필터·냉동 잠열 크레디트·수요 초기화 순서를 보존하며, 습공기 물성의 미구현 진단은 명시적 경계로 남깁니다.',
        'cards/SRC-06.md':'제어 구역 질량 보존과 리턴 공기 조건의 실행 결과를 기록합니다. 실제 B 경계는 `{{actual_B_frontier}}`입니다. 전체 B 및 내부 Native 수치 동등성 완료는 별도입니다.'},
    'finite_archive_inputs':[x for _,x in sorted(inputs.items())],'finite_archive_input_count':len(inputs),'finite_archive_input_bytes':sum(x['bytes'] for x in inputs.values()),
    'publisher_executed':False,'canonical_docs_mutations':False,'Cargo_tests_Native_executed':False,'gate_changes':False}
template_ref=dump('publication-template.json',template)
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
diffs={}
for name,a,b in [('forward',old.encode(),body.encode()),('inverse',body.encode(),old.encode())]:
    delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode()
    assert ns['apply_literal'](a,delta)==b;p=O/(name+'.diff');p.write_bytes(delta);diffs[name]=ref(p)
bridge=dump('publisher-parent-bridge.json',{'parent':ref(OLD),'successor':ref(NEW),'literal_applications':2,'changes':diffs,
    'scope':'Accepted28 two-CLI/zero-test finite archive/docs engine, with29 paths/base4503/4Sources and authentic28 proof transfer. Historical25 Raw receipt remains explicit; three distinct concise UTF8 appends/one SRC06 key/gates unchanged.',
    'publisher_executed':False,'canonical_mutations':False,'actual29_pending':True})
print(json.dumps({'publisher':ref(NEW),'template':template_ref,'bridge':bridge}))

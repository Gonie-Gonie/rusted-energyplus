"""Seal bounded independent union70 result after actual closed commands."""
from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';W=D/'ordinary-provider-assembly-Root-70/workspace';OUT=D/'Reviewer-ordinary-provider-union70-Source-review-01';O=D/'through-primary-diagnostic-A-24H-Root-70/output'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def workref(r):
 p=W/r['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];return ref(p)
def receipt(name,sha,exit):
 p=W/'.runtime/porting/SRC-06'/name/'receipt.json';assert ref(p)['sha256']==sha;r=json.loads(p.read_bytes())
 assert r['exit_code']==exit and r['launch_error'] is None and r['source_bytes_match_before_and_after']
 assert r['source_snapshot']['sha256']=='853ad26349d473354b059d4ac3ce8461555b92ceb56690c461dbbb6602bb7d1f'
 return r,dict(receipt=ref(p),stdout=workref(r['stdout']),stderr=workref(r['stderr']),Source_snapshot=workref(r['source_snapshot']),command=r['command'],actual_exit=exit,elapsed_seconds=r['elapsed_seconds'],Source_unchanged=True,target_cache=r['launch_environment_selected']['CARGO_TARGET_DIR'])
check,cr=receipt('provider-assembly-all-targets-command-70','6e79606b829a776f55f7e3e028a01126ac46686cf8977fce11069029256f4736',0)
tests,tr=receipt('provider-assembly-affected-report-tests-command-70-8MiB','2b45012abc8893c70b4fe75185f57517dc6a744681120046a3696e4be4bbf5c1',0)
cli,ar=receipt('provider-assembly-through-primary-A-24H-command-70','36376f49c0cfade776fad278f340888210eace20e87b33900b84a09953b625c4',6)
stdout=(W/tests['stdout']['path']).read_text(encoding='utf8');summary=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout)
assert summary==[('19','0','0','0','3325')]
actual_tests=re.findall(r'^test ([^\r\n]+) \.\.\. ok\s*$',stdout,re.M);assert len(actual_tests)==len(set(actual_tests))==19
assert tests['command'][2:4]==['--bytes','8388608'] and 'ep_runtime' in tests['command'] and '--lib' in tests['command']
d=json.loads((O/'diagnostics.json').read_bytes());errors=[r for r in d['diagnostics'] if r['severity']=='error'];assert len(errors)==1
error=errors[0];assert error['blocking'] and error['message']=='GetHeatBalanceInput: actual WriteTabularReports5230 WriteBEPSTable entry'
log=(O/'eplusrs.ctf.log').read_bytes();styles=['comma','tab','text','HTML','XML']
announcements=[f'Writing tabular output file results using {style} format.'.encode() for style in styles]
positions=[log.index(t) for t in announcements];assert positions==sorted(positions)
assert b'Beginning Primary Simulation' in log and b'Starting Simulation at 01/01/2013 for RUN PERIOD 1' in log
assert b'Environment:WarmupDays, 20' in (O/'eplusrs.eio').read_bytes()
table=json.loads((O/'logs/source-predefined-table.json').read_bytes());assert table['schema']=='source-predefined-table-observation.v1'
active=table['table']['num_table_entry'];capacity=table['table']['size_table_entry'];assert active==505 and capacity==len(table['table']['allocated_rows_in_original_order'])==800
assert not(O/'logs/source-report-binary64.csv').exists()
snapshot=json.loads((W/check['source_snapshot']['path']).read_bytes());assert len(snapshot['files'])==4428
for r in snapshot['files']:
 p=W/r['historical_path'];a=(W/r['archive']['path']).read_bytes();assert p.read_bytes()==a and len(a)==r['size_bytes'] and hashlib.sha256(a).hexdigest()==r['archive']['sha256']
outputs=[ref(O/n) for n in ['diagnostics.json','eplusrs.ctf.log','eplusrs.eio','eplusrs.eso','eplusrs.mtr','logs/source-predefined-table.json','eplustbl.csv','eplustbl.tab','eplustbl.txt','eplustbl.htm','eplustbl.xml']]
v=dict(schema='src06-independent-union70-Source-command-frontier-review.v1',accepted=True,status='ACCEPTED_MECHANICAL_SOURCE_COMPOSITION_AND_ACTUAL_CHECK_TESTS_EXPECTED_REPORT_FRONTIER',manifest=ref(D/'ordinary-provider-assembly-Root-70/manifest.json'),Source_part=ref(OUT/'source-part.json'),compile_part=ref(OUT/'compile-part.json'),findings=[],review_scope='Mechanical exact composition/custody/census and actual command/frontier only. Some implementation leaves were authored by this reviewer and are accepted here solely through their separately bound independent Root/Audit/Fix peers, not self-approved.',checks=dict(compiler_inputs=4428,Rust_sources=4415,parent_inputs_unchanged=4421,existing_detached=27,new_fresh=7,changed_paths=34,composition_stages=47,literal_applications=258,independent_leaf_peers=10,normalizations=0,conflicts=0,new_test_bodies=0,full_command_snapshot_archive_live4428_equal=True,diagnostic_pipeline_exact69=True,report_binary64_instrumentation_excluded=True),actual_all_targets_check=cr,actual_affected_tests=dict(**tr,passed=19,failed=0,ignored=0,filtered_out=3325,actual_test_names=actual_tests,scope='Existing ep_runtime lib tests selected by actual seven filters, explicit8MiB test stack and shared Root55 target cache. Not full workspace/alltargets tests.'),actual_A24_frontier=dict(**ar,actual_diagnostic=error,earlier69_frontier='WriteTabularReports596 before FillWeather',new70_frontier='actual true5230 WriteBEPSTable child entry after ordered FillWeather5212/FillRemaining5213/Rainfall5214 and all five style-pass announcements',observed_styles=styles,observed_WarmupDays=20,table_active_entries=active,table_allocated_rows=capacity,table_qualification='Observed Source state only; no Native table/value equality, report completion, or active-row/allocated-row conflation.'),output_artifacts=outputs,qualifications=['CLI exit6 is the actual retained typed missing-report-child boundary, not successful completed RuntimeResult. Generic RuntimeConvergenceFailure/GetHeatBalanceInput diagnostic labels do not establish a thermal convergence failure.','No Source completed 24-hour result exporter, full endrun/close, Native binary64 equality, or gate advancement is certified.','Compile/selected tests use recorded shared Root55 cache; no fresh-target or full-suite claim. Source snapshot identity is independently checked.','Installed Native version/header bytes, stream exception parity and pending report children retain existing bounded qualifications.','Reviewer ran only Python/read-only Git/rg and artifact reads, no Cargo/tests/Native or canonical changes.'],reviewer_Source=ref(Path(__file__)),preserved_partial_reviewer01=dict(Source=ref(D/'review-union70-final-Reviewer-01.py'),failure='Wrong wrapper command slice3:5; actual --bytes is index2. Assertion stopped before review artifact; no Source or command execution.'),canonical_changed=False,Git_mutated=False,reviewer_Cargo_tests_Native_executed=False,numerical_PASS_or_gate_claim=False)
p=OUT/'review.json';assert not p.exists();p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

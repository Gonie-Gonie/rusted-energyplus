"""Prepare, never apply, exact Source70 core promotion against announced a0d3403c."""
from pathlib import Path
import ast,difflib,hashlib,json,re,sys
sys.stdout.reconfigure(encoding='utf-8')
R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'canonical-source70-selective-promotion-prepared-Fix-01';W=B/'ordinary-provider-assembly-Root-70/workspace';assert not O.exists();O.mkdir()
BASE_HEAD='a0d3403c15a8d5a5cddb177a90bab66c32b7f2d2'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':sha(b),'bytes':len(b)}
def read(d):
 b=(R/d['path']).read_bytes();assert sha(b)==d['sha256'];assert len(b)==d.get('bytes',len(b));return b
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists()
 if isinstance(b,bytes):p.write_bytes(b)
 else:p.write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return ref(p)
def diff(a,b,p):return ''.join(difflib.unified_diff(a.decode('utf-8').splitlines(True),b.decode('utf-8').splitlines(True),fromfile='before/'+p,tofile='after/'+p)).encode('utf-8')
def apply(a,d):
 old=a.splitlines(True);ls=d.splitlines(True);out=[];c=0;i=0
 while i<len(ls):
  h=re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ls[i])
  if not h:assert ls[i].startswith((b'--- ',b'+++ '));i+=1;continue
  st,n,_,nn=[int(x) if x is not None else 1 for x in h.groups()];at=st-1 if n else st;assert c<=at<=len(old);out+=old[c:at];c=at;i+=1;x=y=0
  while i<len(ls) and not ls[i].startswith(b'@@ '):
   z=ls[i];assert z[:1] in (b' ',b'-',b'+')
   if z[:1] in (b' ',b'-'):assert old[c]==z[1:];c+=1;x+=1
   if z[:1] in (b' ',b'+'):out.append(z[1:]);y+=1
   i+=1
  assert (x,y)==(n,nn)
 return b''.join(out+old[c:])
def sourcepaths(root):
 ps=set((root/'crates').rglob('*.rs'))|set((root/'crates').rglob('Cargo.toml'))
 ps|={root/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (root/n).is_file()}
 return {p.relative_to(root).as_posix() for p in ps}
mp=B/'ordinary-provider-assembly-Root-70/manifest.json';assert ref(mp)['sha256']=='dfd2cadc876377f7e7523891b3f65e3ea474e1c8d808b09ecfcdfd7095c26514';m=json.loads(mp.read_bytes())
peer=B/'Reviewer-ordinary-provider-union70-Source-review-01/review.json';assert ref(peer)['sha256']=='ea960416aa3b8df6597c90951c65b32d418a0b62d304c2f018be1387465df46d';pr=json.loads(peer.read_bytes());assert pr['accepted'] and not pr['findings'] and pr['manifest']==ref(mp)
commands={}
for role,sub,h,exitcode in [('all_targets','provider-assembly-all-targets-command-70','6e79606b829a776f55f7e3e028a01126ac46686cf8977fce11069029256f4736',0),('existing19','provider-assembly-affected-report-tests-command-70-8MiB','2b45012abc8893c70b4fe75185f57517dc6a744681120046a3696e4be4bbf5c1',0),('actual_A','provider-assembly-through-primary-A-24H-command-70','36376f49c0cfade776fad278f340888210eace20e87b33900b84a09953b625c4',6)]:
 p=W/'.runtime/porting/SRC-06'/sub/'receipt.json';assert ref(p)['sha256']==h;r=json.loads(p.read_bytes());assert r['exit_code']==exitcode and r['source_bytes_match_before_and_after'];commands[role]=ref(p)
r=json.loads((R/commands['actual_A']['path']).read_bytes());sp=W/r['source_snapshot']['path'];assert ref(sp)['sha256']==r['source_snapshot']['sha256'];ss=json.loads(sp.read_bytes());index={f['historical_path']:f for f in ss['files']};assert len(index)==4428 and sourcepaths(W)==set(index)
for p,e in index.items():
 b=(W/p).read_bytes();assert len(b)==e['size_bytes'] and sha(b)==e['archive']['sha256'] and (W/e['archive']['path']).read_bytes()==b
P='crates/ep_run/src/pipeline.rs';C='crates/ep_run/src/ctf_initialization_outputs.rs'
stat=B/'ordinary-weather-stat-held-Audit-01/manifest.json';sm=json.loads(stat.read_bytes());assert ref(stat)['sha256']=='99578bb99487d0da2231751426ed2b99ea701e05c1729221834bbf2b76c9d806'
statrow=next(f for f in sm['files'] if f['canonical_path']==C);ctf_core=read(statrow['proposed'])
obs=B/'ordinary-predefined-table-observer-held-Fix-01/manifest.json';om=json.loads(obs.read_bytes());assert ref(obs)['sha256']=='62a1e87bc542b2fafb906500798f518a128aeb44714faca4429fbb2c41d50b78'
orow=om['files'][0];assert orow['canonical_path']==C and read(orow['parent_before'])==ctf_core and read(orow['proposed'])==(W/C).read_bytes()
assert apply(ctf_core,read(orow['parent_forward_diff']))==(W/C).read_bytes() and apply((W/C).read_bytes(),read(orow['parent_inverse_diff']))==ctf_core
canonical_paths=sourcepaths(R);before_census={p:(R/p).read_bytes() for p in canonical_paths};assert len(canonical_paths)==4421
assert P not in {f['canonical_path'] for f in m['files']}
selected={f['canonical_path']:(ctf_core if f['canonical_path']==C else read(f['proposed'])) for f in m['files']}
assert len(selected)==34 and all(p.endswith('.rs') for p in selected)
new={p for p in selected if p not in canonical_paths};existing=set(selected)-new;assert len(new)==7 and len(existing)==27
planned_paths=canonical_paths|new;assert planned_paths==set(index)
rows=[];applications=[]
for i,p in enumerate(sorted(selected),1):
 a=before_census.get(p,b'');z=selected[p];assert a!=z
 if p not in canonical_paths:assert not (R/p).exists()
 assert a.count(b'#[test]')==z.count(b'#[test]')
 fd=diff(a,z,p);iv=diff(z,a,p);assert apply(a,fd)==z and apply(z,iv)==a
 row={'canonical_path':p,'before_absent':p in new,'current_before':None if p in new else ref(R/p),'before':save('before/'+p,a),'literal_inverse':save('literal-inverse/'+p,a),'proposed':save('proposed/'+p,z),'complete_forward_diff':save(f'diffs/{i:02}-forward.diff',fd),'complete_inverse_diff':save(f'diffs/{i:02}-inverse.diff',iv),'Root70_actual_Source':ref(W/p),'planned_equals_actual70':z==(W/p).read_bytes(),'proposal_rule':'Exact accepted STAT01 constructor/core; excludes only diagnostic persist snapshot' if p==C else 'Exact actual independently accepted/typechecked Source70 bytes'}
 rows.append(row);applications.extend([{'path':p,'role':'forward','literal_application_passed':True},{'path':p,'role':'inverse','literal_application_passed':True}])
full=[];exceptions=[]
for p in sorted(planned_paths):
 a=before_census.get(p);z=selected.get(p,a);actual=(W/p).read_bytes();assert z is not None
 equal=z==actual
 if not equal:
  assert p in [P,C]
  exceptions.append({'path':p,'planned_sha256':sha(z),'Root70_sha256':sha(actual),'rule':'Canonical a0 whole pipeline unchanged; held throughPrimary/endrun dispatch and statistics JSON observer excluded' if p==P else 'Exact STAT01 core only; readonly predefined snapshot excluded'})
 if p==P:assert z==before_census[p]
 full.append({'path':p,'before_absent':a is None,'before_sha256':None if a is None else sha(a),'before_bytes':0 if a is None else len(a),'planned_sha256':sha(z),'planned_bytes':len(z),'Root70_sha256':sha(actual),'planned_exact70':equal,'selected_for_write':p in selected})
assert {x['path'] for x in exceptions}=={P,C}
assert all(e['planned_exact70'] for e in full if e['path'] not in [P,C])
assert sum(p.endswith('.rs') for p in planned_paths)==4415
assert sourcepaths(R)==canonical_paths and all((R/p).read_bytes()==b for p,b in before_census.items())
assert sourcepaths(W)==set(index) and all(sha((W/p).read_bytes())==e['archive']['sha256'] for p,e in index.items())
census=save('complete-compiler-Source-plan.json',{'schema':'canonical70-selective-compiler-Source-plan.v1','base_announced_HEAD':BASE_HEAD,'current_Git_queried':False,'before_count':len(canonical_paths),'planned_count':len(planned_paths),'planned_Rust_count':4415,'planned_all_except_two_exact70':True,'explicit_exceptions':exceptions,'files':full})
app_script=r'''"""ROOT-ONLY explicit apply of prepared Source70 core; no tests or Git mutations."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
if sys.argv[1:]!=['--apply']:raise SystemExit('Prepared only. Root may run with explicit --apply after review.')
plan=json.loads((HERE/'manifest.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(r):
    p=ROOT/r['path'];b=p.read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];return b
def sourcepaths(root):
    ps=set((root/'crates').rglob('*.rs'))|set((root/'crates').rglob('Cargo.toml'))
    ps|={root/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (root/n).is_file()}
    return {p.relative_to(root).as_posix() for p in ps}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==plan['base_HEAD']
scope=json.loads(checked(plan['complete_compiler_Source_plan']))
before_paths={e['path'] for e in scope['files'] if not e['before_absent']}
assert sourcepaths(ROOT)==before_paths
for e in scope['files']:
    p=ROOT/e['path'];assert p.resolve().is_relative_to(ROOT.resolve())
    assert not p.exists() if e['before_absent'] else (p.is_file() and sha(p.read_bytes())==e['before_sha256'] and p.stat().st_size==e['before_bytes'])
for row in plan['files']:
    checked(row['before']);checked(row['proposed']);assert checked(row['literal_inverse'])==checked(row['before'])
for row in plan['files']:
    p=ROOT/row['canonical_path'];assert p.resolve().is_relative_to(ROOT.resolve());p.parent.mkdir(parents=True,exist_ok=True)
    temporary=p.with_name(p.name+'.source70-promotion-tmp');assert temporary.resolve().is_relative_to(ROOT.resolve()) and not temporary.exists()
    temporary.write_bytes(checked(row['proposed']));os.replace(temporary,p)
assert sourcepaths(ROOT)=={e['path'] for e in scope['files']}
for e in scope['files']:
    p=ROOT/e['path'];assert sha(p.read_bytes())==e['planned_sha256'] and p.stat().st_size==e['planned_bytes']
print(json.dumps({'applied_Source_paths':len(plan['files']),'new_Source':plan['new_Source_files'],'existing_Source':plan['existing_Source_files'],'canonical_pipeline_whole_unchanged':True,'predefined_snapshot_excluded':True,'tests_or_Git_mutations':False}))
'''
ast.parse(app_script);applyref=save('apply-source70.py',app_script.encode('utf-8'))
manifest={'schema':'prepared-canonical-Source70-selective-promotion.v1','status':'PREPARED UNEXECUTED; Root must review/apply/test/publish','base_HEAD':BASE_HEAD,'base_HEAD_role':'Parent-announced exact current HEAD; raw complete canonical compiler census authenticated; no preparation Git command executed','Root70':ref(mp),'independent_Root70_peer':ref(peer),'Root70_actual_commands':commands,'Root70_actual_Source_snapshot':ref(sp),'required_STAT01':ref(stat),'excluded_readonly_snapshot':ref(obs),'files':rows,'literal_applications':applications,'complete_compiler_Source_plan':census,'apply_script':applyref,'apply_script_ast_parse_passed':True,'apply_script_executed':False,'canonical_changes_by_preparer':0,'new_Source_files':len(new),'existing_Source_files':len(existing),'changed_Source_files':len(rows),'planned_compiler_inputs':4428,'planned_Rust_sources':4415,'all_nonpipeline_nonobserver_core_bytes_exact70':True,'canonical_pipeline_whole_unchanged':True,'binary64_diagnostic_writer6_BEPS_future_packets_excluded':True,'new_test_bodies':0,'Cargo_Native_Git_or_tests_executed_by_preparer':False,'actual_execution_limits':['Root70 all-targets check0 and19 existing affected tests0 at configured8MiB are actual scoped validations; not a fresh-target/full-suite claim.','Actual70 CLI exited6 at true WriteBEPSTable5230 after physical predefined prefix/style; not completed Native endrun620, RuntimeResult exporter or numerical equality.','Canonical promotion retains honest child boundaries and existing default runtime dispatch. No held throughPrimary/endrun pipeline or diagnostic JSON snapshot is promoted.','Native API02 timing capture and raw Which/ESO observations are separate evidence; 575/576 parsed values and one ID97 row42 one-ULP difference do not certify Source binary64/roundtrip equality.'],'Root_next_commands':{'apply':['python',applyref['path'],'--apply'],'canonical_validation':'Root may run the existing27 compatibility/acceptance tests once at configured8MiB after application; no new test bodies requested.'},'author_Source':ref(Path(__file__))}
save('manifest.json',manifest);print(json.dumps(ref(O/'manifest.json')))

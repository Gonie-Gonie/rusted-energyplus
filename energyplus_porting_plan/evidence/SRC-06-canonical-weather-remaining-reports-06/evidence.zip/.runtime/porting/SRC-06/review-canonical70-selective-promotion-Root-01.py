from pathlib import Path
import ast,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-canonical70-selective-promotion-review-01';assert not OUT.exists();OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=sha(b),bytes=len(b))
def checked(v):
 b=(ROOT/v['path']).read_bytes();assert sha(b)==v['sha256']and len(b)==v.get('bytes',len(b)),v['path'];return b
mp=BASE/'canonical-source70-selective-promotion-prepared-Fix-01/manifest.json';assert sha(mp.read_bytes())=='31395e53c1038e64047efd3df39c6f8aa0628a5dc18f2e97a5567781c763f358';m=json.loads(mp.read_bytes());assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b'';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==m['base_HEAD']
t=ast.parse((BASE/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef)and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
for k in ['Root70','independent_Root70_peer','Root70_actual_Source_snapshot','required_STAT01','excluded_readonly_snapshot','complete_compiler_Source_plan','apply_script','author_Source']:checked(m[k])
peer=json.loads(checked(m['independent_Root70_peer']));assert peer.get('accepted',str(peer.get('status','')).startswith('ACCEPTED'))
for role,e in m['Root70_actual_commands'].items():
 q=json.loads(checked(e));assert q['source_bytes_match_before_and_after']and q['exit_code']==(6 if role=='actual_A'else 0)
rows={e['canonical_path']:e for e in m['files']};assert len(rows)==34 and sum(e['before_absent']for e in rows.values())==7
apps=0;ctf='crates/ep_run/src/ctf_initialization_outputs.rs';pipe='crates/ep_run/src/pipeline.rs'
stat=json.loads(checked(m['required_STAT01']));snapshot=json.loads(checked(m['excluded_readonly_snapshot']))
for path,e in rows.items():
 a,b=checked(e['before']),checked(e['proposed']);assert checked(e['literal_inverse'])==a
 assert apply(a,checked(e['complete_forward_diff']))==b and apply(b,checked(e['complete_inverse_diff']))==a;apps+=2
 actual=checked(e['Root70_actual_Source'])
 if path==ctf:
  assert not e['planned_equals_actual70'];assert b==checked(next(q for q in stat['files']if q['canonical_path']==ctf)['proposed'])
  obs=next(q for q in snapshot['files']if q['canonical_path']==ctf)
  assert actual==checked(obs['proposed']) and apply(actual,checked(obs['parent_inverse_diff']))==b
 else:assert e['planned_equals_actual70']and actual==b
c=json.loads(checked(m['complete_compiler_Source_plan']));assert len(c['files'])==4428 and sum(e['path'].endswith('.rs')for e in c['files'])==4415
assert {e['path']for e in c['files']if e['selected_for_write']}==set(rows)
for e in c['files']:
 p=ROOT/e['path']
 if e['before_absent']:assert not p.exists()
 else:
  a=p.read_bytes();assert sha(a)==e['before_sha256']and len(a)==e['before_bytes']
 b=checked(rows[e['path']]['proposed'])if e['path']in rows else p.read_bytes();assert sha(b)==e['planned_sha256']and len(b)==e['planned_bytes']
 actual=(BASE/'ordinary-provider-assembly-Root-70/workspace'/e['path']).read_bytes();assert sha(actual)==e['Root70_sha256'];assert e['planned_exact70']==(b==actual)
 if e['path']not in [pipe,ctf]:assert b==actual
 if e['path']==pipe:assert e['before_sha256']==e['planned_sha256']and e['before_bytes']==e['planned_bytes']and not e['selected_for_write']
script=checked(m['apply_script']);ast.parse(script.decode());assert b'parents[4]'in script and b'os.replace' in script
result=dict(schema='src06-independent-canonical70-promotion-preflight.v1',accepted=True,status='Reviewed exact34 proposals; apply/appropriate canonical QA separate',prepared_manifest=ref(mp),base_HEAD=m['base_HEAD'],changed_Source=34,new_Source=7,existing_Source=27,literal_applications=apps,complete_planned_inputs=4428,Rust_inputs=4415,exact70_inputs=4426,canonical_pipeline_whole_unchanged=True,ctf_core_exact_STAT01_snapshot_only_removed=True,all_other_canonical_before_inputs_authenticated=True,canonical_writes=False,Cargo_or_Native_or_Git_mutation=False,reviewer_Source=ref(Path(__file__).resolve()))
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(OUT/'review.json')))

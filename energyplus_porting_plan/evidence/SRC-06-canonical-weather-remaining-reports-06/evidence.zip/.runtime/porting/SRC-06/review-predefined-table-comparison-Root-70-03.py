from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/porting/SRC-06'
OUT = BASE / 'Root-predefined-table-comparison-70-review-03'
assert not OUT.exists()

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def read(r):
    p = ROOT / r['path']
    assert ref(p) == r
    return p.read_bytes()

p = BASE / 'Reviewer-ordinary-predefined-table-byte-comparison-70-01/comparison.json'
assert ref(p)['sha256'] == 'a469b0047b59e7b494134e4b70eab9dd1b01deb4482bdbc8fb2f9faaa5cbf842'
m = json.loads(p.read_bytes())
s = json.loads(read(m['Source_snapshot']))
ledger = json.loads(read(m['all_cell_ledger']))
assert isinstance(ledger, list)
native_lines = read(m['Native_CSV']).splitlines()
for a in m['Original_authority']:
    raw = read(a['source'])
    assert read(a['literal_excerpt']) == b''.join(raw.splitlines(keepends=True)[a['first_line']-1:a['last_line']])
    assert a['strict_EOF'] and a['pinned_whole_equal']
for k in ['actual_Source_receipt', 'actual_Native_receipt', 'actual_Native_version_receipt']:
    r = json.loads(read(m[k]))
    assert r['exit_code'] == (6 if k == 'actual_Source_receipt' else 0)
    assert r['source_bytes_match_before_and_after']
read(m['input_identity']['original_IDF']); read(m['input_identity']['weather'])

selected_tables = {tuple(v.encode('utf-8') for v in r['cell_labels_Source_UTF8'][:2]) for r in ledger}
cells = defaultdict(list)
report = table = last_label = None
headings = None
for n, line in enumerate(native_lines, 1):
    if line.startswith(b'REPORT:,'):
        report = line[len(b'REPORT:,'):]
        table = headings = None
    elif line.startswith(b',,'):
        table = last_label
        headings = line.split(b',')[2:]
        heading_line = n
    elif line.startswith(b',') and headings is not None:
        parts = line.split(b',')
        if len(headings) == 1:
            obj = parts[1]
            values = [b','.join(parts[2:])]
        else:
            tail = line[1:].rsplit(b',', len(headings))
            obj, values = tail[0], tail[1:]
        if len(values) != len(headings):
            assert (report, table) not in selected_tables, (n, line)
            continue
        for c, (heading, value) in enumerate(zip(headings, values)):
            cells[(report, table, obj, heading)].append((n, heading_line, c, value))
    elif line:
        last_label = line
        if not line.startswith(b'FOR:'):
            headings = None

registry = s['registry']
columns = {x['source_index_one_based']:x for x in registry['allocated_columns_in_original_order']}
tables = {x['source_index_one_based']:x for x in registry['allocated_subtables_in_original_order']}
reports = {x['source_index_one_based']:x for x in registry['allocated_reports_in_original_order']}
rows = s['table']['allocated_rows_in_original_order']
assert s['table']['num_table_entry'] == 505 and s['table']['size_table_entry'] == 800
assert [r['source_position'] for r in ledger] == list(range(287,506))
statuses = Counter()
for row in ledger:
    pos = row['source_position']
    entry = rows[pos-1]
    assert entry['source_index_one_based'] == pos
    column = columns[entry['index_column']]
    sub = tables[column['subtable_index']]
    report = reports[sub['report_index']]
    labels = [report['name_with_spaces'], sub['name'], entry['object_name'], column['heading_including_units']]
    key = tuple(x.encode('utf-8') for x in labels)
    assert labels == row['cell_labels_Source_UTF8']
    assert [x.hex() for x in key] == row['cell_key_hex']
    assert row['Source_report_shown'] == report['show'] == True
    raw = bytes.fromhex(entry['char_entry_hex'])
    assert len(raw) == entry['char_entry_byte_count']
    assert raw.hex() == row['source_char_entry_hex']
    projected = raw.strip(b' ')
    assert projected.hex() == row['source_ASCII_space_stripped_hex']
    found = cells[key]
    assert len(found) == len(row['Native_candidates']) == 1
    ln, hln, cn, val = found[0]
    candidate = row['Native_candidates'][0]
    assert (ln,hln,cn,val.hex(),native_lines[ln-1].hex()) == (
        candidate['native_line'],candidate['native_heading_line'],candidate['native_column_zero_based'],
        candidate['value_hex'],candidate['raw_line_hex'])
    equal = projected == val
    assert equal == row['raw_projected_bytes_equal']
    status = 'EXACT_PROJECTED_REPORTED_BYTES' if equal else 'UNPAIRED_LATE_NATIVE_WRITER'
    assert row['status'] == status
    if not equal:
        assert pos == 481 and projected == b'-' and val == b'232.26'
    statuses[status] += 1
assert dict(statuses) == m['all_selected_statuses']
assert statuses == {'EXACT_PROJECTED_REPORTED_BYTES':218, 'UNPAIRED_LATE_NATIVE_WRITER':1}
OUT.mkdir()
review = dict(accepted=True, comparison=ref(p), full_ledger=m['all_cell_ledger'], independently_recomputed_entries=219,
    statuses=dict(statuses), source_positions=[287,505], Source_snapshot=m['Source_snapshot'], Native_CSV=m['Native_CSV'],
    method='Independent raw Native table parser and Source registry joins; ASCII space strip only; all candidate byte fields and all rows recomputed.',
    unpaired='Position481: Remaining literal placeholder precedes later BEPS overwrite in Native final report. Strict original authority excerpts authenticated.',
    numerical_gate_PASS=False, Source_full_run=False, Source=ref(Path(__file__).resolve()))
q = OUT/'review.json'; q.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(ref(q)))

"""Publish the verified report prefix without activating held dispatch or diagnostic observers."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/porting/SRC-06'
WORK = BASE / 'ordinary-provider-assembly-Root-70/workspace'
PUBLIC = ROOT / 'energyplus_porting_plan/evidence/SRC-06-canonical-weather-remaining-reports-06'
assert not PUBLIC.exists()
payload = {}

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def add(p):
    p = p.resolve(); key = p.relative_to(ROOT).as_posix(); b = p.read_bytes()
    assert key not in payload or payload[key] == b
    payload[key] = b
    return ref(p)

def add_ref(r, base=ROOT):
    p = base / r['path']; b = p.read_bytes()
    assert hashlib.sha256(b).hexdigest() == r['sha256'] and len(b) == r.get('bytes',len(b))
    return add(p)

prepared = BASE / 'canonical-source70-selective-promotion-prepared-Fix-01/manifest.json'
assert ref(prepared)['sha256'] == '31395e53c1038e64047efd3df39c6f8aa0628a5dc18f2e97a5567781c763f358'
m = json.loads(prepared.read_bytes())
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head == m['base_HEAD']
add(prepared); add(Path(__file__).resolve())
for key in ['Root70','independent_Root70_peer','Root70_actual_Source_snapshot','required_STAT01',
            'excluded_readonly_snapshot','complete_compiler_Source_plan','apply_script','author_Source']:
    add_ref(m[key])
for row in m['files']:
    for key in ['proposed','before','literal_inverse','complete_forward_diff','complete_inverse_diff']:
        if row.get(key): add_ref(row[key])
    assert (ROOT/row['canonical_path']).read_bytes() == (ROOT/row['proposed']['path']).read_bytes()
    add(ROOT/row['canonical_path'])
assert len(m['files']) == 34 and m['new_Source_files'] == 7
review = BASE/'Root-canonical70-selective-promotion-review-01/review.json'
assert ref(review)['sha256'] == '3a0413225818dda11a23de9a5af6dbf612e5b83f5ed9002ca26cf73026c8e776'
add(review); add(BASE/'review-canonical70-selective-promotion-Root-01.py')
peer = json.loads(add_ref(m['independent_Root70_peer']) and (ROOT/m['independent_Root70_peer']['path']).read_bytes())
assert peer['accepted']
for key in ['Source_part','reviewer_Source']:
    add_ref(peer[key])
for name,r in m['Root70_actual_commands'].items():
    add_ref(r); receipt=json.loads((ROOT/r['path']).read_bytes())
    assert receipt['exit_code'] == (6 if name=='actual_A' else 0)
    assert receipt['source_bytes_match_before_and_after']
    for k in ['stdout','stderr','source_snapshot']: add_ref(receipt[k],WORK)
qpath=BASE/'canonical-source70-existing-arbitrary-run-tests-Root-06-8MiB/receipt.json'
qa=json.loads(qpath.read_bytes());assert qa['exit_code']==0 and qa['source_bytes_match_before_and_after']
assert '27 passed; 0 failed' in (ROOT/qa['stdout']['path']).read_text(encoding='utf-8')
add(qpath)
for k in ['stdout','stderr','source_snapshot']:add_ref(qa[k])
add(BASE/'run-with-explicit-test-stack-Root-01.py')
out=BASE/'through-primary-diagnostic-A-24H-Root-70/output'
for name in ['diagnostics.json','run-summary.json','eplusrs.ctf.log','eplusrs.eio','eplustbl.csv',
             'eplustbl.tab','eplustbl.txt','eplustbl.htm','eplustbl.xml','logs/source-input-statistics.json',
             'logs/source-predefined-table.json']:add(out/name)
comparison=BASE/'Reviewer-ordinary-predefined-table-byte-comparison-70-01/comparison.json'
c=json.loads(comparison.read_bytes());add(comparison)
assert c['all_selected_statuses']=={'EXACT_PROJECTED_REPORTED_BYTES':218,'UNPAIRED_LATE_NATIVE_WRITER':1}
for k in ['all_cell_ledger','Native_CSV','actual_Native_receipt','actual_Native_version_receipt','reviewer_Source']:
    add_ref(c[k])
for a in c['Original_authority']:add_ref(a['literal_excerpt'])
creview=BASE/'Root-predefined-table-comparison-70-review-03/review.json'
assert json.loads(creview.read_bytes())['accepted'];add(creview)
add(BASE/'review-predefined-table-comparison-Root-70-03.py')
prior=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-input-statistics-tabular-05/summary.json'
assert ref(prior)['sha256']=='a67277ec8bfe9c8d9f4605cb143698a5692cd862ac0f004cf6a6fdbc207b15bf'
PUBLIC.mkdir()
z=PUBLIC/'evidence.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for key,b in sorted(payload.items()):
        item=zipfile.ZipInfo(key,date_time=(2026,10,17,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(item,b)
with zipfile.ZipFile(z) as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(payload)
    for key,b in payload.items():assert archive.read(key)==b
summary=dict(schema='src06-canonical-weather-remaining-reports.v1',
    status='Weather statistics, Remaining and Rainfall report prefix integrated; actual held run stops at true WriteBEPSTable5230 entry',
    Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,
    prepared_selective_promotion=ref(prepared),independent_promotion_review=ref(review),
    changed_Rust_files=34,new_Rust_files=7,existing_Rust_files=27,compiler_inputs=4428,
    canonical_exclusions=['Pipeline whole-byte unchanged from base HEAD; held Source dispatch excluded.',
        'CtfRunOutputs exact STAT01 parent; readonly predefined snapshot excluded.',
        'Future binary64 diagnostics, generic table writers and BEPS packets excluded.'],
    canonical_inputs_exact_actual70=4426,actual_commands=m['Root70_actual_commands'],
    independent_Source_and_actual_peer=m['independent_Root70_peer'],canonical_existing_tests=ref(qpath),
    affected_existing_tests_passed=19,canonical_existing_tests_passed=27,test_stack_bytes=8388608,
    new_test_bodies=0,full_suite_rerun=False,evidence_archive=ref(z),
    archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for k,b in sorted(payload.items())],
    finite_predefined_report_comparison=ref(comparison),independent_byte_comparison_review=ref(creview),
    selected_report_entries=219,exact_projected_reported_bytes=218,unpaired_late_Native_writer=1,
    scope=['Native raw weather STAT bytes, real registry columns and actual same-session report owners are used.',
        'Actual held Source executes FillWeather5212, Remaining5213, Rainfall5214, unit reconciliation and style passes before BEPS5230.',
        'Source predefined table contains505 active entries. Selected219 positions287-505 independently recomputed:218 exact reported bytes.',
        'Remaining6974 writes a literal gross-floor-area placeholder; Native BEPS later appends its value. Position481 is an unpaired phase, not an equality claim.',
        'Five existing assertions in four test files now compare raw byte char entries; no added test bodies or expanded full-suite run.'],
    numeric_observation='Actual70 ESO/MTR/EIO remain whole-byte identical to69/67. Existing reported comparison retains3536/5280 unequal ESO parsed binary64 values and72 exact MTR values. No tolerance change or numerical PASS.',
    previous_checkpoint=ref(prior),remaining=['BEPS body and later actual report/close/endrun sequence.',
        'Completed Source exporter, genuine default dispatcher activation, raw numerical parity and remaining A/B domains.'],
    reconstruction='Git retains all34 canonical Sources. Compact archive binds complete proposals/diffs/compiler hash census, actual command/output observations and independent reviews. No new complete offline replay claim.',
    completed_Source_run_or_export=False,whole_Native_numeric_PASS=False,pipeline_activation=False,
    gate_changes=False,A='14/54',B='14/64',retained_whole_old_comparison=dict(mismatches=235456,required_unavailable_or_unpaired=2754),
    author_Source=ref(Path(__file__).resolve()))
s=PUBLIC/'summary.json';s.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
relative='evidence/SRC-06-canonical-weather-remaining-reports-06/summary.json'
paragraph='날씨 STAT 원시 바이트, 실제 보고 레지스트리와 동일 세션의 상태를 이용해 날씨·잔여·강우 보고 및 출력 형식 선택을 연결했습니다. 실제 진단 실행은 5212·5213·5214 순서를 거쳐 연간 에너지 요약표 WriteBEPSTable5230 진입 전 미구현 경계에서 exit6으로 끝납니다. 새로 도달한 표 항목 219개 중 218개는 동일 입력 Native 최종 보고서와 출력 바이트가 같고, 1개는 Native의 뒤 단계 덮어쓰기 전 자리표시자이므로 단계가 다른 미짝 항목입니다. 관련 기존 테스트 19개와 기본 실행 기존 테스트 27개가 원래 8MiB 설정에서 통과했으며 새 테스트와 전체 테스트 반복은 없습니다. 기본 파이프라인과 읽기 전용 진단 관측은 전환하지 않았습니다. ESO·MTR·EIO는 직전과 바이트까지 같아 기존 ESO 수치 차이가 남습니다. 전체 실행·수치 동등성·카드 완료를 뜻하지 않으며 A14/54·B14/64와 기존 전체 FAIL을 유지합니다.'
for name in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']:
    p=ROOT/'energyplus_porting_plan'/name;text=p.read_text(encoding='utf-8')
    assert 'canonical-weather-remaining-reports-06' not in text
    link='../'+relative if name.startswith('cards/') else relative
    p.write_text(text+'\n\n[날씨·잔여·강우 보고 단계 검증]('+link+'). '+paragraph+'\n',encoding='utf-8',newline='\n')
p=ROOT/'energyplus_porting_plan/plan.json';before=json.loads(p.read_bytes());after=json.loads(p.read_bytes())
task=next(t for t in after['tasks'] if t['id']=='SRC-06');key='canonical_weather_remaining_reports_06'
assert key not in task;task[key]=dict(path=s.relative_to(ROOT).as_posix(),sha256=ref(s)['sha256'],size_bytes=s.stat().st_size)
check=json.loads(json.dumps(after));del next(t for t in check['tasks'] if t['id']=='SRC-06')[key];assert check==before
p.write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(ref(s)));print(json.dumps(ref(z)));print('archive_entries',len(payload))

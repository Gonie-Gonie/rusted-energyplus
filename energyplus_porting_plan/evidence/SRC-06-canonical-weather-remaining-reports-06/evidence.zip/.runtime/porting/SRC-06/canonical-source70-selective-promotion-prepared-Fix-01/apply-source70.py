"""ROOT-ONLY explicit apply of prepared Source70 core; no tests or Git mutations."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
if sys.argv[1:]!=['--apply']:raise SystemExit('Prepared only. Root may run with explicit --apply after review.')
plan=json.loads((HERE/'manifest.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(r):
    p=ROOT/r['path'];b=p.read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];return b
def sourcepaths(root):
    ps=set((root/'crates').rglob('*.rs'))|set((root/'crates').rglob('Cargo.toml'))
    ps|={root/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (root/n).is_file()}
    return {p.relative_to(root).as_posix() for p in ps}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==plan['base_HEAD']
scope=json.loads(checked(plan['complete_compiler_Source_plan']))
before_paths={e['path'] for e in scope['files'] if not e['before_absent']}
assert sourcepaths(ROOT)==before_paths
for e in scope['files']:
    p=ROOT/e['path'];assert p.resolve().is_relative_to(ROOT.resolve())
    assert not p.exists() if e['before_absent'] else (p.is_file() and sha(p.read_bytes())==e['before_sha256'] and p.stat().st_size==e['before_bytes'])
for row in plan['files']:
    checked(row['before']);checked(row['proposed']);assert checked(row['literal_inverse'])==checked(row['before'])
for row in plan['files']:
    p=ROOT/row['canonical_path'];assert p.resolve().is_relative_to(ROOT.resolve());p.parent.mkdir(parents=True,exist_ok=True)
    temporary=p.with_name(p.name+'.source70-promotion-tmp');assert temporary.resolve().is_relative_to(ROOT.resolve()) and not temporary.exists()
    temporary.write_bytes(checked(row['proposed']));os.replace(temporary,p)
assert sourcepaths(ROOT)=={e['path'] for e in scope['files']}
for e in scope['files']:
    p=ROOT/e['path'];assert sha(p.read_bytes())==e['planned_sha256'] and p.stat().st_size==e['planned_bytes']
print(json.dumps({'applied_Source_paths':len(plan['files']),'new_Source':plan['new_Source_files'],'existing_Source':plan['existing_Source_files'],'canonical_pipeline_whole_unchanged':True,'predefined_snapshot_excluded':True,'tests_or_Git_mutations':False}))

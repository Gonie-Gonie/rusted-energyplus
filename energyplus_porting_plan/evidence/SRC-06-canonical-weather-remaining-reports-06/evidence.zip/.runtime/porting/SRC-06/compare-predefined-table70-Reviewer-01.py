"""Read-only byte projection of actual Source70 cells against final Native67 CSV."""
from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'Reviewer-ordinary-predefined-table-byte-comparison-70-01';assert not OUT.exists()
SOURCE=D/'through-primary-diagnostic-A-24H-Root-70/output/logs/source-predefined-table.json'
CSV=D/'native-installed-A-24H-Root-67/output/energyplustbl.csv'
SOURCE_RECEIPT=D/'ordinary-provider-assembly-Root-70/workspace/.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-70/receipt.json'
NATIVE_RECEIPT=D/'native-installed-A-24H-command-Root-67/receipt.json'
VERSION_RECEIPT=D/'native-installed-version-Root-67/receipt.json'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,v):return put(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
assert ref(SOURCE)['sha256']=='582a5658ab647432ce54417bab9659bddbe9f864ed38b5f988c64c065b64d03f'
assert ref(CSV)['sha256']=='f53d9677c158144dca4f35b08cd69c9666c205b1a8e86dc4bfec98940b17c99b'
assert ref(NATIVE_RECEIPT)['sha256']=='66dce9a44c5aa366719a44dec194656aeac174e88f17b05599c4248abd2b20b4'
assert ref(VERSION_RECEIPT)['sha256']=='caf4530dbb186fed594184cc880172aaee5084351c98629fda6f3bfe315a7191'
sr=json.loads(SOURCE_RECEIPT.read_bytes());nr=json.loads(NATIVE_RECEIPT.read_bytes());assert sr['exit_code']==6 and nr['exit_code']==0 and sr['source_bytes_match_before_and_after'] and nr['source_bytes_match_before_and_after']
sc=sr['command'][sr['command'].index('--')+1:];nc=nr['command'];assert sc[0]=='run'
idf=Path(sc[1]);native_idf=Path(nc[-1]);weather=Path(sc[sc.index('--weather')+1]);native_weather=Path(nc[nc.index('--weather')+1])
assert idf.resolve()==native_idf.resolve() and weather.resolve()==native_weather.resolve()
idfbytes=idf.read_bytes();assert len(idfbytes)==9275 and hashlib.sha256(idfbytes).hexdigest().startswith('db66ac')
git_idf=[]
for revision in [nr['repository_before']['head'],sr['repository_before']['head']]:
 q=subprocess.run(['git','show',f'{revision}:{idf.relative_to(ROOT).as_posix()}'],cwd=ROOT,capture_output=True);assert q.returncode==0 and q.stdout==idfbytes
 git_idf.append(dict(revision=revision,exit_code=0,stdout=put('Git/IDF-'+revision[:12]+'.stdout',q.stdout),stderr=put('Git/IDF-'+revision[:12]+'.stderr',q.stderr)))
assert len(weather.read_bytes())==1623506 and ref(weather)['sha256'].startswith('c184')

data=json.loads(SOURCE.read_bytes());reg=data['registry'];active_count=data['table']['num_table_entry'];allocated=data['table']['allocated_rows_in_original_order']
assert active_count==505 and len(allocated)==data['table']['size_table_entry']==800
rows=allocated[:active_count];columns=reg['allocated_columns_in_original_order'];subtables=reg['allocated_subtables_in_original_order'];reports=reg['allocated_reports_in_original_order']
def cell_context(row):
 column=columns[row['index_column']-1];subtable=subtables[column['subtable_index']-1];report=reports[subtable['report_index']-1]
 labels=[report['name_with_spaces'],subtable['name'],row['object_name'],column['heading_including_units']]
 return tuple(s.encode('utf8') for s in labels),labels,report['show']
source_keys=defaultdict(list)
for row in rows:
 key,_,_=cell_context(row);source_keys[key].append(row['source_index_one_based'])
source_duplicate_keys=[dict(cell_key_hex=[x.hex() for x in k],source_positions=v) for k,v in source_keys.items() if len(v)>1]
col_keys=Counter((subtables[c['subtable_index']-1]['report_index'],c['subtable_index'],c['heading_including_units'].encode('utf8')) for c in columns if c['heading_including_units'])

# Native writes these CSV lines without quoting. Decode no Native character data.
raw=CSV.read_bytes();assert raw.endswith(b'\r\n') and b'\n' not in raw.replace(b'\r\n',b'')
lines=raw.split(b'\r\n');boundaries=[i for i,line in enumerate(lines) if line.startswith(b'REPORT:,')]+[len(lines)]
report_blocks=defaultdict(list)
for start,end in zip(boundaries,boundaries[1:]):report_blocks[lines[start][8:]].append((start,end))
table_cache={};structural_notices=[]
def native_tables(report,subtable):
 key=(report,subtable)
 if key in table_cache:return table_cache[key]
 result=[]
 for first,last in report_blocks[report]:
  for i in range(first,last):
   if lines[i]!=subtable:continue
   j=i+1
   while j<last and lines[j]==b'':j+=1
   if j>=last or not lines[j].startswith(b',,'):continue
   headings=lines[j][2:].split(b',');body=[];k=j+1
   while k<last and lines[k]!=b'':
    line=lines[k]
    if line.startswith(b',') and not line.startswith(b',,'):
     # A one-value row retains EVERYTHING after the object delimiter, including
     # the unquoted comma in the Koppen Description; no CSV quoting semantics.
     parts=line.split(b',',2) if len(headings)==1 else line.split(b',')
     if len(parts)==len(headings)+2:body.append(dict(object=parts[1],values=parts[2:],line=k+1,raw=line))
     else:structural_notices.append(dict(report_hex=report.hex(),subtable_hex=subtable.hex(),line=k+1,raw_line_hex=line.hex(),reason='Unquoted multi-column width is ambiguous; no truncation or normalization.'))
    k+=1
   result.append(dict(headings=headings,body=body,heading_line=j+1))
 table_cache[key]=result;return result

late_key=tuple(x.encode('utf8') for x in ['LEED Summary','Sec1.1A-General Information','Total gross floor area [m2]','Data'])
ledger=[]
for row in rows[286:505]:
 index=row['source_index_one_based'];assert 287<=index<=505
 key,labels,shown=cell_context(row);source=bytes.fromhex(row['char_entry_hex']);assert len(source)==row['char_entry_byte_count']
 # ObjexxFCL::stripped(string_view): ONLY ASCII space, never general whitespace.
 projected=source.strip(b' ')
 assert b'~~$~~' not in b''.join(key)+source
 group='rainfall' if index>=482 else ('remaining' if index>=326 else ('weather_statistics' if labels[1]=='Weather Statistics File' else 'weather_LEED_companion'))
 candidates=[]
 for table in native_tables(key[0],key[1]):
  for column_index,heading in enumerate(table['headings']):
   if heading!=key[3]:continue
   for native_row in table['body']:
    if native_row['object']==key[2]:
     candidates.append(dict(native_line=native_row['line'],native_heading_line=table['heading_line'],native_column_zero_based=column_index,value_hex=native_row['values'][column_index].hex(),raw_line_hex=native_row['raw'].hex(),single_value_rest_join=len(table['headings'])==1))
 status='EXACT_PROJECTED_REPORTED_BYTES';reason=None
 if not shown:status='UNPAIRED_HIDDEN_SOURCE_REPORT';reason='Source retained show=false; do not treat a hidden cell as emitted.'
 elif len(source_keys[key])!=1:status='UNPAIRED_DUPLICATE_SOURCE_CELL_WRITERS';reason='More than one actual Source active table entry maps to this reported cell.'
 elif b',' in key[2] or b',' in key[3] or b'|' in key[3]:status='UNPAIRED_LABEL_DELIMITER_OR_MULTILINE';reason='Native unquoted/multirow labels need additional exact authority.'
 elif len(candidates)!=1:status='UNPAIRED_NATIVE_FINAL_CELL_CARDINALITY';reason='Native exact report/subtable/object/column has zero or multiple candidates.'
 elif key==late_key:status='UNPAIRED_LATE_NATIVE_WRITER';reason='Remaining6974 writes the literal placeholder; later BEPS8535-8539 appends the same LEED cell before WritePredefinedTables. Actual Source70 stops at BEPS5230 entry, so final Native value is a later phase.'
 elif bytes.fromhex(candidates[0]['value_hex'])!=projected:status='PROJECTED_REPORTED_BYTE_MISMATCH';reason='Unique comparable reported cell bytes differ; no float tolerance/decoding/case normalization.'
 row_record=dict(source_position=index,group=group,primary_requested_scope=group!='weather_LEED_companion',cell_labels_Source_UTF8=labels,cell_key_hex=[x.hex() for x in key],Source_report_shown=shown,Source_writer_positions=source_keys[key],source_char_entry_hex=source.hex(),source_ASCII_space_stripped_hex=projected.hex(),Native_candidates=candidates,status=status,reason=reason)
 if len(candidates)==1:row_record['raw_projected_bytes_equal']=projected==bytes.fromhex(candidates[0]['value_hex'])
 ledger.append(row_record)
assert len(ledger)==219 and [r['source_position'] for r in ledger]==list(range(287,506))
primary=[r for r in ledger if r['primary_requested_scope']];findings=[r for r in ledger if r['status']!='EXACT_PROJECTED_REPORTED_BYTES']
groups={group:dict(entries=sum(r['group']==group for r in ledger),statuses=dict(Counter(r['status'] for r in ledger if r['group']==group))) for group in sorted({r['group'] for r in ledger})}

NATIVE=ROOT/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048';authority=[]
for path,first,last,purpose in [
 ('src/EnergyPlus/OutputReportTabular.cc',17565,17585,'Unquoted comma projection uses stripped headings/body, literal row labels'),
 ('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.cc',261,277,'stripped(string_view) strips ONLY ASCII spaces from both tails'),
 ('src/EnergyPlus/OutputReportTabular.cc',13986,14029,'Actual active entry/subtable association, exact object names and show guard'),
 ('src/EnergyPlus/OutputReportTabular.cc',14104,14166,'Sequential cell assignments: repeated Native writer entries can replace final body cell; SI formatted path retains charEntry'),
 ('src/EnergyPlus/OutputReportTabular.cc',6968,6976,'Remaining literal total gross floor area placeholder'),
 ('src/EnergyPlus/OutputReportTabular.cc',8522,8542,'Later WriteBEPSTable same LEED gross area PreDefTableEntry'),
 ('src/EnergyPlus/OutputReportTabular.cc',5210,5268,'FillWeather/Remaining/Rainfall precede BEPS; WritePredefinedTables follows later report children'),
 ('src/EnergyPlus/OutputReportPredefined.cc',1837,1875,'String PreDefTableEntry adds a new retained entry, not a unique-key dictionary overwrite'),
 ('src/EnergyPlus/OutputReportPredefined.cc',1955,1976,'Increment table entry allocation and append order'),
 ('src/EnergyPlus/OutputReportTabular.cc',17869,17915,'Currency token handling; selected cells contain no currency replacement token'),
]:
 p=NATIVE/path;b=p.read_bytes();ls=b.splitlines(keepends=True);assert 1<=first<=last<=len(ls)
 q=subprocess.run(['git','show',f'{PIN}:{path}'],cwd=NATIVE,capture_output=True);assert q.returncode==0 and q.stdout==b
 authority.append(dict(source=ref(p),first_line=first,last_line=last,literal_excerpt=put(f'Original/{p.name}-{first}-{last}.txt',b''.join(ls[first-1:last])),strict_EOF=True,pinned_whole_equal=True,purpose=purpose))
lr=meta('all-cell-ledger.json',ledger)
result=dict(schema='src06-actual70-predefined-projected-bytes-vs-final-installedNative67.v1',status='FINITE_REPORTED_BYTE_OBSERVATIONS_ONLY_NO_NUMERICAL_GATE',Source_snapshot=ref(SOURCE),Native_CSV=ref(CSV),actual_Source_receipt=ref(SOURCE_RECEIPT),actual_Native_receipt=ref(NATIVE_RECEIPT),actual_Native_version_receipt=ref(VERSION_RECEIPT),input_identity=dict(original_IDF=ref(idf),same_both_command_input_path=True,read_only_actual_Git_IDF_at_both_revisions=git_idf,weather=ref(weather),same_both_command_weather_path=True,weather_qualification='Current bytes match parent-announced c184/1623506 identity; no Native binary was reread or run by this reviewer.'),Source_active_entries=active_count,Source_allocated_rows=len(allocated),selected_positions=[287,505],all_selected_entries=len(ledger),primary_requested_entries=len(primary),all_selected_statuses=dict(Counter(r['status'] for r in ledger)),primary_requested_statuses=dict(Counter(r['status'] for r in primary)),groups=groups,Source_duplicate_cell_keys=source_duplicate_keys,Native_parser_structural_notices=structural_notices,all_uncapped_findings=findings,all_cell_ledger=lr,Original_commit=PIN,Original_authority=authority,method=['Source JSON is decoded as its actual UTF8 encoding; Source object/report/subtable/column names are encoded to UTF8 bytes exactly. Native CSV is never decoded as generic UTF8 or replacement text.','Match only exact report/subtable/object/column bytes. Do not trim/case-fold row labels or repair Unicode.','Project Source charEntry with ONLY strip(byte0x20), as actual ObjexxFCL stripped; do not strip tabs/other whitespace or parse floats.','Native CSV uses literal unquoted commas. For single-column Weather/LEED tables everything after the object delimiter remains the one value, including Koppen Description comma and raw B0. Multicolumn widths are exact, never truncated.','Source duplicate active writers, hidden reports, ambiguous Native cell cardinality and known late Native writers are explicit unpaired domains. Final CSV uniqueness does not prove unique Native internal writer history.','35 Weather Statistics cells+156 Remaining+24 Rainfall are the requested215 cells. Four weather-batch LEED companion cells are also fully listed and compared separately, giving219 total uncapped records.'],limits=['These are projected reported bytes from Source70 retained charEntry cells, not an actual completed Source CSV body (Source70 stops before WriteBEPSTable).','No Native internal binary64 values are available from CSV; originalRealEntry is not compared with parsed Native decimals. No float tolerance or NumericGate exists in this comparison.','One raw byte difference is intentionally unpaired by phase: Remaining481 placeholder versus later Native BEPS same-cell value. It is retained uncapped with both bytes and Native line.','No whole Weather Statistics/Remaining/Rainfall internal-state or full-run/endrun/exporter equivalence is certified; earlier Source/Native ESO binary64 differences remain unchanged.'],reviewer_Source=ref(Path(__file__)),Source_changes=False,Cargo_Native_tests_or_Git_mutations=False,new_test_bodies=0)
v=meta('comparison.json',result);print(json.dumps(v));print(json.dumps(dict(groups=groups,statuses=result['all_selected_statuses'],finding_count=len(findings))))

"""Correct one supplemental diff's filename label without rewriting history or Rust."""
from pathlib import Path
import difflib
import hashlib
import json

root=Path.cwd();base=root/'.runtime/porting/SRC-06'
parent_path=base/'ordinary-output-prescan-assembly-01/manifest.json'
final_path=base/'ordinary-output-prescan-assembly-02/manifest.json'
parent=json.loads(parent_path.read_bytes());final=json.loads(final_path.read_bytes())
out=base/'ordinary-output-prescan-diff-label-qualification-01'
assert not out.exists()
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
name='crates/ep_run/src/ordinary_input_processor/reporting_prescan.rs'
old_row=next(row for row in parent['files']if row['canonical']['path']==name)
new_row=next(row for row in final['files']if row['canonical']['path']==name)
before=(root/old_row['after']['path']).read_bytes();after=(root/new_row['after']['path']).read_bytes()
assert ref(root/name)==new_row['canonical']
assert after.replace(b'pub(crate) fn resolve(',b'pub(super) fn resolve(')==before
correct=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='assembly01/'+name,tofile='assembly02/'+name)).encode()
historical=base/'ordinary-output-prescan-assembly-02/visibility.parent.diff'
assert historical.read_bytes().splitlines(keepends=True)[2:]==correct.splitlines(keepends=True)[2:]
out.mkdir();diff=out/'visibility.parent.correct-label.diff';diff.write_bytes(correct)
(out/'qualification.json').write_bytes((json.dumps({'schema':'src06-supplemental-diff-label-qualification.v1','historical':ref(historical),'correctly_labelled_diff':ref(diff),'author':ref(Path(__file__)),'whole_byte_inverse_exact':True,'qualification':'Assembly02 supplemental visibility.parent.diff used the loop-final test filename in its two headers. Its complete hunk is the correct raw bridge visibility edit, as are all seven direct diffs. This supplemental artifact corrects only those headers. Canonical Rust and actual QA Source are unchanged; history is preserved.'},indent=2)+'\n').encode())
print(json.dumps({'qualification':ref(out/'qualification.json')}))

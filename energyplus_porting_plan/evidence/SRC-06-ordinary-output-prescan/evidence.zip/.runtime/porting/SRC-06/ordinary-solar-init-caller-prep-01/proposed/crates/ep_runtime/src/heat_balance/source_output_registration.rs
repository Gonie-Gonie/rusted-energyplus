//! Reached OutputProcessor registration storage; no hourly registry substitutes for it.
//! Original OutputProcessor.cc139-193,281-346,421-548,3003-3144,4827-4919.

use super::radiation::ordinary::{OrdinaryRadiationError, OrdinaryRadiationUnavailable};
use crate::error::WarmupOutputError;
use ep_model::ReportInputs;
use std::collections::BTreeMap;
mod meters;
mod integer;
pub(crate) use meters::{SourceExteriorEnergyDeclaration, SourceMeter};

/// Actual output file/system host, supplied by the real Setup route.
pub(crate) trait SourceOutputFileHost {
    fn ensure_mtd_open(&mut self) -> std::io::Result<()>;
    fn minimum_report_frequency(&self) -> &str;
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum SourceOutputUnits { None, W, J, Deg, M2, WPerM2, Rad }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum SourceOutputStoreType { Average, Sum }
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) enum SourceReportFrequency { EachCall, TimeStep, Hour, Day, Month, Simulation, Year }

/// A real variable's stable join to its sole mutable calculation owner.
/// Unrequested/unmetered registrations never retain this join in an OutVar.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum SourceRealVariable {
    ExteriorLightPower { index: usize },
    ExteriorLightConsumption { index: usize },
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SourceRealOutputVariable {
    pub(crate) dd_var_num: usize,
    pub(crate) units: SourceOutputUnits,
    pub(crate) store_type: SourceOutputStoreType,
    pub(crate) value: f64,
    pub(crate) ts_value: f64,
    pub(crate) ei_ts_value: f64,
    pub(crate) store_value: f64,
    pub(crate) num_stored: f64,
    pub(crate) stored: bool,
    pub(crate) report: bool,
    pub(crate) ts_stored: bool,
    pub(crate) this_ts_stored: bool,
    pub(crate) this_ts_count: i32,
    pub(crate) frequency: SourceReportFrequency,
    pub(crate) max_value: f64,
    pub(crate) min_value: f64,
    pub(crate) max_value_date: i32,
    pub(crate) min_value_date: i32,
    pub(crate) report_id: i32,
    pub(crate) zone_multiplier: i32,
    pub(crate) zone_list_multiplier: i32,
    pub(crate) name: String,
    pub(crate) name_upper: String,
    pub(crate) key: String,
    pub(crate) key_upper: String,
    pub(crate) key_colon_name: String,
    pub(crate) key_colon_name_upper: String,
    pub(crate) index_group: String,
    pub(crate) index_group_key: i32,
    pub(crate) meter_nums: Vec<usize>,
    pub(crate) which: SourceRealVariable,
}

impl SourceRealOutputVariable {
    /// The selected Zone/Real constructor then SetupOutputVariable assignments.
    pub(crate) fn zone_real(
        declaration: SourceRealOutputDeclaration<'_>, dd_var_num: usize,
        report_id: i32, which: SourceRealVariable,
    ) -> Self {
        let key_colon_name = format!("{}:{}", declaration.key, declaration.name);
        Self {
            dd_var_num, units: declaration.units, store_type: declaration.store_type,
            value: 0.0, ts_value: 0.0, ei_ts_value: 0.0, store_value: 0.0,
            num_stored: 0.0, stored: false, report: false, ts_stored: false,
            this_ts_stored: false, this_ts_count: 0, frequency: SourceReportFrequency::Hour,
            max_value: -9999.0, min_value: 9999.0, max_value_date: 0, min_value_date: 0,
            report_id, zone_multiplier: 1, zone_list_multiplier: 1,
            name: declaration.name.into(), name_upper: declaration.name.to_ascii_uppercase(),
            key: declaration.key.into(), key_upper: declaration.key.to_ascii_uppercase(),
            key_colon_name_upper: key_colon_name.to_ascii_uppercase(), key_colon_name,
            index_group: "Zone".into(), index_group_key: -999, meter_nums: Vec::new(), which,
        }
    }
}

#[derive(Clone, Copy)]
pub(crate) struct SourceRealOutputDeclaration<'a> {
    pub(crate) name: &'a str,
    pub(crate) key: &'a str,
    pub(crate) units: SourceOutputUnits,
    pub(crate) store_type: SourceOutputStoreType,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct SourceDictionaryVariable {
    pub(crate) integer: bool,
    pub(crate) name: String,
    pub(crate) units: SourceOutputUnits,
    pub(crate) store_type: SourceOutputStoreType,
    pub(crate) next: Option<usize>,
    pub(crate) reported_on_dictionary_file: bool,
    pub(crate) key_out_var_nums: Vec<usize>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct SourceRequestedVariable {
    pub(crate) key: String,
    pub(crate) name: String,
    pub(crate) frequency: SourceReportFrequency,
    pub(crate) used: bool,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct SourceEndUseCategory {
    pub(crate) name: String,
    pub(crate) display_name: String,
    pub(crate) num_subcategories: i32,
    pub(crate) subcategory_names: Option<Vec<String>>,
    pub(crate) num_space_types: i32,
    pub(crate) space_type_names: Option<Vec<String>>,
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SourceOutputRegistration {
    pub(crate) output_initialized: bool,
    pub(crate) get_output_input: bool,
    pub(crate) time_step_zone_sec: f64,
    pub(crate) end_use_categories: Option<Vec<SourceEndUseCategory>>,
    pub(crate) requested_variables: Vec<SourceRequestedVariable>,
    pub(crate) dictionary_variables: Vec<SourceDictionaryVariable>,
    dictionary_by_name: BTreeMap<String, usize>,
    pub(crate) num_total_real_variables: i32,
    pub(crate) num_real_variables: i32,
    pub(crate) num_real_variables_setup: i32,
    pub(crate) num_total_integer_variables: i32,
    pub(crate) num_integer_variables_setup: i32,
    pub(crate) num_integer_variables: i32,
    pub(crate) num_integer_variables_sum: i32,
    pub(crate) num_real_variables_sum: i32,
    pub(crate) num_real_variables_meter: i32,
    pub(crate) report_number_counter: i32,
    pub(crate) out_vars: Vec<SourceRealOutputVariable>,
    pub(crate) meters: Vec<SourceMeter>,
    pub(crate) meter_map: BTreeMap<String, usize>,
    pub(crate) max_num_subcategories: i32,
}
impl Default for SourceOutputRegistration {
    fn default() -> Self {
        Self {
            output_initialized: false, get_output_input: true, time_step_zone_sec: 0.0,
            end_use_categories: None, requested_variables: Vec::new(),
            dictionary_variables: Vec::new(), dictionary_by_name: BTreeMap::new(),
            num_total_real_variables: 0, num_real_variables: 0, num_real_variables_setup: 0,
            num_total_integer_variables: 0, num_integer_variables_setup: 0,
            num_integer_variables: 0, num_integer_variables_sum: 0,
            num_real_variables_sum: 0, num_real_variables_meter: 0,
            report_number_counter: 0, out_vars: Vec::new(), meters: Vec::new(),
            meter_map: BTreeMap::new(), max_num_subcategories: 1,
        }
    }
}

pub(crate) struct SourceRealRegistrationPrefix {
    pub(crate) dd_var_num: usize,
    pub(crate) request_indexes: Vec<usize>,
    pub(crate) this_one_on_the_list: bool,
}

fn selected_frequency(text: &str) -> Result<SourceReportFrequency, OrdinaryRadiationError> {
    use SourceReportFrequency as F;
    Ok(match text.to_ascii_uppercase().as_str() {
        "DETAILED" => F::EachCall, "TIMESTEP" => F::TimeStep, "HOURLY" => F::Hour,
        "DAILY" => F::Day, "MONTHLY" => F::Month, "RUNPERIOD" | "ENVIRONMENT" => F::Simulation,
        "ANNUAL" => F::Year,
        // determineFrequency defaults Hour for fewer than four characters.
        value if value.len() < 4 => F::Hour,
        _ => return Err(OrdinaryRadiationUnavailable::InputBranch.into()),
    })
}
fn is_regex(key: &str) -> bool { key != "*" && key.chars().any(|ch| "*+?()|[]\\.".contains(ch)) }
fn variable_name(name: &str) -> &str {
    name.split('[').next().unwrap_or(name)
        .trim_end_matches(|ch| matches!(ch, ' ' | '\u{000c}' | '\n' | '\r' | '\t' | '\u{000b}'))
}

impl SourceOutputRegistration {
    fn initialize_output(
        &mut self, minutes_in_time_step: i32, host: &mut impl SourceOutputFileHost,
    ) -> Result<(), OrdinaryRadiationError> {
        const NAMES: [&str; 14] = ["Heating", "Cooling", "InteriorLights", "ExteriorLights",
            "InteriorEquipment", "ExteriorEquipment", "Fans", "Pumps", "HeatRejection",
            "Humidifier", "HeatRecovery", "WaterSystems", "Refrigeration", "Cogeneration"];
        const DISPLAY: [&str; 14] = ["Heating", "Cooling", "Interior Lighting", "Exterior Lighting",
            "Interior Equipment", "Exterior Equipment", "Fans", "Pumps", "Heat Rejection",
            "Humidification", "Heat Recovery", "Water Systems", "Refrigeration", "Generators"];
        self.end_use_categories = Some(NAMES.iter().zip(DISPLAY).map(|(&name, display)|
            SourceEndUseCategory { name: name.into(), display_name: display.into(), ..Default::default() }).collect());
        self.output_initialized = true;
        self.time_step_zone_sec = f64::from(minutes_in_time_step) * 60.0;
        host.ensure_mtd_open().map_err(|error| OrdinaryRadiationError::Output(WarmupOutputError::Io(error)))
    }

    fn get_report_variable_input(
        &mut self, input: &ReportInputs, host: &impl SourceOutputFileHost,
        eio: &mut dyn std::io::Write,
    ) -> Result<(), OrdinaryRadiationError> {
        if !self.get_output_input { return Ok(()); }
        self.get_output_input = false;
        let minimum = if host.minimum_report_frequency().is_empty() {
            SourceReportFrequency::EachCall
        } else {
            let actual = selected_frequency(host.minimum_report_frequency())?;
            const NOTICES: [&str; 7] = ["Detailed", "Timestep", "Hourly", "Daily", "Monthly", "RunPeriod", "Annual"];
            writeln!(eio, "! <Minimum Reporting Frequency (overriding input value)>, Value, Input Value")
                .map_err(|error| OrdinaryRadiationError::Output(WarmupOutputError::Io(error)))?;
            writeln!(eio, " Minimum Reporting Frequency, {},{}", NOTICES[actual as usize], host.minimum_report_frequency())
                .map_err(|error| OrdinaryRadiationError::Output(WarmupOutputError::Io(error)))?;
            actual
        };
        for object in &input.output_variables {
            if is_regex(&object.key) || !object.schedule_name.is_empty() {
                return Err(OrdinaryRadiationUnavailable::InputBranch.into());
            }
            self.requested_variables.push(SourceRequestedVariable {
                key: if object.key == "*" { String::new() } else { object.key.clone() },
                name: variable_name(&object.variable_name).into(),
                frequency: selected_frequency(&object.reporting_frequency)?.max(minimum), used: false,
            });
        }
        Ok(())
    }

    fn add_dictionary_variable(&mut self, declaration: SourceRealOutputDeclaration<'_>) -> usize {
        self.add_typed_dictionary_variable(declaration, false)
    }
    fn add_typed_dictionary_variable(&mut self, declaration: SourceRealOutputDeclaration<'_>, integer: bool) -> usize {
        let name_upper = declaration.name.to_ascii_uppercase();
        if let Some(&first) = self.dictionary_by_name.get(&name_upper) {
            let mut index = first;
            loop {
                if self.dictionary_variables[index].units == declaration.units { return index; }
                match self.dictionary_variables[index].next {
                    Some(next) => index = next,
                    None => {
                        self.dictionary_variables[index].next = Some(self.dictionary_variables.len());
                        break;
                    }
                }
            }
        } else { self.dictionary_by_name.insert(name_upper, self.dictionary_variables.len()); }
        let index = self.dictionary_variables.len();
        self.dictionary_variables.push(SourceDictionaryVariable { integer,
            name: declaration.name.into(), units: declaration.units, store_type: declaration.store_type,
            next: None, reported_on_dictionary_file: false, key_out_var_nums: Vec::new(),
        });
        index
    }

    pub(crate) fn prepare_real_registration(
        &mut self, input: &ReportInputs, declaration: SourceRealOutputDeclaration<'_>,
        minutes_in_time_step: i32, host: &mut impl SourceOutputFileHost,
        eio: &mut dyn std::io::Write,
    ) -> Result<SourceRealRegistrationPrefix, OrdinaryRadiationError> {
        if !self.output_initialized { self.initialize_output(minutes_in_time_step, host)?; }
        self.get_report_variable_input(input, host, eio)?;
        let mut request_indexes: Vec<usize> = Vec::new();
        for index in 0..self.requested_variables.len() {
            let request = &mut self.requested_variables[index];
            if !request.name.eq_ignore_ascii_case(declaration.name)
                || !(request.key.is_empty() || request.key.eq_ignore_ascii_case(declaration.key)) { continue; }
            request.used = true;
            let frequency = request.frequency;
            if !request_indexes.iter().any(|&prior| self.requested_variables[prior].frequency == frequency) {
                request_indexes.push(index);
            }
        }
        let this_one_on_the_list = input.output_variables.iter().any(|request|
            variable_name(&request.variable_name).eq_ignore_ascii_case(declaration.name)
            && (request.key == "*" || request.key.eq_ignore_ascii_case(declaration.key)));
        let dd_var_num = self.add_dictionary_variable(declaration);
        self.num_real_variables_setup = self.num_real_variables_setup.checked_add(1)
            .ok_or(OrdinaryRadiationUnavailable::StorageDomain)?;
        self.num_total_real_variables = self.num_total_real_variables.checked_add(
            i32::try_from(request_indexes.len().max(1)).map_err(|_| OrdinaryRadiationUnavailable::StorageDomain)?
        ).ok_or(OrdinaryRadiationUnavailable::StorageDomain)?;
        Ok(SourceRealRegistrationPrefix { dd_var_num, request_indexes, this_one_on_the_list })
    }

    /// Literal no-meter return: dictionary/setup/total writes still occur.
    pub(crate) fn setup_unmetered_zone_real(
        &mut self, input: &ReportInputs, declaration: SourceRealOutputDeclaration<'_>,
        minutes_in_time_step: i32, host: &mut impl SourceOutputFileHost,
        eio: &mut dyn std::io::Write,
    ) -> Result<(), OrdinaryRadiationError> {
        let prefix = self.prepare_real_registration(input, declaration, minutes_in_time_step, host, eio)?;
        if prefix.this_one_on_the_list {
            // Actual OutVar/report-dictionary writer needs its own consumed port.
            return Err(OrdinaryRadiationUnavailable::InputBranch.into());
        }
        Ok(())
    }
}

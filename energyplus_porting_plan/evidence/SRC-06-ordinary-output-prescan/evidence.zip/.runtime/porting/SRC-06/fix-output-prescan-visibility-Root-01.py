"""Correct the actual crate-visible raw bridge; retain prior failed QA bytes."""
from pathlib import Path
import difflib
import hashlib
import json

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
parent_path = base / 'ordinary-output-prescan-assembly-01/manifest.json'
parent = json.loads(parent_path.read_bytes())
out = base / 'ordinary-output-prescan-assembly-02'
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}

assert ref(parent_path)['sha256'] == '7851721b4793474b2227041faab8369bf8f8b043c007992e8f58bac64d73f8f9'
for row in parent['files']:
    assert ref(root / row['canonical']['path']) == row['canonical']
name = 'crates/ep_run/src/ordinary_input_processor/reporting_prescan.rs'
path = root / name
before = path.read_bytes()
old, new = b'pub(super) fn resolve(', b'pub(crate) fn resolve('
assert before.count(old) == 1
after = before.replace(old,new)
assert after.replace(new,old) == before
path.write_bytes(after)
out.mkdir()
files=[]
for index,row in enumerate(parent['files']):
    name=row['canonical']['path']; original=(root/row['before']['path']).read_bytes(); final=(root/name).read_bytes()
    if name != str(path.relative_to(root)).replace('\\','/'):
        assert ref(root/name) == row['canonical']
    after_path=out/f'{index:02}.after';after_path.write_bytes(final)
    diff_path=out/f'{index:02}.diff'
    diff_path.write_bytes(''.join(difflib.unified_diff(original.decode().splitlines(True),final.decode().splitlines(True),fromfile='HEAD/'+name,tofile=name)).encode())
    files.append({**row,'canonical':ref(root/name),'after':ref(after_path),'complete_diff':ref(diff_path)})
delta=out/'visibility.parent.diff'
delta.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='assembly01/'+name,tofile='assembly02/'+name)).encode())
manifest={**parent,'files':files,'parent':ref(parent_path),'visibility_fix':{'complete_parent_diff':ref(delta),'whole_byte_inverse_exact':True,'other_six_complete_files_unchanged':True,'reason':'Actual Rust E0364/E0603: child pub(super) function cannot be re-exported pub(crate). Only its visibility changes; behavior/LOC/test inputs unchanged.'},'authors':parent['authors']+[ref(Path(__file__))]}
(out/'manifest.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'manifest':ref(out/'manifest.json'),'visibility_only':True}))

# Exact output matching boundaries

| Boundary | Actual rule |
|---|---|
| IP addRecord | First bracket ends name; trim trailing ASCII space only, always |
| OP GetReportVariableInput | If bracket exists, erase suffix and trim six ASCII whitespace; otherwise untouched |
| DataOutputs maps | Case-insensitive variable/key emplace; preserve first spelling/value; every attempt increments NumConsidered |
| FindItem | No incoming-name trim/parse; variable lookup then key/wildcard; regex outside selected domain |
| AllSummary | Uppercase then no matching monthly branch, so adds zero |
| AllMonthly/AllSummaryAndMonthly | Expand63 actual names, outside current selected admission |
| Repeated preScan | Max=10000; no clear, counter reset or once guard |

Source-derived cases for an existing test table: no-bracket `Name   ` becomes IP
`Name` but OP retains spaces; no-bracket trailing tab is retained by OP and by IP
after only spaces are trimmed; `Name \t[W]` becomes IP `Name \t`, OP `Name`.
`Name[W]tail` ends at the first bracket. NBSP and leading whitespace are retained.
Generic Unicode trim/casefold is not the Source operation.

The old HELD registration helper unconditionally trims six whitespace characters;
it cannot serve both functions. The new canonical preScan uses its separate
correct operation. A later registration successor must borrow the same retained
DataOutputs owner for ThisOneOnList, not recompute ReportInputs.

The extended existing verify_shared_input_boundary body covers raw lexical order,
mixed case, first spelling, wildcard, empty fallback, whitespace key, retained
tab, unnormalized lookup, duplicate/repeat count, AllSummary zero additions,
scratch retention, unchanged unusedInputs and regex failure prefix. No new body
or binary is needed. Future registration correction should extend an existing
table with no-bracket and bracket cases; no parallel test framework is needed.

Scope: selected ASCII/literal-key lookup. General signed-char8bit map iteration,
Unicode semantics, RE2/API, positive monthly/custom/EMS/preprocessor branches,
full startup/Setup and numerical parity are not claimed. SRC06 gates unchanged.

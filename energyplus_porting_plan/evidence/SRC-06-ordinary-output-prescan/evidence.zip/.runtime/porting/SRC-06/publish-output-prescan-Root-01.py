"""Publish finite actual pre-scan evidence, preserving failed QA and exact Source scope."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root=Path.cwd();base=root/'.runtime/porting/SRC-06'
out=root/'energyplus_porting_plan/evidence/SRC-06-ordinary-output-prescan'
assert not out.exists()
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path):return json.loads(path.read_bytes())
def write(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256'in value:yield value
        else:
            for child in value.values():yield from walk(child)
    elif isinstance(value,list):
        for child in value:yield from walk(child)
assembly_path=base/'ordinary-output-prescan-assembly-02/manifest.json'
parent_path=base/'ordinary-output-prescan-assembly-01/manifest.json'
review_path=base/'Owner-ordinary-output-prescan-Source-review-01/review.json'
qualification_path=base/'ordinary-output-prescan-diff-label-qualification-01/qualification.json'
assert ref(assembly_path)['sha256']=='c3508f56c775e10468f1dd33c9b36d84cb7219a7b029b84facf4fea020734cff'
assert ref(review_path)['sha256']=='83eb1fa9e23c4a31659e9ec58d8b3c737144012fc4f580c9e682c6ec5b5e8c04'
assembly=load(assembly_path);parent=load(parent_path);review=load(review_path)
assert review.get('accepted')is True
archives={row[key]['sha256']:root/row[key]['path']for m in [parent,assembly]for row in m['files']for key in ['before','after']}
artifacts={};historical=[]
def add(path):
    row=ref(path);artifacts[row['path']]=row;return row
def checked(row):
    path=root/row['path']
    if not path.is_file()or ref(path)['sha256']!=row['sha256']:
        path=archives[row['sha256']]
        historical.append({'historical_reference':row,'exact_archive':ref(path),'qualification':'Exact assembly01 raw bridge before crate-visibility correction; history and failed QA retained.'})
    actual=ref(path)
    assert actual['sha256']==row['sha256']and actual['size_bytes']==row.get('size_bytes',actual['size_bytes'])
    return path
for path in [assembly_path,parent_path,review_path,qualification_path]:
    add(path)
    for row in walk(load(path)):add(checked(row))
for row in assembly['files']:assert ref(root/row['canonical']['path'])==row['canonical']
qa=[];tests=[];final_source=None;prior_source=None
for suffix,args,is_final in [
    ('fmt-02',['fmt','--all','--','--check'],True),
    ('admission-tests-02',['test','-p','ep_run','--lib','raw_equipment_admission'],True),
    ('cli-tests-01',['test','-p','ep_run','--test','arbitrary_run','one_zone_runtime_writes_stable_output_layout'],True),
    ('clippy-01',['clippy','--workspace','--all-targets','--','-D','warnings'],True),
    ('quality-01',None,False),
    ('fmt-01',['fmt','--all','--','--check'],False),
]:
    path=base/f'ordinary-output-prescan-{suffix}/receipt.json';value=load(path)
    expected=['C:/Users/GonieGonie/.cargo/bin/cargo.exe',*args]if args else ['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1']
    assert value['command']==expected and value['exit_code']==0 and value['launch_error']is None and value['source_bytes_match_before_and_after']is True
    if is_final:
        if final_source is None:final_source=value['source_snapshot']
        assert final_source==value['source_snapshot']
    else:
        if prior_source is None:prior_source=value['source_snapshot']
        assert prior_source==value['source_snapshot']
    qa.append({'receipt':ref(path),'final_Source':is_final,'qualification':'Final assembly02'if is_final else 'Assembly01; only child raw bridge pub(super)→pub(crate) changed afterward. Exact whole-byte inverse/other-six-file proof; quality LOC and behavior unchanged.'})
    add(path)
    for key in ['stdout','stderr','source_snapshot']:add(checked(value[key]))
    if 'tests-'in suffix:
        groups=[tuple(map(int,group))for group in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',checked(value['stdout']).read_text(encoding='utf8'))]
        assert groups and all(group[1]==group[2]==0 for group in groups)
        tests.append({'scope':suffix,'passed':sum(group[0]for group in groups),'failed':0,'ignored':0})
assert sum(group['passed']for group in tests)==2 and final_source!=prior_source
failed_path=base/'ordinary-output-prescan-admission-tests-01/receipt.json';failed=load(failed_path)
assert failed['exit_code']==101 and failed['source_snapshot']==prior_source and failed['source_bytes_match_before_and_after']is True
add(failed_path)
for key in ['stdout','stderr','source_snapshot']:add(checked(failed[key]))
add(Path(__file__))
out.mkdir();archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
    for name in sorted(artifacts):z.write(root/name,name)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and set(z.namelist())==set(artifacts)
    for name in z.namelist():assert hashlib.sha256(z.read(name)).hexdigest()==artifacts[name]['sha256']
write(out/'manifest.json',{'schema':'src06-output-prescan-evidence.v1','Source_snapshot':final_source,'assembly':ref(assembly_path),'independent_Source_review':ref(review_path),'artifacts':list(artifacts.values()),'historical_references':historical,'archive':ref(archive),'archive_member_count':len(artifacts),'archive_scope':'Seven active Rust files, full exact before/after/diffs, eleven finite Original ranges and their complete authenticated files, review/label qualification and actual QA receipts/logs/source snapshot indexes. This is not a transitive whole-workspace Source-object/Native execution bundle.','gates_updated':False})
write(out/'summary.json',{'schema':'src06-output-prescan-summary.v1','status':'Actual selected ordinary PostIPProcessing/preScan runtime path activated; full startup/Setup not completed','Source_snapshot':final_source,'prior_QA_Source_snapshot':prior_source,'behavior':assembly['behavior'],'QA':qa,'tests':{'selections':tests,'passed':2,'failed':0,'ignored':0,'new_bodies':0,'new_binaries':0},'historical_failed_QA':{'receipt':ref(failed_path),'exit_code':101,'qualification':'Actual E0364/E0603 from Root child pub(super) re-export. Assembly02 fixes only function visibility; full failure/source bytes retained.'},'supplemental_diff_label_qualification':ref(qualification_path),'independent_Source_review':ref(review_path),'limitations':['Literal/wildcard output keys only; RE2/API/monthly-positive producers explicitly unavailable','ASCII case-insensitive lookup equivalence; no general Unicode case folding or 8-bit map iteration ordering claim','Actual reached map writes retained on failure; unconsumed reporting/whole InputProcessor/unused-reporting parity not claimed','Current whole ordinary 235456 mismatches and 2754 required unavailable/unmatched, strict DesignDay nine-field failure and eight UNPAIRED fields unchanged','Full RunSimulation initialization, Setup, ManageHeatBalance/Surface/HVAC and Native numerical comparison incomplete','SRC-06 four gates and A14/54 B14/64 unchanged'],'validation_scope':'Final fmt, all-target workspace Clippy and two existing focused tests. Source-quality passed on assembly01; only one raw bridge visibility token changed afterward, exact inverse and six other full-file equality independently verified. No repeated whole-workspace tests.','manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False})
plan_path=root/'energyplus_porting_plan/plan.json';plan=load(plan_path);task=next(task for task in plan['tasks']if task['id']=='SRC-06')
assert all(task[key]=='미확인'for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_output_prescan'not in task
task['actual_selected_ordinary_output_prescan']=ref(out/'summary.json');write(plan_path,plan)
card=root/'energyplus_porting_plan/cards/SRC-06.md';text=card.read_text(encoding='utf8')
assert text.count('아래 16개 요약')==1
text=text.replace('아래 16개 요약','아래 17개 요약')
needle='\n기존 Weather03·absent site/station'
assert text.count(needle)==1
text=text.replace(needle,'\n| 실제 PostIP / 출력 사전 검색 | [요약](../evidence/SRC-06-ordinary-output-prescan/summary.json) · [색인](../evidence/SRC-06-ordinary-output-prescan/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-output-prescan/evidence.zip) | 실제 raw lexical 입력·첫 이름 표기·중복 count·공백/단위·wildcard와 반복/오류 상태를 보존. 전체 startup/RE2/API/monthly 완료는 아님. |\n'+needle)
needle='\n## 이력과 증거 보존'
assert text.count(needle)==1
text=text.replace(needle,'\n## 실제 PostIP 사전 검색 단위의 QA\n\n최종 Source `'+final_source['sha256']+'`에서 fmt·all-target workspace Clippy와 기존 raw admission·실제 CLI 테스트 **2 passed / 0 failed / 0 ignored**를 확인했다. 새 테스트 본문·binary는 없다. source-quality는 직전 Source에서 통과했으며, 이후 child 함수 공개 범위 한 토큰만 고쳐 전체 파일 역변환과 나머지 여섯 파일 동일성을 확인했다. 첫 컴파일의 실제 E0364/E0603 실패와 supplemental diff의 파일명 header 오기는 역사 및 별도 정정 증거로 남겼다. 입력·상태·scratch/unused 보존의 선택 검증이며 전체 workspace 중복 실행이나 새 Native 수치 비교는 수행하지 않았다. 모든 gate와 A/B 완료 수는 그대로다.\n'+needle)
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'archive_members':len(artifacts),'archive_bytes':archive.stat().st_size,'tests':tests},ensure_ascii=False))

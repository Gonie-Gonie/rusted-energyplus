"""Activate the selected actual PostIP/preScan path against the clean input-origin base."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-output-prescan-assembly-01'
assert not out.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == 'a589f297cce5254f37c28d4f4ffb58c744bacf02'
assert subprocess.check_output(['git', 'status', '--porcelain']) == b''
paths = [
    'crates/ep_runtime/src/heat_balance/source_output_prescan.rs',
    'crates/ep_run/src/ordinary_input_processor/reporting_prescan.rs',
    'crates/ep_runtime/src/heat_balance/mod.rs',
    'crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs',
    'crates/ep_run/src/ordinary_input_processor.rs',
    'crates/ep_run/src/pipeline.rs',
    'crates/ep_run/src/ordinary_input_processor_tests.rs',
]
before = {p: (root / p).read_bytes() if (root / p).is_file() else b'' for p in paths}
proposed = {p: data.decode() for p, data in before.items()}
for p, name in zip(paths[:2], ['source_output_prescan.rs', 'reporting_prescan.rs']):
    assert not (root / p).exists()
    proposed[p] = (base / 'ordinary-output-prescan-prep-Root-01' / name).read_text(encoding='utf8')

def replace(path, old, new):
    assert proposed[path].count(old) == 1, (path, old[:80])
    proposed[path] = proposed[path].replace(old, new)

replace(paths[2], 'pub(crate) mod source_round_format;', 'pub mod source_output_prescan;\npub(crate) mod source_round_format;')
replace(paths[3], '    /// Full allocated predefined string-entry owner.', '''    /// Raw direct-JSON output pre-scan operands, retained independently of getters.
    pub reporting_prescan_input: Option<super::source_output_prescan::SourceReportingPreScanInput>,
    /// Sole selected OutputsData pre-scan owner; not OutputProcessor registration.
    pub output_prescan: super::source_output_prescan::SourceOutputPreScan,
    /// Actual SimulationManager PreP_Fatal constructor member, initially false.
    pub simulation_preprocessor_fatal: bool,
    /// Full allocated predefined string-entry owner.''')
replace(paths[3], "impl CtfInitializationContext<'_> {", """impl CtfInitializationContext<'_> {
    /// Reach actual PostIPProcessing for the raw-admitted ordinary caller.
    ///
    /// # Errors
    /// Missing owners and reached Source failures retain all preceding state.
    pub fn post_input_processing(
        &mut self,
    ) -> Result<(), super::source_output_prescan::SourcePreScanError> {
        use super::source_output_prescan::{SourcePreScanError, post_input_processing};
        let input = self.reports.selected_input_processor.as_ref()
            .ok_or(SourcePreScanError::Unavailable("missing sole admitted input"))?;
        let raw = self.reports.reporting_prescan_input.as_ref()
            .ok_or(SourcePreScanError::Unavailable("missing raw reporting pre-scan operands"))?;
        post_input_processing(
            input, &mut self.reports.input_processor_shortcut, raw,
            &mut self.reports.output_prescan, self.reports.simulation_preprocessor_fatal,
            &mut self.backend,
        )
    }
""")
replace(paths[4], 'mod schema;', '''mod schema;
mod reporting_prescan;
pub(crate) use reporting_prescan::resolve as resolve_reporting_prescan;''')
replace(paths[5], '''    selected_input_processor:
        Option<ep_runtime::heat_balance::selected_input_processor::SelectedInputProcessor>,
}''', '''    selected_input_processor:
        Option<ep_runtime::heat_balance::selected_input_processor::SelectedInputProcessor>,
    reporting_prescan_input:
        Option<ep_runtime::heat_balance::source_output_prescan::SourceReportingPreScanInput>,
}''')
replace(paths[5], '''        ordinary_warmup_reporting: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility
        {''', '''        reporting_prescan_input: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility {
            Some(crate::ordinary_input_processor::resolve_reporting_prescan(raw_model)?)
        } else {
            None
        },
        ordinary_warmup_reporting: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility
        {''')
replace(paths[5], '''            let simulation = if let Some(reporting) = runtime_inputs.ordinary_warmup_reporting {''', '''            if let Some(raw) = runtime_inputs.reporting_prescan_input.take() {
                initialization.reports.reporting_prescan_input = Some(raw);
                initialization.post_input_processing().map_err(|error| error.to_string())?;
            }
            let simulation = if let Some(reporting) = runtime_inputs.ordinary_warmup_reporting {''')
replace(paths[6], '    Ok(())\n}', r'''    // Direct-JSON pre-scan keeps lexical spelling separately from getter alphas.
    let raw = parse_epjson_str(&format!(r#"{{{base},"Output:Variable":{{
        "z":{{"variable_name":"case var [W]","key_value":"key"}},
        "a":{{"variable_name":"CaSe VaR  ","key_value":"KeY"}},
        "b":{{"variable_name":"CASE VAR","key_value":"*"}},
        "c":{{"variable_name":"Tabbed\t  ","key_value":"  "}},
        "d":{{"variable_name":"Fallback","key_value":""}}
    }},"Output:Table:SummaryReports":{{"s":{{"reports":[{{"report_name":"AllSummary"}}]}}}}}}"#))?;
    let projection = resolve_reporting_prescan(&raw)?;
    assert_eq!(projection.variables.iter().map(|row| row.object_name.as_str()).collect::<Vec<_>>(), ["a", "b", "c", "d", "z"]);
    assert_eq!(projection.variables[0].variable_name, "CaSe VaR  ");
    assert_eq!(projection.variables[2].key, "  ");
    assert_eq!(projection.variables[4].variable_name, "case var [W]");
    let input = resolve(&raw)?;
    let unused = input.clone();
    let mut outputs = crate::ctf_initialization_outputs::CtfRunOutputs::new("26.1");
    let mut context = outputs.context();
    context.reports.initialize_input_processor(input)?;
    context.reports.reporting_prescan_input = Some(projection.clone());
    context.backend.state.doing_input_processing = true;
    let scratch = context.reports.input_processor_shortcut.clone();
    context.post_input_processing()?;
    assert!(!context.backend.state.doing_input_processing);
    let mut expected_scratch = scratch;
    expected_scratch.current_module_object = "Output:PreprocessorMessage".into();
    assert_eq!(context.reports.input_processor_shortcut, expected_scratch);
    assert_eq!(context.reports.selected_input_processor.as_ref(), Some(&unused));
    let prescan = &context.reports.output_prescan;
    assert_eq!(prescan.max_considered_output_variables, 10000);
    assert_eq!(prescan.num_considered_output_variables, 5);
    assert_eq!(prescan.output_variables_for_simulation.len(), 3);
    let keys = &prescan.output_variables_for_simulation["case var"];
    assert_eq!(keys.variable_name, "CaSe VaR");
    assert_eq!(keys.keys.len(), 2);
    assert_eq!(keys.keys["key"].key, "KeY");
    assert_eq!(keys.keys["key"].variable_name, "CaSe VaR");
    assert_eq!(keys.keys["*"].variable_name, "CASE VAR");
    assert!(prescan.find_item("unlisted key", "CASE VAR"));
    assert!(prescan.find_item("  ", "tabbed\t"));
    assert!(!prescan.find_item("", "tabbed\t"));
    assert!(!prescan.find_item("  ", "tabbed"));
    assert!(prescan.find_item("anything", "fallback"));
    assert!(!prescan.find_item("anything", "case var [W]"));
    context.post_input_processing()?;
    assert_eq!(context.reports.output_prescan.num_considered_output_variables, 10);
    let retained = context.reports.output_prescan.clone();
    assert!(context.reports.output_prescan.add_record("bad.regex", "unreached").is_err());
    assert_eq!(context.reports.output_prescan, retained);
    let mut bad_projection = projection;
    bad_projection.variables[1].key = "bad.regex".into();
    context.reports.reporting_prescan_input = Some(bad_projection);
    assert!(context.post_input_processing().is_err());
    assert_eq!(context.reports.output_prescan.num_considered_output_variables, 11);
    assert!(!context.reports.output_prescan.find_item("*", "unreached"));
    assert_eq!(context.reports.selected_input_processor.as_ref(), Some(&unused));
    Ok(())
}''')
out.mkdir()
for index, p in enumerate(paths):
    (out / f'{index:02}.before').write_bytes(before[p])
    (root / p).parent.mkdir(parents=True, exist_ok=True)
    (root / p).write_bytes(proposed[p].encode())
(out / 'apply.json').write_bytes((json.dumps({'paths': paths, 'author': str(Path(__file__).relative_to(root)).replace('\\','/'), 'base_head':'a589f297cce5254f37c28d4f4ffb58c744bacf02'}, indent=2)+'\n').encode())
print(json.dumps({'applied': paths, 'new_test_bodies': 0}))

"""Seal actual PostIP/preScan Source changes and authentic finite Original ranges."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-output-prescan-assembly-01'
assert not (out / 'manifest.json').exists()
apply_path = out / 'apply.json'
applied = json.loads(apply_path.read_bytes())

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

files = []
for index, name in enumerate(applied['paths']):
    before_path = out / f'{index:02}.before'
    before = before_path.read_bytes()
    after = (root / name).read_bytes()
    assert before != after
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after))
    if before:
        assert subprocess.check_output(['git', 'show', applied['base_head'] + ':' + name]) == before
    after_path = out / f'{index:02}.after'; after_path.write_bytes(after)
    diff_path = out / f'{index:02}.diff'
    diff_path.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='HEAD/'+name, tofile=name)).encode())
    files.append({'canonical': ref(root / name), 'before': ref(before_path), 'after': ref(after_path), 'complete_diff': ref(diff_path), 'test_bodies_before': len(re.findall(rb'#\[test\]', before)), 'test_bodies_after': len(re.findall(rb'#\[test\]', after))})

reference = root / '.reference/energyplus-src/26.1.0'
pin = '6f2e40d10250a105b49966baa24d843711e61048'
assert subprocess.check_output(['git','-C',str(reference),'rev-parse','HEAD']).decode().strip() == pin
ranges = [
    ('src/EnergyPlus/SimulationManager.cc',2777,2799),
    ('src/EnergyPlus/InputProcessing/InputProcessor.cc',1728,1843),
    ('src/EnergyPlus/InputProcessing/InputProcessor.cc',1845,2054),
    ('src/EnergyPlus/InputProcessing/InputProcessor.cc',2056,2407),
    ('src/EnergyPlus/InputProcessing/InputProcessor.cc',2410,2456),
    ('src/EnergyPlus/DataOutputs.cc',135,206),
    ('src/EnergyPlus/DataOutputs.hh',76,115),
    ('src/EnergyPlus/UtilityRoutines.cc',301,304),
    ('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.hh',631,657),
    ('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.hh',700,708),
    ('third_party/ObjexxFCL/src/ObjexxFCL/char.functions.hh',244,252),
]
originals = []
original_dir = out / 'Original'; original_dir.mkdir()
for index, (name, start, end) in enumerate(ranges):
    path = reference / name
    data = path.read_bytes()
    tracked = subprocess.run(['git','-C',str(reference),'cat-file','-e',pin+':'+name],capture_output=True).returncode == 0
    if tracked:
        blob = subprocess.check_output(['git','-C',str(reference),'show',pin+':'+name])
        assert blob.replace(b'\r\n',b'\n') == data.replace(b'\r\n',b'\n')
    literal = original_dir / f'{index:02}.source'
    literal.write_bytes(b''.join(data.splitlines(keepends=True)[start-1:end]))
    originals.append({'historical_source': ref(path), 'line_start':start,'line_end':end,'literal':ref(literal),'authentication':'Complete Original file matches Git '+pin+' after CRLF normalization' if tracked else 'Actual bundled local Original dependency; not tracked by this reference Git, no Git pin claimed'})
write(out / 'manifest.json', {
    'schema':'src06-output-prescan-canonical-assembly.v1', 'baseline_head':applied['base_head'],
    'files':files,'Original_ranges':originals,'authors':[ref(base/'apply-output-prescan-Root-01.py'),ref(Path(__file__))],
    'behavior':[
        'Actual ordinary runtime invokes PostIP immediately after sole IP/shortcut installation and raw lexical pre-scan projection move; legacy callers keep their existing path.',
        'DoingInputProcessing=false then actual PreprocessorMessage CurrentModuleObject/count, unchanged six scratch arrays and unusedInputs; positive preprocessor remains unsupported.',
        'Retained distinct OutputsData owner: MaxConsidered10000; no repeat guard/clear; duplicate emplace preserves first record spelling but increments signed NumConsidered each call.',
        'InputProcessor removes first bracket suffix and trims only ASCII spaces even without brackets; raw variable/key strings retain original casing. Getter alphas remain separate.',
        'FindItem consumes retained case-insensitive variable/key maps, direct lookup and wildcard, without trimming or parsing the lookup name.',
        'Raw SummaryReports AllSummary has no matching monthly branch and adds no records. Unsupported positive families/regex/monthly branches stop explicitly at reached boundaries.',
        'Existing raw admission test body extended; zero new bodies/binaries; full startup/Setup/numerical parity not claimed.',
    ], 'gates_updated':False,
})
print(json.dumps({'manifest':ref(out/'manifest.json'),'files':len(files),'Original_ranges':len(originals),'new_test_bodies':0}))

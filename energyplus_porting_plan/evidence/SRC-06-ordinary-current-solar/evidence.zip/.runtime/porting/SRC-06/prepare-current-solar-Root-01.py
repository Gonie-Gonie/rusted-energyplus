from pathlib import Path
import hashlib
import difflib
import json

root = Path.cwd()
out = root / '.runtime/porting/SRC-06/ordinary-current-solar-prep-01'
base_dir = 'crates/ep_runtime/src/weather_day/'
proposal = {}
current = (root / (base_dir + 'current.rs')).read_text(encoding='utf-8')
current = current.replace('//! Selected non-solar current weather state in EnergyPlus source order.',
    '//! Selected current weather and solar state in EnergyPlus source order.')
needle = '    /// Outdoor enthalpy, in J/kg.\n'
fields = '''    /// Actual SunIsUp after DetermineSunUpDown.
    pub sun_is_up: bool,
    /// Actual SunIsUpPrevTS, assigned before the current decision.
    pub sun_is_up_previous_timestep: bool,
    /// Actual SOLCOS x/y/z; z is retained even when the sun is down.
    pub solar_direction_cosines: [f64; 3],
    /// Actual BeamSolarRad after the nighttime mask, in W/m2.
    pub beam_solar_rad: f64,
    /// Actual DifSolarRad after the nighttime mask, in W/m2.
    pub dif_solar_rad: f64,
    /// Actual GndSolarRad after reflection and nighttime masking, in W/m2.
    pub gnd_solar_rad: f64,
    /// Actual monthly GndReflectance, with the reached snow modifier.
    pub gnd_reflectance: f64,
    /// Independent ground reflectance for daylighting.
    pub gnd_reflectance_for_daylighting: f64,
    /// Actual sky temperature from Today, in Celsius.
    pub sky_temp: f64,
    /// Actual SkyTempKelvin, calculated from the current Celsius owner.
    pub sky_temp_kelvin: f64,
    /// Actual UseSnowValues selection of Today's IsSnow.
    pub is_snow: bool,
    /// Actual total cloud cover from Today.
    pub total_cloud_cover: f64,
    /// Actual opaque cloud cover from Today.
    pub opaque_cloud_cover: f64,
'''
assert current.count(needle) == 1
current = current.replace(needle, fields + needle)
current = current.replace('    /// Selects Today and updates the bounded non-solar environment in source order.\n    /// EMS, design-day schedules, ground/water/sky/solar/daylight remain separate.',
    '    /// Selects Today and updates the admitted weather/solar environment.\n    /// EMS, optional ground/water models and daylight illuminance remain separate.')
needle = '        let today = state\n'
prefix = '''        let month = usize::try_from(state.environment.month - 1)
            .ok().filter(|&month| month < 12)
            .ok_or_else(|| WeatherDayError::admission("current ground reflectance month unavailable"))?;
        state.environment.current_weather.gnd_reflectance = state.weather.ground_reflectances[month];
        state.environment.current_weather.gnd_reflectance_for_daylighting =
            state.environment.current_weather.gnd_reflectance;
        determine_sun_up_down(state);
        if state.environment.current_weather.sun_is_up && state.weather.solar_altitude_angle < 0.0 {
            return Err(WeatherDayError::source_fatal(format!(
                "SetCurrentWeather: At {:02}/{:02} {:02} Sun is Up but Solar Altitude Angle is < 0.0",
                state.environment.month, state.environment.day_of_month, hour - 1)));
        }
'''
assert current.count(needle) == 1
current = current.replace(needle, prefix + needle)
needle = '        current.liquid_precipitation = today.liquid_precip / 1000.0;'
current = current.replace(needle, '''        state.weather.horizontal_infrared_sky = today.horiz_ir_sky;
        current.sky_temp = today.sky_temp;
        current.sky_temp_kelvin = current.sky_temp + 273.15;
        current.dif_solar_rad = today.dif_solar_rad;
        current.beam_solar_rad = today.beam_solar_rad;
''' + needle)
needle = '        current.out_enthalpy =\n'
suffix = '''        current.total_cloud_cover = today.total_sky_cover;
        current.opaque_cloud_cover = today.opaque_sky_cover;
        current.is_snow = state.weather.use_snow_values && today.is_snow;
        if current.is_snow {
            // Literal max(min(value,1),0) argument order, including NaN behavior.
            let reflectance = current.gnd_reflectance * state.weather.snow_ground_reflectance_modifier;
            let reflectance = if 1.0 < reflectance { 1.0 } else { reflectance };
            current.gnd_reflectance = if reflectance < 0.0 { 0.0 } else { reflectance };
            let daylight = current.gnd_reflectance_for_daylighting
                * state.weather.snow_ground_reflectance_for_daylighting_modifier;
            let daylight = if 1.0 < daylight { 1.0 } else { daylight };
            current.gnd_reflectance_for_daylighting = if daylight < 0.0 { 0.0 } else { daylight };
        }
        let ground = (current.beam_solar_rad * current.solar_direction_cosines[2]
            + current.dif_solar_rad) * current.gnd_reflectance;
        current.gnd_solar_rad = if ground < 0.0 { 0.0 } else { ground };
        if !current.sun_is_up {
            current.dif_solar_rad = 0.0;
            current.beam_solar_rad = 0.0;
            current.gnd_solar_rad = 0.0;
        }
'''
assert current.count(needle) == 1
current = current.replace(needle, suffix + needle)
current += '''
/// Literal DetermineSunUpDown; the daily and location operands have real owners.
fn determine_sun_up_down(state: &mut WeatherDayState) {
    const DEG_TO_RAD: f64 = std::f64::consts::PI / 180.0;
    let env = &mut state.environment;
    let daily = &state.today_variables;
    let weather = &mut state.weather;
    weather.hour_angle = if state.global.time_steps_in_hour != 1 {
        15.0 * (12.0 - (state.global.current_time + daily.equation_of_time))
            + (env.time_zone_meridian - env.longitude)
    } else {
        15.0 * (12.0 - ((state.global.current_time + env.one_step_solar_time_offset)
            + daily.equation_of_time)) + (env.time_zone_meridian - env.longitude)
    };
    let h = weather.hour_angle * DEG_TO_RAD;
    let cos_zenith = env.sin_latitude * daily.sin_solar_declin_angle
        + env.cos_latitude * daily.cos_solar_declin_angle * h.cos();
    let solar_zenith = cos_zenith.acos();
    let sin_altitude = env.cos_latitude * daily.cos_solar_declin_angle * h.cos()
        + env.sin_latitude * daily.sin_solar_declin_angle;
    let solar_altitude = sin_altitude.asin();
    let cos_azimuth = -(env.sin_latitude * cos_zenith - daily.sin_solar_declin_angle)
        / (env.cos_latitude * solar_zenith.sin());
    // Source max(CosAzimuth,-1), then min(1,CosAzimuth), without new clamps.
    let cos_azimuth = if cos_azimuth < -1.0 { -1.0 } else { cos_azimuth };
    let cos_azimuth = if cos_azimuth < 1.0 { cos_azimuth } else { 1.0 };
    let solar_azimuth = cos_azimuth.acos();
    weather.solar_altitude_angle = solar_altitude / DEG_TO_RAD;
    weather.solar_azimuth_angle = solar_azimuth / DEG_TO_RAD;
    if weather.hour_angle < 0.0 {
        weather.solar_azimuth_angle = 360.0 - weather.solar_azimuth_angle;
    }
    let current = &mut env.current_weather;
    current.solar_direction_cosines[2] = cos_zenith;
    current.sun_is_up_previous_timestep = current.sun_is_up;
    if cos_zenith < 0.00001 {
        current.sun_is_up = false;
        current.solar_direction_cosines[1] = 0.0;
        current.solar_direction_cosines[0] = 0.0;
    } else {
        current.sun_is_up = true;
        current.solar_direction_cosines[1] = daily.sin_solar_declin_angle * env.cos_latitude
            - daily.cos_solar_declin_angle * env.sin_latitude * h.cos();
        current.solar_direction_cosines[0] = daily.cos_solar_declin_angle * h.sin();
    }
}
'''
proposal[base_dir + 'current.rs'] = current
context = (root / (base_dir + 'context.rs')).read_text(encoding='utf-8')
needle = '    /// Selected site elevation.\n'
context = context.replace(needle, '''    /// Actual standard time-zone meridian from ResolveLocationInformation.
    pub time_zone_meridian: f64,
    /// Actual stored sine and cosine of site latitude.
    pub sin_latitude: f64,
    /// Actual stored cosine of site latitude.
    pub cos_latitude: f64,
    /// Actual TS1TimeOffset constructor default for hourly solar.
    pub one_step_solar_time_offset: f64,
''' + needle)
context = context.replace('            elevation: 0.0,', '''            time_zone_meridian: 0.0,
            sin_latitude: 0.0,
            cos_latitude: 0.0,
            one_step_solar_time_offset: -0.5,
            elevation: 0.0,''')
needle = '    /// Selected environment\'s rain-indicator control.\n'
context = context.replace(needle, '''    /// Actual DetermineSunUpDown HrAngle in degrees.
    pub hour_angle: f64,
    /// Actual SolarAltitudeAngle in degrees.
    pub solar_altitude_angle: f64,
    /// Actual SolarAzimuthAngle in degrees.
    pub solar_azimuth_angle: f64,
    /// Actual HorizIRSky copied from the selected Today slot.
    pub horizontal_infrared_sky: f64,
    /// Actual default GroundReflectances allocation, independently retained.
    pub ground_reflectances: [f64; 12],
    /// Actual SnowGndRefModifier constructor default.
    pub snow_ground_reflectance_modifier: f64,
    /// Actual SnowGndRefModifierForDayltg constructor default.
    pub snow_ground_reflectance_for_daylighting_modifier: f64,
''' + needle)
context = context.replace('            use_rain_values: true,', '''            hour_angle: 0.0,
            solar_altitude_angle: 0.0,
            solar_azimuth_angle: 0.0,
            horizontal_infrared_sky: 0.0,
            ground_reflectances: [0.2; 12],
            snow_ground_reflectance_modifier: 1.0,
            snow_ground_reflectance_for_daylighting_modifier: 1.0,
            use_rain_values: true,''')
proposal[base_dir + 'context.rs'] = context
lifecycle = (root / (base_dir + 'lifecycle.rs')).read_text(encoding='utf-8')
needle = '        state.environment.elevation = configuration.site.elevation_m;'
lifecycle = lifecycle.replace(needle, needle + '''
        // Literal ResolveLocationInformation4570-4576, after admitted site input.
        state.environment.time_zone_meridian = if configuration.site.time_zone_hours <= 12.0 {
            configuration.site.time_zone_hours * 15.0
        } else { configuration.site.time_zone_hours * 15.0 - 360.0 };
        state.environment.sin_latitude =
            (std::f64::consts::PI / 180.0 * state.environment.latitude).sin();
        state.environment.cos_latitude =
            (std::f64::consts::PI / 180.0 * state.environment.latitude).cos();''')
proposal[base_dir + 'lifecycle.rs'] = lifecycle

def describe(path):
    b = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'size_bytes': len(b)}

rows = []
for index, (key, text) in enumerate(proposal.items(), 1):
    actual = root / key
    before = out / 'base' / key
    after = out / 'proposed' / key
    diff = out / 'diffs' / f'{index:02}.diff'
    for p in [before, after, diff]:
        p.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(actual.read_bytes())
    after.write_bytes(text.encode('utf-8'))
    diff.write_bytes(''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        text.splitlines(True), fromfile=key, tofile=key)).encode('utf-8'))
    rows.append({'canonical_path': key, 'base': describe(before), 'proposal': describe(after), 'complete_direct_diff': describe(diff)})
originals = []
for name, first, last in [('WeatherManager.cc',2036,2273), ('WeatherManager.cc',4275,4335),
                         ('WeatherManager.cc',4570,4576), ('WeatherManager.hh',794,802),
                         ('WeatherManager.hh',849,852), ('DataEnvironment.hh',81,81),
                         ('DataEnvironment.hh',109,159), ('DataEnvironment.hh',172,191)]:
    original = root / '.reference/energyplus-src/26.1.0/src/EnergyPlus' / name
    p = out / 'Original' / f'{name}-{first}-{last}.txt'
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b''.join(original.read_bytes().splitlines(keepends=True)[first-1:last]))
    originals.append({'original':describe(original), 'start_line':first, 'end_line':last, 'literal':describe(p)})
manifest = {'schema':'src06-held-current-solar.v1', 'status':'HELD for Source review and coordinated context/lifecycle merge',
    'actual_base_Source':'90b489e38f4b41d61ff6cd726ea22e03f823179163db04777f5e1107f068d2ee',
    'files':rows, 'literal_Original_ranges':originals,
    'limits':['Selected no-EMS weather; default ground reflectance, no input-loader widening',
        'DD schedule reset belongs to Header and must occur before wind assignment',
        'No daylight illuminance or optional ground/water model claimed',
        'No compiler/test/Native execution, no fabricated expected endpoints']}
(out / 'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf-8'))
print(json.dumps(describe(out / 'manifest.json')))

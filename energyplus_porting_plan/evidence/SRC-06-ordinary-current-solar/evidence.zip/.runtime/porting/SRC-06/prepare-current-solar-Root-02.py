from pathlib import Path
import hashlib
import difflib
import json

root = Path.cwd()
parent = root / '.runtime/porting/SRC-06/ordinary-current-solar-prep-01'
out = root / '.runtime/porting/SRC-06/ordinary-current-solar-prep-02'
parent_manifest = json.loads((parent / 'manifest.json').read_bytes())
assert hashlib.sha256((parent / 'manifest.json').read_bytes()).hexdigest() == '87e6fd92c817d5860f9323b7aed307d2fd638fe4cbacca4a28dc801f1baeda88'
proposals = {r['canonical_path']:(root / r['proposal']['path']).read_text(encoding='utf-8') for r in parent_manifest['files']}
key = 'crates/ep_runtime/src/weather_day/tests.rs'
text = (root / key).read_text(encoding='utf-8')
text = text.replace('                out_enthalpy: real(304, 9),', '''                sun_is_up: true,
                sun_is_up_previous_timestep: false,
                solar_direction_cosines: [-0.0, real(308, 0), real(308, 1)],
                beam_solar_rad: real(308, 2),
                dif_solar_rad: real(308, 3),
                gnd_solar_rad: real(308, 4),
                gnd_reflectance: real(308, 5),
                gnd_reflectance_for_daylighting: real(308, 6),
                sky_temp: real(308, 7),
                sky_temp_kelvin: real(308, 8),
                is_snow: true,
                total_cloud_cover: real(308, 9),
                opaque_cloud_cover: real(308, 10),
                out_enthalpy: real(304, 9),''')
text = text.replace('            elevation: real(100, 5),', '''            time_zone_meridian: real(309, 0),
            sin_latitude: -0.0,
            cos_latitude: real(309, 1),
            one_step_solar_time_offset: real(309, 2),
            elevation: real(100, 5),''')
text = text.replace('            use_rain_values: false,', '''            hour_angle: real(309, 3),
            solar_altitude_angle: real(309, 4),
            solar_azimuth_angle: real(309, 5),
            horizontal_infrared_sky: -0.0,
            ground_reflectances: [real(309, 6); 12],
            snow_ground_reflectance_modifier: real(309, 7),
            snow_ground_reflectance_for_daylighting_modifier: real(309, 8),
            use_rain_values: false,''')
proposals[key] = text
key = 'crates/ep_runtime/src/weather_day/current_tests.rs'
text = (root / key).read_text(encoding='utf-8')
needle = '    assert!(error.to_string().contains("current Today slot unavailable"));\n'
addition = '''    // Reuse this real session for authored solar branch coverage. The source
    // Today owner is deliberately nonzero at night; masking must not mutate it.
    session.state.today_values = WeatherDayValues::allocated(4)?;
    session.state.environment.sin_latitude = 0.0;
    session.state.environment.cos_latitude = 1.0;
    session.state.environment.time_zone_meridian = 0.0;
    session.state.environment.longitude = 0.0;
    session.state.today_variables.sin_solar_declin_angle = 0.0;
    session.state.today_variables.cos_solar_declin_angle = 1.0;
    session.state.today_variables.equation_of_time = 0.0;
    let slot = super::WeatherVars { out_dry_bulb_temp: 20.0, out_dew_point_temp: 10.0,
        out_baro_press: 101325.0, out_rel_hum: 50.0, beam_solar_rad: 800.0,
        dif_solar_rad: 120.0, sky_temp: -20.0, horiz_ir_sky: 300.0,
        total_sky_cover: 7.0, opaque_sky_cover: 6.0, ..super::WeatherVars::default() };
    for hour in [1_usize, 12] {
        session.state.today_values.hour_mut(hour)?.fill(slot);
    }
    session.state.global.hour_of_day = 12;
    session.state.global.time_step = 4;
    session.set_current_weather()?;
    let noon = session.state.environment.current_weather;
    assert!(noon.sun_is_up);
    assert_eq!(noon.solar_direction_cosines, [0.0, 0.0, 1.0]);
    assert_eq!(session.state.weather.solar_altitude_angle, 90.0);
    assert_eq!(noon.gnd_solar_rad, 184.0);
    assert_eq!((noon.beam_solar_rad, noon.dif_solar_rad), (800.0, 120.0));
    assert_eq!(noon.sky_temp_kelvin, 253.14999999999998);
    assert_eq!(session.state.weather.horizontal_infrared_sky, 300.0);
    assert_eq!((noon.total_cloud_cover, noon.opaque_cloud_cover), (7.0, 6.0));
    session.state.global.hour_of_day = 1;
    session.state.global.time_step = 1;
    session.set_current_weather()?;
    let night = session.state.environment.current_weather;
    assert!(!night.sun_is_up);
    assert!(night.sun_is_up_previous_timestep);
    assert!(night.solar_direction_cosines[2] < 0.0);
    assert_eq!(&night.solar_direction_cosines[..2], &[0.0, 0.0]);
    assert_eq!((night.beam_solar_rad, night.dif_solar_rad, night.gnd_solar_rad), (0.0, 0.0, 0.0));
    assert_eq!(session.state.today_values.hour(1)?[0], slot);
    session.set_current_weather()?;
    assert!(!session.state.environment.current_weather.sun_is_up_previous_timestep,
        "a second genuine call at the same clock still advances the retained previous flag");
    session.state.global.hour_of_day = 12;
    session.state.global.time_step = 4;
    session.state.weather.use_snow_values = true;
    session.state.weather.snow_ground_reflectance_modifier = 10.0;
    session.state.weather.snow_ground_reflectance_for_daylighting_modifier = 0.5;
    session.state.today_values.hour_mut(12)?[3].is_snow = true;
    session.set_current_weather()?;
    let snow = session.state.environment.current_weather;
    assert_eq!((snow.gnd_reflectance, snow.gnd_reflectance_for_daylighting), (1.0, 0.1));
    assert_eq!(snow.gnd_solar_rad, 920.0);
    session.state.today_values.hour_mut(12)?[3].is_snow = false;
    session.set_current_weather()?;
    assert_eq!(session.state.environment.current_weather.gnd_reflectance, 0.2,
        "monthly reflectance resets before a new snow decision");
    session.state.global.time_steps_in_hour = 1;
    session.state.global.time_step = 1;
    session.state.weather.time_step_fraction = 1.0;
    session.setup_interpolation_values()?;
    session.state.today_values = WeatherDayValues::allocated(1)?;
    session.state.today_values.hour_mut(12)?[0] = slot;
    session.set_current_weather()?;
    assert_eq!(session.state.weather.hour_angle, 7.5,
        "one timestep uses the real -0.5 hour offset");
    assert!(session.state.environment.current_weather.sun_is_up);
'''
assert text.count(needle) == 1
text = text.replace(needle, needle + addition)
proposals[key] = text

def describe(path):
    b = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(), 'sha256':hashlib.sha256(b).hexdigest(), 'size_bytes':len(b)}

rows = []
for index, (key, text) in enumerate(proposals.items(), 1):
    before = out / 'base' / key
    after = out / 'proposed' / key
    diff = out / 'diffs' / f'{index:02}.diff'
    for p in [before, after, diff]:
        p.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes((root / key).read_bytes())
    after.write_bytes(text.encode('utf-8'))
    diff.write_bytes(''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        text.splitlines(True), fromfile=key, tofile=key)).encode('utf-8'))
    rows.append({'canonical_path':key, 'base':describe(before), 'proposal':describe(after), 'complete_direct_diff':describe(diff)})
manifest = {**parent_manifest, 'schema':'src06-held-current-solar.v2',
    'parent':describe(parent / 'manifest.json'), 'files':rows,
    'test_changes':'Two existing files only; extends one session-admission test with authored solar branches and full handoff canaries; no new test count/binary'}
(out / 'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf-8'))
print(json.dumps(describe(out / 'manifest.json')))

from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = root / 'energyplus_porting_plan/evidence/SRC-06-ordinary-current-solar'
source = 'af6f53c88091a2350ba0545ddc4ed1ee200e75c734e6823e979e20b096f9fa18'

def ref(p):
    b = p.read_bytes()
    return {'path':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def checked(row):
    p = root / row['path']
    actual = ref(p)
    assert actual['sha256'] == row['sha256'], row['path']
    assert actual['size_bytes'] == row.get('size_bytes',actual['size_bytes']), row['path']
    return p
def write(p, data):
    p.write_bytes((json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8'))

assert not out.exists()
prep = base / 'ordinary-current-solar-prep-03/manifest.json'
assert ref(prep)['sha256'] == '1534143cd25f8e7dc5f2ee3dff58310d70624c485f9d071d867076263fceb58b'
m = json.loads(prep.read_bytes())
review_paths = [base / 'Header-ordinary-current-solar-Source-review-03/review.json',
                base / 'Header-ordinary-current-solar-formatter-review-01/review.json']
for p, digest in zip(review_paths, ['02780432608a3c6d22a4f1e45f0adbc7c0d3c3bd74fadc2c953409b4df1441bd',
                                  'fb251f68b922b45450c7779d5399183998f299efbbcaa8b69204a5d263475aa2']):
    assert ref(p)['sha256'] == digest
    assert json.loads(p.read_bytes())['accepted']
format_review = json.loads(review_paths[1].read_bytes())
assert format_review['Source_snapshot']['sha256'] == source
source_index = json.loads(checked(format_review['Source_snapshot']).read_bytes())
rows = {row['historical_path']:row for row in source_index['files']}
for row in format_review['five_affected_files']:
    actual = row['actual_formatted']
    checked(actual)
    assert rows[row['canonical_path']]['archive']['sha256'] == actual['sha256']
assert len(format_review['five_affected_files']) == 5

commands = {
    'fmt-check':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','fmt','--all','--','--check'],
    'source-quality':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1'],
    'clippy':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','clippy','--workspace','--all-targets','--','-D','warnings'],
    'workspace':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','test','--workspace'],
}
qa = []
for key, argv in commands.items():
    p = base / f'ordinary-current-solar-{key}-01/receipt.json'
    data = json.loads(p.read_bytes())
    assert data['exit_code'] == 0 and data['launch_error'] is None
    assert data['command'] == argv
    assert data['source_snapshot']['sha256'] == source
    assert data['source_bytes_match_before_and_after'] is True
    qa.append(ref(p))
test_receipt = json.loads(checked(qa[-1]).read_bytes())
log = checked(test_receipt['stdout']).read_text(encoding='utf-8')
groups = [tuple(map(int, r)) for r in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)]
assert len(groups) == 18 and tuple(map(sum,zip(*groups))) == (4974,0,2), groups
assert 'weather::day::current_tests::current_rejects_clock_that_exceeds_actual_today_storage ... ok' in log
assert 'weather::day::tests::whole_day_transport_preserves_every_slot_and_unowned_canary ... ok' in log

artifacts = {}
def add(p):
    r = ref(p)
    assert r['size_bytes'] <= 10 * 1024 * 1024
    artifacts[r['path']] = r
def gather(value):
    if isinstance(value,dict):
        if 'path' in value and 'sha256' in value:
            add(checked(value))
        else:
            for v in value.values(): gather(v)
    elif isinstance(value,list):
        for v in value: gather(v)
add(Path(__file__).resolve())
for p in [prep,*review_paths,base / 'ordinary-current-solar-application-Root-01/application-literal.json',
          base / 'ordinary-current-solar-fmt-01/receipt.json',*map(checked,qa)]:
    add(p)
    gather(json.loads(p.read_bytes()))
for name in ['prepare-current-solar-Root-01.py','prepare-current-solar-Root-02.py',
             'prepare-current-solar-Root-03.py','apply-current-solar-Root-01.py']:
    add(base / name)
for name in ['ordinary-current-solar-prep-01','ordinary-current-solar-prep-02']:
    p = base / name / 'manifest.json'
    add(p)
    gather(json.loads(p.read_bytes()))
for row in m['literal_Original_ranges']:
    actual = checked(row['original']).read_bytes().splitlines(keepends=True)
    assert checked(row['literal']).read_bytes() == b''.join(actual[row['start_line']-1:row['end_line']])
assert sum(r['size_bytes'] for r in artifacts.values()) < 40 * 1024 * 1024
out.mkdir(parents=True)
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts):
        z.write(checked(artifacts[name]),name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(artifacts)
    for name in z.namelist():
        b = z.read(name)
        assert hashlib.sha256(b).hexdigest() == artifacts[name]['sha256']
        assert len(b) == artifacts[name]['size_bytes']
manifest = {'schema':'src06-current-solar-evidence.v1','Source_snapshot':format_review['Source_snapshot'],
    'artifacts':list(artifacts.values()),'archive':ref(archive),'archive_member_count':len(artifacts),
    'reference_scope':'Finite listed bytes only; Source-index rows are metadata, not a transitive whole-workspace payload archive',
    'large_Native_payloads_read':False,'Native_execution_performed':False,'gates_updated':False}
write(out / 'manifest.json',manifest)
summary = {'schema':'src06-current-solar-summary.v1','status':'Actual consumed selected current-weather solar producer; full port remains incomplete',
    'Source_snapshot':format_review['Source_snapshot'],
    'behavior':['Actual daily coefficients and once-initialized location owners feed DetermineSunUpDown',
        'Independent current sun/previous-sun/SOLCOS/angles, sky/IR/cloud/snow owners are retained',
        'Monthly ground reflectance resets before separate snow modifiers and ground-solar calculation',
        'Night masks current Beam/Dif/Gnd solar without changing Today; duplicate calls mutate previous-sun normally',
        'ObjexxFCL min/max argument order preserves original NaN behavior; hourly offset remains -0.5'],
    'changes':format_review['five_affected_files'],'QA':qa,
    'workspace':{'groups':18,'passed':4974,'failed':0,'ignored':2},
    'test_policy':'Two existing test files extended; test count and binaries unchanged; one full workspace run, no redundant focused run',
    'independent_reviews':list(map(ref,review_paths)),
    'limitations':['No new Native numerical parity claimed',
        'No new DD kickoff/InitSurface caller activation; DD site-schedule reset awaits real configuration integration',
        'Default ground-reflectance/no-EMS scope; optional ground/water models and daylight illuminance not ported here',
        'All SRC-06 gates and A14/54 B14/64 remain unchanged'],
    'manifest':ref(out / 'manifest.json'),'archive':ref(archive)}
write(out / 'summary.json',summary)
print(json.dumps({'summary':ref(out / 'summary.json'),'manifest':ref(out / 'manifest.json'),
    'archive':ref(archive),'members':len(artifacts)}))

from pathlib import Path
import difflib
import hashlib
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools/porting'))
import record_command as rec

prep = root / '.runtime/porting/SRC-06/ordinary-current-solar-prep-03/manifest.json'
out = root / '.runtime/porting/SRC-06/ordinary-current-solar-application-Root-01'
def ref(path):
    b = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def exact(row):
    p = root / row['path']
    assert ref(p) == row, row['path']
    return p.read_bytes()
assert ref(prep)['sha256'] == '1534143cd25f8e7dc5f2ee3dff58310d70624c485f9d071d867076263fceb58b'
m = json.loads(prep.read_bytes())
assert not out.exists()
before = rec.source_snapshot()
assert before['sha256'] == m['actual_base_Source']
pending = []
for row in m['files']:
    path = root / row['canonical_path']
    assert path.resolve().is_relative_to(root / 'crates/ep_runtime/src/weather_day')
    old = exact(row['base'])
    assert path.read_bytes() == old
    new = exact(row['proposal'])
    diff = exact(row['complete_direct_diff']).decode()
    assert diff == ''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),
        fromfile=row['canonical_path'],tofile=row['canonical_path']))
    pending.append((path,new))
assert len(pending) == 5
for row in m['literal_Original_ranges']:
    original = exact(row['original'])
    assert exact(row['literal']) == b''.join(original.splitlines(keepends=True)[row['start_line']-1:row['end_line']])
out.mkdir()
for path,new in pending:
    path.write_bytes(new)
app = {'schema':'src06-current-solar-application.v1','preparation':ref(prep),
    'application_Source':ref(Path(__file__).resolve()),'source_before':before,
    'source_after_literal':rec.source_snapshot(),'changes':m['files'],
    'new_Native_parity_claimed':False,'DD_caller_activation_claimed':False,'gates_updated':False}
p = out / 'application-literal.json'
p.write_bytes(rec.json_bytes(app))
print(json.dumps(ref(p)))

from pathlib import Path
import hashlib
import difflib
import json

root = Path.cwd()
parent = root / '.runtime/porting/SRC-06/ordinary-current-solar-prep-02'
out = root / '.runtime/porting/SRC-06/ordinary-current-solar-prep-03'
m = json.loads((parent / 'manifest.json').read_bytes())
assert hashlib.sha256((parent / 'manifest.json').read_bytes()).hexdigest() == 'e84149893efb155a1076e42c8ae63f0473de2b536c03b7d33e27ea1e9d843d01'
proposals = {r['canonical_path']:(root / r['proposal']['path']).read_text(encoding='utf-8') for r in m['files']}
p = 'crates/ep_runtime/src/weather_day/'
s = proposals[p + 'current.rs']
for a, b in [
    ('if 1.0 < reflectance { 1.0 } else { reflectance }', 'if reflectance < 1.0 { reflectance } else { 1.0 }'),
    ('if 1.0 < daylight { 1.0 } else { daylight }', 'if daylight < 1.0 { daylight } else { 1.0 }'),
    ('if cos_azimuth < 1.0 { cos_azimuth } else { 1.0 }', 'if 1.0 < cos_azimuth { 1.0 } else { cos_azimuth }')]:
    assert s.count(a) == 1
    s = s.replace(a, b)
s = s.replace('        state.weather.rpt_is_rain = if current.is_rain { 1 } else { 0 };',
    '        state.weather.rpt_is_rain = if current.is_rain { 1 } else { 0 };\n        state.weather.rpt_is_snow = if current.is_snow { 1 } else { 0 };')
proposals[p + 'current.rs'] = s
s = proposals[p + 'context.rs']
s = s.replace('    /// Actual DetermineSunUpDown HrAngle in degrees.',
    '    /// Actual RptIsSnow report indicator.\n    pub rpt_is_snow: i32,\n    /// Actual DetermineSunUpDown HrAngle in degrees.')
s = s.replace('            hour_angle: 0.0,', '            rpt_is_snow: 0,\n            hour_angle: 0.0,')
proposals[p + 'context.rs'] = s
s = proposals[p + 'tests.rs']
s = s.replace('            hour_angle: real(309, 3),', '            rpt_is_snow: 310,\n            hour_angle: real(309, 3),')
proposals[p + 'tests.rs'] = s
s = proposals[p + 'current_tests.rs']
s = s.replace('    assert_eq!(session.state.weather.solar_altitude_angle, 90.0);',
    '    assert_eq!(session.state.weather.solar_altitude_angle, 90.0);\n    assert!(session.state.weather.solar_azimuth_angle.is_nan(),\n        "ObjexxFCL min(1, NaN) retains the undefined azimuth at zenith");')
s = s.replace('    assert_eq!(snow.gnd_solar_rad, 920.0);',
    '    assert_eq!(snow.gnd_solar_rad, 920.0);\n    assert_eq!(session.state.weather.rpt_is_snow, 1);')
s = s.replace('    session.state.global.time_steps_in_hour = 1;',
    '    assert_eq!(session.state.weather.rpt_is_snow, 0);\n    session.state.global.time_steps_in_hour = 1;')
proposals[p + 'current_tests.rs'] = s

def describe(path):
    b = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(), 'sha256':hashlib.sha256(b).hexdigest(), 'size_bytes':len(b)}

rows = []
for index, (key, s) in enumerate(proposals.items(), 1):
    before = out / 'base' / key
    after = out / 'proposed' / key
    diff = out / 'diffs' / f'{index:02}.diff'
    delta = out / 'parent-diffs' / f'{index:02}.diff'
    for q in [before, after, diff, delta]:
        q.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes((root / key).read_bytes())
    after.write_bytes(s.encode('utf-8'))
    def full_diff(a,b):
        return ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile=key, tofile=key)).encode('utf-8')
    diff.write_bytes(full_diff(before.read_text(encoding='utf-8'), s))
    old = next(r for r in m['files'] if r['canonical_path'] == key)
    delta.write_bytes(full_diff((root / old['proposal']['path']).read_text(encoding='utf-8'), s))
    rows.append({'canonical_path':key,'base':describe(before),'proposal':describe(after),
        'complete_direct_diff':describe(diff),'complete_parent_diff':describe(delta)})
originals = list(m['literal_Original_ranges'])
for name, first, last in [('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh',88,96),
                         ('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh',337,343),
                         ('src/EnergyPlus/EnergyPlus.hh',160,168)]:
    original = root / '.reference/energyplus-src/26.1.0' / name
    q = out / 'Original' / f'{Path(name).name}-{first}-{last}.txt'
    q.parent.mkdir(parents=True, exist_ok=True)
    q.write_bytes(b''.join(original.read_bytes().splitlines(keepends=True)[first-1:last]))
    originals.append({'original':describe(original),'start_line':first,'end_line':last,'literal':describe(q)})
m = {**m,'schema':'src06-held-current-solar.v3','parent':describe(parent / 'manifest.json'),
    'files':rows,'literal_Original_ranges':originals,
    'peer_corrections':'Exact ObjexxFCL min argument order for NaN; genuine RptIsSnow suffix; existing authored zenith/snow canary assertions extended'}
(out / 'manifest.json').write_bytes((json.dumps(m,indent=2)+'\n').encode('utf-8'))
print(json.dumps(describe(out / 'manifest.json')))

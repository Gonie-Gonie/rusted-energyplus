from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-controlled-prediction-B-NOLIMIT-24H-command-Root-21/receipt.json','7f465ed1c71ef20cec1d96565e913c7d142ccb41b1f8f229ab9a305b8aa4b25f'),
 'A24':('canonical-source-controlled-prediction-A-24H-command-Root-21/receipt.json','df920531202fb7743b38ed075f8f5ee78ce9ea5897362180acc49eecfafa1947'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-component-availability-'+case+'-command-Root-22'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-component-availability-'+case+'-Root-22/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

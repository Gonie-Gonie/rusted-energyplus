"""Unsealed same-owner component-availability lifecycle successor on Source21."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'source-component-availability-draft-Peer-22'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def check(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', got['bytes']), row
    return p
def put(name, b):
    p = O / name; assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b); return ref(p)
def doc(name, obj): return put(name, (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())
def swap(s, old, new):
    assert s.count(old) == 1, old[:100]
    return s.replace(old, new)

parent_ref = ref(D / 'source-controlled-prediction-held-Peer-21/manifest.json')
assert parent_ref['sha256'] == 'c9bef4b49d4c26bfd32a4a517e632a84ef43d95f51a6fe8919cbe90836c1c186'
parent = json.loads(check(parent_ref).read_bytes())
plan = json.loads(check(parent['complete_final_compiler_Source_plan']).read_bytes())
entries = {row['path']: row for row in plan['entries']}
p = P + 'ordinary_equipment/management/availability.rs'
old = check(entries[p]['source']).read_bytes()
assert old == (R / p).read_bytes()
s = old.decode()
s = swap(s, '//! Actual SystemAvailabilityManager136–309/310–1220/1561–1680 empty-manager path.',
    '//! Actual same-owner SystemAvailabilityManager component allocation and no-manager lifecycle.')
s = swap(s, '''                if row.total_components > 0 {
                    return Err(Error::Unavailable(
                        "actual ZoneCompAvailMgrs positive allocation405",
                    ));
                }''', '''                if row.total_components > 0 {
                    let count = usize::try_from(row.total_components)
                        .map_err(|_| Error::Unavailable("actual ZoneCompAvailMgrs allocation405 integer domain"))?;
                    row.managers = Some(vec![SourceZoneComponentManager::default(); count]);
                }''')
s = swap(s, '''            if row.managers.is_none() {
                continue;
            }
            return Err(Error::Unavailable(
                "actual positive zone availability manager257",
            ));''', '''            let Some(managers) = row.managers.as_mut() else {
                continue;
            };
            for component_number in 1..=row.total_components {
                let at = component_number.checked_sub(1)
                    .and_then(|number| usize::try_from(number).ok())
                    .ok_or(Error::Unavailable("actual zone availability component ordinal257"))?;
                let manager = managers.get_mut(at)
                    .ok_or(Error::Unavailable("actual same ZoneCompAvailMgrs259"))?;
                if manager.number_managers > 0 {
                    let _previous_status = manager.status;
                    manager.status = 0; // Native Status::NoAction265 precedes first manager record.
                    return Err(Error::Unavailable("positive zone availability availManagers first record268"));
                } else {
                    manager.status = 0; // Literal no-manager branch287, not a forced readiness flag.
                }
                if manager.zone_number == 0 {
                    continue;
                }
                if self.ancillary.hybrid_ventilation.number_hybrid_ventilation_managers == 0 {
                    continue;
                }
                return Err(Error::Unavailable("positive zone availability HybridVentData first record298"));
            }''')
s = swap(s, '        // Hybrid flags/count remain sole existing ancillary.hybrid_ventilation; zero components never read its inner branch.',
    '        // The hybrid count is borrowed from the same retained ancillary owner only after real ZoneNum != 0.')
new = s.encode()
assert not O.exists(); O.mkdir()
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal>', 'exec'), ns)
f = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p)).encode()
inv = ''.join(difflib.unified_diff(new.decode().splitlines(keepends=True), old.decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p)).encode()
assert ns['apply_literal'](old, f) == new and ns['apply_literal'](new, inv) == old
parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
assert parsed.returncode == 0 and not parsed.stderr
file = {'canonical_path': p, 'parent21': entries[p]['source'], 'before': put('before/' + p, old), 'proposed': put('proposed/' + p, new),
    'forward_diff': put('forward.diff', f), 'inverse_diff': put('inverse.diff', inv), 'both_literal_applications_exact': True,
    'Source_only_parse': {'exit_code': 0, 'stdout': put('parse.stdout', parsed.stdout), 'stderr': put('parse.stderr', parsed.stderr)}}
native, extents = [], []
for p, ranges in {
    'src/EnergyPlus/SystemAvailabilityManager.cc': [(136, 308), (310, 410), (410, 1217), (1448, 1512), (1561, 1679)],
    'src/EnergyPlus/SystemAvailabilityManager.hh': [(68, 152), (397, 431), (574, 615)],
    'src/EnergyPlus/DataZoneEquipment.cc': [(85, 101)],
    'src/EnergyPlus/DataZoneEquipment.hh': [(164, 172)],
    'src/EnergyPlus/InputProcessing/InputProcessor.cc': [(505, 541), (1398, 1470)],
}.items():
    b = subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N)
    assert b == (N / p).read_bytes()
    native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, b)})
    for first, last in ranges:
        literal = b''.join(b.splitlines(keepends=True)[first-1:last])
        extents.append({'native_path': p, 'first': first, 'last': last, 'utf8_sha256': hashlib.sha256(literal).hexdigest(), 'literal': literal.decode()})
contexts = []
for p in [P + q for q in ['ordinary_equipment/management.rs', 'ordinary_hvac_manager/ancillary.rs', 'ordinary_hvac_manager/provider_host.rs',
    'ordinary_hvac_manager.rs', 'ordinary_hvac_manager/owners.rs', 'selected_input_processor.rs']]:
    b = check(entries[p]['source']).read_bytes()
    contexts.append({'canonical_path': p, 'parent21': entries[p]['source'], 'frozen': put('context/' + p, b)})
contract = {'scope': 'Positive component-owned actual count-sized availability allocation and no-manager lifecycle through genuine ManageSystemAvailability return.',
    'same_retained_owner': 'SourceHvacManager.ancillary.availability.ZoneComp; no duplicate vector/count/state or typed projection. Hybrid read uses same ancillary.hybrid_ventilation real IP-produced count.',
    'constructor': {'number_managers': 0, 'status': 'Native Status::NoAction(0)', 'start_time': 0, 'stop_time': 0, 'manager_list_name': '', 'managers': None, 'zone_number': 0, 'input': True, 'count': 0},
    'ordered_lifecycle': ['All12 genuine manager definitions/maxima and existing shortcut locals', 'actual ZoneComp allocation14 if absent',
        'for each of14 types only if its managers allocation absent, actual IP getNumObjectsFound then total_components write then positive count-sized full constructor vector405',
        'same11 per-family manager count/allocation boundaries in Native order', 'existing temporary-array deallocation and true get_input_flag false only after complete input return; initial ManageSystemAvailability returns early',
        'later actual initialize_one_time flag/reset order and existing per-component statuses reset',
        'real primary/plant bounds then each actual type and indexed component1..TotalNumComp; positive NumAvailManagers preserves previous/statusNoAction before real first-record typed bound',
        'zero NumAvailManagers writes Native NoAction; ZoneNum0 skips hybrid count; otherwise actual existing hybrid count0 skips, positive first actual row298 remains typed'],
    'preserved_regions': 'All nine constructor fields and existing count/definition/manager allocations/OptStart one-time/reset/input flags are unchanged except actual positive component vector allocation.',
    'limits': ['Actual21 B stops allocation405 before this Source has run. No fullB, availability manager simulation, positive hybrid, assignment-list/IdealLoads producer or Node lifecycle execution claim.',
        'Existing Source has no GetZoneEqAvailabilityManager caller yet; do not add disconnected list state/getter or falsely clear component.Input/Count. They stay genuine constructor fields until a real later caller is ported.',
        'No Native answers, artificial zero-length positive vector, forced manager counts/ready flags, new tests or arithmetic/tolerance/gate changes.']}
draft = {'status': 'UNSEALED_SOURCE_ONLY_NO_COMPILATION_OR_EXECUTION', 'parent21_producer': parent_ref, 'parent21_plan': parent['complete_final_compiler_Source_plan'],
    'files': [file], 'existing_Source_files': 1, 'new_Source_files': 0, 'literal_applications': 2, 'Native_commit': PIN, 'Native_wholes': native,
    'Native_literal_extents': doc('Native-literal-extents.json', extents), 'unchanged_contexts': contexts, 'integration_contract': doc('integration-contract.json', contract),
    'seal_waits_actual21_and_committed_HEAD': True, 'author_Source': ref(Path(__file__)), 'main_mutations': 0, 'Cargo_Native_or_tests_executed': False, 'new_tests': 0}
print(json.dumps(doc('draft.json', draft)))

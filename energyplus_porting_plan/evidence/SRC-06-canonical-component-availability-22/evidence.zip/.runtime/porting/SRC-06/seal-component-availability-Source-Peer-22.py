"""Seal only the component-availability successor on committed/actual21."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
HEAD = '50bcffc134ee4c60bedb77ce2ea8ba3cc83737f3'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'source-component-availability-held-Peer-22'

def ref(p):
    b = p.read_bytes(); return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def check(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', got['bytes']), row
    return p
def load(row): return json.loads(check(row).read_bytes())
def put(name, b):
    p = O / name; assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b); return ref(p)
def doc(name, obj): return put(name, (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())
def git(p): return subprocess.check_output(['git', 'show', HEAD + ':' + p], cwd=R)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == HEAD
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=R, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
root_ref = ref(D / 'Root-source-controlled-prediction-actual-review-21/review.json')
assert root_ref['sha256'] == '459bd7e7f37a7cb9528198687be451a7fecfc9e9155b83f246e2229a6a76195b'
root = load(root_ref); assert root['accepted'] and not root['findings']
assert root['B_frontier'] == 'GetHeatBalanceInput: actual ZoneCompAvailMgrs positive allocation405'
B_ref, A_ref = root['actual_B'], root['actual_A24']; B, A = load(B_ref), load(A_ref)
assert B_ref['sha256'] == '7f465ed1c71ef20cec1d96565e913c7d142ccb41b1f8f229ab9a305b8aa4b25f'
assert B['exit_code'] == 6 and A['exit_code'] == 0 and B['launch_error'] is None and A['launch_error'] is None
assert B['source_bytes_match_before_and_after'] and A['source_bytes_match_before_and_after']
assert B['source_snapshot']['sha256'] == A['source_snapshot']['sha256'] == '8f2b4e4d0d5b0f81fa2647028d886510428d9641aacc928f5b8b3132a43d0606'
snapshot_ref = B['source_snapshot']; snapshot = load(snapshot_ref)
observed = {row['historical_path']: row for row in snapshot['files']}
assert len(observed) == len(snapshot['files']) == 4490 and sum(p.endswith('.rs') for p in observed) == 4477
draft_ref = ref(D / 'source-component-availability-draft-Peer-22/draft.json')
assert draft_ref['sha256'] == '06d761ffc79f81232710ca1d632810750f82913b1c95c482d8304ac3c907661c'
draft = load(draft_ref); parent = load(draft['parent21_producer']); parent_plan = load(draft['parent21_plan'])
parents = {row['path']: row for row in parent_plan['entries']}; assert set(parents) == set(observed)
for p, row in parents.items():
    b = check(row['source']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == row['final_sha256'] and len(b) == row['final_bytes']
    assert b == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes(), p
paths = set((R / 'crates').rglob('*.rs')) | set((R / 'crates').rglob('Cargo.toml'))
for p in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml']:
    if (R / p).is_file(): paths.add(R / p)
assert {p.relative_to(R).as_posix() for p in paths} == set(observed)
assert P + 'source_output_registration/report_diagnostics.rs' not in observed
assert not (R / (P + 'source_output_registration/report_diagnostics.rs')).exists()
assert len(draft['files']) == draft['existing_Source_files'] == 1 and not draft['new_Source_files']
assert not O.exists(); O.mkdir()
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal>', 'exec'), ns)
row = draft['files'][0]; p = row['canonical_path']; old, new = check(row['before']).read_bytes(), check(row['proposed']).read_bytes()
assert old == check(row['parent21']).read_bytes() == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes() == git(p)
f, inv = check(row['forward_diff']).read_bytes(), check(row['inverse_diff']).read_bytes()
assert ns['apply_literal'](old, f) == new and ns['apply_literal'](new, inv) == old
parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
assert parsed.returncode == 0 and not parsed.stderr
added = ''.join(line[1:] for line in f.decode().splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
assert not re.search(r'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)!|#\[test\]|\.runtime[/\\]', added)
file = {'canonical_path': p, 'before_absent': False, 'before': put('before/' + p, old), 'proposed': put('proposed/' + p, new), 'literal_inverse': put('literal-inverse/' + p, old),
    'forward_diff': put('forward.diff', f), 'inverse_diff': put('inverse.diff', inv), 'actual21_archive': observed[p]['archive'], 'committed21_Git_and_actual21_and_live_before_whole_equal': True,
    'Source_only_parse': {'exit_code': 0, 'stdout': put('parse.stdout', parsed.stdout), 'stderr': put('parse.stderr', parsed.stderr)}}
entries, hits = [], []
patterns = ['SourceAvailability', 'SourceZoneComponentManager', 'zone_components', 'manager_list_name', 'get_source_inputs(', 'manage_source_system_availability(']
for path in sorted(observed):
    source = file['proposed'] if path == p else observed[path]['archive']; b = check(source).read_bytes()
    entries.append({'path': path, 'final_sha256': source['sha256'], 'final_bytes': len(b), 'source': {**source, 'bytes': len(b)},
        'origin': 'selected22 genuine component availability Source' if path == p else 'whole exact actual21 archived parent'})
    if path.endswith('.rs'):
        for number, line in enumerate(b.decode().splitlines(), 1):
            found = [pattern for pattern in patterns if pattern in line]
            if found: hits.append({'path': path, 'line': number, 'literal': line, 'patterns': found})
assert sum('manage_source_system_availability(' in row['patterns'] for row in hits) == 2
assert sum('get_source_inputs(' in row['patterns'] for row in hits) == 2
plan_ref = doc('complete-final-compiler-Source-plan.json', {'base_HEAD': HEAD, 'parent_actual_snapshot': snapshot_ref, 'inputs': 4490, 'Rust_sources': 4477,
    'entries': entries, 'Root_full_rehash_required': True})
api_ref = doc('whole-crates-concrete-API-inventory.json', {'Rust_sources': 4477, 'all4490_before_and_final_wholes_rehashed': True, 'includes_all_crates_runtime_and_tests': True,
    'occurrences': hits, 'signature_changes': 0, 'new_owner_or_field': 0, 'new_tests': 0, 'same_hybrid_owner': 'SourceHvacManager.ancillary.hybrid_ventilation.number_hybrid_ventilation_managers',
    'actual_component_manager_ctor_writes': 'Only current Source::default and same genuine count-sized allocation405; existing beginEnvironment/reset consumers retain the exact same rows.'})
contexts = []
for row in draft['unchanged_contexts']:
    path = row['canonical_path']; b = check(row['frozen']).read_bytes()
    assert path != p and b == check(observed[path]['archive']).read_bytes() == git(path) == (R / path).read_bytes()
    contexts.append({'canonical_path': path, 'whole': put('context/' + path, b), 'actual21_archive': observed[path]['archive'], 'committed21_Git_and_actual21_and_live_whole_equal': True})
native, native_bytes = [], {}
for row in draft['Native_wholes']:
    path = row['Native_path']; b = check(row['whole']).read_bytes()
    assert b == subprocess.check_output(['git', 'show', PIN + ':' + path], cwd=N) == (N / path).read_bytes()
    native_bytes[path] = b; native.append({'Native_path': path, 'revision': PIN, 'whole': put('Original-Git/' + path, b)})
extents = load(draft['Native_literal_extents'])
for row in extents:
    b = b''.join(native_bytes[row['native_path']].splitlines(keepends=True)[row['first']-1:row['last']])
    assert b.decode() == row['literal'] and hashlib.sha256(b).hexdigest() == row['utf8_sha256']
for path, first, last in [('src/EnergyPlus/SystemAvailabilityManager.cc', 110, 135), ('src/EnergyPlus/InputProcessing/InputProcessor.cc', 1398, 1477)]:
    b = b''.join(native_bytes[path].splitlines(keepends=True)[first-1:last])
    extents.append({'native_path': path, 'first': first, 'last': last, 'utf8_sha256': hashlib.sha256(b).hexdigest(), 'literal': b.decode()})
source = new.decode()
ctor = source.split('impl Default for SourceZoneComponentManager {', 1)[1].split('\n}', 1)[0]
assert ctor == old.decode().split('impl Default for SourceZoneComponentManager {', 1)[1].split('\n}', 1)[0]
assert 'row.managers = Some(vec![SourceZoneComponentManager::default(); count]);' in source
assert source.index('if manager.zone_number == 0') < source.index('if self.ancillary.hybrid_ventilation.number_hybrid_ventilation_managers == 0')
ledger_ref = doc('complete-component-constructor-and-lifecycle-ledger.json', {'Native_header': 'SystemAvailabilityManager.hh412–431', 'complete_nine_fields': [
    ['NumAvailManagers', 'number_managers', 0], ['availStatus', 'status', 'Status::NoAction=0'], ['StartTime', 'start_time', 0], ['StopTime', 'stop_time', 0],
    ['AvailManagerListName', 'manager_list_name', 'empty String'], ['availManagers', 'managers', 'unallocated None'], ['ZoneNum', 'zone_number', 0], ['Input', 'input', True], ['Count', 'count', 0]],
    'ZoneCompTypeData': [['ZoneCompAvailMgrs', 'managers', 'unallocated None'], ['TotalNumComp', 'total_components', 0]],
    'all_constructor_and_default_source_bytes_unchanged': True,
    'positive_allocation': 'Actual getNumObjectsFound stored TotalNumComp first; positive count converted exactly, then full genuine constructor cloned into each distinct real row. No zero-size positive vector.',
    'manage_status_order': 'NumAvailManagers>0 saves actual previous status then NoAction before typed first availManagers(1)268; zero manager branch writes NoAction287.',
    'hybrid_short_circuit': 'ZoneNum0 skips hybrid read entirely; otherwise same actual ancillary hybrid count governs first row298 typed boundary. No flags/counts inferred or overwritten.',
    'input_flags': 'get_input_flag remains true until get_source_inputs complete; then actual caller clears and first ManageSystemAvailability returns. Per-component Input/Count stay original ctor state until genuine later GetZoneEq caller exists.'})
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
manifest = {'schema': 'src06-held-cohesive-component-availability.v1', 'status': 'HELD Source only; compilation/actual22 pending', 'base_HEAD': HEAD,
    'actual21_review': root_ref, 'actual21_snapshot': snapshot_ref, 'actual21_B': B_ref, 'actual21_A24': A_ref, 'actual21_complete_plan': draft['parent21_plan'],
    'parent21_producer': draft['parent21_producer'], 'files': [file], 'existing_Source_files': 1, 'new_Source_files': 0, 'literal_applications': 2, 'Source_only_parses': 1,
    'complete_final_compiler_Source_plan': plan_ref, 'whole_crates_API_inventory': api_ref, 'Native_commit': PIN,
    'Native_wholes': [{**ref(N / row['Native_path']), 'whole_equals_git': True} for row in native], 'frozen_Native_wholes': native,
    'Native_literal_extents': doc('Native-literal-extents.json', extents), 'unchanged_contexts': contexts, 'constructor_and_lifecycle_ledger': ledger_ref,
    'integration_contract': put('integration-contract.json', check(draft['integration_contract']).read_bytes()), 'unsealed_author_draft': draft_ref,
    'author_Source': draft['author_Source'], 'sealer_Source': ref(Path(__file__)), 'new_test_bodies': 0, 'Cargo_Native_or_tests_executed': False,
    'main_mutations': 0, 'FP_tolerance_or_gate_changes': False, 'full_B_or_positive_Node_execution_claim': False}
print(json.dumps(doc('manifest.json', manifest)))

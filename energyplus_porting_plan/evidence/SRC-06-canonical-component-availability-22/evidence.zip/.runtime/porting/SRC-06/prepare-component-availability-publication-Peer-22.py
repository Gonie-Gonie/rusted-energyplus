"""Prepare minimal held publication22 only; no publisher/main/Cargo execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'component-availability-publication-prepared-Peer-22'
OLD = D / 'publish-controlled-prediction-checkpoint-Outer-21.py'
NEW = D / 'publish-component-availability-checkpoint-Peer-22.py'

def ref(p):
    b = p.read_bytes(); return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def checked(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', row.get('size_bytes', got['bytes'])), row
    return p
def write(p, obj): p.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())

assert not O.exists() and not NEW.exists()
parent_ref = ref(OLD)
assert parent_ref['sha256'] == '525f2b7a288a1e6c02ee11924eb851fcc74975de934fa2917c1f53399112e70f'
producer_ref = ref(D / 'source-component-availability-held-Peer-22/manifest.json')
assert producer_ref['sha256'] == '529c9857848d73f4177ac3d38571962bb78375029fc99044607470a7bf49af2a'
producer = json.loads(checked(producer_ref).read_bytes())
application_ref = ref(D / 'Root-component-availability-application-22/receipt.json')
assert application_ref['sha256'] == '8cc469bf616cc5e76b715f03e960ee758581798271da6deece7fe5651a011464'
application = json.loads(checked(application_ref).read_bytes())
assert application['accepted'] and not application['findings']
assert application['base_HEAD'] == producer['base_HEAD'] == '50bcffc134ee4c60bedb77ce2ea8ba3cc83737f3'
assert application['producer'] == producer_ref
peer_ref = application['independent_peer']; peer = json.loads(checked(peer_ref).read_bytes())
assert peer['accepted'] and not peer['findings']
old = OLD.read_bytes().decode()
text = old
replacements = [
    ('checkpoint21', 'checkpoint22'),
    ('controlled-prediction-publication-prepared-Outer-21', 'component-availability-publication-prepared-Peer-22'),
    ('SRC-06-canonical-controlled-prediction-21', 'SRC-06-canonical-component-availability-22'),
    ('controlled-prediction-publication-readback-Outer-21', 'component-availability-publication-readback-Peer-22'),
    ('80e68ac8b55fd21ff1c754849cbd34b23fafa45b', '50bcffc134ee4c60bedb77ce2ea8ba3cc83737f3'),
    ("len(producer['files']) == 4 and producer['existing_Source_files'] == 4 and producer['new_Source_files'] == 0", "len(producer['files']) == 1 and producer['existing_Source_files'] == 1 and producer['new_Source_files'] == 0"),
    ('Root-source-controlled-prediction-actual-review-21', 'Root-source-component-availability-actual-review-22'),
    ('selected4_final_sources_exact', 'selected1_final_sources_exact'),
    ('canonical-source-controlled-prediction-B-NOLIMIT-24H-Root-21', 'canonical-source-component-availability-B-NOLIMIT-24H-Root-22'),
    ('canonical-source-controlled-prediction-A-24H-Root-21', 'canonical-source-component-availability-A-24H-Root-22'),
    ('canonical21-finite', 'canonical22-finite'),
    ('4 coherent controlled predicted-load Sources', '1 coherent component availability Source'),
    ('src06-canonical-controlled-prediction.v1', 'src06-canonical-component-availability.v1'),
    ('Genuine Source controlled predicted-load path', 'Genuine Source component availability lifecycle'),
    ('positive controlled predicted-load Native numerical equivalence', 'positive component-availability Native state equivalence'),
    ('canonical_controlled_prediction_21', 'canonical_component_availability_22'),
    ('[Source 제어 부하 예측 검증]', '[Source 설비 가용성 경로 검증]'),
    ('accepted19', 'accepted21'),
    ('equal19', 'equal21'),
]
for before, after in replacements:
    assert before in text, before
    text = text.replace(before, after)
assert 'equal19' not in text and 'accepted19' not in text
assert 'Root-source-controlled-prediction-actual-review-21' not in text
assert 'canonical_controlled_prediction_21' not in text
ast.parse(text)
assert '\ufffd' not in text
NEW.write_bytes(text.encode())

inputs = {}
def add(row):
    p = checked(row); got = ref(p)
    assert p.suffix.lower() != '.zip'
    assert not any(token in got['path'] for token in ['controlled-air-native', 'source-controlled-zone-numerical-draft', 'source-CalcMoreNodeInfo-draft'])
    assert got['path'] not in inputs or inputs[got['path']] == got
    inputs[got['path']] = got

add(producer_ref)
for key in ['complete_final_compiler_Source_plan', 'whole_crates_API_inventory', 'integration_contract', 'Native_literal_extents', 'constructor_and_lifecycle_ledger', 'author_Source', 'sealer_Source']:
    add(producer[key])
for row in producer['Native_wholes']: add(row)
for row in producer['unchanged_contexts']: add(row['whole'])
for row in producer['files']:
    for key in ['before', 'proposed', 'literal_inverse', 'forward_diff', 'inverse_diff']: add(row[key])
    for key in ['stdout', 'stderr']: add(row['Source_only_parse'][key])
previous = ref(R / 'energyplus_porting_plan/evidence/SRC-06-canonical-controlled-prediction-21/summary.json')
add(previous); add(application_ref); add(application['author_Source']); add(peer_ref); add(ref(Path(__file__)))
docs = {
    'CHECKLIST.md': '실제 설비 수만큼 가용성 상태를 할당하고 관리자 없는 설비의 처리 경로를 연결했습니다. B·A24 실행 결과와 남은 경계를 공개 요약에 기록합니다.',
    'STATE_CONTRACTS.md': '기존 가용성 소유자와 실제 생성자·입력 플래그를 사용합니다. 설비별 상태 초기화와 구역·하이브리드 조건의 원래 순서를 보존합니다.',
    'cards/SRC-06.md': '실제 B 미완료 경계는 `{{actual_B_frontier}}`입니다. 전체 B 완료와 Node 상태의 Native 검증은 아직 주장하지 않습니다.',
}
assert len(set(docs.values())) == 3
for value in docs.values():
    assert '?' not in value and '\ufffd' not in value
    assert sum('\uac00' <= ch <= '\ud7a3' for ch in value) > 10
template = {
    'schema': 'src06-held-canonical22-publication-template.v1',
    'status': 'HELD_FOR_ROOT_REVIEW_ACTUAL_AND_PEER_HASHES_REQUIRED',
    'base_HEAD': producer['base_HEAD'], 'producer': producer_ref, 'complete_plan': producer['complete_final_compiler_Source_plan'],
    'previous_checkpoint': previous, 'publisher_Source': ref(NEW), 'publisher_parent_Source': parent_ref,
    'expected_actual_review_path': '.runtime/porting/SRC-06/Root-source-component-availability-actual-review-22/review.json',
    'Root_application': application_ref, 'Root_application_Source': application['author_Source'],
    'accepted_independent_peer': peer_ref,
    'pending_Root_custody': {'actual_review_sha256': 'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source': 'REQUIRED_FROM_ACCEPTED_actual.author_Source',
        'launcher_Source': 'REQUIRED_FROM_ACCEPTED_actual.launcher_Source',
        'B_CLI': '.runtime/porting/SRC-06/canonical-source-component-availability-B-NOLIMIT-24H-command-Root-22/receipt.json',
        'A24_CLI': '.runtime/porting/SRC-06/canonical-source-component-availability-A-24H-command-Root-22/receipt.json'},
    'Root_custody_at_publish': 'Accepted actual.application -> application receipt and its author_Source; actual.author_Source -> checker; actual.launcher_Source -> launcher. All four directly byte-checked and archived, following accepted21 algorithm. Known application22 and its script are additionally pinned in this finite input inventory; no prior Root implementation substituted.',
    'summary_template': {'A': '14/54', 'B': '14/64', 'changed_Rust_sources': 1, 'existing_Rust_sources': 1, 'new_Rust_sources': 0,
        'new_test_functions': 0, 'actual_test_bodies_executed': 0,
        'focused_validation_policy': 'Two actual CLI runs B then A24. No unrelated test-profile rerun or habitual alltargets check.',
        'scope': 'Genuine same-owner positive component count-sized availability allocation, complete existing constructor rows and no-manager status lifecycle through return. Existing definitions/count order/GetInput latch and true ZoneNum/hybrid short circuits retained. No disconnected getter or readiness state.',
        'full_B_or_finite15_completion_claim': False, 'Native_harness_runtime_or_unit_equivalence_claim': False, 'gate_changes': False, 'policy_changes': False},
    'doc_appends': docs, 'finite_archive_inputs': [row for _, row in sorted(inputs.items())],
    'finite_archive_input_count': len(inputs), 'finite_archive_input_bytes': sum(row['bytes'] for row in inputs.values()),
    'publisher_executed': False, 'canonical_docs_mutations': False, 'Cargo_tests_Native_executed': False, 'gate_changes': False,
}
O.mkdir(); template_path = O / 'publication-template.json'; write(template_path, template)
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal>', 'exec'), ns)
diffs = {}
for kind, a, b in [('forward', old.encode(), text.encode()), ('inverse', text.encode(), old.encode())]:
    delta = ''.join(difflib.unified_diff(a.decode().splitlines(keepends=True), b.decode().splitlines(keepends=True), fromfile=OLD.name, tofile=NEW.name)).encode()
    assert ns['apply_literal'](a, delta) == b
    p = O / (kind + '.diff'); p.write_bytes(delta); diffs[kind] = ref(p)
bridge_path = O / 'publisher-parent-bridge.json'
write(bridge_path, {'parent': parent_ref, 'successor': ref(NEW), 'literal_applications': 2, 'changes': diffs,
    'scope': 'Checkpoint/path/one-source/proof21 labels, base commit and UTF8 link-title metadata only. Complete accepted21 archive/docs/SRC06-key algorithm unchanged.',
    'UTF8_Korean_appends_validated': True, 'publisher_executed': False, 'public_or_main_mutations': False})
print(json.dumps({'template': ref(template_path), 'publisher': ref(NEW), 'parent_bridge': ref(bridge_path)}))

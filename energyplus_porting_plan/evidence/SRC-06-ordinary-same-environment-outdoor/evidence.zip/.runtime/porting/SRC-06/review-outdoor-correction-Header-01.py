"""Independent one-expression correction review; read-only canonical access."""
from pathlib import Path
import difflib
import hashlib
import json

root = Path.cwd()
name = '.runtime/porting/SRC-06/ordinary-same-environment-outdoor-correction-prep-01/manifest.json'
output = '.runtime/porting/SRC-06/Header-ordinary-same-environment-outdoor-correction-Source-review-01/review.json'

def read(path):
    return (root/path).read_bytes()

def ref(path):
    data = read(path)
    return {'path': path, 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

assert ref(name) == {'path': name, 'sha256': '9ab8fa83c2d7d1c5081ffa8a97c456fe791425c416ca3c407413ca26dca83169', 'size_bytes': 2844}
m = json.loads(read(name))
count = 0
def walk(value):
    global count
    if isinstance(value, dict):
        if {'path', 'sha256', 'size_bytes'} <= value.keys():
            assert ref(value['path']) == {k: value[k] for k in ('path', 'sha256', 'size_bytes')}
            count += 1
        else:
            for child in value.values(): walk(child)
    elif isinstance(value, list):
        for child in value: walk(child)
walk(m)
assert len(m['files']) == 1
row = m['files'][0]
before, after = read(row['before']['path']), read(row['proposal']['path'])
assert read(row['canonical_path']) == before
prior = json.loads(read(m['prior_actual_assembly']['path']))
prior_row = next(item for item in prior['files'] if item['canonical_path'] == row['canonical_path'])
assert before == read(prior_row['after']['path'])
old = b'''    if let Some(driver) = weather_driver
        && let Err(error) = driver.finish_environment()
    {
        crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
            state,
            initialization.as_deref_mut(),
        );
        return Err(error);
    }'''
new = old.replace(b'initialization.as_deref_mut()', b'initialization')
assert before.count(old) == after.count(new) == 1
assert before.replace(old, new) == after and after.replace(new, old) == before
assert b'initialization' not in after[after.index(new)+len(new):]
actual_diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
    fromfile=row['canonical_path'], tofile=row['canonical_path'])).encode()
assert actual_diff == read(row['complete_diff']['path'])
qa = []
for item, expected in zip(m['prior_QA_receipts'], [0, 0, 101]):
    receipt = json.loads(read(item['path']))
    assert receipt['exit_code'] == expected and receipt['source_bytes_match_before_and_after'] is True
    logs = []
    for key in ('stdout', 'stderr'):
        log = ref(receipt[key]['path'])
        assert log['sha256'] == receipt[key]['sha256']
        logs.append(log)
    qa.append({'receipt': item, 'actual_exit_code': expected, 'logs': logs,
        'Source_snapshot': receipt['source_snapshot']})
assert len({item['Source_snapshot']['sha256'] for item in qa}) == 1
assert b'needless_option_as_deref' in read(qa[2]['logs'][1]['path'])
assert m['new_test_bodies'] == 0 and m['gates_updated'] is False
report = {'schema': 'src06-independent-outdoor-correction-Source-review.v1',
    'accepted': True, 'findings': [], 'preparation_manifest': ref(name),
    'prior_actual_assembly': m['prior_actual_assembly'],
    'prior_application_review': m['prior_application_review'], 'files': m['files'],
    'verification': {'direct_refs_authenticated': count, 'exact_current_before': True,
        'actual_Source01_runtime_join': True, 'whole_forward_and_inverse_exact': True,
        'complete_diff_regenerated_exact': True, 'literal_replacements': 1,
        'no_later_initialization_use': True, 'new_test_bodies': 0},
    'rationale': 'At the final finish_environment Err branch, Option<&mut Context> is consumed directly into the unchanged retain_failed_state call. The branch immediately returns the same error. No later code uses initialization, so earlier reborrows, same reached State custody, owner identity, scientific arithmetic and successful return are unchanged. No lint allowance is introduced.',
    'historical_QA': qa,
    'qualification': 'Source01 fmtcheck and quality were actual0; Clippy was actual101 on this one needless Option dereference. This is a Source-only correction review, not a new compiler/test result. No tests on Source01 or future corrected-source QA are inferred.',
    'canonical_mutated': False, 'compiler_tests_engine_executed': False,
    'reviewer': ref(Path(__file__).relative_to(root).as_posix())}
assert not (root/output).exists()
(root/output).parent.mkdir(parents=True, exist_ok=True)
(root/output).write_bytes((json.dumps(report, indent=2)+'\n').encode())
print(json.dumps(ref(output)))

"""Publish one actual same-environment outdoor assembly and affected QA."""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

root = Path.cwd()
base = root/'.runtime/porting/SRC-06'
out = root/'energyplus_porting_plan/evidence/SRC-06-ordinary-same-environment-outdoor'
assembly_path = base/'ordinary-same-environment-outdoor-assembly-02/manifest.json'
review_path = root/sys.argv[1]
review_sha, assembly_sha = sys.argv[2:]
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(), 'sha256':hashlib.sha256(data).hexdigest(), 'size_bytes':len(data)}
def load(path): return json.loads(path.read_bytes())
def write(path, value): path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode())
def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value: yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value, list):
        for child in value: yield from walk(child)

assert ref(assembly_path)['sha256'] == assembly_sha
assert ref(review_path)['sha256'] == review_sha and load(review_path)['accepted'] is True
assert any(row['sha256'] == assembly_sha for row in walk(load(review_path)))
assembly = load(assembly_path)
held_path = root/assembly['accepted_packet']['path']
assert ref(held_path)['sha256'] == '228825afb936cb3e28b7d0d226a1a039fc59909bdd948f10bd4302575f1fa3b6'
parent_path = base/'ordinary-same-environment-outdoor-prep-01/manifest.json'
assert ref(parent_path)['sha256'] == '92d5f11bbd05014ae16de26b8f02d69e0a42b417a2ccb756dbe1022d994f5a23'
detail = assembly['additional_provenance']
prior_path = root/detail['prior_actual_assembly']['path']
artifacts, historical, archives = {}, {}, {}
for version in [assembly, load(prior_path)]:
    for row in version['files']:
        for key in ['before', 'after', 'accepted_proposal']:
            value = row[key]
            archives[value['sha256']] = root/value['path']
for path in [held_path, parent_path]:
    for row in load(path)['files']:
        for key in ['before', 'proposal']:
            if row[key] is not None:
                value = row[key]
                archives[value['sha256']] = root/value['path']

def add(path):
    value = ref(path)
    artifacts[value['path']] = value
    return value
def checked(row):
    path = root/row['path']
    if not path.is_file() or ref(path)['sha256'] != row['sha256']:
        path = archives[row['sha256']]
        historical[row['path']+row['sha256']] = {'historical_reference':row, 'exact_archive':ref(path),
            'qualification':'Immutable exact historical bytes, not relabeled current.'}
    value = ref(path)
    assert value['sha256'] == row['sha256'] and value['size_bytes'] == row.get('size_bytes', value['size_bytes'])
    return path

paths = [assembly_path, held_path, parent_path, root/assembly['independent_Source_review']['path'],
         review_path, root/assembly['apply']['path'], prior_path, root/load(prior_path)['apply']['path']]
paths.extend(root/detail[key]['path'] for key in ['correction_packet', 'independent_correction_Source_review', 'prior_application_review'])
for path in paths:
    add(path)
    for row in walk(load(path)): add(checked(row))
for row in assembly['files']: assert ref(root/row['canonical']['path']) == row['canonical']
historical_qa = []
for row in detail['prior_QA_receipts']:
    path = checked(row)
    value = load(path)
    assert value['source_bytes_match_before_and_after'] is True
    historical_qa.append({'receipt':ref(path), 'exit_code':value['exit_code'],
        'qualification':'Actual Source01 result, not final Source02. No tests executed on Source01.'})
    add(path)
    for key in ['stdout', 'stderr', 'source_snapshot']: add(checked(value[key]))
assert [row['exit_code'] for row in historical_qa] == [0,0,101]
add(base/'run-ci-force-time-step-Root-01.ps1')
cargo = 'C:/Users/GonieGonie/.cargo/bin/cargo.exe'
expected = {
    'fmt':[cargo,'fmt','--all','--','--check'],
    'quality':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1'],
    'clippy':[cargo,'clippy','--workspace','--all-targets','--','-D','warnings'],
    'focused-tests':[cargo,'test','-p','ep_runtime','--lib','--',
        'heat_balance::convection::surface_environment::ordinary::tests::',
        'ordinary_cache_uses_real_registry_columns_and_postlude_before_lifecycle'],
    'cli-tests':[cargo,'test','-p','ep_run','--test','arbitrary_run','one_zone_runtime_writes_stable_output_layout'],
    'ci-timestep-tests':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','.runtime/porting/SRC-06/run-ci-force-time-step-Root-01.ps1'],
}
qa, tests, snapshot = [], [], None
for suffix, command in expected.items():
    path = base/f'ordinary-same-environment-outdoor-{suffix}-02/receipt.json'
    value = load(path)
    assert value['command'] == command
    assert value['exit_code'] == 0 and value['launch_error'] is None and value['source_bytes_match_before_and_after'] is True
    if snapshot is None: snapshot = value['source_snapshot']
    assert snapshot == value['source_snapshot']
    qa.append({'receipt':ref(path), 'command':command, 'exit_code':0})
    add(path)
    for key in ['stdout', 'stderr', 'source_snapshot']: add(checked(value[key]))
    if 'tests' in suffix:
        groups = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', checked(value['stdout']).read_text(encoding='utf8'))]
        assert groups == [(5 if suffix == 'focused-tests' else 1, 0, 0)]
        tests.append({'scope':suffix, 'passed':groups[0][0], 'failed':0, 'ignored':0})
assert [row['passed'] for row in tests] == [5,1,1]
add(Path(__file__))
out.mkdir()
archive = out/'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts): z.write(root/name, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(artifacts)
    for name in z.namelist(): assert hashlib.sha256(z.read(name)).hexdigest() == artifacts[name]['sha256']
write(out/'manifest.json', {'schema':'src06-same-environment-outdoor-evidence.v1', 'Source_snapshot':snapshot,
    'assembly':ref(assembly_path), 'artifacts':list(artifacts.values()), 'historical_references':list(historical.values()),
    'archive':ref(archive), 'archive_member_count':len(artifacts),
    'archive_scope':'Eight actual full Source02 before/after files and final/formatter diffs, immutable Source01 custody and one literal Option correction; two finite preparations and their exact proposal custody; five literal Original ranges; independent Source/application/correction reviews; six final and three genuine historical QA receipts/logs/Source indexes. Older HB full archives and Native objects are referenced rather than recursively bundled.',
    'gates_updated':False})
write(out/'summary.json', {'schema':'src06-same-environment-outdoor-summary.v1',
    'status':'Actual same-production-environment Zone/Surface outdoor setters and moved failed-State custody connected; full InitHeatBalance pending',
    'Source_snapshot':snapshot, 'behavior':[
        'The constructor, warmup and run-period outdoor calls borrow the same retained production weather session and its actual Station/Site parameters. Current weather is bit-joined to that session; no second Zone/weather owner or default terrain substitution is used for Source-connected owners.',
        'The sole retained Zone array is updated in Original bulk order: every dry/wet temperature, first reached cold guard/fatal, every wind speed and every wind direction. Existing Surface setters follow only after that successful Zone return.',
        'Actual complete Zone-ID sets, centroids, linked-node/EMS exclusion and Surface identity/order are validated before writes. Legacy callers without either Source owner preserve the existing surface-only route.',
        'On fallible post-initializer preparation, initial outdoor, warmup, run-period or final-weather return, the sole Source-connected State moves into one Rust host Option<Box<HeatBalanceState>> in retained reports. Completed Zone/Surface/global/Solar owners survive without cloning or changing the actual error. The slot is not an Original flag or a retry permission.',
    ], 'QA':qa, 'historical_QA':historical_qa, 'tests':{'selections':tests, 'passed':7, 'failed':0, 'ignored':0, 'new_bodies':0, 'new_binaries':0},
    'validation_scope':'One filtered runtime lib command executes four existing outdoor guard tests and one existing initializer-table test; normal CLI1 and actual CI_FORCE_TIME_STEP=Y CLI1. Three existing bodies extended. One fmt/source-quality/all-target workspace Clippy. No full workspace-test repeat or new Native execution; earlier successes not recounted.',
    'limitations':[
        'Full GetSurfaceData/SetupZoneGeometry, GetHeatBalanceInput, InitHeatBalance, SetupSimulation, numerical inside/radiation/HVAC and whole-port completion remain pending.',
        'Cold/fatal tests certify actual in-call Zone prefixes; the existing initializer-table row separately certifies move-only allocation custody using actual initialized Surface/Solar plus clearly authored Zone/global payload. It is not a captured Native error endpoint or a forced public whole-runtime failure.',
        'The Rust host retains the most recent failed Source-connected State. Legacy/manual failures retain their previous behavior; no new retry guarantee is introduced.',
        'Preparation01 is preserved with its CRLF proposal conversion and imprecise historical HB02/HB47 labels. Preparation02 authenticates the actual complete HB48 Source03 on clean c5c4ab18 and preserves LF. Historical language is not a remaining HB blocker.',
        'Actual Source01 fmt/quality passed and Clippy failed101 on the final needless_option_as_deref; no tests ran on that Source. Reviewed Source02 passes the same final context directly into failed-State custody, with no later use and no owner/math/error/assertion change. Original failed receipt and all Source01 bytes remain preserved.',
        'Whole ordinary235456 mismatches/2754 unavailable and DesignDay nine strict failures/eight UNPAIRED remain unchanged. SRC06 four gates stay unverified; A14/54 B14/64 unchanged.',
    ], 'independent_Source_review':assembly['independent_Source_review'], 'independent_application_review':ref(review_path),
    'manifest':ref(out/'manifest.json'), 'archive':ref(archive), 'gates_updated':False})
plan_path = root/'energyplus_porting_plan/plan.json'
plan = load(plan_path)
task = next(row for row in plan['tasks'] if row['id'] == 'SRC-06')
assert all(task[key] == '미확인' for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_same_environment_outdoor' not in task
task['actual_selected_ordinary_same_environment_outdoor'] = ref(out/'summary.json')
write(plan_path, plan)
card = root/'energyplus_porting_plan/cards/SRC-06.md'
text = card.read_text(encoding='utf8')
assert text.count('아래 21개 요약') == 1
text = text.replace('아래 21개 요약', '아래 22개 요약')
needle = '\n기존 Weather03·absent site/station'
assert text.count(needle) == 1
text = text.replace(needle, '| 동일 기상 상태 / Zone·Surface 외기와 오류 보존 | [요약](../evidence/SRC-06-ordinary-same-environment-outdoor/summary.json) · [색인](../evidence/SRC-06-ordinary-same-environment-outdoor/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-same-environment-outdoor/evidence.zip) | 동일 Station/Site/current와 Zone 온도→guard→풍속·풍향→기존 Surface. 실패한 실제 State를 이동 보존; 전체 InitHB/Setup·Native 수치 완료는 아님. |\n'+needle)
needle = '\n## 이력과 증거 보존'
assert text.count(needle) == 1
text = text.replace(needle, '\n## 동일 기상 상태 외기 연결 단위의 QA\n\nSource `'+snapshot['sha256']+'`에서 fmt·source-quality·all-target workspace Clippy와 기존 테스트 **7 passed / 0 failed / 0 ignored**를 확인했다. runtime 한 선택으로 기존 외기 guard4·초기화 table1을 묶고 일반 CLI1·실제 `CI_FORCE_TIME_STEP=Y` CLI1을 실행했다. 기존 본문3개에서 기상 매개변수·부호 있는0·cold fatal 이전 완료 온도/미실행 wind 및 실제 Surface/Solar와 작성한 Zone/global의 이동 보존을 검사했다. Source01 Clippy101과 이전 bytes/로그를 보존했고, 같은 마지막 컨텍스트를 직접 전달한 Source02에서 확인했다. 실제 전체 runtime 실패/새 Native endpoint는 이 PASS의 범위가 아니다. 새 본문·binary·전체 workspace 반복·새 Native 실행은 없다. 앞 단위 성공을 합산하지 않으며 모든 gate와 A/B 완료 수는 그대로다.\n'+needle)
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'), 'archive_members':len(artifacts), 'archive_bytes':archive.stat().st_size, 'tests':tests}, ensure_ascii=False))

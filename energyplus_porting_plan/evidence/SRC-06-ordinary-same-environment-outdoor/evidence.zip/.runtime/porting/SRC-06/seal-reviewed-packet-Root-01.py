"""Seal one actual formatted assembly; preserve exact before/proposal/current custody."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
out = root/sys.argv[1]
assert out.resolve().is_relative_to((root/'.runtime/porting/SRC-06').resolve())
assert not (out/'manifest.json').exists()
def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
apply = json.loads((out/'apply.json').read_bytes())
assert apply['HEAD']==subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
rows = []
for row in apply['files']:
    canonical = root/row['canonical_path']
    saved = out/'after'/row['canonical_path']
    saved.parent.mkdir(parents=True,exist_ok=True)
    saved.write_bytes(canonical.read_bytes())
    before = (root/row['before']['path']).read_bytes().replace(b'\r\n',b'\n').decode()
    after = saved.read_bytes().replace(b'\r\n',b'\n').decode()
    proposal = (root/row['accepted_proposal']['path']).read_bytes().replace(b'\r\n',b'\n').decode()
    refs = {}
    for name,first in [('complete_actual_diff',before),('held_to_actual_diff',proposal)]:
        path = out/name/(row['canonical_path'].replace('/','__')+'.diff')
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(''.join(difflib.unified_diff(first.splitlines(keepends=True),after.splitlines(keepends=True),
            fromfile=row['canonical_path'],tofile=row['canonical_path'])).encode())
        refs[name] = ref(path)
    rows.append({**row,'canonical':ref(canonical),'after':ref(saved),**refs})
value = {'schema':'src06-actual-finite-reviewed-assembly.v1','HEAD':apply['HEAD'],
    'status':'Actual finite assembly; awaiting actual QA','apply':ref(out/'apply.json'),
    'accepted_packet':apply['accepted_packet'],'independent_Source_review':apply['independent_Source_review'],
    'files':rows,'sealer':ref(Path(__file__)),'new_test_bodies':0,'gates_updated':False}
(out/'manifest.json').write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'assembly':ref(out/'manifest.json'),'files':len(rows)}))

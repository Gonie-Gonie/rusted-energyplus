"""Apply one finite reviewed Source packet, including authenticated new paths."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
packet_name, packet_sha, review_name, review_sha, output_name, expected_head = sys.argv[1:]
packet, review, out = root/packet_name, root/review_name, root/output_name
assert out.resolve().is_relative_to((root/'.runtime/porting/SRC-06').resolve())
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value: yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value,list):
        for child in value: yield from walk(child)
assert not subprocess.check_output(['git','status','--porcelain'])
head = subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head == expected_head
assert ref(packet)['sha256'] == packet_sha and ref(review)['sha256'] == review_sha
m, r = json.loads(packet.read_bytes()), json.loads(review.read_bytes())
assert r['accepted'] is True and any(value['sha256']==packet_sha for value in walk(r))
paths = [row['canonical_path'] for row in m['files']]
assert len(paths) == len(set(paths)) and paths
for row in m['files']:
    canonical = root / row['canonical_path']
    assert canonical.resolve().is_relative_to((root/'crates').resolve()) and canonical.suffix=='.rs'
    for key in ['proposal','complete_diff']:
        assert ref(root/row[key]['path'])['sha256']==row[key]['sha256']
    if row['before'] is None:
        assert not canonical.exists() and row.get('existed_before', False) is False
        assert subprocess.run(['git','cat-file','-e',head+':'+row['canonical_path']],capture_output=True).returncode!=0
    else:
        assert ref(root/row['before']['path'])['sha256']==row['before']['sha256']
        current = canonical.read_bytes()
        assert current.replace(b'\r\n',b'\n') == (root/row['before']['path']).read_bytes().replace(b'\r\n',b'\n')
        assert current==subprocess.check_output(['git','show',head+':'+row['canonical_path']])
out.mkdir()
rows = []
for row in m['files']:
    canonical = root/row['canonical_path']
    existed = canonical.exists()
    saved = out/'before'/row['canonical_path']
    saved.parent.mkdir(parents=True,exist_ok=True)
    saved.write_bytes(canonical.read_bytes() if existed else b'')
    canonical.parent.mkdir(parents=True,exist_ok=True)
    canonical.write_bytes((root/row['proposal']['path']).read_bytes())
    rows.append({'canonical_path':row['canonical_path'],'existed_before':existed,
        'before':ref(saved),'accepted_proposal':row['proposal'],'after_apply':ref(canonical)})
value = {'schema':'src06-finite-reviewed-apply.v2','HEAD':head,'accepted_packet':ref(packet),
    'independent_Source_review':ref(review),'files':rows,'author':ref(Path(__file__)),
    'predecessor':ref(root/'.runtime/porting/SRC-06/apply-reviewed-packet-Root-02.py'),
    'schema_compatibility':'A genuine before=None authenticates an absent new path even when preparation omits redundant existed_before. Canonical absence and Git object absence remain required. Historical author failure is recorded in its original HB application only.',
    'targets_executed':[]}
(out/'apply.json').write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'apply':ref(out/'apply.json'),'files':len(rows)}))

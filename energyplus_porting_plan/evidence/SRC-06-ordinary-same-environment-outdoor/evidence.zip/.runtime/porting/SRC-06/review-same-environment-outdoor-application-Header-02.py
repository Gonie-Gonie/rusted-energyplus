"""Independent narrow final application review, no target execution."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

root = Path.cwd()
base = '.runtime/porting/SRC-06/'
manifest = base + 'ordinary-same-environment-outdoor-assembly-02/manifest.json'
fmtpath = base + 'ordinary-same-environment-outdoor-fmt-02/receipt.json'
output = base + 'Header-ordinary-same-environment-outdoor-application-review-02/review.json'

def read(path):
    return (root/path).read_bytes()

def ref(path):
    data = read(path)
    return {'path': path, 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def check(value):
    actual = ref(value['path'])
    assert actual['sha256'] == value['sha256'], value['path']
    assert actual['size_bytes'] == value.get('size_bytes', actual['size_bytes']), value['path']
    return actual

assert ref(manifest) == {'path': manifest, 'sha256': '2dd2a0449b1b5867cbf7dbcafb8fccc423ef8247bc75a5ade699d341253f3099', 'size_bytes': 20555}
m = json.loads(read(manifest))
refs = set()
def walk(value):
    if isinstance(value, dict):
        if {'path', 'sha256'} <= value.keys():
            check(value)
            refs.add((value['path'], value['sha256']))
        else:
            for child in value.values(): walk(child)
    elif isinstance(value, list):
        for child in value: walk(child)
walk(m)
app = json.loads(read(m['apply']['path']))
walk(app)
provenance = m['additional_provenance']
assert app['additional_provenance'] == provenance
prior = json.loads(read(provenance['prior_actual_assembly']['path']))
prior_review = json.loads(read(provenance['prior_application_review']['path']))
assert prior_review['accepted'] is True
assert prior_review['actual_assembly'] == provenance['prior_actual_assembly']
correction = json.loads(read(provenance['correction_packet']['path']))
correction_review = json.loads(read(provenance['independent_correction_Source_review']['path']))
assert correction_review['accepted'] is True
assert correction_review['preparation_manifest'] == provenance['correction_packet']
old = {row['canonical_path']: row for row in prior['files']}
applied = {row['canonical_path']: row for row in app['files']}
assert len(m['files']) == len(old) == len(applied) == 8
details = []
same = 0
for row in m['files']:
    name = row['canonical_path']
    assert name in old and name in applied
    before = read(row['before']['path'])
    after = read(row['after']['path'])
    held = read(row['accepted_proposal']['path'])
    assert before == read(old[name]['before']['path'])
    assert after == read(name)
    assert row['after_apply'] == row['canonical']
    assert row['after_apply'] == applied[name]['after_apply']
    assert row['accepted_proposal'] == applied[name]['accepted_proposal']
    for key, first in [('complete_actual_diff', before), ('held_to_actual_diff', held)]:
        actual = ''.join(difflib.unified_diff(first.replace(b'\r\n', b'\n').decode().splitlines(True),
            after.replace(b'\r\n', b'\n').decode().splitlines(True), fromfile=name, tofile=name)).encode()
        assert actual == read(row[key]['path']), name
    if name == 'crates/ep_runtime/src/runtime.rs':
        correction_row = correction['files'][0]
        assert read(old[name]['after']['path']) == read(correction_row['before']['path'])
        assert row['accepted_proposal'] == correction_row['proposal']
        assert after == read(correction_row['proposal']['path'])
        assert read(row['held_to_actual_diff']['path']) == b''
    else:
        assert after == read(old[name]['after']['path'])
        assert read(row['complete_actual_diff']['path']) == read(old[name]['complete_actual_diff']['path'])
        assert read(row['held_to_actual_diff']['path']) == read(old[name]['held_to_actual_diff']['path'])
        same += 1
    details.append({'canonical': row['canonical'], 'saved_after': row['after'],
        'complete_actual_diff': row['complete_actual_diff'], 'held_to_actual_diff': row['held_to_actual_diff'],
        'whole_byte_equal_Source01': name != 'crates/ep_runtime/src/runtime.rs'})
assert same == 7
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == m['HEAD']
changed = {row[3:] for row in subprocess.check_output(['git', 'status', '--porcelain=v1', '-z', '--untracked-files=all'], cwd=root).decode().split('\0') if row}
assert changed == set(old)
fmt = json.loads(read(fmtpath))
assert fmt['command'] == ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'fmt', '--all', '--', '--check']
assert fmt['exit_code'] == 0 and fmt['launch_error'] is None and fmt['source_bytes_match_before_and_after'] is True
for key in ('stdout', 'stderr', 'source_snapshot'): check(fmt[key])
snapshot = json.loads(read(fmt['source_snapshot']['path']))
snapshot_rows = {row['historical_path']: row for row in snapshot['files']}
for row in m['files']:
    snap = snapshot_rows[row['canonical_path']]
    assert snap['archive']['sha256'] == row['canonical']['sha256']
    assert snap['size_bytes'] == row['canonical']['size_bytes']
    check(snap['archive'])
assert m['new_test_bodies'] == 0 and m['gates_updated'] is False
assert not (root/output).exists()
result = {'schema': 'src06-independent-same-environment-outdoor-application-review.v2',
    'accepted': True, 'findings': [], 'actual_assembly': ref(manifest), 'actual_application': m['apply'],
    'preparation_manifest': m['accepted_packet'], 'independent_Source_review': m['independent_Source_review'],
    'additional_provenance': provenance, 'Source_snapshot': check(fmt['source_snapshot']),
    'fmtcheck_receipt': ref(fmtpath),
    'verification': {'finite_unique_refs': len(refs), 'actual_paths': 8, 'current_equals_saved_after': 8,
        'whole_byte_equal_actual_Source01': 7, 'accepted_literal_correction_applied_exact': 1,
        'complete_actual_diff_regenerated': 8, 'held_to_actual_diff_regenerated': 8,
        'after_apply_equals_current_all_paths': 8, 'formatter02_changes_after_correction': 0,
        'final_Source_snapshot_selected_joins': 8, 'exact_git_changed_path_set': True},
    'files': details,
    'review_conclusion': 'The final runtime file is whole-byte exact to the accepted one-expression correction. Its final finish_environment Err branch consumes the same initialization Option, moves the same reached State into failure custody and returns the same error; no later use exists. All seven other full files and both families of their final diffs are byte-exact Source01. Thus prior complete Source/formatter reads are reusable; no scientific arithmetic, owner association, error prefix or assertion changes were added.',
    'qualifications': [
        'Source01 actual fmtcheck0/quality0/Clippy101 and no-test history are retained verbatim, not relabeled as final successful QA.',
        'Mutating fmt02 was a direct Root command without a separate recorded formatter receipt. Authenticated after_apply/current equality proves no new formatting delta; genuine fmtcheck02 closed0/stable and provides final Source custody.',
        'Assembly complete diffs retain the original c5c4ab18 before base; runtime accepted_proposal is the correction successor, while seven others retain original proposals. These are distinct provenance stages, not a claim that all were first applied again.',
        'Earlier README chronology, authored Zone/global custody test qualification, selected domain and unchanged unverified whole-port gates from Source review remain in force.',
        'Reviewer ran only finite Source authentication; no canonical mutation, compiler, Cargo, tests, checker, engine or Native target execution. Root final remaining QA is separate.'
    ], 'new_test_bodies': 0, 'canonical_mutated': False, 'targets_executed': False,
    'reviewer': ref(Path(__file__).relative_to(root).as_posix())}
(root/output).parent.mkdir(parents=True, exist_ok=True)
(root/output).write_bytes((json.dumps(result, indent=2)+'\n').encode())
print(json.dumps(ref(output)))

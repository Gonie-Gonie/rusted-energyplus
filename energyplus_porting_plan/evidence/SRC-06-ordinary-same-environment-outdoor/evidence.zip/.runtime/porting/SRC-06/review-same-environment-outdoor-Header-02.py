"""Independent finite Source authentication; never compiles or runs targets."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path.cwd()
MANIFEST = '.runtime/porting/SRC-06/ordinary-same-environment-outdoor-prep-02/manifest.json'
PIN = '228825afb936cb3e28b7d0d226a1a039fc59909bdd948f10bd4302575f1fa3b6'
OUT = ROOT / '.runtime/porting/SRC-06/Header-ordinary-same-environment-outdoor-Source-review-02/review.json'


def read(name):
    return (ROOT / name).read_bytes()


def ref(name):
    data = read(name)
    return {'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}


def git(*args, cwd=ROOT):
    return subprocess.run(['git', *args], cwd=cwd, check=True, capture_output=True).stdout


def lf(data):
    return data.replace(b'\r\n', b'\n')


def diff(before, after, fromfile, tofile):
    return ''.join(difflib.unified_diff(before.decode('utf-8').splitlines(True),
        after.decode('utf-8').splitlines(True), fromfile=fromfile, tofile=tofile)).encode('utf-8')


assert ref(MANIFEST) == {'path': MANIFEST, 'sha256': PIN, 'size_bytes': 20519}
m = json.loads(read(MANIFEST))
assert git('rev-parse', 'HEAD').decode().strip() == m['HEAD'] == 'c5c4ab18e4e20c62419f01f14c8340dfcf1eb427'
assert git('status', '--porcelain=v1') == b''
refs = {}


def walk(value):
    if isinstance(value, dict):
        if {'path', 'sha256', 'size_bytes'} <= value.keys():
            expected = {key: value[key] for key in ('path', 'sha256', 'size_bytes')}
            assert ref(value['path']) == expected, value['path']
            refs[value['path']] = expected
        else:
            for child in value.values():
                walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)


walk(m)
parent = json.loads(read(m['historical_parent_preparation']['path']))
old = {row['canonical_path']: row for row in parent['files']}
details = []
for row in m['files']:
    name = row['canonical_path']
    before = read(row['before']['path']) if row['before'] else b''
    after = read(row['proposal']['path'])
    if row['before']:
        assert read(name) == before, name
        assert lf(git('show', f"{m['HEAD']}:{name}")) == lf(before), name
        assert b'\r\n' not in before and b'\r\n' not in after, name
    else:
        assert not (ROOT / name).exists(), name
    assert diff(before, after, name if row['before'] else '/dev/null', name) == read(row['complete_diff']['path']), name
    prior = old.get(name)
    prior_bytes = read(prior['proposal']['path']) if prior else before
    assert diff(prior_bytes, after, prior['proposal']['path'] if prior else name,
        row['proposal']['path']) == read(row['exact_parent_diff']['path']), name
    tests_before = len(re.findall(rb'#\[test\]', before))
    tests_after = len(re.findall(rb'#\[test\]', after))
    assert tests_before == tests_after, name
    details.append({'canonical_path': name, 'base': row['before'], 'proposal': row['proposal'],
        'complete_diff': row['complete_diff'], 'exact_parent_diff': row['exact_parent_diff'],
        'current_base_exact': bool(row['before']), 'new_path_absent': row['before'] is None,
        'direct_and_parent_diff_regenerated_exact': True,
        'parent_equal_after_newline_normalization': lf(prior_bytes) == lf(after),
        'test_bodies_before_and_after': tests_before})

originals = []
blobs = {}
reference_root = ROOT / '.reference/energyplus-src/26.1.0'
for row in m['Original_ranges']:
    relative = row['source']['path'].split('.reference/energyplus-src/26.1.0/', 1)[1]
    key = (row['Original_git_commit'], relative)
    if key not in blobs:
        blobs[key] = git('show', f'{key[0]}:{key[1]}', cwd=reference_root)
        assert lf(blobs[key]) == lf(read(row['source']['path'])), relative
    literal = b''.join(blobs[key].splitlines(True)[row['line_start'] - 1:row['line_end']])
    assert literal == read(row['literal']['path']), relative
    originals.append({'source': row['source'], 'commit': key[0], 'line_start': row['line_start'],
        'line_end': row['line_end'], 'literal': row['literal'], 'Git_literal_and_full_file_LF_exact': True})

# Read-only structural assertions supplement the complete manual Source review.
rows = {row['canonical_path']: row for row in m['files']}
def proposal(name):
    return read(rows[name]['proposal']['path']).decode('utf-8')

runtime = proposal('crates/ep_runtime/src/runtime.rs')
ordinary = proposal('crates/ep_runtime/src/heat_balance/convection/surface_environment/ordinary.rs')
context = proposal('crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs')
assert runtime.count('retain_failed_state(') == 7
assert 'pub(crate) failed_heat_balance_state: Option<Box<super::state::HeatBalanceState>>' in context
assert 'failed_heat_balance_state = Some(Box::new(state))' in ordinary
assert '.clone()' not in ordinary[ordinary.index('pub(crate) fn retain_failed_state'):]
assert m['new_test_bodies'] == m['new_test_binaries'] == 0 and m['changed_existing_test_bodies'] == 3
assert git('status', '--porcelain=v1') == b''
assert not OUT.exists(), 'Review evidence is immutable; choose a fresh successor.'
report = {
    'schema': 'src06-independent-same-environment-outdoor-Source-review.v1',
    'accepted': True, 'findings': [], 'preparation_manifest': ref(MANIFEST),
    'HEAD': m['HEAD'], 'actual_HB_parent': m['actual_HB_parent'],
    'historical_parent_preparation': m['historical_parent_preparation'],
    'scope': 'Independent Source-only full eight-diff and affected-caller review; finite current-base/diff/Git-literal authentication. Not an application or numerical parity certificate.',
    'verification': {'unique_direct_refs_authenticated': len(refs), 'selected_paths': len(details),
        'direct_diffs_regenerated': 8, 'parent_diffs_regenerated': 8,
        'existing_bases_current_and_HEAD_LF_exact': 7, 'new_path_absent': 1,
        'Original_ranges_Git_exact': len(originals), 'Original_full_files_LF_exact': len(blobs),
        'clean_worktree_before_and_after': True, 'existing_newline_styles_preserved': True},
    'files': details, 'Original_ranges': originals,
    'reviewed_behavior': [
        'Legacy invocation retains its factory and effect order. Source invocation is selected only when both sole Source Zone and global owners exist; partial owner presence is an explicit error.',
        'Complete Surface association and complete Zone identity set/cardinality/name/centroid/linked-node association are validated before writes. The Source route requires real ordinary equipment and rejects actual EMS state.',
        'One retained production weather session is borrowed. Actual Station/Site return state and four Current weather bit patterns are checked; retained site/station coefficients feed both Zone and Surface updates without recreating them.',
        'Actual Zone row order is preserved: all temperature writes, cold check/error backend, wind factor and all wind writes, then all directions. Existing Surface producers follow. Exponent-zero, nonpositive height and signed-zero behavior retain literal Original branches.',
        'Cold failure retains reached bulk bulb values and diagnostics, leaves later wind/Surface writes unreached, and propagates the same backend error. No local environment, EMS override, full InitHeatBalance cadence or Setup completion is claimed.',
        'Seven fallible post-State runtime exits move the sole reached State into the one reports Box slot before returning the same error: missing equipment, initial outdoor, warmup preparation, inside-temperature preparation, warmup execution, run execution, and final weather finish. Earlier initializer errors retain their existing context prefix.',
        'Failure custody performs no scientific clone or reconstruction. Surface/Zone allocations, Solar/global owners and partial updates move together. The slot is Rust error custody, not an Original readiness flag or retry permission.',
        'Three existing test bodies are expanded without adding bodies or binaries: real Zone coefficient/order/partial-failure cases and actual initializer Surface/Solar plus explicitly authored Zone/global custody with allocation pointer identity. This source review does not establish an executed full-runtime error endpoint.'
    ],
    'chronology_qualification': 'The inherited README sentence saying HB47 must finish is historical Outdoor01 text. Outdoor02 manifest authority binds completed clean HB48 commit c5c4ab18 and actual Source03 befac98e; it is not a remaining blocker. Parent CRLF-to-LF differences are explicit exact parent diffs, not a claim of raw byte equality to Outdoor01.',
    'limitations': ['No compiler, formatter, tests, engine, checker, capture or target was executed by this reviewer.',
        'No Native observation or numerical/gate PASS is inferred from authored tests or Source correspondence.',
        'Failure custody is conditional on Source-connected State owner presence; legacy failure behavior remains as reviewed.'],
    'canonical_mutated': False, 'targets_executed': False,
    'reviewer_script': ref(Path(__file__).relative_to(ROOT).as_posix())
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes((json.dumps(report, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))
print(json.dumps(ref(OUT.relative_to(ROOT).as_posix())))

from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.runtime/porting/SRC-06'
PARENT=BASE/'ordinary-same-environment-outdoor-prep-01/manifest.json'
ACTUAL=BASE/'ordinary-hb-input-assembly-03/manifest.json'
OUT=BASE/'ordinary-same-environment-outdoor-prep-02'
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def check(item):
    actual=ref(ROOT/item['path'])
    assert all(item[key]==actual[key] for key in actual if key in item),item['path']
assert not OUT.exists()
head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True).stdout.strip()
assert head=='c5c4ab18e4e20c62419f01f14c8340dfcf1eb427'
assert not subprocess.run(['git','status','--porcelain=v1'],cwd=ROOT,capture_output=True,text=True,check=True).stdout
assert ref(PARENT)['sha256']=='92d5f11bbd05014ae16de26b8f02d69e0a42b417a2ccb756dbe1022d994f5a23'
assert ref(ACTUAL)['sha256']=='befac98ef8fadbaff474407f2f01543f3e6e1bc17053b074393ed6db1cee6c15'
parent=json.loads(PARENT.read_bytes())
actual=json.loads(ACTUAL.read_bytes())
actual_rows={row['canonical_path']:row for row in actual['files']}
pending=[]
proof=[]
def replace_once(text,old,new):
    assert text.count(old)==1,old[:100]
    return text.replace(old,new)
for row in parent['files']:
    for key in ['before','proposal','complete_diff']:
        if row[key] is not None:check(row[key])
    name=row['canonical_path']
    before=(ROOT/row['before']['path']).read_bytes() if row['before'] else None
    proposed=(ROOT/row['proposal']['path']).read_bytes()
    assert (ROOT/name).read_bytes()==before if before is not None else not (ROOT/name).exists()
    after=proposed.replace(b'\r\n',b'\n')
    if before is not None and b'\r\n' in before:
        after=after.replace(b'\n',b'\r\n')
    delta=None
    if name.endswith('/ordinary/source.rs'):
        old=b'|| state.zones.iter().any(|zone| !ids.contains(&zone.zone_id))'
        new=b'|| state.zones.iter().map(|zone| zone.zone_id).collect::<std::collections::BTreeSet<_>>() != ids'
        assert after.count(old)==1
        after=after.replace(old,new)
        assert after.replace(new,old)==proposed
        delta='Complete actual Zone ID set equality also rejects duplicated/missing state Zone IDs; retained Source row order stays intact.'
    else:
        assert after.replace(b'\r\n',b'\n')==proposed.replace(b'\r\n',b'\n')
    if name.endswith('/surface_environment/ordinary.rs'):
        text=after.decode()
        marker='/// Source-connected callers borrow the existing production session. Legacy\n'
        text=replace_once(text,marker,'''/// Rust failure custody for a moved Source-connected State. This is not an
/// Original readiness flag or a second live simulation owner.
pub(crate) fn retain_failed_state(
    state: HeatBalanceState,
    context: Option<&mut CtfInitializationContext<'_>>,
) {
    if (state.selected_zone_input.is_some() || state.selected_heat_balance_globals.is_some())
        && let Some(context) = context
    {
        context.reports.failed_heat_balance_state = Some(Box::new(state));
    }
}

'''+marker)
        after=text.encode()
        delta='One consumed move-only failed-State custody helper, only for Source-connected owners.'
    if name.endswith('/runtime.rs'):
        text=after.decode()
        text=replace_once(text,'''                crate::heat_balance::convection::surface_environment::ordinary::invoke_from_driver(
                    model,
                    &mut state,
                    initial_weather_context,
                    weather_driver,
                    initialization.as_deref_mut(),
                )?;''','''                if let Err(error) = crate::heat_balance::convection::surface_environment::ordinary::invoke_from_driver(
                    model,
                    &mut state,
                    initial_weather_context,
                    weather_driver,
                    initialization.as_deref_mut(),
                ) {
                    crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                        state, initialization.as_deref_mut(),
                    );
                    return Err(error);
                }''')
        text=replace_once(text,'''                if state.ordinary_equipment.is_none() {
                    return Err(RuntimeError::WarmupUnavailable {
                        reason: "missing retained geometry equipment owner".into(),
                    });
                }''','''                if state.ordinary_equipment.is_none() {
                    crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                        state, initialization.as_deref_mut(),
                    );
                    return Err(RuntimeError::WarmupUnavailable {
                        reason: "missing retained geometry equipment owner".into(),
                    });
                }''')
        text=replace_once(text,'''        crate::heat_balance::warmup::ordinary::prepare(
            model,
            &mut state,
            weather_driver,
            input,
            initialization
                .as_deref_mut()
                .ok_or_else(|| RuntimeError::WarmupUnavailable {
                    reason: "missing explicit ordinary output context".into(),
                })?,
        )?;
        crate::heat_balance::ordinary_inside_temperatures::prepare(''','''        let prepared = initialization.as_deref_mut()
            .ok_or_else(|| RuntimeError::WarmupUnavailable {
                reason: "missing explicit ordinary output context".into(),
            })
            .and_then(|context| crate::heat_balance::warmup::ordinary::prepare(
                model, &mut state, weather_driver, input, context,
            ));
        if let Err(error) = prepared {
            crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                state, initialization.as_deref_mut(),
            );
            return Err(error);
        }
        let prepared = crate::heat_balance::ordinary_inside_temperatures::prepare(''')
        text=replace_once(text,'''            reason: format!("ordinary temperature owner unavailable: {reason:?}"),
        })?;
    }
    let mut warmup_day_end_zone_air_states''','''            reason: format!("ordinary temperature owner unavailable: {reason:?}"),
        });
        if let Err(error) = prepared {
            crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                state, initialization.as_deref_mut(),
            );
            return Err(error);
        }
    }
    let mut warmup_day_end_zone_air_states''')
        start=text.index('    let warmup = run_heat_balance_run_period_warmup_with_reporting(')
        end=text.index('    let run_period_initial_zone_air_states =',start)
        body=text[start:end]
        body=replace_once(body,'    let warmup = run_heat_balance_run_period_warmup_with_reporting(',
            '    let warmup = match run_heat_balance_run_period_warmup_with_reporting(')
        body=replace_once(body,'''    )?;
''','''    ) {
        Ok(warmup) => warmup,
        Err(error) => {
            crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                state, initialization.as_deref_mut(),
            );
            return Err(error);
        }
    };
''')
        text=text[:start]+body+text[end:]
        text=replace_once(text,'    } = sample_heat_balance_run_period(',
            '    } = match sample_heat_balance_run_period(')
        text=replace_once(text,'''        initialization,
    )?;
    if let Some(driver) = weather_driver {
        driver.finish_environment()?;
    }''','''        initialization.as_deref_mut(),
    ) {
        Ok(sampled) => sampled,
        Err(error) => {
            crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                state, initialization.as_deref_mut(),
            );
            return Err(error);
        }
    };
    if let Some(driver) = weather_driver
        && let Err(error) = driver.finish_environment()
    {
        crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
            state, initialization.as_deref_mut(),
        );
        return Err(error);
    }''')
        after=text.encode()
        delta='Actual outdoor/warmup/run/final-weather errors move the sole Source-connected State into reports before returning the same error; no clone or new host.'
    if name in actual_rows:
        assert ref(ROOT/name)['sha256']==actual_rows[name]['canonical']['sha256']
    if before is not None:
        assert len(re.findall(rb'#\[test\]',before))==len(re.findall(rb'#\[test\]',after))
    pending.append((name,before,after))
    proof.append({'canonical_path':name,'parent_proposal_normalization_checked_before_explicit_successor_edits':True,
        'Source03_selected_file_exact':name in actual_rows,'explicit_logic_delta':delta,
        'existing_newline_style_preserved':True})

# The sole failed State slot is an explicit Rust error-custody owner, not an
# invented EnergyPlus flag. It retains the moved Zone/global/Solar owners.
name='crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs'
before=(ROOT/name).read_bytes()
assert name in actual_rows and ref(ROOT/name)['sha256']==actual_rows[name]['canonical']['sha256']
text=before.decode()
old='''    /// Actual partial Zone/Space arrays, moved only after initializer success.
'''
new='''    /// Rust failure custody after the Source-connected State has been moved.
    /// On a later outdoor/runtime error the actual State moves here without
    /// cloning its Zone/global/Solar owners; this is not an Original flag.
    pub(crate) failed_heat_balance_state: Option<Box<super::state::HeatBalanceState>>,
'''+old
text=replace_once(text,old,new)
pending.append((name,before,text.encode()))
proof.append({'canonical_path':name,'Source03_selected_file_exact':True,
    'explicit_logic_delta':'One constructor-default None, consumed move-only failed-State custody slot; no extra scientific state or readiness claim.',
    'existing_newline_style_preserved':True})

# Extend the existing initializer test's successful row: same real initialized
# State/Solar plus explicitly authored Zone/global payload for Rust custody.
name='crates/ep_runtime/src/runtime/tests/ctf_ordinary_outputs.rs'
before=(ROOT/name).read_bytes()
committed=subprocess.run(['git','show',f'{head}:{name}'],cwd=ROOT,capture_output=True,check=True).stdout
assert committed.replace(b'\r\n',b'\n')==before.replace(b'\r\n',b'\n')
text=before.decode()
text=replace_once(text,'            let output = result?;','            let mut output = result?;')
text=replace_once(text,'''            output.ordinary_solar_radiation.ok_or("missing moved actual Solar owner")?
''','''            // Authored Rust failure-custody payload, not Native getter endpoints.
            // Preserve the actual initialized Surface/Solar allocations by move.
            use crate::heat_balance::selected_heat_balance_input::zone::{SelectedZoneData, SelectedZoneInputOwners};
            output.selected_zone_input = Some(SelectedZoneInputOwners {
                zones: Some(vec![SelectedZoneData {
                    typed_zone_id: Some(model.typed.zones[0].id),
                    name: model.typed.zones[0].name.0.clone(),
                    dry_bulb: -101.0, wet_bulb: -99.0, wind_speed: -0.0,
                    ..Default::default()
                }]), ..Default::default()
            });
            output.selected_heat_balance_globals = Some(Default::default());
            let surface_allocation = output.surfaces.as_ptr();
            let zone_allocation = output.selected_zone_input.as_ref().and_then(|owner| owner.zones.as_ref())
                .ok_or("authored custody Zone allocation")?.as_ptr();
            assert!(reports.failed_heat_balance_state.is_none());
            {
                let mut context = CtfInitializationContext { reports: &mut reports, eio: &mut eio,
                    backend: SourceErrorBackend { state: &mut state, error_stream: Some(&mut error),
                        console: &mut console, out_unit1: None, out_unit2: None, f_message: None,
                        message_callback: None, error_callback: None, sqlite: None } };
                crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
                    output, Some(&mut context),
                );
            }
            assert!(reports.selected_zone_input.is_none());
            assert!(reports.selected_heat_balance_globals.is_none());
            let mut failed = reports.failed_heat_balance_state.take().ok_or("missing moved failed State")?;
            assert_eq!(failed.surfaces.as_ptr(), surface_allocation);
            let rows = failed.selected_zone_input.as_ref().and_then(|owner| owner.zones.as_ref())
                .ok_or("failed State lost Zone allocation")?;
            assert_eq!(rows.as_ptr(), zone_allocation);
            assert_eq!([rows[0].dry_bulb, rows[0].wet_bulb], [-101.0, -99.0]);
            assert_eq!(rows[0].wind_speed.to_bits(), (-0.0_f64).to_bits());
            assert!(failed.selected_heat_balance_globals.is_some());
            failed.ordinary_solar_radiation.take().ok_or("failed State lost moved actual Solar owner")?
''')
assert len(re.findall(rb'#\[test\]',before))==len(re.findall(rb'#\[test\]',text.encode()))
pending.append((name,before,text.encode()))
proof.append({'canonical_path':name,'Source03_selected_file_exact':False,
    'explicit_logic_delta':'One existing successful initializer row verifies actual Surface/Solar and authored Zone/global allocations move intact into failure custody, with pointer identity and no duplicate owners.',
    'existing_newline_style_preserved':True})
OUT.mkdir()
rows=[]
for name,before,after in pending:
    prior=OUT/'before'/name
    if before is not None:
        prior.parent.mkdir(parents=True,exist_ok=True)
        prior.write_bytes(before)
    proposal=OUT/'proposed'/name
    proposal.parent.mkdir(parents=True,exist_ok=True)
    proposal.write_bytes(after)
    direct=OUT/'diffs'/(name.replace('/','__')+'.diff')
    direct.parent.mkdir(exist_ok=True)
    direct.write_bytes(''.join(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),
        after.decode().splitlines(keepends=True),fromfile=name if before is not None else '/dev/null',tofile=name)).encode())
    parent_row=next((row for row in parent['files'] if row['canonical_path']==name),None)
    parent_data=(ROOT/parent_row['proposal']['path']).read_bytes() if parent_row else before
    parent_delta=OUT/'exact_parent_diffs'/(name.replace('/','__')+'.diff')
    parent_delta.parent.mkdir(exist_ok=True)
    parent_delta.write_bytes(''.join(difflib.unified_diff(parent_data.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),
        fromfile=parent_row['proposal']['path'] if parent_row else name,tofile=proposal.relative_to(ROOT).as_posix())).encode())
    rows.append({'canonical_path':name,'before':ref(prior) if before is not None else None,
        'proposal':ref(proposal),'complete_diff':ref(direct),'exact_parent_diff':ref(parent_delta)})
for row in parent['Original_ranges']:check(row['literal'])
for row in parent['unchanged_borrowed_contracts']:check(row)
README=OUT/'README.md'
text=(ROOT/parent['README']['path']).read_text(encoding='utf-8')
text+='''
Source02 qualification: Source01 is preserved as an unapplied preparation with CRLF-converted proposal bytes and an imprecise historical HB02 parent label. Its actual archived runtime base already contains the real Source03 host move. This successor directly authenticates the same before bytes against actual Source03 where applicable, preserves each existing file's original newline style, and adds the complete-ID-set guard plus consumed move-only failure custody beyond the LF-normalized Source01 logic. New-file diff labels correctly use /dev/null to the actual canonical path. No canonical Source was changed by either preparation.

Failure custody is one Rust-only `reports.failed_heat_balance_state: Option<Box<HeatBalanceState>>`, initially None. All fallible post-constructor preparation, initial outdoor, warmup, run-period and final weather errors move the actual Source-connected State there before returning the same error. The moved State retains completed Zone/Surface prefixes and all its original global/Solar/temperature owners; no second live State is created. Legacy states without either Source owner keep existing failure behavior. The slot records the most recent failed Source-connected runtime attempt; it is not a retry permission or a full-Setup owner. Earlier independent initializer failures continue to retain their existing reports owners. Other legacy/manual failure paths are not promoted to full failed-State custody.

A third existing test body (the initializer table's successful row) checks move-only custody with actual initialized Surface/Solar allocations plus clearly authored Zone/global payload, pointer identity, retained bulbs/wind, and absence of duplicate reports Zone/global owners. It does not claim a Native failure endpoint or executed result. Include that existing libtest in the affected selection alongside the four ordinary outdoor guard tests.
'''
README.write_text(text,encoding='utf-8')
value={key:parent[key] for key in ['schema','status','Original_ranges','unchanged_borrowed_contracts',
    'changed_existing_test_bodies','new_test_bodies','new_test_binaries','canonical_writes','formatter_executed',
    'compiler_executed','tests_executed','engine_executed','numeric_or_gate_PASS','scope']}
value.update({'HEAD':subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True).stdout.strip(),
    'actual_HB_parent':ref(ACTUAL),'historical_parent_preparation':ref(PARENT),'files':rows,
    'successor_proof':proof,'README':ref(README),'author':ref(Path(__file__))})
value['changed_existing_test_bodies']=3
(OUT/'manifest.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps(ref(OUT/'manifest.json')))

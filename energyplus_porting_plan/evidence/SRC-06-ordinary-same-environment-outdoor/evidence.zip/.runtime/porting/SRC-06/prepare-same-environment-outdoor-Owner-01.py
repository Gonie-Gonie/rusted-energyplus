import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-same-environment-outdoor-prep-01'
ORIGINAL = ROOT / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'

def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def replace_once(text, before, after):
    assert text.count(before) == 1, before[:140]
    return text.replace(before, after)

def diff(before, after, name):
    return ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile=name, tofile=name)).encode()

assert not OUT.exists(), 'fresh immutable preparation only'
parent_path = ROOT / '.runtime/porting/SRC-06/ordinary-hb-input-assembly-02/manifest.json'
parent = json.loads(parent_path.read_text(encoding='utf-8'))
names = [
 'crates/ep_runtime/src/heat_balance/convection/surface_environment/ordinary.rs',
 'crates/ep_runtime/src/heat_balance/convection/surface_environment/ordinary/source.rs',
 'crates/ep_runtime/src/heat_balance/convection/surface_environment/ordinary_tests.rs',
 'crates/ep_runtime/src/runtime.rs',
 'crates/ep_runtime/src/heat_balance/warmup.rs',
 'crates/ep_runtime/src/heat_balance/run_period/standalone.rs',
]
payloads = {}
for name in names:
    path = ROOT / name
    payloads[name] = path.read_bytes() if path.exists() else None

name = names[0]
before = payloads[name]
text = before.decode().replace('\r\n', '\n')
text = replace_once(text, 'use crate::heat_balance::state::HeatBalanceState;',
    'use crate::heat_balance::state::{HeatBalanceState, SurfaceHeatBalanceState};\nuse crate::heat_balance::weather_driver::HeatBalanceWeatherDriver;\n\nmod source;')
start = text.index('    let mut min_bulb = 0.0;\n', text.index('pub fn check_surface_out_bulb_temperatures'))
end = text.index('\nfn unavailable(', start)
guard = text[start:end]
guard = replace_once(guard, 'for (row, name) in rows {', 'for (dry_bulb, wet_bulb, centroid_height, name) in rows {')
guard = guard.replace('row.dry_bulb_c', 'dry_bulb').replace('row.wet_bulb_c', 'wet_bulb').replace('row.centroid_height_m', 'centroid_height')
guard = replace_once(guard, 'backend.show_severe_error("SetOutBulbTempAt: Surface Outdoor Temperatures < -100 C")?;',
    'backend.show_severe_error(&format!("SetOutBulbTempAt: {kind} Outdoor Temperatures < -100 C"))?;')
guard = replace_once(guard, '"surface height .0R unavailable: {error:?}"', '"{} height .0R unavailable: {error:?}", kind.to_ascii_lowercase()')
guard = replace_once(guard, '"...check Surface Heights - Maximum Surface Height=[{height}]."', '"...check {kind} Heights - Maximum {kind} Height=[{height}]."')
guard = replace_once(guard, '"...look at Surface Name= {name}"', '"...look at {kind} Name= {name}"')
text = text[:start] + '''    check_out_bulb_temperatures(
        "Surface",
        rows.into_iter().map(|(row, name)| (
            row.dry_bulb_c, row.wet_bulb_c, row.centroid_height_m, name,
        )),
        backend,
    )
}

// Both Original bulk guards invoke the same DataEnvironment error routine.
fn check_out_bulb_temperatures<'a>(
    kind: &str,
    rows: impl IntoIterator<Item = (f64, f64, f64, &'a str)>,
    backend: &mut SourceErrorBackend<'_>,
) -> Result<(), SurfaceOutdoorEnvironmentError> {
''' + guard + text[end:]

# Keep the legacy surface-only entry, parameters and numeric bodies intact.
validate_start = text.index('    if state.surfaces.len() != model.typed.surfaces.len()', text.index('pub(crate) fn invoke('))
validate_end = text.index('    output.backend.state.warmup_flag', validate_start)
validation = text[validate_start:validate_end]
text = text[:validate_start] + '    validate_surfaces(model, state)?;\n' + text[validate_end:]
apply_start = text.index('    for surface in &mut state.surfaces {', text.index('pub(crate) fn invoke('))
apply_end = text.index('\npub(crate) fn invoke_if_active(', apply_start)
application = text[apply_start:apply_end]
application = application.replace('&mut state.surfaces', 'surfaces').replace('state.surfaces', 'surfaces').replace('state\n            .surfaces', 'surfaces')
application = replace_once(application, 'for surface in surfaces {', 'for surface in surfaces.iter_mut() {')
application = application.replace('&mut output.backend', 'backend')
text = text[:apply_start] + '''    apply_surfaces(&mut state.surfaces, parameters, weather, &mut output.backend)
}

fn validate_surfaces(model: &SimulationModel, state: &HeatBalanceState) -> Result<(), RuntimeError> {
''' + validation + '''    Ok(())
}

fn apply_surfaces(
    surfaces: &mut [SurfaceHeatBalanceState],
    parameters: SurfaceOutdoorEnvironmentParameters,
    weather: SurfaceOutdoorWeather,
    backend: &mut SourceErrorBackend<'_>,
) -> Result<(), RuntimeError> {
''' + application + '''
/// Source-connected callers borrow the existing production session. Legacy
/// callers without either Source owner retain the surface-only invocation.
pub(crate) fn invoke_from_driver(
    model: &SimulationModel,
    state: &mut HeatBalanceState,
    weather: Option<HeatBalanceWeatherContext<'_>>,
    driver: Option<HeatBalanceWeatherDriver<'_>>,
    output: Option<&mut CtfInitializationContext<'_>>,
) -> Result<(), RuntimeError> {
    match (state.selected_zone_input.is_some(), state.selected_heat_balance_globals.is_some()) {
        (false, false) => invoke(model, state, weather, output),
        (true, true) => source::invoke(model, state, weather, driver, output),
        _ => Err(unavailable("partial Source Zone/global outdoor ownership")),
    }
}
''' + text[apply_end:]
text = replace_once(text, '''pub(crate) fn invoke_if_active(
    model: &SimulationModel,
    state: &mut HeatBalanceState,
    weather: Option<HeatBalanceWeatherContext<'_>>,
    output:''', '''pub(crate) fn invoke_if_active(
    model: &SimulationModel,
    state: &mut HeatBalanceState,
    weather: Option<HeatBalanceWeatherContext<'_>>,
    driver: Option<HeatBalanceWeatherDriver<'_>>,
    output:''')
text = replace_once(text, '        invoke(model, state, weather, output)?;', '        invoke_from_driver(model, state, weather, driver, output)?;')
payloads[name] = (before, text.encode().replace(b'\n', b'\r\n'))

source = r'''//! Consumed Zone outdoor setters followed by the existing Surface setters.
//! The same retained weather session supplies both Station/Site and Current.
use super::*;
use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneData;

pub(super) fn invoke(
    model: &SimulationModel,
    state: &mut HeatBalanceState,
    weather: Option<HeatBalanceWeatherContext<'_>>,
    driver: Option<HeatBalanceWeatherDriver<'_>>,
    output: Option<&mut CtfInitializationContext<'_>>,
) -> Result<(), RuntimeError> {
    let actual = weather.and_then(|value| value.owned)
        .ok_or_else(|| unavailable("Zone outdoor requires actual current production weather"))?;
    let clock = actual.ctf_history_clock
        .ok_or_else(|| unavailable("Zone outdoor requires actual caller WarmupFlag"))?;
    let Some(HeatBalanceWeatherDriver::Production(series)) = driver else {
        return Err(unavailable("Source outdoor requires the retained production weather session"));
    };
    let output = output.ok_or_else(|| unavailable("Zone outdoor requires the actual error backend"))?;
    validate_surfaces(model, state)?;
    let globals = state.selected_heat_balance_globals.as_ref()
        .ok_or_else(|| unavailable("missing Source outdoor globals"))?;
    if globals.any_energy_management_system_in_model || state.ordinary_equipment.is_none() {
        return Err(unavailable("Source outdoor requires admitted non-EMS geometry equipment input"));
    }
    let doing_sizing = globals.doing_sizing;
    let zones = state.selected_zone_input.as_mut()
        .and_then(|owner| owner.zones.as_mut())
        .ok_or_else(|| unavailable("Source outdoor before actual Zone allocation"))?;
    let ids = zones.iter().filter_map(|zone| zone.typed_zone_id)
        .collect::<std::collections::BTreeSet<_>>();
    if zones.len() != model.typed.zones.len() || ids.len() != zones.len()
        || state.zones.len() != zones.len()
        || state.zones.iter().any(|zone| !ids.contains(&zone.zone_id))
        || zones.iter().any(|zone| zone.centroid_m.is_none() || zone.linked_outdoor_air_node != 0
            || !model.typed.zones.iter().any(|typed| Some(typed.id) == zone.typed_zone_id
                && typed.name == ep_model::NormalizedName::new(&zone.name)))
    {
        return Err(unavailable("Source outdoor Zone identity/centroid/linked-node owner changed"));
    }
    series.with_source_environment_mut(|environment, _minutes| {
        if !environment.source_weather_station_initialized || !environment.source_site_atmosphere_initialized {
            return Err(unavailable("Source outdoor before real Station/Site returns"));
        }
        let current = environment.current_weather;
        if [current.out_dry_bulb_temp, current.out_wet_bulb_temp, current.wind_speed, current.wind_dir].map(f64::to_bits)
            != [actual.current_weather.out_dry_bulb_temp, actual.current_weather.out_wet_bulb_temp,
                actual.current_weather.wind_speed, actual.current_weather.wind_dir].map(f64::to_bits)
        {
            return Err(unavailable("Source outdoor current context belongs to another weather slot"));
        }
        let parameters = environment.outdoor_environment_parameters;
        let weather = SurfaceOutdoorWeather {
            dry_bulb_c: current.out_dry_bulb_temp,
            wet_bulb_c: current.out_wet_bulb_temp,
            wind_speed_m_per_s: current.wind_speed,
            wind_direction_deg: current.wind_dir,
        };
        output.backend.state.warmup_flag = matches!(clock.phase, WeatherDayPhase::Warmup { .. });
        output.backend.state.doing_sizing = doing_sizing;
        update_zones(zones, parameters, weather, &mut output.backend)?;
        apply_surfaces(&mut state.surfaces, parameters, weather, &mut output.backend)
    })
}

// Source DataHeatBalance SetZoneOutBulbTempAt/Check/SetWindSpeedAt/SetWindDirAt.
// The selected raw admission excludes local-environment and EMS families;
// linked-node and actual EMS ownership are also checked before any writes.
pub(super) fn update_zones(
    zones: &mut [SelectedZoneData],
    parameters: SurfaceOutdoorEnvironmentParameters,
    weather: SurfaceOutdoorWeather,
    backend: &mut SourceErrorBackend<'_>,
) -> Result<(), SurfaceOutdoorEnvironmentError> {
    if zones.iter().any(|zone| zone.linked_outdoor_air_node != 0) {
        return Err(SurfaceOutdoorEnvironmentError::Unavailable("Zone outdoor centroid/linked-node association"));
    }
    // Validate every centroid before writes. This transient scalar projection
    // neither replaces geometry nor retains a second Zone/weather owner.
    let heights = zones.iter().map(|zone| zone.centroid_m.map(|centroid| centroid[2])
        .ok_or(SurfaceOutdoorEnvironmentError::Unavailable("Zone outdoor centroid unavailable")))
        .collect::<Result<Vec<_>, _>>()?;
    for (zone, &height) in zones.iter_mut().zip(&heights) {
        zone.dry_bulb = parameters.temperature_at_height(weather.dry_bulb_c, height);
        zone.wet_bulb = parameters.temperature_at_height(weather.wet_bulb_c, height);
    }
    check_out_bulb_temperatures("Zone", zones.iter().zip(&heights).map(|(zone, &height)| (
        zone.dry_bulb, zone.wet_bulb, height, zone.name.as_str(),
    )), backend)?;
    let factor = weather.wind_speed_m_per_s * parameters.weather_file_wind_modifier
        * parameters.site_wind_boundary_layer_height_m.powf(-parameters.site_wind_exponent);
    for (zone, &height) in zones.iter_mut().zip(&heights) {
        zone.wind_speed = if parameters.site_wind_exponent == 0.0 {
            weather.wind_speed_m_per_s
        } else if height <= 0.0 {
            0.0
        } else {
            factor * height.powf(parameters.site_wind_exponent)
        };
    }
    for zone in zones {
        zone.wind_direction = weather.wind_direction_deg;
    }
    Ok(())
}
'''
payloads[names[1]] = (None, source.encode())

name = names[2]
before = payloads[name]
text = before.decode().replace('\r\n', '\n')
anchor = '    assert_eq!(minimum_three(0.0, -0.0, 0.0).to_bits(), 0.0_f64.to_bits());\n'
extension = r'''
    use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneData;
    let mut zones = [SelectedZoneData { name: "actual Zone owner".into(),
        centroid_m: Some([0.0, 0.0, 10.0]), ..Default::default() }];
    let mut parameters = SurfaceOutdoorEnvironmentParameters {
        site_temperature_gradient_k_per_m: 0.0, weather_file_temperature_modifier_c: 123.0,
        site_wind_exponent: 0.0, site_wind_boundary_layer_height_m: 77.0,
        weather_file_wind_modifier: 19.0,
    };
    let weather = SurfaceOutdoorWeather { dry_bulb_c: 21.0, wet_bulb_c: 13.0,
        wind_speed_m_per_s: 4.0, wind_direction_deg: -0.0 };
    let (mut error_state, mut error, mut console) = (state(), Vec::new(), Vec::new());
    assert!(source::update_zones(&mut zones, parameters, weather,
        &mut backend(&mut error_state, &mut error, &mut console)).is_ok());
    assert_eq!([zones[0].dry_bulb, zones[0].wet_bulb, zones[0].wind_speed], [21.0, 13.0, 4.0]);
    assert_eq!(zones[0].wind_direction.to_bits(), (-0.0_f64).to_bits());
    parameters.site_temperature_gradient_k_per_m = 0.0065;
    parameters.weather_file_temperature_modifier_c = 0.75;
    parameters.site_wind_exponent = 0.22;
    parameters.weather_file_wind_modifier = 1.25;
    assert!(source::update_zones(&mut zones, parameters, weather,
        &mut backend(&mut error_state, &mut error, &mut console)).is_ok());
    assert_eq!(zones[0].dry_bulb.to_bits(), (21.0_f64 + 0.75 - 0.0065 * 6_356_000.0 * 10.0 / (6_356_000.0 + 10.0)).to_bits());
    assert_eq!(zones[0].wind_speed.to_bits(), (4.0_f64 * 1.25 * 77.0_f64.powf(-0.22) * 10.0_f64.powf(0.22)).to_bits());
    zones[0].centroid_m = Some([0.0, 0.0, -1.0]);
    assert!(source::update_zones(&mut zones, parameters, weather,
        &mut backend(&mut error_state, &mut error, &mut console)).is_ok());
    assert_eq!(zones[0].dry_bulb, 21.75);
    assert_eq!(zones[0].wet_bulb, 13.75);
    assert_eq!(zones[0].wind_speed.to_bits(), 0.0_f64.to_bits());
    zones[0].centroid_m = None;
    let before = zones.clone();
    assert!(matches!(source::update_zones(&mut zones, parameters, weather,
        &mut backend(&mut error_state, &mut error, &mut console)),
        Err(SurfaceOutdoorEnvironmentError::Unavailable(_))));
    assert_eq!(zones, before);
    assert!(error.is_empty());
'''
text = replace_once(text, anchor, anchor + extension)
anchor = '''    let text = std::str::from_utf8(&error)?;
    assert!(text.contains("Reference severe error count=8"));
    assert!(!text.contains("must not be visited"));
'''
extension = r'''
    use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneData;
    let mut zones = [SelectedZoneData { name: "first cold Zone".into(),
        centroid_m: Some([0.0, 0.0, 20000.0]), wind_speed: -0.0, wind_direction: 321.0,
        ..Default::default() }, SelectedZoneData { name: "later Zone".into(),
        centroid_m: Some([0.0, 0.0, 1.0]), wind_speed: 987.0, wind_direction: -0.0,
        ..Default::default() }];
    let incoming = zones.clone();
    let parameters = SurfaceOutdoorEnvironmentParameters {
        site_temperature_gradient_k_per_m: 0.0, weather_file_temperature_modifier_c: 99.0,
        site_wind_exponent: 0.22, site_wind_boundary_layer_height_m: 370.0,
        weather_file_wind_modifier: 1.0,
    };
    let weather = SurfaceOutdoorWeather { dry_bulb_c: -101.0, wet_bulb_c: -99.0,
        wind_speed_m_per_s: 4.0, wind_direction_deg: 123.0 };
    let mut zone_error = Vec::new();
    let result = source::update_zones(&mut zones, parameters, weather,
        &mut backend(&mut state, &mut zone_error, &mut console));
    assert!(matches!(result, Err(SurfaceOutdoorEnvironmentError::Fatal(_))));
    for (zone, before) in zones.iter().zip(&incoming) {
        assert_eq!([zone.dry_bulb, zone.wet_bulb], [-101.0, -99.0]);
        assert_eq!(zone.wind_speed.to_bits(), before.wind_speed.to_bits());
        assert_eq!(zone.wind_direction.to_bits(), before.wind_direction.to_bits());
    }
    let text = std::str::from_utf8(&zone_error)?;
    assert!(text.contains("SetOutBulbTempAt: Zone Outdoor Temperatures < -100 C"));
    assert!(text.contains("...check Zone Heights - Maximum Zone Height=[20000]."));
    assert!(text.contains("...look at Zone Name= first cold Zone"));
    assert!(!text.contains("later Zone"));
    assert_eq!(state.tracking.total_severe_errors, 9);
    assert_eq!(state.tracking.total_severe_errors_during_warmup, 6);
'''
text = replace_once(text, anchor, anchor + extension)
payloads[name] = (before, text.encode().replace(b'\n', b'\r\n'))

for name in names[3:]:
    before = payloads[name]
    text = before.decode().replace('\r\n', '\n')
    if name.endswith('/runtime.rs'):
        text = replace_once(text, 'surface_environment::ordinary::invoke(\n', 'surface_environment::ordinary::invoke_from_driver(\n')
        text = replace_once(text, '                    initial_weather_context,\n                    initialization.as_deref_mut(),', '                    initial_weather_context,\n                    weather_driver,\n                    initialization.as_deref_mut(),')
    else:
        indent = '                    ' if name.endswith('/warmup.rs') else '                '
        text = replace_once(text, f'{indent}weather_context,\n{indent}output.as_deref_mut(),', f'{indent}weather_context,\n{indent}weather_driver,\n{indent}output.as_deref_mut(),')
    payloads[name] = (before, text.encode().replace(b'\n', b'\r\n'))

OUT.mkdir()
rows = []
for name in names:
    before, after = payloads[name]
    assert (ROOT/name).read_bytes() == before if before is not None else not (ROOT/name).exists()
    proposed = OUT/'proposed'/name
    proposed.parent.mkdir(parents=True, exist_ok=True)
    proposed.write_bytes(after)
    archived = OUT/'before'/name
    if before is not None:
        archived.parent.mkdir(parents=True, exist_ok=True)
        archived.write_bytes(before)
    delta = OUT/'diffs'/(name.replace('/', '__')+'.diff')
    delta.parent.mkdir(exist_ok=True)
    delta.write_bytes(diff(before or b'', after, name if before is not None else '/dev/null'))
    if before is not None:
        assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after)), name
    rows.append({'canonical_path': name, 'before': ref(archived) if before is not None else None,
        'proposal': ref(proposed), 'complete_diff': ref(delta)})

ranges = []
for file, start, end in [
 ('src/EnergyPlus/DataHeatBalance.cc', 144, 214),
 ('src/EnergyPlus/DataHeatBalance.cc', 302, 339),
 ('src/EnergyPlus/DataEnvironment.cc', 236, 248),
 ('src/EnergyPlus/HeatBalanceManager.cc', 2742, 2820),
 ('src/EnergyPlus/HeatBalanceSurfaceManager.cc', 299, 354),
]:
    path = ORIGINAL/file
    data = path.read_bytes()
    tracked = subprocess.run(['git','show',f'{PIN}:{file}'], cwd=ORIGINAL, capture_output=True, check=True).stdout
    assert tracked.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n'), file
    literal = OUT/'Original'/(Path(file).name+f'.{start}-{end}.txt')
    literal.parent.mkdir(exist_ok=True)
    literal.write_bytes(b''.join(data.splitlines(keepends=True)[start-1:end]))
    ranges.append({'source': ref(path), 'Original_git_commit': PIN,
        'full_file_Git_equality_after_LF_normalization': True, 'line_start': start, 'line_end': end,
        'literal': ref(literal)})

contracts = [ref(ROOT/name) for name in [
 'crates/ep_runtime/src/heat_balance/state.rs',
 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs',
 'crates/ep_runtime/src/heat_balance/selected_heat_balance_globals.rs',
 'crates/ep_runtime/src/weather_day/production/source_environment.rs',
 'crates/ep_runtime/src/weather_day/context.rs',
 'crates/ep_runtime/src/heat_balance/weather_driver.rs',
 'crates/ep_runtime/src/heat_balance/convection/surface_environment.rs',
 'crates/ep_run/src/ordinary_equipment_input.rs',
]]
readme = OUT/'README.md'
readme.write_text('''# HELD same-environment Zone and Surface outdoor connection

This Source-only proposal connects the existing ordinary constructor, warmup and run calls. The Source-connected path borrows the same retained production weather session after the genuine Station/Site returns, reads its current weather and actual environment coefficients, writes the sole selected Zone rows in their retained order, then invokes the existing Surface setters. No environment, Zone outdoor vector, Source global, geometry or weather cursor is duplicated.

Original order is Zone dry/wet bulk writes, cumulative cold guard, bulk wind-speed factor and rows, direction rows, then the existing Surface temperature/guard/wind/direction sequence. A failed Zone guard retains every completed temperature write and the real backend prefix; Zone wind and Surface rows remain untouched. Full associations and represented selected prerequisites are validated before scientific writes. The existing selected positive-family admission excludes local-environment and EMS input families; actual EMS and linked-Zone-node ownership are checked as well. This is not a complete no-Node or full-HVAC certificate.

The legacy route with neither Source Zone nor Source global owners keeps the existing surface-only invocation and compiled-terrain default factory. A partial Source owner cannot fall back to that path. Existing manual/None calls remain unchanged. Source-connected callers use retained coefficients and do not reconstruct the terrain factory. The actual current-context four outdoor operands must bit-match the same borrowed session before writes.

Two existing ordinary guard test bodies are extended, without new test bodies or binaries: zero gradient/exponent ignoring nontrivial modifiers, positive-height lapse/wind expressions, nonpositive-height base/+0 wind, missing-centroid no-write rejection, and the real Zone cold-guard prefix with all-temperature/unchanged-wind retention. These authored cases are not Native endpoint fixtures or executed results. Existing Surface severity, NaN/tie, format failure and backend failure assertions remain.

This proposal does not activate genuine ManageHeatBalance/SetupSimulation, move eager CTF timing, supply missing BeginSim/firstTime flags, close full GetSurfaceData or claim full InitHeatBalance/InitSurfaceHeatBalance parity. Root's current HB47 unit must finish QA/commit before application. No formatter, compiler, Cargo test, Native engine or canonical write is executed by this preparation.

Suggested affected verification after application: the four existing `convection::surface_environment::ordinary::tests` libtests, existing normal ordinary CLI and CI=Y ordinary CLI. Root owns final selection and actual receipts. No workspace rerun is required solely by this draft.
''', encoding='utf-8')
manifest = {
 'schema': 'src06-same-environment-outdoor-preparation.v1',
 'status': 'HELD-Source-only-not-applied-or-tested',
 'HEAD': subprocess.run(['git','rev-parse','HEAD'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip(),
 'actual_HB_parent': ref(parent_path), 'files': rows, 'Original_ranges': ranges,
 'unchanged_borrowed_contracts': contracts, 'README': ref(readme), 'author': ref(__file__),
 'changed_existing_test_bodies': 2, 'new_test_bodies': 0, 'new_test_binaries': 0,
 'canonical_writes': False, 'formatter_executed': False, 'compiler_executed': False,
 'tests_executed': False, 'engine_executed': False, 'numeric_or_gate_PASS': False,
 'scope': 'Consumed same-session Station/Site outdoor operands; sole Zone bulk producers before existing Surface setters at current ordinary callers; no full InitHB/Setup timing claim.',
}
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps(ref(OUT/'manifest.json')))

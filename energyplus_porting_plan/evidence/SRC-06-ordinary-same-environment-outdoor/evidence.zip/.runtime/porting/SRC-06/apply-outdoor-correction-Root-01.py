"""Apply finite reviewed corrections without overwriting the failed Source01 custody."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root=Path.cwd(); base=root/'.runtime/porting/SRC-06'
packet_path=root/sys.argv[1]; packet_sha=sys.argv[2]
review_path=root/sys.argv[3]; review_sha=sys.argv[4]
prior_path=base/'ordinary-same-environment-outdoor-assembly-01/manifest.json'
out=base/'ordinary-same-environment-outdoor-assembly-02'
assert not out.exists()
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path): return json.loads(path.read_bytes())
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value: yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value,list):
        for child in value: yield from walk(child)
assert ref(prior_path)['sha256']=='c36dde44363d638c74a046ce6784f6c7c4b5cf4030a6cabd9b8e6b3ff2756871'
assert ref(packet_path)['sha256']==packet_sha and ref(review_path)['sha256']==review_sha
packet,review,prior=load(packet_path),load(review_path),load(prior_path)
assert review['accepted'] is True and any(row['sha256']==packet_sha for row in walk(review))
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==prior['HEAD']
for row in prior['files']: assert ref(root/row['canonical_path'])==row['canonical']
dirty=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','-z']).decode().split('\0')
assert {row[3:] for row in dirty if row}=={row['canonical_path'] for row in prior['files']}
corrections={row['canonical_path']:row for row in packet['files']}
assert len(corrections)==len(packet['files'])==1
for name,row in corrections.items():
    assert (root/name).resolve().is_relative_to((root/'crates').resolve()) and name.endswith('.rs')
    for key in ['before','proposal','complete_diff']: assert ref(root/row[key]['path'])['sha256']==row[key]['sha256']
    assert ref(root/name)['sha256']==row['before']['sha256']
prior_rows={row['canonical_path']:row for row in prior['files']}
assert set(corrections)<=set(prior_rows)
for name in set(corrections)-set(prior_rows):
    assert (root/name).read_bytes()==subprocess.check_output(['git','show',prior['HEAD']+':'+name])
qa=[]
for suffix,expected in [('fmt',0),('quality',0),('clippy',101)]:
    path=base/f'ordinary-same-environment-outdoor-{suffix}-01/receipt.json';value=load(path)
    assert value['exit_code']==expected and value['source_bytes_match_before_and_after'] is True
    qa.append(ref(path))
assert len({load(root/row['path'])['source_snapshot']['sha256'] for row in qa})==1
out.mkdir()
rows=[]
for name in sorted(set(prior_rows)|set(corrections)):
    old=prior_rows.get(name); correction=corrections.get(name); canonical=root/name
    saved=out/'before'/name;saved.parent.mkdir(parents=True,exist_ok=True)
    saved.write_bytes((root/old['before']['path']).read_bytes() if old else canonical.read_bytes())
    proposal=correction['proposal'] if correction else old['accepted_proposal']
    if correction: canonical.write_bytes((root/proposal['path']).read_bytes())
    rows.append({'canonical_path':name,'existed_before':old['existed_before'] if old else True,
        'before':ref(saved),'accepted_proposal':proposal,'after_apply':ref(canonical)})
value={'schema':'src06-actual-outdoor-corrective-apply.v1','HEAD':prior['HEAD'],
    'accepted_packet':prior['accepted_packet'],'independent_Source_review':prior['independent_Source_review'],
    'files':rows,'author':ref(Path(__file__)),
    'additional_provenance':{'prior_actual_assembly':ref(prior_path),'correction_packet':ref(packet_path),
        'independent_correction_Source_review':ref(review_path),
        'prior_application_review':ref(base/'Header-ordinary-same-environment-outdoor-application-review-01/review.json'),
        'prior_QA_receipts':qa,
        'qualification':'Actual Source01 and all three QA receipts remain immutable: fmt0, quality0, Clippy101 one final Option borrow lint; no tests ran. Source02 changes only that same final context delivery. Seven other complete actual files remain exact Source01.'},
    'targets_executed':[]}
(out/'apply.json').write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'apply':ref(out/'apply.json'),'files':len(rows)}))

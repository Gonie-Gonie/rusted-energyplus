"""Prepare the literal final Option move without touching canonical Source."""
from pathlib import Path
import difflib
import hashlib
import json

root = Path.cwd()
base = root/'.runtime/porting/SRC-06'
out = base/'ordinary-same-environment-outdoor-correction-prep-01'
assert not out.exists()
def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(), 'sha256':hashlib.sha256(data).hexdigest(), 'size_bytes':len(data)}
prior_path = base/'ordinary-same-environment-outdoor-assembly-01/manifest.json'
assert ref(prior_path)['sha256'] == 'c36dde44363d638c74a046ce6784f6c7c4b5cf4030a6cabd9b8e6b3ff2756871'
prior = json.loads(prior_path.read_bytes())
for row in prior['files']: assert ref(root/row['canonical_path']) == row['canonical']
name = 'crates/ep_runtime/src/runtime.rs'
before = (root/name).read_bytes()
old = b'''    if let Some(driver) = weather_driver
        && let Err(error) = driver.finish_environment()
    {
        crate::heat_balance::convection::surface_environment::ordinary::retain_failed_state(
            state,
            initialization.as_deref_mut(),
        );
        return Err(error);
    }'''
new = old.replace(b'initialization.as_deref_mut()', b'initialization')
assert before.count(old) == 1
after = before.replace(old, new)
assert after.replace(new, old) == before
assert b'initialization' not in before[before.index(old)+len(old):]
qa = []
for suffix, expected in [('fmt',0), ('quality',0), ('clippy',101)]:
    path = base/f'ordinary-same-environment-outdoor-{suffix}-01/receipt.json'
    value = json.loads(path.read_bytes())
    assert value['exit_code'] == expected and value['source_bytes_match_before_and_after'] is True
    qa.append(ref(path))
assert len({json.loads((root/row['path']).read_bytes())['source_snapshot']['sha256'] for row in qa}) == 1
out.mkdir()
saved = out/'before'/name
saved.parent.mkdir(parents=True)
saved.write_bytes(before)
proposal = out/'proposed'/name
proposal.parent.mkdir(parents=True)
proposal.write_bytes(after)
diff = out/'runtime.rs.diff'
diff.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=name, tofile=name)).encode())
value = {'schema':'src06-outdoor-literal-correction-preparation.v1', 'status':'HELD not applied or tested',
    'prior_actual_assembly':ref(prior_path), 'files':[{'canonical_path':name, 'before':ref(saved), 'proposal':ref(proposal), 'complete_diff':ref(diff)}],
    'prior_application_review':ref(base/'Header-ordinary-same-environment-outdoor-application-review-01/review.json'),
    'prior_QA_receipts':qa, 'author':ref(Path(__file__)),
    'logic':'Only final finish-environment Err return consumes the same Option<&mut Context> directly. There is no later initialization use. Earlier borrows, actual error and moved State are unchanged.',
    'qualification':'Source01 fmt and quality passed; Clippy failed101 on one needless_option_as_deref before tests. No tests executed on that Source. No mathematical or test assertion change.',
    'new_test_bodies':0, 'gates_updated':False}
(out/'manifest.json').write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(ref(out/'manifest.json')))

"""Finite independent actual application/formatter review. No target execution."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path.cwd()
BASE = '.runtime/porting/SRC-06/'
ASSEMBLY = BASE + 'ordinary-same-environment-outdoor-assembly-01/manifest.json'
FMT = BASE + 'ordinary-same-environment-outdoor-fmt-01/receipt.json'
OUT = BASE + 'Header-ordinary-same-environment-outdoor-application-review-01/review.json'


def read(name):
    return (ROOT / name).read_bytes()


def ref(name):
    data = read(name)
    return {'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}


def checked(value):
    actual = ref(value['path'])
    assert actual['sha256'] == value['sha256'], value['path']
    assert actual['size_bytes'] == value.get('size_bytes', actual['size_bytes']), value['path']
    return actual


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, check=True, capture_output=True).stdout


def diff(before, after, name):
    first = before.replace(b'\r\n', b'\n').decode().splitlines(True)
    second = after.replace(b'\r\n', b'\n').decode().splitlines(True)
    return ''.join(difflib.unified_diff(first, second, fromfile=name, tofile=name)).encode()


assert ref(ASSEMBLY)['sha256'] == 'c36dde44363d638c74a046ce6784f6c7c4b5cf4030a6cabd9b8e6b3ff2756871'
m = json.loads(read(ASSEMBLY))
checked(m['apply'])
checked(m['accepted_packet'])
checked(m['independent_Source_review'])
checked(m['sealer'])
app = json.loads(read(m['apply']['path']))
prep = json.loads(read(m['accepted_packet']['path']))
review = json.loads(read(m['independent_Source_review']['path']))
assert review['accepted'] is True and review['preparation_manifest'] == m['accepted_packet']
assert app['accepted_packet'] == m['accepted_packet']
assert app['independent_Source_review'] == m['independent_Source_review']
assert app['HEAD'] == m['HEAD'] == git('rev-parse', 'HEAD').decode().strip()
checked(app['author'])
checked(app['predecessor'])
prep_rows = {row['canonical_path']: row for row in prep['files']}
apply_rows = {row['canonical_path']: row for row in app['files']}
assert len(m['files']) == len(prep_rows) == len(apply_rows) == 8
assert {row['canonical_path'] for row in m['files']} == set(prep_rows) == set(apply_rows)
details = []
formatter = []
for row in m['files']:
    name = row['canonical_path']
    source = prep_rows[name]
    application = apply_rows[name]
    for key in ('before', 'accepted_proposal', 'after', 'canonical', 'complete_actual_diff', 'held_to_actual_diff'):
        checked(row[key])
    assert row['before'] == application['before']
    assert row['accepted_proposal'] == application['accepted_proposal'] == source['proposal']
    assert row['after_apply'] == application['after_apply']
    # Historical after_apply points to a canonical path that was later formatted.
    # Authenticate it against the immutable accepted proposal, never the current path.
    assert row['after_apply']['path'] == name
    assert {k: row['after_apply'][k] for k in ('sha256', 'size_bytes')} == {
        k: row['accepted_proposal'][k] for k in ('sha256', 'size_bytes')}
    before = read(row['before']['path'])
    held = read(row['accepted_proposal']['path'])
    actual = read(row['after']['path'])
    assert actual == read(name)
    if row['existed_before']:
        assert source['before'] is not None
        assert before == read(source['before']['path'])
        assert before.replace(b'\r\n', b'\n') == git('show', f"{m['HEAD']}:{name}").replace(b'\r\n', b'\n')
    else:
        assert source['before'] is None and before == b''
        absent = subprocess.run(['git', 'cat-file', '-e', f"{m['HEAD']}:{name}"],
            cwd=ROOT, capture_output=True)
        assert absent.returncode != 0
    assert diff(before, actual, name) == read(row['complete_actual_diff']['path'])
    assert diff(held, actual, name) == read(row['held_to_actual_diff']['path'])
    assert len(re.findall(rb'#\[test\]', held)) == len(re.findall(rb'#\[test\]', actual))
    details.append({'canonical': row['canonical'], 'exact_saved_after': row['after'],
        'accepted_proposal': row['accepted_proposal'], 'complete_actual_diff': row['complete_actual_diff'],
        'held_to_actual_diff': row['held_to_actual_diff'], 'formatter_changed': held != actual})
    if held != actual:
        formatter.append(name)
assert len(formatter) == 4
expected = set(prep_rows)
changed = {item[3:] for item in git('status', '--porcelain=v1', '-z', '--untracked-files=all').decode().split('\0') if item}
assert changed == expected, changed ^ expected
checked({'path': FMT, 'sha256': '23d170b54747578c537f9c50fc2d9c489c1d9b126b8d5d01b93e33507842acbf'})
fmt = json.loads(read(FMT))
assert fmt['command'] == ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'fmt', '--all', '--', '--check']
assert fmt['exit_code'] == 0 and fmt['launch_error'] is None and fmt['source_bytes_match_before_and_after'] is True
for key in ('stdout', 'stderr', 'source_snapshot'):
    checked(fmt[key])
snapshot = json.loads(read(fmt['source_snapshot']['path']))
mapped = {row['historical_path']: row for row in snapshot['files']}
for row in m['files']:
    item = mapped[row['canonical_path']]
    assert item['archive']['sha256'] == row['canonical']['sha256']
    assert item['size_bytes'] == row['canonical']['size_bytes']
    checked(item['archive'])
    assert read(item['archive']['path']) == read(row['canonical']['path'])
assert not (ROOT / OUT).exists()
result = {
    'schema': 'src06-independent-same-environment-outdoor-application-review.v1',
    'accepted': True, 'findings': [], 'actual_assembly': ref(ASSEMBLY),
    'actual_application': m['apply'], 'preparation_manifest': m['accepted_packet'],
    'independent_Source_review': m['independent_Source_review'],
    'Source_snapshot': checked(fmt['source_snapshot']), 'fmtcheck_receipt': ref(FMT),
    'verification': {'actual_paths': 8, 'existing_before_HEAD_join': 7, 'genuine_absent_new_path': 1,
        'application_proposal_hash_size_joins': 8, 'current_equals_saved_after': 8,
        'complete_actual_diff_regenerated': 8, 'held_to_actual_diff_regenerated': 8,
        'formatter_changed_paths': 4, 'whole_byte_equal_held_paths': 4,
        'Source_snapshot_selected_archive_joins': 8, 'exact_git_changed_path_set': True,
        'no_added_test_bodies': True},
    'files': details,
    'formatter_review': [
        {'path': formatter[0], 'finding': 'Line wrapping, argument layout and optional trailing commas only; diagnostic text, branch conditions and scientific operand order unchanged.'},
        {'path': formatter[1], 'finding': 'Expression-chain/array wrapping, expression closure braces and optional trailing commas only; complete ID-set checks, Current bit joins, Zone bulk order and wind arithmetic unchanged.'},
        {'path': formatter[2], 'finding': 'Existing test assertions and authored numeric cases wrapped; no changed values, expected errors, signs, names or test bodies.'},
        {'path': formatter[3], 'finding': 'and_then closure expression wrapped in braces, and argument layout/trailing commas; all seven post-State failure custody sites and same-error returns unchanged.'}
    ],
    'qualifications': [
        'The mutating cargo fmt command was run directly by Root, not by a separately recorded formatter. No such receipt is invented. This review authenticates the four complete held-to-actual diffs and exact final files; the genuine separately recorded fmtcheck closed0 with stable Source supplies final snapshot custody.',
        'after_apply references in immutable application/assembly are historical preformat stages. Their SHA/size join the immutable accepted proposals; current canonical hashes and saved after files are final authority.',
        'Complete eight actual diffs and all four nonempty formatter deltas were read, reusing the accepted full Source review for unchanged scientific logic and caller/error retention.',
        'Inherited Outdoor01 README HB47 text remains historical; actual completed HB48 c5c4ab18 base and Source03 parent authority are unchanged.',
        'The initializer custody test includes explicitly authored Zone/global payload. Source correspondence and allocation preservation do not establish a captured Native or whole-runtime failure endpoint.',
        'This reviewer executed only finite read-only Source authentication and wrote ignored review evidence. No compiler, Cargo, tests, engine, Native/checker target or canonical edits; other Root QA results are not inferred here.'
    ],
    'new_test_bodies': 0, 'canonical_mutated': False, 'targets_executed': False,
    'reviewer': ref(Path(__file__).relative_to(ROOT).as_posix())
}
(ROOT / OUT).parent.mkdir(parents=True, exist_ok=True)
(ROOT / OUT).write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(ref(OUT)))

//! Fallible production weather access without borrowed cursor guards.

use super::sky_transport_trace::{
    self as sky_trace, SkyTransportKind, SkyTransportStamp, SkyTransportValues,
};
use super::{
    CurrentWeatherState, WeatherDayError, WeatherEnvironmentConfiguration, WeatherSession,
    WeatherVars,
};
use crate::weather::{EpwRecord, WeatherTimestepSample};
use ep_model::FirstHourInterpolationStartingValues;
use std::cell::{Cell, RefCell};

mod setup;
pub use setup::{SetupSimulationCall, SetupSimulationControls, SetupSimulationRole};

/// Explicit caller phase; repeated warmup days retain independent call identities.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WeatherDayPhase {
    /// A thermal warmup day using the first source weather day.
    Warmup {
        /// One-based warmup iteration.
        day: u32,
    },
    /// A reported run-period day, one-based within the environment.
    Run {
        /// One-based simulation day within the environment.
        day: usize,
    },
}

/// Existing shadowing-period coefficients, separate from actual daily coefficients.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ProductionSolarMetadata {
    /// Sine of shadowing-period solar declination.
    pub sin_declination: f64,
    /// Cosine of shadowing-period solar declination.
    pub cos_declination: f64,
    /// Shadowing-period equation of time in hours.
    pub equation_of_time_hours: f64,
}

/// Explicit caller clock copied before the thermal consumer. Production weather
/// supplies its actual owner; prepared manual/legacy callers own a separate
/// lifecycle. No clock is reconstructed from a surface counter or coefficient.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ProductionCtfHistoryClock {
    /// Actual owned weather phase, including independent warmup-day identity.
    pub phase: WeatherDayPhase,
    /// Actual raw-hour request index.
    pub record_index: usize,
    /// Actual BeginSimFlag.
    pub begin_simulation: bool,
    /// Actual BeginEnvrnFlag.
    pub begin_environment: bool,
    /// Actual DayOfSim.
    pub day_of_sim: i32,
    /// Actual HourOfDay.
    pub hour_of_day: i32,
    /// Actual TimeStep.
    pub time_step: i32,
    /// Actual SimTimeSteps, retained independently of the phase/index key.
    pub sim_time_steps: i32,
    /// Actual TimeStepZone in hours.
    pub time_step_zone: f64,
    /// Actual TimeStepZoneSec.
    pub time_step_zone_seconds: f64,
}

impl ProductionCtfHistoryClock {
    pub(crate) fn same_zone_step(self, other: Self) -> bool {
        self.phase == other.phase
            && self.record_index == other.record_index
            && self.day_of_sim == other.day_of_sim
            && self.hour_of_day == other.hour_of_day
            && self.time_step == other.time_step
    }
}

/// Owned operands from the actual Today owner at one thermal timestep.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ProductionWeatherContext {
    /// Actual raw-hour projection, separate from civil calendar identity.
    pub record: EpwRecord,
    /// Actual selected current values with separate sky and solar samples.
    pub sample: WeatherTimestepSample,
    /// Complete processed Today slot, directly used by sky/rain/solar consumers.
    pub weather: WeatherVars,
    /// Actual selected environment after SetCurrentWeather.
    pub current_weather: CurrentWeatherState,
    /// Existing calendar-derived shadowing metadata, not weather-preview values.
    pub solar: ProductionSolarMetadata,
    /// Actual raw-hour ending clock at the current zone timestep.
    pub local_hour: f64,
    /// Passive actual Current completion identity; absent outside C6 capture.
    pub sky_transport_stamp: Option<SkyTransportStamp>,
    /// Genuine caller clock; explicit standalone contexts may have no lifecycle.
    pub ctf_history_clock: Option<ProductionCtfHistoryClock>,
}

/// Actual selected owner view for the ordinary warmup report call boundary.
#[derive(Clone, Debug, PartialEq)]
pub struct ProductionWarmupReportContext {
    /// Actual prepared phase, not a derived convergence count.
    pub phase: WeatherDayPhase,
    /// Actual BeginEnvrnFlag at this consumer.
    pub begin_environment: bool,
    /// Actual WarmupFlag at this consumer.
    pub warmup_flag: bool,
    /// Actual EndDayFlag at this consumer.
    pub end_day: bool,
    /// Actual DayOfSim, HourOfDay and TimeStep.
    pub day: i32,
    /// Actual HourOfDay.
    pub hour: i32,
    /// Actual TimeStep.
    pub time_step: i32,
    /// Actual TimeStepsInHour allocation input.
    pub time_steps_in_hour: i32,
    /// Actual retained RunPeriodEnvironment after the selected getter branch.
    pub run_period_environment: bool,
    /// Actual admitted environment owner.
    pub environment_name: String,
}

/// Production weather lifecycle shared by A and B consumers.
///
/// Its interior owner is borrowed only while advancing or copying operands.
/// Thermal callbacks receive owned values after the borrow has been released.
#[derive(Debug)]
pub struct ProductionWeatherTimestepSeries {
    session: RefCell<WeatherSession>,
    // Separate real kickoff lifecycle; the ordinary phase/duplicate guard is unchanged.
    setup_started: Cell<bool>,
    setup_completed: Cell<bool>,
    // Actual first ReadUserWeatherInput/GetDesignDayData report suffix only.
    setup_design_day_reports_registered: Cell<bool>,
    prepared_phase: RefCell<Option<WeatherDayPhase>>,
    current_phase: RefCell<Option<WeatherDayPhase>>,
    last_consumed: RefCell<Option<(usize, u32)>>,
    current_step: RefCell<Option<(WeatherDayPhase, usize, u32)>>,
    current_step_stamp: RefCell<Option<SkyTransportStamp>>,
}

impl ProductionWeatherTimestepSeries {
    /// Opens actual input bytes; no eager physical series is accepted.
    pub fn from_bytes(
        bytes: Vec<u8>,
        configuration: WeatherEnvironmentConfiguration,
    ) -> Result<Self, WeatherDayError> {
        Ok(Self {
            session: RefCell::new(WeatherSession::new(bytes, configuration)?),
            setup_started: Cell::new(false),
            setup_completed: Cell::new(false),
            setup_design_day_reports_registered: Cell::new(false),
            prepared_phase: RefCell::new(None),
            current_phase: RefCell::new(None),
            last_consumed: RefCell::new(None),
            current_step: RefCell::new(None),
            current_step_stamp: RefCell::new(None),
        })
    }

    /// Prepares actual Today before humidity and CTF seeds. The first day hook
    /// consumes the phase token without another handoff or another prefetch.
    pub fn prepare_initial_phase(&self, phase: WeatherDayPhase) -> Result<(), WeatherDayError> {
        if self.current_phase.borrow().is_some() {
            return Err(WeatherDayError::admission(
                "initial weather phase already prepared",
            ));
        }
        self.admit_phase(phase)?;
        let mut session = self.session.borrow_mut();
        session.set_phase(phase, true);
        if self.setup_completed.get() {
            // RunSimulation does not restore BeginSim after actual kickoff.
            session.state.global.begin_sim_flag = false;
        }
        session.get_next_environment()?;
        session.initialize_weather()?;
        *self.prepared_phase.borrow_mut() = Some(phase);
        *self.current_phase.borrow_mut() = Some(phase);
        Ok(())
    }

    /// Performs one actual source BeginDay transport and its optional prefetch.
    pub fn begin_day(&self, phase: WeatherDayPhase) -> Result<(), WeatherDayError> {
        self.admit_phase(phase)?;
        let prepared = *self.prepared_phase.borrow();
        if let Some(prepared) = prepared {
            if prepared != phase {
                return Err(WeatherDayError::admission(
                    "first weather hook differs from prepared phase",
                ));
            }
            *self.prepared_phase.borrow_mut() = None;
            return Ok(());
        }
        if self.current_phase.borrow().is_none() {
            return Err(WeatherDayError::admission(
                "weather must be prepared before thermal seeds",
            ));
        }
        let mut session = self.session.borrow_mut();
        // SimulationManager.cc:549 completes the previous hour before the next
        // day resets HourOfDay. The weather handoff itself only writes this
        // clock on BeginEnvrn.
        if self
            .last_consumed
            .borrow()
            .is_some_and(|(index, timestep)| {
                index % 24 == 23 && timestep == session.configuration.steps()
            })
        {
            session.state.global.previous_hour = session.state.global.hour_of_day;
        }
        session.set_phase(phase, false);
        session.initialize_weather()?;
        *self.current_phase.borrow_mut() = Some(phase);
        Ok(())
    }

    /// Actual CheckWarmupConvergence -> ManageHeatBalance day-zero boundary.
    /// No weather buffer, cursor, previous-hour or timestep owner is transported.
    pub fn finish_warmup(&self) -> Result<(), WeatherDayError> {
        let mut session = self.session.borrow_mut();
        let actual_last_step = self
            .last_consumed
            .borrow()
            .is_some_and(|(index, timestep)| {
                index % 24 == 23 && timestep == session.configuration.steps()
            });
        if !matches!(
            *self.current_phase.borrow(),
            Some(WeatherDayPhase::Warmup { .. })
        ) || !session.state.global.warmup_flag
            || !session.state.global.end_day_flag
            || !actual_last_step
        {
            return Err(WeatherDayError::admission(
                "warmup exit requires the actual consumed warmup EndDay",
            ));
        }
        session.state.global.warmup_flag = false;
        session.state.global.day_of_sim = 0;
        session.state.global.day_of_sim_chr = "0".into();
        Ok(())
    }

    fn admit_phase(&self, phase: WeatherDayPhase) -> Result<(), WeatherDayError> {
        let valid = match phase {
            WeatherDayPhase::Warmup { day } => day > 0,
            WeatherDayPhase::Run { day } => {
                day > 0 && day <= self.session.borrow().configuration.total_days()
            }
        };
        if valid {
            Ok(())
        } else {
            Err(WeatherDayError::admission(
                "weather phase outside environment",
            ))
        }
    }

    /// Returns owned actual current-day operands for an explicit thermal call.
    #[track_caller]
    pub fn current_for(
        &self,
        record_index: usize,
        timestep: u32,
    ) -> Result<ProductionWeatherContext, WeatherDayError> {
        let phase = self
            .current_phase
            .borrow()
            .ok_or_else(|| WeatherDayError::admission("Today is not prepared"))?;
        let mut session = self.session.borrow_mut();
        let steps = session.configuration.steps();
        if !(1..=steps).contains(&timestep) {
            return Err(WeatherDayError::admission("weather timestep outside hour"));
        }
        let day = match phase {
            WeatherDayPhase::Warmup { .. } => 1,
            WeatherDayPhase::Run { day } => day,
        };
        if record_index / 24 + 1 != day {
            return Err(WeatherDayError::admission(
                "weather request does not belong to actual current day",
            ));
        }
        let hour_zero = record_index % 24;
        let step = (phase, record_index, timestep);
        if *self.current_step.borrow() != Some(step) {
            let hour = hour_zero as i32 + 1;
            if session.state.global.hour_of_day != hour {
                session.state.global.previous_hour = session.state.global.hour_of_day;
            }
            session.state.global.hour_of_day = hour;
            session.state.global.time_step = timestep as i32;
            session.state.global.begin_day_flag = hour_zero == 0 && timestep == 1;
            session.state.global.begin_envrn_flag &= hour_zero == 0 && timestep == 1;
            session.state.global.begin_sim_flag &= hour_zero == 0 && timestep == 1;
            session.state.global.begin_hour_flag = timestep == 1;
            session.state.global.begin_time_step_flag = true;
            session.state.global.end_hour_flag = timestep == steps;
            session.state.global.end_day_flag = hour_zero == 23 && timestep == steps;
            session.state.global.end_envrn_flag = matches!(phase, WeatherDayPhase::Run { .. })
                && record_index + 1 == session.configuration.time_axis.points.len()
                && timestep == steps;
            // The shared day hook has already executed BeginDay Initialize.
            if !session.state.global.begin_day_flag {
                session.initialize_weather()?;
            }
            session.set_current_weather()?;
            *self.current_step_stamp.borrow_mut() = sky_trace::completed_stamp(
                phase,
                record_index,
                session.state.global.hour_of_day,
                session.state.global.time_step,
            );
            // The initial humidity seed and first thermal consumer share one
            // zone step. Both consumer calls remain observable; the accepted
            // current owner is calculated once for this phase/hour/timestep.
            *self.current_step.borrow_mut() = Some(step);
        }
        let produced = session
            .today_produced
            .as_ref()
            .ok_or_else(|| WeatherDayError::admission("Today physical owner unavailable"))?;
        let record = produced.records[hour_zero];
        let mut sample = produced.samples[hour_zero * steps as usize + timestep as usize - 1];
        sample.record_index = record_index;
        let current_weather = session.state.environment.current_weather;
        sample.dry_bulb_c = current_weather.out_dry_bulb_temp;
        sample.wet_bulb_c = current_weather.out_wet_bulb_temp;
        sample.relative_humidity_percent = current_weather.out_rel_hum;
        sample.outdoor_humidity_ratio = current_weather.out_hum_rat;
        sample.atmospheric_pressure_pa = current_weather.out_baro_press;
        sample.wind_speed_m_per_s = current_weather.wind_speed;
        sample.wind_direction_deg = current_weather.wind_dir;
        let weather = session.state.today_values.hour(hour_zero + 1)?[timestep as usize - 1];
        // The sample contract is mm, while the current owner is m. Preserve
        // the actual Today depth instead of a lossy m-to-mm round trip.
        sample.liquid_precipitation_depth_mm = weather.liquid_precip;
        sample.direct_normal_radiation_w_per_m2 = weather.beam_solar_rad;
        sample.diffuse_horizontal_radiation_w_per_m2 = weather.dif_solar_rad;
        sample.horizontal_infrared_radiation_w_per_m2 = weather.horiz_ir_sky;
        let period_start = ((day - 1) / 20) * 20;
        let period_days = 20
            .min(session.configuration.total_days() - period_start)
            .max(1);
        let period_point = session
            .configuration
            .day_point(period_start + 1)
            .ok_or_else(|| WeatherDayError::admission("missing shadowing calendar metadata"))?;
        // Preserve existing solar wrapper's non-leap metadata policy. The actual
        // solar position below is computed separately from the actual raw date.
        let ordinal = super::configuration::ordinal(
            period_point.month as i32,
            period_point.day_of_month as i32,
            0,
        )
        .map_err(WeatherDayError::admission)?;
        let (sin_declination, cos_declination, equation_of_time_hours) =
            crate::heat_balance::solar::energyplus_average_solar_coefficients(
                ordinal as u32,
                period_days,
            );
        let ctf_history_clock = ProductionCtfHistoryClock {
            phase,
            record_index,
            begin_simulation: session.state.global.begin_sim_flag,
            begin_environment: session.state.global.begin_envrn_flag,
            day_of_sim: session.state.global.day_of_sim,
            hour_of_day: session.state.global.hour_of_day,
            time_step: session.state.global.time_step,
            sim_time_steps: session.state.global.sim_time_steps,
            time_step_zone: session.state.global.time_step_zone,
            time_step_zone_seconds: session.state.global.time_step_zone_sec,
        };
        let context = ProductionWeatherContext {
            record,
            sample,
            ctf_history_clock: Some(ctf_history_clock),
            sky_transport_stamp: *self.current_step_stamp.borrow(),
            weather,
            current_weather,
            solar: ProductionSolarMetadata {
                sin_declination,
                cos_declination,
                equation_of_time_hours,
            },
            local_hour: f64::from(record.hour.saturating_sub(1))
                + f64::from(timestep) / f64::from(steps),
        };
        sky_trace::record(
            SkyTransportKind::OwnedContextReceipt,
            context.sky_transport_stamp,
            SkyTransportValues::OwnedContext {
                today: [
                    weather.sky_temp,
                    weather.horiz_ir_sky,
                    weather.total_sky_cover,
                    weather.opaque_sky_cover,
                ],
                sample_ir: context.sample.horizontal_infrared_radiation_w_per_m2,
            },
            None,
        );
        super::production_trace::record_consumer(record_index, timestep, phase, context, &session);
        *self.last_consumed.borrow_mut() = Some((record_index, timestep));
        Ok(context)
    }

    /// Actual Today hour-one dry bulb for initial CTF boundary histories.
    pub fn initial_hourly_dry_bulb_c(&self) -> Result<f64, WeatherDayError> {
        let session = self.session.borrow();
        session
            .today_produced
            .as_ref()
            .map(|day| day.hourly_values[0].out_dry_bulb_temp)
            .ok_or_else(|| WeatherDayError::admission("initial Today record is unavailable"))
    }

    /// Completes an environment if its final timestep did not already rewind it.
    pub fn finish_environment(&self) -> Result<(), WeatherDayError> {
        let mut session = self.session.borrow_mut();
        let last = (
            session.configuration.time_axis.points.len() - 1,
            session.configuration.steps(),
        );
        if *self.last_consumed.borrow() != Some(last) {
            return Ok(());
        }
        if session.state.global.end_envrn_flag {
            return Ok(());
        }
        session.state.global.begin_envrn_flag = false;
        session.state.global.begin_sim_flag = false;
        session.state.global.begin_day_flag = false;
        session.state.global.end_day_flag = true;
        session.state.global.end_envrn_flag = true;
        session.initialize_weather()
    }

    /// Number of metadata-axis hours; no placeholder weather values are returned.
    #[must_use]
    pub fn hourly_count(&self) -> usize {
        self.session.borrow().configuration.time_axis.points.len()
    }
    /// Zone timesteps in each hour.
    #[must_use]
    pub fn zone_steps_per_hour(&self) -> u32 {
        self.session.borrow().configuration.steps()
    }
    /// RunPeriod's declared first-hour policy.
    #[must_use]
    pub fn first_hour_interpolation_starting_values(&self) -> FirstHourInterpolationStartingValues {
        self.session.borrow().configuration.first_policy()
    }
    /// Borrow only actual report operands after the genuine current-step call.
    pub fn warmup_report_context(&self) -> Result<ProductionWarmupReportContext, WeatherDayError> {
        let phase = self
            .current_phase
            .borrow()
            .ok_or_else(|| WeatherDayError::admission("missing report weather phase"))?;
        let session = self.session.borrow();
        let global = &session.state.global;
        Ok(ProductionWarmupReportContext {
            phase,
            begin_environment: global.begin_envrn_flag,
            warmup_flag: global.warmup_flag,
            end_day: global.end_day_flag,
            day: global.day_of_sim,
            hour: global.hour_of_day,
            time_step: global.time_step,
            time_steps_in_hour: global.time_steps_in_hour,
            run_period_environment: session.state.environment.run_period_environment,
            environment_name: session.state.environment.environment_name.clone(),
        })
    }

    /// Read-only owned snapshot for independently collected evidence.
    #[must_use]
    pub fn snapshot(&self) -> super::production_trace::WeatherSessionSnapshot {
        super::production_trace::WeatherSessionSnapshot::from_session(&self.session.borrow())
    }
}

#[cfg(test)]
#[path = "design_day_native_tests.rs"]
pub(super) mod design_day_native_tests;

#!/usr/bin/env python3
"""Held six-TU additive DesignDay Native build; Root executes after Source review."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
PREP = ROOT / '.runtime/porting/SRC-06/ordinary-design-day-native-prep-02'
MANIFEST_SHA = '73f18a49cddf4c35d0bab493be8b1d57da8895e7d12954ae9dfdc8e4f85cfc66'
BUILD = ROOT / '.runtime/ep261-gcc13-o0'
ORIGINAL = ROOT / '.reference/energyplus-src/26.1.0'
TOOLS = ROOT / '.runtime/reference-tools'
CMAKE = TOOLS / 'cmake-4.4.4/cmake-4.4.4-windows-x86_64/bin/cmake.exe'
NINJA = TOOLS / 'ninja-1.13.2/ninja.exe'
RECORDER = ROOT / 'tools/porting/record_command.py'
CORE = BUILD / 'Products/libenergypluslib.a'
TARGET = 'ordinary_design_day_helper'
UNIT = Path('D:/CodexBuild/rusted-energyplus/SRC-06/ordinary-design-day-native-build-01')
META = ROOT / '.runtime/porting/SRC-06/ordinary-design-day-native-build-01'
OLD_INCLUDE = ROOT / '.runtime/porting/SRC-06/ordinary-radiation-producer-native-build-prep-01/additive-reference.cmake'
SNAPSHOT = None  # Required actual current Source SHA256 operand; never a guessed future hash.
COMPILER = TOOLS / 'winlibs-gcc13.2.0-ucrt-r3/mingw64/bin/g++.exe'
PARENT_BUILD = ROOT / '.runtime/porting/SRC-06/ordinary-radiation-producer-native-build-01/native-build.json'
PARENT_BUILD_SHA = '72c06c51c737eb46a6b69e4dc1431a88ac1dde8a3c6ed448fc57c899c81bc0cd'
CORE_BASELINE = {'path':'.runtime/ep261-gcc13-o0/Products/libenergypluslib.a',
                 'sha256':'32d873007f14c3f8e3c66c6280ebd508c7cb595cea28f4a20f47ac745113a694',
                 'size_bytes':1832731010}
ENVIRONMENT = None



def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def ref(path):
    path = Path(path).resolve()
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else path.as_posix(),
            'sha256': sha(path), 'size_bytes': path.stat().st_size}


def checked(row):
    path = ROOT / row['path']
    assert sha(path) == row['sha256'], path
    if 'size_bytes' in row:
        assert path.stat().st_size == row['size_bytes'], path
    return path


def write(path, value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())
    return ref(path)


def cache():
    result = {}
    for line in (BUILD / 'CMakeCache.txt').read_text(encoding='utf-8').splitlines():
        if line and not line.startswith(('#', '//')) and '=' in line:
            key, value = line.split('=', 1)
            result[key] = value
    return result


def commands():
    return json.loads((BUILD / 'compile_commands.json').read_bytes())


def normalized(value):
    return str(value).replace('\\', '/').lower()


def run(name, argv):
    directory = META / (name + '-command-01')
    outer = subprocess.run([sys.executable, '-X', 'utf8', '-B', str(RECORDER),
                            '--output-dir', str(directory), '--', *map(str, argv)], cwd=ROOT, env=ENVIRONMENT)
    receipt_path = directory / 'receipt.json'
    receipt = json.loads(receipt_path.read_bytes())
    assert outer.returncode == receipt['exit_code'] == 0, (name, outer.returncode)
    assert receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after'] is True
    assert receipt['source_snapshot']['sha256'] == SNAPSHOT
    assert receipt['command'] == list(map(str, argv)), name
    return ref(receipt_path), checked(receipt['stdout']).read_text(encoding='utf-8')


def compile_plan(stdout, rows):
    steps = re.findall(r'^\[\d+/\d+\] (.+)$', stdout, re.MULTILINE)
    assert len(steps) == 7, ('expected only six compiles and one link', len(steps))
    for step, row in zip(steps[:6], rows):
        step = normalized(step)
        assert ' -c ' in step and 'g++.exe' in step
        assert normalized(row['file']) in step, row['file']
        output = normalized(Path(row['output']).relative_to(BUILD))
        assert output in step and normalized(TARGET + '.dir') in step
    link = normalized(steps[-1])
    assert 'g++.exe' in link and ' -c ' not in link
    assert normalized(UNIT / 'bin' / (TARGET + '.exe')) in link
    assert normalized('Products/libenergypluslib.a') in link
    assert normalized(UNIT / 'bin' / (TARGET + '.map')) in link
    for row in rows:
        assert normalized(Path(row['output']).relative_to(BUILD)) in link
    return steps


def core_identity():
    value = CORE.stat()
    assert CORE.is_file() and value.st_size == CORE_BASELINE['size_bytes']
    return {'size_bytes':value.st_size, 'mtime_ns':value.st_mtime_ns,
            'device':value.st_dev, 'inode':value.st_ino}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-approval', required=True, help='Root accepted Native Source review path#sha256')
    parser.add_argument('--frozen-environment', required=True, help='Root accepted explicit environment/provider JSON path#sha256')
    parser.add_argument('--required-current-source', required=True, help='Actual current Rust Source snapshot SHA256, verified by every real command receipt')
    args = parser.parse_args()
    global SNAPSHOT
    assert re.fullmatch(r'[0-9a-f]{64}', args.required_current_source), 'Actual Source SHA256 required'
    SNAPSHOT = args.required_current_source
    approval_path, digest = args.source_approval.rsplit('#', 1)
    approval_ref = {'path': approval_path, 'sha256': digest}
    approval = json.loads(checked(approval_ref).read_bytes())
    assert approval.get('accepted') is True or approval.get('status') == 'ACCEPTED_SOURCE_ONLY'
    approval_manifest = approval.get('native_source_manifest', approval.get('native_preparation'))
    assert approval_manifest['sha256'] == MANIFEST_SHA
    held = json.loads((HERE / 'manifest.json').read_bytes())
    assert checked(held['launcher_Source']).resolve() == Path(__file__).resolve()
    checked(held['current_live_registry'])
    checked(held['current_cache'])
    environment_path, environment_sha = args.frozen_environment.rsplit('#', 1)
    environment_ref = {'path':environment_path, 'sha256':environment_sha}
    frozen = json.loads(checked(environment_ref).read_bytes())
    assert frozen['schema'] == 'src06-design-day-native-frozen-build-environment.v1' and frozen['accepted'] is True
    assert frozen['native_source_manifest']['sha256'] == MANIFEST_SHA and frozen['Source_snapshot']['sha256'] == SNAPSHOT
    assert checked(frozen['build_source_manifest']).resolve() == (HERE / 'manifest.json').resolve()
    assert frozen['core_archive_baseline'] == CORE_BASELINE
    global ENVIRONMENT
    ENVIRONMENT = frozen['environment']
    assert isinstance(ENVIRONMENT, dict) and len(ENVIRONMENT)==18
    assert all(isinstance(k,str) and isinstance(v,str) for k,v in ENVIRONMENT.items())
    assert len({k.casefold() for k in ENVIRONMENT}) == len(ENVIRONMENT), 'Ambiguous Windows environment keys'
    env_keys = {k.casefold():v for k,v in ENVIRONMENT.items()}
    assert all(k in env_keys for k in ['path','systemroot','comspec','temp','tmp'])
    assert normalized(env_keys['path'].split(';')[0]) == normalized(COMPILER.parent)
    assert frozen['compiler']['path'] == COMPILER.relative_to(ROOT).as_posix()
    provider_refs = frozen['provider_files']
    assert len({normalized(row['path']) for row in provider_refs}) == len(provider_refs)
    provider_names = {Path(row['path']).name.casefold() for row in provider_refs}
    assert {'g++.exe','cc1plus.exe','collect2.exe','as.exe','ld.exe',
            'libgcc_s_seh-1.dll','libstdc++-6.dll','libwinpthread-1.dll'} <= provider_names
    assert frozen['compiler'] in provider_refs
    assert normalized(str(Path(sys.executable).resolve())) in {normalized(str((ROOT/row['path']).resolve())) for row in provider_refs}
    assert frozen['provider_set_complete_for_this_build'] is True
    version = json.loads(checked(frozen['compiler_version_receipt']).read_bytes())
    assert version['schema'] == 'recorded-porting-command.v1' and version['exit_code'] == 0 and version['launch_error'] is None
    assert version['source_bytes_match_before_and_after'] is True
    assert [normalized(x) for x in version['command']] == [normalized(COMPILER), '--version']
    assert '13.2.0' in checked(version['stdout']).read_text(encoding='utf-8')
    for row in provider_refs:
        checked(row)
    assert sha(PARENT_BUILD) == PARENT_BUILD_SHA
    parent = json.loads(PARENT_BUILD.read_bytes())
    assert parent['schema'] == 'src06-ordinary-radiation-producer-native-build.v1'
    assert parent['core_archive_before'] == parent['core_archive_after'] == CORE_BASELINE
    historical_protected_metadata = ref(checked(parent['protected_before']))
    parent_protected = [ref(OLD_INCLUDE)]  # Do not traverse historical protected/header closure.

    manifest_path = PREP / 'manifest.json'
    assert sha(manifest_path) == MANIFEST_SHA
    manifest = json.loads(manifest_path.read_bytes())
    ranges = json.loads(checked(manifest['Original_ranges']).read_bytes())
    source_refs = [ref(manifest_path)] + manifest['compiled_source_files']
    source_refs += [manifest[key] for key in ['Source_author', 'README',
        'literal_source_additions', 'Original_ranges', 'header', 'CMake_recipe']]
    source_refs += [row[key] for row in manifest['derived_Original_TUs'] for key in ['Original','derived','complete_diff']]
    source_refs += [row[key] for row in manifest['complete_parent_diffs'] for key in ['base','proposal','complete_diff']]
    source_refs += [row[key] for row in ranges for key in ['Original', 'literal']]
    source_refs = list({normalized(row['path']): row for row in source_refs}.values())
    for row in source_refs:
        checked(row)
    assert not UNIT.exists() and not META.exists(), 'Fresh build/output unit required'
    assert not list(BUILD.glob('CMakeFiles/' + TARGET + '.dir/**/*')), 'New target objects must not preexist'
    old_rows = commands()
    assert len(old_rows) == 773 and all(TARGET + '.dir' not in r['output'] for r in old_rows), ('Actual live registry differs from reviewed 773', len(old_rows))
    assert sum('ordinary_radiation_producer_helper.dir' in r['output'] for r in old_rows) == 5
    assert sum('ordinary_radiation_lu_helper.dir' in r['output'] for r in old_rows) == 5
    assert sum('ordinary_temperature_owner_helper.dir' in r['output'] for r in old_rows) == 7
    assert sum('ordinary_readiness_owner_helper.dir' in r['output'] for r in old_rows) == 12
    old_cache = cache()
    assert normalized(old_cache['CMAKE_PROJECT_INCLUDE:UNINITIALIZED']) == normalized(OLD_INCLUDE)
    assert normalized(old_cache['CMAKE_CXX_COMPILER:UNINITIALIZED']) == normalized(COMPILER)
    assert old_cache['CMAKE_BUILD_TYPE:STRING'] == 'RelWithDebInfo'
    assert old_cache['CMAKE_CXX_FLAGS:STRING'] == '-Wa,-mbig-obj -ffp-contract=off'
    assert old_cache['CMAKE_CXX_FLAGS_RELWITHDEBINFO:STRING'] == '-O0 -g -DNDEBUG'
    assert normalized(old_cache['CMAKE_HOME_DIRECTORY:INTERNAL']) == normalized(ORIGINAL)
    # Finite accepted provider/header refs; no new recursive header/history walk.
    protected = parent_protected + provider_refs
    protected += [ref(p) for p in [HERE/'additive-reference.cmake', HERE/'build.py', HERE/'manifest.json']]
    protected += [approval_ref, environment_ref, frozen['compiler_version_receipt'], ref(PARENT_BUILD)]
    protected = list({normalized(row['path']): row for row in protected}.values())
    for row in protected:
        checked(row)
    core_before = dict(CORE_BASELINE)  # Authenticated historical digest, not a fresh hash.
    core_stat_before = core_identity()
    META.mkdir(parents=True)
    (UNIT / 'bin').mkdir(parents=True)
    old_rows_ref = write(META / 'compile-commands-before.json', old_rows)
    old_cache_ref = write(META / 'cache-before.json', old_cache)
    protected_ref = write(META / 'protected-before.json', protected)
    configure_argv = [CMAKE, '-S', ORIGINAL, '-B', BUILD, '-G', 'Ninja',
                      '-DCMAKE_PROJECT_INCLUDE=' + (HERE / 'additive-reference.cmake').as_posix(),
                      '-DORDINARY_DESIGN_DAY_SOURCE_DIR=' + PREP.as_posix(),
                      '-DORDINARY_DESIGN_DAY_OUTPUT_DIR=' + (UNIT / 'bin').as_posix()]
    configure, _ = run('configure', configure_argv)
    current = commands()
    old_keys = Counter(json.dumps(r, sort_keys=True) for r in old_rows)
    new_keys = Counter(json.dumps(r, sort_keys=True) for r in current)
    assert not (old_keys - new_keys), 'Existing compile registration changed'
    extra = new_keys - old_keys
    new_rows = [r for r in current if TARGET + '.dir' in r['output']]
    assert len(current) == 779 and sum(extra.values()) == len(new_rows) == 6
    assert Counter(json.dumps(r, sort_keys=True) for r in new_rows) == extra
    expected = [PREP / name for name in ['surface_consumer_main.cpp', 'WeatherManager.design_day.cc',
        'SimulationManager.design_day.cc', 'surface_consumer_observer.cc']]
    expected += [ORIGINAL / 'src/EnergyPlus/api/EnergyPlusPgm.cc', ORIGINAL / 'src/EnergyPlus/CommandLineInterface.cc']
    assert {normalized(p) for p in expected} == {normalized(ROOT/r['path']) for r in manifest['compiled_source_files']}
    assert {normalized(r['file']) for r in new_rows} == {normalized(p) for p in expected}
    # Preserve the recipe's source order for the six fresh actual compile operations.
    new_rows.sort(key=lambda r: [normalized(p) for p in expected].index(normalized(r['file'])))
    for row in new_rows:
        assert not Path(row['output']).exists(), row['output']
        for token in ['-ffp-contract=off', '-O0', '-g', '-UNDEBUG', '-std=c++20']:
            assert token in row['command'], token
        assert normalized(COMPILER) in normalized(row['command'])
        assert re.findall(r'-(?:D|U)NDEBUG\b', row['command'])[-1] == '-UNDEBUG'
        assert re.findall(r'(?<!\S)-O(?:[0-3sgz]|fast)(?!\S)', row['command'])[-1] == '-O0'
        assert re.findall(r'-ffp-contract=(\w+)', row['command'])[-1] == 'off'
        assert not any(token in row['command'] for token in ['-ffast-math','-Ofast','-funsafe-math-optimizations',
            '-ffinite-math-only','-ffp-contract=fast','-fassociative-math'])
    new_cache = cache()
    allowed = {'CMAKE_PROJECT_INCLUDE:UNINITIALIZED', 'ORDINARY_DESIGN_DAY_SOURCE_DIR:UNINITIALIZED',
               'ORDINARY_DESIGN_DAY_OUTPUT_DIR:UNINITIALIZED'}
    assert {k:v for k,v in old_cache.items() if k not in allowed} == {k:v for k,v in new_cache.items() if k not in allowed}
    dry_run, dry_stdout = run('dry-run', [NINJA, '-C', BUILD, '-n', '-v', TARGET])
    dry_steps = compile_plan(dry_stdout, new_rows)
    compile_receipt, actual_stdout = run('compile', [CMAKE, '--build', BUILD, '--target', TARGET, '--parallel', '1', '--verbose'])
    actual_steps = compile_plan(actual_stdout, new_rows)
    assert actual_steps == dry_steps, 'Actual command list differs from accepted dry run'
    for row in source_refs + protected:
        checked(row)
    core_stat_after = core_identity()
    assert core_stat_after == core_stat_before, 'Actual core file identity/size/mtime changed'
    core_after = dict(CORE_BASELINE)
    binary = UNIT / 'bin' / (TARGET + '.exe')
    link_map = UNIT / 'bin' / (TARGET + '.map')
    with binary.open('rb') as f:
        assert f.read(2) == b'MZ'
    assert link_map.is_file()
    load_lines = []
    with link_map.open(encoding='utf-8') as f:
        for line in f:
            if line.startswith('LOAD '):
                load_lines.append(line.rstrip('\n'))
    providers = []
    for row in new_rows:
        relative = Path(row['output']).relative_to(BUILD).as_posix()
        witnesses = [line for line in load_lines if normalized(relative) in normalized(line)]
        assert len(witnesses) == 1, relative
        providers.append({'object': ref(row['output']), 'map_lines': witnesses})
    result = {'schema':'src06-ordinary-design-day-native-build.v1', 'status':'built-actual-six-TU-core-preserved',
              'native_source_manifest':ref(manifest_path), 'Source_snapshot':{'sha256':SNAPSHOT},
              'source_approval':approval_ref, 'helper_binary':ref(binary), 'map_file':ref(link_map),
              'build_commands':{'configure':configure, 'dry_run':dry_run, 'compile':compile_receipt},
              'core_archive_before':core_before, 'core_archive_after':core_after,
              'old_registration_archive':old_rows_ref, 'old_cache_archive':old_cache_ref,
              'protected_before':protected_ref, 'old_registration_rows_exact':773, 'Original_prior_registration_count':744, 'retained_temperature_registration_count':7, 'retained_readiness_registration_count':12, 'retained_LU_registration_count':5, 'retained_radiation_producer_registration_count':5,
              'new_registration_rows':new_rows, 'new_registration_count':6,
              'target_objects_and_map_LOADs':providers, 'actual_only_six_compiles_one_link':True,
              'frozen_environment':environment_ref, 'explicit_build_providers':provider_refs,
              'historical_core_baseline':CORE_BASELINE, 'historical_radiation_producer_build':ref(PARENT_BUILD), 'historical_protected_metadata_provenance_only':historical_protected_metadata,
              'core_baseline_fresh_hash_verified':False, 'actual_core_stat_before':core_stat_before, 'actual_core_stat_after':core_stat_after,
              'provider_address_binding_requires_separate_Root_review':True,
              'all_protected_refs_unchanged':True, 'unscanned_historical_objects_byte_exact_claimed':False,
              'engine_executed':False, 'integration_PASS_claimed':False, 'gates_updated':False}
    print(json.dumps({'native_build':write(META / 'native-build.json', result)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

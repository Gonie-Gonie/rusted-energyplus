"""Author held weather-only API Source; never run the proposed subsystem."""
import copy
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
UNIT = ROOT / '.runtime/porting/SRC-06/ordinary-setup-weather-host-prep-04'
PARENT = ROOT / '.runtime/porting/SRC-06/ordinary-setup-caller-prep-03/manifest.json'

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def checked(row):
    path = ROOT / row['path']
    assert ref(path) == row
    return path.read_text(encoding='utf-8')

parent = json.loads(PARENT.read_text(encoding='utf-8'))
rows = []
excluded = []
for original in parent['files']:
    row = copy.deepcopy(original)
    canonical = row['canonical_path']
    if canonical in ['crates/ep_runtime/src/heat_balance/mod.rs', 'crates/ep_runtime/src/heat_balance/setup_simulation.rs']:
        excluded.append({'canonical_path': canonical, 'held_proposal': row['proposal']})
        continue
    before = checked(row['proposal'])
    after = before
    if canonical.endswith('weather_day/production/setup.rs'):
        docs = {
            'begin_setup_simulation': 'Begin the selected weather subsystem before ordinary weather access.\n    /// This does not run Exterior, HeatBalance or the Setup postludes.\n    ///\n    /// # Errors\n    /// Reentry, active sizing, or missing real DesignDay/control owners are unavailable.',
            'reset_setup_environment_counter': 'Apply the actual pre-traversal Envrn=0 assignment at SimulationManager270.\n    /// The real caller invokes this once after its early registry/progress prefix.',
            'next_setup_environment': 'Advance the actual DesignDay/RunPeriod weather getter and Setup flags.\n    /// Call after the sole early registry preparation; retain both getter booleans.\n    ///\n    /// # Errors\n    /// Actual getter/report/owner failures retain their original source.',
            'setup_environment_name': 'Borrow the selected actual environment name for caller progress output.',
            'prepare_setup_call': 'Apply the real last-hour clock writes before its caller progress operation.',
            'manage_setup_weather': 'Run actual selected InitializeWeather and SetCurrentWeather once.\n    /// The caller supplies its real ordinal/role and KickOff/reporting authority.\n    /// The three roles remain distinct even when the first two physical clocks match.\n    ///\n    /// # Errors\n    /// Missing active environment or an actual weather producer failure is returned.',
            'with_setup_environment_mut': 'Borrow the sole live environment for a real downstream consumer.',
            'finish_first_setup_call': 'Apply Source2021-2024 only after the real first call consumers return.',
            'finish_setup_simulation': 'Apply only the weather warmup/completion handoff after real caller suffixes.\n    /// This method does not claim that Exterior/HB/cost/fault/curve operations ran.',
        }
        for name, doc in docs.items():
            token = '    pub(crate) fn ' + name
            assert after.count(token) == 1
            after = after.replace(token, '    /// ' + doc + '\n    pub fn ' + name)
    elif canonical.endswith('heat_balance/ctf_initialization_context.rs'):
        anchor = '    pub(crate) fn prepare_registry('
        assert after.count(anchor) == 1
        wrapper = '''    /// Perform the real early SetPredefinedTables prefix for the selected weather host.
    /// The success-only retained flag prevents only this route's later duplicate.
    /// Legacy initialization keeps its established repeated registration behavior.
    ///
    /// # Errors
    /// Returns the actual registry/backend failure with the completed prefix retained.
    pub fn prepare_setup_weather_registry(
        &mut self, model: &TypedModel,
    ) -> Result<(), CtfInitializationError> {
        self.prepare_registry(model)?;
        self.reports.setup_simulation_registry_prepared = true;
        Ok(())
    }

'''
        after = after.replace(anchor, wrapper + anchor)
    if after != before:
        destination = UNIT / 'proposed' / canonical
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(after.encode('utf-8'))
        parent_diff = UNIT / 'parent-diffs' / f'{len(rows)+1:02}.diff'
        parent_diff.parent.mkdir(parents=True, exist_ok=True)
        parent_diff.write_bytes(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='Setup03/'+canonical, tofile=canonical)).encode())
        base = checked(row['base']) if row['base'] else ''
        direct = UNIT / 'diffs' / f'{len(rows)+1:02}.diff'
        direct.parent.mkdir(parents=True, exist_ok=True)
        direct.write_bytes(''.join(difflib.unified_diff(base.splitlines(True), after.splitlines(True), fromfile=canonical, tofile=canonical)).encode())
        row['prior_Setup03_proposal'] = row['proposal']
        row['proposal'] = ref(destination)
        row['complete_parent_Setup03_diff'] = ref(parent_diff)
        row['complete_direct_diff'] = ref(direct)
    rows.append(row)
readme = '''# Held weather subsystem API

This is an eight-path projection of Setup03. Full SetupSimulationOperations/caller
and its HeatBalance module registration remain held and excluded. There are no
fake operations, no new traversal framework, and no full Setup success claim.

The real caller begins weather, calls the sole context.prepare_setup_weather_registry
at the early Source215 boundary, performs its actual progress/kickoff prefix, then
resets Envrn and traverses next_setup_environment. Each environment uses actual
FirstHour, RepeatedFirstHour and LastHour roles; manage_setup_weather acquires the
real local year on BeginEnv. Actual downstream consumers must finish before the
first-role flag handoff. Weather completion remains conditional on real caller
postludes; it must not be used to claim unported HeatBalance/Exterior execution.

GetDesignDayData's six report cells are called once from the actual first getter
before close/increment, with the same caller-owned registry/table. Both Available
and ErrorsFound remain visible for the caller's genuine fatal boundary. None,
ordinary duplicate-clock, and legacy reporting routes retain their previous code.

This packet was authored only. Dependency/lock resolution, actual Native fixture,
compiled API integration and quality checks remain Root-owned release work.
'''
(UNIT/'README.md').write_bytes(readme.encode())
manifest = {
    'schema': 'src06-held-setup-weather-host.v1',
    'status': 'HELD public weather subsystem Source; no full Setup/HB/Exterior activation',
    'actual_canonical_base_Source': parent['actual_canonical_base_Source'],
    'parent_Setup03': ref(PARENT), 'files': rows, 'excluded_held_caller_paths': excluded,
    'README': ref(UNIT/'README.md'), 'author_Source': ref(Path(__file__)),
    'engines_builds_Cargo_tests_executed': False, 'whole_Setup_PASS': False, 'gates_PASS': False,
}
(UNIT/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps(ref(UNIT/'manifest.json')))

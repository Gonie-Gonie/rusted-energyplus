# Held weather subsystem API

This is an eight-path projection of Setup03. Full SetupSimulationOperations/caller
and its HeatBalance module registration remain held and excluded. There are no
fake operations, no new traversal framework, and no full Setup success claim.

The real caller begins weather, calls the sole context.prepare_setup_weather_registry
at the early Source215 boundary, performs its actual progress/kickoff prefix, then
resets Envrn and traverses next_setup_environment. Each environment uses actual
FirstHour, RepeatedFirstHour and LastHour roles; manage_setup_weather acquires the
real local year on BeginEnv. Actual downstream consumers must finish before the
first-role flag handoff. Weather completion remains conditional on real caller
postludes; it must not be used to claim unported HeatBalance/Exterior execution.

GetDesignDayData's six report cells are called once from the actual first getter
before close/increment, with the same caller-owned registry/table. Both Available
and ErrorsFound remain visible for the caller's genuine fatal boundary. None,
ordinary duplicate-clock, and legacy reporting routes retain their previous code.

This packet was authored only. Dependency/lock resolution, actual Native fixture,
compiled API integration and quality checks remain Root-owned release work.

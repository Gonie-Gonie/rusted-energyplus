"""Independently bind actual providers and runtime inputs; never run the engine."""
import argparse
import hashlib
import importlib.util
import json
import mmap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = 'af6f53c88091a2350ba0545ddc4ed1ee200e75c734e6823e979e20b096f9fa18'


def ref(path):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else path.as_posix(),
            'sha256': digest, 'size_bytes': path.stat().st_size}


def checked(row):
    p = ROOT / row['path']
    actual = ref(p)
    assert actual['sha256'] == row['sha256'], p
    assert actual['size_bytes'] == row.get('size_bytes', actual['size_bytes']), p
    return p


def load(row):
    return json.loads(checked(row).read_bytes())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--native-build', required=True)
    parser.add_argument('--peer-review', required=True)
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()

    def bound(value):
        name, digest = value.rsplit('#', 1)
        row = ref(ROOT / name)
        assert row['sha256'] == digest
        return row, load(row)

    build_ref, build = bound(args.native_build)
    peer_ref, peer = bound(args.peer_review)
    assert build['schema'] == 'src06-ordinary-design-day-native-build.v1'
    assert build['status'] == 'built-actual-six-TU-core-preserved'
    assert build['new_registration_count'] == 6 and build['actual_only_six_compiles_one_link'] is True
    assert build['engine_executed'] is False
    assert peer['accepted'] and peer['helper_binary'] == build['helper_binary']
    assert peer['native_build']['sha256'] == build_ref['sha256']
    assert (ROOT / peer['native_build']['path']).resolve() == (ROOT / build_ref['path']).resolve()
    assert peer['Source_snapshot']['sha256'] == build['Source_snapshot']['sha256'] == SOURCE
    prep = load(build['native_source_manifest'])
    expected_sources = {row['path']: row['sha256'] for row in prep['compiled_source_files']}
    binary = checked(build['helper_binary'])
    pe_source = ROOT / 'tools/porting/native_pe.py'
    assert ref(pe_source)['sha256'] == 'afef047aec5a0bb5be90b6da155688b9bbaa672dd4dd90615569396d306cba56'
    spec = importlib.util.spec_from_file_location('root_design_day_native_pe', pe_source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    mapping = module.inspect(binary)
    assert mapping == load(peer['actual_PE'])
    assert mapping['machine'] == 0x8664 and len(mapping['data_directories']) == 16
    providers = load(peer['actual_address_bound_providers'])
    assert len(providers) == peer['selected_providers']
    for name in ['SetupSimulation', 'GetNextEnvironment', 'GetDesignDayData', 'ManageWeather', 'InitializeWeather', 'UpdateWeatherData', 'SetUpDesignDay', 'SetCurrentWeather']:
        assert sum(('::' + name + '(') in row['symbol'] for row in providers) == 1, name
    wanted_lines = {}
    with binary.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
        for row in providers:
            source = row['actual_source']
            assert expected_sources[source['path']] == source['sha256']
            checked(source)
            rva = row['address'] - mapping['image_base']
            length = row['end'] - row['address']
            sections = [s for s in mapping['sections'] if s['characteristics'] & 0x20000000
                        and s['rva'] <= rva and rva + length <= s['rva'] + s['raw_size']]
            assert len(sections) == 1 and length == row['code_byte_count'] > 0
            section = sections[0]
            offset = section['raw_offset'] + rva - section['rva']
            assert offset == row['PE_raw_offset'] and section['name'] == row['PE_section']
            assert hashlib.sha256(data[offset:offset + length]).hexdigest() == row['code_bytes_sha256']
            assert row['section']['start'] <= row['address'] < row['end'] <= row['section']['start'] + row['section']['size']
            assert row['section']['owner'] == row['spec']['owner']
            wanted_lines[row['line']] = row['literal']
            wanted_lines[row['section']['line']] = row['section']['literal']
    with checked(build['map_file']).open(encoding='utf8') as stream:
        for number, line in enumerate(stream, 1):
            if number in wanted_lines:
                assert line.rstrip('\n') == wanted_lines.pop(number)
    assert not wanted_lines
    addr = load(peer['actual_addr2line_execution'])
    assert addr['exit_code'] == 0 and addr['launch_error'] is None and addr['source_bytes_match_before_and_after']
    assert addr['source_snapshot']['sha256'] == SOURCE
    resolved = checked(addr['stdout']).read_text(encoding='utf8').splitlines()
    checked(addr['stderr'])
    assert len(resolved) == 2 * len(providers)
    for index, row in enumerate(providers):
        assert resolved[2 * index] == row['symbol'] == row['actual_addr2line_function']
        assert resolved[2 * index + 1].replace('\\', '/') == row['actual_addr2line_location']
    assert build['core_archive_before'] == build['core_archive_after']
    assert build['core_archive_after']['sha256'] == '32d873007f14c3f8e3c66c6280ebd508c7cb595cea28f4a20f47ac745113a694'
    assert build['core_baseline_fresh_hash_verified'] is False
    assert build['actual_core_stat_before'] == build['actual_core_stat_after']
    assert build['actual_core_stat_after']['size_bytes'] == build['core_archive_after']['size_bytes']
    environment = load(build['frozen_environment'])
    assert ref(checked(build['frozen_environment']))['sha256'] == '54ad7290f4e223ebc61c64580796b6e2a16f6107147ae71d47fd43a300a5db9f'
    assert environment['accepted'] is True and environment['Source_snapshot']['sha256'] == SOURCE
    assert environment['native_source_manifest']['sha256'] == build['native_source_manifest']['sha256']
    roles = [{'role': role, 'execution': build['build_commands'][key]}
             for role, key in [('configure', 'configure'), ('dry_run', 'dry_run'), ('compile', 'compile')]]
    for row in roles:
        receipt = load(row['execution'])
        assert receipt['exit_code'] == 0 and receipt['launch_error'] is None
        assert receipt['source_bytes_match_before_and_after'] and receipt['source_snapshot']['sha256'] == SOURCE
        checked(receipt['stdout'])
        checked(receipt['stderr'])
    dll_dir = ROOT / '.runtime/reference-tools/winlibs-gcc13.2.0-ucrt-r3/mingw64/bin'
    pins = {'libgcc_s_seh-1.dll': '403b4169b307d0bfb27a9cbcccbca491efe634eb0462fc1f3fc5ace373bd2827',
            'libstdc++-6.dll': '748b10c9f25828fbc78e8eaf50355e7f178d0ed0438d2c396565b56c5bd4ac0a',
            'libwinpthread-1.dll': 'a086938c9612746fda0ab8640b8d21e8d36bc3e53c1e8e70f9896888b41607dd'}
    dlls = [ref(dll_dir / name) for name in pins]
    assert all(row['sha256'] == pins[Path(row['path']).name] for row in dlls)
    out = ROOT / args.output_dir
    out.mkdir(parents=True, exist_ok=False)

    def write(name, value):
        p = out / name
        with p.open('xb') as f:
            f.write((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())
        return ref(p)

    pe_ref = write('pe.json', mapping)
    provider_ref = write('review.json', {
        'schema': 'src06-ordinary-design-day-Root-provider-acceptance.v1', 'accepted': True,
        'native_build': build_ref, 'binary': build['helper_binary'], 'native_source_manifest': build['native_source_manifest'],
        'independent_provider_review': peer_ref, 'independent_full_PE': pe_ref,
        'actual_address_bound_providers': peer['actual_address_bound_providers'],
        'actual_addr2line_execution': peer['actual_addr2line_execution'],
        'all_actual_provider_byte_ranges_and_map_lines_rechecked': True, 'actual_provider_count': len(providers),
        'full_PE_independently_recomputed_equal': True, 'historical_core_baseline_matches_accepted_producer_metadata': True,
        'core_fresh_byte_hash_verified': False, 'actual_core_stat_continuity_verified': True,
        'helper_executed': False, 'scientific_PASS_claimed': False, 'gates_updated': False,
        'review_Source': ref(Path(__file__))})
    closure_ref = write('runtime-closure.json', {
        'schema': 'src06-ordinary-design-day-native-runtime-closure.v1', 'accepted': True,
        'native_build': build_ref, 'native_source_manifest': build['native_source_manifest'],
        'helper_binary': build['helper_binary'], 'Source_snapshot': build['Source_snapshot'],
        'frozen_environment': ref(checked(build['frozen_environment'])),
        'pinned_runtime_DLLs': dlls, 'provider_review': provider_ref, 'build_commands': roles})
    print(json.dumps({'provider_review': provider_ref, 'runtime_closure': closure_ref}))


if __name__ == '__main__':
    main()

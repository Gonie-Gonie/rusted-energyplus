"""Apply the reviewed weather unit after the one authentic Native capture closed."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
base = root / '.runtime/porting/SRC-06'

def ref(path):
    data = path.read_bytes()
    return dict(path=path.relative_to(root).as_posix(), sha256=hashlib.sha256(data).hexdigest(), size_bytes=len(data))

def checked(row):
    path = root / row['path']
    assert ref(path)['sha256'] == row['sha256'], row
    return path

plan = base / 'ordinary-design-day-application-plan-01.json'
assert ref(plan)['sha256'] == 'a35c77ed3eec082aa5b26cc59a3e01409687071d885175a3978b947aa5cc0330'
manifest = json.loads(plan.read_bytes())
capture = base / 'ordinary-design-day-native-capture-command-01/receipt.json'
assert ref(capture)['sha256'] == '7952d77089e5c74bd9e78c94c33f6e04a464d504d65d2d09d3f3ea28ecb26fbf'
receipt = json.loads(capture.read_bytes())
assert receipt['exit_code'] == 0 and receipt['source_bytes_match_before_and_after'] is True
assert receipt['source_snapshot']['sha256'] == manifest['expected_current_Source']
spec = importlib.util.spec_from_file_location('actual_source_recorder', root / 'tools/porting/record_command.py')
recorder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recorder)
assert recorder.source_snapshot()['sha256'] == manifest['expected_current_Source']
out = base / 'ordinary-design-day-application-01'
out.mkdir(exist_ok=False)
changes = []
for row in manifest['files']:
    canonical = root / row['canonical_path']
    before = b'' if row['base'] is None else checked(row['base']).read_bytes()
    assert (not canonical.exists()) if row['base'] is None else canonical.read_bytes() == before
    after = checked(row['proposal']).read_bytes()
    if canonical.name == 'ctf_reports.rs':
        # Gather's integer overload remains held with its actual caller. Only
        # the genuinely consumed DD fixed2/shared formatter is released here.
        text = after.decode('utf-8')
        start = text.index('    /// Integer overload assigns only text/object/column, retaining real metadata.')
        end = text.index('\n}', start)
        text = text[:start] + text[end:]
        after = text.encode('utf-8')
    canonical.parent.mkdir(parents=True, exist_ok=True)
    canonical.write_bytes(after)
    diff = out / f'{len(changes):02}.diff'
    diff.write_text(''.join(difflib.unified_diff(before.decode('utf-8').splitlines(True), after.decode('utf-8').splitlines(True), fromfile=row['canonical_path'], tofile=row['canonical_path'])), encoding='utf-8', newline='\n')
    changes.append(dict(canonical=ref(canonical), reviewed_proposal=row['proposal'], applied_complete_diff=ref(diff)))
result = dict(schema='src06-design-day-weather-actual-application.v1', plan=ref(plan),
    capture_execution=ref(capture), files=changes,
    integer_Gather_overload_released=False, full_Setup_or_port_PASS=False,
    author_Source=ref(Path(__file__)))
file = out / 'application.json'
file.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(application=ref(file), files=len(changes))))

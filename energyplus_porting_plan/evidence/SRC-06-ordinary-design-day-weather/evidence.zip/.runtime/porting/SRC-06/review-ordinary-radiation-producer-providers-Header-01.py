"""One actual read-only map/PE/provider review; never call a helper or build."""
from pathlib import Path
from collections import Counter
import argparse, hashlib, importlib.util, json, mmap, re, subprocess, sys

ROOT=Path(__file__).resolve().parents[3]
BUILD=ROOT/'.runtime/ep261-gcc13-o0'
OUT=ROOT/'.runtime/porting/SRC-06/Header-ordinary-radiation-producer-provider-review-01'

digests={}
def ref(p):
    p=Path(p).resolve()
    if p not in digests:
        with p.open('rb') as f: digests[p]=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else p.as_posix(),sha256=digests[p],size_bytes=p.stat().st_size)
def check(r):
    p=ROOT/r['path'];v=ref(p);assert v['sha256']==r['sha256'],p
    if 'size_bytes'in r:assert v['size_bytes']==r['size_bytes'],p
    return p
def load(r):return json.loads(check(r).read_bytes())
def write(name,value):
    p=OUT/name;p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf8');return ref(p)
def norm(p):return str(p).replace('\\','/').lower()

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--native-build',required=True,help='Actual closed radiation producer build path#sha256')
parser.add_argument('--native-source',required=True,help='Approved radiation producer Source01 manifest path#sha256')
args=parser.parse_args()
def operand(text):
    path,digest=text.rsplit('#',1);assert re.fullmatch('[0-9a-f]{64}',digest)
    return dict(path=path,sha256=digest)
build_ref=ref(check(operand(args.native_build)));source_ref=ref(check(operand(args.native_source)))
b=load(build_ref)
assert b['schema']=='src06-ordinary-radiation-producer-native-build.v1'
assert b['status']=='built-actual-five-TU-core-preserved' and b['engine_executed'] is False
assert b['gates_updated'] is False and b['unscanned_historical_objects_byte_exact_claimed'] is False
assert b['Source_snapshot']['sha256']=='779fc20679fcc6ff4ebc03cb6d88e5398086e16b67e68a57cef194782d375ca4'
assert check(b['native_source_manifest']).resolve()==check(source_ref).resolve()
assert b['native_source_manifest']['sha256']==source_ref['sha256']
prep=load(source_ref)
assert prep['schema']=='src06-ordinary-radiation-producer-native-Source-prep.v1'
assert source_ref['sha256']=='577b28bd0beaf583b58dc04b4c4d55465ebb15fa0346fdd8285169def22cb162'
ranges=load(prep['Original_ranges'])
source_refs=prep['compiled_source_files']+[prep[k]for k in ['Source_author','README','Original','derived_Original','literal_source_additions','Original_ranges','self_check','comparison_policy','header','CMake_recipe']]+[x[k]for x in ranges for k in ['Original','literal']]
source_refs += [row[key] for row in prep['complete_diffs'] for key in ['base','proposal','complete_diff']]
for row in source_refs:check(row)
OUT.mkdir(exist_ok=False)
protected_before=load(b['protected_before'])
assert b['all_protected_refs_unchanged'] is True  # Genuine builder checked these; no duplicate provider/history byte scan here.
binary=check(b['helper_binary']);linkmap=check(b['map_file'])
assert b['core_archive_before']==b['core_archive_after']==b['historical_core_baseline']
assert b['core_baseline_fresh_hash_verified'] is False
assert b['actual_core_stat_before']==b['actual_core_stat_after']
core=BUILD/'Products/libenergypluslib.a';core_stat=core.stat()
actual_core_stat={'size_bytes':core_stat.st_size,'mtime_ns':core_stat.st_mtime_ns,'device':core_stat.st_dev,'inode':core_stat.st_ino}
assert actual_core_stat==b['actual_core_stat_after'] and actual_core_stat['size_bytes']==b['historical_core_baseline']['size_bytes']
historical_LU_build=load(b['historical_LU_build'])
assert historical_LU_build['schema']=='src06-ordinary-radiation-lu-native-build.v1'
assert historical_LU_build['core_archive_before']==historical_LU_build['core_archive_after']==b['historical_core_baseline']
freeze=ROOT/'.runtime/porting/SRC-05/cold-guard-native-build-01/frozen-build-inputs.json'
assert ref(freeze)['sha256']=='ce5d01f106323a9354cc656ee81e07fef06b8e50b9280e8e8e1600d88342a3c5'
frozen_core=[]
def find_core(v):
    if isinstance(v,dict):
        if v.get('path','').endswith('/Products/libenergypluslib.a'):frozen_core.append(v)
        for x in v.values():find_core(x)
    elif isinstance(v,list):
        for x in v:find_core(x)
find_core(json.loads(freeze.read_bytes()))
assert frozen_core and all(x==b['core_archive_before'] for x in frozen_core)
old=load(b['old_registration_archive']);now=json.loads((BUILD/'compile_commands.json').read_bytes())
oldc=Counter(json.dumps(x,sort_keys=True)for x in old);nowc=Counter(json.dumps(x,sort_keys=True)for x in now)
assert len(old)==768 and len(now)==773 and not oldc-nowc
assert nowc-oldc==Counter(json.dumps(x,sort_keys=True)for x in b['new_registration_rows'])
receipts={k:load(v)for k,v in b['build_commands'].items()}
for x in receipts.values():
    assert x['exit_code']==0 and x['launch_error'] is None and x['source_bytes_match_before_and_after'] is True
    assert x['source_snapshot']['sha256']==b['Source_snapshot']['sha256']
    check(x['stdout']);check(x['stderr'])
assert receipts['configure']['finished_utc']<=receipts['dry_run']['started_utc']<=receipts['dry_run']['finished_utc']<=receipts['compile']['started_utc']
steps=lambda x:re.findall(r'^\[\d+/\d+\] (.+)$',check(x['stdout']).read_text(encoding='utf8'),re.MULTILINE)
assert steps(receipts['compile'])==steps(receipts['dry_run']) and len(steps(receipts['compile']))==6
objects={}
for row in b['new_registration_rows']:
    p=Path(row['output']);check(next(x['object']for x in b['target_objects_and_map_LOADs']if check(x['object'])==p))
    objects[Path(row['file']).name]=p.relative_to(BUILD).as_posix()
specs=[]
def add(prefix,source,exact=False,debug_source=None):specs.append(dict(prefix=prefix,source=source,debug_source=debug_source or source,owner=objects[source],exact=exact))
for name in ['CalcScriptF','CalcMatrixInverse','FixViewFactors']:
    add('EnergyPlus::HeatBalanceIntRadExchange::'+name+'(','HeatBalanceIntRadExchange.radiation_producer.cc')
add('EnergyPlusPgm(','EnergyPlusPgm.cc')
add('EnergyPlus::CommandLineInterface::ProcessArgs(','CommandLineInterface.cc')
for name in ['record_marker','record_matrices','record_pivot','record_fix','record_scriptf','finish']:
    add('SurfaceConsumerObservation::'+name+'(','surface_consumer_observer.cc')
add('main','surface_consumer_main.cpp',True)
assert len(specs)==12 and len(objects)==5

selected=[];loads=[];section=pending=None
section_re=re.compile(r'^\s+(\.text\S*)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(.+?)\s*$')
continued_re=re.compile(r'^\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(.+?)\s*$')
symbol_re=re.compile(r'^\s+(0x[0-9a-fA-F]+)\s+(.+?)\s*$')
with linkmap.open(encoding='utf8')as f:
    for number,line in enumerate(f,1):
        line=line.rstrip('\n');m=section_re.match(line)
        if m:section=dict(name=m[1],start=int(m[2],16),size=int(m[3],16),owner=m[4],literal=line,line=number);pending=None
        elif re.match(r'^\s+\.text\S*\s*$',line):pending=dict(name=line.strip(),name_literal=line,name_line=number)
        elif pending and (m:=continued_re.match(line)):
            section=dict(**pending,start=int(m[1],16),size=int(m[2],16),owner=m[3],literal=line,line=number);pending=None
        if line.startswith('LOAD ')and('ordinary_radiation_producer_helper.dir/'in line or line=='LOAD Products/libenergypluslib.a'):
            loads.append(dict(line=number,literal=line))
        m=symbol_re.match(line)
        if not(m and section and section['start']<=int(m[1],16)<section['start']+section['size']):continue
        address,name=int(m[1],16),m[2]
        for row in selected:
            if row['section']==section and address>row['address'] and 'end'not in row:row['end']=address
        for spec in specs:
            matched=name==spec['prefix'] if spec['exact']else name.startswith(spec['prefix'])and'::{'not in name and' [clone 'not in name
            if matched:
                assert norm(section['owner'])==norm(spec['owner']),(name,section['owner'],spec['owner'])
                selected.append(dict(spec=spec,symbol=name,address=address,address_hex=m[1],section=dict(section),literal=line,line=number))
assert len(loads)==6 and all(sum(x['spec']==s for x in selected)==1 for s in specs),(len(loads),[s['prefix']for s in specs if sum(x['spec']==s for x in selected)!=1])
for row in selected:row.setdefault('end',row['section']['start']+row['section']['size'])
pe_source=ROOT/'tools/porting/native_pe.py';assert ref(pe_source)['sha256']=='afef047aec5a0bb5be90b6da155688b9bbaa672dd4dd90615569396d306cba56'
spec=importlib.util.spec_from_file_location('actual_accepted_native_pe',pe_source);pe=importlib.util.module_from_spec(spec);spec.loader.exec_module(pe)
mapping=pe.inspect(binary);assert mapping['sha256']==b['helper_binary']['sha256']
pe_ref=write('actual-PE.json',mapping)
with binary.open('rb')as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as data:
    for row in selected:
        rva=row['address']-mapping['image_base'];length=row['end']-row['address'];assert length>0
        sections=[s for s in mapping['sections']if not s['debug']and s['characteristics']&0x20000000 and s['rva']<=rva and rva+length<=s['rva']+s['raw_size']];assert len(sections)==1
        s=sections[0];offset=s['raw_offset']+rva-s['rva'];payload=data[offset:offset+length]
        row.update(code_bytes_sha256=hashlib.sha256(payload).hexdigest(),code_byte_count=length,PE_section=s['name'],PE_raw_offset=offset)
addr=ROOT/'.runtime/reference-tools/winlibs-gcc13.2.0-ucrt-r3/mingw64/bin/addr2line.exe'
assert ref(addr)['sha256']=='2a09b9eb95ea235075831caf186c746c1e4a2c566a2b065f13ce8912df3b5885'
command=[str(addr),'-f','-C','-e',str(binary),*[x['address_hex']for x in selected]]
directory=OUT/'addr2line-command-01'
result=subprocess.run([sys.executable,'-X','utf8','-B',str(ROOT/'tools/porting/record_command.py'),'--output-dir',str(directory),'--',*command],cwd=ROOT)
receipt=json.loads((directory/'receipt.json').read_bytes());assert result.returncode==receipt['exit_code']==0 and receipt['command']==command
assert receipt['source_snapshot']['sha256']==b['Source_snapshot']['sha256']and receipt['source_bytes_match_before_and_after']is True
resolved=check(receipt['stdout']).read_text(encoding='utf8').splitlines();assert len(resolved)==2*len(selected)
for i,row in enumerate(selected):
    assert resolved[2*i]==row['symbol'],(resolved[2*i],row['symbol'])
    location=resolved[2*i+1].replace('\\','/');match=re.search(r'^(.*):(\d+)(?: \(discriminator \d+\))?$',location);assert match,location
    path=Path(match[1]);assert path.name==row['spec']['debug_source']and path.is_file(),location
    expected_path = next((ROOT/x['path'] for x in prep['compiled_source_files'] if Path(x['path']).name==row['spec']['debug_source']), None)
    assert expected_path is not None and path.resolve()==expected_path.resolve(),location
    source_line=int(match[2]);assert 1<=source_line<=len(path.read_bytes().splitlines())
    row.update(actual_addr2line_function=resolved[2*i],actual_addr2line_location=location,actual_source=ref(path),actual_source_line=source_line)
providers_ref=write('actual-address-bound-providers.json',selected)
review=dict(schema='src06-ordinary-radiation-producer-native-provider-review.v1',accepted=True,native_build=build_ref,helper_binary=b['helper_binary'],binary=b['helper_binary'],native_source_manifest=b['native_source_manifest'],Source_snapshot=b['Source_snapshot'],actual_PE=pe_ref,actual_address_bound_providers=providers_ref,actual_addr2line_execution=ref(directory/'receipt.json'),actual_build_commands=b['build_commands'],frozen_SRC05_build_inputs=ref(freeze),historical_core_archive=b['historical_core_baseline'],historical_core_baseline_matches_accepted_SRC05_metadata=True,core_baseline_fresh_hash_verified=False,actual_core_stat_continuity=actual_core_stat,old768_registration_rows_exact=True,retained_temperature_registration_rows=7,retained_readiness_registration_rows=12,retained_LU_registration_rows=5,new_compile_rows=5,actual_only_five_compiles_and_one_link=True,selected_providers=len(selected),fresh_target_objects=len(objects),actual_target_and_core_LOADs=loads,all_selected_map_addresses_bound_to_actual_executable_PE_bytes=True,all_selected_providers_addr2line_bind_actual_Source=True,PE_sections=len(mapping['sections']),PE_directories=len(mapping['data_directories']),runtime_reference_counts=mapping['runtime_references']['counts'],provider_extent_caveat='Next mapped text symbol in same actual input text section, otherwise input section end; may include local code or padding. Static provenance is not an engine inner invocation trace.',protected_guard_refs_reused_from_actual_build=len(protected_before),protected_provider_bytes_rescanned=False,unscanned_historical_objects_byte_exact_claimed=False,helper_executed=False,scientific_PASS_claimed=False,gates_updated=False,review_Source=ref(Path(__file__)))
print(json.dumps(dict(review=write('review.json',review),providers=len(selected))))

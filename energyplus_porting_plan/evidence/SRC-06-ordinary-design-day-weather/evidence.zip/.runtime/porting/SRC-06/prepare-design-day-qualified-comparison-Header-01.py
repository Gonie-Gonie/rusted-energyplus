"""Emit held comparison Source only; never import/run Rust or mutate canonical."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-design-day-qualified-comparison-prep-Header-01'
TARGET = 'crates/ep_runtime/src/weather_day/design_day_native_tests.rs'

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

old = (ROOT / TARGET).read_bytes()
source = old.decode('utf-8').replace('\r\n', '\n')
assert 'static BIT_DIAGNOSTIC:' in source
source = source.replace('pub(crate) fn verify_actual_design_day_weather() -> TestResult {\n',
    'pub(crate) fn verify_actual_design_day_weather() -> TestResult {\n    NUMERICAL_ASSESSMENT.with_borrow_mut(|values| values.clear());\n', 1)
anchor = '            let snapshot = series.snapshot();\n'
assert source.count(anchor) == 1
source = source.replace(anchor, anchor + '''            // UpdateWeatherData copies this selected DesignDay's full Tomorrow
            // carrier to Today. Test that transport against Rust's own produced
            // carrier; computed Native values have the separately declared scope.
            assert_eq!(snapshot.state.today_values.is_allocated(), snapshot.state.tomorrow_values.is_allocated());
            assert_eq!(snapshot.state.today_values.time_steps(), snapshot.state.tomorrow_values.time_steps());
            assert_eq!(snapshot.state.today_values.hours(), snapshot.state.tomorrow_values.hours());
            assert_eq!(snapshot.state.today_values.slots().len(), snapshot.state.tomorrow_values.slots().len());
            for (today, tomorrow) in snapshot.state.today_values.slots().iter().zip(snapshot.state.tomorrow_values.slots()) {
                assert_eq!(today.boolean_values(), tomorrow.boolean_values());
                assert_eq!(today.real_values().map(f64::to_bits), tomorrow.real_values().map(f64::to_bits), "literal full DesignDay weather carrier copy");
            }
''', 1)
begin = source.index('    let mismatches = BIT_DIAGNOSTIC.with_borrow(')
end = source.index('    Ok(())\n}', begin)
source = source[:begin] + '''    let assessments = NUMERICAL_ASSESSMENT.with_borrow(|values| values.clone());
    for field in PSY_CALLER_FIELDS.into_iter().chain(UNPAIRED_FIELDS) {
        assert!(assessments.contains_key(field), "declared numerical field was not observed: {field}");
    }
    for (name, (observations, nonidentical_bits, max_absolute)) in assessments {
        let role = match real_scope(&name)? {
            NativeRealScope::PsyCaller { .. } => "inherited-PSY-caller-output-assessment; PSY-input/cache-pairing-unobserved",
            NativeRealScope::UnpairedComputed => "UNPAIRED-computed-output; no-numerical-PASS",
            NativeRealScope::ExactBits => return Err("exact field incorrectly entered numerical accounting".into()),
        };
        eprintln!("DD scoped assessment {name}: {role}; {observations} observations; {nonidentical_bits} nonidentical bits; maximum absolute {max_absolute:e}");
    }
    // The immutable strict-bit diagnostic remains FAIL. Passing this regression
    // certifies its declared transport/owner scope, never all Native weather,
    // PSY cache/input pairing, full Setup, or a libm attribution.
''' + source[end:]
begin = source.index('fn real(actual: f64, native: &Value, name: &str) -> TestResult {')
source = source[:begin] + '''#[derive(Clone, Copy)]
enum NativeRealScope {
    ExactBits,
    PsyCaller { atol: f64, rtol: f64 },
    UnpairedComputed,
}

const PSY_CALLER_FIELDS: [&str; 5] = [
    "OutDewPointTemp", "OutWetBulbTemp", "OutHumRat", "OutEnthalpy", "OutAirDensity",
];
const UNPAIRED_FIELDS: [&str; 8] = [
    "OutRelHum", "OutRelHumValue", "SkyTemp", "SkyTempKelvin", "HorizIRSky",
    "BeamSolarRad", "DifSolarRad", "GndSolarRad",
];

fn real_scope(name: &str) -> Result<NativeRealScope, Box<dyn std::error::Error>> {
    let field = name.rsplit('.').next().ok_or("missing field name")?;
    let scope = match field {
        // These constants already existed in frozen PSY-01/02 contracts. Here
        // they assess caller outputs only: intermediate/cache inputs were not
        // captured, so this cannot certify paired PSY calls/cache parity.
        "OutDewPointTemp" | "OutWetBulbTemp" => NativeRealScope::PsyCaller { atol: 1.0e-10, rtol: 1.0e-13 },
        "OutHumRat" | "OutAirDensity" => NativeRealScope::PsyCaller { atol: 1.0e-12, rtol: 1.0e-13 },
        "OutEnthalpy" => NativeRealScope::PsyCaller { atol: 1.0e-7, rtol: 1.0e-13 },
        "OutRelHum" | "OutRelHumValue" | "SkyTemp" | "SkyTempKelvin" | "HorizIRSky"
        | "BeamSolarRad" | "DifSolarRad" | "GndSolarRad" => NativeRealScope::UnpairedComputed,
        // No fallback classification: every remaining currently compared real
        // carrier is named explicitly and retains strict signed-zero bit checks.
        "PressBarom" | "OutDryBulbTemp" | "spSiteSchedules" | "origRealEntry"
        | "Interpolation" | "SolarInterpolation" | "TimeStepFraction"
        | "CurrentTime" | "TimeStepZone" | "TimeStepZoneSec"
        | "SinSolarDeclinAngle" | "CosSolarDeclinAngle" | "EquationOfTime"
        | "OutBaroPress" | "WindSpeed" | "WindDir" | "Albedo" | "WaterPrecip"
        | "LiquidPrecip" | "TotalSkyCover" | "OpaqueSkyCover" | "LiquidPrecipitation"
        | "GndReflectance" | "GndReflectanceForDayltg" | "TotalCloudCover"
        | "OpaqueCloudCover" | "SOLCOS" | "CosLatitude" | "Elevation" | "Latitude"
        | "Longitude" | "SinLatitude" | "StdBaroPress" | "TS1TimeOffset"
        | "TimeZoneMeridian" | "TimeZoneNumber" | "HrAngle" | "SnowGndRefModifier"
        | "SnowGndRefModifierForDayltg" | "SolarAltitudeAngle" | "SolarAzimuthAngle"
        | "GroundReflectances" => NativeRealScope::ExactBits,
        _ => return Err(format!("undeclared Native real comparison field: {name}").into()),
    };
    Ok(scope)
}

fn real(actual: f64, native: &Value, name: &str) -> TestResult {
    let bits = u64::from_str_radix(
        native["value_bits"].as_str().ok_or_else(|| format!("missing bits {name}: {native}"))?,
        16,
    )?;
    let expected = f64::from_bits(bits);
    // This selected fixture was independently audited as finite/+zero only.
    // No nonfinite value or signed-zero change can pass a numerical exemption.
    assert!(actual.is_finite() && expected.is_finite(), "{name} selected finite domain");
    assert_eq!(actual.classify(), expected.classify(), "{name} IEEE class");
    if actual == 0.0 && expected == 0.0 {
        assert_eq!(actual.to_bits(), bits, "{name} signed zero");
    }
    match real_scope(name)? {
        NativeRealScope::ExactBits => assert_eq!(actual.to_bits(), bits, "{name} exact carrier bits"),
        scope => {
            let difference = (actual - expected).abs();
            if let NativeRealScope::PsyCaller { atol, rtol } = scope {
                assert!(difference <= atol + rtol * expected.abs(), "{name} inherited PSY caller-output bound: Rust {actual:?}, Native {expected:?}, difference {difference:e}");
            }
            // UNPAIRED deliberately has no magnitude acceptance threshold. It
            // is retained/class-checked, counted and reported, never a PASS row.
            let field = name.rsplit('.').next().ok_or("missing field name")?.to_owned();
            NUMERICAL_ASSESSMENT.with_borrow_mut(|values| {
                let entry = values.entry(field).or_insert((0, 0, 0.0));
                entry.0 += 1;
                entry.1 += usize::from(actual.to_bits() != bits);
                entry.2 = entry.2.max(difference);
            });
        }
    }
    Ok(())
}

thread_local! {
    static NUMERICAL_ASSESSMENT: std::cell::RefCell<std::collections::BTreeMap<String, (usize, usize, f64)>> = const { std::cell::RefCell::new(std::collections::BTreeMap::new()) };
}
'''

assert source.count('#[test]') == old.decode().count('#[test]') == 0
assert 'BIT_DIAGNOSTIC' not in source
OUT.mkdir(parents=True, exist_ok=False)
(OUT / 'before.rs').write_bytes(old)
(OUT / 'proposed.rs').write_bytes(source.encode('utf-8'))
diff = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), source.splitlines(keepends=True), fromfile=TARGET, tofile=TARGET))
(OUT / 'complete.diff').write_bytes(diff.encode('utf-8'))
contracts = [ROOT / 'energyplus_porting_plan/contracts' / name for name in ['PSY-01-tolerances.json', 'PSY-02-tolerances.json', 'CLK-03-tolerances.json']]
scope = {
    'schema': 'src06-design-day-scoped-regression-policy.v1',
    'status': 'held-source-not-executed',
    'existing_contracts': [ref(path) for path in contracts],
    'strict_bit_diagnostic_retained_as_failure': True,
    'new_numerical_tolerance_added': False,
    'exact': ['all existing discrete/call/site/clock/report/shape/index assertions', 'explicitly whitelisted remaining real fields including signed zero', 'within-Rust full 96-slot Today/Tomorrow literal carrier copy on every selected call'],
    'psy_caller_outputs': {
        'OutDewPointTemp': {'function': 'PsyTsatFnPb', 'atol': 1e-10, 'rtol': 1e-13},
        'OutWetBulbTemp': {'function': 'PsyTwbFnTdbWPb', 'atol': 1e-10, 'rtol': 1e-13},
        'OutHumRat': {'function': 'PsyWFnTdbRhPb', 'atol': 1e-12, 'rtol': 1e-13},
        'OutEnthalpy': {'function': 'PsyHFnTdbW', 'atol': 1e-7, 'rtol': 1e-13},
        'OutAirDensity': {'function': 'PsyRhoAirFnPbTdbW', 'atol': 1e-12, 'rtol': 1e-13},
    },
    'unpaired_computed_fields': ['OutRelHum', 'OutRelHumValue', 'SkyTemp', 'SkyTempKelvin', 'HorizIRSky', 'BeamSolarRad', 'DifSolarRad', 'GndSolarRad'],
    'unpaired_assertions': 'selected finite domain, exact IEEE class/signed zero; counts and raw-bit differences retained; no magnitude threshold and no numerical PASS',
    'required_observation_coverage': 'all five declared PSY caller fields and all eight UNPAIRED fields must actually be reached; unknown real names are errors',
    'not_certified': ['intermediate PSY input-bit pairing', 'PSY cache/history parity', 'libm cause', 'all Native weather numerics', 'downstream BeginTimeStepFlag or PreviousSolRadPositive HB writes', 'full Setup', 'porting gates'],
    'gates_updated': False,
}
(OUT / 'scope.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8')
(OUT / 'README.md').write_text('''# Held DesignDay scoped regression successor

One existing helper changes; no new test, framework, binary or production math. All old call, clock, input/default, report, owner, array shape and index assertions remain. Today/Tomorrow copies are additionally checked against Rust's own complete carrier bits, which does not imply that computed Native endpoints are bit-identical.

The genuine strict-bit diagnostic02 remains FAIL. Five caller outputs use only the already frozen PSY-01/02 numerical bounds. This is a caller-output assessment; absent intermediate/cache input observations prevent a paired PSY/cache PASS. Eight explicitly named RH/sky/solar outputs are UNPAIRED even when bits happen to agree. They retain finite/class/signed-zero assertions and counted differences without any magnitude PASS threshold. Unknown names fail closed.

Other explicitly named real comparisons remain bit-exact. No libm attribution, all-weather numerical parity, downstream HB writes, full Setup or port gate is claimed. Classification and exact transport/default scope can pass independently of unresolved computed-output parity. The metadata scope is part of the reviewable contract; it must accompany any reported test PASS.

The before file is actual read-time canonical Source, not a launch-time custody claim. This author emitted held files only and performed no Rust/Native execution. Parent owns application/format/validation.
''', encoding='utf-8')
manifest = {
    'schema': 'src06-design-day-qualified-comparison-preparation.v1',
    'status': 'held-source-only-not-applied-or-executed',
    'canonical_path': TARGET,
    'base': ref(OUT / 'before.rs'),
    'proposed': ref(OUT / 'proposed.rs'),
    'complete_diff': ref(OUT / 'complete.diff'),
    'scope': ref(OUT / 'scope.json'),
    'readme': ref(OUT / 'README.md'),
    'author': ref(Path(__file__).resolve()),
    'state_child_read_time_source': ref(ROOT / 'crates/ep_runtime/src/weather_day/design_day_native_state_tests.rs'),
    'actual_strict_diagnostic_stderr': ref(ROOT / '.runtime/porting/SRC-06/ordinary-design-day-rust-bit-diagnostic-02/stderr.log'),
    'actual_native_fixture': ref(ROOT / '.runtime/porting/SRC-06/ordinary-design-day-fixture-actual-01/fixture.json'),
    'existing_contracts': [ref(path) for path in contracts],
    'new_test_count': 0,
    'target_executed': False,
    'canonical_changed': False,
    'gates_updated': False,
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'manifest': ref(OUT / 'manifest.json'), 'proposed': ref(OUT / 'proposed.rs')}))

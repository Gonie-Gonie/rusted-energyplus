#pragma once
#include <array>
#include <cstdint>
#include <iosfwd>
#include <string>
namespace EnergyPlus { struct EnergyPlusData; }
namespace SurfaceConsumerObservation {
enum class Procedure { SetupSimulation, GetNextEnvironment, GetDesignDayData, ManageWeather, InitializeWeather, UpdateWeatherData, SetUpDesignDay, SetCurrentWeather, Count };
struct Capture {
    explicit Capture(std::ostream &output) noexcept : output(output) {}
    std::ostream &output;
    std::array<std::uint64_t, static_cast<unsigned>(Procedure::Count)> procedure_calls{};
    std::array<std::uint64_t, static_cast<unsigned>(Procedure::Count)> scope_normal_exits{};
    std::array<std::uint64_t, static_cast<unsigned>(Procedure::Count)> scope_unwinds{};
    std::uint64_t attempted_events=0, retained_events=0, copy_failures=0;
    std::uint64_t first_failed_event=0, last_failed_event=0, stream_failed_events=0;
    std::uint64_t setup_calls=0;
    bool counter_overflow=false, first_event=true, stream_failed=false;
};
class Binding {
public:
    explicit Binding(Capture &) noexcept;
    ~Binding() noexcept;
    Binding(Binding const &)=delete;
    Binding &operator=(Binding const &)=delete;
private: Capture *previous;
};
class Scope {
public:
    Scope(EnergyPlus::EnergyPlusData const *, Procedure, bool const *errors=nullptr, bool const *available=nullptr) noexcept;
    ~Scope() noexcept;
    Scope(Scope const &)=delete;
    Scope &operator=(Scope const &)=delete;
    Procedure procedure;
    std::uint64_t ordinal=0;
    Scope *parent=nullptr;
    EnergyPlus::EnergyPlusData const *state=nullptr;
    bool state_from_actual_parent=false;
    bool const *actual_errors_found=nullptr;
    bool const *actual_available=nullptr;
private: int exceptions_on_entry;
};
class SetupCall {
public:
    SetupCall(EnergyPlus::EnergyPlusData const &, char const *) noexcept;
    ~SetupCall() noexcept;
    SetupCall(SetupCall const &)=delete;
    SetupCall &operator=(SetupCall const &)=delete;
private:
    char const *previous_role;
    std::uint64_t previous_ordinal;
    int exceptions_on_entry;
};
void record_local_year(int year) noexcept;
void record_input_order(int input_ordinal, int environment_ordinal, std::string const &name) noexcept;
bool finish(Capture &, bool, int, char const *) noexcept;
}

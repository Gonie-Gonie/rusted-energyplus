//! Literal selected SetupSimulation caller order and retained failure prefix.
//!
//! This caller is connected only with real Exterior/HeatBalance/input postludes.
//! There are no default no-op operations and no ordinary-clock phase adapter.

use super::ctf_initialization_context::{CtfInitializationContext, CtfInitializationError};
use super::error_backend::{SourceErrorBackendFailure, SourceFatalStop};
use ep_model::TypedModel;
use crate::weather::day::{
    ProductionWeatherTimestepSeries, SetupSimulationCall, SetupSimulationRole,
    WeatherDayError, WeatherEnvironmentState,
};
use crate::RuntimeError;
use std::fmt::{Display, Formatter};

/// Required real operations at the selected normal SetupSimulation caller.
///
/// An implementation owns the real retained model/state. HeatBalance lazily
/// initializes that state at its first call using this actual DesignDay weather.
/// The borrowed environment must not be reentered through the weather series.
pub(crate) trait SetupSimulationOperations {
    fn manage_exterior_energy_use(
        &mut self,
        call: &SetupSimulationCall,
        environment: &mut WeatherEnvironmentState,
        context: &mut CtfInitializationContext<'_>,
    ) -> Result<(), RuntimeError>;

    fn manage_heat_balance(
        &mut self,
        call: &SetupSimulationCall,
        environment: &mut WeatherEnvironmentState,
        context: &mut CtfInitializationContext<'_>,
    ) -> Result<(), RuntimeError>;

    fn simulate_cost_estimate(
        &mut self,
        context: &mut CtfInitializationContext<'_>,
    ) -> Result<(), RuntimeError>;

    fn check_and_read_faults(
        &mut self,
        context: &mut CtfInitializationContext<'_>,
    ) -> Result<(), RuntimeError>;

    fn initialize_curve_reporting(
        &mut self,
        context: &mut CtfInitializationContext<'_>,
    ) -> Result<(), RuntimeError>;
}

/// A stopped real caller retains the completed operation prefix in its owners.
#[derive(Debug)]
pub(crate) enum SetupSimulationError {
    State(&'static str),
    Weather(WeatherDayError),
    Backend(SourceErrorBackendFailure),
    Initialization(Box<CtfInitializationError>),
    Fatal(SourceFatalStop),
    Operation { operation: &'static str, ordinal: u64, source: Box<RuntimeError> },
}

impl Display for SetupSimulationError {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::State(reason) => formatter.write_str(reason),
            Self::Weather(error) => Display::fmt(error, formatter),
            Self::Backend(error) => Display::fmt(error, formatter),
            Self::Initialization(error) => Display::fmt(error, formatter),
            Self::Fatal(error) => Display::fmt(error, formatter),
            Self::Operation { operation, ordinal, source } => {
                write!(formatter, "SetupSimulation {operation} at actual call {ordinal}: {source}")
            }
        }
    }
}
impl std::error::Error for SetupSimulationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::State(_) => None,
            Self::Weather(error) => Some(error),
            Self::Backend(error) => Some(error),
            Self::Initialization(error) => Some(error.as_ref()),
            Self::Fatal(error) => Some(error),
            Self::Operation { source, .. } => Some(source.as_ref()),
        }
    }
}
impl From<WeatherDayError> for SetupSimulationError {
    fn from(error: WeatherDayError) -> Self { Self::Weather(error) }
}
impl From<SourceErrorBackendFailure> for SetupSimulationError {
    fn from(error: SourceErrorBackendFailure) -> Self { Self::Backend(error) }
}

/// Persistent real caller state; no failed suffix is reported as completed.
#[derive(Debug, Default)]
pub(crate) struct SetupSimulationCaller {
    started: bool,
    completed: bool,
    kickoff_simulation: bool,
    kickoff_sizing: bool,
    do_weather_init_reporting: bool,
    ask_for_connections_report: bool,
    attempted_calls: u64,
    completed_calls: u64,
    pending: Option<(u64, SetupSimulationRole)>,
}

impl SetupSimulationCaller {
    pub(crate) fn completed(&self) -> bool { self.completed }
    pub(crate) fn completed_calls(&self) -> u64 { self.completed_calls }
    pub(crate) fn pending_call(&self) -> Option<(u64, SetupSimulationRole)> { self.pending }

    /// Selected no-ground-domain, non-sizing RunSimulation prefix and Setup.
    ///
    /// The same admitted raw family closure excludes slabs/basements. Positive
    /// Exterior:Lights is NOT excluded; its actual producer is mandatory above.
    /// A failed call cannot be resumed by replaying already-consumed first-time
    /// operations. Its caller, weather, reports, state and diagnostic prefix stay.
    pub(crate) fn run(
        &mut self,
        weather: &ProductionWeatherTimestepSeries,
        model: &TypedModel,
        operations: &mut impl SetupSimulationOperations,
        context: &mut CtfInitializationContext<'_>,
    ) -> Result<(), SetupSimulationError> {
        if self.started {
            return Err(SetupSimulationError::State("SetupSimulation already started"));
        }
        weather.begin_setup_simulation()?; // Real BeginSim201 before output267.
        self.started = true;
        // Original204,267: reporting is false before the actual progress call.
        self.do_weather_init_reporting = false;
        // Real SimulationManager215, before the first weather input getter.
        // Set the reached-route flag only after actual registration returns.
        context.prepare_registry(model).map_err(|error| SetupSimulationError::Initialization(Box::new(error)))?;
        context.reports.setup_simulation_registry_prepared = true;
        context.backend.display_string("Initializing Simulation")?;
        self.kickoff_simulation = true; // Original268.
        context.backend.state.kickoff_simulation = true;
        weather.reset_setup_environment_counter(); // Original270 only.
        let mut errors_found;
        loop {
            let (available, getter_errors) = weather.next_setup_environment(context.reports)
                .map_err(|source| SetupSimulationError::Operation {
                    operation: "GetNextEnvironment", ordinal: self.attempted_calls, source: Box::new(source),
                })?;
            errors_found = getter_errors;
            if !available { break; } // Original1985 precedes ErrorsFound1988.
            if errors_found { break; }
            context.backend.state.warmup_flag = true;
            for role in [
                SetupSimulationRole::FirstHour,
                SetupSimulationRole::RepeatedFirstHour,
                SetupSimulationRole::LastHour,
            ] {
                self.attempted_calls = self.attempted_calls.checked_add(1)
                    .ok_or(SetupSimulationError::State("Setup call ordinal overflow"))?;
                let ordinal = self.attempted_calls;
                self.pending = Some((ordinal, role));
                weather.prepare_setup_call(role);
                if context.backend.state.developer_flag {
                    let prefix = match role {
                        SetupSimulationRole::FirstHour => "Initializing Simulation - timestep 1:",
                        SetupSimulationRole::RepeatedFirstHour => "Initializing Simulation - 2nd timestep 1:",
                        SetupSimulationRole::LastHour => "Initializing Simulation - hour 24 timestep 1:",
                    };
                    context.backend.display_string(&(prefix.to_owned() + &weather.setup_environment_name()))?;
                }
                let call = weather.manage_setup_weather(
                    ordinal, role, self.kickoff_simulation, self.kickoff_sizing,
                    self.do_weather_init_reporting,
                )?;
                weather.with_setup_environment_mut(|environment| {
                    operations.manage_exterior_energy_use(&call, environment, context)
                }).map_err(|source| SetupSimulationError::Operation {
                    operation: "ManageExteriorEnergyUse", ordinal, source: Box::new(source),
                })?;
                weather.with_setup_environment_mut(|environment| {
                    operations.manage_heat_balance(&call, environment, context)
                }).map_err(|source| SetupSimulationError::Operation {
                    operation: "ManageHeatBalance", ordinal, source: Box::new(source),
                })?;
                self.completed_calls += 1;
                self.pending = None;
                if role == SetupSimulationRole::FirstHour {
                    weather.finish_first_setup_call(); // Exact2021-2024 writes.
                }
            }
        }
        if errors_found {
            // Original2058 skips Cost;2061 owns the actual fatal/backend effects.
            return match context.backend.show_fatal_error("Previous conditions cause program termination.") {
                Ok(impossible) => match impossible {},
                Err(stop) => Err(SetupSimulationError::Fatal(stop)),
            };
        }
        operations.simulate_cost_estimate(context).map_err(|source| SetupSimulationError::Operation {
            operation: "SimCostEstimate", ordinal: self.attempted_calls, source: Box::new(source),
        })?;
        operations.check_and_read_faults(context).map_err(|source| SetupSimulationError::Operation {
            operation: "CheckAndReadFaults", ordinal: self.attempted_calls, source: Box::new(source),
        })?;
        operations.initialize_curve_reporting(context).map_err(|source| SetupSimulationError::Operation {
            operation: "InitCurveReporting", ordinal: self.attempted_calls, source: Box::new(source),
        })?;
        self.ask_for_connections_report = true; // Original278.
        self.kickoff_simulation = false; // Original279, only after all postludes.
        context.backend.state.kickoff_simulation = false;
        weather.finish_setup_simulation(); // Original280.
        context.backend.state.warmup_flag = false;
        self.do_weather_init_reporting = true; // Original281.
        self.completed = true;
        Ok(())
    }
}

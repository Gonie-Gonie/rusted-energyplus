from pathlib import Path
import hashlib

root=Path(__file__).resolve().parents[3]
held=root/'.runtime/porting/SRC-06/ordinary-design-day-site-comparison-prep-Header-01/site_and_solar.rs'
manifest=root/'.runtime/porting/SRC-06/ordinary-design-day-site-comparison-prep-Header-01/manifest.json'
if hashlib.sha256(manifest.read_bytes()).hexdigest()!='51a95655d06352025a1f91c205f3f98a30369b7c5793a42cd9568b5325756792':
    raise RuntimeError('held helper manifest changed')
target=root/'crates/ep_runtime/src/weather_day/design_day_native_state_tests.rs'
if 'fn site_and_solar(' in target.read_text():raise RuntimeError('already appended')
with target.open('ab')as stream:stream.write(b'\n'+held.read_bytes())
print('Appended reviewed 61-line site and solar comparison helper.')

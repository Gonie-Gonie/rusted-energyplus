"""Audit only finite listed historical refs before publication."""
from pathlib import Path
import ast
import hashlib
import json

root=Path.cwd()
base=root/'.runtime/porting/SRC-06'
tree=ast.parse((base/'publish-design-day-weather-Root-01.py').read_text())
names={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in {'PREPS','REVIEWS'}}
findings=[]
def walk(value,manifest):
    if isinstance(value,dict):
        if 'path' in value and 'sha256' in value:
            path=(root/value['path']).resolve()
            if not path.is_relative_to(root) or path.stat().st_size>10*1024*1024:
                return
            data=path.read_bytes()
            actual=hashlib.sha256(data).hexdigest()
            if actual!=value['sha256'] or len(data)!=value.get('size_bytes',len(data)):
                findings.append({'manifest':manifest,'historical_ref':value,'current_sha256':actual,'current_size_bytes':len(data)})
        else:
            for item in value.values():walk(item,manifest)
    elif isinstance(value,list):
        for item in value:walk(item,manifest)
for name in names['PREPS']+names['REVIEWS']:
    walk(json.loads((base/name).read_bytes()),name)
out=base/'ordinary-design-day-publication-reference-audit-01.json'
assert not out.exists()
out.write_bytes((json.dumps({'findings':findings,'engine_executed':False},indent=2)+'\n').encode())
print(json.dumps(findings,indent=2))

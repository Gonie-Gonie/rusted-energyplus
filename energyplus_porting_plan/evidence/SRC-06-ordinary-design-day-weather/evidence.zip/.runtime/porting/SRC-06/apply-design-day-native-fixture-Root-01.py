import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
source = root / '.runtime/porting/SRC-06/ordinary-design-day-fixture-actual-01/fixture.json'
data = source.read_bytes()
if hashlib.sha256(data).hexdigest() != '98c6673bd0ac9557c35051b9b612c7a98729e2bd64fc7dbb0b568fe5ae784be2':
    raise RuntimeError('fixture custody changed')
target = root / 'crates/ep_runtime/src/weather_day/fixtures/ordinary_design_day_native.json'
target.parent.mkdir(exist_ok=True)
with target.open('xb') as output:
    output.write(data)
fixture = json.loads(data)
weather = fixture['design_day_manage_weather_returns'][0]['weather']
for key in ['spSiteSchedules', 'site', 'weather_solar']:
    print(key, json.dumps(weather[key])[:500])
print('Native report first cell', fixture['actual_six_cell_rows'][0])

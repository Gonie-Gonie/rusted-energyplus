"""Apply reviewed scoped DD regression without rewriting historical diagnostics."""
from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
manifest_path = base / 'ordinary-design-day-qualified-comparison-prep-Header-01/manifest.json'
manifest = json.loads(manifest_path.read_bytes())
assert hashlib.sha256(manifest_path.read_bytes()).hexdigest() == 'd7d5d99d4c58f715f8d4dbf6fe8a4c39fcd83a36eb8b5cb09be9165fce1e72b3'
canonical = root / manifest['canonical_path']
assert hashlib.sha256(canonical.read_bytes()).hexdigest() == manifest['base']['sha256']
proposed = root / manifest['proposed']['path']
assert hashlib.sha256(proposed.read_bytes()).hexdigest() == manifest['proposed']['sha256']
assert len(proposed.read_bytes()) == manifest['proposed']['size_bytes']
review = json.loads((base / 'Owner-design-day-qualified-comparison-Source-review-01/review.json').read_bytes())
assert review['accepted'] is True
canonical.write_bytes(proposed.read_bytes())
output = base / 'ordinary-design-day-qualified-comparison-application-01.json'
assert not output.exists()
output.write_bytes((json.dumps({'schema': 'src06-qualified-comparison-application.v1', 'preparation': manifest_path.relative_to(root).as_posix(), 'canonical_path': manifest['canonical_path'], 'before_sha256': manifest['base']['sha256'], 'after_sha256': manifest['proposed']['sha256'], 'historical_strict_diagnostic_preserved': True, 'gates_updated': False}, indent=2) + '\n').encode())
print('Applied reviewed qualified DD comparison; historical strict diagnostic unchanged.')

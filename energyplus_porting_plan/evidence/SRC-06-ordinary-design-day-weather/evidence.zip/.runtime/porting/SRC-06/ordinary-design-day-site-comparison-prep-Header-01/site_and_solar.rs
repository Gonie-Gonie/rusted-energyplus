// Held additive helper for design_day_native_state_tests.rs; no new test.
pub(super) fn site_and_solar(
    state: &WeatherDayState,
    event: &Value,
    time_zone_number: f64,
) -> TestResult {
    let e = &state.environment;
    let w = &state.weather;
    let native = &event["weather"];
    let site = &native["site"];
    for (name, value) in [
        ("CosLatitude", e.cos_latitude),
        ("Elevation", e.elevation),
        ("Latitude", e.latitude),
        ("Longitude", e.longitude),
        ("SinLatitude", e.sin_latitude),
        ("StdBaroPress", e.std_baro_press),
        ("TS1TimeOffset", e.one_step_solar_time_offset),
        ("TimeZoneMeridian", e.time_zone_meridian),
        ("TimeZoneNumber", time_zone_number),
    ] {
        real(value, &site[name], &format!("site.{name}"))?;
    }
    for (name, value) in [
        ("DisplayWeatherMissingDataWarnings", e.display_weather_missing_data_warnings),
        ("IgnoreBeamRadiation", e.ignore_beam_radiation),
        ("IgnoreDiffuseRadiation", e.ignore_diffuse_radiation),
        ("IgnoreSolarRadiation", e.ignore_solar_radiation),
    ] {
        assert_eq!(Some(value), site[name].as_bool(), "site.{name}");
    }
    let solar = &native["weather_solar"];
    for (name, value) in [
        ("HorizIRSky", w.horizontal_infrared_sky),
        ("HrAngle", w.hour_angle),
        ("SnowGndRefModifier", w.snow_ground_reflectance_modifier),
        ("SnowGndRefModifierForDayltg", w.snow_ground_reflectance_for_daylighting_modifier),
        ("SolarAltitudeAngle", w.solar_altitude_angle),
        ("SolarAzimuthAngle", w.solar_azimuth_angle),
    ] {
        real(value, &solar[name], &format!("weather_solar.{name}"))?;
    }
    for (name, value) in [("RptIsRain", w.rpt_is_rain), ("RptIsSnow", w.rpt_is_snow)] {
        assert_eq!(Some(i64::from(value)), solar[name].as_i64(), "weather_solar.{name}");
    }
    let reflectance = &solar["GroundReflectances"];
    assert_eq!(reflectance["allocated"], true);
    assert_eq!(reflectance["lower"], 1);
    assert_eq!(reflectance["upper"], 12);
    assert_eq!(reflectance["size"], 12);
    let rows = reflectance["rows"].as_array().ok_or("GroundReflectances rows")?;
    assert_eq!(rows.len(), w.ground_reflectances.len());
    for (index, (actual, row)) in w.ground_reflectances.iter().zip(rows).enumerate() {
        assert_eq!(row["index"], index + 1);
        real(*actual, &row["value"], "weather_solar.GroundReflectances")?;
    }
    // PreviousSolRadPositive belongs to downstream InitSolarHeatGains. Its
    // Native false values here do not authorize pretending that HB ran.
    Ok(())
}

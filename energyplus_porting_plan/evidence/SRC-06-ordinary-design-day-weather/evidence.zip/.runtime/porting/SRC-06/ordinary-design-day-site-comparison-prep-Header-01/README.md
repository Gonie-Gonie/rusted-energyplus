# Held actual DD site/solar comparison expansion

Append the literal helper to design_day_native_state_tests.rs and invoke it from the existing DD comparison loop after state::verify. Pass the actual retained session.configuration.site.time_zone_hours as the third argument. This compares all thirteen captured site members, all nine weather_solar members including the complete twelve-entry GroundReflectances owner, with the existing strict binary64 real helper. All six genuine DD return events are checked by the existing loop; no new test, fixture or engine execution is introduced.

The already genuine fixture98c6673b remains unchanged. Native PreviousSolRadPositive is downstream HB-owned and deliberately excluded alongside BeginTimeStepFlag; no weather-only test should perform those missing consumer writes. Raw DD projection and full HB/Setup remain separate scope. This additive fragment is held for Root's canonical assembly and formatting, not claimed applied/compiled.

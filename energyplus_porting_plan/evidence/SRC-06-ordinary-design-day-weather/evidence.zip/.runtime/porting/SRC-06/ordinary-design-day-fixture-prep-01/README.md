# Actual DesignDay fixture extraction

The extractor authenticates the actual outer capture stdout/custody join and
closed finite provider/loader metadata, then reads every raw event with the
accepted fixed stream parser. It performs no weather calculation and reruns no
engine. Raw binary64 bits and classes are copied literally.

Selection includes both GetDesignDayData boundaries, every actual input-order and
local-year checkpoint, and every DD ManageWeather return. All three actual Setup
roles for each observed DD must be present, with full Today/Tomorrow arrays,
daily/modifier/site-schedule collections, selected weather flags/current/site,
and original getter report arrays plus the six genuine column IDs/cells.

All recursive `*_address` members, solar shading payloads, non-DD weather calls
and the explicitly enumerated unsupported system/HVAC/InsideSurf clock members
are omitted. Weather SimTimeSteps remains because UpdateWeatherData owns it.
No RunPeriod/HB/full Setup numerical parity or gate success is claimed. Native
transport/counters and fixture copying are separate from pending Rust tests.

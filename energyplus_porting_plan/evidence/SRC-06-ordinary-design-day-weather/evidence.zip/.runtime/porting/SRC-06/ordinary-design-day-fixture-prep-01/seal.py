"""Seal finite Source/extraction refs; never run a producer or numerical test."""
from pathlib import Path
import hashlib,json
ROOT=Path.cwd();UNIT=ROOT/'.runtime/porting/SRC-06/ordinary-design-day-fixture-prep-01'
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
manifest={'schema':'src06-actual-design-day-fixture-preparation.v1',
    'extractor_Source':ref(UNIT/'extract.py'),'README':ref(UNIT/'README.md'),
    'accepted_stream_parser':ref(ROOT/'.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'),
    'actual_fixture':ref(ROOT/'.runtime/porting/SRC-06/ordinary-design-day-fixture-actual-01/fixture.json'),
    'actual_metadata':ref(ROOT/'.runtime/porting/SRC-06/ordinary-design-day-fixture-actual-01/metadata.json'),
    'seal_Source':ref(Path(__file__)),'actual_capture_command':ref(ROOT/'.runtime/porting/SRC-06/ordinary-design-day-native-capture-command-01/receipt.json'),
    'native_numerical_math_performed':False,'engine_rerun':False,'canonical_modified':False,
    'Rust_numerical_parity_checked':False,'whole_Setup_PASS':False,'gates_PASS':False}
(UNIT/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps(ref(UNIT/'manifest.json')))

"""Copy actual DD weather observations into a finite fixture; no weather math."""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[4]
PARSER = ROOT/'.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'
PARSER_SHA = '8e7f05196fe567c052352d4d0fe501eb02a0f8e5a623c20f7dcd3db669f6bab8'
SOURCE_SHA = 'af6f53c88091a2350ba0545ddc4ed1ee200e75c734e6823e979e20b096f9fa18'
NATIVE_SHA = '73f18a49cddf4c35d0bab493be8b1d57da8895e7d12954ae9dfdc8e4f85cfc66'
CAPTURE_SHA = '166863334d9b946f19025e470b92054572eed63d86ddc5465fdbee749cfd70dd'
PROCEDURES = ['SetupSimulation','GetNextEnvironment','GetDesignDayData','ManageWeather',
    'InitializeWeather','UpdateWeatherData','SetUpDesignDay','SetCurrentWeather']
TAGS = {'procedure_entry','procedure_return','setup_call_entry','setup_call_return',
    'local_year_resolved','input_object_order'}
CLOCK_KEYS = {'environment_index','environment_name','CalendarYear','Month','DayOfMonth','DayOfSim',
    'HourOfDay','TimeStep','KindOfSim','CurrentTime','TimeStepZone','TimeStepZoneSec','KickOffSimulation',
    'WarmupFlag','BeginSimFlag','BeginEnvrnFlag','BeginDayFlag','BeginHourFlag','BeginTimeStepFlag',
    'ZoneSizingCalc','SysSizingCalc'}
DD_COLUMNS = ['pdchDDmaxDB','pdchDDrange','pdchDDhumid','pdchDDhumTyp','pdchDDwindSp','pdchDDwindDr']

def need(value, message):
    if not value: raise ValueError(message)

def ref(path):
    path=Path(path).resolve()
    with path.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.as_posix(),'sha256':digest,'size_bytes':path.stat().st_size}

def checked(row):
    path=(ROOT/row['path']).resolve(); actual=ref(path)
    need(actual['sha256']==row['sha256'] and actual['size_bytes']==row.get('size_bytes',actual['size_bytes']),str(path))
    return path

def unique(pairs):
    result={}
    for key,value in pairs:
        need(key not in result,'Duplicate JSON key: '+key);result[key]=value
    return result

def load(path):
    return json.loads(path.read_bytes(),object_pairs_hook=unique,
        parse_constant=lambda value:need(False,'Nonfinite JSON literal: '+value))

def bound(value):
    path,digest=value.rsplit('#',1);need(re.fullmatch('[0-9a-f]{64}',digest),'SHA operand')
    path=checked({'path':path,'sha256':digest});return ref(path),load(path)

def walk(value):
    if type(value) is list:
        for child in value:walk(child)
    elif type(value) is dict:
        if 'value_bits' in value or 'value_class' in value:
            need(set(value)=={'value_bits','value_class'},'Raw scalar shape')
            bits=value['value_bits'];need(type(bits)is str and re.fullmatch('[0-9a-f]{16}',bits),'Raw bits')
            raw=int(bits,16);mag,neg=raw&0x7fffffffffffffff,raw>>63
            kind=('nan' if mag>0x7ff0000000000000 else
                ('negative_infinity' if neg else 'positive_infinity') if mag==0x7ff0000000000000 else
                ('negative_zero' if neg else 'positive_zero') if mag==0 else 'finite')
            need(value['value_class']==kind,'Raw scalar class')
        else:
            for child in value.values():walk(child)

def without_addresses(value):
    if type(value)is list:return [without_addresses(child)for child in value]
    if type(value)is dict:return {key:without_addresses(child)for key,child in value.items()
        if not key.endswith('_address')}
    return value

def projected(event):
    result={key:without_addresses(value)for key,value in event.items()
        if key not in {'solar_shading','clock','counted_as_PASS'}}
    result['clock']={key:value for key,value in event['clock'].items()if key in CLOCK_KEYS}
    return result

def write(path,value):
    with path.open('xb')as stream:stream.write((json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode())
    return ref(path)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture-custody',required=True)
    parser.add_argument('--capture-command',required=True)
    parser.add_argument('--output-dir',required=True)
    args=parser.parse_args()
    custody_ref,custody=bound(args.capture_custody); command_ref,command=bound(args.capture_command)
    need(custody['schema']=='src06-ordinary-design-day-native-capture-custody.v1'
        and custody['transport_custody_accepted']is True and custody['actual_native_child_count']==1
        and custody['native_exit_code']==0 and custody['launch_error']is None,'Closed actual capture')
    need(custody['input_executable_Source_DLL_bytes_unchanged']is True and not custody['guard_errors']
        and custody['raw_within_limit']is True and custody['inherited_environment_merged']is False,'Actual custody')
    need(command['schema']=='recorded-porting-command.v1' and command['exit_code']==0
        and command['launch_error']is None and command['source_bytes_match_before_and_after']is True
        and command['source_snapshot']['sha256']==custody['Source_snapshot']['sha256']==SOURCE_SHA,'Actual outer receipt')
    emitted=load(checked(command['stdout']));checked(command['stderr'])
    need(set(emitted)=={'custody','transport_custody_accepted'}and emitted['transport_custody_accepted']is True
        and ref(checked(emitted['custody']))==custody_ref,'Complete stdout/custody join')
    capture_source=ROOT/'.runtime/porting/SRC-06/ordinary-design-day-native-capture-prep-01/capture.py'
    checked({'path':str(capture_source),'sha256':CAPTURE_SHA})
    need(Path(command['command'][4]).resolve()==capture_source.resolve(),'Actual capture Source argv')
    need(custody['native_source_manifest']['sha256']==NATIVE_SHA,'Native Source binding')
    checked(custody['native_source_manifest'])
    build=load(checked(custody['native_build']));closure=load(checked(custody['runtime_closure']))
    provider=load(checked(custody['provider_review']));before=load(checked(custody['before']))
    need(build['native_source_manifest']==closure['native_source_manifest']==custody['native_source_manifest']
        and build['helper_binary']==closure['helper_binary'] and closure['native_build']==custody['native_build']
        and closure['provider_review']==custody['provider_review'] and closure['accepted']is True
        and provider['accepted']is True and provider['native_build']==custody['native_build'],'Actual provider closure')
    need(before['guards']==custody['after_guards']and before['actual_native_argv']==custody['actual_native_argv']
        and before['actual_helper_argv']==custody['actual_helper_argv'],'Recorded guard/argv equality')
    need(len(custody['actual_native_argv'])==7 and custody['actual_helper_argv'][4:]==custody['actual_native_argv'],
        'Complete seven native arguments')
    checked(custody['native_stdout']);checked(custody['native_stderr'])
    for output in custody['normal_engine_outputs']:checked(output)
    raw=checked(custody['raw_observation'])
    checked({'path':str(PARSER),'sha256':PARSER_SHA})
    specification=importlib.util.spec_from_file_location('accepted_DD_stream_parser',PARSER)
    module=importlib.util.module_from_spec(specification);specification.loader.exec_module(module)
    dd_calls=[];getter=[];order=[];years=[];counts=collections.Counter();maximum=collections.Counter();selected_roles=collections.defaultdict(list)
    event_count=0
    def visit(event):
        nonlocal event_count
        event_count+=1;need(event['event_ordinal']==event_count,'Full stream ordinal')
        need(event['design_day_protocol']=='src06-ordinary-design-day-native.v1'and event['procedure']in PROCEDURES
            and event['checkpoint']in TAGS and event['counted_as_PASS']is False,'Literal event protocol/tag')
        walk(event);procedure=event['procedure'];invocation=event['invocation_ordinal']
        need(type(invocation)is int and invocation>0,'Actual invocation ordinal')
        maximum[procedure]=max(maximum[procedure],invocation);counts[(procedure,event['checkpoint'])]+=1
        if event['checkpoint']=='input_object_order':order.append(projected(event))
        if event['checkpoint']=='local_year_resolved':years.append(projected(event))
        if procedure=='GetDesignDayData'and event['checkpoint']in {'procedure_entry','procedure_return'}:getter.append(projected(event))
        if procedure=='ManageWeather'and event['checkpoint']=='procedure_return'and event['clock']['KindOfSim']==1:
            need(event['clock']['KickOffSimulation']is True and event['setup_role']in {'FirstHour','RepeatedFirstHour','LastHour'},'Actual DD Setup role')
            for key in ['wvarsHrTsToday','wvarsHrTsTomorrow']:
                array=event['weather'][key]
                need(array['allocated']is True and array['size']==array['size1']*array['size2']
                    and len(array['rows'])==array['size'],'Complete allocated '+key)
                expected=[(hour,step)for hour in range(array['lower2'],array['upper2']+1)
                    for step in range(array['lower1'],array['upper1']+1)]
                need([(row['hour'],row['timestep'])for row in array['rows']]==expected,'Full bounds/order '+key)
            dd_calls.append(projected(event));selected_roles[event['weather']['Envrn']].append(event['setup_role'])
    header=module.read(raw,need,unique,visit);summary=header['summary']
    need(header['schema']=='ctf10-surface-consumer-native-observation.v1'
        and header['actual_native_arguments']==[custody['actual_helper_argv'][0],*custody['actual_native_argv']], 'Actual main/native argv')
    need(summary['design_day_protocol']=='src06-ordinary-design-day-native.v1'
        and summary['procedure_names']==PROCEDURES and summary['actual_engine_entry_returned']is True
        and summary['actual_engine_exit_code']==0 and summary['outer_caught_exception_class']is None,'Actual terminal')
    for key in ['copy_failures','first_failed_event','last_failed_event','stream_failed_events']:need(summary[key]==0,key)
    for key in ['stream_failed','counter_overflow','observer_invokes_producer','integration_PASS_claimed']:need(summary[key]is False,key)
    need(summary['attempted_events']==summary['retained_events']==event_count,'Complete full stream counts')
    need(len(summary['procedure_calls'])==len(summary['scope_normal_exits'])==len(summary['scope_unwinds'])==len(PROCEDURES),'Counter shapes')
    for index,name in enumerate(PROCEDURES):
        need(summary['procedure_calls'][index]==summary['scope_normal_exits'][index]
            and summary['scope_unwinds'][index]==0 and maximum[name]<=summary['procedure_calls'][index],'Complete counters '+name)
    need(len(getter)==2 and getter[0]['checkpoint']=='procedure_entry'and getter[1]['checkpoint']=='procedure_return','One full actual getter pair')
    number_dd=getter[1]['weather']['TotDesDays']
    need(number_dd>0 and len(order)==number_dd and len(years)==number_dd and len(dd_calls)==3*number_dd,'All actual DD producers and calls')
    for roles in selected_roles.values():need(roles==['FirstHour','RepeatedFirstHour','LastHour'],'All actual same-environment role order')
    need(len(selected_roles)==number_dd,'Complete actual DD environment coverage')
    ids={name:getter[1]['predefined_reports'][name]for name in DD_COLUMNS}
    reports=getter[1]['predefined_reports'];actual_cells=[row for row in reports['tableEntry']['rows']
        if row['index']<=reports['numTableEntry']and row['value']['indexColumn']in ids.values()]
    need(len(actual_cells)==6*number_dd,'Actual six DD cells per input')
    out=Path(args.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
    fixture={'schema':'src06-actual-design-day-weather-fixture.v1','capture_custody':custody_ref,
        'capture_command':command_ref,'raw_observation':custody['raw_observation'],'Native_Source':custody['native_source_manifest'],
        'get_design_day_data':getter,'input_object_order':order,'actual_local_year':years,
        'design_day_manage_weather_returns':dd_calls,'six_predefined_column_ids':ids,'actual_six_cell_rows':actual_cells,
        'full_stream_summary':summary,'scope':'DD weather only; no RunPeriod/HB/full Setup parity',
        'omissions':['every recursive *_address key','solar_shading payload','non-DD ManageWeather events',
            'HVAC/system/InsideSurfIterations clock members; exact admitted weather clock key table retained']}
    fixture_ref=write(out/'fixture.json',fixture)
    metadata={'schema':'src06-actual-design-day-fixture-extraction.v1','fixture':fixture_ref,
        'capture_custody':custody_ref,'capture_command':command_ref,'raw_observation':custody['raw_observation'],
        'extractor_Source':ref(Path(__file__)),'accepted_parser_Source':ref(PARSER),
        'full_raw_events_read':event_count,'actual_DD_count':number_dd,'selected_DD_returns':len(dd_calls),
        'getter_boundaries':len(getter),'actual_input_order_rows':len(order),'local_year_observations':len(years),
        'actual_predefined_cells':len(actual_cells),'no_numeric_computation':True,
        'scalar_bits_and_classes_literal_copied':True,'engine_rerun':False,'Rust_parity_checked':False,'gates_PASS':False}
    print(json.dumps({'metadata':write(out/'metadata.json',metadata),'fixture':fixture_ref}))

if __name__=='__main__':main()

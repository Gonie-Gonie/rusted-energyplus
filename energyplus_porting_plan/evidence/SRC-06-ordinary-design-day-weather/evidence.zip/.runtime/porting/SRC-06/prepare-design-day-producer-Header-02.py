"""Seal the single reviewed import correction; no canonical or target actions."""
from pathlib import Path
import copy
import difflib
import hashlib
import json

ROOT = Path.cwd()
PARENT = ROOT / '.runtime/porting/SRC-06/ordinary-design-day-producer-prep-01'
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-design-day-producer-prep-02'
assert not OUT.exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def put(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode('utf-8') if isinstance(data, str) else data)
    return ref(path)

parent_ref = ref(PARENT / 'manifest.json')
assert parent_ref['sha256'] == '106ced4549dcd28ba771fdd3295dd5115901d9175be08ed47aa71a319203aa3d'
manifest = copy.deepcopy(json.loads((PARENT / 'manifest.json').read_bytes()))
canonical = 'crates/ep_runtime/src/weather_day/design_day/reports.rs'
row = next(row for row in manifest['files'] if row['canonical_path'] == canonical)
old = (ROOT / row['proposal']['path']).read_bytes()
before = b'use crate::weather_day::WeatherEnvironmentConfiguration;'
after = b'use crate::weather::day::WeatherEnvironmentConfiguration;'
assert old.count(before) == 1
new = old.replace(before, after)
assert new.replace(after, before) == old
proposal = put('proposed/' + canonical, new)
direct_diff = put('diffs/reports.direct.diff', ''.join(difflib.unified_diff(
    [], new.decode('utf-8').splitlines(keepends=True), fromfile=canonical, tofile=canonical)))
parent_diff = put('diffs/reports.parent.diff', ''.join(difflib.unified_diff(
    old.decode('utf-8').splitlines(keepends=True), new.decode('utf-8').splitlines(keepends=True),
    fromfile=row['proposal']['path'], tofile=proposal['path'])))
original_row = copy.deepcopy(row)
row['proposal'] = proposal
row['complete_direct_diff'] = direct_diff
manifest['parent_preparation'] = parent_ref
manifest['single_parent_delta'] = {'canonical_path': canonical, 'before_proposal': original_row['proposal'],
    'after_proposal': proposal, 'complete_parent_diff': parent_diff, 'inverse_full_bytes_exact': True}
manifest['author_Source'] = ref(Path(__file__).resolve())
manifest['README'] = put('README.md', '''# Held DesignDay producer Source02

This immutable successor corrects only the reviewed report import from `crate::weather_day` to the existing `crate::weather::day` reexport. Reversing that single import reproduces the complete Source01 report bytes. All twelve other proposals, their bases/diffs, all literal Original/schema/dependency references, input-domain decisions, solar/psychrometric arithmetic and retained owners are unchanged references to frozen Source01.

The actual af6f53c8 base remains historical authority for these direct proposals; this is held for coherent Setup/Gather assembly and genuine Native observation, with no canonical edits, formatter, Cargo, engine, numerical PASS or gate changes. No Fourier or retained-input wind change was made: both were checked against Original and found correct.
''')
put('manifest.json', json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
print(json.dumps(ref(OUT / 'manifest.json')))

"""Publish actual scoped regression status, retaining the failed strict probe."""
from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}
def load(path):
    return json.loads(path.read_bytes())
scope = base / 'ordinary-design-day-qualified-comparison-prep-Header-01/scope.json'
assert ref(scope)['sha256'] == 'ef5a0ef78d5bbb4a2da879d522ca15a9709e0c5d3b5b1ad04add9b6f4e1405ee'
qa = base / 'ordinary-design-day-workspace-01/receipt.json'
actual = load(qa)
assert actual['exit_code'] == 0 and actual['source_bytes_match_before_and_after'] is True
strict = base / 'ordinary-design-day-rust-bit-diagnostic-02/receipt.json'
assert load(strict)['exit_code'] == 101
assert ref(strict)['sha256'] == 'fbe3d34d4cf4ba8ad00e59791506a085c8974c486e8d69947fd793e21c15dafc'
policy = load(scope)
policy.update({'status': 'actual-scoped-regression-passed-strict-bit-diagnostic-still-failed',
               'reviewed_declared_scope': ref(scope), 'actual_workspace': ref(qa),
               'actual_source_snapshot': actual['source_snapshot'],
               'retained_strict_diagnostic': ref(strict),
               'numerical_parity_status': 'UNCONFIRMED; eight declared computed fields have no numerical acceptance criterion',
               'strict_diagnostic_difference_fields': 9,
               'strict_diagnostic_maximum_absolute_difference': 2.2737367544323206e-13})
output = base / 'ordinary-design-day-comparison-policy-01.json'
assert not output.exists()
output.write_bytes((json.dumps(policy, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())
print(json.dumps(ref(output)))

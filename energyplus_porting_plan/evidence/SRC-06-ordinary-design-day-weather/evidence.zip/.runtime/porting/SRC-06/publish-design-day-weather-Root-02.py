"""Archive finite actual DD Source, diagnostics and QA; never change gates."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess
import zipfile

ROOT=Path.cwd()
BASE=ROOT/'.runtime/porting/SRC-06'
OUT=ROOT/'energyplus_porting_plan/evidence/SRC-06-ordinary-design-day-weather'
PREPS=[
 'ordinary-design-day-producer-prep-02/manifest.json',
 'ordinary-setup-weather-host-prep-04/manifest.json',
 'ordinary-design-day-application-plan-01.json',
 'ordinary-design-day-application-01/application.json',
 'ordinary-design-day-native-prep-02/manifest.json',
 'ordinary-design-day-fixture-prep-01/manifest.json',
 'ordinary-design-day-site-comparison-prep-Header-01/manifest.json',
 'ordinary-design-day-raw-comparison-prep-Header-01/manifest.json',
 'ordinary-design-day-qualified-comparison-prep-Header-01/manifest.json',
 'ordinary-design-day-qualified-comparison-application-01.json',
]
REVIEWS=[
 'Root-ordinary-design-day-producer-Source-review-01/review.json',
 'Root-ordinary-design-day-native-Source-review-01/review.json',
 'Header-ordinary-design-day-native-Source-review-02/review.json',
 'Header-ordinary-design-day-native-environment-review-02/review.json',
 'Header-ordinary-design-day-launcher-Source-review-01/review.json',
 'Header-ordinary-design-day-provider-Source-review-01/review.json',
 'Root-ordinary-design-day-provider-review-01/review.json',
 'Root-ordinary-design-day-provider-acceptance-01/review.json',
 'Header-ordinary-design-day-fixture-review-01/review.json',
 'Header-ordinary-design-day-final-tests-review-02/review.json',
 'Owner-design-day-qualified-comparison-Source-review-01/review.json',
]

def write(path,data):
    path.write_bytes((json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def ref(path):
    path=path.resolve()
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path):return json.loads(path.read_bytes())
def checked(row):
    path=(ROOT/row['path']).resolve()
    actual=ref(path)
    assert actual['sha256']==row['sha256'],row['path']
    assert actual['size_bytes']==row.get('size_bytes',actual['size_bytes']),row['path']
    return path

assert not OUT.exists()
qa=[]
for name,argv in [
 ('fmt-check',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','fmt','--all','--','--check']),
 ('source-quality',['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1']),
 ('clippy',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','clippy','--workspace','--all-targets','--','-D','warnings']),
 ('workspace',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','test','--workspace']),
]:
    suffix='01' if name=='workspace' else '02'
    path=BASE/f'ordinary-design-day-{name}-{suffix}/receipt.json'
    data=load(path)
    assert data['command']==argv and data['exit_code']==0 and data['launch_error']is None
    assert data['source_bytes_match_before_and_after']is True
    qa.append(ref(path))
source=load(checked(qa[-1]))['source_snapshot']
assert all(load(checked(row))['source_snapshot']==source for row in qa)
stdout=checked(load(checked(qa[-1]))['stdout']).read_text(encoding='utf8')
groups=[tuple(map(int,row))for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
assert len(groups)==18 and tuple(map(sum,zip(*groups)))==(4974,0,2),groups
for name in ['weather::day::lifecycle_tests::warmup_hooks_copy_current_first_day_without_reading_or_prefetching',
 'ordinary_equipment_input::tests::raw_equipment_admission_preserves_empty_presence_and_rejects_positive_or_field_branches']:
    assert re.search(re.escape(name)+r' \.\.\. ok(?:[\r\n]|$)',stdout),name
diagnostic=BASE/'ordinary-design-day-rust-bit-diagnostic-02/receipt.json'
assert load(diagnostic)['exit_code']==101 and load(diagnostic)['source_bytes_match_before_and_after']is True
assert 'strict-bit diagnostic found differences; no numerical parity claimed' in checked(load(diagnostic)['stderr']).read_text()

artifacts={}
external=[]
def add(path):
    path=path.resolve()
    assert path.is_relative_to(ROOT)
    assert path.stat().st_size<=10*1024*1024,path
    row=ref(path);artifacts[row['path']]=row
def gather(value):
    if isinstance(value,dict):
        if 'path'in value and 'sha256'in value:
            path=(ROOT/value['path']).resolve()
            if value['path']=='.runtime/ep261-gcc13-o0/compile_commands.json':
                # The pre-build preparation binds the 773-TU database. Actual
                # CMake regeneration adds this helper's six TUs (779); retain
                # the historical ref without pretending those bytes are current.
                assert value['sha256']=='d4e70d866ddbfdbbd97d62769f20b07a16341b6a0d88dd1de7982ebf2a8f3305'
                assert ref(path)['sha256']=='a2b5d02cf6a94426445c54f4353ba3aa527cebcf71706d548babc39d17cf9a27'
                external.append(dict(value,historical_only=True,reason='Preparation database preceded actual six-TU target regeneration; actual build commands/closure are separately retained'))
            elif not path.is_relative_to(ROOT)or path.stat().st_size>10*1024*1024:
                external.append(value)
            elif path.relative_to(ROOT).as_posix().startswith('crates/'):
                # Application/held manifests name their historical canonical
                # bytes. Their literal proposals/bases are archived separately;
                # current bytes are authenticated in final Source changes below.
                if ref(path)['sha256']==value['sha256']:add(checked(value))
                else:external.append(value)
            else:add(checked(value))
        else:
            for item in value.values():gather(item)
    elif isinstance(value,list):
        for item in value:gather(item)
for name in PREPS:
    path=BASE/name;add(path);gather(load(path))
for name in REVIEWS:
    path=BASE/name
    assert load(path)['accepted']is True,name
    add(path);gather(load(path))
prior_failures=[]
for name in ['ordinary-design-day-rust-focused-01','ordinary-design-day-rust-focused-02',
 'ordinary-design-day-rust-focused-03','ordinary-design-day-rust-bit-diagnostic-01',
 'ordinary-design-day-clippy-01']:
    path=BASE/name/'receipt.json'
    assert load(path)['exit_code']==101,name
    add(path);gather(load(path));prior_failures.append(ref(path))
for path in [*map(checked,qa),diagnostic,
 BASE/'ordinary-design-day-native-build-01/native-build.json',
 BASE/'ordinary-design-day-native-environment-02/frozen-environment.json',
 BASE/'ordinary-design-day-native-capture-command-01/receipt.json',
 BASE/'ordinary-design-day-fixture-actual-01/metadata.json',
 BASE/'ordinary-design-day-comparison-policy-01.json']:
    add(path)
    if path.name=='receipt.json':gather(load(path))
add(Path(__file__))
add(BASE/'publish-design-day-weather-Root-01.py')
add(BASE/'ordinary-design-day-publication-reference-audit-01.json')
add(BASE/'audit-design-day-publication-refs-Root-01.py')
add(BASE/'write-design-day-comparison-policy-Root-01.py')
add(ROOT/'crates/ep_runtime/src/weather_day/fixtures/ordinary_design_day_native.json')
add(ROOT/'energyplus_porting_plan/contracts/PSY-01-tolerances.json')
add(ROOT/'energyplus_porting_plan/contracts/PSY-02-tolerances.json')
for name in ['apply-design-day-weather-Root-01.py','apply-design-day-native-fixture-Root-01.py',
 'apply-design-day-raw-regression-Root-01.py','append-design-day-site-helper-Root-01.py']:
    add(BASE/name)
add(BASE/'apply-design-day-qualified-comparison-Root-01.py')
diff_dir=BASE/'ordinary-design-day-final-source-diffs-01'
diff_dir.mkdir(exist_ok=False)
names=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT,text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines())
changes=[]
for name in sorted(names):
    if not(name.startswith('crates/')or name in {'Cargo.lock','.gitattributes'}):continue
    path=ROOT/name
    if path.suffix=='.json':continue
    add(path)
    old=subprocess.run(['git','show','HEAD:'+name],cwd=ROOT,capture_output=True)
    before=old.stdout if old.returncode==0 else b''
    after=path.read_bytes()
    diff=diff_dir/(name.replace('/','__')+'.diff')
    diff.write_text(''.join(difflib.unified_diff(before.decode('utf8').splitlines(True),after.decode('utf8').splitlines(True),fromfile='HEAD/'+name,tofile=name)),encoding='utf8',newline='')
    add(diff);changes.append({'canonical':ref(path),'complete_direct_diff':ref(diff)})
assert sum(row['size_bytes']for row in artifacts.values())<60*1024*1024
OUT.mkdir()
archive=OUT/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED)as zipped:
    for name in sorted(artifacts):zipped.write(checked(artifacts[name]),name)
with zipfile.ZipFile(archive)as zipped:
    assert zipped.testzip()is None and set(zipped.namelist())==set(artifacts)
    for name in zipped.namelist():
        data=zipped.read(name)
        assert hashlib.sha256(data).hexdigest()==artifacts[name]['sha256']
        assert len(data)==artifacts[name]['size_bytes']
manifest={'schema':'src06-design-day-weather-evidence.v1','Source_snapshot':source,
 'changes':changes,'artifacts':list(artifacts.values()),'archive':ref(archive),
 'archive_member_count':len(artifacts),'external_historical_references_not_rehashed':external,
 'reference_scope':'Finite listed Source/fixture/metadata only; large Native image/map/core/raw remain custody references',
 'gates_updated':False}
write(OUT/'manifest.json',manifest)
summary={'schema':'src06-design-day-weather-summary.v1','status':'Selected DD weather input/producer/lifecycle implemented; full port incomplete',
 'Source_snapshot':source,'QA':qa,'workspace':{'groups':18,'passed':4974,'failed':0,'ignored':2},
 'actual_native_capture':ref(BASE/'ordinary-design-day-native-capture-command-01/receipt.json'),
 'actual_native_fixture':ref(ROOT/'crates/ep_runtime/src/weather_day/fixtures/ordinary_design_day_native.json'),
 'comparison_scope':load(BASE/'ordinary-design-day-comparison-policy-01.json'),
 'retained_strict_bit_failure':ref(diagnostic),
 'prior_actual_failed_commands':prior_failures,
 'test_policy':'Two existing test bodies extended; test binaries/body count unchanged. Full workspace once after resolving failures; no engine rerun.',
 'behavior':['Effective IDF/epJSON order, ReverseDD, selected defaults, six raw controls',
 'DefaultMultipliers/WetBulb-DewPoint/ASHRAEClearSky/ClarkAllen and whole96-slot Today/Tomorrow owners',
 'Actual early registry/six cells per DD, live local year, selected three-role weather lifecycle and no EPW reads in DD'],
 'limitations':['Whole Setup/Exterior/HB/postludes and ordinary activation still under implementation',
 'Strict calculated-output bit comparison failed; no whole-weather bit parity or new tolerance claimed',
 'Intermediate Native psychrometric inputs/caches are not paired; no PSY cache/state completion claim',
 'Selected warning-free branch only; alternative schedules/models/diagnostics remain unavailable',
 'All SRC-06 gates and A14/54 B14/64 unchanged'],
 'manifest':ref(OUT/'manifest.json'),'archive':ref(archive)}
write(OUT/'summary.json',summary)
print(json.dumps({'summary':ref(OUT/'summary.json'),'manifest':ref(OUT/'manifest.json'),'members':len(artifacts)}))

// Passive copies of real FixViewFactors, CalcScriptF and nested LU calls only.
#include "surface_consumer_observer.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/HeatBalanceIntRadExchange.hh>
#include <nlohmann/json.hpp>
#include <cstring>
#include <exception>
#include <limits>
#include <ostream>

#if !defined(__MINGW32__) || !defined(_WIN64) || __GNUC__ != 13 || __GNUC_MINOR__ != 2
#error "Original private-state reference requires verified GCC13.2 Windows ABI"
#endif
#if defined(_GLIBCXX_DEBUG) || defined(__FAST_MATH__) || defined(NDEBUG)
#error "Reference requires original assertions, nondebug containers and no fast math"
#endif
#if !defined(EP_psych_errors) || defined(EP_psych_stats)
#error "Reference definitions must match the genuine original core"
#endif

namespace SurfaceConsumerObservation {
namespace {
using json = nlohmann::json;
thread_local Capture *active = nullptr;
thread_local Scope *current_scope = nullptr;
char const *procedure_name(Procedure p) noexcept
{
    switch (p) {
    case Procedure::CalcScriptF: return "CalcScriptF";
    case Procedure::CalcMatrixInverse: return "CalcMatrixInverse";
    case Procedure::FixViewFactors: return "FixViewFactors";
    default: return "unknown-observer-procedure";
    }
}
bool increment(std::uint64_t &counter) noexcept
{
    if (counter == std::numeric_limits<std::uint64_t>::max()) {
        active->counter_overflow = true;
        return false;
    }
    ++counter;
    return true;
}
// scalar() and clock() are exact accepted readiness03 helper bodies.
// Their bodies are inserted by prepare_sources.py from its pinned parent.
// BEGIN_ACCEPTED_HELPERS
json scalar(double value)
{
    static_assert(sizeof(double) == sizeof(std::uint64_t));
    static_assert(std::numeric_limits<double>::is_iec559);
    std::uint64_t bits;
    std::memcpy(&bits, &value, sizeof(bits));
    char text[17];
    char const *hex = "0123456789abcdef";
    for (unsigned i = 0; i < 16; ++i) text[i] = hex[(bits >> ((15 - i) * 4)) & 15];
    text[16] = '\0';
    auto const magnitude = bits & 0x7fffffffffffffffULL;
    bool const negative = (bits >> 63) != 0;
    char const *kind = magnitude > 0x7ff0000000000000ULL ? "nan" :
        magnitude == 0x7ff0000000000000ULL ? (negative ? "negative_infinity" : "positive_infinity") :
        magnitude == 0 ? (negative ? "negative_zero" : "positive_zero") : "finite";
    return {{"value_bits", text}, {"value_class", kind}};
}
json clock(EnergyPlus::EnergyPlusData const &state)
{
    auto const &g = *state.dataGlobal;
    auto const &e = *state.dataEnvrn;
    auto const &h = *state.dataHVACGlobal;
    return {{"state_address", reinterpret_cast<std::uintptr_t>(&state)},
        {"environment_index", e.CurEnvirNum}, {"environment_name", e.EnvironmentName},
        {"CalendarYear", g.CalendarYear}, {"Month", e.Month}, {"DayOfMonth", e.DayOfMonth},
        {"DayOfSim", g.DayOfSim}, {"HourOfDay", g.HourOfDay}, {"TimeStep", g.TimeStep},
        {"KindOfSim", static_cast<int>(g.KindOfSim)}, {"CurrentTime", scalar(g.CurrentTime)},
        {"TimeStepZone", scalar(g.TimeStepZone)}, {"TimeStepZoneSec", scalar(g.TimeStepZoneSec)},
        {"TimeStepSys", scalar(h.TimeStepSys)}, {"TimeStepSysSec", scalar(h.TimeStepSysSec)},
        {"SysTimeElapsed", scalar(h.SysTimeElapsed)}, {"FracTimeStepZone", scalar(h.FracTimeStepZone)},
        {"FirstTimeStepSysFlag", h.FirstTimeStepSysFlag}, {"ShortenTimeStepSys", h.ShortenTimeStepSys},
        {"UseZoneTimeStepHistory", h.UseZoneTimeStepHistory}, {"NumOfSysTimeSteps", h.NumOfSysTimeSteps},
        {"KickOffSimulation", g.KickOffSimulation}, {"WarmupFlag", g.WarmupFlag},
        {"BeginSimFlag", g.BeginSimFlag}, {"BeginEnvrnFlag", g.BeginEnvrnFlag},
        {"BeginDayFlag", g.BeginDayFlag}, {"BeginHourFlag", g.BeginHourFlag},
        {"BeginTimeStepFlag", g.BeginTimeStepFlag}, {"ZoneSizingCalc", g.ZoneSizingCalc},
        {"SysSizingCalc", g.SysSizingCalc}, {"InsideSurfIterations", state.dataHeatBal->InsideSurfIterations}};
}
// END_ACCEPTED_HELPERS
json matrix_copy(ObjexxFCL::Array2<double> const &values, bool contents_initialized)
{
    json out{{"allocated", values.allocated()}, {"size", values.size()},
        {"lower1", values.l1()}, {"upper1", values.u1()},
        {"lower2", values.l2()}, {"upper2", values.u2()},
        {"size1", values.size1()}, {"size2", values.size2()},
        {"array_address", reinterpret_cast<std::uintptr_t>(&values)},
        {"storage_address", values.data() ? json(reinterpret_cast<std::uintptr_t>(values.data())) : json(nullptr)},
        {"contents_initialized_by_actual_producer", contents_initialized},
        {"flat_values", nullptr}, {"flat_index_layout", "ObjexxFCL Array2::operator[] offsets 0..size-1"}};
    if (!contents_initialized || !values.allocated()) return out;
    out["flat_values"] = json::array();
    for (ObjexxFCL::Array2<double>::size_type offset = 0; offset < values.size(); ++offset)
        out["flat_values"].push_back({{"offset", offset}, {"value", scalar(values[offset])}});
    return out;
}
struct ProducerInputs {
    int dimension;
    ObjexxFCL::Array1D<double> const *areas;
    ObjexxFCL::Array2<double> const *factors;
    ObjexxFCL::Array1D<double> const *emissivities = nullptr;
    ObjexxFCL::Array2<double> const *script_f = nullptr;
    bool output_initialized = false;
    std::string const *enclosure_name = nullptr;
    std::vector<int> const *spaces = nullptr;
    double const *original_check = nullptr;
    double const *fixed_check = nullptr;
    double const *final_check = nullptr;
    int const *iterations = nullptr;
    double const *row_sum = nullptr;
    bool any_internal_mass = false;
    char const *return_kind = nullptr;
};
json vector_copy(ObjexxFCL::Array1D<double> const &values)
{
    json out{{"allocated", values.allocated()}, {"size", values.size()},
        {"lower", values.l()}, {"upper", values.u()},
        {"array_address", reinterpret_cast<std::uintptr_t>(&values)},
        {"storage_address", values.data() ? json(reinterpret_cast<std::uintptr_t>(values.data())) : json(nullptr)},
        {"values", json::array()}};
    if (values.allocated())
        for (int index = values.l(); index <= values.u(); ++index)
            out["values"].push_back({{"index", index}, {"value", scalar(values(index))}});
    return out;
}
json actual_spaces(EnergyPlus::EnergyPlusData const &state, std::vector<int> const &spaces)
{
    auto const &hb = *state.dataHeatBal;
    json out = json::array();
    for (int space_num : spaces) {
        json item{{"spaceNum", space_num}, {"space_owner_present", false}, {"zone_owner_present", false}};
        if (hb.space.allocated() && space_num >= 1 && space_num <= hb.space.isize()) {
            auto const &space = hb.space(space_num);
            item["space_owner_present"] = true;
            item["space_name"] = space.Name;
            item["space_address"] = reinterpret_cast<std::uintptr_t>(&space);
            item["zoneNum"] = space.zoneNum;
            if (hb.Zone.allocated() && space.zoneNum >= 1 && space.zoneNum <= hb.Zone.isize()) {
                auto const &zone = hb.Zone(space.zoneNum);
                item["zone_owner_present"] = true;
                item["zone_address"] = reinterpret_cast<std::uintptr_t>(&zone);
                item["EnforcedReciprocity"] = zone.EnforcedReciprocity;
                item["zone_spaceIndexes"] = json::array();
                for (int index : zone.spaceIndexes) item["zone_spaceIndexes"].push_back(index);
            }
        }
        out.push_back(item);
    }
    return out;
}
json producer_copy(ProducerInputs const &p)
{
    json out{{"N", p.dimension}, {"A", vector_copy(*p.areas)}, {"F", matrix_copy(*p.factors, true)}};
    if (p.emissivities && p.script_f) {
        out["kind"] = "CalcScriptF";
        out["EMISS"] = vector_copy(*p.emissivities);
        out["ScriptF"] = matrix_copy(*p.script_f, p.output_initialized);
    } else {
        out["kind"] = "FixViewFactors";
        out["enclosure_name"] = *p.enclosure_name;
        out["spaceNums"] = *p.spaces;
        out["space_associations"] = current_scope && current_scope->state ? actual_spaces(*current_scope->state, *p.spaces) : json(nullptr);
        out["LargestSurf"] = current_scope && current_scope->state ? json(current_scope->state->dataHeatBalIntRadExchg->LargestSurf) : json(nullptr);
        out["actual_output_arguments_read"] = p.return_kind != nullptr;
        if (p.return_kind) {
            out["OriginalCheckValue"] = scalar(*p.original_check);
            out["FixedCheckValue"] = scalar(*p.fixed_check);
            out["FinalCheckValue"] = scalar(*p.final_check);
            out["NumIterations"] = *p.iterations;
            out["RowSum"] = scalar(*p.row_sum);
        }
        out["anyIntMassInZone"] = p.any_internal_mass;
        out["actual_return_kind"] = p.return_kind ? json(p.return_kind) : json(nullptr);
        out["F_argument_is_actual_Array2A_proxy"] = true;
    }
    return out;
}
void emit(char const *checkpoint, ObjexxFCL::Array2<double> const *A,
          ObjexxFCL::Array2<double> const *I, bool inverse_initialized,
          int dimension, int pivot_index, int pivot_selected, double const *pivot_magnitude,
          ProducerInputs const *producer = nullptr) noexcept
{
    if (!active) return;
    if (!increment(active->attempted_events)) return;
    auto const ordinal = active->attempted_events;
    try {
        json event{{"event_ordinal", ordinal}, {"checkpoint", checkpoint},
            {"radiation_producer_protocol", "src06-ordinary-radiation-producer-native.v1"},
            {"clock", current_scope && current_scope->state ? clock(*current_scope->state) : json(nullptr)},
            {"state_from_actual_parent", current_scope ? json(current_scope->state_from_actual_parent) : json(nullptr)},
            {"procedure", current_scope ? json(procedure_name(current_scope->procedure)) : json(nullptr)},
            {"invocation_ordinal", current_scope ? json(current_scope->ordinal) : json(nullptr)},
            {"parent_procedure", current_scope && current_scope->parent ? json(procedure_name(current_scope->parent->procedure)) : json(nullptr)},
            {"parent_invocation_ordinal", current_scope && current_scope->parent ? json(current_scope->parent->ordinal) : json(nullptr)},
            {"locals", json::object()}, {"matrices", json::object()}, {"counted_as_PASS", false}};
        if (producer) {
            event["producer"] = producer_copy(*producer);
        } else if (A && I) {
            event["matrices"]["A"] = matrix_copy(*A, true);
            event["matrices"]["I"] = matrix_copy(*I, inverse_initialized);
        } else if (pivot_magnitude) {
            event["locals"] = {{"i", pivot_index}, {"iPiv", pivot_selected}, {"aPiv", scalar(*pivot_magnitude)}};
        } else {
            event["locals"]["N"] = dimension;
        }
        auto const bytes = event.dump();
        if (!active->first_event) active->output << ',';
        active->output << bytes;
        if (!active->output) {
            active->stream_failed = true;
            increment(active->stream_failed_events);
            return;
        }
        active->first_event = false;
        increment(active->retained_events);
    } catch (...) {
        increment(active->copy_failures);
        if (active->first_failed_event == 0) active->first_failed_event = ordinal;
        active->last_failed_event = ordinal;
    }
}
} // namespace
Binding::Binding(Capture &capture) noexcept : previous(active) { active = &capture; }
Binding::~Binding() noexcept { active = previous; }
Scope::Scope(EnergyPlus::EnergyPlusData const *actual_state, Procedure p) noexcept
    : procedure(p), parent(current_scope), state(actual_state ? actual_state : (parent ? parent->state : nullptr)),
      state_from_actual_parent(actual_state == nullptr && parent && parent->state), exceptions_on_entry(std::uncaught_exceptions())
{
    current_scope = this;
    if (active) {
        auto &calls = active->procedure_calls[static_cast<unsigned>(procedure)];
        if (increment(calls)) ordinal = calls;
    }
}
Scope::~Scope() noexcept
{
    if (active) {
        auto &counts = std::uncaught_exceptions() > exceptions_on_entry ? active->scope_unwinds : active->scope_normal_exits;
        increment(counts[static_cast<unsigned>(procedure)]);
    }
    current_scope = parent;
}
void record_marker(char const *checkpoint, int dimension) noexcept
{
    emit(checkpoint, nullptr, nullptr, false, dimension, 0, 0, nullptr);
}
void record_matrices(char const *checkpoint, ObjexxFCL::Array2<double> const &A,
                     ObjexxFCL::Array2<double> const &I, bool inverse_initialized) noexcept
{
    emit(checkpoint, &A, &I, inverse_initialized, 0, 0, 0, nullptr);
}
void record_pivot(int index, int selected_index, double magnitude) noexcept
{
    emit("matrix_inverse_pivot_selected", nullptr, nullptr, false, 0, index, selected_index, &magnitude);
}
void record_fix(char const *checkpoint, int dimension, ObjexxFCL::Array1D<double> const &areas,
                ObjexxFCL::Array2<double> const &factors, std::string const &enclosure_name,
                std::vector<int> const &spaces, double const &original_check,
                double const &fixed_check, double const &final_check, int const &iterations,
                double const &row_sum, bool any_internal_mass, char const *return_kind) noexcept
{
    ProducerInputs p{dimension, &areas, &factors};
    p.enclosure_name = &enclosure_name;
    p.spaces = &spaces;
    p.original_check = &original_check;
    p.fixed_check = &fixed_check;
    p.final_check = &final_check;
    p.iterations = &iterations;
    p.row_sum = &row_sum;
    p.any_internal_mass = any_internal_mass;
    p.return_kind = return_kind;
    emit(checkpoint, nullptr, nullptr, false, dimension, 0, 0, nullptr, &p);
}
void record_scriptf(char const *checkpoint, int dimension, ObjexxFCL::Array1D<double> const &areas,
                    ObjexxFCL::Array2<double> const &factors, ObjexxFCL::Array1D<double> const &emissivities,
                    ObjexxFCL::Array2<double> const &script_f, bool output_initialized) noexcept
{
    ProducerInputs p{dimension, &areas, &factors};
    p.emissivities = &emissivities;
    p.script_f = &script_f;
    p.output_initialized = output_initialized;
    emit(checkpoint, nullptr, nullptr, false, dimension, 0, 0, nullptr, &p);
}
bool finish(Capture &capture, bool returned, int exit_code, char const *caught) noexcept
{
    try {
        json names = json::array();
        for (unsigned i = 0; i < static_cast<unsigned>(Procedure::Count); ++i)
            names.push_back(procedure_name(static_cast<Procedure>(i)));
        json summary{{"radiation_producer_protocol", "src06-ordinary-radiation-producer-native.v1"},
            {"capture_selection", "every-real-FixViewFactors-and-CalcScriptF-input-output-plus-complete-nested-LU"},
            {"actual_engine_entry_returned", returned}, {"actual_engine_exit_code", returned ? json(exit_code) : json(nullptr)},
            {"outer_caught_exception_class", caught ? json(caught) : json(nullptr)}, {"procedure_names", names},
            {"procedure_calls", capture.procedure_calls}, {"scope_normal_exits", capture.scope_normal_exits},
            {"scope_unwinds", capture.scope_unwinds}, {"attempted_events", capture.attempted_events},
            {"retained_events", capture.retained_events}, {"copy_failures", capture.copy_failures},
            {"first_failed_event", capture.first_failed_event}, {"last_failed_event", capture.last_failed_event},
            {"stream_failed_events", capture.stream_failed_events}, {"counter_overflow", capture.counter_overflow},
            {"stream_failed", capture.stream_failed}, {"uninitialized_inverse_contents_read", false},
            {"ScriptF_producer_or_cache_parity_claimed", false}, {"ordinary_radiation_activated", false},
            {"numeric_profiles_chosen", false}, {"integration_PASS_claimed", false}};
        capture.output << "],\"summary\":" << summary.dump() << '}';
        capture.output.flush();
        return static_cast<bool>(capture.output) && !capture.stream_failed && !capture.counter_overflow && capture.copy_failures == 0;
    } catch (...) { return false; }
}
} // namespace SurfaceConsumerObservation

"""Author the finite passive DD/report/shadow Source successor; execute no target."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
PARENT = HERE.parent/'ordinary-design-day-native-prep-01'

def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}

def put(name,data):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data.encode() if isinstance(data,str) else data)
    return ref(path)

def replace(text,before,after):
    assert text.count(before)==1, before[:100]
    return text.replace(before,after,1)

assert ref(PARENT/'manifest.json')['sha256']=='7639949ff797795da7b45fb2ff71db943fddeba6b1fc5afdea8fe86d5f42a51f'
parent=json.loads((PARENT/'manifest.json').read_bytes())
for row in parent['compiled_source_files']+[parent['header'],parent['CMake_recipe']]:
    assert ref(ROOT/row['path'])==row

header=(PARENT/'surface_consumer_observer.hh').read_text(encoding='utf-8')
header=replace(header,'std::uint64_t setup_calls=0;','std::uint64_t setup_calls=0, non_kickoff_manage_weather_calls=0;')
header=replace(header,'std::uint64_t ordinal=0;','std::uint64_t ordinal=0, non_kickoff_manage_weather_ordinal=0;')
put('surface_consumer_observer.hh',header)
collector=(PARENT/'surface_consumer_observer.cc').read_text(encoding='utf-8')
collector=replace(collector,'#include <EnergyPlus/WeatherManager.hh>',
    '#include <EnergyPlus/WeatherManager.hh>\n#include <EnergyPlus/OutputReportPredefined.hh>\n#include <EnergyPlus/SolarShading.hh>\n#include <EnergyPlus/DataSurfaces.hh>')
additional=r'''json predefined_copy(EnergyPlus::EnergyPlusData const &state) {
    auto const &p=*state.dataOutRptPredefined;
    return {{"sizeReportName",p.sizeReportName},{"numReportName",p.numReportName},
        {"sizeSubTable",p.sizeSubTable},{"numSubTable",p.numSubTable},
        {"sizeColumnTag",p.sizeColumnTag},{"numColumnTag",p.numColumnTag},
        {"sizeTableEntry",p.sizeTableEntry},{"numTableEntry",p.numTableEntry},
        {"pdchDDmaxDB",p.pdchDDmaxDB},{"pdchDDrange",p.pdchDDrange},{"pdchDDhumid",p.pdchDDhumid},
        {"pdchDDhumTyp",p.pdchDDhumTyp},{"pdchDDwindSp",p.pdchDDwindSp},{"pdchDDwindDr",p.pdchDDwindDr},
        {"reportName",array_copy(p.reportName,[](auto const &v){return json{
            {"name",v.name},{"namewithspaces",v.namewithspaces},{"abrev",v.abrev},{"show",v.show}};})},
        {"subTable",array_copy(p.subTable,[](auto const &v){return json{
            {"name",v.name},{"indexReportName",v.indexReportName},{"footnote",v.footnote}};})},
        {"columnTag",array_copy(p.columnTag,[](auto const &v){return json{
            {"heading",v.heading},{"indexSubTable",v.indexSubTable}};})},
        {"tableEntry",array_copy(p.tableEntry,[](auto const &v){return json{
            {"charEntry",v.charEntry},{"objectName",v.objectName},{"indexColumn",v.indexColumn},
            {"subTableIndex",v.subTableIndex},{"uniqueObjName",v.uniqueObjName},
            {"origRealEntry",scalar(v.origRealEntry)},{"significantDigits",v.significantDigits},
            {"origEntryIsReal",v.origEntryIsReal}};})}};
}
template<class Values> json cube_copy(Values const &v) {
    json result{{"allocated",v.allocated()},{"size",v.size()},
        {"lower1",v.l1()},{"upper1",v.u1()},{"size1",v.size1()},
        {"lower2",v.l2()},{"upper2",v.u2()},{"size2",v.size2()},
        {"lower3",v.l3()},{"upper3",v.u3()},{"size3",v.size3()},
        {"object_address",reinterpret_cast<std::uintptr_t>(&v)},
        {"storage_address",v.data()?json(reinterpret_cast<std::uintptr_t>(v.data())):json(nullptr)},
        {"rows",json::array()}};
    if(v.allocated()) for(int k=v.l3();k<=v.u3();++k) for(int j=v.l2();j<=v.u2();++j)
        for(int i=v.l1();i<=v.u1();++i)
            result["rows"].push_back({{"index1",i},{"index2",j},{"index3",k},{"value",scalar(v(i,j,k))}});
    return result;
}
json shading_copy(EnergyPlus::EnergyPlusData const &state) {
    auto const &s=*state.dataSolarShading;
    auto const &h=*state.dataHeatBal;
    auto const &d=*state.dataSurface;
    json result{{"TotSurfaces",d.TotSurfaces},{"ShadowingDaysLeft",s.ShadowingDaysLeft},
        {"ShadowingCalcFrequency",s.ShadowingCalcFrequency},{"InitComplexOnce",s.InitComplexOnce},
        {"firstTime",s.firstTime},{"CalcSkyDifShading",s.CalcSkyDifShading},
        {"Surface",ep_vector_copy(d.Surface,[](auto const &v){return json{
            {"Name",v.Name},{"Zone",v.Zone},{"spaceNum",v.spaceNum},
            {"HeatTransSurf",v.HeatTransSurf},{"ExtSolar",v.ExtSolar},{"ExtBoundCond",v.ExtBoundCond},
            {"Area",scalar(v.Area)},{"ViewFactorSky",scalar(v.ViewFactorSky)},
            {"ViewFactorGround",scalar(v.ViewFactorGround)},{"ViewFactorSkyIR",scalar(v.ViewFactorSkyIR)},
            {"ViewFactorGroundIR",scalar(v.ViewFactorGroundIR)},
            {"OutNormVec",{scalar(v.OutNormVec.x),scalar(v.OutNormVec.y),scalar(v.OutNormVec.z)}},
            {"SinTilt",scalar(v.SinTilt)},{"CosTilt",scalar(v.CosTilt)},
            {"SinAzim",scalar(v.SinAzim)},{"CosAzim",scalar(v.CosAzim)}};})},
        {"SurfSunCosTheta",array_copy(s.SurfSunCosTheta,[](double v){return scalar(v);})},
        {"SurfSunlitArea",array_copy(s.SurfSunlitArea,[](double v){return scalar(v);})},
        {"SurfAnisoSkyMult",array_copy(s.SurfAnisoSkyMult,[](double v){return scalar(v);})},
        {"SurfMultIsoSky",array_copy(s.SurfMultIsoSky,[](double v){return scalar(v);})},
        {"SurfMultCircumSolar",array_copy(s.SurfMultCircumSolar,[](double v){return scalar(v);})},
        {"SurfMultHorizonZenith",array_copy(s.SurfMultHorizonZenith,[](double v){return scalar(v);})},
        {"SurfDifShdgRatioIsoSky",array_copy(s.SurfDifShdgRatioIsoSky,[](double v){return scalar(v);})},
        {"SurfCurDifShdgRatioIsoSky",array_copy(s.SurfCurDifShdgRatioIsoSky,[](double v){return scalar(v);})},
        {"SurfDifShdgRatioHoriz",array_copy(s.SurfDifShdgRatioHoriz,[](double v){return scalar(v);})},
        {"SurfWithShdgIsoSky",array_copy(s.SurfWithShdgIsoSky,[](double v){return scalar(v);})},
        {"SurfWoShdgIsoSky",array_copy(s.SurfWoShdgIsoSky,[](double v){return scalar(v);})},
        {"SurfWithShdgHoriz",array_copy(s.SurfWithShdgHoriz,[](double v){return scalar(v);})},
        {"SurfWoShdgHoriz",array_copy(s.SurfWoShdgHoriz,[](double v){return scalar(v);})},
        {"SurfDifShdgRatioIsoSkyHRTS",cube_copy(s.SurfDifShdgRatioIsoSkyHRTS)},
        {"SurfDifShdgRatioHorizHRTS",cube_copy(s.SurfDifShdgRatioHorizHRTS)},
        {"SurfCosIncAng",cube_copy(h.SurfCosIncAng)},{"SurfSunlitFrac",cube_copy(h.SurfSunlitFrac)}};
    return result;
}
'''
collector=replace(collector,'json full_weather(EnergyPlus::EnergyPlusData const &state) {',additional+'json full_weather(EnergyPlus::EnergyPlusData const &state) {')
collector=replace(collector,'|| g.KindOfSim==EnergyPlus::Constant::KindOfSim::DesignDay;',
    '|| g.KindOfSim==EnergyPlus::Constant::KindOfSim::DesignDay\n        || (p==Procedure::ManageWeather && current_scope->non_kickoff_manage_weather_ordinal>0\n            && current_scope->non_kickoff_manage_weather_ordinal<=2);')
collector=replace(collector,'{"weather",full_weather(*current_scope->state)},{"counted_as_PASS",false}};',
    '{"weather",full_weather(*current_scope->state)},\n            {"actual_non_kickoff_manage_weather_ordinal",current_scope->non_kickoff_manage_weather_ordinal},\n            {"predefined_reports",current_scope->procedure==Procedure::GetDesignDayData?predefined_copy(*current_scope->state):json(nullptr)},\n            {"solar_shading",current_scope->procedure==Procedure::ManageWeather?shading_copy(*current_scope->state):json(nullptr)},\n            {"counted_as_PASS",false}};')
collector=replace(collector,'    emit("procedure_entry");',
    '    if(active && procedure==Procedure::ManageWeather && state && !state->dataGlobal->KickOffSimulation\n'
    '       && increment(active->non_kickoff_manage_weather_calls))\n'
    '        non_kickoff_manage_weather_ordinal=active->non_kickoff_manage_weather_calls;\n'
    '    emit("procedure_entry");')
collector=replace(collector,'all-DD-getter-and-producer-calls-and-every-actual-kickoff-weather-boundary; all-eight-procedure-counters',
    'all-DD-getter-and-producer-calls-and-every-actual-kickoff-weather-boundary-plus-first-two-actual-nonkickoff-ManageWeather; all-eight-procedure-counters')
collector=replace(collector,'{"setup_calls",capture.setup_calls},{"attempted_events",capture.attempted_events},',
    '{"setup_calls",capture.setup_calls},{"non_kickoff_manage_weather_calls",capture.non_kickoff_manage_weather_calls},\n            {"attempted_events",capture.attempted_events},')
put('surface_consumer_observer.cc',collector)

for name in ['surface_consumer_main.cpp','WeatherManager.design_day.cc','SimulationManager.design_day.cc',
             'WeatherManager.design_day.cc.diff','SimulationManager.design_day.cc.diff','source-additions.json',
             'ordinary_design_day_reference.cmake']:
    put(name,(PARENT/name).read_bytes())
parent_ranges=json.loads((PARENT/'Original-ranges.json').read_bytes())
ranges=[]
for row in parent_ranges:
    literal=ROOT/row['literal']['path']
    new=put('Original/'+literal.name,literal.read_bytes())
    ranges.append({**row,'literal':new})
for name,start,end in [('OutputReportPredefined.hh',78,137),('OutputReportPredefined.hh',201,214),
    ('OutputReportPredefined.hh',1666,1713),('SolarShading.hh',364,394),('SolarShading.hh',410,447),
    ('SolarShading.cc',887,917),('SolarShading.cc',974,982),('SolarShading.cc',10529,10544),
    ('DataHeatBalance.hh',1987,1991),('DataSurfaces.hh',735,745),('DataSurfaces.hh',754,782),
    ('DataSurfaces.hh',829,842)]:
    original=ROOT/'.reference/energyplus-src/26.1.0/src/EnergyPlus'/name
    lines=original.read_text(encoding='utf-8').splitlines(keepends=True)
    literal=put(f'Original/{name}-{start}-{end}.txt',''.join(lines[start-1:end]))
    ranges.append({'Original':ref(original),'start_line':start,'end_line':end,'literal':literal})
put('Original-ranges.json',json.dumps(ranges,indent=2)+'\n')

diffs=[]
for name in ['surface_consumer_observer.cc','surface_consumer_observer.hh']:
    before=(PARENT/name).read_text(encoding='utf-8')
    after=(HERE/name).read_text(encoding='utf-8')
    diff=put(name+'.parent.diff',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
        fromfile='parent01/'+name,tofile='proposal02/'+name)))
    diffs.append({'base':ref(PARENT/name),'proposal':ref(HERE/name),'complete_diff':diff})
manifest={**parent,'Source_author':ref(Path(__file__)),'README':ref(HERE/'README.md'),
    'parent_DD_preparation':ref(PARENT/'manifest.json'),
    'compiled_source_files':[ref(HERE/Path(r['path']).name) if r['path'].startswith(PARENT.relative_to(ROOT).as_posix()+'/') else r for r in parent['compiled_source_files']],
    'derived_Original_TUs':[{**r,'derived':ref(HERE/Path(r['derived']['path']).name),
        'complete_diff':ref(HERE/Path(r['complete_diff']['path']).name)} for r in parent['derived_Original_TUs']],
    'header':ref(HERE/'surface_consumer_observer.hh'),'CMake_recipe':ref(HERE/'ordinary_design_day_reference.cmake'),
    'literal_source_additions':ref(HERE/'source-additions.json'),'Original_ranges':ref(HERE/'Original-ranges.json'),
    'complete_parent_diffs':diffs,
    'normal_RunPeriod_full_payload_captured':False,
    'normal_RunPeriod_first_two_actual_ManageWeather_boundaries_captured':True,
    'predefined_reports_capture_scope':'complete allocated registry/table arrays and six DD IDs at every GetDesignDayData selected event only',
    'solar_shading_capture_scope':'actual allocated initialized shading/HB arrays and Surface geometry at every selected ManageWeather entry/return only',
    'solar_shading_array_initialized_source_ranges_included':True,
    'additional_compilation_units_or_engine_calls':0}
put('manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':ref(HERE/'manifest.json'),'collector':ref(HERE/'surface_consumer_observer.cc'),'parent_diffs':diffs}))

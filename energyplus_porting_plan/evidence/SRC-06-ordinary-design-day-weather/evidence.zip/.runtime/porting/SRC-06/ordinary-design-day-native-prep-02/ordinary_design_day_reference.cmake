# One additive six-TU target; a launcher must include the current project chain first.
if(NOT DEFINED ORDINARY_DESIGN_DAY_SOURCE_DIR OR NOT DEFINED ORDINARY_DESIGN_DAY_OUTPUT_DIR)
  message(FATAL_ERROR "DesignDay observation requires reviewed Source and a fresh D output directory")
endif()
if(CMAKE_SOURCE_DIR STREQUAL PROJECT_SOURCE_DIR)
  get_property(_ordinary_design_day_scheduled GLOBAL PROPERTY ORDINARY_DESIGN_DAY_SCHEDULED)
  if(NOT _ordinary_design_day_scheduled)
    set_property(GLOBAL PROPERTY ORDINARY_DESIGN_DAY_SCHEDULED TRUE)
    function(ordinary_design_day_add_reference)
      if(NOT TARGET energypluslib)
        message(FATAL_ERROR "DesignDay observation requires genuine unchanged energypluslib")
      endif()
      get_target_property(_ordinary_design_day_defs energypluslib COMPILE_DEFINITIONS)
      get_directory_property(_ordinary_design_day_dir_defs DIRECTORY "${CMAKE_SOURCE_DIR}/src/EnergyPlus" COMPILE_DEFINITIONS)
      list(APPEND _ordinary_design_day_defs ${_ordinary_design_day_dir_defs})
      list(FILTER _ordinary_design_day_defs EXCLUDE REGEX "-NOTFOUND$")
      list(REMOVE_DUPLICATES _ordinary_design_day_defs)
      add_executable(ordinary_design_day_helper
        "${ORDINARY_DESIGN_DAY_SOURCE_DIR}/surface_consumer_main.cpp"
        "${ORDINARY_DESIGN_DAY_SOURCE_DIR}/WeatherManager.design_day.cc"
        "${ORDINARY_DESIGN_DAY_SOURCE_DIR}/SimulationManager.design_day.cc"
        "${ORDINARY_DESIGN_DAY_SOURCE_DIR}/surface_consumer_observer.cc"
        "${CMAKE_SOURCE_DIR}/src/EnergyPlus/api/EnergyPlusPgm.cc"
        "${CMAKE_SOURCE_DIR}/src/EnergyPlus/CommandLineInterface.cc")
      target_include_directories(ordinary_design_day_helper PRIVATE
        "$<TARGET_PROPERTY:energypluslib,INCLUDE_DIRECTORIES>" "${ORDINARY_DESIGN_DAY_SOURCE_DIR}")
      target_compile_definitions(ordinary_design_day_helper PRIVATE ${_ordinary_design_day_defs} ENERGYPLUS_STATIC_API)
      target_link_libraries(ordinary_design_day_helper PRIVATE energypluslib project_options project_fp_options project_warnings bcrypt)
      target_compile_features(ordinary_design_day_helper PRIVATE cxx_std_20)
      set_target_properties(ordinary_design_day_helper PROPERTIES
        RUNTIME_OUTPUT_DIRECTORY "${ORDINARY_DESIGN_DAY_OUTPUT_DIR}")
      target_link_options(ordinary_design_day_helper PRIVATE
        "-Wl,-Map,${ORDINARY_DESIGN_DAY_OUTPUT_DIR}/ordinary_design_day_helper.map")
    endfunction()
    cmake_language(DEFER CALL ordinary_design_day_add_reference)
  endif()
endif()

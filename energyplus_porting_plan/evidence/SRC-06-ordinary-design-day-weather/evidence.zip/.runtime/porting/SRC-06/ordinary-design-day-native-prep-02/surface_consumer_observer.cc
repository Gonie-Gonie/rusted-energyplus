// Passive actual DD getters/weather/Setup call-site copies; no producer invocation.
#include "surface_consumer_observer.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataReportingFlags.hh>
#include <EnergyPlus/DataSystemVariables.hh>
#include <EnergyPlus/WeatherManager.hh>
#include <EnergyPlus/OutputReportPredefined.hh>
#include <EnergyPlus/SolarShading.hh>
#include <EnergyPlus/DataSurfaces.hh>
#include <nlohmann/json.hpp>
#include <cstring>
#include <exception>
#include <limits>
#include <ostream>
#if !defined(__MINGW32__) || !defined(_WIN64) || __GNUC__ != 13 || __GNUC_MINOR__ != 2
#error "Original reference requires verified GCC13.2 Windows ABI"
#endif
#if defined(_GLIBCXX_DEBUG) || defined(__FAST_MATH__) || defined(NDEBUG)
#error "Reference requires original assertions, nondebug containers and no fast math"
#endif
#if !defined(EP_psych_errors) || defined(EP_psych_stats)
#error "Reference definitions must match the genuine original core"
#endif
namespace SurfaceConsumerObservation {
namespace {
using json = nlohmann::json;
thread_local Capture *active=nullptr;
thread_local Scope *current_scope=nullptr;
thread_local char const *current_role=nullptr;
thread_local std::uint64_t current_setup_ordinal=0;
char const *procedure_name(Procedure p) noexcept {
    switch(p) {
    case Procedure::SetupSimulation: return "SetupSimulation";
    case Procedure::GetNextEnvironment: return "GetNextEnvironment";
    case Procedure::GetDesignDayData: return "GetDesignDayData";
    case Procedure::ManageWeather: return "ManageWeather";
    case Procedure::InitializeWeather: return "InitializeWeather";
    case Procedure::UpdateWeatherData: return "UpdateWeatherData";
    case Procedure::SetUpDesignDay: return "SetUpDesignDay";
    case Procedure::SetCurrentWeather: return "SetCurrentWeather";
    default: return "unknown-observer-procedure";
    }
}
bool increment(std::uint64_t &counter) noexcept {
    if(counter==std::numeric_limits<std::uint64_t>::max()) { active->counter_overflow=true; return false; }
    ++counter;
    return true;
}
// BEGIN_ACCEPTED_HELPERS
json scalar(double value)
{
    static_assert(sizeof(double) == sizeof(std::uint64_t));
    static_assert(std::numeric_limits<double>::is_iec559);
    std::uint64_t bits;
    std::memcpy(&bits, &value, sizeof(bits));
    char text[17];
    char const *hex = "0123456789abcdef";
    for (unsigned i = 0; i < 16; ++i) text[i] = hex[(bits >> ((15 - i) * 4)) & 15];
    text[16] = '\0';
    auto const magnitude = bits & 0x7fffffffffffffffULL;
    bool const negative = (bits >> 63) != 0;
    char const *kind = magnitude > 0x7ff0000000000000ULL ? "nan" :
        magnitude == 0x7ff0000000000000ULL ? (negative ? "negative_infinity" : "positive_infinity") :
        magnitude == 0 ? (negative ? "negative_zero" : "positive_zero") : "finite";
    return {{"value_bits", text}, {"value_class", kind}};
}
json clock(EnergyPlus::EnergyPlusData const &state)
{
    auto const &g = *state.dataGlobal;
    auto const &e = *state.dataEnvrn;
    auto const &h = *state.dataHVACGlobal;
    return {{"state_address", reinterpret_cast<std::uintptr_t>(&state)},
        {"environment_index", e.CurEnvirNum}, {"environment_name", e.EnvironmentName},
        {"CalendarYear", g.CalendarYear}, {"Month", e.Month}, {"DayOfMonth", e.DayOfMonth},
        {"DayOfSim", g.DayOfSim}, {"HourOfDay", g.HourOfDay}, {"TimeStep", g.TimeStep},
        {"KindOfSim", static_cast<int>(g.KindOfSim)}, {"CurrentTime", scalar(g.CurrentTime)},
        {"TimeStepZone", scalar(g.TimeStepZone)}, {"TimeStepZoneSec", scalar(g.TimeStepZoneSec)},
        {"TimeStepSys", scalar(h.TimeStepSys)}, {"TimeStepSysSec", scalar(h.TimeStepSysSec)},
        {"SysTimeElapsed", scalar(h.SysTimeElapsed)}, {"FracTimeStepZone", scalar(h.FracTimeStepZone)},
        {"FirstTimeStepSysFlag", h.FirstTimeStepSysFlag}, {"ShortenTimeStepSys", h.ShortenTimeStepSys},
        {"UseZoneTimeStepHistory", h.UseZoneTimeStepHistory}, {"NumOfSysTimeSteps", h.NumOfSysTimeSteps},
        {"KickOffSimulation", g.KickOffSimulation}, {"WarmupFlag", g.WarmupFlag},
        {"BeginSimFlag", g.BeginSimFlag}, {"BeginEnvrnFlag", g.BeginEnvrnFlag},
        {"BeginDayFlag", g.BeginDayFlag}, {"BeginHourFlag", g.BeginHourFlag},
        {"BeginTimeStepFlag", g.BeginTimeStepFlag}, {"ZoneSizingCalc", g.ZoneSizingCalc},
        {"SysSizingCalc", g.SysSizingCalc}, {"InsideSurfIterations", state.dataHeatBal->InsideSurfIterations}};
}
// END_ACCEPTED_HELPERS
json weather_copy(EnergyPlus::Weather::WeatherVars const &v)
{
    return {{"IsRain", v.IsRain},
        {"IsSnow", v.IsSnow},
        {"OutDryBulbTemp", scalar(v.OutDryBulbTemp)},
        {"OutDewPointTemp", scalar(v.OutDewPointTemp)},
        {"OutBaroPress", scalar(v.OutBaroPress)},
        {"OutRelHum", scalar(v.OutRelHum)},
        {"WindSpeed", scalar(v.WindSpeed)},
        {"WindDir", scalar(v.WindDir)},
        {"SkyTemp", scalar(v.SkyTemp)},
        {"HorizIRSky", scalar(v.HorizIRSky)},
        {"BeamSolarRad", scalar(v.BeamSolarRad)},
        {"DifSolarRad", scalar(v.DifSolarRad)},
        {"Albedo", scalar(v.Albedo)},
        {"WaterPrecip", scalar(v.WaterPrecip)},
        {"LiquidPrecip", scalar(v.LiquidPrecip)},
        {"TotalSkyCover", scalar(v.TotalSkyCover)},
        {"OpaqueSkyCover", scalar(v.OpaqueSkyCover)}};
}
json daily_copy(EnergyPlus::Weather::DayWeatherVariables const &v)
{
    return {{"DayOfYear", v.DayOfYear},
        {"DayOfYear_Schedule", v.DayOfYear_Schedule},
        {"Year", v.Year},
        {"Month", v.Month},
        {"DayOfMonth", v.DayOfMonth},
        {"DayOfWeek", v.DayOfWeek},
        {"DaylightSavingIndex", v.DaylightSavingIndex},
        {"HolidayIndex", v.HolidayIndex},
        {"SinSolarDeclinAngle", scalar(v.SinSolarDeclinAngle)},
        {"CosSolarDeclinAngle", scalar(v.CosSolarDeclinAngle)},
        {"EquationOfTime", scalar(v.EquationOfTime)}};
}
json input_copy(EnergyPlus::Weather::DesignDayData const &v)
{
    return {{"Title", v.Title},
        {"RainInd", v.RainInd},
        {"SnowInd", v.SnowInd},
        {"DayOfMonth", v.DayOfMonth},
        {"Month", v.Month},
        {"DayType", v.DayType},
        {"DSTIndicator", v.DSTIndicator},
        {"PressureEntered", v.PressureEntered},
        {"DewPointNeedsSet", v.DewPointNeedsSet},
        {"maxWarmupDays", v.maxWarmupDays},
        {"suppressBegEnvReset", v.suppressBegEnvReset},
        {"MaxDryBulb", scalar(v.MaxDryBulb)},
        {"DailyDBRange", scalar(v.DailyDBRange)},
        {"HumIndValue", scalar(v.HumIndValue)},
        {"PressBarom", scalar(v.PressBarom)},
        {"WindSpeed", scalar(v.WindSpeed)},
        {"WindDir", scalar(v.WindDir)},
        {"SkyClear", scalar(v.SkyClear)},
        {"TauB", scalar(v.TauB)},
        {"TauD", scalar(v.TauD)},
        {"DailyWBRange", scalar(v.DailyWBRange)},
        {"HumIndType", static_cast<int>(v.HumIndType)},
        {"solarModel", static_cast<int>(v.solarModel)},
        {"dryBulbRangeType", static_cast<int>(v.dryBulbRangeType)},
        {"tempRangeSched_address", v.tempRangeSched ? json(reinterpret_cast<std::uintptr_t>(v.tempRangeSched)) : json(nullptr)},
        {"humIndSched_address", v.humIndSched ? json(reinterpret_cast<std::uintptr_t>(v.humIndSched)) : json(nullptr)},
        {"beamSolarSched_address", v.beamSolarSched ? json(reinterpret_cast<std::uintptr_t>(v.beamSolarSched)) : json(nullptr)},
        {"diffuseSolarSched_address", v.diffuseSolarSched ? json(reinterpret_cast<std::uintptr_t>(v.diffuseSolarSched)) : json(nullptr)}};
}
json environment_copy(EnergyPlus::Weather::EnvironmentData const &v)
{
    return {{"Title", v.Title},
        {"cKindOfEnvrn", v.cKindOfEnvrn},
        {"DesignDayNum", v.DesignDayNum},
        {"RunPeriodDesignNum", v.RunPeriodDesignNum},
        {"SeedEnvrnNum", v.SeedEnvrnNum},
        {"HVACSizingIterationNum", v.HVACSizingIterationNum},
        {"TotalDays", v.TotalDays},
        {"StartJDay", v.StartJDay},
        {"StartMonth", v.StartMonth},
        {"StartDay", v.StartDay},
        {"StartYear", v.StartYear},
        {"StartDate", v.StartDate},
        {"EndMonth", v.EndMonth},
        {"EndDay", v.EndDay},
        {"EndJDay", v.EndJDay},
        {"EndYear", v.EndYear},
        {"EndDate", v.EndDate},
        {"DayOfWeek", v.DayOfWeek},
        {"UseDST", v.UseDST},
        {"UseHolidays", v.UseHolidays},
        {"ApplyWeekendRule", v.ApplyWeekendRule},
        {"UseRain", v.UseRain},
        {"UseSnow", v.UseSnow},
        {"SetWeekDays", v.SetWeekDays},
        {"NumSimYears", v.NumSimYears},
        {"CurrentCycle", v.CurrentCycle},
        {"WP_Type1", v.WP_Type1},
        {"UseWeatherFileHorizontalIR", v.UseWeatherFileHorizontalIR},
        {"CurrentYear", v.CurrentYear},
        {"IsLeapYear", v.IsLeapYear},
        {"RollDayTypeOnRepeat", v.RollDayTypeOnRepeat},
        {"TreatYearsAsConsecutive", v.TreatYearsAsConsecutive},
        {"MatchYear", v.MatchYear},
        {"ActualWeather", v.ActualWeather},
        {"RawSimDays", v.RawSimDays},
        {"firstHrInterpUseHr1", v.firstHrInterpUseHr1},
        {"maxCoolingOATSizing", scalar(v.maxCoolingOATSizing)},
        {"maxCoolingOADPSizing", scalar(v.maxCoolingOADPSizing)},
        {"minHeatingOATSizing", scalar(v.minHeatingOATSizing)},
        {"minHeatingOADPSizing", scalar(v.minHeatingOADPSizing)},
        {"KindOfEnvrn", static_cast<int>(v.KindOfEnvrn)},
        {"skyTempModel", static_cast<int>(v.skyTempModel)}};
}
template<class T> json mods_copy(T const &v) {
    return {{"OutDryBulbTemp",scalar(v.OutDryBulbTemp)},{"OutRelHum",scalar(v.OutRelHum)},
        {"BeamSolarRad",scalar(v.BeamSolarRad)},{"DifSolarRad",scalar(v.DifSolarRad)},{"SkyTemp",scalar(v.SkyTemp)}};
}
template<class Values, class Copy> json matrix_copy(Values const &v, Copy copy) {
    json result{{"allocated",v.allocated()},{"size",v.size()},{"lower1",v.l1()},{"upper1",v.u1()},
        {"lower2",v.l2()},{"upper2",v.u2()},{"size1",v.size1()},{"size2",v.size2()},
        {"object_address",reinterpret_cast<std::uintptr_t>(&v)},
        {"storage_address",v.data()?json(reinterpret_cast<std::uintptr_t>(v.data())):json(nullptr)},
        {"rows",json::array()}};
    if(v.allocated()) for(int hour=v.l2(); hour<=v.u2(); ++hour)
        for(int step=v.l1(); step<=v.u1(); ++step)
            result["rows"].push_back({{"hour",hour},{"timestep",step},{"value",copy(v(step,hour))}});
    return result;
}
template<class Values, class Copy> json ep_vector_copy(Values const &v, Copy copy) {
    json result{{"allocated",v.allocated()},{"size",v.isize()},
        {"object_address",reinterpret_cast<std::uintptr_t>(&v)},{"rows",json::array()}};
    if(v.allocated()) for(int i=1;i<=v.isize();++i)
        result["rows"].push_back({{"index",i},{"value",copy(v(i))}});
    return result;
}
template<class Values, class Copy> json array_copy(Values const &v, Copy copy) {
    json result{{"allocated",v.allocated()},{"size",v.size()},{"lower",v.l()},{"upper",v.u()},
        {"object_address",reinterpret_cast<std::uintptr_t>(&v)},
        {"storage_address",v.data()?json(reinterpret_cast<std::uintptr_t>(v.data())):json(nullptr)},
        {"rows",json::array()}};
    if(v.allocated()) for(int i=v.l();i<=v.u();++i)
        result["rows"].push_back({{"index",i},{"value",copy(v(i))}});
    return result;
}
json predefined_copy(EnergyPlus::EnergyPlusData const &state) {
    auto const &p=*state.dataOutRptPredefined;
    return {{"sizeReportName",p.sizeReportName},{"numReportName",p.numReportName},
        {"sizeSubTable",p.sizeSubTable},{"numSubTable",p.numSubTable},
        {"sizeColumnTag",p.sizeColumnTag},{"numColumnTag",p.numColumnTag},
        {"sizeTableEntry",p.sizeTableEntry},{"numTableEntry",p.numTableEntry},
        {"pdchDDmaxDB",p.pdchDDmaxDB},{"pdchDDrange",p.pdchDDrange},{"pdchDDhumid",p.pdchDDhumid},
        {"pdchDDhumTyp",p.pdchDDhumTyp},{"pdchDDwindSp",p.pdchDDwindSp},{"pdchDDwindDr",p.pdchDDwindDr},
        {"reportName",array_copy(p.reportName,[](auto const &v){return json{
            {"name",v.name},{"namewithspaces",v.namewithspaces},{"abrev",v.abrev},{"show",v.show}};})},
        {"subTable",array_copy(p.subTable,[](auto const &v){return json{
            {"name",v.name},{"indexReportName",v.indexReportName},{"footnote",v.footnote}};})},
        {"columnTag",array_copy(p.columnTag,[](auto const &v){return json{
            {"heading",v.heading},{"indexSubTable",v.indexSubTable}};})},
        {"tableEntry",array_copy(p.tableEntry,[](auto const &v){return json{
            {"charEntry",v.charEntry},{"objectName",v.objectName},{"indexColumn",v.indexColumn},
            {"subTableIndex",v.subTableIndex},{"uniqueObjName",v.uniqueObjName},
            {"origRealEntry",scalar(v.origRealEntry)},{"significantDigits",v.significantDigits},
            {"origEntryIsReal",v.origEntryIsReal}};})}};
}
template<class Values> json cube_copy(Values const &v) {
    json result{{"allocated",v.allocated()},{"size",v.size()},
        {"lower1",v.l1()},{"upper1",v.u1()},{"size1",v.size1()},
        {"lower2",v.l2()},{"upper2",v.u2()},{"size2",v.size2()},
        {"lower3",v.l3()},{"upper3",v.u3()},{"size3",v.size3()},
        {"object_address",reinterpret_cast<std::uintptr_t>(&v)},
        {"storage_address",v.data()?json(reinterpret_cast<std::uintptr_t>(v.data())):json(nullptr)},
        {"rows",json::array()}};
    if(v.allocated()) for(int k=v.l3();k<=v.u3();++k) for(int j=v.l2();j<=v.u2();++j)
        for(int i=v.l1();i<=v.u1();++i)
            result["rows"].push_back({{"index1",i},{"index2",j},{"index3",k},{"value",scalar(v(i,j,k))}});
    return result;
}
json shading_copy(EnergyPlus::EnergyPlusData const &state) {
    auto const &s=*state.dataSolarShading;
    auto const &h=*state.dataHeatBal;
    auto const &d=*state.dataSurface;
    json result{{"TotSurfaces",d.TotSurfaces},{"ShadowingDaysLeft",s.ShadowingDaysLeft},
        {"ShadowingCalcFrequency",s.ShadowingCalcFrequency},{"InitComplexOnce",s.InitComplexOnce},
        {"firstTime",s.firstTime},{"CalcSkyDifShading",s.CalcSkyDifShading},
        {"Surface",ep_vector_copy(d.Surface,[](auto const &v){return json{
            {"Name",v.Name},{"Zone",v.Zone},{"spaceNum",v.spaceNum},
            {"HeatTransSurf",v.HeatTransSurf},{"ExtSolar",v.ExtSolar},{"ExtBoundCond",v.ExtBoundCond},
            {"Area",scalar(v.Area)},{"ViewFactorSky",scalar(v.ViewFactorSky)},
            {"ViewFactorGround",scalar(v.ViewFactorGround)},{"ViewFactorSkyIR",scalar(v.ViewFactorSkyIR)},
            {"ViewFactorGroundIR",scalar(v.ViewFactorGroundIR)},
            {"OutNormVec",{scalar(v.OutNormVec.x),scalar(v.OutNormVec.y),scalar(v.OutNormVec.z)}},
            {"SinTilt",scalar(v.SinTilt)},{"CosTilt",scalar(v.CosTilt)},
            {"SinAzim",scalar(v.SinAzim)},{"CosAzim",scalar(v.CosAzim)}};})},
        {"SurfSunCosTheta",array_copy(s.SurfSunCosTheta,[](double v){return scalar(v);})},
        {"SurfSunlitArea",array_copy(s.SurfSunlitArea,[](double v){return scalar(v);})},
        {"SurfAnisoSkyMult",array_copy(s.SurfAnisoSkyMult,[](double v){return scalar(v);})},
        {"SurfMultIsoSky",array_copy(s.SurfMultIsoSky,[](double v){return scalar(v);})},
        {"SurfMultCircumSolar",array_copy(s.SurfMultCircumSolar,[](double v){return scalar(v);})},
        {"SurfMultHorizonZenith",array_copy(s.SurfMultHorizonZenith,[](double v){return scalar(v);})},
        {"SurfDifShdgRatioIsoSky",array_copy(s.SurfDifShdgRatioIsoSky,[](double v){return scalar(v);})},
        {"SurfCurDifShdgRatioIsoSky",array_copy(s.SurfCurDifShdgRatioIsoSky,[](double v){return scalar(v);})},
        {"SurfDifShdgRatioHoriz",array_copy(s.SurfDifShdgRatioHoriz,[](double v){return scalar(v);})},
        {"SurfWithShdgIsoSky",array_copy(s.SurfWithShdgIsoSky,[](double v){return scalar(v);})},
        {"SurfWoShdgIsoSky",array_copy(s.SurfWoShdgIsoSky,[](double v){return scalar(v);})},
        {"SurfWithShdgHoriz",array_copy(s.SurfWithShdgHoriz,[](double v){return scalar(v);})},
        {"SurfWoShdgHoriz",array_copy(s.SurfWoShdgHoriz,[](double v){return scalar(v);})},
        {"SurfDifShdgRatioIsoSkyHRTS",cube_copy(s.SurfDifShdgRatioIsoSkyHRTS)},
        {"SurfDifShdgRatioHorizHRTS",cube_copy(s.SurfDifShdgRatioHorizHRTS)},
        {"SurfCosIncAng",cube_copy(h.SurfCosIncAng)},{"SurfSunlitFrac",cube_copy(h.SurfSunlitFrac)}};
    return result;
}
json full_weather(EnergyPlus::EnergyPlusData const &state) {
    auto const &w=*state.dataWeather;
    auto const &e=*state.dataEnvrn;
    auto const &g=*state.dataGlobal;
    json environment= array_copy(w.Environment,environment_copy);
    if(w.Environment.allocated()) for(auto &row:environment["rows"])
        row["value"]["MonWeekDay"]=array_copy(w.Environment(row["index"].get<int>()).MonWeekDay,[](int v){return json(v);});
    json result{{"Environment",environment},
        {"DesDayInput",ep_vector_copy(w.DesDayInput,input_copy)},
        {"DesignDay",ep_vector_copy(w.DesignDay,daily_copy)},
        {"desDayMods",ep_vector_copy(w.desDayMods,[](auto const &v){return matrix_copy(v,[](auto const &x){return mods_copy(x);});})},
        {"spSiteSchedules",ep_vector_copy(w.spSiteSchedules,[](auto const &v){return mods_copy(v);})},
        {"TodayVariables",daily_copy(w.TodayVariables)},{"TomorrowVariables",daily_copy(w.TomorrowVariables)},
        {"wvarsHrTsToday",matrix_copy(w.wvarsHrTsToday,weather_copy)},
        {"wvarsHrTsTomorrow",matrix_copy(w.wvarsHrTsTomorrow,weather_copy)},
        {"Interpolation",array_copy(w.Interpolation,[](double v){return scalar(v);})},
        {"SolarInterpolation",array_copy(w.SolarInterpolation,[](double v){return scalar(v);})},
        {"TimeStepFraction",scalar(w.TimeStepFraction)},
        {"Envrn",w.Envrn},{"NumOfEnvrn",w.NumOfEnvrn},{"TotDesDays",e.TotDesDays},
        {"ReverseDD",state.dataSysVars->ReverseDD},{"DoWeatherInitReporting",state.dataReportFlag->DoWeatherInitReporting},
        {"FirstCall",w.FirstCall},{"GetEnvironmentFirstCall",w.GetEnvironmentFirstCall},
        {"PrintDDHeader",w.PrintDDHeader},{"PrintEnvrnStamp",w.PrintEnvrnStamp},
        {"UseRainValues",w.UseRainValues},{"UseSnowValues",w.UseSnowValues},
        {"NextHour",w.NextHour},{"PreviousHour",g.PreviousHour},{"SimTimeSteps",g.SimTimeSteps},
        {"TimeStepsInHour",g.TimeStepsInHour},{"EndEnvrnFlag",g.EndEnvrnFlag},{"EndDayFlag",g.EndDayFlag},
        {"EndHourFlag",g.EndHourFlag},{"EndDesignDayEnvrnsFlag",g.EndDesignDayEnvrnsFlag},
        {"DoDesDaySim",g.DoDesDaySim},{"DoWeathSim",g.DoWeathSim},{"KickOffSizing",g.KickOffSizing},
        {"DayOfYear",e.DayOfYear},{"DayOfYear_Schedule",e.DayOfYear_Schedule},{"DayOfWeek",e.DayOfWeek},
        {"HolidayIndex",e.HolidayIndex},{"DSTIndicator",e.DSTIndicator},{"Year",e.Year},
        {"RunPeriodEnvironment",e.RunPeriodEnvironment},{"EndMonthFlag",e.EndMonthFlag},
        {"CurMnDy",e.CurMnDy},{"EnvironmentStartEnd",e.EnvironmentStartEnd},
        {"EndYearFlag",e.EndYearFlag},{"PreviousSolRadPositive",e.PreviousSolRadPositive},
        {"site",json::object()},{"current",json::object()},{"weather_solar",json::object()}};
    result["site"]["Latitude"]=scalar(e.Latitude);
    result["site"]["Longitude"]=scalar(e.Longitude);
    result["site"]["TimeZoneNumber"]=scalar(e.TimeZoneNumber);
    result["site"]["TimeZoneMeridian"]=scalar(e.TimeZoneMeridian);
    result["site"]["Elevation"]=scalar(e.Elevation);
    result["site"]["SinLatitude"]=scalar(e.SinLatitude);
    result["site"]["CosLatitude"]=scalar(e.CosLatitude);
    result["site"]["StdBaroPress"]=scalar(e.StdBaroPress);
    result["site"]["TS1TimeOffset"]=scalar(e.TS1TimeOffset);
    result["site"]["IgnoreSolarRadiation"]=e.IgnoreSolarRadiation;
    result["site"]["IgnoreBeamRadiation"]=e.IgnoreBeamRadiation;
    result["site"]["IgnoreDiffuseRadiation"]=e.IgnoreDiffuseRadiation;
    result["site"]["DisplayWeatherMissingDataWarnings"]=e.DisplayWeatherMissingDataWarnings;
    result["current"]["OutDryBulbTemp"]=scalar(e.OutDryBulbTemp);
    result["current"]["OutDewPointTemp"]=scalar(e.OutDewPointTemp);
    result["current"]["OutBaroPress"]=scalar(e.OutBaroPress);
    result["current"]["OutRelHum"]=scalar(e.OutRelHum);
    result["current"]["OutRelHumValue"]=scalar(e.OutRelHumValue);
    result["current"]["OutHumRat"]=scalar(e.OutHumRat);
    result["current"]["OutWetBulbTemp"]=scalar(e.OutWetBulbTemp);
    result["current"]["WindSpeed"]=scalar(e.WindSpeed);
    result["current"]["WindDir"]=scalar(e.WindDir);
    result["current"]["LiquidPrecipitation"]=scalar(e.LiquidPrecipitation);
    result["current"]["BeamSolarRad"]=scalar(e.BeamSolarRad);
    result["current"]["DifSolarRad"]=scalar(e.DifSolarRad);
    result["current"]["GndSolarRad"]=scalar(e.GndSolarRad);
    result["current"]["GndReflectance"]=scalar(e.GndReflectance);
    result["current"]["GndReflectanceForDayltg"]=scalar(e.GndReflectanceForDayltg);
    result["current"]["SkyTemp"]=scalar(e.SkyTemp);
    result["current"]["SkyTempKelvin"]=scalar(e.SkyTempKelvin);
    result["current"]["TotalCloudCover"]=scalar(e.TotalCloudCover);
    result["current"]["OpaqueCloudCover"]=scalar(e.OpaqueCloudCover);
    result["current"]["OutEnthalpy"]=scalar(e.OutEnthalpy);
    result["current"]["OutAirDensity"]=scalar(e.OutAirDensity);
    result["current"]["IsRain"]=e.IsRain;
    result["current"]["IsSnow"]=e.IsSnow;
    result["current"]["SunIsUp"]=e.SunIsUp;
    result["current"]["SunIsUpPrevTS"]=e.SunIsUpPrevTS;
    result["current"]["SOLCOS"]={scalar(e.SOLCOS.x),scalar(e.SOLCOS.y),scalar(e.SOLCOS.z)};
    result["weather_solar"]["HrAngle"]=scalar(w.HrAngle);
    result["weather_solar"]["SolarAltitudeAngle"]=scalar(w.SolarAltitudeAngle);
    result["weather_solar"]["SolarAzimuthAngle"]=scalar(w.SolarAzimuthAngle);
    result["weather_solar"]["HorizIRSky"]=scalar(w.HorizIRSky);
    result["weather_solar"]["SnowGndRefModifier"]=scalar(w.SnowGndRefModifier);
    result["weather_solar"]["SnowGndRefModifierForDayltg"]=scalar(w.SnowGndRefModifierForDayltg);
    result["weather_solar"]["GroundReflectances"]=array_copy(w.GroundReflectances,[](double v){return scalar(v);});
    result["weather_solar"]["RptIsRain"]=w.RptIsRain;
    result["weather_solar"]["RptIsSnow"]=w.RptIsSnow;
    return result;
}
bool selected() noexcept {
    if(!current_scope || !current_scope->state) return false;
    auto const p=current_scope->procedure;
    auto const &g=*current_scope->state->dataGlobal;
    return p==Procedure::GetDesignDayData || p==Procedure::GetNextEnvironment || p==Procedure::SetUpDesignDay
        || p==Procedure::SetupSimulation || g.KickOffSimulation
        || g.KindOfSim==EnergyPlus::Constant::KindOfSim::DesignDay
        || (p==Procedure::ManageWeather && current_scope->non_kickoff_manage_weather_ordinal>0
            && current_scope->non_kickoff_manage_weather_ordinal<=2);
}
void emit(char const *checkpoint, int const *year=nullptr, int input_ordinal=0,
          int environment_ordinal=0, std::string const *name=nullptr) noexcept {
    if(!active || !selected()) return;
    if(!increment(active->attempted_events)) return;
    auto const ordinal=active->attempted_events;
    try {
        json locals=json::object();
        if(year) locals["actual_CurrentYear"]=*year;
        if(name) locals={{"iDesDay",input_ordinal},{"EnvrnNum",environment_ordinal},{"actual_getObjectItem_name",*name}};
        if(current_scope->actual_errors_found) locals["actual_ErrorsFound"]=*current_scope->actual_errors_found;
        if(current_scope->actual_available) locals["actual_Available"]=*current_scope->actual_available;
        json event{{"event_ordinal",ordinal},{"checkpoint",checkpoint},
            {"design_day_protocol","src06-ordinary-design-day-native.v1"},
            {"procedure",procedure_name(current_scope->procedure)},{"invocation_ordinal",current_scope->ordinal},
            {"parent_procedure",current_scope->parent?json(procedure_name(current_scope->parent->procedure)):json(nullptr)},
            {"parent_invocation_ordinal",current_scope->parent?json(current_scope->parent->ordinal):json(nullptr)},
            {"clock",clock(*current_scope->state)},{"locals",locals},
            {"setup_role",current_role?json(current_role):json(nullptr)},
            {"actual_setup_call_ordinal",current_role?json(current_setup_ordinal):json(nullptr)},
            {"weather",full_weather(*current_scope->state)},
            {"actual_non_kickoff_manage_weather_ordinal",current_scope->non_kickoff_manage_weather_ordinal},
            {"predefined_reports",current_scope->procedure==Procedure::GetDesignDayData?predefined_copy(*current_scope->state):json(nullptr)},
            {"solar_shading",current_scope->procedure==Procedure::ManageWeather?shading_copy(*current_scope->state):json(nullptr)},
            {"counted_as_PASS",false}};
        if(!active->first_event) active->output<<',';
        active->output<<event.dump();
        if(!active->output) { active->stream_failed=true; increment(active->stream_failed_events); return; }
        active->first_event=false;
        increment(active->retained_events);
    } catch(...) {
        increment(active->copy_failures);
        if(active->first_failed_event==0) active->first_failed_event=ordinal;
        active->last_failed_event=ordinal;
    }
}
} // namespace
Binding::Binding(Capture &capture) noexcept:previous(active) {active=&capture;}
Binding::~Binding() noexcept {active=previous;}
Scope::Scope(EnergyPlus::EnergyPlusData const *actual_state,Procedure p,bool const *errors,bool const *available) noexcept
    :procedure(p),parent(current_scope),state(actual_state?actual_state:(parent?parent->state:nullptr)),
     state_from_actual_parent(actual_state==nullptr && parent && parent->state),actual_errors_found(errors),
     actual_available(available),exceptions_on_entry(std::uncaught_exceptions()) {
    current_scope=this;
    if(active && increment(active->procedure_calls[static_cast<unsigned>(procedure)])) ordinal=active->procedure_calls[static_cast<unsigned>(procedure)];
    if(active && procedure==Procedure::ManageWeather && state && !state->dataGlobal->KickOffSimulation
       && increment(active->non_kickoff_manage_weather_calls))
        non_kickoff_manage_weather_ordinal=active->non_kickoff_manage_weather_calls;
    emit("procedure_entry");
}
Scope::~Scope() noexcept {
    bool const unwind=std::uncaught_exceptions()>exceptions_on_entry;
    if(active) increment((unwind?active->scope_unwinds:active->scope_normal_exits)[static_cast<unsigned>(procedure)]);
    emit(unwind?"procedure_unwind":"procedure_return");
    current_scope=parent;
}
SetupCall::SetupCall(EnergyPlus::EnergyPlusData const &state,char const *role) noexcept
    :previous_role(current_role),previous_ordinal(current_setup_ordinal),exceptions_on_entry(std::uncaught_exceptions()) {
    (void)state;
    current_role=role;
    if(active && increment(active->setup_calls)) current_setup_ordinal=active->setup_calls;
    emit("setup_call_entry");
}
SetupCall::~SetupCall() noexcept {
    emit(std::uncaught_exceptions()>exceptions_on_entry?"setup_call_unwind":"setup_call_return");
    current_role=previous_role;
    current_setup_ordinal=previous_ordinal;
}
void record_local_year(int year) noexcept {emit("local_year_resolved",&year);}
void record_input_order(int input_ordinal,int environment_ordinal,std::string const &name) noexcept {
    emit("input_object_order",nullptr,input_ordinal,environment_ordinal,&name);
}
bool finish(Capture &capture,bool returned,int code,char const *caught) noexcept {
    try {
        json names=json::array();
        for(unsigned i=0;i<static_cast<unsigned>(Procedure::Count);++i) names.push_back(procedure_name(static_cast<Procedure>(i)));
        json summary{{"design_day_protocol","src06-ordinary-design-day-native.v1"},
            {"capture_selection","all-DD-getter-and-producer-calls-and-every-actual-kickoff-weather-boundary-plus-first-two-actual-nonkickoff-ManageWeather; all-eight-procedure-counters"},
            {"normal_later_RunPeriod_full_payload_captured",false},
            {"actual_engine_entry_returned",returned},{"actual_engine_exit_code",returned?json(code):json(nullptr)},
            {"outer_caught_exception_class",caught?json(caught):json(nullptr)},
            {"procedure_names",names},{"procedure_calls",capture.procedure_calls},
            {"scope_normal_exits",capture.scope_normal_exits},{"scope_unwinds",capture.scope_unwinds},
            {"setup_calls",capture.setup_calls},{"non_kickoff_manage_weather_calls",capture.non_kickoff_manage_weather_calls},
            {"attempted_events",capture.attempted_events},
            {"retained_events",capture.retained_events},{"copy_failures",capture.copy_failures},
            {"first_failed_event",capture.first_failed_event},{"last_failed_event",capture.last_failed_event},
            {"stream_failed_events",capture.stream_failed_events},{"counter_overflow",capture.counter_overflow},
            {"stream_failed",capture.stream_failed},{"observer_invokes_producer",false},
            {"ordinary_activation_or_whole_weather_parity_claimed",false},{"integration_PASS_claimed",false}};
        capture.output<<"],\"summary\":"<<summary.dump()<<'}';
        capture.output.flush();
        return static_cast<bool>(capture.output) && !capture.stream_failed && !capture.counter_overflow && capture.copy_failures==0;
    } catch(...) {return false;}
}
} // namespace SurfaceConsumerObservation

from pathlib import Path
import hashlib
import json
root=Path(__file__).resolve().parents[3]
path=root/'.runtime/porting/SRC-06/ordinary-design-day-raw-comparison-prep-Header-01/manifest.json'
if hashlib.sha256(path.read_bytes()).hexdigest()!='ef9a5e935a8ce2963f72d7a38932ef24a1f4f01e150fe726f2f99e27ad6d09a1':raise RuntimeError('manifestchanged')
manifest=json.loads(path.read_bytes())
for row in manifest['changes']:
    target=root/row['canonical_path']
    base=target.read_bytes()if target.exists()else b''
    if hashlib.sha256(base).hexdigest()!=row['base']['sha256']:raise RuntimeError('basechanged '+str(target))
    proposal=(root/row['proposed']['path']).read_bytes()
    if hashlib.sha256(proposal).hexdigest()!=row['proposed']['sha256']:raise RuntimeError('proposalchanged')
for row in manifest['changes']:
    (root/row['canonical_path']).write_bytes((root/row['proposed']['path']).read_bytes())
print('Applied reviewed raw DD regression in one existing test body.')

//! One finite Native comparison consumed by the existing lifecycle regression.

use super::{ProductionWeatherTimestepSeries, SetupSimulationControls, SetupSimulationRole};
use crate::heat_balance::ctf_initialization_context::CtfInitializationReports;
use crate::weather::day::{DesignDayHumidity, DesignDayInput, DesignDayParameters};
use chrono::{Datelike, Local};
use ep_model::FirstHourInterpolationStartingValues;
use serde_json::Value;

#[path = "design_day_native_state_tests.rs"]
mod state;

type TestResult = Result<(), Box<dyn std::error::Error>>;

pub(crate) fn verify_actual_design_day_weather() -> TestResult {
    let fixture: Value =
        serde_json::from_str(include_str!("fixtures/ordinary_design_day_native.json"))?;
    assert_eq!(
        fixture["schema"],
        "src06-actual-design-day-weather-fixture.v1"
    );
    let mut config = super::super::lifecycle_tests::configuration(
        6,
        30,
        7,
        2,
        FirstHourInterpolationStartingValues::Hour24,
    )?;
    // These are the pinned A-24H input operands, not Native calculated outputs.
    // The decoy EPW supplies header transport only; DD must consume no EPW rows.
    config.site.elevation_m = 1829.0;
    config.design_day_count = 2;
    config.setup_simulation_controls = Some(SetupSimulationControls::from_admitted_input_flags(
        false, false, false, false, false, true,
    ));
    for (name, month, day_type, db, range, wb, speed, direction, clearness) in [
        (
            "DENVER CENTENNIAL  GOLDEN   N ANN HTG 99% CONDNS DB",
            12,
            10,
            -15.5,
            0.0,
            -15.5,
            3.0,
            340.0,
            0.0,
        ),
        (
            "DENVER CENTENNIAL  GOLDEN   N ANN CLG 1% CONDNS DB=>MWB",
            7,
            9,
            32.0,
            15.2,
            15.5,
            4.9,
            0.0,
            1.0,
        ),
    ] {
        config
            .design_days
            .push(DesignDayInput::from_selected_parameters(
                DesignDayParameters {
                    name: name.into(),
                    month,
                    day_of_month: 21,
                    day_type,
                    maximum_dry_bulb: db,
                    daily_dry_bulb_range: range,
                    humidity_type: DesignDayHumidity::WetBulb,
                    humidity_indicator: wb,
                    barometric_pressure: Some(81198.0),
                    wind_speed: speed,
                    wind_direction: direction,
                    rain: false,
                    snow: false,
                    daylight_saving: false,
                    sky_clearness: clearness,
                    maximum_warmup_days: -1,
                },
                4,
            )?);
    }
    let series = ProductionWeatherTimestepSeries::from_bytes(
        super::super::lifecycle_tests::DECOY_BYTES.to_vec(),
        config,
    )?;
    let mut reports = CtfInitializationReports::default();
    reports
        .registry
        .set_predefined_tables(false, false)
        .map_err(|error| format!("real early registry: {error:?}"))?;
    series.begin_setup_simulation()?;
    series.reset_setup_environment_counter();
    let events = fixture["design_day_manage_weather_returns"]
        .as_array()
        .ok_or("DD calls")?;
    assert_eq!(events.len(), 6);
    let initial = series.snapshot();
    let mut ordinal = 0;
    let mut initialized_years = [0; 2];
    for environment in 1..=2 {
        assert_eq!(series.next_setup_environment(&mut reports)?, (true, false));
        if environment == 1 {
            verify_reports(&reports, &fixture)?;
        }
        for role in [
            SetupSimulationRole::FirstHour,
            SetupSimulationRole::RepeatedFirstHour,
            SetupSimulationRole::LastHour,
        ] {
            ordinal += 1;
            let native = &events[ordinal - 1];
            assert_eq!(native["actual_setup_call_ordinal"], ordinal);
            assert_eq!(native["setup_role"], format!("{role:?}"));
            series.prepare_setup_call(role);
            let year_before = Local::now().year();
            let call = series.manage_setup_weather(ordinal as u64, role, true, false, false)?;
            let year_after = Local::now().year();
            // date_and_time is a live external input. Future runs must obtain the
            // actual local year, never replay the captured year into production.
            if role == SetupSimulationRole::FirstHour {
                assert!([year_before, year_after].contains(&call.daily.year));
                initialized_years[environment - 1] = call.daily.year;
            }
            assert_eq!(call.daily.year, initialized_years[environment - 1]);
            assert_eq!(call.ordinal, ordinal as u64);
            assert_eq!(call.environment_number, environment as i32);
            assert_eq!(call.environment_name, native["clock"]["environment_name"]);
            assert_eq!(series.setup_environment_name(), call.environment_name);
            assert_eq!(
                Some(call.kickoff_simulation),
                native["clock"]["KickOffSimulation"].as_bool()
            );
            assert_eq!(
                Some(call.kickoff_sizing),
                native["weather"]["KickOffSizing"].as_bool()
            );
            assert_eq!(
                Some(call.do_weather_init_reporting),
                native["weather"]["DoWeatherInitReporting"].as_bool()
            );
            let snapshot = series.snapshot();
            state::verify(&snapshot.state, native, ordinal)?;
            state::site_and_solar(&snapshot.state, native, -7.0)?;
            verify_design_day_owners(&series, &native["weather"], &initialized_years)?;
            assert_eq!(snapshot.interpret_count, initial.interpret_count);
            assert_eq!(snapshot.line_read_count, initial.line_read_count);
            if role == SetupSimulationRole::FirstHour {
                series.finish_first_setup_call();
            }
        }
    }
    // Do not enter the real RunPeriod with the unrelated decoy weather file.
    // Exterior/HB/full Setup are separate consumers and are not claimed here.
    let mismatches = BIT_DIAGNOSTIC.with_borrow(|values| values.clone());
    if !mismatches.is_empty() {
        for (name, (count, max_absolute)) in mismatches {
            eprintln!(
                "strict-bit diagnostic {name}: {count} differences; maximum absolute {max_absolute:e}"
            );
        }
        return Err("strict-bit diagnostic found differences; no numerical parity claimed".into());
    }
    Ok(())
}

fn verify_design_day_owners(
    series: &ProductionWeatherTimestepSeries,
    native: &Value,
    initialized_years: &[i32; 2],
) -> TestResult {
    let session = series.session.borrow();
    for (index, input) in session.configuration.design_days.iter().enumerate() {
        let raw = &native["DesDayInput"]["rows"][index]["value"];
        assert_eq!(input.name(), raw["Title"]);
        real(
            input.resolved_pressure(),
            &raw["PressBarom"],
            "DesDayInput.PressBarom",
        )?;
        state::daily(
            input.daily_variables(),
            &native["DesignDay"]["rows"][index]["value"],
            initialized_years[index],
        )?;
        let modifiers = native["desDayMods"]["rows"][index]["value"]["rows"]
            .as_array()
            .ok_or("mods")?;
        assert_eq!(modifiers.len(), input.dry_bulb_modifiers().len());
        for (actual, expected) in input.dry_bulb_modifiers().iter().zip(modifiers) {
            real(
                *actual,
                &expected["value"]["OutDryBulbTemp"],
                "desDayMods.OutDryBulbTemp",
            )?;
        }
        let schedules = &native["spSiteSchedules"]["rows"][index]["value"];
        for (actual, name) in input.site_schedule_values().iter().zip([
            "OutDryBulbTemp",
            "OutRelHum",
            "BeamSolarRad",
            "DifSolarRad",
            "SkyTemp",
        ]) {
            real(*actual, &schedules[name], "spSiteSchedules")?;
        }
    }
    Ok(())
}

fn verify_reports(reports: &CtfInitializationReports, fixture: &Value) -> TestResult {
    let native = &fixture["get_design_day_data"][1]["predefined_reports"];
    for (key, value) in fixture["six_predefined_column_ids"]
        .as_object()
        .ok_or("columns")?
    {
        assert_eq!(
            reports
                .registry
                .named_indices
                .get(key)
                .copied()
                .map(i64::from),
            value.as_i64()
        );
    }
    assert_eq!(
        Some(i64::from(reports.table.num_table_entry)),
        native["numTableEntry"].as_i64()
    );
    assert_eq!(
        Some(i64::from(reports.table.size_table_entry)),
        native["sizeTableEntry"].as_i64()
    );
    let entries = reports
        .table
        .entries
        .as_ref()
        .ok_or("real table allocation")?;
    let rows = native["tableEntry"]["rows"]
        .as_array()
        .ok_or("Native table rows")?;
    assert_eq!(entries.len(), rows.len());
    for (actual, row) in entries.iter().zip(rows) {
        let expected = &row["value"];
        assert_eq!(actual.char_entry, expected["charEntry"]);
        assert_eq!(actual.object_name, expected["objectName"]);
        assert_eq!(
            Some(i64::from(actual.index_column)),
            expected["indexColumn"].as_i64()
        );
        assert_eq!(
            Some(i64::from(actual.sub_table_index)),
            expected["subTableIndex"].as_i64()
        );
        assert_eq!(
            Some(i64::from(actual.unique_object_name)),
            expected["uniqueObjName"].as_i64()
        );
        assert_eq!(
            Some(i64::from(actual.significant_digits)),
            expected["significantDigits"].as_i64()
        );
        assert_eq!(
            Some(actual.original_entry_is_real),
            expected["origEntryIsReal"].as_bool()
        );
        real(
            actual.original_real_entry,
            &expected["origRealEntry"],
            "table.origRealEntry",
        )?;
    }
    Ok(())
}

fn real(actual: f64, native: &Value, name: &str) -> TestResult {
    let bits = u64::from_str_radix(
        native["value_bits"]
            .as_str()
            .ok_or_else(|| format!("missing bits {name}: {native}"))?,
        16,
    )?;
    let expected = f64::from_bits(bits);
    if actual.to_bits() != bits {
        assert_eq!(
            actual.is_finite(),
            expected.is_finite(),
            "{name} IEEE class"
        );
        assert_eq!(actual == 0.0, expected == 0.0, "{name} zero class");
        let key = name.rsplit('.').next().ok_or("field name")?.to_owned();
        BIT_DIAGNOSTIC.with_borrow_mut(|values| {
            let item = values.entry(key).or_insert((0, 0.0));
            item.0 += 1;
            item.1 = item.1.max((actual - expected).abs());
        });
    }
    Ok(())
}

thread_local! {
    // Temporary strict comparison diagnostic; final numerical policy is reviewed
    // against the already-frozen contracts before this unit can be released.
    static BIT_DIAGNOSTIC: std::cell::RefCell<std::collections::BTreeMap<String, (usize, f64)>> = const { std::cell::RefCell::new(std::collections::BTreeMap::new()) };
}

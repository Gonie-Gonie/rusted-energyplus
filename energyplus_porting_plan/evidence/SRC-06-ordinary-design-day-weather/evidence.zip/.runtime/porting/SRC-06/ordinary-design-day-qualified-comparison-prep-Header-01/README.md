# Held DesignDay scoped regression successor

One existing helper changes; no new test, framework, binary or production math. All old call, clock, input/default, report, owner, array shape and index assertions remain. Today/Tomorrow copies are additionally checked against Rust's own complete carrier bits, which does not imply that computed Native endpoints are bit-identical.

The genuine strict-bit diagnostic02 remains FAIL. Five caller outputs use only the already frozen PSY-01/02 numerical bounds. This is a caller-output assessment; absent intermediate/cache input observations prevent a paired PSY/cache PASS. Eight explicitly named RH/sky/solar outputs are UNPAIRED even when bits happen to agree. They retain finite/class/signed-zero assertions and counted differences without any magnitude PASS threshold. Unknown names fail closed.

Other explicitly named real comparisons remain bit-exact. No libm attribution, all-weather numerical parity, downstream HB writes, full Setup or port gate is claimed. Classification and exact transport/default scope can pass independently of unresolved computed-output parity. The metadata scope is part of the reviewable contract; it must accompany any reported test PASS.

The before file is actual read-time canonical Source, not a launch-time custody claim. This author emitted held files only and performed no Rust/Native execution. Parent owns application/format/validation.

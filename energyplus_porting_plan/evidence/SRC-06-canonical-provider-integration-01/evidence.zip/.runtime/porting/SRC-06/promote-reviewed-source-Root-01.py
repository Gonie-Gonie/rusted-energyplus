"""Promote the fully tested reviewed Rust union, preserving byte custody."""
from pathlib import Path
import hashlib,json,subprocess,re
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06'
WORK=BASE/'ordinary-provider-assembly-Root-60/workspace'
OUT=BASE/'reviewed-source-promotion-Root-01'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 p=base/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];assert len(b)==r.get('bytes',r.get('size_bytes',len(b)));return b
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert not OUT.exists()
assert not git('status','--porcelain=v1','-z')
head=git('rev-parse','HEAD').decode().strip();remote=git('rev-parse','origin/main').decode().strip();assert head==remote=='568ff1a91db30bbe462d0670b4c7f397107e14a4'
receipt=WORK/'.runtime/porting/SRC-06/provider-assembly-existing-workspace-all-targets-tests-60-8MiB/receipt.json'
r=json.loads(receipt.read_bytes());assert r['exit_code']==0 and r['source_bytes_match_before_and_after']
peer=BASE/'Audit-ordinary-provider-union60-Source-review-01/review.json'
review=json.loads(peer.read_bytes());assert review['status'].startswith('ACCEPTED')
index=json.loads(read(r['source_snapshot'],WORK));rows=index['files'];assert not index['bytes_normalized']
stdout=read(r['stdout'],WORK).decode('utf8');results=[tuple(map(int,x))for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
assert results and all(fail==0 for _,fail,_ in results)
assert 'heat_balance::error_backend::tests::warning_all_search_matches_and_warmup_sizing_abort_guards_are_literal ... ok' in stdout
changes=[];source=[]
for row in rows:
 path=row['historical_path'];b=read(row['archive'],WORK);assert len(b)==row['size_bytes'] and (WORK/path).read_bytes()==b
 p=ROOT/path;a=p.read_bytes()if p.exists()else b''
 source.append(dict(path=path,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
 if a==b:continue
 assert path.endswith('.rs') and b'\r\n' not in b and p.resolve().is_relative_to(ROOT/'crates')
 tree=git('ls-tree',head,'--',path);blob=git('show',head+':'+path)if tree else b''
 assert bool(tree)==p.exists() and blob==a
 assert a.count(b'#[test]')==b.count(b'#[test]')
 changes.append(dict(path=path,before_sha256=hashlib.sha256(a).hexdigest(),before_bytes=len(a),before_Git_exists=bool(tree),after_sha256=hashlib.sha256(b).hexdigest(),after_bytes=len(b)))
assert len(changes)==417 and sum(not row['before_Git_exists']for row in changes)==325
OUT.mkdir()
for row in changes:
 p=ROOT/row['path'];a=p.read_bytes()if p.exists()else b'';assert hashlib.sha256(a).hexdigest()==row['before_sha256']
 b=(WORK/row['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['after_sha256']
 old=OUT/'before'/row['path'];old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(a)
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for row in source:
 b=(ROOT/row['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
v=dict(schema='src06-reviewed-tested-source-canonical-promotion.v1',status='APPLIED exact reviewed tested Source bytes; commit and push pending',base_HEAD=head,origin_main_before=remote,parent_assembly=ref(BASE/'ordinary-provider-assembly-Root-60/manifest.json'),independent_union_peer=ref(peer),actual_existing_workspace_all_targets_tests=ref(receipt),whole_compiler_input_snapshot=dict(path=r['source_snapshot']['path'],sha256=r['source_snapshot']['sha256'],workspace=WORK.relative_to(ROOT).as_posix()),whole_current_compiler_inputs=source,changes=changes,counts=dict(compiler_inputs=len(rows),changed=417,new=325,existing=92,passed=sum(x[0]for x in results),failed=sum(x[1]for x in results),ignored=sum(x[2]for x in results)),new_test_bodies=0,pipeline_activation=False,whole_run_Native_numeric_verified=False,gate_changes=False,A='14/54',B='14/64',whole_old_comparison=dict(mismatches=235456,required_unavailable_or_unpaired=2754),unchanged_checkout_byte_bridge='Unchanged scheduled_output.rs remains exactly as tested; checkpoint07 records its Git LF/working CRLF single-byte bridge. All417 changed Sources are LF and exactly Git-reconstructible.',author_Source=ref(Path(__file__).resolve()))
p=OUT/'promotion.json';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)));print(json.dumps(v['counts']))

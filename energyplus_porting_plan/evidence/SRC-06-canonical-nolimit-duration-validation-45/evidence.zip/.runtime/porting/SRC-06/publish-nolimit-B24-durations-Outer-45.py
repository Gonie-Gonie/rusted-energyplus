"""Root-only B24/72/annual validation publication and one-reader promotion."""
from pathlib import Path
import argparse,ast,hashlib,json,re,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-nolimit-duration-validation-45';BACK=D/'nolimit-validation-publication-readback-Outer-45'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R);r=ref(p);assert r['sha256']==row['sha256']and r['bytes']==row.get('bytes',r['bytes']);return p
def load(row):return json.loads(checked(row).read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def main(a):
 assert a.publish and not PUBLIC.exists()and not BACK.exists();t=load(dict(path=a.template,sha256=a.template_sha));assert t['status']=='READY_ROOT_ACTUAL_AGGREGATE_ACCEPTED'
 assert ref(Path(__file__))==t['publisher_Source'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==t['base_HEAD']
 ar=dict(path=t['expected_actual_review_path'],sha256=a.actual_sha);actual=load(ar);ar=ref(checked(ar));assert actual['accepted']and not actual['findings']and ar==t['accepted_actual_review']
 assert actual['all4511_current_and_recorded_Source_compiler_inputs_exact']and actual['Rust_sources']==4498 and actual['duration_core_three_artifacts_fresh_true_equal44']
 assert actual['totals']['all_three_strict_comparisons_pass']and actual['totals']['tolerance_failures']==actual['totals']['rmse_failures']==0
 assert{c['case']for c in actual['cases']}=={'B-NOLIMIT-24H','B-NOLIMIT-72H','B-NOLIMIT-ANNUAL'}and len(actual['cases'])==3
 assert actual['own_export_scope']['verified_cases']==['B-NOLIMIT-24H']and actual['own_export_scope']['JSON_CSV_scalar_roundtrips']==9792 and actual['own_export_scope']['unverified_cases']==['B-NOLIMIT-72H','B-NOLIMIT-ANNUAL']
 assert actual['ancillary_IO_scope']['overall_IO_PASS']is False and not actual['ancillary_IO_scope']['admitted_cases']and actual['new_test_bodies']==actual['actual_test_bodies_executed']==actual['policy_changes']==actual['gate_changes']==0
 for case in actual['cases']:
  assert case['Source620_completed']and case['Native_completed']and case['strict_ordered_reported_stream_comparison_pass']
  for k in('Source_receipt','Native_receipt'):
   run=load(case[k]);assert run['exit_code']==0 and run['launch_error']is None and run['source_bytes_match_before_and_after']
 plan=load(actual['complete_compiler_plan']);assert(plan['compiler_inputs'],plan['Rust_sources'])==(4511,4498)
 for row in plan['entries']:
  p=R/row['path'];b=p.read_bytes();assert len(b)==row['final_bytes']and hashlib.sha256(b).hexdigest()==row['final_sha256']
 promotion=load(t['public_reader_promotion']);target=R/promotion['canonical_path'];before=checked(promotion['before']).read_bytes();after=checked(promotion['proposed']).read_bytes();assert target.read_bytes()==before==subprocess.check_output(['git','show',head+':'+promotion['canonical_path']],cwd=R)
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal','exec'),ns)
 assert ns['apply'](before,checked(promotion['forward_diff']).read_bytes())==after and ns['apply'](after,checked(promotion['inverse_diff']).read_bytes())==before
 assert promotion['only_available_variables_function_changed']and promotion['available_variables_whole_exact_held']and promotion['all_other_functions_numeric_parser_API_and_module_AST_exact']and promotion['canonical_ROOT_parents2_whole_unchanged']
 base=R/'energyplus_porting_plan';docs={name:(base/name).read_bytes()for name in('CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md')};pp=base/'plan.json';oldplan=pp.read_bytes();oldvalue=json.loads(oldplan)
 for name,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+name],cwd=R)
 assert oldplan==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
 files={}
 def add(row):
  p=checked(row);r=ref(p);assert p.suffix.lower()not in('.zip','.exe','.dll','.a')and r['bytes']<64*1024*1024
  assert not('ANNUAL' in r['path']and(p.name in('source-reported-results.json','source-eso.csv','source-mtr.csv')or p.suffix in('.eso','.mtr')))
  if r['path']in files:assert files[r['path']][1]==r
  files[r['path']]=(p,r)
 for row in t['finite_archive_inputs']:add(row)
 for row in(actual['publication_artifacts']+[ar,actual['author_Source'],ref(Path(__file__)),dict(path=a.template,sha256=a.template_sha)]):add(row)
 for key in('Source_receipt','Native_receipt'):
  for case in actual['cases']:
   run=load(case[key]);add(case[key])
   for k in('stdout','stderr','source_snapshot'):add(run[k])
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan);(BACK/'public-comparer-before.py').write_bytes(before)
 for name,b in docs.items():q=BACK/'docs-before'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 target.write_bytes(after);assert target.read_bytes()==after;add(ref(target))
 archive=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,(p,r)in sorted(files.items()):assert ref(p)==r;z.write(p,arcname=name)
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and set(z.namelist())==set(files)
  for name,(_,r)in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==r['sha256']
 mp=PUBLIC/'manifest.json';write(mp,dict(schema='src06-B-nolimit-three-case-finite-validation-evidence45.v1',archive=ref(archive),entries=[r for _,(_,r)in sorted(files.items())],scope='All three strict comparison reports, full B24 own9792 raw-sample/ancillary ledgers and small B24 own exports; actual command/custody/stdout/stderr/Source-snapshot metadata, unchanged policy and one-function Regular-reader proof. Annual outputs are hashed/inventoried only and remain ignored; no large annual JSON/CSV/ESO, runtime DLL/exe/core or recursive ZIP included. Native runtime pin metadata is not a bundled runtime or loaded-module trace.'))
 summary=dict(t['summary_template']);summary.update(schema='src06-canonical-nolimit-duration-validation45.v1',status='Three genuine Source620 and matching Native NoLimit case results; all original-policy reported comparisons passed',Root_actual_aggregate=ar,cases=actual['cases'],totals=actual['totals'],complete_compiler_plan=actual['complete_compiler_plan'],own_export_scope=actual['own_export_scope'],ancillary_IO_scope=actual['ancillary_IO_scope'],Native_B24_historical_IDD_qualification=actual['Native_B24_historical_IDD_qualification'],public_Regular_comparer=ref(target),public_promotion=t['public_reader_promotion'],Regular_reader_proof=actual['Regular_reader_proof'],archive=ref(archive),archive_manifest=ref(mp),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json';write(sp,summary);relative='evidence/SRC-06-canonical-nolimit-duration-validation-45/summary.json'
 for name,b in docs.items():
  link='../'+relative if name.startswith('cards/')else relative;append='\n\n[Source45 NoLimit B24/72/annual validation]('+link+'). '+t['doc_appends'][name]+'\n';assert '\ufffd'not in append and(base/name).read_bytes()==b;(base/name).write_bytes(b+append.encode('utf8'))
 new=json.loads(oldplan);task=next(v for v in new['tasks']if v['id']=='SRC-06');key='canonical_nolimit_duration_validation_45';assert key not in task;task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=ref(sp)['sha256'],size_bytes=sp.stat().st_size)
 inverse=json.loads(json.dumps(new));del next(v for v in inverse['tasks']if v['id']=='SRC-06')[key];assert inverse==oldvalue;write(pp,new)
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(archive),archive_manifest=ref(mp),archive_entries=len(files),base_HEAD=head,publisher_Source=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),validation_public_tool_only_change=ref(target),production_compiler_inputs_changed=0,new_tests=0,Cargo_Native_Source_commands_executed_by_publisher=False,gate_changes=False,Git_mutated=False)
 q=BACK/'publication-readback.json';write(q,result);print(json.dumps(ref(q)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--template',required=True);p.add_argument('--template-sha',required=True);p.add_argument('--actual-sha',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

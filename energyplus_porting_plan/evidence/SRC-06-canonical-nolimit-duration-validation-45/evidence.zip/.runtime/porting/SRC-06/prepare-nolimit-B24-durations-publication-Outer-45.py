"""Private finite operational publication template; no publisher execution."""
from pathlib import Path
import argparse,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=R/row['path'];r=ref(p);assert r['sha256']==row['sha256']and r['bytes']==row.get('bytes',r['bytes']);return p
def main(a):
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='73b35d70c1397a7718e4b2bdd13587d31d06b066';out=D/('nolimit-B24-durations-publication-READY-Outer-45'if a.actual else'nolimit-B24-durations-publication-WAIT-Outer-45');assert not out.exists();files={}
 def add(row):
  p=checked(row);r=ref(p);assert p.suffix.lower()not in('.zip','.exe','.dll','.a')and r['bytes']<64*1024*1024
  if r['path']in files:assert files[r['path']]==r
  files[r['path']]=r
 def addp(p):add(ref(p))
 waitp=D/'nolimit-validation-publication-WAIT-Outer-after44/publication-WAIT.json';wait=json.loads(waitp.read_bytes());addp(waitp)
 for row in wait['known_finite_archive_inputs']:add(row)
 launch=json.loads(checked(wait['launch_input_plan']).read_bytes());rp=D/'completed-B-comparison-ready-Audit-01/plan.json';reader=json.loads(rp.read_bytes());addp(rp)
 for key in('author_Source','held_Regular_RDD_reader_proposal','proposal_forward_diff','proposal_inverse_diff','accepted_Native39_baseline_bridge'):add(reader[key])
 promotionp=D/'public-Regular-reader-held-Outer-45/manifest.json';promotion=json.loads(promotionp.read_bytes());addp(promotionp)
 for key in('author_Source','before','proposed','forward_diff','inverse_diff'):add(promotion[key])
 ownp=D/'completed-B-own-export-and-ancillary-Root-44/review.json';own=json.loads(ownp.read_bytes());add(own['author_Source']);add(own['all9792_raw_tokens_bits_native_tuples_indices_physical_lines']);add(own['ancillary']['all_uncapped_raw_differences'])
 for key in('reported_bundle','Source_ESO','Source_ESO_CSV','Source_MTR_CSV'):add(own[key])
 for p in(D/'check-nolimit-B24-durations-actual-Outer-45.py',D/'publish-nolimit-B24-durations-Outer-45.py',Path(__file__)):addp(p)
 t=dict(schema='src06-nolimit-three-case-publication-template45.v1',status='WAITING_ROOT_ACTUAL_AGGREGATE',base_HEAD=head,publisher_Source=ref(D/'publish-nolimit-B24-durations-Outer-45.py'),actual_checker_Source=ref(D/'check-nolimit-B24-durations-actual-Outer-45.py'),expected_actual_review_path='.runtime/porting/SRC-06/Root-nolimit-B24-durations-actual-review-45/review.json',public_reader_promotion=ref(promotionp),finite_archive_inputs=list(files.values()),summary_template=dict(A='14/54',B='14/64',gate_changes=False,policy_changes=False,new_production_Sources=0,validation_tool_existing_files_changed=1,new_test_bodies=0,actual_test_bodies_executed=0,production_Source_changed=False,Source4511_Rust4498_parent_preserved=True,new_duration_Source_CLI_invocations=2,new_duration_Native_CLI_invocations=2,inherited_B24_Source_and_Native_not_rerun=True,qualification='These three NoLimit B cases only, not the remaining flow/capacity/both variants or full15/64-card closure. Native comparisons use original named tolerances/RMSE; raw/binary64 differences remain in complete reports. Own JSON/CSV verified only B24, durations unverified; no overall ancillary IO PASS. Public tool promotion adds Regular RDD input support only and preserves all numerical/parser/API logic outside that one reader and canonical ROOT location.'),doc_appends={
 'cards/SRC-06.md':'\ubb34\uc81c\ud55c B\uc758 24\uc2dc\uac04\u00b772\uc2dc\uac04\u00b7\uc5f0\uac04 Source \uc2e4\ud589\uacfc \uac19\uc740 \ucf00\uc774\uc2a4\uc758 Native \ubcf4\uace0\uac12 \uc804\uccb4 \ube44\uad50\ub97c \ud655\uc778\ud588\ub2e4. \uae30\uc874 \ud5c8\uc6a9\uc624\ucc28\uc640 RMSE \uc870\uac74\uc744 \ubaa8\ub450 \ud1b5\uacfc\ud588\uc73c\uba70 \uc6d0\uc2dc\uac12\u00b7\ube44\ud2b8 \ucc28\uc774\ub294 \ube44\uad50 \ubcf4\uace0\uc11c\uc5d0 \ub0a8\uacbc\ub2e4.',
 'CHECKLIST.md':'Source44\uc758 \ub3d9\uc77c\ud55c \ube4c\ub4dc\ub85c B72\uc640 \uc5f0\uac04\uc744 \uc2e4\ud589\ud558\uace0 \uc0c8 Native \uae30\uc900 \uc2e4\ud589\uc744 \uac01\uac01 \uc5f0\uacb0\ud588\ub2e4. \uc0c8 \ud14c\uc2a4\ud2b8 \ube4c\ub4dc\ub294 \uc5c6\uc73c\uba70 \uacf5\uac1c \ube44\uad50 \ub3c4\uad6c\uc5d0 Regular RDD \uc77d\uae30\ub9cc \ucd94\uac00\ud588\ub2e4. \uce74\ub4dc\u00b7\uac8c\uc774\ud2b8 \uc218\uce58\ub294 \ubcc0\uacbd\ud558\uc9c0 \uc54a\uc558\ub2e4.',
 'STATE_CONTRACTS.md':'\uc790\uccb4 JSON/CSV \uc7ac\ud655\uc778\uc740 B24\uc758 9,792\uac1c\uc5d0 \ud55c\uc815\ud55c\ub2e4. B72\u00b7\uc5f0\uac04 \ub0b4\ubcf4\ub0b4\uae30\ub294 \ubbf8\uac80\uc99d\uc73c\ub85c \ub0a8\uae30\uace0 \ubd80\uac00 IO\uc758 \ubbf8\ubd84\ub958 \ucc28\uc774\ub3c4 \ubcf4\uc874\ud55c\ub2e4. \uc5f0\uac04 \ub300\ud615 \uacb0\uacfc\uc640 \uc2e4\ud589 \ubc14\uc774\ub108\ub9ac\ub97c \uc99d\uac70 ZIP\uc5d0 \ub123\uc9c0 \uc54a\ub294\ub2e4.'})
 if a.actual:
  path,sha=a.actual.rsplit('#',1);row=dict(path=path,sha256=sha);actual=json.loads(checked(row).read_bytes());assert actual['accepted']and not actual['findings']and actual['totals']['all_three_strict_comparisons_pass']and actual['author_Source']==t['actual_checker_Source'];t['accepted_actual_review']=ref(checked(row));t['status']='READY_ROOT_ACTUAL_AGGREGATE_ACCEPTED'
 out.mkdir();p=out/'publication-template.json';p.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(dict(template=ref(p),publisher=t['publisher_Source'],fixed_archive_inputs=len(files),published=False)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--actual');main(p.parse_args())

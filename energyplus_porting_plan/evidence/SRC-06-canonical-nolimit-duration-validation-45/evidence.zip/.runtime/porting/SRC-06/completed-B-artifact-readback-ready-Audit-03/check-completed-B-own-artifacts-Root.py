"""ROOT ONLY after genuine B0: own JSON/CSV bits plus uncapped ancillary IO.

No Source/Native/Cargo execution, policy modification or completed-B inference.
Ancillary differences are retained before narrowly classifying metadata.
"""
from pathlib import Path
import argparse,base64,collections,csv,hashlib,io,itertools,json,math,re,struct
R=Path(__file__).resolve().parents[4]
D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return {'path':p.resolve().relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return p

def pairs(rows):
 d={}
 for k,v in rows:assert k not in d,('duplicate JSON key',k);d[k]=v
 return d

def decode(b):
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON '+x)))

def load(p):return decode(p.read_bytes())

def bits(x):return struct.pack('>d',float(x)).hex()

def keys(v,expected):assert isinstance(v,dict) and set(v)==set(expected),(set(v),expected)

def path_equal(text,p):assert isinstance(text,str) and Path(text).resolve()==p.resolve(),(text,str(p))

def integer(v):assert type(v) is int;return v

def parse_stream(path,stream):
 raw=path.read_bytes();assert raw.endswith(b'\r\n') and raw.count(b'\r\n')==raw.count(b'\n')
 lines=raw[:-2].decode('utf8').split('\r\n');assert lines[0].startswith('Program Version,')
 assert lines.count('End of Data Dictionary')==lines.count('End of Data')==1
 di=lines.index('End of Data Dictionary');en=lines.index('End of Data');assert en==len(lines)-2
 foot=re.fullmatch(r' Number of Records Written= *(\d+)',lines[-1]);assert foot
 dictionary={};declared=[];series={}
 for line in lines[1:di]:
  x=line.split(',',2);rid,width=int(x[0]),int(x[1]);assert rid>0 and rid not in dictionary;dictionary[rid]=line
  if rid<=6:continue
  if stream=='eso':key,tail=x[2].split(',',1)
  else:key,tail=None,x[2]
  m=re.fullmatch(r'(.+) \[(.*)\] !(TimeStep|Hourly)',tail);assert m and width==1
  d=dict(report_id=rid,key=key,name=m[1],units=m[2],frequency={'TimeStep':'timestep','Hourly':'hourly'}[m[3]],kind='variable' if stream=='eso' else 'meter')
  declared.append(d);series[rid]=[]
 assert set(range(1,7))<=set(dictionary)
 environments=[];stamps=[];current=None;count=0
 for physical,line in enumerate(lines[di+1:en],di+2):
  head,payload=line.split(',',1);rid=int(head);assert rid in dictionary
  if rid==1:
   fields=payload.rsplit(',',4);assert len(fields)==5 and all(math.isfinite(float(s)) for s in fields[1:])
   environments.append(dict(ordinal=len(environments)+1,fields=fields,physical_line=physical));current=None;continue
  if rid==2:
   fields=payload.split(',');assert len(fields)==8 and environments and all(re.fullmatch(r'-?\d+',s.strip()) for s in fields[:5]) and all(math.isfinite(float(s)) for s in fields[5:7]) and fields[7]
   current=len(stamps);stamps.append(dict(report_id=rid,kind='interval',environment_ordinal=len(environments),physical_line=physical,fields=fields));continue
  assert rid>6 and rid in series and current is not None
  fields=payload.split(',');assert len(fields)==1;value=float(fields[0]);assert math.isfinite(value);count+=1
  series[rid].append(dict(reported_fields=fields,value=value,parsed_binary64_bits=bits(value),stamp_index=current,physical_line=physical,stream_data_ordinal=count))
 assert count==int(foot[1])
 for values in series.values():
  ids=[(stamps[v['stamp_index']]['environment_ordinal'],tuple(stamps[v['stamp_index']]['fields'])) for v in values];assert values and len(set(ids))==len(ids)
 return dict(stream=stream,path=path,version_line=lines[0],dictionary=dictionary,declarations=declared,series=series,environments=environments,stamps=stamps,count=count)

def get_option(command,name):
 assert command.count(name)==1;at=command.index(name);assert at+1<len(command);return command[at+1]
def endings(raw):
 return {'CRLF':raw.count(b'\r\n'),'bare_LF':raw.count(b'\n')-raw.count(b'\r\n'),'embedded_or_unterminated_tail':bool(raw and not raw.endswith(b'\n'))}
def physical_inventory(source,native,output):
 # No mismatch is hidden by classification: retain every raw row and missing file.
 comparisons=[];mismatch_count=0;non_metadata_count=0
 ledger=output/'all-ancillary-physical-differences.jsonl'
 pairs=[('eplusrs.'+k,'energyplusout.'+k,k) for k in ['audit','bnd','eio','rdd','mdd','mtd','shd','err','end']]
 pairs += [('eplustbl.'+k,'eplustbl.'+k,'table.'+k) for k in ['csv','htm','tab','txt','xml']]
 source_inventory=[ref(p) for p in sorted(source.iterdir()) if p.is_file()]
 native_inventory=[ref(p) for p in sorted(native.iterdir()) if p.is_file()]
 known_source={sn for sn,_,_ in pairs}|{'eplusrs.eso','eplusrs.mtr'}
 known_native={nn for _,nn,_ in pairs}|{'energyplusout.eso','energyplusout.mtr'}
 # Retain unexpected Native-style physical streams, including Source-only
 # DXF/DBG/CTF files, rather than silently dropping them from the comparison.
 extra_suffixes={p.name[len('eplusrs.'):] for p in source.iterdir() if p.is_file() and p.name.startswith('eplusrs.') and p.name not in known_source}
 extra_suffixes|={p.name[len('energyplusout.'):] for p in native.iterdir() if p.is_file() and p.name.startswith('energyplusout.') and p.name not in known_native}
 pairs += [('eplusrs.'+k,'energyplusout.'+k,'extra-physical.'+k) for k in sorted(extra_suffixes)]
 with ledger.open('x',encoding='utf-8',newline='\n') as stream:
  for sn,nn,label in pairs:
   sp,np=source/sn,native/nn;row={'kind':label,'Source_present':sp.is_file(),'Native_present':np.is_file()}
   if not sp.exists() and not np.exists():row['both_absent']=True;comparisons.append(row);continue
   if sp.exists():row.update(Source=ref(sp),Source_endings=endings(sp.read_bytes()))
   if np.exists():row.update(Native=ref(np),Native_endings=endings(np.read_bytes()))
   source_lines=sp.read_bytes().splitlines(keepends=True) if sp.exists() else []
   native_lines=np.read_bytes().splitlines(keepends=True) if np.exists() else []
   differences=metadata=0
   for line,(s,n) in enumerate(itertools.zip_longest(source_lines,native_lines),1):
    if s==n:continue
    differences+=1;mismatch_count+=1;classification='unclassified physical content/absence difference'
    # Only the two actual first Program Version rows are metadata. An EIO
    # Version payload, diagnostic, elapsed-time line or missing END is retained.
    if line==1 and s is not None and n is not None and s.startswith(b'Program Version,') and n.startswith(b'Program Version,') and ((s.endswith(b'\r\n') and n.endswith(b'\r\n')) or (s.endswith(b'\n') and not s.endswith(b'\r\n') and n.endswith(b'\n') and not n.endswith(b'\r\n'))):
     classification='actual first-line producer Program Version/owned clock metadata';metadata+=1
    else:non_metadata_count+=1
    stream.write(json.dumps({'file':label,'physical_line':line,'classification':classification,'Source_complete_raw_base64':base64.b64encode(s).decode() if s is not None else None,'Native_complete_raw_base64':base64.b64encode(n).decode() if n is not None else None,'entire_rows_retained':True},ensure_ascii=False)+'\n')
   row.update(Source_physical_rows=len(source_lines),Native_physical_rows=len(native_lines),all_uncapped_unequal_rows=differences,explicit_first_header_metadata_rows=metadata,unclassified_rows=differences-metadata,whole_bytes_equal=sp.exists() and np.exists() and sp.read_bytes()==np.read_bytes())
   comparisons.append(row)
 return {'Source_full_top_level_inventory':source_inventory,'Native_full_top_level_inventory':native_inventory,'Source_specific_summary_diagnostic_support_files_are_inventory_only':True,'comparisons':comparisons,'all_uncapped_raw_differences':ref(ledger),'unequal_physical_rows':mismatch_count,'unclassified_physical_rows':non_metadata_count,'all_physical_IO_equal_except_only_explicit_first_header_metadata':non_metadata_count==0,'qualification':'No blanket ancillary PASS when extra/missing/data/diagnostic/elapsed-time differences remain. Native B12 has no tables; both absence and extra Source table files are explicit. Source run-summary/diagnostic/support files are separate products.'}
def main():
 a=argparse.ArgumentParser();a.add_argument('--source-receipt',required=True);a.add_argument('--source-receipt-sha256',required=True);a.add_argument('--reported-comparison',required=True);a.add_argument('--reported-comparison-sha256',required=True);a.add_argument('--output',required=True);a=a.parse_args()
 rp=(R/a.source_receipt).resolve();assert rp.is_relative_to(R) and ref(rp)['sha256']==a.source_receipt_sha256;r=load(rp)
 assert r['exit_code']==0 and r['launch_error'] is None and r['source_bytes_match_before_and_after']
 command=r['command'];assert get_option(command,'--porting-scope')=='B' and not {'--oracle-baseline','--compare-oracle','--dry-run','test'}&set(command)
 source=Path(get_option(command,'--output-dir')).resolve();assert source.is_relative_to(R)
 nr=D/'native-installed-B-NOLIMIT-24H-command-Root-12/receipt.json';assert ref(nr)['sha256']=='5e4c9f0ad0ca63bd3ba1a03e41373cbebf350a9d606071e6745dedbd4f794f2b';n=load(nr);assert n['exit_code']==0;native=Path(get_option(n['command'],'--output-directory')).resolve()
 summaryp=source/'run-summary.json';summary=load(summaryp);assert summary['status']=='success' and summary['exit_code']==0 and summary['oracle'] is None and summary['comparison'] is None
 runtime=summary['rust_runtime'];assert runtime['schema']=='rusted-energyplus.source-runtime.v1' and runtime['execution']=='actual Source ManageSimulation successful through620' and runtime['native_environment_hour_scope']==24
 assert runtime['requested_hours'] in [None,24] and summary['config']['dry_run'] is False and summary['config']['oracle_baseline'] is False and summary['config']['compare_oracle'] is False
 cp=(R/a.reported_comparison).resolve();assert cp.is_relative_to(R) and ref(cp)['sha256']==a.reported_comparison_sha256;comparison=load(cp);assert comparison['schema']=='src06-completed-finite-case-strict-reported-stream-comparison.v1' and comparison['case']=='B-NOLIMIT-24H' and comparison['Source_receipt']==ref(rp) and comparison['Native_receipt']==ref(nr)
 assert comparison['totals']['series']==102 and comparison['totals']['samples']==9792 and comparison['policy']['sha256']=='d3cd3e5956ce7e02dbcebe9e8c48799673b66c7b181d932f57514a949dcbf698'
 output=(R/a.output).resolve();assert output.is_relative_to(D.resolve()) and output!=D.resolve() and not output.exists();output.mkdir()
 ancillary=physical_inventory(source,native,output)
 # The physical ancillary ledger is complete even if a later export check rejects.
 (output/'ancillary-inventory.json').write_text(json.dumps(ancillary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
 p=parse_stream(source/'eplusrs.eso','eso');assert p['count']==9792 and len(p['declarations'])==102 and len(p['environments'])==1 and len(p['stamps'])==96
 assert all(len(p['series'][d['report_id']])==96 and d['frequency']=='timestep' and d['kind']=='variable' for d in p['declarations'])
 bundlep=source/'results/source-reported-results.json';bundle=load(bundlep);keys(bundle,['schema','timestamp_boundary','value_boundary','eso','mtr'])
 assert bundle['schema']=='rusted-energyplus.source-reported-streams.v1' and bundle['value_boundary']=='exact reported decimal tokens plus parsed binary64; not unformatted internal state' and bundle['timestamp_boundary']=='actual ESO/MTR tuples; no civil year inferred for interval/daily/monthly/run-period records'
 q=bundle['eso'];keys(q,['deleted_empty','environment_tuples','path','reported_record_count','series','stream','timestamp_tuples','version_line']);assert q['stream']=='eso' and q['deleted_empty'] is False and integer(q['reported_record_count'])==9792
 path_equal(q['path'],p['path']);assert q['version_line']==p['version_line'] and q['environment_tuples']==p['environments'] and q['timestamp_tuples']==p['stamps']
 assert len(q['series'])==102 and [integer(x['report_id']) for x in q['series']]==[d['report_id'] for d in p['declarations']]
 owners={x['stream']:x for x in runtime['reported_streams']};assert len(owners)==len(runtime['reported_streams'])==2 and set(owners)=={'eso','mtr'}
 path_equal(owners['eso']['owned_path'],p['path']);assert owners['eso']['reported_numeric_records']==9792 and owners['eso']['series']==102 and not owners['eso']['deleted_empty']
 comparison_series={x['report_id']:x for x in next(x for x in comparison['streams'] if x['stream']=='eso')['series']};assert len(comparison_series)==102
 csv_header=['stream','report_id','key','name','units','frequency','store_type','kind','sample_index','stream_data_ordinal','environment_ordinal','environment_fields_json','timestamp_report_id','timestamp_kind','timestamp_fields_json','reported_fields_json','reported_decimal','parsed_binary64_bits']
 csvp=source/'results/source-eso.csv';csvfile=csvp.open('r',encoding='utf-8',newline='');csvrows=csv.reader(csvfile,strict=True);assert next(csvrows)==csv_header
 total=0;samplep=output/'all9792-own-export-roundtrip-samples.jsonl'
 with samplep.open('x',encoding='utf-8',newline='\n') as evidence:
  assert len(owners['eso']['series_samples'])==102
  for actual,d,owner in zip(q['series'],p['declarations'],owners['eso']['series_samples']):
   keys(actual,['frequency','key','kind','name','report_id','sample_count','samples','store_type','units']);authority=comparison_series[d['report_id']]
   for k in ['frequency','key','kind','name','report_id','units']:assert actual[k]==d[k]
   assert actual['store_type']==authority['store_type'] and integer(actual['sample_count'])==len(actual['samples'])==96
   keys(owner,['report_id','key','name','units','frequency','store_type','kind','samples'])
   for k in ['report_id','key','name','units','frequency','store_type','kind']:assert owner[k]==actual[k]
   assert owner['samples']==96
   for index,(exported,physical) in enumerate(zip(actual['samples'],p['series'][d['report_id']])):
    keys(exported,['parsed_binary64_bits','physical_line','reported_fields','stamp_index','stream_data_ordinal','value']);assert isinstance(exported['value'],(int,float)) and not isinstance(exported['value'],bool) and math.isfinite(exported['value'])
    assert bits(exported['value'])==physical['parsed_binary64_bits']==exported['parsed_binary64_bits'] and re.fullmatch('[0-9a-f]{16}',exported['parsed_binary64_bits'])
    for k in ['reported_fields','stamp_index','physical_line','stream_data_ordinal']:assert exported[k]==physical[k]
    for k in ['stamp_index','physical_line','stream_data_ordinal']:integer(exported[k])
    stamp=p['stamps'][physical['stamp_index']];env=p['environments'][stamp['environment_ordinal']-1]
    expected=['eso',str(d['report_id']),d['key'],d['name'],d['units'],d['frequency'],actual['store_type'],d['kind'],str(index),str(physical['stream_data_ordinal']),str(stamp['environment_ordinal']),env['fields'],str(stamp['report_id']),stamp['kind'],stamp['fields'],physical['reported_fields'],physical['reported_fields'][0],physical['parsed_binary64_bits']]
    row=next(csvrows);assert len(row)==len(csv_header)
    for i,(v,e) in enumerate(zip(row,expected)):
     if i in [11,14,15]:assert decode(v)==e
     else:assert v==e
    evidence.write(json.dumps({'report_id':d['report_id'],'sample_index':index,'reported_fields':physical['reported_fields'],'parsed_binary64_bits':physical['parsed_binary64_bits'],'environment':env,'stamp':stamp,'stamp_index':physical['stamp_index'],'physical_line':physical['physical_line'],'stream_data_ordinal':physical['stream_data_ordinal'],'JSON_and_CSV_exact_physical_roundtrip':True},ensure_ascii=False,separators=(',',':'))+'\n');total+=1
  assert next(csvrows,None) is None
 csvfile.close();assert total==9792
 # Absence is certified by the completed Source owner and empty export, never
 # inferred from only the Native file being absent.
 assert not (source/'eplusrs.mtr').exists() and not (native/'energyplusout.mtr').exists()
 q=bundle['mtr'];keys(q,['deleted_empty','environment_tuples','path','reported_record_count','series','stream','timestamp_tuples','version_line']);assert q['stream']=='mtr' and q['deleted_empty'] is True and q['reported_record_count']==0 and q['environment_tuples']==q['timestamp_tuples']==q['series']==[] and q['version_line'] is None;path_equal(q['path'],source/'eplusrs.mtr')
 owner=owners['mtr'];assert owner['deleted_empty'] is True and owner['reported_numeric_records']==owner['series']==0 and owner['series_samples']==[];path_equal(owner['owned_path'],source/'eplusrs.mtr')
 mtrcsv=source/'results/source-mtr.csv'
 with mtrcsv.open('r',encoding='utf-8',newline='') as f:assert list(csv.reader(f,strict=True))==[csv_header]
 artifacts=summary['artifacts'];assert not {'result_store_json','selected_outputs_csv','meters_csv'}&set(artifacts)
 for k,name in [('source_reported_results_json','source-reported-results.json'),('source_eso_csv','source-eso.csv'),('source_mtr_csv','source-mtr.csv')]:path_equal(artifacts[k],source/'results'/name)
 assert {x.name for x in (source/'results').iterdir()}=={'source-reported-results.json','source-eso.csv','source-mtr.csv'}
 diagnostics=load(source/'diagnostics.json');assert summary['diagnostics']['error']==0 and not any(x['severity']=='error' or x['blocking'] for x in diagnostics['diagnostics'])
 result={'schema':'src06-completed-B-own-export-and-ancillary-readback.v1','accepted':True,'findings':[],'Source_receipt':ref(rp),'Source_summary':ref(summaryp),'Native_retained_receipt':ref(nr),'strict_reported_comparison':ref(cp),'strict_reported_numeric_pass':comparison['accepted'],'series':102,'JSON_CSV_scalar_roundtrips':9792,'all9792_raw_tokens_bits_native_tuples_indices_physical_lines':ref(samplep),'reported_bundle':ref(bundlep),'Source_ESO':ref(p['path']),'Source_ESO_CSV':ref(csvp),'Source_MTR_CSV':ref(mtrcsv),'MTR_genuinely_deleted_empty_with_actual_Source_zero_counter':True,'MTR_CSV_header_only':True,'ancillary':ancillary,'ancillary_all_equal_or_only_explicit_metadata':ancillary['all_physical_IO_equal_except_only_explicit_first_header_metadata'],'overall_reported_and_own_export_pass':bool(comparison['accepted']),'Native_baseline_IDD_history_qualification':'Retain accepted Native39-vs-installed12 bridge684df2. Installed12 receipt does not independently pin historical IDD bytes/INI absence; current explicit39 capture and whole physical Native reported agreement are separate evidence.','A5352_proof_used_as_B_proof':False,'no_Cargo_Native_Source_CLI_or_tests_executed':True,'new_test_bodies':0,'canonical_Source_or_policy_mutations':0,'author_Source':ref(Path(__file__))}
 (output/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(output/'review.json')))
 return 0 if comparison['accepted'] else 1
if __name__=='__main__':raise SystemExit(main())

"""Root-only bounded existing-result aggregate; no engines, Cargo or large JSON."""
from pathlib import Path
import ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-nolimit-B24-durations-actual-review-45';H='73b35d70c1397a7718e4b2bdd13587d31d06b066'
EXPECTED={
 'B-NOLIMIT-24H':('canonical-source-thermostat-predefined-B-NOLIMIT-24H-command-Root-44','c87dc0133188773ba95f8b78efd25ee22e772b60a2d57e63551c41497820f49d','native-installed-B-NOLIMIT-24H-command-Root-12','5e4c9f0ad0ca63bd3ba1a03e41373cbebf350a9d606071e6745dedbd4f794f2b','completed-B-NOLIMIT-24H-reported-Root-44','d2263d8c26582e382f0f33127ec49c0851a7c9e7e47cb75b296eccdb9a9acfad'),
 'B-NOLIMIT-72H':('source-nolimit-duration-B-NOLIMIT-72H-command-Root-45','6934ec93067ae205ead1ce45cd6f38aa849cfaadce2f3f6ea722df81111ba4b2','native-installed-nolimit-duration-B-NOLIMIT-72H-command-Root-45','937dbb69fafba685035ac25bbd20c8854b2f7c85f759e4b1d26a33b2b5e41cf3','completed-B-NOLIMIT-72H-reported-Root-45','7ead35bd78cae71034ce89be6eb673696552585a17bb9dd85cda58e5d52fda95'),
 'B-NOLIMIT-ANNUAL':('source-nolimit-duration-B-NOLIMIT-ANNUAL-command-Root-45','5700ad3595294608035a766f0bf6f4e31c27312c0829da611983bc387963e17a','native-installed-nolimit-duration-B-NOLIMIT-ANNUAL-command-Root-45','63d8b965596c1a10dd2ec355689ed67f41506cf63e07ac1da4ad0f3021044367','completed-B-NOLIMIT-ANNUAL-reported-Root-45','5f0e243e2964796d0d0b9fa0bf8df136b8488444209cf4ca2852ab97aad8980d')}
def ref(p):
 p=p.resolve();h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=p.relative_to(R).as_posix(),sha256=h.hexdigest(),bytes=p.stat().st_size)
def checked(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R);r=ref(p);assert r['sha256']==row['sha256']and r['bytes']==row.get('bytes',r['bytes']);return p
def load(row):return json.loads(checked(row).read_bytes())
def auth(path,sha):
 p=D/path;r=ref(p);assert r['sha256']==sha;return r,load(r)
def option(cmd,key):assert cmd.count(key)==1;return cmd[cmd.index(key)+1]
def same_path(text,p):assert Path(text).resolve()==p.resolve()
def core(run,fresh):
 rows={}
 for line in checked(run['stdout']).read_bytes().splitlines():
  try:v=json.loads(line)
  except(ValueError,UnicodeDecodeError):continue
  if not isinstance(v,dict)or v.get('reason')!='compiler-artifact':continue
  name=v['target']['name']
  if name not in('ep_runtime','ep_run','eplus-rs'):continue
  assert name not in rows and v['fresh']is fresh
  crate='ep_cli'if name=='eplus-rs'else name;same_path(v['manifest_path'],R/f'crates/{crate}/Cargo.toml');same_path(v['target']['src_path'],R/f'crates/{crate}/src/{"main"if name=="eplus-rs"else"lib"}.rs')
  v.pop('fresh');rows[name]=v
 assert len(rows)==3;return rows
def main():
 assert not O.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
 lp,launch=auth('nolimit-duration-launch-prepared-Outer-after44/plan.json','7b1611f1b71510fb516e3b759edb283238c77d2200aa075ef8c09e54cbb1086d')
 actual=load(launch['accepted44_actual_review']);assert actual['accepted']and actual['B_Source_completed']and not actual['findings'];plan=load(launch['complete_compiler_plan']);assert(plan['compiler_inputs'],plan['Rust_sources'])==(4511,4498)
 rows={v['path']:v for v in plan['entries']};assert len(rows)==4511
 for name,row in rows.items():
  b=checked(row['source']).read_bytes();assert len(b)==row['final_bytes']and hashlib.sha256(b).hexdigest()==row['final_sha256']and(R/name).read_bytes()==b,name
 snap_cache=set();cases=[];artifacts=[];inventories=[]
 policy=checked(launch['unchanged_output_policy']);assert policy.read_bytes()==subprocess.check_output(['git','show','2fffe68fb9131c80efcd3232de3a81d5290045c6:energyplus_porting_plan/contracts/output-tolerances.json'],cwd=R)
 rp=D/'completed-B-comparison-ready-Audit-01/plan.json';reader=load(ref(rp));public=checked(reader['canonical_public_comparator']);held=checked(reader['held_Regular_RDD_reader_proposal']);assert ref(held)==launch['strict_Regular_reported_comparer']
 a,b=ast.parse(public.read_bytes()),ast.parse(held.read_bytes());fa={x.name:ast.dump(x,include_attributes=False)for x in a.body if isinstance(x,ast.FunctionDef)};fb={x.name:ast.dump(x,include_attributes=False)for x in b.body if isinstance(x,ast.FunctionDef)};assert fa.keys()==fb.keys()and{k for k in fa if fa[k]!=fb[k]}=={'available_variables'}
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));f=next(v for v in t.body if isinstance(v,ast.FunctionDef)and v.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'literal','exec'),ns)
 assert ns['apply'](public.read_bytes(),checked(reader['proposal_forward_diff']).read_bytes())==held.read_bytes()and ns['apply'](held.read_bytes(),checked(reader['proposal_inverse_diff']).read_bytes())==public.read_bytes()
 promotionp=D/'public-Regular-reader-held-Outer-45/manifest.json';promotion=load(ref(promotionp));assert promotion['only_available_variables_function_changed']and promotion['canonical_ROOT_parents2_whole_unchanged'];assert checked(promotion['before']).read_bytes()==public.read_bytes()
 for name,values in EXPECTED.items():
  sp,ss,np,ns_,cp,cs=values;sr,source=auth(sp+'/receipt.json',ss);nr,native=auth(np+'/receipt.json',ns_);cr,comparison=auth(cp+'/comparison.json',cs)
  meta_path=R/'energyplus_porting_plan/cases'/name/'metadata.json';meta=json.loads(meta_path.read_bytes());input_path=checked(meta['input']);weather=checked(meta['weather']);assert(meta['id'],meta['scope'],meta['limit_variant'])==(name,'B','NOLIMIT')
  expected_steps=meta['expected_zone_steps_excluding_warmup'];hours=expected_steps//meta['expected_settings']['timesteps_per_hour']
  assert comparison['case']==name and comparison['profile']=='B'and comparison['accepted']and comparison['Source_receipt']==sr and comparison['Native_receipt']==nr and comparison['author_Source']==launch['strict_Regular_reported_comparer']and comparison['policy']==launch['unchanged_output_policy']
  for label,run in [('Source',source),('Native',native)]:
   assert run['exit_code']==0 and run['launch_error']is None and run['source_bytes_match_before_and_after'];assert run['repository_before']['head']==run['repository_after']['head'];cmd=run['command'];same_path(option(cmd,'--weather'),weather)
   assert len([v for v in cmd if v.lower().endswith('.idf')and Path(v).resolve()==input_path])==1
   for key in('stdout','stderr','source_snapshot'):checked(run[key]);artifacts.append(run[key])
   if label=='Source':
    assert option(cmd,'--porting-scope')=='B'and '--hours'not in cmd and not{'--oracle-baseline','--compare-oracle','--dry-run','test'}&set(cmd)
    same_path(run['launch_environment_selected']['CARGO_TARGET_DIR'],D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh')
    # Recorder's selected environment does not include CARGO_INCREMENTAL.
    # Authenticate its explicit enforcement in the actual Root launcher; do
    # not invent a recorded environment value using a default/get fallback.
    launcher=launch['launch_Source']if name!='B-NOLIMIT-24H'else actual['launcher_Source']
    assert "env['CARGO_INCREMENTAL']='0'"in checked(launcher).read_text(encoding='utf8')
    snap=run['source_snapshot']
    if snap['sha256']not in snap_cache:
     snapshot=load(snap);index={v['historical_path']:v for v in snapshot['files']};assert index.keys()==rows.keys()
     for p,row in index.items():assert row['archive']['sha256']==rows[p]['final_sha256']and row['size_bytes']==rows[p]['final_bytes'];checked(row['archive'])
     snap_cache.add(snap['sha256'])
   else:same_path(cmd[0],checked(launch['installed_executable']));assert option(cmd,'--output-prefix')=='energyplus'
  summary_path=Path(option(source['command'],'--output-dir'))/'run-summary.json';summary=load(ref(summary_path));runtime=summary['rust_runtime'];assert summary['exit_code']==0 and summary['status']=='success'and runtime['schema']=='rusted-energyplus.source-runtime.v1'and runtime['execution']=='actual Source ManageSimulation successful through620'
  assert runtime['native_environment_hour_scope']==hours and runtime['native_environment_scope']==comparison['selected_Source_environment_scope'];assert runtime['native_options']['DoWeathSim']is True
  diagnostics=summary_path.with_name('diagnostics.json');diag=load(ref(diagnostics));assert not[v for v in diag['diagnostics']if v['severity']=='error']
  assert not{'result_store_json','selected_outputs_csv','meters_csv'}&summary['artifacts'].keys()
  result_dir=summary_path.parent/'results';assert{p.name for p in result_dir.iterdir()}=={'source-reported-results.json','source-eso.csv','source-mtr.csv'}
  # Stream hash inventories do not parse or certify annual JSON/CSV values.
  result_inventory=[dict(**ref(p),verification='presence/whole hash only; own-export values unverified for72/annual')for p in sorted(result_dir.iterdir())]
  inventories.append(dict(case=name,reported_result_artifacts=result_inventory,own_export_readback_admitted=name=='B-NOLIMIT-24H'))
  series=[s for stream in comparison['streams']for s in stream['series']];totals=comparison['totals'];assert len(series)==meta['object_counts']['output:variable']==totals['series']==102
  assert all(s['frequency']=='TimeStep'and s['samples']==expected_steps and s['passed']and s['rmse_limit_met']and s['tolerance_failures']==0 for s in series)
  assert totals['samples']==sum(s['samples']for s in series)==len(series)*expected_steps and totals['raw_operand_unequal']==sum(s['raw_operand_unequal']for s in series)and totals['parsed_binary64_unequal']==sum(s['parsed_binary64_unequal']for s in series)and totals['tolerance_failures']==totals['rmse_failures']==0 and totals['passed']
  for stream in comparison['streams']:
   if stream.get('deleted_empty'):assert stream['stream']=='mtr'and not stream['series']and stream['records']==0;continue
   for key in('Source','Native'):checked(stream[key])
  for v in comparison['type_authorities']:checked(v);artifacts.append(v)
  checked(comparison['all_uncapped_tolerance_failures']);artifacts.extend([sr,nr,cr,comparison['all_uncapped_tolerance_failures'],ref(meta_path),ref(input_path),ref(summary_path),ref(diagnostics)])
  custodies=[]
  if name!='B-NOLIMIT-24H':
   assert source['repository_before']['head']==native['repository_before']['head']==H;same_path(option(native['command'],'--idd'),checked(launch['explicit_IDD']))
   assert core(source,True)==core(load(actual['actual_B']),False)
   for label in('source','native-installed'):
    q=D/f'{label}-nolimit-duration-{name}-custody-Root-45/custody.json';c=load(ref(q));assert c['case']==name and c['exit_code']==0 and c['command_receipt']==(sr if label=='source'else nr)and c['input_plan']==lp and c['launcher_Source']==launch['launch_Source']
    assert c['installed_runtime_bytes_exact_before_and_after']and c['installed_runtime_before']==c['installed_runtime_after']==launch['installed_runtime_pins']and c['actual44_production_code_wholes_checked']and c['case_input']==ref(input_path)and c['weather']==ref(weather)and c['explicit_IDD']==launch['explicit_IDD']
    custodies.append(ref(q));artifacts.append(ref(q))
  per_units={}
  for s in series:
   if s['units']not in per_units or s['max_abs_delta']>per_units[s['units']]['max_abs_delta']:per_units[s['units']]={k:s[k]for k in('key','name','units','max_abs_delta','rmse_delta','policy')}
  cases.append(dict(case=name,Source_receipt=sr,Native_receipt=nr,comparison=cr,Source_summary=ref(summary_path),Source_diagnostics=ref(diagnostics),case_metadata=ref(meta_path),case_input=ref(input_path),weather=ref(weather),full_case_hours=hours,zone_steps=expected_steps,metrics=totals,maximum_absolute_deltas_by_actual_unit=per_units,custodies=custodies,Source620_completed=True,Native_completed=True,strict_ordered_reported_stream_comparison_pass=True,raw_and_binary64_exact=totals['raw_operand_unequal']==totals['parsed_binary64_unequal']==0,own_JSON_CSV_verified=name=='B-NOLIMIT-24H',ancillary_IO_admitted=False))
 er,export=auth('completed-B-own-export-and-ancillary-Root-44/review.json','6fca3f8908f513fd971b8d15340affbb3cbe670f167f0cb5858167acb4cc0871');assert export['accepted']and export['overall_reported_and_own_export_pass']and export['JSON_CSV_scalar_roundtrips']==9792 and not export['A5352_proof_used_as_B_proof']and not export['ancillary_all_equal_or_only_explicit_metadata']
 samplep=checked(export['all9792_raw_tokens_bits_native_tuples_indices_physical_lines']);assert sum(1 for _ in samplep.open('rb'))==9792;checked(export['ancillary']['all_uncapped_raw_differences'])
 artifacts.extend([er,export['author_Source'],export['all9792_raw_tokens_bits_native_tuples_indices_physical_lines'],export['ancillary']['all_uncapped_raw_differences']])
 for key in('reported_bundle','Source_ESO','Source_ESO_CSV','Source_MTR_CSV'):checked(export[key]);artifacts.append(export[key])
 proof=dict(held_readiness_plan=ref(rp),public_before=promotion['canonical_before'],held_reader=reader['held_Regular_RDD_reader_proposal'],held_forward_diff=reader['proposal_forward_diff'],held_inverse_diff=reader['proposal_inverse_diff'],only_available_variables_function_and_private_ROOT_relocation_change=True,all_other_numeric_parser_API_functions_AST_exact=True,public_promotion=ref(promotionp),public_proposed=promotion['proposed'],public_ROOT_parents2_preserved=True)
 O.mkdir();ip=O/'large-duration-result-artifact-hash-inventory.json';ip.write_bytes((json.dumps(inventories,ensure_ascii=False,indent=2)+'\n').encode('utf8'));artifacts.append(ref(ip))
 totals=dict(case_series=sum(c['metrics']['series']for c in cases),reported_scalar_samples=sum(c['metrics']['samples']for c in cases),raw_operand_unequal=sum(c['metrics']['raw_operand_unequal']for c in cases),parsed_binary64_unequal=sum(c['metrics']['parsed_binary64_unequal']for c in cases),tolerance_failures=0,rmse_failures=0,all_three_strict_comparisons_pass=True)
 result=dict(schema='src06-nolimit-B24-B72-annual-actual-validation45.v1',accepted=True,findings=[],base_HEAD=H,author_Source=ref(Path(__file__)),launch_input_plan=lp,complete_compiler_plan=launch['complete_compiler_plan'],accepted44_production_review=launch['accepted44_actual_review'],all4511_current_and_recorded_Source_compiler_inputs_exact=True,Rust_sources=4498,duration_core_three_artifacts_fresh_true_equal44=True,cases=cases,totals=totals,unchanged_original_policy=launch['unchanged_output_policy'],Regular_reader_proof=proof,own_export_scope=dict(verified_cases=['B-NOLIMIT-24H'],JSON_CSV_scalar_roundtrips=9792,readback=er,all_samples=export['all9792_raw_tokens_bits_native_tuples_indices_physical_lines'],unverified_cases=['B-NOLIMIT-72H','B-NOLIMIT-ANNUAL'],existing_public_bounded_own_export_reader=False,qualification='Existing public comparator verifies physical reported streams only; existing private own-export readers load complete JSON/physical histories/CSV lists. No new reader or huge annual JSON-tree load was introduced.'),ancillary_IO_scope=dict(overall_IO_PASS=False,admitted_cases=[],known_B24_unclassified_rows=export['ancillary']['unclassified_physical_rows'],uncapped_B24_raw_differences=export['ancillary']['all_uncapped_raw_differences'],duration_ancillary_unreviewed=True),Native_B24_historical_IDD_qualification=export['Native_baseline_IDD_history_qualification'],publication_artifacts=artifacts,large_result_artifact_inventory=ref(ip),actual_Source_receipts=3,actual_Native_receipts=3,inherited_B24_Source_and_Native_not_rerun=True,new_duration_Source_commands=2,new_duration_Native_commands=2,new_test_bodies=0,actual_test_bodies_executed=0,checker_Cargo_Source_Native_commands_executed=False,checker_public_or_canonical_mutations=0,policy_changes=0,gate_changes=0,limits='Reported physical values and completed Source620 for these three NoLimit B cases only. 72/annual raw/binary64 differences are preserved, not exact-match claims. Own JSON/CSV proven only B24; ancillary not admitted. Flow/capacity/both variants, internal operation conformance and full15/64-card completion remain separate.')
 q=O/'review.json';q.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(dict(review=ref(q),totals=totals)))
if __name__=='__main__':main()

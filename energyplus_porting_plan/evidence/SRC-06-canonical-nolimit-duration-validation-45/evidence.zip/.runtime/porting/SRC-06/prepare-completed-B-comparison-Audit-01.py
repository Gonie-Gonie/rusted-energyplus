"""Read-only readiness plan and HELD Regular-RDD reader for a future genuine B0."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'completed-B-comparison-ready-Audit-01';assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return p
def save(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(n,v):return save(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
tool=R/'tools/porting/check_completed_reported_streams.py';assert ref(tool)['sha256']=='46a1b6f9081d9a0ff5a2d430b17ec647b88a41f5052c3bb1c95df98174ab754c';before=tool.read_text(encoding='utf-8');tree=ast.parse(before)
fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='available_variables');lines=before.splitlines(keepends=True);old=''.join(lines[fn.lineno-1:fn.end_lineno])
new='''def available_variables(path):
    rows = {}
    lines = path.read_text(encoding="utf8").splitlines()
    regular = (len(lines) >= 2 and lines[0].startswith("Program Version,")
               and lines[1] == "Var Type (reported time step),Var Report Type,Variable Name [Units]")
    for line in lines[2:] if regular else lines:
        if not regular and line.startswith("!"):
            continue
        if regular:
            m = re.fullmatch(r"(Zone|HVAC),(Average|Sum),(.+) \\[(.*)\\]", line)
            require(m is not None, f"unsupported Regular RDD row: {line}")
            timestep_type, store_type, name, units = m[1], m[2], m[3], m[4]
        else:
            m = re.fullmatch(r"Output:Variable,\\*,(.+),hourly; !- (Zone|HVAC) (Average|Sum) \\[(.*)\\]", line)
            require(m is not None, f"unsupported RDD row: {line}")
            name, timestep_type, store_type, units = m[1], m[2], m[3], m[4]
        identity = name, units
        require(identity not in rows, "duplicate RDD identity")
        rows[identity] = {"raw_line": line, "timestep_type": timestep_type, "store_type": store_type}
    return rows
'''
assert before.count(old)==1;after=before.replace(old,new,1);assert after.count('ROOT = Path(__file__).resolve().parents[2]')==1;after=after.replace('ROOT = Path(__file__).resolve().parents[2]','ROOT = Path(__file__).resolve().parents[7]  # ignored proposal relocation only',1)
proposed=save('proposed/tools/porting/check_completed_reported_streams.py',after.encode());assert checked(proposed).parents[7]==R
ta=ast.parse(after);old_functions={x.name:ast.dump(x,include_attributes=False) for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};new_functions={x.name:ast.dump(x,include_attributes=False) for x in ta.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};assert old_functions.keys()==new_functions.keys() and [n for n in old_functions if old_functions[n]!=new_functions[n]]==['available_variables']
fwd=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='canonical-public-tool',tofile='held-Regular-reader-proposal'));inv=''.join(difflib.unified_diff(after.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='held-Regular-reader-proposal',tofile='canonical-public-tool'))
t=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));applyfn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='diff_apply');ns={'re':re};exec(compile(ast.Module(body=[applyfn],type_ignores=[]),'<literal>','exec'),ns);assert ns['diff_apply'](tool.read_bytes(),fwd)==after.encode() and ns['diff_apply'](after.encode(),inv)==tool.read_bytes()
forward=save('tool-forward.diff',fwd.encode());inverse=save('tool-inverse.diff',inv.encode())
np=D/'native-installed-B-NOLIMIT-24H-command-Root-12/receipt.json';assert ref(np)['sha256']=='5e4c9f0ad0ca63bd3ba1a03e41373cbebf350a9d606071e6745dedbd4f794f2b';native=json.loads(np.read_bytes());assert native['exit_code']==0 and native['launch_error'] is None and native['source_bytes_match_before_and_after'];cmd=native['command'];nd=Path(cmd[cmd.index('--output-directory')+1])
scopep=R/'energyplus_porting_plan/contracts/scope.json';scope=json.loads(scopep.read_bytes());case=next(x for x in scope['cases'] if x['id']=='B-NOLIMIT-24H');metadata=json.loads(checked(case['metadata']).read_bytes());assert metadata['expected_zone_steps_excluding_warmup']==96 and metadata['expected_weather_environments']==1 and metadata['expected_settings']['timesteps_per_hour']==4
policy=R/'energyplus_porting_plan/contracts/output-tolerances.json';assert ref(policy)['sha256']=='d3cd3e5956ce7e02dbcebe9e8c48799673b66c7b181d932f57514a949dcbf698';pv=json.loads(policy.read_bytes());assert len(pv['profiles']['B'])==102 and not pv['meter_profiles']['B']
assert subprocess.check_output(['git','show','2fffe68fb9131c80efcd3232de3a81d5290045c6:'+policy.relative_to(R).as_posix()],cwd=R)==policy.read_bytes()
bridgep=D/'system-report-Native-reported-comparison-Peer-39/comparison.json';assert ref(bridgep)['sha256']=='684df2ea2aff18aa187bf704c34f10cf38e2c4b6952084ca8208764b1e298aaf';bridge=json.loads(bridgep.read_bytes());assert bridge['accepted'] and not bridge['findings'] and bridge['actual_installed_Native_receipt']==ref(np) and bridge['metrics']['series']==102 and bridge['metrics']['samples']==9792
reader=next(x for x in ta.body if isinstance(x,ast.FunctionDef) and x.name=='available_variables');ns={'re':re,'require':lambda ok,message:None if ok else (_ for _ in ()).throw(ValueError(message))};exec(compile(ast.Module(body=[reader],type_ignores=[]),'<held-metadata-reader-only>','exec'),ns)
regular=ns['available_variables'](nd/'energyplusout.rdd');assert len(regular)==382
oldreader=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='available_variables');oldns={'re':re,'require':ns['require']};exec(compile(ast.Module(body=[oldreader],type_ignores=[]),'<existing-IDF-reader>','exec'),oldns)
old_failed=False
try:oldns['available_variables'](nd/'energyplusout.rdd')
except ValueError:old_failed=True
assert old_failed
actualA=D/'canonical-source-node-setpoint-endrun-A-24H-Root-41-02/output/eplusrs.rdd';assert actualA.is_file();assert ns['available_variables'](actualA)==oldns['available_variables'](actualA)
selected=[]
with (nd/'energyplusout.eso').open('rb') as stream:
 assert stream.readline().startswith(b'Program Version,')
 for raw in stream:
  line=raw.decode().rstrip('\r\n')
  if line=='End of Data Dictionary':break
  head=line.split(',',2)
  if int(head[0])<=6:continue
  m=re.fullmatch(r'(\d+),1,([^,]*),(.+) \[(.*)\] !TimeStep',line);assert m;assert (m[3],m[4]) in regular;selected.append({'report_id':int(m[1]),'key':m[2],'name':m[3],'units':m[4],'RDD':regular[(m[3],m[4])]})
assert len(selected)==102 and not (nd/'energyplusout.mtr').exists()
native_inventory=[{'suffix':p.suffix.lstrip('.'),'whole':ref(p)} for p in sorted(nd.iterdir()) if p.is_file()]
native_src=R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/OutputProcessor.cc';raw=native_src.read_bytes();assert raw==subprocess.check_output(['git','-C',str(R/'.reference/energyplus-src/26.1.0'),'show','6f2e40d10250a105b49966baa24d843711e61048:src/EnergyPlus/OutputProcessor.cc']);parts=raw.splitlines(keepends=True)
authority={'Native_path':'src/EnergyPlus/OutputProcessor.cc','whole':ref(native_src),'pinned_Git':'6f2e40d10250a105b49966baa24d843711e61048','strict_extent':save('Native-ProduceRDDMDD4731-4825.txt',b''.join(parts[4730:4825]))}
launcher='''"""ROOT ONLY: read actual future B0; no Native/Source CLI/Cargo or policy edits."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
a=argparse.ArgumentParser();a.add_argument('--source-receipt',required=True);a.add_argument('--source-receipt-sha256',required=True);a.add_argument('--output',required=True);a=a.parse_args()
source=(R/a.source_receipt).resolve();assert source.is_relative_to(R) and hashlib.sha256(source.read_bytes()).hexdigest()==a.source_receipt_sha256
receipt=json.loads(source.read_bytes());assert receipt['exit_code']==0 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
command=receipt['command'];assert command[command.index('--porting-scope')+1]=='B' and not {'--oracle-baseline','--compare-oracle','--dry-run'}&set(command)
summary=json.loads((Path(command[command.index('--output-dir')+1])/'run-summary.json').read_bytes());assert summary['status']=='success' and summary['exit_code']==0 and summary['rust_runtime']['schema']=='rusted-energyplus.source-runtime.v1' and summary['rust_runtime']['execution']=='actual Source ManageSimulation successful through620'
tool=R/TOOL_PATH;assert hashlib.sha256(tool.read_bytes()).hexdigest()==TOOL_SHA
native=D/'native-installed-B-NOLIMIT-24H-command-Root-12/receipt.json';assert hashlib.sha256(native.read_bytes()).hexdigest()=='5e4c9f0ad0ca63bd3ba1a03e41373cbebf350a9d606071e6745dedbd4f794f2b'
output=(R/a.output).resolve();allowed=D.resolve();assert output.is_relative_to(allowed) and output!=allowed and not output.exists()
raise SystemExit(subprocess.call([sys.executable,str(tool),'--case','B-NOLIMIT-24H','--source-receipt',str(source),'--source-receipt-sha256',a.source_receipt_sha256,'--native-receipt',str(native),'--native-receipt-sha256','5e4c9f0ad0ca63bd3ba1a03e41373cbebf350a9d606071e6745dedbd4f794f2b','--output',str(output)],cwd=R))
'''.replace('TOOL_PATH',repr(proposed['path'])).replace('TOOL_SHA',repr(proposed['sha256']));ast.parse(launcher);lr=save('launch-completed-B-reported-comparison-Root.py',launcher.encode())
plan={'schema':'src06-future-completed-B-comparison-readiness.v1','status':'HELD READ-ONLY PREPARATION; no completed Source B receipt exists or is claimed here','author_Source':ref(Path(__file__)),'canonical_public_comparator':ref(tool),'held_Regular_RDD_reader_proposal':proposed,'proposal_forward_diff':forward,'proposal_inverse_diff':inverse,'unchanged_numeric_comparison_and_all_other_functions_AST_exact':True,'only_reader_and_private_ROOT_relocation_changes':True,'Root_only_future_launcher':lr,'case':case,'case_scope':ref(scopep),'case_metadata':ref(checked(case['metadata'])),'original_policy':ref(policy),'original_policy_revision':'2fffe68fb9131c80efcd3232de3a81d5290045c6','actual_retained_Native_receipt':ref(np),'actual_retained_Native_command':cmd,'Native_inventory':native_inventory,'accepted_Native39_baseline_bridge':ref(bridgep),'Native_bridge_metrics':bridge['metrics'],'Native_baseline_custody_qualification':bridge['input_custody_qualification'],'Regular_dictionary_Native_authority':authority,'pure_metadata_read_checks':{'existing_IDF_only_reader_rejects_true_B_Regular_RDD':old_failed,'Regular_reader_parses_all382_native_declarations':True,'all102_selected_ESO_declarations_join_actual_Regular_RDD':True,'unchanged_IDF_reader_result_on_actual_A_RDD':True},'expected_completed_B':{'series':102,'samples':9792,'zone_steps':96,'weather_environments':1,'meter_series':0,'Native_MTR_actually_absent':True,'Source_MTR_zero_counter_and_deleted_empty_ownership_must_be_observed_not_inferred':True},'next_actual_validation_steps':[{'operation':'Run held strict reported comparison after actual B0 only','command':['python',lr['path'],'--source-receipt','FUTURE_ACTUAL_B0_RECEIPT','--source-receipt-sha256','FUTURE_SHA','--output','.runtime/porting/SRC-06/completed-B-NOLIMIT-24H-reported-Root-NN'],'checks':'Physical dictionary/report IDs/key/name/unit/StoreType/frequency, exact raw Native environment/timestamp tuples and record order/footer/EOF, original point atol/rtol and sequential per-series RMSE. No policy or formula changes.'},{'operation':'Full own JSON/CSV roundtrip after same genuine B0','source_reuse':ref(D/'check-actual-Source82-export-roundtrip-Peer-01.py'),'source_reuse_scope':'Reuse parse_stream and exact raw token/binary64/native-tuple/index/physical-line CSV comparisons; adapt counts only to actual B102*96=9792 and genuine deleted-empty MTR. Preserve Source-specific envelope/no Legacy keys; CSV source-mtr.csv must contain header only and JSON mtr must carry deleted_empty=true/zero rows with actual zero Source owner counter. A5352 proof is not B9792 evidence.','report_fields':'Validate all9792 JSON value bits/raw operands/timestamp indices/environment tuples against own completed ESO, and both CSV files/summary owner catalog StoreType/frequency. Do not compare JSON numeric internal history or collapse frequencies.'},{'operation':'Whole ancillary inventory and all uncapped physical differences','Native_files':[x['suffix'] for x in native_inventory],'checks':'Compare every shared audit/BND/EIO/RDD/MDD/MTD/SHD/ERR/END physical row and line ending, preserve absent/extra files and every raw mismatch uncapped. Classify only exact producer-version/owned clock metadata after observing actual pairs. B has no Native tabular files; record future Source table absence/extra presence, never borrow A19312 table proof. Native END elapsed time and ERR diagnostic payloads require explicit qualification. Runtime/Source diagnostics and support artifacts are separate from Native file-name inventory.'}],'scope_limits':['Original tool is NOT currently B-ready unchanged due to true Regular dictionary format. This held proposal is not promoted or executed as a completed comparison.','Native39 and installed B12 ESO102/9792 whole bodies match after only their actual ProgramVersion clocks. That is Native-vs-Native evidence, not Source B conformance.','Historical B12 receipt has actual0 input/weather argv but does not independently record historical IDD bytes/INI absence; retain accepted bridge qualification verbatim.','Ancillary physical IO and exported own JSON/CSV are outside the public reported comparator; they must be verified separately for first B0.','Inherited A58/5352 tolerance and serialization proof is separate and cannot certify B102/9792. No full finite15/12B/card/gate completion is inferred.'],'Source_B_completed_claimed':False,'new_test_bodies':0,'canonical_Source_or_policy_mutations':0,'Cargo_Source_CLI_or_Native_executed':False}
print(json.dumps({'plan':dump('plan.json',plan),'held_reader':proposed,'Root_future_launcher':lr,'no_B_completion_claim':True}))

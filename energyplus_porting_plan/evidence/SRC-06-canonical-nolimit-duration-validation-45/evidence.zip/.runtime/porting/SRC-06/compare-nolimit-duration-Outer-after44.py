"""Root-only read-only adapter to the unchanged Regular strict stream comparer."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3]
def checked(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256']and len(b)==row.get('bytes',len(b));return p
def argument(value):
 path,sha=value.rsplit('#',1);return dict(path=(R/path).resolve().relative_to(R).as_posix(),sha256=sha)
def main(a):
 plan=json.loads(checked(argument(a.plan)).read_bytes());tool=checked(plan['strict_Regular_reported_comparer']);checked(plan['unchanged_output_policy']);assert a.case in{c['case']for c in plan['cases']}
 source,native=argument(a.source_receipt),argument(a.native_receipt)
 for row in(source,native):
  run=json.loads(checked(row).read_bytes());assert run['exit_code']==0 and run['launch_error']is None and run['source_bytes_match_before_and_after']
  assert any(Path(v).resolve()==checked(next(c['input']for c in plan['cases']if c['case']==a.case))for v in run['command']if v.lower().endswith('.idf'))
 # All declaration/clock/identity/footer/full-value/count/unchanged tolerance and
 # sequential RMSE acceptance stays inside the whole authenticated old tool.
 return subprocess.call([sys.executable,str(tool),'--case',a.case,'--source-receipt',str(checked(source)),'--source-receipt-sha256',source['sha256'],'--native-receipt',str(checked(native)),'--native-receipt-sha256',native['sha256'],'--output',str((R/a.output).resolve())],cwd=R)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--case',choices=['B-NOLIMIT-72H','B-NOLIMIT-ANNUAL'],required=True);p.add_argument('--source-receipt',required=True);p.add_argument('--native-receipt',required=True);p.add_argument('--output',required=True);raise SystemExit(main(p.parse_args()))

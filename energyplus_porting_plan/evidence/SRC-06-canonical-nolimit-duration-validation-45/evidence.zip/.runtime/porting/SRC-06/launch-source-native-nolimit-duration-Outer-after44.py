"""Root-only future Source/installedNative duration launch; no implicit run."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 p=p.resolve();h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=p.relative_to(R).as_posix(),sha256=h.hexdigest(),bytes=p.stat().st_size)
def checked(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R);r=ref(p);assert r['sha256']==row['sha256']and r['bytes']==row.get('bytes',r['bytes']);return p
def argument(value):
 path,sha=value.rsplit('#',1);r=ref((R/path).resolve());assert r['sha256']==sha;return r
def main(a):
 assert a.execute,'Root explicit --execute is required';pr=argument(a.plan);plan=json.loads(checked(pr).read_bytes());assert ref(Path(__file__))==plan['launch_Source']
 assert re.fullmatch(r'Root-[0-9]+(?:-[A-Za-z0-9]+)*',a.run_label)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==plan['base_HEAD']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
 actual=json.loads(checked(plan['accepted44_actual_review']).read_bytes());assert actual['accepted']and actual['B_Source_completed']and not actual['findings']
 source_plan=json.loads(checked(plan['complete_compiler_plan']).read_bytes());assert(source_plan['compiler_inputs'],source_plan['Rust_sources'])==(4511,4498)
 inventory={p.relative_to(R).as_posix()for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix()for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
 assert inventory=={r['path']for r in source_plan['entries']}
 for row in source_plan['entries']:
  p=R/row['path'];r=ref(p);assert(r['sha256'],r['bytes'])==(row['final_sha256'],row['final_bytes']),row['path']
 case=next(v for v in plan['cases']if v['case']==a.case)
 for key in ('input','metadata','weather'):checked(case[key])
 for key in ('input','metadata'):
  row=case[key];assert subprocess.check_output(['git','show',plan['base_HEAD']+':'+row['path']],cwd=R)==checked(row).read_bytes()
 checked(plan['calendar_contract']);metadata=json.loads(checked(case['metadata']).read_bytes());assert(metadata['id'],metadata['scope'],metadata['duration'],metadata['limit_variant'])==(a.case,'B',case['duration'],'NOLIMIT')
 assert metadata['expected_zone_steps_excluding_warmup']==case['expected_zone_steps_excluding_warmup']
 assert metadata['input']['sha256']==case['input']['sha256']and metadata['weather']['sha256']==case['weather']['sha256']
 before=[ref(checked(v))for v in plan['installed_runtime_pins']]
 kind='source'if a.engine=='Source'else'native-installed'
 stem=f'{kind}-nolimit-duration-{a.case}';out=D/f'{stem}-{a.run_label}/output';receipt=D/f'{stem}-command-{a.run_label}';custody=D/f'{stem}-custody-{a.run_label}'
 assert not out.parent.exists()and not receipt.exists()and not custody.exists()
 env=dict(os.environ)
 if a.engine=='Source':
  parent=json.loads(checked(actual['actual_B']).read_bytes());assert parent['exit_code']==0 and parent['source_bytes_match_before_and_after']
  cmd=list(parent['command']);old_input=next(v for v in cmd if v.lower().endswith('.idf'));assert old_input.endswith('/cases/B-NOLIMIT-24H/input.idf')
  cmd[cmd.index(old_input)]=checked(case['input']).as_posix();cmd[cmd.index('--weather')+1]=checked(case['weather']).as_posix();cmd[cmd.index('--output-dir')+1]=out.as_posix()
  assert cmd[cmd.index('--porting-scope')+1]=='B'and '--hours'not in cmd and not{'test','--all-targets','--oracle-baseline','--compare-oracle'}&set(cmd)
  target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve();assert target.is_dir();env['CARGO_TARGET_DIR']=str(target);env['CARGO_INCREMENTAL']='0'
  for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'):assert env.get(key)is None,key
 else:
  parent=json.loads(checked(plan['Native12_B24_path_and_version_witness']).read_bytes());assert parent['exit_code']==0 and parent['launch_error']is None
  exe=checked(plan['installed_executable']);assert Path(parent['command'][0]).resolve()==exe
  cmd=[exe.as_posix(),'--idd',checked(plan['explicit_IDD']).as_posix(),'--weather',checked(case['weather']).as_posix(),'--output-directory',out.as_posix(),'--output-prefix','energyplus',checked(case['input']).as_posix()]
 command=[sys.executable,'tools/porting/record_command.py','--output-dir',receipt.relative_to(R).as_posix(),'--',*cmd]
 print(f'Root-only {a.engine} {a.case}: full case scope, fresh paths, no comparison or gate update',flush=True)
 code=subprocess.call(command,cwd=R,env=env)
 after=[ref(checked(v))for v in plan['installed_runtime_pins']];assert before==after
 for key in ('input','metadata','weather'):checked(case[key])
 rr=ref(receipt/'receipt.json');run=json.loads(checked(rr).read_bytes());assert run['exit_code']==code and run['launch_error']is None and run['source_bytes_match_before_and_after']
 custody.mkdir();result=dict(schema='src06-nolimit-duration-launch-custody.v1',engine=a.engine,case=a.case,launcher_Source=ref(Path(__file__)),input_plan=pr,command_receipt=rr,exit_code=code,installed_runtime_before=before,installed_runtime_after=after,installed_runtime_bytes_exact_before_and_after=True,case_input=case['input'],case_metadata=case['metadata'],weather=case['weather'],explicit_IDD=plan['explicit_IDD'],actual44_production_code_wholes_checked=True,expected_zone_steps_excluding_warmup=case['expected_zone_steps_excluding_warmup'],comparison_executed=False,Native_duration_baseline_established_by_preparation=False,module_loading_claim=False,qualification='Only the real recorded command establishes execution. Current installed exe/API/top-level DLL/IDD/schema pins are checked before and after; this is not a loaded-module trace or a fabricated historical B12 binary hash. Source receives runtime/IDD/weather and its own case only, never Native result files. No numerical/ancillary/gate claim is supplied by this launcher.')
 p=custody/'custody.json';p.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(ref(p)));return code
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--engine',choices=['Source','Native'],required=True);p.add_argument('--case',choices=['B-NOLIMIT-72H','B-NOLIMIT-ANNUAL'],required=True);p.add_argument('--run-label',required=True);p.add_argument('--execute',action='store_true');raise SystemExit(main(p.parse_args()))

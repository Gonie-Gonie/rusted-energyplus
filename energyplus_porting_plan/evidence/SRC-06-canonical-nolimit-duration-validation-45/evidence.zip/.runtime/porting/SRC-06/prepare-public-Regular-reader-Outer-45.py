"""Isolated one-function public Regular RDD reader proposal; no public writes."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'public-Regular-reader-held-Outer-45'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def fn(source,name):
 t=ast.parse(source);n=next(v for v in t.body if isinstance(v,ast.FunctionDef)and v.name==name);return b''.join(source.splitlines(True)[n.lineno-1:n.end_lineno])
def main():
 assert not O.exists();p=R/'tools/porting/check_completed_reported_streams.py';held=D/'completed-B-comparison-ready-Audit-01/proposed/tools/porting/check_completed_reported_streams.py';a=p.read_bytes();b=held.read_bytes()
 assert ref(p)['sha256']=='46a1b6f9081d9a0ff5a2d430b17ec647b88a41f5052c3bb1c95df98174ab754c'and ref(held)['sha256']=='1f0fd5053748210d812201957ec9e1ae56e8712e0082a2c9b7cdac3cba79e7b8'
 old,new=fn(a,'available_variables'),fn(b,'available_variables');assert a.count(old)==1;out=a.replace(old,new);assert out.replace(new,old)==a and fn(out,'available_variables')==new
 ta,tb=ast.parse(a),ast.parse(out);fa={v.name:ast.dump(v,include_attributes=False)for v in ta.body if isinstance(v,ast.FunctionDef)};fb={v.name:ast.dump(v,include_attributes=False)for v in tb.body if isinstance(v,ast.FunctionDef)};assert fa.keys()==fb.keys()and{k for k in fa if fa[k]!=fb[k]}=={'available_variables'}
 ta.body=[v for v in ta.body if not isinstance(v,ast.FunctionDef)or v.name!='available_variables'];tb.body=[v for v in tb.body if not isinstance(v,ast.FunctionDef)or v.name!='available_variables'];assert ast.dump(ta,include_attributes=False)==ast.dump(tb,include_attributes=False)
 fw=''.join(difflib.unified_diff(a.decode().splitlines(True),out.decode().splitlines(True),fromfile=p.relative_to(R).as_posix(),tofile=p.relative_to(R).as_posix())).encode();iv=''.join(difflib.unified_diff(out.decode().splitlines(True),a.decode().splitlines(True),fromfile=p.relative_to(R).as_posix(),tofile=p.relative_to(R).as_posix())).encode()
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'literal','exec'),ns);assert ns['apply'](a,fw)==out and ns['apply'](out,iv)==a
 manifest=dict(schema='src06-public-Regular-RDD-reader-one-function-proposal.v1',status='HELD_NO_PUBLIC_MUTATION',author_Source=ref(Path(__file__)),canonical_path=p.relative_to(R).as_posix(),canonical_before=ref(p),before=put(O/'before/tools/porting/check_completed_reported_streams.py',a),proposed=put(O/'proposed/tools/porting/check_completed_reported_streams.py',out),held_Regular_comparator=ref(held),forward_diff=put(O/'forward.diff',fw),inverse_diff=put(O/'inverse.diff',iv),only_available_variables_function_changed=True,available_variables_whole_exact_held=True,all_other_functions_numeric_parser_API_and_module_AST_exact=True,canonical_ROOT_parents2_whole_unchanged=True,all_other_canonical_bytes_restored_by_one_function_inverse=True,new_tests=0,policy_changes=0,Cargo_Native_Source_commands_executed=False)
 q=O/'manifest.json';put(q,(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(dict(manifest=ref(q),proposed=manifest['proposed'])))
if __name__=='__main__':main()

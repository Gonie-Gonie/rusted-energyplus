from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-Node-lifecycle-application-16';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-positive-Node-lifecycle-held-Peer-01/manifest.json');assert mr['sha256']=='d847033281222cf9a0461bd2f73b533024af03dea42beb784a5f70aa6e8c7f15';m=json.loads(checked(mr))
pr=ref(R/sys.argv[1]);assert pr['sha256']==sys.argv[2];peer=json.loads(checked(pr));assert(peer.get('accepted') is True or peer.get('status')=='accepted') and not peer['findings'];assert mr in [v for v in peer.values() if isinstance(v,dict)]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='017cf481d81f553dbd3b656e9ea66eec3913252b' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
assert m['new_test_bodies']==0 and not m['Cargo_Native_or_tests_executed'] and not m['Native_answer_production_inputs']
parents={v['historical_path']:v for v in json.loads(checked(m['actual15_snapshot']))['files']}
inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4486 and set(parents)==inventory
for n,v in parents.items():assert(R/n).read_bytes()==checked(v['archive']) and(R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a,b=checked(f['before']),checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
 if f['before_absent']:assert not(R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and(R/n).stat().st_nlink==1
 assert f['parse']['exit_code']==0;checked(f['parse']['stdout']);checked(f['parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==13 and len(new)==1 and tests==0
native=R/'.reference/energyplus-src/26.1.0';rev='6f2e40d10250a105b49966baa24d843711e61048';wholes={}
for v in m['Native_wholes']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',rev+':'+v['Native_path']],cwd=native);wholes[v['Native_path']]=b
for v in m['Native_strict_extents']:assert b''.join(wholes[v['Native_path']].splitlines(keepends=True)[v['first_line']-1:v['last_line']])==checked(v['strict_extent'])
for f in m['context']:assert checked(f['frozen'])==(R/f['canonical_path']).read_bytes()==checked(f['actual15_archive'])==subprocess.check_output(['git','show',head+':'+f['canonical_path']],cwd=R)
for k in ['Native34_declarations','ResetNodeData_assignment_ledger','Root_closed_volume_component','private_API_and_test_caller_inventory','accepted_Root_actual15_review']:checked(m[k])
plan=json.loads(checked(m['complete_compiler_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4487 and sum(n.endswith('.rs') for n in rows)==4474
for n,v in rows.items():
 b=checked(v['final_source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'];assert b==(checked(selected[n]['proposed']) if n in selected else(R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert(R/n).read_bytes()==checked(v['final_source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,complete_compiler_plan=m['complete_compiler_plan'],selected=selected,original_parent_inputs=4486,final_inputs=4487,final_Rust_sources=4474,selected_Rust=13,new_Rust=1,literal_applications=26,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read Node34 declaration/Which/live output code, actual file/backend/flag/caller diffs, reset19+6 Native field assignments and genuine initial-enclosure volume branch. Same real owners/registration/files and signed arithmetic; no diagnostic projection, native result injection, readiness bypass, extra winding gate or reset whole-record clone. Full independent thirteen-Source peer accepted before application.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

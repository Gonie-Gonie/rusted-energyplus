"""Root-actual-bound preparation only; no canonical files are written here."""
from pathlib import Path
import argparse, ast, hashlib, json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';READY=D/'Node-lifecycle-publication-prepared-Audit-16'
def ref(path):
 path=path.resolve();raw=path.read_bytes();return dict(path=path.relative_to(R).as_posix(),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def main(args):
 assert not READY.exists();inputs={}
 def add(path):
  row=ref(path);assert path.suffix.lower()!='.zip';inputs[row['path']]=row;return row
 def addref(row):
  got=add(R/row['path']);assert got['sha256']==row['sha256']and got['bytes']==row.get('bytes',row.get('size_bytes',got['bytes']));return row
 producer_path=D/'source-positive-Node-lifecycle-held-Peer-01/manifest.json';producer_ref=add(producer_path)
 assert producer_ref['sha256']=='d847033281222cf9a0461bd2f73b533024af03dea42beb784a5f70aa6e8c7f15'
 producer=json.loads(producer_path.read_bytes())
 peer_path=D/'Audit-positive-Node-lifecycle-coherent-Source-review-16/review.json';peer_ref=add(peer_path)
 assert peer_ref['sha256']=='c6fc2acade986737f7c0c6617aebd4227604f149bef8e9515fe7fbcc36416a08'
 peer=json.loads(peer_path.read_bytes());assert peer['accepted']and not peer['findings'];addref(peer['reviewer_Source'])
 addref(producer['complete_compiler_plan']);plan=json.loads((R/producer['complete_compiler_plan']['path']).read_bytes())
 assert plan['planned_inputs']==4487 and plan['planned_Rust']==4474 and len(plan['selected_paths'])==13
 addref(producer['sealer_Source'])
 for key in ['Native34_declarations','ResetNodeData_assignment_ledger','private_API_and_test_caller_inventory','Root_closed_volume_component']:addref(producer[key])
 volume=json.loads((R/producer['Root_closed_volume_component']['path']).read_bytes());addref(volume['author_Source'])
 for row in producer['files']:
  for key in ['before','proposed','forward_diff','inverse_diff']:addref(row[key])
 for row in producer['Native_strict_extents']:addref(row['strict_extent'])
 for row in producer['context']:addref(row['frozen'])
 application_path=D/'Root-Node-lifecycle-application-16/receipt.json';application_ref=add(application_path)
 assert application_ref['sha256']=='dca9b7ef4ae428e88b80e61f31a21c674dd66f943dad064aebccc3740247c4a9'
 application=json.loads(application_path.read_bytes());assert application['accepted']and not application['findings'];addref(application['author_Source'])
 fixture=add(R/'crates/ep_runtime/src/heat_balance/fixtures/ordinary_equipment_native_selected.json')
 previous=add(R/'energyplus_porting_plan/evidence/SRC-06-canonical-controlled-equipment-15/summary.json')
 publisher_path=D/'publish-Node-lifecycle-checkpoint-Audit-16-template.py';ast.parse(publisher_path.read_text(encoding='utf-8'));publisher=add(publisher_path);author=add(Path(__file__))
 actual_path=D/'Root-source-Node-lifecycle-actual-review-16/review.json';actual_ref=add(actual_path);assert actual_ref['sha256']==args.actual_sha
 actual=json.loads(actual_path.read_bytes());assert actual['accepted']and not actual['findings']
 for key in ['author_Source','accepted15_full5352_proof','unchanged_original_tolerance_policy','comparison_helper_Source']:addref(actual[key])
 validation=dict(Root_actual_review=actual_ref,test=actual['actual_owner_test'],B_CLI=actual['actual_B'],A24_CLI=actual['actual_A24'])
 for label,run in [('B','canonical-source-Node-lifecycle-B-NOLIMIT-24H-Root-16'),('A24','canonical-source-Node-lifecycle-A-24H-Root-16')]:
  for suffix,name in [('summary','run-summary.json'),('diagnostics','diagnostics.json')]:
   row=ref(D/run/'output'/name);assert row in actual['publication_artifacts'];validation[label+'_'+suffix]=row
 required=['same4487_archived_inputs_exact_final_plan','selected13_final_sources_exact','first_B_core_fresh_false','A24_same_core_reused_fresh_true','original_tolerance_RMSE_5352_proof_transferred','whole_JSON_equal15_after_exactly_two_owned_path_field_bridges','full_runtime_equal15_after_two_owned_path_bridges']
 assert all(actual[key]is True for key in required)
 transfer=dict(series=58,samples=5352,unchanged_policy=actual['unchanged_original_tolerance_policy'],accepted15_proof=actual['accepted15_full5352_proof'],physical_files_whole_equal15=len(actual['whole_physical_streams_equal15']),CSV_files_whole_equal15=len(actual['whole_CSV_equal15']),table_lines=actual['table_lines'],clock_only_line_changes_versus15=actual['table_clock_metadata_changes'],scope='Transfer from accepted15 output evidence; no new Native/72h/annual execution or internal-state equivalence claim.')
 assert transfer['physical_files_whole_equal15']==7 and transfer['CSV_files_whole_equal15']==2 and transfer['table_lines']==19312
 execution=actual['B_Node_lifecycle_execution']
 template=dict(schema='src06-held-canonical16-publication-template.v1',status='HELD_READY_FOR_ROOT_REVIEW',base_HEAD=producer['base_HEAD'],producer=producer_ref,independent_peer=peer_ref,complete_plan=producer['complete_compiler_plan'],application=application_ref,existing_test_JSON_fixture=fixture,previous_checkpoint=previous,publisher_Source=publisher,actual_review=actual_ref,required_true_actual_predicates=required,actual_B_frontier=actual['B_frontier'],actual_A24_proof_transfer=transfer,actual_preceding_B_returns=execution,
  summary_template=dict(A='14/54',B='14/64',changed_Rust_sources=13,existing_Rust_sources=12,new_Rust_sources=1,new_test_functions=0,existing_test='actual_native_get_equipment_pair_and_input_owner_transitions',test_scope='One existing Native uncontrolled pair7 plus real input/owner transitions; not positive Node lifecycle Native paired state validation or all8 fixture cases.',existing_included_JSON_fixture=fixture,fixture_snapshot_scope='Existing rs/Cargo recorder omits this included JSON, which is separately Git/current bound and directly archived; no recorder change.',producer=producer_ref,independent_peer=peer_ref,complete_compiler_plan=producer['complete_compiler_plan'],Root_volume_component=producer['Root_closed_volume_component'],focused_validation_policy='One meaningful existing runtime test build plus actualCLI B/A24; no new helper tests or habitual separate workspace-all-targets check.',scope='Retain actual initial enclosure and signed volume calculation/user-volume branches while removing an extra Rust-only admission. Genuine sole-owner Node reporting declarations/live values/stream borrows and19+6 field reset are authored; actual reach and next boundary are reported solely by the accepted Root aggregate.',full_B_or_finite15_completion_claim=False,gate_changes=False),
  doc_appends={
   'CHECKLIST.md':'체적·Node 경로를 연결하고 기존 소유권 테스트와 A-24H 회귀를 통과했습니다. B의 실제 다음 경계는 증빙 요약에 기록했으며 A14/54·B14/64 게이트는 유지합니다.',
   'STATE_CONTRACTS.md':'체적 계산은 Native의 최초 폐쇄 판정·부호와 양수 사용자 입력값 처리를 보존합니다. Node 보고는 같은 물리 필드·실제 스트림을 참조하고, 초기화는 지정된19+6개 필드만 갱신합니다.',
   'cards/SRC-06.md':'Native에 없는 추가 체적 입장 조건을 제거하고 같은 Node 소유자의 보고 등록·실제 값 참조·필드 초기화를 연결했습니다. 기존 Native 비제어 입력1쌍(pair7)·소유권 전이 테스트와 A-24H 회귀를 통과하고 보고값5,352개의 기존 검증을 유지했습니다. B의 실제 미완료 경계는 `'+actual['B_frontier']+'`입니다. Node setup/reset의 실제 도달 범위는 증빙 요약을 따르며, 내부 상태의 Native 대조와 후속 B 포팅은 남아 있습니다. 게이트는 A14/54·B14/64를 유지합니다.'},
  targets=['energyplus_porting_plan/evidence/SRC-06-canonical-Node-lifecycle-16/'+name for name in ['summary.json','manifest.json','evidence.zip']],append_existing_docs=['energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/cards/SRC-06.md'],plan_add_only='SRC-06.canonical_Node_lifecycle_16',finite_archive_inputs=[row for name,row in sorted(inputs.items())],finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(row['bytes']for row in inputs.values()),author_Source=author,publisher_executed=False,canonical_docs_mutations=False,Cargo_tests_Native_executed=False,gate_changes=False)
 READY.mkdir();validation_path=READY/'validation-refs.json';validation_path.write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8',newline='\n');target=READY/'publication-template.json';target.write_text(json.dumps(template,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(dict(template=ref(target),publisher=publisher,validation=ref(validation_path),archive_inputs=len(inputs),archive_raw_bytes=template['finite_archive_input_bytes'])))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--actual-sha',required=True);main(parser.parse_args())

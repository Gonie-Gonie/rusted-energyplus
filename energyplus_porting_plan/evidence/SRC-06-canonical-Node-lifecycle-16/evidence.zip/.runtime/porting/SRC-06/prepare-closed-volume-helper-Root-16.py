from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-closed-volume-helper-held-Root-16';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 b=(R/v['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='017cf481d81f553dbd3b656e9ea66eec3913252b' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
br=ref(D/'canonical-source-controlled-equipment-B-NOLIMIT-24H-command-Root-15/receipt.json');assert br['sha256']=='e661ad760789195dcf30804a4832d09a54118c7561e8da290380b0c92a422ad1';run=json.loads(checked(br));assert run['exit_code']==6 and run['source_bytes_match_before_and_after'];snapshot=json.loads(checked(run['source_snapshot']));parents={v['historical_path']:v for v in snapshot['files']}
n='crates/ep_runtime/src/heat_balance/selected_heat_balance_input/surface/setup_volume.rs';before=(R/n).read_bytes();assert before==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R)
a=b'    InitializedZoneGeometry, ZoneGeometryProperties, bounded_topology_rejection, initial_enclosure,\n';b=b'    InitializedZoneGeometry, ZoneGeometryProperties, initial_enclosure,\n';assert before.count(a)==1;after=before.replace(a,b,1)
a=b'''            diagnostics.topology_rejection =
                bounded_topology_rejection(&numeric.faces, &diagnostics);
            if diagnostics.topology_rejection.is_some() {
                // Six faces and consistent winding/positive signed volume are
                // conservative Rust admission, not extra Native enclosure tests.
                return Err(Error::Unavailable(
                    "selected initially-closed six-quad volume domain",
                ));
            }
'''
b=b'''            // Native's initially enclosed branch consumes the signed result
            // directly, then retains a positive user-entered Zone.Volume.
            // Face count and winding are not additional Native enclosure tests.
'''
assert after.count(a)==1;after=after.replace(a,b,1);assert after.count(b'#[test]')==before.count(b'#[test]')
O.mkdir();refs={}
for k,data in [('before',before),('proposed',after),('literal_inverse',before)]:
 p=O/k/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);refs[k]=ref(p)
for k,x,y in [('forward_diff',before,after),('inverse_diff',after,before)]:
 p=O/(k+'.diff');p.write_bytes(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile='before/'+n,tofile='proposed/'+n)).encode());refs[k]=ref(p)
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
assert apply(before,checked(refs['forward_diff']))==after and apply(after,checked(refs['inverse_diff']))==before
p=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True,cwd=R);assert p.returncode==0
q=O/'parse.stdout';q.write_bytes(p.stdout);stdout=ref(q);q=O/'parse.stderr';q.write_bytes(p.stderr);stderr=ref(q)
native=R/'.reference/energyplus-src/26.1.0';rev='6f2e40d10250a105b49966baa24d843711e61048';wholes=[];extents=[]
for name,spans in [('SurfaceGeometry.cc',[(12010,12322),(12325,12348)]),('Vectors.cc',[(505,529)]),('Vectors.hh',[(130,147)])]:
 q=native/'src/EnergyPlus'/name;data=q.read_bytes();assert data==subprocess.check_output(['git','show',rev+':src/EnergyPlus/'+name],cwd=native);v=ref(q);wholes.append(dict(Native_path='src/EnergyPlus/'+name,revision=rev,whole_source=v))
 for first,last in spans:
  p=O/'Native'/(name+'.L'+str(first)+'-'+str(last)+'.txt');p.parent.mkdir(exist_ok=True);p.write_bytes(b''.join(data.splitlines(keepends=True)[first-1:last]));extents.append(dict(Native_path='src/EnergyPlus/'+name,whole_source=v,first_line=first,last_line=last,literal_excerpt=ref(p)))
contexts=[]
for n2 in ['crates/ep_runtime/src/geometry/zone_volume/topology.rs','crates/ep_runtime/src/geometry/zone_volume.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context/setup_zone_geometry.rs']:
 data=(R/n2).read_bytes();assert data==checked(parents[n2]['archive'])==subprocess.check_output(['git','show',head+':'+n2],cwd=R);p=O/'Source-context'/n2;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);contexts.append(dict(canonical_path=n2,whole_source=ref(p)))
m=dict(schema='src06-held-genuine-initially-closed-volume-admission.v1',base_HEAD=head,actual15_B=br,actual_parent_snapshot=run['source_snapshot'],files=[dict(canonical_path=n,before_absent=False,**refs,Source_only_parse=dict(exit_code=0,stdout=stdout,stderr=stderr))],Native_wholes=wholes,Native_literal_extents=extents,unchanged_contexts=contexts,literal_applications=2,new_test_bodies=0,Cargo_Native_or_tests_executed=False,main_mutations=0,FP_or_tolerance_changes=False,
 scope='Source CalculateZoneVolume already executes genuine initial enclosure and signed polyhedron helpers, followed by Native user-volume/height/calculated branches. Remove an extra Rust-only bounded-topology admission check from this actual Source route. Legacy bounded_topology_rejection helper and callers remain unchanged. Same real Zone/Space writers, signed calculation, warning order, nonpositive final-volume typed boundary, debug typed boundary and initial-open/repair typed boundary remain byte-identical.',
 Native_reason='Native isEnclosedVolume returns true when every initial edge is used twice, independently of winding or six-quad counts. Its enclosed branch consumes CalcPolyhedronVolume signed result; subsequent positive entered Zone.Volume remains unchanged, with comparison warnings only when calculated>0. Negative calculated volume does not by itself invalidate positive user volume. No absolute value, winding repair, fabricated volume or tolerance adjustment.',
 execution_qualification='Actual15 stops at removed admission after actual initial closure returned. Next execution and exact Source state/Native equivalence are not claimed here. This helper is intended for cohesive16 final plan and real B/A24 verification.',author_Source=ref(Path(__file__).resolve()))
p=O/'manifest.json';p.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

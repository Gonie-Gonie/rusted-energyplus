"""Seal Node reporting/reset Sources only after Root's committed15 custody exists."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
P = 'crates/ep_runtime/src/heat_balance/'
OLD = 'b68a0060d750eac9c074adb0f8de5635f6e8039c'
draft = D / 'source-positive-Node-reporting-draft-Peer-01'
O = D / 'source-positive-Node-lifecycle-held-Peer-01'
parser = argparse.ArgumentParser()
parser.add_argument('--head', required=True)
parser.add_argument('--check', required=True)
parser.add_argument('--check-sha', required=True)
parser.add_argument('--actual', required=True)
parser.add_argument('--actual-sha', required=True)
parser.add_argument('--root-review', required=True)
parser.add_argument('--root-review-sha', required=True)
a = parser.parse_args()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
def check(row):
    path = R / row['path']; observed = ref(path)
    assert observed['sha256'] == row['sha256'] and observed['bytes'] == row.get('bytes', observed['bytes']), row
    return path
def authenticated(path, digest):
    row = ref(R / path)
    assert row['sha256'] == digest
    return row, json.loads(check(row).read_bytes())
def put(name, data):
    path = O / name; assert not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
    return ref(path)
def doc(name, obj):
    return put(name, (json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())
def git_blob(revision, path):
    return subprocess.check_output(['git', 'show', revision + ':' + path], cwd=R)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == a.head
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=R, text=True).strip() == a.head
check_ref, checked = authenticated(a.check, a.check_sha)
actual_ref, actual = authenticated(a.actual, a.actual_sha)
root_ref, root_review = authenticated(a.root_review, a.root_review_sha)
assert root_review['accepted'] and not root_review['findings']
assert checked['exit_code'] == 0 and checked['source_bytes_match_before_and_after']
assert actual['exit_code'] == 6 and actual['source_bytes_match_before_and_after']
assert actual_ref['sha256'] == 'e661ad760789195dcf30804a4832d09a54118c7561e8da290380b0c92a422ad1'
assert checked['source_snapshot']['sha256'] == actual['source_snapshot']['sha256']
snapshot_ref = ref(check(actual['source_snapshot']))
snapshot = json.loads(check(snapshot_ref).read_bytes())
observed = {row['historical_path']: row for row in snapshot['files']}
assert len(observed) == len(snapshot['files'])
assert len(observed) == 4486
paths = set((R / 'crates').rglob('*.rs')) | set((R / 'crates').rglob('Cargo.toml'))
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml']:
    if (R / name).is_file(): paths.add(R / name)
assert {p.relative_to(R).as_posix() for p in paths} == set(observed)
for p, row in observed.items():
    archived = check(row['archive']).read_bytes()
    assert len(archived) == row['size_bytes'] and archived == (R / p).read_bytes(), p
assert sum(p.endswith('.rs') for p in observed) == 4473
assert P + 'source_output_registration/report_diagnostics.rs' not in observed
assert not (R / (P + 'source_output_registration/report_diagnostics.rs')).exists()

summary_ref = ref(draft / 'draft.json')
summary = json.loads(check(summary_ref).read_bytes())
assert summary['Source_count'] == 12 and summary['new_sources'] == 1
assert summary['parse_exits'] == [0] * 12
volume_ref = ref(D / 'source-closed-volume-helper-held-Root-16/manifest.json')
assert volume_ref['sha256'] == '7ed149e0d5d628a1d6a9e8213bca5bf44fa0099f0afb297310b591a98c8d6400'
volume = json.loads(check(volume_ref).read_bytes())
assert volume['base_HEAD'] == a.head and volume['actual15_B']['sha256'] == actual_ref['sha256']
assert volume['actual_parent_snapshot']['sha256'] == snapshot_ref['sha256']
assert len(volume['files']) == 1 and volume['literal_applications'] == 2
volume_row = volume['files'][0]
assert volume_row['canonical_path'] not in {row['canonical_path'] for row in summary['files']}
author_rows = [*summary['files'], {'canonical_path': volume_row['canonical_path'], 'before': volume_row['before'], 'bytes': volume_row['proposed']['bytes'], 'sha256': volume_row['proposed']['sha256']}]
author_rows.sort(key=lambda row: row['canonical_path'])
assert not O.exists(); O.mkdir()
literal_node = next(node for node in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(node, ast.FunctionDef) and node.name == 'apply_literal')
namespace = {'re': re}
exec(compile(ast.Module(body=[literal_node], type_ignores=[]), '<own-literal-apply>', 'exec'), namespace)
files = []
for i, row in enumerate(author_rows, 1):
    p = row['canonical_path']
    is_volume = p == volume_row['canonical_path']
    new = check(volume_row['proposed']).read_bytes() if is_volume else (draft / 'proposed' / p).read_bytes()
    assert hashlib.sha256(new).hexdigest() == row['sha256'] and len(new) == row['bytes']
    before_absent = row['before'] is None
    if before_absent:
        assert p not in observed and not (R / p).exists()
        old = b''
    else:
        old = check(row['before']).read_bytes()
        assert old == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes()
        assert old == git_blob(a.head, p)
        if not is_volume: assert old == git_blob(OLD, p)
    forward = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile=p, tofile=p)).encode()
    inverse = ''.join(difflib.unified_diff(new.decode().splitlines(keepends=True), old.decode().splitlines(keepends=True), fromfile=p, tofile=p)).encode()
    if is_volume:
        forward = check(volume_row['forward_diff']).read_bytes()
        inverse = check(volume_row['inverse_diff']).read_bytes()
    assert namespace['apply_literal'](old, forward) == new
    assert namespace['apply_literal'](new, inverse) == old
    if is_volume:
        assert forward == check(volume_row['forward_diff']).read_bytes()
        assert inverse == check(volume_row['inverse_diff']).read_bytes()
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and not parsed.stderr
    files.append({'canonical_path': p, 'before_absent': before_absent, 'before': put('before/' + p, old), 'proposed': put('proposed/' + p, new),
        'actual15_archive': observed[p]['archive'] if p in observed else None, 'committed15_Git_and_actual15_and_live_before_equal': not before_absent,
        'historical14_Git_bridge_checked': not before_absent and not is_volume, 'component_packet': volume_ref if is_volume else summary_ref,
        'literal_inverse': put('literal-inverse/' + p, old), 'forward_diff': put(f'diffs/{i:02d}-forward.diff', forward), 'inverse_diff': put(f'diffs/{i:02d}-inverse.diff', inverse),
        'parse': {'exit_code': 0, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})

old_plan_ref = ref(D / 'positive-Node-reporting-read-only-plan-Peer-02/plan.json')
assert old_plan_ref['sha256'] == '10ebfd0d261a2a48dd9e8cd6e71c0b6bd493dd0951eb21ffb7d390b413ed4305'
old_plan = json.loads(check(old_plan_ref).read_bytes())
context_paths = {row['path'] for row in old_plan['sources']}
context_paths |= {P + q for q in ['ordinary_equipment/source_nodes.rs', 'ordinary_hvac_manager/owners.rs', 'source_output_registration/general_real.rs',
    'source_output_registration/requested_input.rs', 'selected_heat_balance_globals.rs', 'selected_heat_balance_input.rs',
    'ordinary_source_simulation/primary_host.rs', 'error_backend/scoped.rs']}
context_paths |= {row['canonical_path'] for row in volume['unchanged_contexts']}
selected = {row['canonical_path']: row for row in files}
context = []
for p in sorted(context_paths - set(selected)):
    data = check(observed[p]['archive']).read_bytes()
    assert data == git_blob(a.head, p) == (R / p).read_bytes()
    context.append({'canonical_path': p, 'actual15_archive': observed[p]['archive'], 'committed15_Git_and_live_equal': True, 'frozen': put('context/' + p, data)})

native_paths = ['NodeInputManager.cc', 'NodeInputManager.hh', 'DataLoopNode.hh', 'OutputProcessor.cc', 'DataGlobalConstants.hh', 'SimulationManager.cc', 'UtilityRoutines.cc', 'HVACManager.cc', 'SurfaceGeometry.cc', 'Vectors.cc', 'Vectors.hh']
native, native_bytes, extents = [], {}, []
for name in native_paths:
    p = 'src/EnergyPlus/' + name
    data = subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N)
    assert data == (N / p).read_bytes()
    native_bytes[name] = data
    native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, data)})
for name, first, last in [('NodeInputManager.cc', 188, 514), ('DataLoopNode.hh', 66, 96), ('DataLoopNode.hh', 439, 555),
    ('OutputProcessor.cc', 3003, 3144), ('DataGlobalConstants.hh', 371, 482), ('SimulationManager.cc', 278, 326),
    ('UtilityRoutines.cc', 360, 405), ('HVACManager.cc', 2151, 2197)]:
    data = b''.join(native_bytes[name].splitlines(keepends=True)[first - 1:last])
    extents.append({'Native_path': 'src/EnergyPlus/' + name, 'first_line': first, 'last_line': last, 'strict_extent': put(f'Native/{name}-{first}-{last}.txt', data)})
for row in volume['Native_wholes']:
    assert check(row['whole_source']).read_bytes() == native_bytes[Path(row['Native_path']).name]
for row in volume['Native_literal_extents']:
    name, first, last = Path(row['Native_path']).name, row['first_line'], row['last_line']
    data = b''.join(native_bytes[name].splitlines(keepends=True)[first - 1:last])
    assert data == check(row['literal_excerpt']).read_bytes()
    extents.append({'Native_path': row['Native_path'], 'first_line': first, 'last_line': last, 'strict_extent': put(f'Native/{name}-{first}-{last}.txt', data)})
for row in volume['unchanged_contexts']:
    assert check(row['whole_source']).read_bytes() == check(observed[row['canonical_path']]['archive']).read_bytes()
ledger = json.loads(check(old_plan['Native34_ledger']).read_bytes())
assert len(ledger) == 34
ledger_ref = doc('Native34-declaration-and-live-owner-ledger.json', ledger)
reset_ref = doc('ResetNodeData-assignment-ledger.json', summary['reset_scope'])
entries = []
for p in sorted(set(observed) | set(selected)):
    before = observed.get(p)
    after = selected[p]['proposed'] if p in selected else before['archive']
    entries.append({'path': p, 'before_sha256': before['archive']['sha256'] if before else None, 'before_bytes': before['size_bytes'] if before else None,
        'final_sha256': after['sha256'], 'final_bytes': after.get('bytes', before['size_bytes'] if before else None), 'final_source': after, 'selected': p in selected})
assert len(entries) == 4487 and sum(row['path'].endswith('.rs') for row in entries) == 4474
plan_ref = doc('complete-compiler-Source-plan.json', {'base_HEAD': a.head, 'actual15_snapshot': snapshot_ref,
    'before_inputs': len(observed), 'before_Rust': sum(p.endswith('.rs') for p in observed), 'planned_inputs': len(entries), 'planned_Rust': sum(row['path'].endswith('.rs') for row in entries),
    'selected_paths': sorted(selected), 'entries': entries})

# Whole-crates/test inventory. No test is authored or executed here.
patterns = ['setup_source_node_variables_for_reporting', 'reset_source_node_data', 'LiveReadFields {', 'LiveReadView {', 'SourceAllOutputOwners {', 'SourceNonFacilityOutputOwners {', 'SourceCombinedOutputOwners {', 'SourceOutputUnits', 'SourceRealOutputTarget', 'match target']
hits = []
for p in sorted(path for path in observed if path.endswith('.rs')):
    data = check(observed[p]['archive']).read_text(encoding='utf-8')
    for number, line in enumerate(data.splitlines(), 1):
        matched = [pattern for pattern in patterns if pattern in line]
        if matched: hits.append({'path': p, 'line': number, 'text': line, 'patterns': matched})
inventory_ref = doc('whole-crates-private-API-and-test-caller-inventory.json', {'Rust_files_read': 4473, 'scope': 'all crates including runtime/tests; complete actual15 archive/live byte equality authenticated above', 'hits': hits,
    'adapters': 'All three actual LiveReadFields constructors and one LiveReadView construction are changed in held Sources. Setup has one production caller; reset caller API is unchanged. No existing test constructor requires an adapter and no new test body is added.'})
manifest = {'schema': 'src06-held-closed-volume-positive-Node-lifecycle.v1', 'status': 'HELD Source only; Root application/compilation/actual and independent full Source peer pending',
    'base_HEAD': a.head, 'historical14_HEAD': OLD, 'actual15_check': check_ref, 'actual15_B': actual_ref, 'accepted_Root_actual15_review': root_ref, 'actual15_snapshot': snapshot_ref,
    'actual15_observed_frontier': 'GetHeatBalanceInput: selected initially-closed six-quad volume domain',
    'execution_qualification': 'Actual15 passes EquipmentData/wrapper but stops in earlier geometry. Positive SetupNodeVarsForReporting and positive ResetNodeData are authored downstream Source, not executed or Native-paired in this packet.',
    'files': files, 'existing_sources': 12, 'new_sources': 1, 'literal_applications': 26, 'whole_parent_recoveries': 12, 'empty_parent_recoveries': 1, 'parse_exits': [0] * 13,
    'all4486_parent_archived_and_live_inputs_exact': True, 'complete_compiler_plan': plan_ref, 'planned4487_inputs_4474_Rust': True, 'context': context,
    'Native_commit': PIN, 'Native_wholes': native, 'Native_strict_extents': extents, 'Native34_declarations': ledger_ref, 'ResetNodeData_assignment_ledger': reset_ref,
    'Root_closed_volume_component': volume_ref, 'volume_component_proposal_and_both_diffs_join_exact': True,
    'private_API_and_test_caller_inventory': inventory_ref, 'read_only_design_plan': old_plan_ref, 'unsealed_author_draft': summary_ref,
    'same_owner_and_call_contract': ['Sole OrdinaryEquipment.nodes native ordinal and full Node/MoreNodeInfo fields; no typed Node IDs, duplicate owner, snapshot or fabricated report values.',
        'Actual AbortProcessing, DisplayAdvancedReportVariables, CO2Simulation and GenericContamSimulation owners; no forced flags or readiness writes.',
        'Actual existing System/Average unmetered bound registration pipeline with exact units, NodeID key, real input and ESO/MTR/EIO/BND streams; all34 ordered declarations and real live Which callbacks.',
        'Source volume route removes only its extra bounded-topology admission and unused import. Genuine initial closure, signed calculation/default P0, real positive user-volume/height/calculated branches and diagnostic/space writes remain; no winding repair, absolute value or fabricated volume. Legacy topology helper/callers stay unchanged.',
        'Native ResetNodeData zero-count return followed by whole physical allocation19 assignments and allocated MoreNodeInfo6 assignments from same defaults; no whole-record clone/reset.',
        'Native also calls SetupNodeVarsForReporting during UtilityRoutines fatal-final processing after AbortProcessing=true. This function preserves abort-skip/latch/BND semantics; no new fatal Source dispatch is added or claimed.'],
    'remaining_positive_boundaries': ['Actual Source CalcMoreNodeInfo NodeID1012 and calculation1071 remain typed unavailable; no Node thermodynamics or plant/HVAC physics is claimed.',
        'Unused convenience All/NonFacility/Combined owner views explicitly reject Node targets. The actual LiveReadView has the genuine equipment borrow and routes them.'],
    'main_mutations': 0, 'Cargo_Native_or_tests_executed': False, 'new_test_bodies': 0, 'Native_answer_production_inputs': False, 'sealer_Source': ref(Path(__file__))}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == a.head
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
print(json.dumps(doc('manifest.json', manifest)))

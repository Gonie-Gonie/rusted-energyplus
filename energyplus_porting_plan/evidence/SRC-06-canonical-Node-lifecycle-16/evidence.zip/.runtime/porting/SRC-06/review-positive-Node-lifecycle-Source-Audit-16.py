"""Single independent cohesive13Source peer, including Root's volume component."""
from pathlib import Path
import ast, hashlib, json, re, subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Audit-positive-Node-lifecycle-coherent-Source-review-16'
NATIVE='6f2e40d10250a105b49966baa24d843711e61048';HEAD='017cf481d81f553dbd3b656e9ea66eec3913252b'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 b=(R/v['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'],v['path'];assert len(b)==v.get('bytes',len(b));return b
def git(repo,revision,path):return subprocess.check_output(['git','-C',str(repo),'show',revision+':'+path])
def enum(text,name):
 s=re.search(r'enum class '+name+r'\s*(?::[^\{]+)?\{(.*?)\};',text,re.S);assert s,name
 s=re.sub(r'//[^\n]*|/\*.*?\*/','',s[1],flags=re.S);out={};value=-1
 for x in s.split(','):
  if not x.strip():continue
  p=x.strip().split('=');value=int(p[1].strip())if len(p)==2 else value+1;out[p[0].strip()]=value
 return out
def main():
 assert not (O/'review.json').exists()
 mp=D/'source-positive-Node-lifecycle-held-Peer-01/manifest.json';assert ref(mp)['sha256']=='d847033281222cf9a0461bd2f73b533024af03dea42beb784a5f70aa6e8c7f15'
 m=json.loads(mp.read_bytes());assert m['base_HEAD']==HEAD and m['Native_commit']==NATIVE
 assert m['main_mutations']==m['new_test_bodies']==0 and not m['Cargo_Native_or_tests_executed'] and not m['Native_answer_production_inputs']
 before={r['historical_path']:r for r in json.loads(checked(m['actual15_snapshot']))['files']}
 plan=json.loads(checked(m['complete_compiler_plan']));final={r['path']:r for r in plan['entries']};files={r['canonical_path']:r for r in m['files']}
 assert len(before)==4486 and len(final)==4487 and len(files)==13
 assert plan['planned_inputs']==4487 and plan['planned_Rust']==4474 and set(plan['selected_paths'])==set(files)
 assert sum(r['before_absent']for r in files.values())==1
 assert set(final)==set(before)|{p for p,r in files.items()if r['before_absent']}
 for p,row in final.items():
  if p in before:assert (row['before_sha256'],row['before_bytes'])==(before[p]['archive']['sha256'],before[p]['size_bytes'])
  if p in files:assert (row['final_sha256'],row['final_bytes'])==(files[p]['proposed']['sha256'],files[p]['proposed']['bytes'])
  else:assert (row['final_sha256'],row['final_bytes'])==(before[p]['archive']['sha256'],before[p]['size_bytes'])
 actual=json.loads(checked(m['accepted_Root_actual15_review']));assert actual['accepted'] and not actual['findings']
 for key,code in [('actual15_check',0),('actual15_B',6)]:
  run=json.loads(checked(m[key]));assert run['exit_code']==code and run['source_bytes_match_before_and_after'];assert run['source_snapshot']['sha256']==m['actual15_snapshot']['sha256']
 assert actual['B_frontier']==m['actual15_observed_frontier']
 source=(D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8');fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<pure-app>','exec'),ns);apply=ns['apply']
 native={}
 for row in m['Native_wholes']:
  raw=checked(row['whole']);assert row['revision']==NATIVE and raw==git(R/'.reference/energyplus-src/26.1.0',NATIVE,row['Native_path']);native[row['Native_path']]=raw
 for row in m['Native_strict_extents']:
  assert checked(row['strict_extent'])==b''.join(native[row['Native_path']].splitlines(keepends=True)[row['first_line']-1:row['last_line']])
 contexts=[]
 for row in m['context']:
  p=row['canonical_path'];raw=checked(row['frozen']);assert raw==checked(row['actual15_archive'])==(R/p).read_bytes()==git(R,HEAD,p);assert row['actual15_archive']==before[p]['archive'];contexts.append(row['frozen'])
 O.mkdir(exist_ok=True);texts={};reviewed=[]
 for index,row in enumerate(m['files'],1):
  p=row['canonical_path'];old,new=checked(row['before']),checked(row['proposed'])
  assert apply(old,checked(row['forward_diff']))==new and apply(new,checked(row['inverse_diff']))==old==checked(row['literal_inverse'])
  if row['before_absent']:assert old==b'' and p not in before and not (R/p).exists()
  else:assert old==checked(row['actual15_archive'])==(R/p).read_bytes()==git(R,HEAD,p)
  result=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True);assert result.returncode==0,result.stderr
  a,b=O/f'{index:02d}.parse.stdout',O/f'{index:02d}.parse.stderr';a.write_bytes(result.stdout);b.write_bytes(result.stderr)
  assert row['parse']['exit_code']==0;checked(row['parse']['stdout']);checked(row['parse']['stderr'])
  added=b''.join(x[1:]for x in checked(row['forward_diff']).splitlines(keepends=True)if x.startswith(b'+')and not x.startswith(b'+++'))
  assert not re.search(rb'\b(?:unwrap|expect)\s*\(',added)and not re.search(rb'\b(?:panic|todo|unimplemented|unreachable)\s*!',added)and b'#[test]'not in added
  texts[p]=new.decode('utf-8');reviewed.append(dict(canonical_path=p,before=row['before'],proposed=row['proposed'],literal_forward_inverse_exact=True,fresh_parse_exit=0,parse_stdout=ref(a),parse_stderr=ref(b)))
 volume=json.loads(checked(m['Root_closed_volume_component']));assert volume['base_HEAD']==HEAD
 v=volume['files'][0];joined=files[v['canonical_path']]
 for key in ['before','proposed','forward_diff','inverse_diff']:assert checked(v[key])==checked(joined[key])
 for row in volume['unchanged_contexts']:
  assert checked(row['whole_source'])==checked(before[row['canonical_path']]['archive'])
 setup=texts['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_setup_reporting.rs'];registration=texts['crates/ep_runtime/src/heat_balance/source_output_registration.rs']
 native_setup=b''.join(native['src/EnergyPlus/NodeInputManager.cc'].splitlines(keepends=True)[187:514]).decode('utf-8')
 calls=re.findall(r'SetupOutputVariable\(\s*state,\s*"([^"]+)",\s*Constant::Units::(\w+),\s*(.*?),\s*OutputProcessor::TimeStepType::(\w+),\s*OutputProcessor::StoreType::(\w+),\s*NodeID\s*\);',native_setup,re.S)
 rust_calls=re.findall(r'\(Field::(\w+),\s*"([^"]+)",\s*Units::(\w+)\)',setup)
 ledger=json.loads(checked(m['Native34_declarations']));assert len(calls)==len(rust_calls)==len(ledger)==34
 units_enum=enum(native['src/EnergyPlus/DataGlobalConstants.hh'].decode('utf-8'),'Units')
 unit_table=re.search(r'unitNames\s*=\s*\{(.*?)\};',native['src/EnergyPlus/DataGlobalConstants.hh'].decode('utf-8'),re.S);assert unit_table
 unit_names=re.findall(r'"([^"\n]*)"',re.sub(r'//[^\n]*','',unit_table[1]));assert len(unit_names)==units_enum['Num']
 source_symbols=dict(re.findall(r'Self::(\w+)\s*=>\s*"([^"]*)"',registration))
 for i,(n,r,l)in enumerate(zip(calls,rust_calls,ledger),1):
  name,unit,target,step,store=n;field,rust_name,rust_unit=r
  assert name==rust_name==l['name']and unit==l['Native_units']and re.sub(r'\s+','',target)==re.sub(r'\s+','',l['Native_target'])
  assert step==l['time_step']=='System'and store==l['store_type']=='Average'and l['Native_order']==i
  assert unit_names[units_enum[unit]]==source_symbols[rust_unit]==l['exact_symbol']
  assert rust_unit==l['Source_unit_plan'].split()[0]
  assert re.search(r'Field::'+field+r'\s*=>\s*&row\.'+l['same_Source_field']+r'\b',setup)
  if 13<=i<=15:assert l['condition']=='Node.fluidType Air or Water'
  if 23<=i<=32:assert l['condition']=='DisplayAdvancedReportVariables'
 assert 'SourceOutputStoreType::Average'in setup and 'unmetered(TimeStepKind::System)'in setup
 # Every static BND header byte is independently matched, in Native order.
 n_headers=[json.loads('"'+x+'"')for x in re.findall(r'"((?:\\.|[^"\\])*)"',native_setup)if x.startswith('! ')]
 r_headers=[json.loads('"'+x+'"').removesuffix('\n')for x in re.findall(r'b"((?:\\.|[^"\\])*)"',setup)if x.startswith('! ')]
 assert n_headers==r_headers
 reset=texts['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_reset.rs'];reset_ledger=json.loads(checked(m['ResetNodeData_assignment_ledger']))
 assignments=re.findall(r'node\.(\w+)\s*=\s*defaults\.(\w+);',reset);assert all(a==b for a,b in assignments)
 assert [a for a,b in assignments]==reset_ledger['physical_assignments']and len(assignments)==19
 more=re.findall(r'self\.(\w+)\s*=\s*([^;]+);',setup[setup.index('fn reset_source_node_data'):setup.index('\nfn index')]);assert len(more)==6
 assert [x[0]for x in more]==['wet_bulb_temperature','relative_humidity','report_enthalpy','volume_flow_rate_standard_density','volume_flow_rate_current_density','density']
 assert 'air_dew_point_temperature'not in str(more)and 'specific_heat'not in str(more)
 # Reconstruct every actual15 Rust-source literal caller/enum census hit. This
 # is one bounded raw read, no thousands of Git calls or execution of tests.
 patterns=['setup_source_node_variables_for_reporting','reset_source_node_data','LiveReadFields {','LiveReadView {','SourceAllOutputOwners {','SourceNonFacilityOutputOwners {','SourceCombinedOutputOwners {','SourceOutputUnits','SourceRealOutputTarget','match target']
 hits=[]
 for p in sorted(p for p in before if p.endswith('.rs')):
  content=(R/before[p]['archive']['path']).read_text(encoding='utf-8')
  for number,line in enumerate(content.splitlines(),1):
   found=[x for x in patterns if x in line]
   if found:hits.append(dict(path=p,line=number,text=line,patterns=found))
 inventory=json.loads(checked(m['private_API_and_test_caller_inventory']));assert inventory['Rust_files_read']==4473 and hits==inventory['hits']
 checked(m['read_only_design_plan']);checked(m['unsealed_author_draft']);checked(m['sealer_Source'])
 report=dict(schema='src06-independent-coherent-Node-lifecycle-and-closed-volume-Source-review.v1',accepted=True,findings=[],producer=ref(mp),base_HEAD=HEAD,actual15_B=m['actual15_B'],accepted_actual15=m['accepted_Root_actual15_review'],actual15_snapshot=m['actual15_snapshot'],complete_compiler_plan=m['complete_compiler_plan'],all4486_parent_to4487_4474_plan_metadata_exact=True,raw_parent_custody='Twelve selected existing Sources and sixteen unchanged contexts are whole archived/current/committed017cf Git exact; new source has empty absent parent. Complete metadata is exact; no redundant full4486 Git loop or blanket allGit equality claim.',whole_sources13=True,literal_applications26=True,fresh_parse_exits=[0]*13,files=reviewed,Native_commit=NATIVE,Native11_wholes=m['Native_wholes'],Native12_strict_extents=m['Native_strict_extents'],Native34_declarations_reconstructed=True,Native_units_enum_and_actual_symbols_reconstructed=True,Native34_live_field_maps_exact=True,all_static_BND_headers_order_and_bytes_exact=True,physical19_MoreInfo6_reset_assignments_exact=True,private_API_census4473_before_Rust_sources_reconstructed=dict(reference=m['private_API_and_test_caller_inventory'],hits=len(hits)),Root_volume_component=m['Root_closed_volume_component'],whole_volume_proposal_and_both_diffs_join_exact=True,contexts16=contexts,reviewed_semantics=['Native NodeVarsSetup guard and same AbortProcessing guard precede full MoreNodeInfo default allocation/unique-node loop. All34 declarations preserve native ordinal/NodeID key, physical vs MoreNodeInfo field identity, exact units, System/Average unmetered options, Air-or-Water/advanced/CO2/generic real owner guards and order. No forced flags or returned values.','Same existing registration/request/prescan/minimum-frequency/clock/output-file/dictionary/backend owners are borrowed through the production prelude. Same SourceInitializationFiles outputs [ESO,EIO,MTR,BND] are disjointly borrowed; no new stream or postprocessing. Setup latch is written only after declarations and before the complete BND tail, including suspicious reference loop.','The live Which target contains genuine native signed Node ordinal and field; reads return references into the same retained physical/MoreNodeInfo rows. All actual LiveReadFields/LiveReadView constructors carry the genuine equipment borrow. Convenience views without this owner reject Node targets explicitly; no default zero or type-profile fallback.','Reset preserves Native zero-count return and traverses the entire existing physical allocation for19 explicit default-field assignments, then allocated MoreNodeInfo for exactly6 assignments. Dewpoint/specific heat, other physical fields, counts and request arrays remain untouched. No whole-record clone/reset.','Root volume component removes only the extra Rust bounded_topology_rejection import/call/admission. Native initial edge-two closure is independent of face count or winding; signed polyhedron math is unchanged. A positive entered Zone.Volume survives a negative calculated result; actual positive calculated comparison warnings, height/floor alternative, final nonpositive boundary, Space writes/debug and open-zone boundaries remain unchanged.','Default P0/signed Newell/dot-product Source helpers and their same unchanged contexts were read against pinned Vectors505–529/130–147; no absolute value, winding repair, numeric-zero invention or tolerance change is added. Legacy topology helper and callers are unchanged.'],limits=['Actual15 stopped at the earlier volume admission, so this peer does not claim positive Setup/Reset execution or Native paired state equivalence. Root owns focused existing test/build and real B/A24 with the final compiler plan.','CalcMoreNodeInfo positive request/EMS and physical math remain typed boundaries, as do open-zone/polygon repair, final nonpositive volume diagnostics, debug printing and other unrepresented paths.','Native fatal-final Setup call is acknowledged: this body preserves AbortProcessing skip/latch/BND behavior, but no additional fatal Source dispatch is introduced or claimed.','No test body, Cargo invocation, Native execution, main application or B completion is claimed by this Source review.'],main_mutations=0,new_test_bodies=0,Cargo_Native_or_tests_executed=False,reviewer_Source=ref(Path(__file__)))
 (O/'review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(O/'review.json')))
if __name__=='__main__':main()

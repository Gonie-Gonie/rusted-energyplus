"""Root-only guarded seven-path canonical09 application; no Git/Cargo/tests."""
from pathlib import Path
import argparse, hashlib, json, subprocess
ROOT = Path(__file__).resolve().parents[3]
def read(r):
 b=(ROOT/r['path']).read_bytes(); assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']; return b
p=argparse.ArgumentParser(); p.add_argument('--apply',action='store_true'); a=p.parse_args(); assert a.apply
M=json.loads((ROOT/'.runtime/porting/SRC-06/canonical-source77-post-summary-core-prepared-Peer-09/manifest.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==M['base_HEAD']
plan=json.loads(read(M['complete_compiler_Source_plan']))
for r in plan['files']:
 p=ROOT/r['path']
 if r['before_absent']: assert not p.exists()
 else:
  b=p.read_bytes(); assert len(b)==r['before_bytes'] and hashlib.sha256(b).hexdigest()==r['before_sha256']
values=[]
for r in M['files']:
 p=ROOT/r['canonical_path']; b=read(r['proposed'])
 if not r['before_absent']: assert p.stat().st_nlink==1 and p.read_bytes()==read(r['before'])
 if r['planned_exact_actual77']: assert b==read(r['actual77'])
 else: assert b==read(r['before'])+read(M['EIO_append_only_bridge']['accepted_append'])
 values.append((p,b))
for p,b in values: p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
for r in plan['files']:
 b=(ROOT/r['path']).read_bytes(); assert len(b)==r['planned_bytes'] and hashlib.sha256(b).hexdigest()==r['planned_sha256']
print(json.dumps(dict(applied_paths=len(values),compiler_inputs_verified=len(plan['files']),Git_mutated=False,Cargo_or_tests_executed=False)))

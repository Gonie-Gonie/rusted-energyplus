from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-ordinary-post-summary-next-caller-Source-review-01';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def walk(v):
    if isinstance(v,dict):
        if 'path' in v and 'sha256' in v:checked(v)
        for x in v.values():walk(x)
    elif isinstance(v,list):
        for x in v:walk(x)
t=ast.parse((BASE/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
mp=BASE/'ordinary-post-summary-next-caller-held-Reviewer-01/manifest.json';assert ref(mp)['sha256']=='4b02581abdc3fd41c058caf52c5fb19277080e48531cdb76ad4aee3ab1d63fee'
m=json.loads(mp.read_bytes());walk(m);assert len(m['files'])==1;e=m['files'][0]
a,p,b=checked(e['before']),checked(e['parent_before']),checked(e['proposed'])
assert a==checked(e['canonical_before'])==subprocess.check_output(['git','show',m['base_HEAD']+':'+e['canonical_path']],cwd=ROOT)==(ROOT/e['canonical_path']).read_bytes()
assert p==checked(e['parent_proposed'])==checked(e['literal_parent_inverse'])==(BASE/'ordinary-provider-assembly-Root-76/workspace'/e['canonical_path']).read_bytes()
assert a==checked(e['literal_inverse'])
for x,k,y in [(a,'complete_forward_diff',b),(b,'complete_inverse_diff',a),(p,'parent_forward_diff',b),(b,'parent_inverse_diff',p)]:assert apply(x,checked(e[k]))==y
for n in m['Original_authority']:
    raw=checked(n['source']);assert checked(n['literal_excerpt'])==b''.join(raw.splitlines(keepends=True)[n['first_line']-1:n['last_line']])
    path=n['source']['path'].split('/26.1.0/',1)[1];assert raw==subprocess.check_output(['git','show','6f2e40d10250a105b49966baa24d843711e61048:'+path],cwd=ROOT/'.reference/energyplus-src/26.1.0')
q=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--emit','stdout'],input=b,capture_output=True);assert q.returncode==0,q.stderr
receiver=b'fn write_source_tabular_reports_prefix_on_session(\n        &self,';assert p.count(receiver)==1
mutable=p.replace(receiver,receiver.replace(b'&self,',b'&mut self,'))
prefix,suffix=mutable.split(b'            return Err(unavailable("actual WriteTabularReports5239 WriteEioTables entry"));');assert b.startswith(prefix) and b.endswith(suffix)
block=b[len(prefix):len(b)-len(suffix)];calls=[b'write_source_eio_tables(self, &mut next_owners)',b'write_source_load_component_summary(&next_owners)',b'write_source_heat_emission_table(&mut next_owners)',b'if session.tabular.display_thermal_resilience_summary && !globals.do_pure_load_calc',b'actual WriteTabularReports5244 WriteThermalResilienceTables entry',b'actual WriteTabularReports5246 CO2Resilience conditional entry']
assert all(block.count(x)==1 for x in calls) and [block.index(x) for x in calls]==sorted(block.index(x) for x in calls)
assert b'clone(' not in block and b'default(' not in block
for x in [b'reports.selected_zone_input.as_ref()',b'reports.selected_simulation_startup.as_ref()',b'results: &reports.source_results_framework',b'sqlite: &reports.source_sqlite',b'backend: &mut *backend',b'warmup: &weather.state.global.warmup_flag']:assert x in block
peer=BASE/sys.argv[1]/'review.json';assert ref(peer)['sha256']==sys.argv[2];pm=json.loads(peer.read_bytes());assert pm.get('accepted') or str(pm.get('decision','')).startswith('ACCEPTED')
OUT.mkdir();result=dict(accepted=True,manifest=ref(mp),accepted_body_peer=ref(peer),Source_files=1,literal_applications=4,pinned_Original_ranges=len(m['Original_authority']),parse_only=1,exact_parent76=True,only_receiver_mutability_and_next_child_block_changed=True,actual_same_owner_borrows=True,findings=[],scope='Actual5239 EIO same retained open file,5240 genuine load flags/global,5241 real BuildingPreDefReport emission values. Same retained TAB/Globals/Zones/HVAC/results/SQL and short same backend/live flags. Thermal true branch stops5244, false branch stops before actual CO2 condition5246. Earlier effects and false5278 unchanged.',canonical_changes=0,Cargo_Native_tests_executed=False,numerical_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve()))
p=OUT/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-actual-tabular77-five-format-comparison-01';assert not OUT.exists()
S=BASE/'through-primary-diagnostic-A-24H-Root-77/output';P=BASE/'through-primary-diagnostic-A-24H-Root-76/output';N=BASE/'native-installed-A-24H-Root-67/output';W=BASE/'ordinary-provider-assembly-Root-77/workspace'
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(p.read_bytes())
check=W/'.runtime/porting/SRC-06/provider-assembly-all-targets-command-77/receipt.json';cli=W/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-77/receipt.json'
c=load(check);r=load(cli);assert c['exit_code']==0 and r['exit_code']==6 and c['source_bytes_match_before_and_after'] and r['source_bytes_match_before_and_after'] and c['source_snapshot']==r['source_snapshot']
assert b'actual WriteTabularReports5244 WriteThermalResilienceTables entry' in (S/'eplusrs.err').read_bytes()
assert b'--oracle-baseline' not in ' '.join(r['command']).encode() and b'--compare-oracle' not in ' '.join(r['command']).encode()
compiler=[]
for line in (W/r['stdout']['path']).read_bytes().splitlines():
    try:row=json.loads(line)
    except (ValueError,UnicodeError):continue
    if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name') in ['ep_runtime','ep_run','eplus-rs']:
        assert row['fresh'] is False and str(W).replace('\\','/').lower() in row['target']['src_path'].replace('\\','/').lower();compiler.append(row)
assert len(compiler)==3
formats=[];all_bad=[];total=exact=0
for ext in ['csv','tab','txt','htm','xml']:
    sp=S/f'eplustbl.{ext}';np=N/f'energyplustbl.{ext}';sb=sp.read_bytes();nb=np.read_bytes();sl=sb.splitlines(keepends=True);nl=nb.splitlines(keepends=True);assert len(nl)>=len(sl)
    bad=[]
    for i,(a,b) in enumerate(zip(sl,nl),1):
        if a==b:continue
        version=(b'rusted-energyplus' in a or b'rusted-energyp' in a) and b'EnergyPlus' in b
        ca=re.fullmatch(rb'( *)\d{2}:\d{2}:\d{2}(</b></p>)?(\r?\n)?',a);cb=re.fullmatch(rb'( *)\d{2}:\d{2}:\d{2}(</b></p>)?(\r?\n)?',b)
        clock=ca is not None and cb is not None and ca.groups()==cb.groups()
        date=False
        if (ext=='htm' and i==5) or (ext=='xml' and i==9):
            da=re.fullmatch(rb'( *)\d{4}-\d{2}-\d{2}(\r?\n)?',a);db=re.fullmatch(rb'( *)\d{4}-\d{2}-\d{2}(\r?\n)?',b)
            date=da is not None and db is not None and da.groups()==db.groups()
        if ext=='htm' and a.startswith((b'<p>Timestamp: <b>',b'<p>Simulation Timestamp: <b>')):
            da=re.fullmatch(rb'(<p>(?:Simulation )?Timestamp: <b>)\d{4}-\d{2}-\d{2}(\r?\n)?',a);db=re.fullmatch(rb'(<p>(?:Simulation )?Timestamp: <b>)\d{4}-\d{2}-\d{2}(\r?\n)?',b)
            date=da is not None and db is not None and da.groups()==db.groups()
        bad.append(dict(format=ext,line=i,classification='producer version/build' if version else 'actual wall clock' if clock else 'actual wall date' if date else 'UNCLASSIFIED',Source_complete_raw_hex=a.hex(),Native_complete_raw_hex=b.hex()))
    formats.append(dict(format=ext,Source=ref(sp),Native=ref(np),Source_lines=len(sl),Native_lines=len(nl),exact_lines=len(sl)-len(bad),unequal_lines=len(bad),mismatches=bad));all_bad+=bad;total+=len(sl);exact+=len(sl)-len(bad)
physics=[]
for n in ['eplusrs.eso','eplusrs.mtr','eplusrs.eio','logs/source-report-binary64.csv']:
    assert (S/n).read_bytes()==(P/n).read_bytes();physics.append(dict(path=n,Source77=ref(S/n),Source76=ref(P/n),whole_equal=True))
snapshot=load(S/'logs/source-predefined-table.json');prior=load(P/'logs/source-predefined-table.json')
sr=snapshot['table']['allocated_rows_in_original_order'];pr=prior['table']['allocated_rows_in_original_order'];delta=[]
for i in range(max(len(sr),len(pr))):
    a=sr[i] if i<len(sr) else None;b=pr[i] if i<len(pr) else None
    if a!=b:delta.append(dict(ordinal=i+1,before=b,after=a))
assert snapshot['registry']==prior['registry'] and snapshot['timing']==prior['timing']
html=(S/'eplustbl.htm').read_bytes();named=re.findall(rb'<!-- FullName:(.*?)-->',html)
# Preserve a finite complete record even if a new report exposes a mismatch.
OUT.mkdir();result=dict(accepted=all(r['classification']!='UNCLASSIFIED' for r in all_bad),actual_Source_check=ref(check),actual_Source_CLI=ref(cli),Source77_manifest=ref(BASE/'ordinary-provider-assembly-Root-77/manifest.json'),Root_Source_preflight=ref(BASE/'Root-ordinary-provider-union77-preflight-02/review.json'),Native_actual_receipt=ref(BASE/'native-installed-A-24H-command-Root-67/receipt.json'),Native_prior_custody=ref(BASE/'Root-actual-BEPS-five-format-comparison-72-02/comparison.json'),original_IDF=ref(ROOT/'energyplus_porting_plan/cases/A-24H/input.idf'),weather=ref(ROOT/'.runtime/energyplus/26.1.0/WeatherData/USA_CO_Golden-NREL.724666_TMY3.epw'),actual_first_error='actual WriteTabularReports5244 WriteThermalResilienceTables entry',compiler_artifact_rows=compiler,physical_formats=formats,raw_prefix_lines=total,exact_raw_prefix_lines=exact,unequal_raw_prefix_lines=len(all_bad),all_uncapped_raw_mismatches=all_bad,physics_whole_equal76=physics,predefined_snapshot77=ref(S/'logs/source-predefined-table.json'),predefined_snapshot76=ref(P/'logs/source-predefined-table.json'),active_entries76=prior['table']['num_table_entry'],active_entries77=snapshot['table']['num_table_entry'],all_allocated_row_deltas=delta,HTML_named_table_comments=[x.decode('utf8') for x in named],findings=[x for x in all_bad if x['classification']=='UNCLASSIFIED'],method='Every raw physical Source line including CR/LF compared against the same position of complete Native output. No normalization, tolerance, decimal conversion or mismatch cap. Version/clock differences retained verbatim as full raw hex. Physical report prefix only; selected source run remains incomplete.',whole_run_complete=False,numerical_gate_PASS=False,author_Source=ref(Path(__file__).resolve()))
p=OUT/'comparison.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)));print(json.dumps(dict(accepted=result['accepted'],lines=total,exact=exact,unequal=len(all_bad),active_entries77=result['active_entries77'],snapshot_deltas=len(delta))))

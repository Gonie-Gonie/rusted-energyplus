"""Publish the verified seven-file checkpoint after canonical all-targets PASS."""
from pathlib import Path
import argparse,collections,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-post-summary-core-09'
READY=D/'canonical-post-summary-publication-Root-09'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r,base=ROOT):
 p=base/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return p
def load(p):return json.loads(p.read_bytes())
def accepted(p):
 v=load(p);assert v.get('accepted') or str(v.get('decision','')).startswith('ACCEPTED');assert not v.get('findings',[]);return v
def main(args):
 assert args.publish and not PUBLIC.exists() and not READY.exists()
 cp=ROOT/args.canonical_receipt;assert ref(cp)['sha256']==args.canonical_receipt_sha;check=load(cp)
 assert check['exit_code']==0 and check['launch_error'] is None and check['source_bytes_match_before_and_after'] and '--all-targets' in check['command'] and '--workspace' in check['command']
 prepared=D/'canonical-source77-post-summary-core-prepared-Peer-09/manifest.json';assert ref(prepared)['sha256']=='e9e304696934ceccfabcabbb55381be5540247529502af9b18bc384dbd40ebd7';M=load(prepared)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip();assert head==M['base_HEAD']
 plan=load(checked(M['complete_compiler_Source_plan']));planned={r['path']:r for r in plan['files']};observed={r['historical_path']:r for r in load(checked(check['source_snapshot']))['files']}
 assert set(observed)==set(planned) and len(observed)==4453 and sum(n.endswith('.rs') for n in observed)==4440
 for n,r in observed.items():
  b=(ROOT/n).read_bytes();assert b==checked(r['archive']).read_bytes() and len(b)==planned[n]['planned_bytes'] and hashlib.sha256(b).hexdigest()==planned[n]['planned_sha256']
 for r in M['files']:assert (ROOT/r['canonical_path']).read_bytes()==checked(r['proposed']).read_bytes()
 promotion=D/'Root-canonical77-post-summary-core-review-09/review.json';assert ref(promotion)['sha256']=='51cd30b4ceee653f457abeab5309ac48cab74abf6511635e6eb51c5caedcef0b';accepted(promotion)
 actual=checked(M['actual77_independent_review']);assert ref(actual)['sha256']=='e4b7aa77f6f72e4039b98c17f601eb99314ad4cdc29a5145b0f699f4092b0975';A=accepted(actual)
 comparison=checked(A['comparison']);assert ref(comparison)['sha256']=='760b88eebac2799347411a2ae6eb24e23861079b514e5b23002a8f2ec7a6c568';C=accepted(comparison)
 assert (C['raw_prefix_lines'],C['exact_raw_prefix_lines'],C['unequal_raw_prefix_lines'],len(C['HTML_named_table_comments']))==(9620,9588,32,75)
 assert C['raw_prefix_lines']==sum(f['Source_lines'] for f in C['physical_formats']) and C['exact_raw_prefix_lines']==sum(f['exact_lines'] for f in C['physical_formats'])
 assert C['unequal_raw_prefix_lines']==len(C['all_uncapped_raw_mismatches'])==sum(f['unequal_lines'] for f in C['physical_formats'])
 metadata=dict(collections.Counter(x['classification'] for x in C['all_uncapped_raw_mismatches']));assert metadata=={'producer version/build':10,'actual wall date':11,'actual wall clock':11}
 assert C['active_entries76']==C['active_entries77']==914 and C['all_allocated_row_deltas']==[]
 prior=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-tabular-report-core-08/summary.json';assert ref(prior)['sha256']=='d31bfe47322829f207652a47dcf54f89e643f21be60da093e3ff054009704c92';priorv=load(prior)
 oldplanp=ROOT/'energyplus_porting_plan/plan.json';oldplan=load(oldplanp);docnames=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md'];before={n:(ROOT/'energyplus_porting_plan'/n).read_bytes() for n in docnames}
 for b in before.values():assert '\ufffd' not in b.decode('utf8','strict')
 payload={}
 def add(p):
  p=p.resolve();k=p.relative_to(ROOT).as_posix();b=p.read_bytes();assert k not in payload or payload[k]==b;payload[k]=b;return ref(p)
 def addref(r,base=ROOT):return add(checked(r,base))
 def receipt(r):
  p=checked(r);v=load(p);add(p)
  for k in ['stdout','stderr','source_snapshot']:addref(v[k],Path(v['cwd']))
  return v
 for p in [Path(__file__),prepared,promotion,actual,comparison,prior]:add(p)
 for v in [load(promotion),A,C]:
  for k in ['reviewer_Source','author_Source']:
   if k in v:addref(v[k])
 for k in ['complete_compiler_Source_plan','apply_script','author_Source','actual77']:addref(M[k])
 for r in M['files']:
  for k in ['before','literal_inverse','proposed','complete_forward_diff','complete_inverse_diff','actual77']:addref(r[k])
  add(ROOT/r['canonical_path'])
 for r in M['EIO_append_only_bridge'].values():
  if isinstance(r,dict) and 'path' in r and 'sha256' in r:addref(r)
 for r in M['packets']:
  addref(r);v=load(checked(r))
  for a in v.get('Original_authority',[]):addref(a['literal_excerpt'])
  if 'author_Source' in v:addref(v['author_Source'])
 for r in M['independent_leaf_and_caller_reviews']:
  addref(r);v=load(checked(r))
  for k in ['reviewer_Source','author_Source']:
   if k in v:addref(v[k])
 for k in ['actual_check','actual_CLI']:receipt(A[k])
 receipt(ref(cp));receipt(C['Native_actual_receipt'])
 priorNative=load(checked(C['Native_prior_custody']));addref(C['Native_prior_custody'])
 if 'Native_version_receipt' in priorNative:receipt(priorNative['Native_version_receipt'])
 for k in ['Root_Source_preflight','original_IDF','weather','predefined_snapshot77','predefined_snapshot76']:addref(C[k])
 for f in C['physical_formats']:addref(f['Source']);addref(f['Native'])
 for r in C['physics_whole_equal76']:addref(r['Source77']);addref(r['Source76'])
 prior76=D/'Root-ordinary-provider-union76-actual-review-01/review.json';P76=accepted(prior76);add(prior76);addref(P76['comparison'])
 out=D/'through-primary-diagnostic-A-24H-Root-77/output'
 for n in ['diagnostics.json','run-summary.json','eplusrs.err','eplusrs.ctf.log']:add(out/n)
 old27=priorv['prior_existing27_receipt'];addref(old27)
 raw=priorv['raw_reporting_observation']
 for k in ['independent_all55','Root_six_series','all576_pairs']:addref(raw[k])
 READY.mkdir(parents=True);(READY/'plan-before.json').write_bytes(oldplanp.read_bytes())
 for n,b in before.items():
  p=READY/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 PUBLIC.mkdir(parents=True);z=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as arc:
  for k,b in sorted(payload.items()):
   info=zipfile.ZipInfo(k,date_time=(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;arc.writestr(info,b)
 with zipfile.ZipFile(z) as arc:
  assert arc.testzip() is None and len(arc.namelist())==len(payload)
  for k,b in payload.items():assert arc.read(k)==b
 s=PUBLIC/'summary.json';summary=dict(schema='src06-canonical-post-summary-core.v1',status='Canonical component-sizing, shadowing, component-cost, adaptive, EIO, load-guard and heat-emission report core; actual held Source77 writes75 named tables then stops true5244 ThermalResilience',Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,prepared_selective_promotion=ref(prepared),independent_promotion_review=ref(promotion),changed_Rust_files=7,new_Rust_files=3,existing_Rust_files=4,compiler_inputs=4453,Rust_sources=4440,literal_applications=14,canonical_inputs_exact_actual77=4445,canonical_check=ref(cp),actual_Source77_check=A['actual_check'],actual_Source77_CLI=A['actual_CLI'],actual_Source_and_frontier_review=ref(actual),finite_five_format_comparison=ref(comparison),actual_named_tables=75,all_raw_prefix_lines=9620,exact_raw_prefix_lines=9588,all_explicit_version_clock_date_difference_lines=32,metadata_difference_counts=metadata,active_predefined_entries_before=914,active_predefined_entries_after=914,allocated_capacity=1600,EIO_append_only_bridge=M['EIO_append_only_bridge'],other_seven_existing_diagnostic_files_whole_canonical=M['existing_diagnostic_paths_whole_canonical_unchanged'],diagnostic_new_file_absent=M['absent_diagnostic_path'],diagnostic_observer_changes_excluded=True,canonical_pipeline_whole_unchanged=True,readonly_predefined_snapshot_excluded=True,prior_existing27_receipt=old27,prior_existing27_scope='Historical canonical06 existing27 PASS only; not rerun or enlarged to certify this checkpoint.',new_test_bodies=0,full_suite_rerun=False,completed_Source_run_or_export=False,whole_Native_numeric_PASS=False,pipeline_activation=False,gate_changes=False,A=priorv['A'],B=priorv['B'],retained_whole_old_comparison=priorv['retained_whole_old_comparison'],previous_checkpoint=ref(prior),raw_reporting_observation=raw,numeric_observation='ESO/MTR/EIO/raw binary64 sidecar remain whole-equal Source76. Existing3536 unequal parsed ESO observations and unassigned FP cause remain; physical report equality does not establish internal Native binary64 equality.',remaining=['Actual5244 Thermal/CO2/Visual resilience reports, period/coil/predefined/monthly/annual reports, full tabular audit/close/endrun/export.','Default dispatcher activation, whole numerical parity and all remaining declared A/B cases/gates.'],reconstruction='Finite7 Source before/proposals/inverses plus exact2186-byte EIO method bridge,4453-input hash plan, commands and complete declared raw report observations. Six Source files whole-exact actual77; EIO canonical prefix excludes1164 bytes of held observer changes. No full offline simulation replay claim.',evidence_archive=ref(z),archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for k,b in sorted(payload.items())],author_Source=ref(Path(__file__)))
 assert summary['A']=='14/54' and summary['B']=='14/64';s.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 relative='evidence/SRC-06-canonical-post-summary-core-09/summary.json'
 paragraph='크기 산정·음영·비용·적응 쾌적 보고, 초기화 요약·부하 보고 조건·열배출 보고의 Rust 파일 7개(신규 3개·기존 4개)를 반영했습니다. 실제 격리 Source77 실행은 이름 있는 표 75개를 작성한 뒤 열적 복원력 보고 5244 진입에서 exit6으로 끝납니다. 같은 입력 Native와 다섯 출력 형식의 앞부분 9,620줄을 대조해 9,588줄이 바이트까지 같으며, 버전 10줄·실제 시각 11줄·실행 날짜 11줄의 차이는 전체 원문 hex로 보존했습니다. Source 실행일은 10월 19일, 보존한 Native 실행일은 10월 17일입니다. EIO는 같은 열린 파일의 위치를 복원하며 읽습니다. 본체에는 그 메서드 2,186바이트만 추가하고 기존 진단 관측 변경 1,164바이트는 제외했습니다. Predefined 914개 항목과 ESO·MTR·EIO·원시 진단 출력은 직전 실행과 같습니다. Canonical 전체 타깃 컴파일을 통과했고 새 테스트나 전체 테스트 반복은 없습니다. 기본 pipeline과 진단 관측은 전환하지 않았습니다. 기존 ESO 수치 차이·원인 미확정 상태, A14/54·B14/64와 전체 FAIL은 유지하며 전체 실행·수치 동등성·내보내기 완료를 뜻하지 않습니다.'
 for n in docnames:
  p=ROOT/'energyplus_porting_plan'/n;assert p.read_bytes()==before[n];link='../'+relative if n.startswith('cards/') else relative
  p.write_bytes(before[n]+('\n\n[후속 요약 보고 단계 검증]('+link+'). '+paragraph+'\n').encode('utf8'))
 after=json.loads(json.dumps(oldplan));task=next(t for t in after['tasks'] if t['id']=='SRC-06');key='canonical_post_summary_core_09';assert key not in task
 task[key]=dict(path=s.relative_to(ROOT).as_posix(),sha256=ref(s)['sha256'],size_bytes=s.stat().st_size)
 restored=json.loads(json.dumps(after));del next(t for t in restored['tasks'] if t['id']=='SRC-06')[key];assert restored==oldplan
 assert oldplanp.read_bytes()==(READY/'plan-before.json').read_bytes();oldplanp.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 p=READY/'publication-readback.json';v=dict(summary=ref(s),archive=ref(z),archive_entries=len(payload),canonical_check=ref(cp),base_HEAD=head,plan_before=ref(READY/'plan-before.json'),publisher=ref(Path(__file__)),Git_mutated=False,Cargo_tests_Native_executed=False);p.write_bytes((json.dumps(v,indent=2)+'\n').encode());print(json.dumps(v))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--canonical-receipt',required=True);p.add_argument('--canonical-receipt-sha',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-ordinary-post-summary-caller-Source-review-01';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    if r['path'].startswith('crates/'):
        b=subprocess.check_output(['git','show',m['base_HEAD']+':'+r['path']],cwd=ROOT)
    else:b=(ROOT/r['path']).read_bytes()
    assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def walk(v):
    if isinstance(v,dict):
        if 'path' in v and 'sha256' in v:checked(v)
        for x in v.values():walk(x)
    elif isinstance(v,list):
        for x in v:walk(x)
t=ast.parse((BASE/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
mp=BASE/'ordinary-post-summary-caller-held-Reviewer-01/manifest.json';assert ref(mp)['sha256']=='5b35f07354865ab71186821064cca37332718c137b2837ab053e5386f2965230'
m=json.loads(mp.read_bytes());walk(m);assert len(m['files'])==1;e=m['files'][0]
a,p,b=checked(e['before']),checked(e['parent_before']),checked(e['proposed'])
assert a==checked(e['canonical_before'])==subprocess.check_output(['git','show',m['base_HEAD']+':'+e['canonical_path']],cwd=ROOT)
assert p==checked(e['parent_proposed'])==checked(e['literal_parent_inverse'])==(BASE/'ordinary-provider-assembly-Root-75/workspace'/e['canonical_path']).read_bytes()
assert p==(ROOT/e['canonical_path']).read_bytes(),'Current canonical08 caller must be exact compiled75 parent'
assert a==checked(e['literal_inverse'])
for x,k,y in [(a,'complete_forward_diff',b),(b,'complete_inverse_diff',a),(p,'parent_forward_diff',b),(b,'parent_inverse_diff',p)]:assert apply(x,checked(e[k]))==y
for n in m['Original_authority']:
    raw=checked(n['source']);assert checked(n['literal_excerpt'])==b''.join(raw.splitlines(keepends=True)[n['first_line']-1:n['last_line']])
    path=n['source']['path'].split('/26.1.0/',1)[1];assert raw==subprocess.check_output(['git','show','6f2e40d10250a105b49966baa24d843711e61048:'+path],cwd=ROOT/'.reference/energyplus-src/26.1.0')
q=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--emit','stdout'],input=b,capture_output=True);assert q.returncode==0,q.stderr
prefix,suffix=p.split(b'            return Err(unavailable("actual WriteTabularReports5235 WriteComponentSizing entry"));');assert b.startswith(prefix) and b.endswith(suffix)
block=b[len(prefix):len(b)-len(suffix)]
calls=[b'write_source_component_sizing(',b'write_source_surface_shadowing(',b'write_source_component_cost_table(',b'write_source_adaptive_comfort_table(',b'actual WriteTabularReports5239 WriteEioTables entry']
assert [block.index(x) for x in calls]==sorted(block.index(x) for x in calls)
assert all(block.count(x)==1 for x in calls) and b'clone(' not in block and b'default(' not in block
for x in [b'geometry: &reports.surface_geometry_input',b'reports.ordinary_solar_radiation.as_ref()',b'registry: &mut reports.registry',b'&reports.cost_estimate_monetary',b'&reports.selected_internal_heat_gains',b'backend: &mut *backend',b'warmup: &weather.state.global.warmup_flag']:assert x in block
peer=BASE/sys.argv[1]/'review.json';assert ref(peer)['sha256']==sys.argv[2];pm=json.loads(peer.read_bytes());assert pm.get('accepted') or str(pm.get('decision','')).startswith('ACCEPTED')
OUT.mkdir();result=dict(accepted=True,manifest=ref(mp),accepted_body_peer=ref(peer),Source_files=1,literal_applications=4,pinned_Original_ranges=len(m['Original_authority']),parse_only=1,earlier_prefix_and_false5278_exact=True,actual_same_owner_borrows=True,findings=[],scope='Exact75 parent, real5235-5238 sequential calls then typed5239. CompSize/shadow registry mutable borrows, existing geometry/solar combinations, same cost/gains and short same-backend/live flag borrows. Immutable leaf-peer-pending metadata is superseded only for this separate accepted review.',canonical_changes=0,Cargo_Native_tests_executed=False,numerical_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve()))
p=OUT/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

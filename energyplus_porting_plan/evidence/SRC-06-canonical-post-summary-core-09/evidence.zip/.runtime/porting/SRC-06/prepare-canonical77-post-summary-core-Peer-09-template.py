"""Prepare the seven-path canonical09 packet only after accepted actual77.

This template does not execute Cargo, Native, tests, Git mutations, documentation
edits, or canonical writes. Preparation emits frozen proposals and a separately
guarded Root-only application script. Do not run before the actual77 review.
"""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, re, subprocess

ROOT = Path(__file__).resolve().parents[3]
D = ROOT / '.runtime/porting/SRC-06'
OUT = D / 'canonical-source77-post-summary-core-prepared-Peer-09'
HEAD = '36b48e14e2c103ab8dd621cea4357cc37fcbc881'

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def read(r, base=ROOT):
    b = (base / r['path']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == r['sha256'] and len(b) == r.get('bytes', len(b)), r['path']
    return b

def load(p):
    return json.loads(p.read_bytes())

def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True)

def paths(w):
    p = subprocess.run(['rg', '--files', '--hidden', '--no-ignore', '-g', '*.rs', '-g', 'Cargo.toml', 'crates'], cwd=w, capture_output=True, check=True)
    return {n.replace('\\', '/') for n in p.stdout.decode().splitlines()} | {
        n for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml'] if (w/n).is_file()}

def accepted(p):
    j = load(p)
    assert j.get('accepted', str(j.get('decision', '')).startswith('ACCEPTED')) and not j.get('findings', [])
    return j

parser = argparse.ArgumentParser()
parser.add_argument('--prepare-after-actual77', action='store_true')
parser.add_argument('--actual-review', required=True)
args = parser.parse_args()
assert args.prepare_after_actual77, 'Preparation requires closed actual77 and accepted Root actual review'
assert git('rev-parse', 'HEAD').stdout.decode().strip() == HEAD and git('status', '--porcelain').stdout == b''
assert not OUT.exists()

mp = D / 'ordinary-provider-assembly-Root-77/manifest.json'
assert ref(mp)['sha256'] == '1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
M = load(mp)
assert M['assembled_compiler_inputs'] == 4454 and M['assembled_Rust_sources'] == 4441
W = ROOT / M['workspace']
parentp = D / 'ordinary-provider-assembly-Root-76/manifest.json'
assert read(M['parent']) == parentp.read_bytes()
P = load(parentp)
PW = ROOT / P['workspace']
reviewp = ROOT / args.actual_review
review = accepted(reviewp)
assert review['manifest'] == ref(mp)

checkp = W / '.runtime/porting/SRC-06/provider-assembly-all-targets-command-77/receipt.json'
clip = W / '.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-77/receipt.json'
check, cli = load(checkp), load(clip)
assert check['exit_code'] == 0 and cli['exit_code'] == 6
assert check['source_bytes_match_before_and_after'] and cli['source_bytes_match_before_and_after']
assert check['source_snapshot'] == cli['source_snapshot']
assert Path(check['cwd']).resolve() == W.resolve() == Path(cli['cwd']).resolve()
assert review['actual_check'] == ref(checkp) and review['actual_CLI'] == ref(clip)
errorp = D / 'through-primary-diagnostic-A-24H-Root-77/output/eplusrs.err'
assert b'actual WriteTabularReports5244 WriteThermalResilienceTables entry' in errorp.read_bytes()
snapshotp = W / cli['source_snapshot']['path']
assert hashlib.sha256(snapshotp.read_bytes()).hexdigest() == cli['source_snapshot']['sha256']
snapshot = load(snapshotp)
index = {r['historical_path']: r for r in snapshot['files']}
actual = paths(W)
assert set(index) == actual and len(actual) == 4454
for n, row in index.items():
    assert read(row['archive'], W) == (W/n).read_bytes()

# Authenticate the already compiled canonical08 whole compiler-input plan before
# deriving this next plan. This also binds the existing deliberate diagnostic gap.
priorp = D / 'canonical-source75-report-core-prepared-Reviewer-08/manifest.json'
prior = load(priorp)
priorplanp = ROOT / prior['complete_compiler_Source_plan']['path']
priorplan = json.loads(read(prior['complete_compiler_Source_plan']))
priorindex = {r['path']: r for r in priorplan['files']}
beforepaths = paths(ROOT)
assert set(priorindex) == beforepaths and len(beforepaths) == 4450
for n, row in priorindex.items():
    b = (ROOT/n).read_bytes()
    assert len(b) == row['planned_bytes'] and hashlib.sha256(b).hexdigest() == row['planned_sha256'], n

packet_refs = P['packets'] + M['packets']
peer_refs = P['independent_reviews'] + M['independent_reviews']
packets = [json.loads(read(r)) for r in packet_refs]
for peer_ref, packet_ref in zip(peer_refs, packet_refs):
    peer = json.loads(read(peer_ref))
    assert peer.get('accepted', str(peer.get('decision', '')).startswith('ACCEPTED')) and not peer.get('findings', [])
    reviewed = peer.get('manifest', peer.get('preparation_manifest', peer.get('reviewed_manifest')))
    assert reviewed == packet_ref
selected = {r['canonical_path'] for packet in packets for r in packet['files']}
assert len(selected) == 7
diagp = D / 'ordinary-report-binary64-diagnostic-held-Reviewer-01/manifest.json'
diagnostic = load(diagp)
excluded = {r['canonical_path'] for r in diagnostic['files']}
eio = 'crates/ep_runtime/src/heat_balance/source_initialization/files.rs'
assert len(excluded) == 9 and selected & excluded == {eio}

tree = ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes())
ns = {'re': re, 'difflib': difflib}
for name in ['diff', 'apply_literal']:
    f = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module(body=[f], type_ignores=[]), '<pure-literal>', 'exec'), ns)

# EIO is the sole selected path carrying held observer code in its old prefix.
# Recover the whole actual76 prefix, extract only the accepted trailing method,
# then append those exact bytes to the already compiled canonical prefix.
eiorow = next(r for r in M['files'] if r['canonical_path'] == eio)
eio76 = read(eiorow['before'])
eio77 = read(eiorow['proposed'])
assert eio76 == (PW/eio).read_bytes() == read(eiorow['literal_inverse'])
assert ns['apply_literal'](eio76, read(eiorow['forward_diff'])) == eio77
assert ns['apply_literal'](eio77, read(eiorow['inverse_diff'])) == eio76
leaf_eio = next(r for packet in packets for r in packet['files'] if r['canonical_path'] == eio)
assert read(leaf_eio['parent_before']) == eio76 and read(leaf_eio['proposed']) == eio77
assert ns['apply_literal'](eio76, read(leaf_eio['parent_forward_diff'])) == eio77
assert ns['apply_literal'](eio77, read(leaf_eio['parent_inverse_diff'])) == eio76
assert eio77.startswith(eio76)
append = eio77[len(eio76):]
canonical_eio = (ROOT/eio).read_bytes()
assert len(eio76) == 9826 and len(eio77) == 12012 and len(append) == 2186 and len(canonical_eio) == 8662
assert priorindex[eio]['actual75_sha256'] == hashlib.sha256(eio76).hexdigest()
assert append.startswith(b'\n\nimpl SourceInitializationFiles {\n') and append.count(b'pub(crate) fn source_eio_lines(') == 1
assert b'source_eio_lines' not in canonical_eio and b'report_diagnostics' not in append

new = {n for n in selected if not (ROOT/n).exists()}
planned = beforepaths | new
assert len(new) == 3 and len(planned) == 4453 and sum(n.endswith('.rs') for n in planned) == 4440
absent_diag = actual - planned
assert absent_diag == {n for n in excluded if not (ROOT/n).exists()} and len(absent_diag) == 1
values, patches, gits = {}, {}, []
for n in sorted(selected):
    a = (ROOT/n).read_bytes() if (ROOT/n).exists() else b''
    z = canonical_eio + append if n == eio else (W/n).read_bytes()
    q = git('show', HEAD + ':' + n)
    assert (q.returncode == 128 and n in new) or (q.returncode == 0 and q.stdout == a)
    assert a != z and a.count(b'#[test]') == z.count(b'#[test]') and b'\r' not in z
    f = ns['diff'](a, z, n, 'before', 'proposed')
    inverse = ns['diff'](z, a, n, 'proposed', 'before')
    assert ns['apply_literal'](a, f) == z and ns['apply_literal'](z, inverse) == a
    values[n], patches[n] = (a, z), (f, inverse)
    gits.append(dict(path=n, revision=HEAD, exit_code=q.returncode))

plan, differences = [], []
for n in sorted(planned):
    a = (ROOT/n).read_bytes() if (ROOT/n).exists() else None
    z = values[n][1] if n in selected else a
    assert z is not None
    actualbytes = (W/n).read_bytes()
    exact = z == actualbytes
    if not exact:
        differences.append(n)
    plan.append(dict(path=n, before_absent=a is None,
                     before_sha256=hashlib.sha256(a).hexdigest() if a is not None else None,
                     before_bytes=len(a) if a is not None else None,
                     planned_sha256=hashlib.sha256(z).hexdigest(), planned_bytes=len(z),
                     actual77_sha256=hashlib.sha256(actualbytes).hexdigest(),
                     planned_exact_actual77=exact, selected_for_write=n in selected))
assert set(differences) == {n for n in excluded if (ROOT/n).exists()} and len(differences) == 8
whole_excluded = set(differences) - {eio}
assert len(whole_excluded) == 7 and not whole_excluded & selected
pipeline = 'crates/ep_run/src/pipeline.rs'
assert pipeline in whole_excluded and pipeline not in values
assert hashlib.sha256((ROOT/pipeline).read_bytes()).hexdigest() == priorindex[pipeline]['planned_sha256']

OUT.mkdir(parents=True)
def write(n, b):
    p = OUT/n
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(b)
    return ref(p)

def meta(n, o):
    return write(n, (json.dumps(o, ensure_ascii=False, indent=2)+'\n').encode())

rows = []
for i, n in enumerate(sorted(selected), 1):
    rows.append(dict(canonical_path=n, before_absent=n in new,
                     before=write('before/'+n, values[n][0]),
                     literal_inverse=write('literal-inverse/'+n, values[n][0]),
                     proposed=write('proposed/'+n, values[n][1]),
                     complete_forward_diff=write(f'diffs/{i:02}.diff', patches[n][0]),
                     complete_inverse_diff=write(f'diffs/{i:02}.inverse.diff', patches[n][1]),
                     actual77=ref(W/n), planned_exact_actual77=n != eio))
appendref = write('accepted-EIO-method-append.bin', append)
planref = meta('complete-compiler-Source-plan.json', dict(schema='selective-canonical77-compiler-input-plan.v1', base_HEAD=HEAD, files=plan))
applyp = D / 'apply-canonical77-post-summary-core-prepared-Peer-09.py'
assert not applyp.exists()
applyp.write_text('''"""Root-only guarded seven-path canonical09 application; no Git/Cargo/tests."""
from pathlib import Path
import argparse, hashlib, json, subprocess
ROOT = Path(__file__).resolve().parents[3]
def read(r):
 b=(ROOT/r['path']).read_bytes(); assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']; return b
p=argparse.ArgumentParser(); p.add_argument('--apply',action='store_true'); a=p.parse_args(); assert a.apply
M=json.loads((ROOT/'.runtime/porting/SRC-06/canonical-source77-post-summary-core-prepared-Peer-09/manifest.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==M['base_HEAD']
plan=json.loads(read(M['complete_compiler_Source_plan']))
for r in plan['files']:
 p=ROOT/r['path']
 if r['before_absent']: assert not p.exists()
 else:
  b=p.read_bytes(); assert len(b)==r['before_bytes'] and hashlib.sha256(b).hexdigest()==r['before_sha256']
values=[]
for r in M['files']:
 p=ROOT/r['canonical_path']; b=read(r['proposed'])
 if not r['before_absent']: assert p.stat().st_nlink==1 and p.read_bytes()==read(r['before'])
 if r['planned_exact_actual77']: assert b==read(r['actual77'])
 else: assert b==read(r['before'])+read(M['EIO_append_only_bridge']['accepted_append'])
 values.append((p,b))
for p,b in values: p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
for r in plan['files']:
 b=(ROOT/r['path']).read_bytes(); assert len(b)==r['planned_bytes'] and hashlib.sha256(b).hexdigest()==r['planned_sha256']
print(json.dumps(dict(applied_paths=len(values),compiler_inputs_verified=len(plan['files']),Git_mutated=False,Cargo_or_tests_executed=False)))
''', encoding='utf8', newline='\n')
result = meta('manifest.json', dict(
    schema='selective-canonical77-post-summary-core-prepared.v1',
    status='PREPARED_ONLY_ROOT_APPLICATION_AND_CANONICAL_ALLTARGETS_CHECK_PENDING', base_HEAD=HEAD,
    actual77=ref(mp), actual77_check=ref(checkp), actual77_CLI=ref(clip), actual77_frontier=ref(errorp),
    actual77_independent_review=ref(reviewp), previous_canonical08_preparation=ref(priorp),
    previous_canonical08_complete_plan=ref(priorplanp), packets=packet_refs, independent_leaf_and_caller_reviews=peer_refs,
    files=rows, complete_compiler_Source_plan=planref, apply_script=ref(applyp), readonly_Git=gits,
    EIO_append_only_bridge=dict(actual76_prefix=ref(PW/eio), actual77_full=ref(W/eio),
                               actual77_forward_diff=eiorow['forward_diff'], actual77_inverse_diff=eiorow['inverse_diff'],
                               accepted_append=appendref, canonical_prefix_bytes=8662,
                               held_prefix_bytes=9826, held_observer_prefix_delta_bytes=1164,
                               planned_bytes=10848, literal_full77_parent_recovery=True,
                               method_append_exact_accepted_leaf=True),
    counts=dict(selected_paths=7, new_Rust=3, existing_Rust=4, literal_applications=14,
                canonical_before_inputs=4450, planned_inputs=4453, planned_Rust=4440,
                planned_inputs_exact_actual77=4445),
    diagnostic_paths=sorted(excluded), existing_diagnostic_paths_whole_canonical_unchanged=sorted(whole_excluded),
    existing_diagnostic_path_with_only_accepted_EIO_append=eio, absent_diagnostic_path=sorted(absent_diag),
    canonical_pipeline_whole_unchanged=True, readonly_predefined_observer_not_promoted=True,
    new_test_bodies=0, normalizations=0, reviewer_applied_canonical=False,
    Cargo_Native_tests_executed=False, Git_mutated=False, numerical_gate_claim=False,
    qualifications=[
        'Union of accepted four-report03, next-post-summary02 and their genuine callers: seven unique paths, three new and four existing.',
        'Six selected proposals are whole-byte exact actual77. EIO retains the whole current canonical prefix and appends only the accepted2186-byte source_eio_lines method. The1164-byte held observer prefix delta remains excluded.',
        'Seven other existing diagnostic paths retain whole canonical bytes, the new diagnostic child stays absent, and the normal pipeline stays unchanged.',
        'Actual77 ends at true WriteTabularReports5244; Thermal/CO2/Visual/Coil/Predefined and later endrun/export remain incomplete. This is no complete-runtime or numerical-gate claim.',
        'Root canonical all-targets check remains required after guarded application. No new tests or repeated full-suite requirement is added.'
    ], author_Source=ref(Path(__file__))))
print(json.dumps(result))

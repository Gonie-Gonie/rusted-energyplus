from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-ordinary-provider-union77-actual-review-01';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
mp=BASE/'ordinary-provider-assembly-Root-77/manifest.json';m=json.loads(mp.read_bytes());assert ref(mp)['sha256']=='1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
W=ROOT/m['workspace'];census=json.loads(checked(m['compiler_Source_census']))
for r in census['files']:
    b=(W/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['assembled77_sha256'] and len(b)==r['bytes77']
pre=BASE/'Root-ordinary-provider-union77-preflight-02/review.json';assert json.loads(pre.read_bytes())['accepted_for_compile']
cp=BASE/'Root-actual-tabular77-five-format-comparison-01/comparison.json';c=json.loads(cp.read_bytes());assert ref(cp)['sha256']=='760b88eebac2799347411a2ae6eb24e23861079b514e5b23002a8f2ec7a6c568' and c['accepted'] and not c['findings']
check=json.loads(checked(c['actual_Source_check']));cli=json.loads(checked(c['actual_Source_CLI']));assert check['exit_code']==0 and cli['exit_code']==6 and cli['source_bytes_match_before_and_after'] and check['source_snapshot']==cli['source_snapshot']
assert checked(c['predefined_snapshot77'])==checked(c['predefined_snapshot76']) and c['all_allocated_row_deltas']==[] and len(c['HTML_named_table_comments'])==75
assert (c['raw_prefix_lines'],c['exact_raw_prefix_lines'],c['unequal_raw_prefix_lines'])==(9620,9588,32)
for r in c['physics_whole_equal76']:assert checked(r['Source77'])==checked(r['Source76'])
OUT.mkdir();p=OUT/'review.json';p.write_text(json.dumps(dict(accepted=True,manifest=ref(mp),preflight=ref(pre),actual_check=c['actual_Source_check'],actual_CLI=c['actual_Source_CLI'],comparison=ref(cp),compiler_inputs_rechecked=4454,actual_expected_boundary='WriteTabularReports5244 WriteThermalResilienceTables',five_formats_raw_prefix_lines=9620,exact_lines=9588,unequal_version_clock_lines=32,complete_named_tables=75,predefined914_entries_whole_equal76=True,physics_whole_equal76=True,metadata_qualification='All32 differences are10 producer version/build lines,11 actual clock lines and11 actual wall-date header lines. Source executes19October while retained Native baseline executed17October; every raw byte difference is preserved. No weather/report time-axis normalization or tolerance.',findings=[],canonical_changes=0,whole_run_complete=False,numerical_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve())),indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

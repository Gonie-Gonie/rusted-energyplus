"""Real5239-5241 short caller; same mutable EIO handle, no Source execution."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';OUT=D/'ordinary-post-summary-next-caller-held-Reviewer-01'
HEAD='36b48e14e2c103ab8dd621cea4357cc37fcbc881';N=ROOT/'.reference/energyplus-src/26.1.0'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 b=(ROOT/r['path']).read_bytes();assert len(b)==r.get('bytes',len(b)) and hashlib.sha256(b).hexdigest()==r['sha256'];return b
def auth(n,h):
 p=D/n;assert ref(p)['sha256']==h;return p,json.loads(p.read_bytes())
def write(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,o):return write(n,(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode())
assert subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip()==HEAD
pp,P=auth('ordinary-post-summary-caller-held-Reviewer-01/manifest.json','5b35f07354865ab71186821064cca37332718c137b2837ab053e5386f2965230')
pr,PR=auth('Root-ordinary-post-summary-caller-Source-review-01/review.json','5c356fbe67f7a38bfef27ccdec1338ac3f2172bf6f8624a7b303c4bb5ed03e3b');assert PR['accepted'] and not PR['findings']
lp,L=auth('ordinary-post-summary-next-held-Audit-01/manifest.json','70de5cb0737d7cb891781d63efaa1caf5fe01733897def6ff56a391d3631c2bc');read(L['API'])
fp,F=auth('ordinary-post-summary-held-Reviewer-03/manifest.json','7a7f64da30cf86d9b46fb2f42c04f75ad64c9e2a1ddaea68a21ba430b29bd09c')
n='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';row=P['files'][0];assert row['canonical_path']==n;before=read(row['proposed'])
receiver=b'    fn write_source_tabular_reports_prefix_on_session(\n        &self,'
mutable=b'    fn write_source_tabular_reports_prefix_on_session(\n        &mut self,'
old=b'            return Err(unavailable("actual WriteTabularReports5239 WriteEioTables entry"));'
new=b'''            {
                let mut next_owners = crate::heat_balance::ordinary_tabular_reports::SourcePostSummaryReportOwners {
                    globals,
                    zones: required(
                        reports.selected_zone_input.as_ref(),
                        "actual same BuildingPreDefRep before EIO5239",
                    )?,
                    hvac: &required(
                        reports.selected_simulation_startup.as_ref(),
                        "actual same HVAC globals before EIO5239",
                    )?.hvac_globals,
                    results: &reports.source_results_framework,
                    sqlite: &reports.source_sqlite,
                    writer: crate::heat_balance::ordinary_tabular_reports::SourceTabularWriterOwners {
                        monetary: &reports.cost_estimate_monetary,
                        flags: SourceDiagnosticFlags {
                            kickoff: &globals.kickoff_simulation,
                            developer: &project.system.developer_flag,
                            warmup: &weather.state.global.warmup_flag,
                            doing_sizing: &globals.doing_sizing,
                        },
                        backend: &mut *backend,
                    },
                };
                session.tabular.write_source_eio_tables(self, &mut next_owners)
                    .map_err(hb_input_error)?;
                session.tabular.write_source_load_component_summary(&next_owners)
                    .map_err(hb_input_error)?;
                session.tabular.write_source_heat_emission_table(&mut next_owners)
                    .map_err(hb_input_error)?;
            }
            if session.tabular.display_thermal_resilience_summary && !globals.do_pure_load_calc {
                return Err(unavailable("actual WriteTabularReports5244 WriteThermalResilienceTables entry"));
            }
            return Err(unavailable("actual WriteTabularReports5246 CO2Resilience conditional entry"));'''
assert before.count(receiver)==before.count(old)==1
proposal=before.replace(receiver,mutable,1).replace(old,new,1)
assert proposal.replace(mutable,receiver,1).replace(new,old,1)==before
assert proposal.count(b'#[test]')==before.count(b'#[test]')
p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposal,capture_output=True);assert p.returncode==0,p.stderr.decode()
canonical=(ROOT/n).read_bytes();g=subprocess.run(['git','show',f'{HEAD}:{n}'],cwd=ROOT,capture_output=True);assert g.returncode==0 and g.stdout==canonical
parent75=D/'ordinary-provider-assembly-Root-75/workspace'/n
assert parent75.read_bytes()==canonical
energy=json.loads((D/'ordinary-source-energy-caller-held-Audit-01/manifest.json').read_bytes());assert canonical==read(energy['files'][0]['proposed'])
tr=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(x for x in tr.body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
assert not OUT.exists();OUT.mkdir(parents=True)
r=dict(canonical_path=n,canonical_before=ref(ROOT/n),Git_authentication=dict(revision=HEAD,exit_code=0),current_canonical_exact_actual75=ref(parent75),current_canonical_exact_SourceEnergy_parent=energy['files'][0]['proposed'],parent_proposed=row['proposed'],before=write('before/'+n,canonical),parent_before=write('parent-before/'+n,before),proposed=write('proposed/'+n,proposal),literal_inverse=write('literal-inverse/'+n,canonical),literal_parent_inverse=write('literal-parent-inverse/'+n,before));apps=0
for b,f,iv in [(canonical,'complete_forward_diff','complete_inverse_diff'),(before,'parent_forward_diff','parent_inverse_diff')]:
 fb=ns['diff'](b,proposal,n,f+'-before',f+'-after');ib=ns['diff'](proposal,b,n,iv+'-before',iv+'-after');assert ns['apply_literal'](b,fb)==proposal and ns['apply_literal'](proposal,ib)==b;apps+=2
 r[f]=write('diffs/'+f+'.diff',fb);r[iv]=write('diffs/'+iv+'.diff',ib)
orig=[]
for lo,hi in [(5235,5250),(13868,13946),(14623,14662),(15258,15267)]:
 p=N/'src/EnergyPlus/OutputReportTabular.cc';raw=p.read_bytes();lines=raw.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines);orig.append(dict(source=ref(p),first_line=lo,last_line=hi,literal_excerpt=write(f'Original/OutputReportTabular.cc-{lo}-{hi}.txt',b''.join(lines[lo-1:hi]))))
api=meta('API.json',dict(existing_public_entries_unchanged=True,private_prefix_receiver='&self -> &mut self only, actual same EIO stream seek/read capability',calls=['write_source_eio_tables(self,&mut next_owners)','write_source_load_component_summary(&next_owners)','write_source_heat_emission_table(&mut next_owners)'],same_borrowed_fields=['globals existing shared reference','reports.selected_zone_input (BuildingPreDefRep)','reports.selected_simulation_startup.hvac_globals','reports.source_results_framework','reports.source_sqlite','reports.cost_estimate_monetary','existing project/globals/weather live flags','short &mut *backend'],new_owners=0,new_constructor_fields=0,next_boundary='actual5244 Thermal child when displayThermalResilienceSummary && !DoPureLoadCalc; otherwise next unported CO2 conditional5246'))
result=meta('manifest.json',dict(schema='src06-post-summary-next-caller-held.v1',status='HELD actual5239-5241 caller; Audit leaf Root/Fix independent peer/compiler/traversal pending',base_HEAD=HEAD,files=[r],Original_commit='6f2e40d10250a105b49966baa24d843711e61048',Original_authority=orig,dependencies=[ref(pp),ref(pr),ref(lp),L['API'],ref(fp)],leaf_independent_peer='PENDING Root-assigned independent body review; no selfacceptance',four_leaf03_narrow_peer='PENDING at seal; accepted02 and exact LF-only successor retained',API=api,literal_applications=apps,whole_parent_recoveries=1,rustfmt_stdin_parse_exit=0,new_test_bodies=0,canonical_mutations=0,Git_mutated=False,Cargo_Native_tests_executed=False,previous_full_prefix_and_false5278_unchanged=True,qualifications=['Current36b canonical bytes are explicitly authenticated and exactly equal actual75/f1f SourceEnergy parent. The direct proposal parent is immutable fourcaller5b35, with old da frozen captures retained rather than read through stale canonical aliases.','Exactly private receiver annotation plus one final5239 block changes. Same EIO owner is borrowed mutably; no reopen/path/handle clone, input replay, extra PSY scope, constructor reset or counter inference.','Three real child errors retain hb_input_error typed transport and previous file/state effects. HeatEmission uses actual Zone owner building_predefined, not ComfortSummary.','Thermal short-circuit uses actual retained TAB flag and same Globals DoPureLoadCalc. No unsupported false-branch guards are guessed; if false, typed boundary marks next actual conditional5246.','Caller-only is independent of Audit-authored child bodies; no body acceptance, runtime completion, numerical gate or canonical pipeline activation is claimed.'],author_Source=ref(Path(__file__))));print(json.dumps(result))

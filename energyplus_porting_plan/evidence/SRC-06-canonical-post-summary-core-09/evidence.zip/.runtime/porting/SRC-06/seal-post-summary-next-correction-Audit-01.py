from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8');R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'ordinary-post-summary-next-held-Audit-02';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def get(d):
 b=(R/d['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==d['sha256'] and len(b)==d['bytes'];return b
oldmp=B/'ordinary-post-summary-next-held-Audit-01/manifest.json';assert ref(oldmp)['sha256']=='70de5cb0737d7cb891781d63efaa1caf5fe01733897def6ff56a391d3631c2bc';old=json.loads(oldmp.read_bytes())
rejected=B/'Fix-ordinary-post-summary-next-Source-review-01/review.json';assert ref(rejected)['sha256']=='62239d9141440d3951e48a4e19b489423ac427e0073987b2ca339526f873e884';rej=json.loads(rejected.read_bytes())
tree=ast.parse((B/'seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<custody>','exec'),ns)
tree=ast.parse((B/'seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));ps={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<literal-diff>','exec'),ps)
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();changed='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/post_summary_next/eio.rs'
needle=b'.map(source_stripped_report_text)';replacement=b'.map(|field| source_stripped_report_text(field).to_vec())'
proposed={r['canonical_path']:get(r['proposed']) for r in old['files']};assert proposed[changed].count(needle)==1;proposed[changed]=proposed[changed].replace(needle,replacement,1)
assert proposed[changed].replace(replacement,needle,1)==get(next(r for r in old['files'] if r['canonical_path']==changed)['proposed'])
parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed[changed],capture_output=True);assert parse.returncode==0,parse.stderr
git=[]
for r in old['files']:
 n=r['canonical_path'];a=get(r['before']);p=R/n
 assert p.read_bytes()==a if p.exists() else a==b''
 q=subprocess.run(['git','show',f'{head}:{n}'],capture_output=True);assert q.returncode==(0 if p.exists() else 128) and q.stdout==a
 git.append(dict(path=n,revision=head,exit_code=q.returncode,current_and_original01_before_equal=True,sha256=hashlib.sha256(q.stdout).hexdigest()))
for a in old['Original_authority']:
 b=get(a['source']);ls=b.splitlines(True);assert 1<=a['first_line']<=a['last_line']<=len(ls) and get(a['literal_excerpt'])==b''.join(ls[a['first_line']-1:a['last_line']])
O.mkdir();apps=0;direct=[]
for r in old['files']:
 n=r['canonical_path'];p=r.get('parent_proposed');ns['row'](n,proposed[n],R/p['path'] if p is not None else None);nr=ns['rows'][-1]
 for a,k,b in [(nr['before'],'complete_forward_diff',nr['proposed']),(nr['proposed'],'complete_inverse_diff',nr['before']),(nr['parent_before'],'parent_forward_diff',nr['proposed']),(nr['proposed'],'parent_inverse_diff',nr['parent_before'])]:assert ps['apply_diff'](get(a),get(nr[k]))==get(b);apps+=1
 nr['direct_parent_proposed']=r['proposed']
 for key,a,z in [('direct01_forward_diff',get(r['proposed']),proposed[n]),('direct01_inverse_diff',proposed[n],get(r['proposed']))]:
  d=''.join(difflib.unified_diff(a.decode().splitlines(True),z.decode().splitlines(True),fromfile='before/'+n,tofile='after/'+n)).encode();assert ps['apply_diff'](a,d)==z;apps+=1
  q=O/'direct01'/f'{len(ns["rows"]):02}-{key}.diff';q.parent.mkdir(exist_ok=True);q.write_bytes(d);nr[key]=ref(q)
 direct.append(dict(path=n,whole_equal01=n!=changed))
api=old['API'];assert get(api)
checks=dict(whole_Source_paths=4,literal_full_owner_and_direct01_applications=apps,only_changed_Source=changed,exact_same_stripped_field_owned_byte_conversion=True,exact_one_line_reversal_recovers_whole01=True,other3_whole_Source_equal01=True,all12_Native_whole_refs_equal01=True,changed_Source_stdin_parse_exit=0,current_Git=git)
q=O/'checks.json';q.write_bytes((json.dumps(checks,indent=2)+'\n').encode())
m=dict(schema='src06-post-summary-EIO-load-heat-narrow-successor.v1',status='HELD exact owned stripped-field correction; independent narrow peer and caller/runtime pending',base_HEAD=head,Original_version=old['Original_version'],Original_commit=old['Original_commit'],files=ns['rows'],Original_authority=old['Original_authority'],API=api,dependencies=old['dependencies']+[ref(oldmp),ref(rejected)],direct_rejected01=ref(rejected),checks=ref(q),same_owner_read_only_Source=old['read_only_same_owner_Source'],author_Source=ref(Path(__file__).resolve()),qualifications=old['qualifications']+['Exact .to_vec ownership conversion fixes only Source compile/API mismatch: Native splitCommaString pushes an owned stripped string. Same raw bytes, trimming, parser/stream/order/heat formulas and every other body remain unchanged.','Current HEAD now contains canonical08 exact75 core. All four affected current/base-Git before images (or absences) independently equal retained01 before captures; previous WIP bridge/rejection retained historically.','Original owner parent_proposed remains first-integration baseline. Direct01 is correction-history custody only; unintegrated01 must not erase original75 changes during composition.'],canonical_mutations=0,Git_mutations=0,Cargo_Native_tests_executed=False,new_test_bodies=0,numerical_PASS_or_gate_claim=False)
assert apps==24
p=O/'manifest.json';p.write_bytes((json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

"""Exactly27 inserted CR bytes removed; all Source operations unchanged."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';OUT=D/'ordinary-post-summary-held-Reviewer-03'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 b=(ROOT/r['path']).read_bytes();assert len(b)==r.get('bytes',len(b)) and hashlib.sha256(b).hexdigest()==r['sha256'];return b
def write(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,o):return write(n,(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode())
mp=D/'ordinary-post-summary-held-Reviewer-02/manifest.json';assert ref(mp)['sha256']=='0ed4f84325bd69ffd4c6bafb6e7deeedb8ebc1fb3a4209bee0ee7c5c0957baf8';M=json.loads(mp.read_bytes())
rp=D/'Fix-ordinary-post-summary-correction-Source-review-01/review.json';assert ref(rp)['sha256']=='f8c2e1d3dcc441df8b399648f74dc7b0f4221f632f7e2eb3ed7c0cf97d77ae4d';R=json.loads(rp.read_bytes());assert R.get('decision')=='ACCEPTED bounded exact import correction' and not R.get('findings',[])
tr=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(x for x in tr.body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
reg='crates/ep_runtime/src/heat_balance/predefined_tables.rs'
assert not OUT.exists();OUT.mkdir(parents=True);rows=[];apps=0;unchanged=[]
for row in M['files']:
 r=copy.deepcopy(row);n=r['canonical_path'];old=read(r['proposed']);z=old
 if n==reg:
  a=read(r['parent_before']);assert a.count(b'\r')==0 and a.count(b'\n')==295
  assert old.count(b'\r')==old.count(b'\r\n')==27
  z=old.replace(b'\r\n',b'\n');assert len(old)-len(z)==27 and z.count(b'\r')==0
  # Every old line remains exact after removing only the inserted blocks.
  source01=json.loads((D/'ordinary-post-summary-held-Reviewer-01/manifest.json').read_bytes())
  prior=next(x for x in source01['files'] if x['canonical_path']==reg)
  assert read(prior['proposed'])==old
  r['proposed']=write('proposed/'+n,z);r['direct_parent02_proposed']=row['proposed']
  fb=ns['diff'](old,z,n,'02','03');iv=ns['diff'](z,old,n,'03','02')
  assert ns['apply_literal'](old,fb)==z and ns['apply_literal'](z,iv)==old;apps+=2
  r['direct_parent02_forward_diff']=write('diffs/registry-direct02.diff',fb);r['direct_parent02_inverse_diff']=write('diffs/registry-direct02.inverse.diff',iv)
 else:unchanged.append(n)
 for b,f,iv in [(read(r['before']),'complete_forward_diff','complete_inverse_diff'),(read(r['parent_before']),'parent_forward_diff','parent_inverse_diff')]:
  fb=ns['diff'](b,z,n,f+'-before',f+'-after');ib=ns['diff'](z,b,n,iv+'-before',iv+'-after')
  assert ns['apply_literal'](b,fb)==z and ns['apply_literal'](z,ib)==b;apps+=2
  r[f]=write('diffs/'+Path(n).name+'-'+f+'.diff',fb);r[iv]=write('diffs/'+Path(n).name+'-'+iv+'.diff',ib)
 p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=z,capture_output=True);assert p.returncode==0,p.stderr.decode()
 rows.append(r)
assert apps==14 and len(unchanged)==2
for a in M['Original_authority']:
 raw=read(a['source']);lines=raw.splitlines(keepends=True);lo,hi=a['first_line'],a['last_line'];assert 1<=lo<=hi<=len(lines);assert read(a['literal_excerpt'])==b''.join(lines[lo-1:hi])
read(M['API'])
checks=meta('EOL-checks.json',dict(only_changed_Source=reg,removed_CR_bytes=27,parent_CR_bytes=0,parent_LF_lines=295,old_inserted_CRLF=27,normalized_Source_has_zero_CR=True,entire_line_text_identical_under_splitlines=True,other_two_whole_Source_unchanged=unchanged,literal_applications=apps,full_applications_regenerated=12,direct02_applications=2,Original15_and_API_unchanged=True,rustfmt_stdin_parse=3,Source_semantics_unchanged=True,canonical_authentication='Only immutable01/02 before/parent captures and historical da Git observations. Concurrent canonical08 applied bytes are not queried or silently rebased.'))
result=copy.deepcopy(M);result.update(schema='src06-ordinary-post-summary-LF-held.v3',status='HELD exactly27 inserted CR byte normalization over accepted02; independent narrow peer/compile/caller pending',files=rows,dependencies=M['dependencies']+[ref(mp),ref(rp)],parent02=ref(mp),parent02_accepted_peer=ref(rp),EOL_checks=checks,author_Source=ref(Path(__file__)),old_author02_Source_retained=M['author_Source'],partial_author03_retained=ref(D/'seal-post-summary-eol-Reviewer-03.py'),partial_author03_failure='Assumed accepted boolean; actual independent peer uses exact accepted decision string. Failed before output directory or Source creation.')
result['qualifications']+=['03 removes only27 CR bytes from the newly inserted Registry blocks. Parent whole295 LF lines and every source token/body/constructor/flag/math/order/import/API remain exact.01/02 and sole import rejection/correction histories remain immutable.','Future compiled/promoted Source can therefore use exact LF bytes; no compiler or Git normalization result is invented.']
print(json.dumps(meta('manifest.json',result)))

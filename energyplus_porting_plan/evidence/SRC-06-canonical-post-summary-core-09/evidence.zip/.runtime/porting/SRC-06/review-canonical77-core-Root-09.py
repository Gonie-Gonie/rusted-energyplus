from pathlib import Path
import ast,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-canonical77-post-summary-core-review-09';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
mp=BASE/'canonical-source77-post-summary-core-prepared-Peer-09/manifest.json';assert ref(mp)['sha256']=='e9e304696934ceccfabcabbb55381be5540247529502af9b18bc384dbd40ebd7';m=json.loads(mp.read_bytes());plan=json.loads(checked(m['complete_compiler_Source_plan']))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==m['base_HEAD'] and subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
actualroot=BASE/'ordinary-provider-assembly-Root-77/workspace';selected={e['canonical_path']:e for e in m['files']};assert len(selected)==7 and len(plan['files'])==4453
inventory={p.relative_to(ROOT).as_posix() for p in (ROOT/'crates').rglob('*.rs')}|{p.relative_to(ROOT).as_posix() for p in (ROOT/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
assert inventory=={r['path'] for r in plan['files'] if not r['before_absent']} and len(inventory)==4450
exact=0
for r in plan['files']:
    p=ROOT/r['path'];assert p.resolve().is_relative_to(ROOT)
    if r['before_absent']:assert not p.exists()
    else:
        b=p.read_bytes();assert len(b)==r['before_bytes'] and hashlib.sha256(b).hexdigest()==r['before_sha256']
    b=checked(selected[r['path']]['proposed']) if r['path'] in selected else p.read_bytes();assert len(b)==r['planned_bytes'] and hashlib.sha256(b).hexdigest()==r['planned_sha256']
    actual=(actualroot/r['path']).read_bytes();assert hashlib.sha256(actual).hexdigest()==r['actual77_sha256'];same=b==actual;assert same==r['planned_exact_actual77'];exact+=same
assert exact==4445
t=ast.parse((BASE/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
for e in m['files']:
    a,b=checked(e['before']),checked(e['proposed']);assert checked(e['literal_inverse'])==a
    assert apply(a,checked(e['complete_forward_diff']))==b and apply(b,checked(e['complete_inverse_diff']))==a
    if not e['before_absent']:
        assert (ROOT/e['canonical_path']).stat().st_nlink==1
        assert a==subprocess.check_output(['git','show',m['base_HEAD']+':'+e['canonical_path']],cwd=ROOT)
    else:assert subprocess.run(['git','cat-file','-e',m['base_HEAD']+':'+e['canonical_path']],cwd=ROOT,capture_output=True).returncode!=0
    if e['planned_exact_actual77']:assert b==checked(e['actual77'])
bridge=m['EIO_append_only_bridge'];prefix=checked(bridge['actual76_prefix']);full=checked(bridge['actual77_full']);append=checked(bridge['accepted_append'])
assert full==prefix+append and len(append)==2186 and len(prefix)==9826
assert apply(prefix,checked(bridge['actual77_forward_diff']))==full and apply(full,checked(bridge['actual77_inverse_diff']))==prefix
eio='crates/ep_runtime/src/heat_balance/source_initialization/files.rs';assert set(selected)&set(m['diagnostic_paths'])=={eio}
assert checked(selected[eio]['proposed'])==checked(selected[eio]['before'])+append and len(checked(selected[eio]['before']))==8662
assert len(m['existing_diagnostic_paths_whole_canonical_unchanged'])==7 and len(m['absent_diagnostic_path'])==1
for r in [m['actual77_independent_review'],*m['independent_leaf_and_caller_reviews']]:
    p=json.loads(checked(r));assert p.get('accepted') or str(p.get('decision','')).startswith('ACCEPTED')
ast.parse(checked(m['apply_script']).decode('utf8'));OUT.mkdir();p=OUT/'review.json';p.write_text(json.dumps(dict(accepted=True,manifest=ref(mp),complete_plan=m['complete_compiler_Source_plan'],exact_before_inventory=4450,planned_compiler_inputs=4453,planned_Rust=4440,planned_whole_exact_actual77=4445,selected_Rust=7,new_Rust=3,existing_Rust=4,literal_applications=14,EIO_exact_accepted_append_only=2186,other_seven_diagnostic_files_whole_canonical=True,diagnostic_new_file_absent=True,all_existing_selected_paths_single_link=True,findings=[],applied=False,Cargo_Native_tests_executed=False,numerical_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve())),indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

"""Only the real 5235-5238 same-owner caller; no execution or canonical mutation."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';OUT=D/'ordinary-post-summary-caller-held-Reviewer-01'
HEAD='da272c921d1bd4ff162f248dcf1fbf8685baf104';PIN='6f2e40d10250a105b49966baa24d843711e61048';N=ROOT/'.reference/energyplus-src/26.1.0'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 b=(ROOT/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
def auth(n,h):
 p=D/n;assert ref(p)['sha256']==h;return p,json.loads(p.read_bytes())
def write(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,o):return write(n,(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode())
assert subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip()==HEAD
assert subprocess.run(['git','rev-parse','HEAD'],cwd=N,capture_output=True,check=True).stdout.decode().strip()==PIN
pp,P=auth('ordinary-source-energy-caller-held-Audit-01/manifest.json','f1f946f95ecc0c0978c6390f025a587806ecdfb30be1e22db0ef386f76505b1c')
pr,PR=auth('Root-ordinary-source-energy-caller-Source-review-01/review.json','176cd49b70f48221814eb864e133c8f852d250a8c1ad421cbf40ce998d9dcfa3');assert PR['accepted'] and not PR['findings']
lp,L=auth('ordinary-post-summary-held-Reviewer-01/manifest.json','41bd25b8770c37cd21acbb743b302c22a66d53744163cb5ad0288226ca64f920')
n='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';row=P['files'][0];assert row['canonical_path']==n;before=read(row['proposed'])
old=b'            return Err(unavailable("actual WriteTabularReports5235 WriteComponentSizing entry"));'
new=b'''            session.tabular.write_source_component_sizing(&mut reports.registry)
                .map_err(hb_input_error)?;
            session.tabular.write_source_surface_shadowing(
                &mut crate::heat_balance::ordinary_tabular_reports::SourceSurfaceShadowingReportOwners {
                    geometry: &reports.surface_geometry_input,
                    radiation: required(
                        reports.ordinary_solar_radiation.as_ref(),
                        "actual same ShadowComb owner before SurfaceShadowing5236",
                    )?,
                    registry: &mut reports.registry,
                    sqlite: &reports.source_sqlite,
                    results: &reports.source_results_framework,
                    writer: crate::heat_balance::ordinary_tabular_reports::SourceTabularWriterOwners {
                        monetary: &reports.cost_estimate_monetary,
                        flags: SourceDiagnosticFlags {
                            kickoff: &globals.kickoff_simulation,
                            developer: &project.system.developer_flag,
                            warmup: &weather.state.global.warmup_flag,
                            doing_sizing: &globals.doing_sizing,
                        },
                        backend: &mut *backend,
                    },
                },
            ).map_err(hb_input_error)?;
            session.tabular.write_source_component_cost_table(&reports.cost_estimate_monetary)
                .map_err(hb_input_error)?;
            session.tabular.write_source_adaptive_comfort_table(&reports.selected_internal_heat_gains)
                .map_err(hb_input_error)?;
            return Err(unavailable("actual WriteTabularReports5239 WriteEioTables entry"));'''
assert before.count(old)==1;proposal=before.replace(old,new,1);assert proposal.replace(new,old,1)==before
assert proposal.count(b'#[test]')==before.count(b'#[test]')
p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposal,capture_output=True);assert p.returncode==0,p.stderr.decode()
canonical=(ROOT/n).read_bytes();g=subprocess.run(['git','show',f'{HEAD}:{n}'],cwd=ROOT,capture_output=True);assert g.returncode==0 and g.stdout==canonical
tr=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(x for x in tr.body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
assert not OUT.exists();OUT.mkdir(parents=True)
r=dict(canonical_path=n,canonical_before=ref(ROOT/n),Git_authentication=dict(revision=HEAD,exit_code=0),parent_proposed=row['proposed'],before=write('before/'+n,canonical),parent_before=write('parent-before/'+n,before),proposed=write('proposed/'+n,proposal),literal_inverse=write('literal-inverse/'+n,canonical),literal_parent_inverse=write('literal-parent-inverse/'+n,before));apps=0
for b,f,iv in [(canonical,'complete_forward_diff','complete_inverse_diff'),(before,'parent_forward_diff','parent_inverse_diff')]:
 fb=ns['diff'](b,proposal,n,f+'-before',f+'-after');ib=ns['diff'](proposal,b,n,iv+'-before',iv+'-after');assert ns['apply_literal'](b,fb)==proposal and ns['apply_literal'](proposal,ib)==b;apps+=2
 r[f]=write('diffs/'+f+'.diff',fb);r[iv]=write('diffs/'+iv+'.diff',ib)
orig=[]
for lo,hi in [(5227,5241),(14199,14274),(14472,14533),(10856,10865),(12367,12382)]:
 p=N/'src/EnergyPlus/OutputReportTabular.cc';raw=p.read_bytes();lines=raw.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines);orig.append(dict(source=ref(p),first_line=lo,last_line=hi,literal_excerpt=write(f'Original/OutputReportTabular.cc-{lo}-{hi}.txt',b''.join(lines[lo-1:hi]))))
api=meta('API.json',dict(entry='Existing SourceInitializationFiles::write_source_tabular_reports_prefix_on_session signature unchanged',order=['ComponentSizing5235','SurfaceShadowing5236','CompCost5237','AdaptiveComfort5238','typed missing WriteEioTables5239'],owner_mapping=dict(tabular='session.tabular',registry='reports.registry',geometry='reports.surface_geometry_input',radiation='reports.ordinary_solar_radiation',monetary='reports.cost_estimate_monetary',gains='reports.selected_internal_heat_gains',sqlite='reports.source_sqlite',results='reports.source_results_framework',diagnostic_flags='same existing globals/project/weather references',backend='fresh short &mut *backend reborrow'),new_owners=0,new_constructor_fields=0))
result=meta('manifest.json',dict(schema='src06-ordinary-post-summary-caller-held.v1',status='HELD caller-only; four-report independent leaf peer pending, Root caller peer/compiler/actual traversal pending',base_HEAD=HEAD,Original_commit=PIN,files=[r],Original_authority=orig,dependencies=[ref(pp),ref(pr),ref(lp),L['API']],leaf_independent_peer='PENDING Root-assigned Fix peer; no self-acceptance claimed',API=api,literal_applications=apps,whole_parent_recoveries=1,rustfmt_stdin_parse_exit=0,unchanged_entire_prefix_and_false_branch=True,changed_block=dict(before=old.decode(),after=new.decode()),qualifications=['Exactly one final5235 boundary replaced by sequential same-owner calls; previous full5212-5234 prefix and false5278 branch byte-identical.','No repeated getters, owner reset, cloned records/files, output answer injection, prologue or PSY scope added.','Each call transports the existing typed HeatBalanceInputError through hb_input_error and retains its prior file/persistent effects on error.','Four-report positive limitations and actual empty CompSize domain remain inherited; no full positive sizing or People/cost body claim.','No Cargo/tests/Native, canonical/Git mutation, numerical gate or default pipeline activation.'],author_Source=ref(Path(__file__)),canonical_mutations=0,Cargo_Native_tests_executed=False,Git_mutated=False,new_test_bodies=0,numerical_PASS_or_gate_claim=False));print(json.dumps(result))

//! New Source-only production attachment; the legacy eager adapter is preserved.
use super::ProductionWeatherTimestepSeries;
use crate::weather::day::SourceWeatherInitializationError;
use crate::weather::day::source_initialization::{
    SourceWeatherInitializationChildren, SourceWeatherInitializationOwners,
};
use crate::weather::day::{
    WeatherDayError, WeatherDayState, WeatherEnvironmentConfiguration, WeatherSession,
};
impl ProductionWeatherTimestepSeries {
    /// Move genuine Project owners into an unopened weather session.
    /// # Errors
    /// Returns the actual prepared Project/timestep association boundary.
    pub fn from_unopened_source_project_state(
        bytes: Vec<u8>,
        configuration: WeatherEnvironmentConfiguration,
        state: &mut WeatherDayState,
    ) -> Result<Self, WeatherDayError> {
        Ok(Self::from_session(
            WeatherSession::from_source_project_state(bytes, configuration, state)?,
        ))
    }
    pub(crate) fn get_next_source_environment_prefix(
        &self,
        owners: &mut SourceWeatherInitializationOwners<'_, '_>,
        children: &mut impl SourceWeatherInitializationChildren,
    ) -> Result<std::convert::Infallible, SourceWeatherInitializationError> {
        self.session
            .borrow_mut()
            .get_next_source_environment_prefix(owners, children)
    }
}

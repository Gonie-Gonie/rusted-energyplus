# HELD actual RunSimulation213–241 prefix

Source only. No canonical writes, Rust compiler, Cargo, tests, Native or engine execution.
Base: actual Root six-handler03. Its genuine normalized equipment-clock hunk remains unchanged.
The caller now runs the consumed213–241 prefix after both actual handlers and before weather allocation, retaining the same Project/global/HVAC/IP/schedule/weather owners.

Actual RunPeriodsInInput205 queries are inserted before the two guards, with original short-circuit order. CheckEnvironment uses the caller's real filesystem path. No EPW numeric values or new timestep are fabricated. Registry215 consumes actual current DoSizing fields. Construction bounds216 remain on the sole startup owner. OutputProcessor218/220 targets live fields rather than copied f64; the same output_registration owner will later be extended by requested-variable registration. Prefix reentry preserves the original duplicate-pointer fatal, not an invented ready guard.

Facility222 is a focused extraction of the existing selected real constructor. Future gain integration must move reports.facility_electric_service into EmptyInternalGainProviders.electric and delete its old constructor path; do not create both. Coil223/Branches227/Connector228/Plugin231 are the existing Root held implementations. The eight selected sizing getters run in order with actual schema/count queries, real built-in AlwaysOn identity and local allocations. SummaryReports now retains exact object_name and performs actual unusedInputs erase after local reset and before alpha writes.233/240 update the actual retained DoingSizing and its existing backend diagnostic carrier; on Err true and all prior effects stay retained.237 consumes the actual run flags, and241 writes the separate current Space control.

Future HB GetProjectControl MUST borrow reports.heat_balance_space_controls, remove its old persistent sizing/simulation fields from SelectedHeatBalanceInputState and forward the same owner; do not copy/reset those flags. This packet adds only their literal constructor-false state before the getter is reached. Positive OA/Zone/System/Plant sizing, SpaceHVAC, positive Branch/Connector/Plugin/EMS and WindowEquivalentLayer remain explicit unavailable branches, never successful no-ops. PerformancePrecision positive override remains unavailable; OverrideTimestep constructor false is retained separately from CI_FORCE_TIME_STEP.

Later243+ RunSimulation checks and SetupSimulation/HB numerical loops are outside this prefix. No whole Setup completion, numerical parity, Native rerun or new readiness claim. Existing fixture/math files are not touched. Root owns formatting and one coherent actual QA run after Source review.

## Source02 existing-body verification

Only the existing ep_run output/fatal body is expanded; no new test body or binary.
The unchanged admitted AllSummary object proves real SummaryReports unused erase.
Real prefix success checks reached predefined registry and240 diagnostic state.
Repeated prefix checks original215 append before218 duplicate-target fatal, retaining
the consumed input and EIO bytes. A deliberately wrong permanent SummaryReports
association reaches234 after all eight getters; the existing diagnostic carrier
must retain233 DoingSizing=true and the actual SummaryReports object remains unused.
The actual CtfRunOutputs/file owner and real filesystem are used throughout.
No new private owner snapshot API or mock weather numerical result is introduced.
All production Source is byte-exact01; Root still owns actual formatting/QA.

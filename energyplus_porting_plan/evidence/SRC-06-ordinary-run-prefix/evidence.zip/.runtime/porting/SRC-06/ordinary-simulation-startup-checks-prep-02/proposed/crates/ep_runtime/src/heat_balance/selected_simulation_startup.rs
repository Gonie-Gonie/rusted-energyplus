//! Actual selected SimulationManager startup checks and borrowed time bindings.
//! The real caller supplies the same input, globals, report cache and OS path.

use super::error_backend::{SourceErrorBackend, SourceErrorBackendFailure, SourceFatalStop};
use super::report_scan::{ReportScanDiagnostic, ReportScanFailure, ReportScanState, ReportScanUnavailable, SourceReportScanInput, try_scan_for_reports, try_scan_for_reports_with_input};
use super::selected_heat_balance_globals::SelectedHeatBalanceGlobals;
use super::selected_input_processor::{SelectedInputProcessor, SourceInputProcessorShortCut};
use crate::weather::day::WeatherGlobalState;
use crate::weather::day::SetupSimulationControls;
use ep_model::ReportInputs;
use std::path::Path;

#[derive(Debug)]
pub(crate) enum StartupError {
    Backend(SourceErrorBackendFailure),
    Fatal(SourceFatalStop),
    Scan(ReportScanUnavailable),
    Filesystem(std::io::Error),
    Unavailable(&'static str),
}
impl From<SourceErrorBackendFailure> for StartupError {
    fn from(value: SourceErrorBackendFailure) -> Self { Self::Backend(value) }
}
impl std::fmt::Display for StartupError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Backend(e) => std::fmt::Display::fmt(e, f),
            Self::Fatal(e) => std::fmt::Display::fmt(e, f),
            Self::Scan(e) => write!(f, "startup report request unavailable: {e:?}"),
            Self::Filesystem(e) => std::fmt::Display::fmt(e, f),
            Self::Unavailable(e) => write!(f, "selected simulation startup unavailable: {e}"),
        }
    }
}
impl std::error::Error for StartupError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self { Self::Backend(e) => Some(e), Self::Fatal(e) => Some(e),
            Self::Filesystem(e) => Some(e), Self::Scan(_) | Self::Unavailable(_) => None }
    }
}
fn fatal(backend: &mut SourceErrorBackend<'_>, message: &str) -> Result<(), StartupError> {
    match backend.show_fatal_error(message) {
        Ok(never) => match never {},
        Err(error) => Err(StartupError::Fatal(error)),
    }
}

/// The sixteen actual RuntimeLanguage counts written on each CheckIfAnyEMS call.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct SelectedRuntimeLanguage {
    pub(crate) number_of_sensors: usize,
    pub(crate) number_of_actuators_used: usize,
    pub(crate) number_of_program_call_managers: usize,
    pub(crate) number_of_erl_programs: usize,
    pub(crate) number_of_erl_subroutines: usize,
    pub(crate) number_of_user_global_variables: usize,
    pub(crate) number_of_ems_output_variables: usize,
    pub(crate) number_of_ems_metered_output_variables: usize,
    pub(crate) number_of_ems_curve_indices: usize,
    pub(crate) number_of_external_interface_global_variables: usize,
    pub(crate) number_of_fmu_import_global_variables: usize,
    pub(crate) number_of_fmu_export_global_variables: usize,
    pub(crate) number_of_external_interface_actuators: usize,
    pub(crate) number_of_fmu_import_actuators: usize,
    pub(crate) number_of_fmu_export_actuators: usize,
    pub(crate) number_of_ems_construction_indices: usize,
    pub(crate) output_edd_file: bool,
}

/// Sole selected DataHVACGlobals scalars; constructors are +0, not the zone step.
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedHvacGlobals {
    pub(crate) time_step_sys: f64,
    pub(crate) time_step_sys_seconds: f64,
}

/// Sole actual preconstruction bound, initialized before any window allocation.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct SelectedConstructionBounds {
    pub(crate) max_solid_window_layers: i32,
}
impl SelectedConstructionBounds {
    pub(crate) fn set_preconstruction_input_parameters(&mut self, input: &SelectedInputProcessor) -> Result<(), StartupError> {
        self.max_solid_window_layers = 7;
        if input.get_num_objects_found("Construction:ComplexFenestrationState") > 0 {
            self.max_solid_window_layers = self.max_solid_window_layers.max(10);
        }
        let constructions = input.get_num_objects_found("Construction:WindowEquivalentLayer");
        if constructions > 0 {
            // The real positive loop must read getObjectItem; this admitted route
            // does not replace its layer fields with counts or guessed bounds.
            return Err(StartupError::Unavailable("positive WindowEquivalentLayer getter"));
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum TimeStepKind { Zone, System }

/// A concrete field identity resolved against the sole live owners on every read.
/// This represents the pointer target without unsafe addresses or cached values.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum TimeStepTarget { GlobalZoneTimeStep, HvacSystemTimeStep }

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedOutputTimeValue {
    pub(crate) target: Option<TimeStepTarget>,
    pub(crate) current_minute: f64,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedOutputTimePointers {
    pub(crate) zone: SelectedOutputTimeValue,
    pub(crate) system: SelectedOutputTimeValue,
}

/// Root's operations boundary must borrow its same retained session/context pair.
/// The reference lifetime prevents retaining a scalar copy across later updates.
pub(crate) struct LiveTimeStepOwners<'a> {
    pub(crate) global: &'a WeatherGlobalState,
    pub(crate) hvac: &'a SelectedHvacGlobals,
}
impl SelectedOutputTimePointers {
    pub(crate) fn setup_time_pointer(&mut self, kind: TimeStepKind, backend: &mut SourceErrorBackend<'_>) -> Result<(), StartupError> {
        let (slot, target, name) = match kind {
            TimeStepKind::Zone => (&mut self.zone, TimeStepTarget::GlobalZoneTimeStep, "Zone"),
            TimeStepKind::System => (&mut self.system, TimeStepTarget::HvacSystemTimeStep, "System"),
        };
        if slot.target.is_some() {
            return fatal(backend, &format!("SetupTimePointers was already called for {name}"));
        }
        slot.target = Some(target);
        Ok(())
    }

    pub(crate) fn time_step<'a>(&self, kind: TimeStepKind, owners: &LiveTimeStepOwners<'a>) -> Result<&'a f64, StartupError> {
        let target = match kind { TimeStepKind::Zone => self.zone.target, TimeStepKind::System => self.system.target };
        match target {
            Some(TimeStepTarget::GlobalZoneTimeStep) if kind == TimeStepKind::Zone => Ok(&owners.global.time_step_zone),
            Some(TimeStepTarget::HvacSystemTimeStep) if kind == TimeStepKind::System => Ok(&owners.hvac.time_step_sys),
            _ => Err(StartupError::Unavailable("OutputProcessor timestep target association")),
        }
    }
}

/// Selected retained startup portions of distinct Native member owners.
/// Globals and report-cache storage are borrowed separately and never duplicated.
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedSimulationStartup {
    pub(crate) runtime_language: SelectedRuntimeLanguage,
    pub(crate) construction_bounds: SelectedConstructionBounds,
    pub(crate) output_time_pointers: SelectedOutputTimePointers,
    pub(crate) hvac_globals: SelectedHvacGlobals,
    pub(crate) plant_loops: Option<Vec<()>>,
}

impl SelectedSimulationStartup {
    pub(crate) fn check_if_any_ems(&mut self, input: &mut SelectedInputProcessor,
        shortcut: &mut SourceInputProcessorShortCut,
        globals: &mut SelectedHeatBalanceGlobals, report_inputs: &ReportInputs,
        scan: &mut ReportScanState, external_hvac_manager: bool,
        running_via_api: bool, active_callback_count: usize,
        backend: &mut SourceErrorBackend<'_>) -> Result<(), StartupError> {
        let r = &mut self.runtime_language;
        r.number_of_sensors = input.get_num_objects_found("EnergyManagementSystem:Sensor");
        r.number_of_actuators_used = input.get_num_objects_found("EnergyManagementSystem:Actuator");
        r.number_of_program_call_managers = input.get_num_objects_found("EnergyManagementSystem:ProgramCallingManager");
        r.number_of_erl_programs = input.get_num_objects_found("EnergyManagementSystem:Program");
        r.number_of_erl_subroutines = input.get_num_objects_found("EnergyManagementSystem:Subroutine");
        r.number_of_user_global_variables = input.get_num_objects_found("EnergyManagementSystem:GlobalVariable");
        r.number_of_ems_output_variables = input.get_num_objects_found("EnergyManagementSystem:OutputVariable");
        r.number_of_ems_metered_output_variables = input.get_num_objects_found("EnergyManagementSystem:MeteredOutputVariable");
        r.number_of_ems_curve_indices = input.get_num_objects_found("EnergyManagementSystem:CurveOrTableIndexVariable");
        r.number_of_external_interface_global_variables = input.get_num_objects_found("ExternalInterface:Variable");
        r.number_of_fmu_import_global_variables = input.get_num_objects_found("ExternalInterface:FunctionalMockupUnitImport:To:Variable");
        r.number_of_fmu_export_global_variables = input.get_num_objects_found("ExternalInterface:FunctionalMockupUnitExport:To:Variable");
        r.number_of_external_interface_actuators = input.get_num_objects_found("ExternalInterface:Actuator");
        r.number_of_fmu_import_actuators = input.get_num_objects_found("ExternalInterface:FunctionalMockupUnitImport:To:Actuator");
        r.number_of_fmu_export_actuators = input.get_num_objects_found("ExternalInterface:FunctionalMockupUnitExport:To:Actuator");
        r.number_of_ems_construction_indices = input.get_num_objects_found("EnergyManagementSystem:ConstructionIndexVariable");
        let output_ems_objects = input.get_num_objects_found("Output:EnergyManagementSystem");
        let python_plugins = input.get_num_objects_found("PythonPlugin:Instance");
        globals.any_energy_management_system_in_model = [r.number_of_sensors, r.number_of_actuators_used,
            r.number_of_program_call_managers, r.number_of_erl_programs, r.number_of_erl_subroutines,
            r.number_of_user_global_variables, r.number_of_ems_output_variables, r.number_of_ems_curve_indices,
            r.number_of_external_interface_global_variables, r.number_of_external_interface_actuators,
            r.number_of_ems_construction_indices, r.number_of_ems_metered_output_variables,
            r.number_of_fmu_import_actuators, r.number_of_fmu_import_global_variables,
            r.number_of_fmu_export_actuators, r.number_of_fmu_export_global_variables,
            output_ems_objects, python_plugins, active_callback_count].iter().any(|&count| count > 0);
        globals.any_energy_management_system_in_model = globals.any_energy_management_system_in_model
            || external_hvac_manager || running_via_api;
        let mut diagnostic = |diagnostic| match diagnostic {
                ReportScanDiagnostic::Warning(message) => backend.show_warning_error(&message),
                ReportScanDiagnostic::Continue(message) => backend.show_continue_error(&message),
            };
        let result = if scan.get_report_input {
            let mut source = SourceReportScanInput::new(input, shortcut, report_inputs).map_err(StartupError::Scan)?;
            try_scan_for_reports_with_input(report_inputs, scan, "EnergyManagementSystem", None, None, None, &mut source, &mut diagnostic)
        } else {
            // A cached request does not inspect or rewrite inactive getter operands.
            try_scan_for_reports(report_inputs, scan, "EnergyManagementSystem", None, None, None, &mut diagnostic)
        };
        r.output_edd_file = result.map_err(|error| match error {
                ReportScanFailure::Unavailable(error) => StartupError::Scan(error),
                ReportScanFailure::Diagnostic(error) => StartupError::Backend(error),
            })?;
        if globals.any_energy_management_system_in_model {
            return Err(StartupError::Unavailable("active EMS/API/plugin/EDD producer outside selected route"));
        }
        if r.output_edd_file {
            backend.show_warning_error("CheckIFAnyEMS: No EnergyManagementSystem has been set up in the input file but output is requested.")?;
            backend.show_continue_error("No EDD file will be produced. Refer to EMS Application Guide and/or InputOutput Reference to set up your EnergyManagementSystem.")?;
        }
        Ok(())
    }

    pub(crate) fn is_input_object_used(&mut self, input: &mut SelectedInputProcessor,
        shortcut: &mut SourceInputProcessorShortCut, globals: &mut SelectedHeatBalanceGlobals,
        report_inputs: &ReportInputs, scan: &mut ReportScanState,
        external_hvac_manager: bool, running_via_api: bool, active_callback_count: usize,
        backend: &mut SourceErrorBackend<'_>) -> Result<(), StartupError> {
        globals.air_loop_hvac_doas_used_in_sim = input.get_num_objects_found("AirLoopHVAC:DedicatedOutdoorAirSystem") > 0;
        self.check_if_any_ems(input, shortcut, globals, report_inputs, scan, external_hvac_manager,
            running_via_api, active_callback_count, backend)?;
        shortcut.current_module_object = "PlantLoop".into();
        let plant = input.get_num_objects_found(&shortcut.current_module_object);
        shortcut.current_module_object = "CondenserLoop".into();
        let condenser = input.get_num_objects_found(&shortcut.current_module_object);
        globals.any_plant_in_model = plant > 0 || condenser > 0;
        if !globals.any_plant_in_model { self.plant_loops = Some(Vec::new()); }
        globals.any_slabs_in_model = input.get_num_objects_found("Site:GroundDomain:Slab") > 0;
        globals.any_basements_in_model = input.get_num_objects_found("Site:GroundDomain:Basement") > 0;
        globals.any_ideal_cond_ent_setpoint_in_model = input.get_num_objects_found("SetpointManager:CondenserEnteringReset:Ideal") > 0;
        Ok(())
    }
}

// Actual FileSystem::fileExists: exists and not a directory, following symlinks.
// Unexpected filesystem errors propagate instead of becoming "not attached".
fn weather_file_exists(path: &Path) -> Result<bool, StartupError> {
    match std::fs::metadata(path) {
        Ok(metadata) => Ok(!metadata.is_dir()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(StartupError::Filesystem(error)),
    }
}

pub(crate) fn check_environment_specifications(input: &SelectedInputProcessor,
    controls: SetupSimulationControls, run_control_in_input: bool, run_periods_in_input: bool,
    globals: &SelectedHeatBalanceGlobals, input_weather_file_path: &Path,
    backend: &mut SourceErrorBackend<'_>) -> Result<(), StartupError> {
    let mut errors_found = false;
    let zone = input.get_num_objects_found("Sizing:Zone");
    let system = input.get_num_objects_found("Sizing:System");
    let plant = input.get_num_objects_found("Sizing:Plant");
    let design_days = input.get_num_objects_found("SizingPeriod:DesignDay");
    let weather_days = input.get_num_objects_found("SizingPeriod:WeatherFileDays");
    let condition_types = input.get_num_objects_found("SizingPeriod:WeatherFileConditionType");
    let sizing_days = design_days > 0 || weather_days > 0 || condition_types > 0;
    let weather_design = weather_days > 0 || condition_types > 0;
    let weather_attached = weather_file_exists(input_weather_file_path)?;
    if run_control_in_input {
        if controls.zone_sizing() {
            if zone > 0 && !sizing_days {
                errors_found = true;
                backend.show_severe_error("CheckEnvironmentSpecifications: Sizing for Zones has been requested but there are no design environments specified.")?;
                backend.show_continue_error("...Add appropriate SizingPeriod:* objects for your simulation.")?;
            }
            if zone > 0 && weather_design && !weather_attached {
                errors_found = true;
                backend.show_severe_error("CheckEnvironmentSpecifications: Sizing for Zones has been requested; Design period from the weather file requested; but no weather file specified.")?;
            }
        }
        if controls.system_sizing() {
            if system > 0 && !sizing_days {
                errors_found = true;
                backend.show_severe_error("CheckEnvironmentSpecifications: Sizing for Systems has been requested but there are no design environments specified.")?;
                backend.show_continue_error("...Add appropriate SizingPeriod:* objects for your simulation.")?;
            }
            if system > 0 && weather_design && !weather_attached {
                errors_found = true;
                backend.show_severe_error("CheckEnvironmentSpecifications: Sizing for Systems has been requested; Design period from the weather file requested; but no weather file specified.")?;
            }
        }
        if controls.plant_sizing() {
            if plant > 0 && !sizing_days {
                errors_found = true;
                backend.show_severe_error("CheckEnvironmentSpecifications: Sizing for Equipment/Plants has been requested but there are no design environments specified.")?;
                backend.show_continue_error("...Add appropriate SizingPeriod:* objects for your simulation.")?;
            }
            if plant > 0 && weather_design && !weather_attached {
                errors_found = true;
                backend.show_severe_error("CheckEnvironmentSpecifications: Sizing for Equipment/Plants has been requested; Design period from the weather file requested; but no weather file specified.")?;
            }
        }
        if controls.run_sizing_periods() && !sizing_days {
            backend.show_warning_error("CheckEnvironmentSpecifications: SimulationControl specified doing design day simulations, but no design environments specified.")?;
            backend.show_continue_error("...No design environment results produced. For these results, add appropriate SizingPeriod:* objects for your simulation.")?;
        }
        if controls.run_sizing_periods() && weather_design && !weather_attached {
            errors_found = true;
            backend.show_severe_error("CheckEnvironmentSpecifications: SimulationControl specified doing design day simulations; weather file design environments specified; but no weather file specified.")?;
        }
        if controls.run_weather_periods() && !run_periods_in_input {
            backend.show_warning_error("CheckEnvironmentSpecifications: SimulationControl specified doing weather simulations, but no run periods for weather file specified.  No annual results produced.")?;
        }
        if controls.run_weather_periods() && run_periods_in_input && !weather_attached {
            backend.show_warning_error("CheckEnvironmentSpecifications: SimulationControl specified doing weather simulations; run periods for weather file specified; but no weather file specified.")?;
        }
    }
    if !controls.run_sizing_periods() && !controls.run_weather_periods() {
        if !controls.hvac_sizing_simulation() && !globals.do_pure_load_calc {
            backend.show_severe_error("All elements of SimulationControl are set to \"No\". No simulations can be done. Program terminates.")?;
            errors_found = true;
        } else {
            backend.show_warning_error("\"Run Simulation for Sizing Periods\" and \"Run Simulation for Weather File Run Periods\" are both set to \"No\". No simulations will be performed, and most input will not be read.")?;
        }
    }
    if errors_found { return fatal(backend, "Program terminates due to preceding conditions."); }
    Ok(())
}

pub(crate) fn check_for_requested_reporting(input: &SelectedInputProcessor,
    controls: SetupSimulationControls, globals: &SelectedHeatBalanceGlobals,
    backend: &mut SourceErrorBackend<'_>) -> Result<(), StartupError> {
    let simulation_periods = input.get_num_objects_found("SizingPeriod:DesignDay") > 0
        || input.get_num_objects_found("SizingPeriod:WeatherFileDays") > 0
        || input.get_num_objects_found("SizingPeriod:WeatherFileConditionType") > 0
        || input.get_num_objects_found("RunPeriod") > 0;
    if (controls.run_sizing_periods() || controls.run_weather_periods() || globals.do_pure_load_calc) && simulation_periods {
        let requested = ["Output:Table:SummaryReports", "Output:Table:TimeBins", "Output:Table:Monthly",
            "Output:Table:Annual", "Output:Variable", "Output:Meter", "Output:Meter:MeterFileOnly",
            "Output:Meter:Cumulative", "Output:Meter:Cumulative:MeterFileOnly"].iter()
            .any(|name| input.get_num_objects_found(name) > 0);
        if !requested {
            backend.show_warning_error("No reporting elements have been requested. No simulation results produced.")?;
            backend.show_continue_error("...Review requirements such as \"Output:Table:SummaryReports\", \"Output:Table:Monthly\", \"Output:Variable\", \"Output:Meter\" and others.")?;
        }
    }
    Ok(())
}

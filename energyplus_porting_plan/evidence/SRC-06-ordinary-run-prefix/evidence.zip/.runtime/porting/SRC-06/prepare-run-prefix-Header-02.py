from pathlib import Path
import hashlib,json,difflib
ROOT=Path.cwd()
PARENT=ROOT/'.runtime/porting/SRC-06/ordinary-run-prefix-prep-01'
UNIT=ROOT/'.runtime/porting/SRC-06/ordinary-run-prefix-prep-02'
if UNIT.exists(): raise SystemExit('immutable packet already exists')
UNIT.mkdir(parents=True)
def ref(p):
    p=Path(p);p=p if p.is_absolute() else ROOT/p;b=p.read_bytes()
    return {'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def change(text,before,after):
    if text.count(before)!=1:raise ValueError((before[:120],text.count(before)))
    return text.replace(before,after,1)
m=json.loads((PARENT/'manifest.json').read_bytes())
rows=[]
for row in m['files']:
    path=row['canonical_path'];source=ROOT/row['proposal']['path'];b=source.read_bytes();t=b.decode()
    if path=='crates/ep_run/src/ctf_initialization_outputs.rs':
        t=change(t,'"Timestep":{"t":{}},"Zone":{"z":{}},','''"Timestep":{"t":{}},"Zone":{"z":{}},
            "Output:Table:SummaryReports":{"summary":{"reports":[{"report_name":"AllSummary"}]}},''')
        t=change(t,'                schedules: crate::ordinary_schedule_input::resolve(&raw)?,','''                schedules: crate::ordinary_schedule_input::resolve(&raw)?,
                sizing: crate::ordinary_sizing_input::resolve(&raw)?,''')
        needle='''        success.persist(&dir)?;
        let actual_eio = std::fs::read(dir.join("eplusrs.eio"))?;'''
        t=change(t,needle,'''        assert!(success.reports.selected_input_processor.as_ref().ok_or("sole IP missing")?
            .is_object_unused("Output:Table:SummaryReports", "summary"));
        success.initialize_source_run_prefix(&ep_model::ReportInputs::default())?;
        assert!(success.reports.setup_simulation_registry_prepared);
        assert!(success.reports.registry.report_count > 0);
        assert!(!success.state.doing_sizing, "actual240 must follow successful234");
        assert!(!success.reports.selected_input_processor.as_ref().ok_or("sole IP missing")?
            .is_object_unused("Output:Table:SummaryReports", "summary"));
        success.persist(&dir)?;
        let actual_eio = std::fs::read(dir.join("eplusrs.eio"))?;''')
        needle='''        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?, actual_eio);
        drop(success);'''
        t=change(t,needle,'''        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?, actual_eio);
        let reached_reports = success.reports.registry.report_count;
        let repeated = success.initialize_source_run_prefix(&ep_model::ReportInputs::default())
            .err().ok_or("actual duplicate pointer did not stop")?;
        assert!(repeated.contains("SetupTimePointers was already called for Zone"));
        assert!(success.reports.registry.report_count > reached_reports,
            "actual repeated215 occurs before duplicate218 fatal");
        assert!(!success.state.doing_sizing);
        assert!(!success.reports.selected_input_processor.as_ref().ok_or("sole IP missing")?
            .is_object_unused("Output:Table:SummaryReports", "summary"));
        success.persist(&dir)?;
        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?, actual_eio);
        drop(success);

        // A genuine association failure reached inside234 keeps233 true and
        // retains all real six-handler/file/registry prefixes without retry.
        let mut sizing_failure = CtfRunOutputs::new("26.1");
        let (input, mut operands) = make_input()?;
        operands.sizing.summary_report_objects[0].object_name = "wrong permanent key".into();
        sizing_failure.reports.initialize_input_processor(input)?;
        sizing_failure.prepare_source_environment(&dir, operands)?;
        sizing_failure.initialize_source_state(&ep_model::ReportInputs::default())?;
        let sizing_error = sizing_failure.initialize_source_run_prefix(&ep_model::ReportInputs::default())
            .err().ok_or("actual234 association did not fail")?;
        assert!(sizing_error.contains("summary permanent/extensible association"));
        assert!(sizing_failure.state.doing_sizing, "Err234 must not execute240");
        assert!(sizing_failure.reports.setup_simulation_registry_prepared);
        assert!(sizing_failure.reports.registry.report_count > 0);
        assert!(sizing_failure.reports.selected_input_processor.as_ref().ok_or("sole IP missing")?
            .is_object_unused("Output:Table:SummaryReports", "summary"));
        sizing_failure.persist(&dir)?;
        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?, actual_eio);
        drop(sizing_failure);''')
    if t.encode()!=b:
        p=UNIT/'proposed'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.encode())
        pd=UNIT/'parent-diffs'/(path.replace('/','__')+'.diff');pd.parent.mkdir(parents=True,exist_ok=True)
        pd.write_bytes(''.join(difflib.unified_diff(b.decode().splitlines(True),t.splitlines(True),fromfile=row['proposal']['path'],tofile='proposed/'+path)).encode())
        base=(ROOT/row['before']['path']).read_bytes()
        d=UNIT/'diffs'/(path.replace('/','__')+'.diff');d.parent.mkdir(parents=True,exist_ok=True)
        d.write_bytes(''.join(difflib.unified_diff(base.decode().splitlines(True),t.splitlines(True),fromfile='before/'+path,tofile='proposed/'+path)).encode())
        row={**row,'parent_proposal':row['proposal'],'proposal':ref(p),'complete_diff':ref(d),'complete_parent_diff':ref(pd),'test_bodies_after':t.count('#[test]')}
    rows.append(row)
m.update(schema='src06-held-source-run-prefix.v2',author=ref(Path(__file__).resolve()),parent_manifest=ref(PARENT/'manifest.json'),base_head='1f59f2ba',files=rows)
readme=(PARENT/'README.md').read_text(encoding='utf-8')+'''
## Source02 existing-body verification

Only the existing ep_run output/fatal body is expanded; no new test body or binary.
The unchanged admitted AllSummary object proves real SummaryReports unused erase.
Real prefix success checks reached predefined registry and240 diagnostic state.
Repeated prefix checks original215 append before218 duplicate-target fatal, retaining
the consumed input and EIO bytes. A deliberately wrong permanent SummaryReports
association reaches234 after all eight getters; the existing diagnostic carrier
must retain233 DoingSizing=true and the actual SummaryReports object remains unused.
The actual CtfRunOutputs/file owner and real filesystem are used throughout.
No new private owner snapshot API or mock weather numerical result is introduced.
All production Source is byte-exact01; Root still owns actual formatting/QA.
'''
(UNIT/'README.md').write_bytes(readme.encode())
m['README']=ref(UNIT/'README.md')
m['actual_new_test_bodies']=sum(r['test_bodies_after']-r['test_bodies_before'] for r in rows)
assert m['actual_new_test_bodies']==0
(UNIT/'manifest.json').write_bytes((json.dumps(m,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps(ref(UNIT/'manifest.json')))

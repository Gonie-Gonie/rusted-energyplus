"""Apply an independently accepted finite prefix packet on the exact clean base."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
packet = base / 'ordinary-run-prefix-prep-02/manifest.json'
review = root / sys.argv[1]
review_sha = sys.argv[2]
out = base / 'ordinary-run-prefix-assembly-01'
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
        'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, value): path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode())

def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value, list):
        for child in value: yield from walk(child)

assert not subprocess.check_output(['git', 'status', '--porcelain'])
head = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert head.startswith('1f59f2ba')
assert ref(packet)['sha256'] == 'e796964b6deefa900ef3c55ce336ac465f92d4d0f4af68050257d32a95d6fb16'
assert ref(review)['sha256'] == review_sha
m = json.loads(packet.read_bytes())
r = json.loads(review.read_bytes())
assert r['accepted'] is True
assert any(row['sha256'] == ref(packet)['sha256'] for row in walk(r))
paths = [row['canonical_path'] for row in m['files']]
assert len(paths) == len(set(paths)) == 16
for row in m['files']:
    assert row['canonical_path'].startswith('crates/') and row['canonical_path'].endswith('.rs')
    for key in ['before', 'proposal', 'complete_diff']:
        assert ref(root / row[key]['path'])['sha256'] == row[key]['sha256']
    target = root / row['canonical_path']
    before = target.read_bytes() if target.exists() else b''
    assert before.replace(b'\r\n', b'\n') == (root / row['before']['path']).read_bytes()
    if target.exists():
        assert subprocess.check_output(['git', 'show', head + ':' + row['canonical_path']]) == before
    else:
        missing = subprocess.run(['git', 'cat-file', '-e', head + ':' + row['canonical_path']], capture_output=True)
        assert missing.returncode != 0

out.mkdir()
rows = []
for row in m['files']:
    target = root / row['canonical_path']
    existed = target.exists()
    before = target.read_bytes() if existed else b''
    saved = out / 'before' / row['canonical_path']
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(before)
    proposal = (root / row['proposal']['path']).read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(proposal)
    rows.append({'canonical_path': row['canonical_path'], 'existed_before': existed,
        'before': ref(saved), 'accepted_proposal': row['proposal'], 'after_apply': ref(target)})
write(out/'apply.json', {'schema': 'src06-run-prefix-apply.v1', 'HEAD': head,
    'accepted_packet': ref(packet), 'independent_Source_review': ref(review),
    'files': rows, 'author': ref(Path(__file__)), 'targets_executed': []})
print(json.dumps({'apply': ref(out/'apply.json'), 'files': len(rows)}))

"""Publish one actual reached startup prefix, preserving finite Source custody."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = root / 'energyplus_porting_plan/evidence/SRC-06-ordinary-run-prefix'
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}
def load(path): return json.loads(path.read_bytes())
def write(path, value): path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value, list):
        for child in value: yield from walk(child)

assembly_path = base / 'ordinary-run-prefix-assembly-01/manifest.json'
held_path = base / 'ordinary-run-prefix-prep-02/manifest.json'
assembly, held = load(assembly_path), load(held_path)
assert ref(assembly_path)['sha256'] == 'fb5be68e4d8a57e76076cb273803b669fc2d1439eb235854f0fb290ec17d719a'
assert ref(held_path)['sha256'] == 'e796964b6deefa900ef3c55ce336ac465f92d4d0f4af68050257d32a95d6fb16'
review_paths = [base/name/'review.json' for name in [
    'Owner-ordinary-run-prefix-Source-review-02', 'Owner-ordinary-run-prefix-application-review-01',
    'Header-ordinary-run-prefix-selfcheck-02']]
assert ref(review_paths[0])['sha256'] == 'a8137a622c5892825bf4433a5dcb363a39deaeccbeb689806b76eafec5112b1f'
assert ref(review_paths[1])['sha256'] == '1457d29b6e062e5bfed13ac16f8c7b585e2191e11e0e217da2c6723e055b5f59'
assert all(load(path)['accepted'] for path in review_paths[:2])
archives = {}
for m in [assembly, held]:
    for row in m['files']:
        for key in ['before','after','proposal','accepted_proposal']:
            value = row.get(key)
            if value: archives[value['sha256']] = root / value['path']
artifacts, historical = {}, []
def add(path):
    value = ref(path)
    artifacts[value['path']] = value
    return value
def checked(row):
    path = root / row['path']
    if not path.is_file() or ref(path)['sha256'] != row['sha256']:
        path = archives[row['sha256']]
        historical.append({'historical_reference':row, 'exact_archive':ref(path),
            'qualification':'Historical canonical/after_apply reference resolved by identical complete immutable bytes; not relabeled current.'})
    actual = ref(path)
    assert actual['sha256'] == row['sha256'] and actual['size_bytes'] == row.get('size_bytes',actual['size_bytes'])
    return path
for path in [assembly_path,held_path,*review_paths,base/'ordinary-run-prefix-assembly-01/apply.json']:
    add(path)
    for row in walk(load(path)): add(checked(row))
for row in assembly['files']:
    assert ref(root / row['canonical']['path']) == row['canonical']
for dep in held['dependencies']:
    path = checked(dep['manifest'])
    add(path)
    # Future HB/OP manifests are provenance only; their algorithms are not
    # reached by the current prefix. Bundle only active prerequisite literals.
    if dep['role'].startswith('future_'): continue
    for key,value in load(path).items():
        if 'original' in key.lower() or 'schema' in key.lower():
            for row in walk(value): add(checked(row))
add(base/'run-ci-force-time-step-Root-01.ps1')
qa, tests, snapshot = [], [], None
for suffix in ['fmt','quality','clippy','input-output-tests','cli-tests','ci-timestep-tests']:
    path = base/f'ordinary-run-prefix-{suffix}-01/receipt.json'
    value = load(path)
    assert value['exit_code'] == 0 and value['launch_error'] is None
    assert value['source_bytes_match_before_and_after'] is True
    if snapshot is None: snapshot = value['source_snapshot']
    assert value['source_snapshot'] == snapshot
    qa.append({'receipt':ref(path),'command':value['command'],'exit_code':0})
    add(path)
    for key in ['stdout','stderr','source_snapshot']: add(checked(value[key]))
    if 'tests' in suffix:
        groups = [tuple(map(int,row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',checked(value['stdout']).read_text(encoding='utf8'))]
        assert groups and all(row[1] == row[2] == 0 for row in groups)
        tests.append({'scope':suffix,'passed':sum(row[0] for row in groups),'failed':0,'ignored':0})
assert [row['passed'] for row in tests] == [2,1,1]
add(Path(__file__))
out.mkdir()
archive = out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts): z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(artifacts)
    for name in z.namelist(): assert hashlib.sha256(z.read(name)).hexdigest() == artifacts[name]['sha256']
write(out/'manifest.json',{'schema':'src06-run-prefix-evidence.v1',
    'Source_snapshot':snapshot,'assembly':ref(assembly_path),'independent_reviews':[ref(path) for path in review_paths[:2]],
    'artifacts':list(artifacts.values()),'historical_references':historical,
    'archive':ref(archive),'archive_member_count':len(artifacts),
    'archive_scope':'16 actual full before/after/direct diffs and held-to-formatter diffs; finite active startup/sizing/branch/facility Original literal/schema prerequisites, independent review and actual six QA receipts/logs/Source indexes. Future HB/OP manifests and prior six-handler assembly are provenance, not bundled full transitive Source trees or Native binaries.',
    'gates_updated':False})
write(out/'summary.json',{'schema':'src06-run-prefix-summary.v1',
    'status':'Actual bounded ordinary RunSimulation205/213-241 prefix connected; later startup and full Setup incomplete',
    'Source_snapshot':snapshot,'behavior':[
        'Actual RunPeriodsInInput205 short-circuit queries precede both real init guards; same actual weather path reaches environment213/report214 checks.',
        'Same predefined registry215 is retained before actual preconstruction216 bounds and Zone/System218/220 live timestep field bindings. Reentry performs215 again then raises the genuine duplicate Zone-pointer fatal.',
        'Facility222 and coil223 actual constructors, repeated EMS/isInputUsed225, Branch227/Connector228 and zero-plugin231 path consume the same IP/shortcut and retain partial owner prefixes.',
        'DoingSizing233 is true before eight ordered selected ManageSizing234 getters. Actual default OA uses the genuine AlwaysOn schedule index. SummaryReports resets its local arguments, erases exact unused identity, then fills; shared arguments are not substituted.',
        'Actual DoOutputReporting237/DoingSizing240/doSpace241 assignments use the same weather/global and sole focused space-control owner; Err234 retains DoingSizing=true.',
        'Later HB GetProjectControl must borrow the same space-control owner; later gains must move the same facility. No second authority is created by this prefix.',
    ],'QA':qa,'tests':{'selections':tests,'passed':4,'failed':0,'ignored':0,'new_bodies':0,'new_binaries':0},
    'validation_scope':'Existing output/fatal body verifies registry reach, real SummaryReports unused erase, repeated215-before218 fatal and Err234 DoingSizing retention. Existing raw admission and actual normal/CI_FORCE_TIME_STEP=Y CLI pass. One fmt/quality/all-target workspace Clippy run; no repeated full-workspace test suite or new Native execution.',
    'limitations':[
        'Full RunSimulation243+ and SetupSimulation/HeatBalance/HVAC remain incomplete. Positive sizing/SpaceHVAC/branch/connector/plugin/EMS and WindowEquivalentLayer getter branches remain explicitly unavailable.',
        'Live time target resolution expects the genuine caller weather/HVAC owners; downstream report writers and requested-variable registration are separate held work.',
        'Selected Rust regression and independent Source review do not certify new Native numerical equivalence.',
        'Whole ordinary235456 mismatches/2754 unavailable, DesignDay nine strict failures/eight UNPAIRED fields and existing tolerance policy unchanged.',
        'SRC06 four gates remain unverified; A14/54 B14/64 unchanged.',
    ],'independent_reviews':[ref(path) for path in review_paths[:2]],
    'manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False})
plan_path = root/'energyplus_porting_plan/plan.json'
plan = load(plan_path)
task = next(row for row in plan['tasks'] if row['id']=='SRC-06')
assert all(task[key]=='미확인' for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_run_prefix' not in task
task['actual_selected_ordinary_run_prefix'] = ref(out/'summary.json')
write(plan_path,plan)
card = root/'energyplus_porting_plan/cards/SRC-06.md'
text = card.read_text(encoding='utf8')
assert text.count('아래 18개 요약') == 1
text = text.replace('아래 18개 요약','아래 19개 요약')
needle = '\n기존 Weather03·absent site/station'
assert text.count(needle)==1
text = text.replace(needle,'| 실제 실행 전 검사 / Sizing·출력 시간 연결 | [요약](../evidence/SRC-06-ordinary-run-prefix/summary.json) · [색인](../evidence/SRC-06-ordinary-run-prefix/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-run-prefix/evidence.zip) | 실제205/213–241의 검사·등록·bounds·서비스·8개 sizing getter, 동일 상태와 오류 prefix. 전체 startup/Setup·Native 수치 완료는 아님. |\n'+needle)
needle = '\n## 이력과 증거 보존'
assert text.count(needle)==1
text = text.replace(needle,'\n## 실제 실행 전 검사 연결 단위의 QA\n\nSource `'+snapshot['sha256']+'`에서 fmt·source-quality·all-target workspace Clippy와 기존 입력/출력 2개·일반 CLI 1개·실제 `CI_FORCE_TIME_STEP=Y` CLI 1개, **4 passed / 0 failed / 0 ignored**를 확인했다. 기존 output/fatal 본문에 SummaryReports의 정확한 unused erase, 실제215 이후218 재호출 fatal과234 실패 시 DoingSizing=true 보존을 추가했다. 새 테스트 본문·binary와 전체 workspace 반복 실행은 없다. actual 파일 16개의 전체 diff·독립 검토와 실제 QA Source를 고정했으며, 앞 단위의20개 성공은 중복 합산하지 않는다. 모든 gate와 A/B 완료 수는 그대로다.\n'+needle)
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'archive_members':len(artifacts),'archive_bytes':archive.stat().st_size,'tests':tests},ensure_ascii=False))

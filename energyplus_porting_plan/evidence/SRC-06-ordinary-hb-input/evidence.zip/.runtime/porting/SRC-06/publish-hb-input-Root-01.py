"""Publish the actual selected HB input assembly and finite affected checks."""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

root = Path.cwd()
base = root/'.runtime/porting/SRC-06'
out = root/'energyplus_porting_plan/evidence/SRC-06-ordinary-hb-input'
assert not out.exists()
assembly_path = base/'ordinary-hb-input-assembly-03/manifest.json'
review_path = root/sys.argv[1]
review_sha, assembly_sha = sys.argv[2:]

def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path): return json.loads(path.read_bytes())
def write(path,value): path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value: yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value,list):
        for child in value: yield from walk(child)
assert ref(assembly_path)['sha256']==assembly_sha
assert ref(review_path)['sha256']==review_sha and load(review_path)['accepted'] is True
assert any(row['sha256']==assembly_sha for row in walk(load(review_path)))
assembly=load(assembly_path)
held_path=root/assembly['accepted_packet']['path']
assert ref(held_path)['sha256']=='dd54bbcbae55d389d1fd92313c6a56707b4b02d188a41db2909e61b637ede082'
artifacts,historical,archives={},{},{}
versions=[(assembly_path,assembly)]
while 'additional_provenance' in versions[-1][1]:
    path=root/versions[-1][1]['additional_provenance']['prior_actual_assembly']['path']
    versions.append((path,load(path)))
assert len(versions)==3
correction_paths=[root[value['additional_provenance']['correction_packet']['path'] for _,value in versions if 'additional_provenance' in value]
for _,version in versions:
    for row in version['files']:
        for key in ['before','after','accepted_proposal']:
            value=row[key]; archives[value['sha256']]=root/value['path']
for path in correction_paths:
    for row in load(path)['files']:
        for key in ['before','proposal']:
            value=row[key]; archives[value['sha256']]=root/value['path']
def add(path):
    value=ref(path); artifacts[value['path']]=value; return value
def checked(row):
    path=root/row['path']
    if not path.is_file() or ref(path)['sha256']!=row['sha256']:
        path=archives[row['sha256']]
        historical[row['path']+row['sha256']]={'historical_reference':row,'exact_archive':ref(path),
            'qualification':'Exact immutable historical bytes, not relabeled current.'}
    actual=ref(path)
    assert actual['sha256']==row['sha256'] and actual['size_bytes']==row.get('size_bytes',actual['size_bytes'])
    return path
paths=[held_path,root/assembly['independent_Source_review']['path'],review_path]
for path,value in versions:
    paths.extend([path,root/value['apply']['path']])
    if 'additional_provenance' in value:
        detail=value['additional_provenance']
        paths.extend(root/detail[key]['path'] for key in ['correction_packet','independent_correction_Source_review','prior_application_review'])
for path in dict.fromkeys(paths):
    add(path)
    for row in walk(load(path)): add(checked(row))
for row in assembly['files']: assert ref(root/row['canonical']['path'])==row['canonical']
historical_QA=[]
for row in [row for _,value in reversed(versions) if 'additional_provenance' in value for row in value['additional_provenance']['prior_QA_receipts']]:
    path=checked(row);value=load(path)
    assert value['source_bytes_match_before_and_after'] is True
    historical_QA.append({'receipt':ref(path),'exit_code':value['exit_code'],
        'qualification':'Actual historical Source01/02 result, preserved without relabeling as final Source03. Source02 focused failure includes10 partial passes,1 failure,and no runtime3 execution.'})
    add(path)
    for key in ['stdout','stderr','source_snapshot']: add(checked(value[key]))
assert [row['exit_code'] for row in historical_QA]==[0,0,101,101,0,0,101,101]
add(base/'run-ci-force-time-step-Root-01.ps1')
cargo='C:/Users/GonieGonie/.cargo/bin/cargo.exe'
expected_commands={
    'fmt':[cargo,'fmt','--all','--','--check'],
    'quality':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1'],
    'clippy':[cargo,'clippy','--workspace','--all-targets','--','-D','warnings'],
    'focused-tests':[cargo,'test','-p','ep_runtime','-p','ep_compiler','-p','ep_raw_model','-p','ep_run','--lib','--',
        'early_report_scan_is_shared_and_prescanned_owner_is_not_replayed',
        'ordinary_cache_uses_real_registry_columns_and_postlude_before_lifecycle',
        'source_constructor_defaults_and_allocation_are_distinct','compiler::report_inputs::',
        'twelve_unnamed_reports_keep_actual_idf_count_order_and_field_counts',
        'actual_fatal_prefix_survives_runtime_failure_and_summary',
        'raw_equipment_admission_preserves_empty_presence_and_rejects_positive_or_field_branches'],
    'cli-tests':[cargo,'test','-p','ep_run','--test','arbitrary_run','one_zone_runtime_writes_stable_output_layout'],
    'ci-timestep-tests':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','.runtime/porting/SRC-06/run-ci-force-time-step-Root-01.ps1'],
}
qa,tests,snapshot=[],[],None
for suffix,expected in expected_commands.items():
    path=base/f'ordinary-hb-input-{suffix}-03/receipt.json'
    value=load(path)
    assert value['command']==expected
    assert value['exit_code']==0 and value['launch_error'] is None and value['source_bytes_match_before_and_after'] is True
    if snapshot is None: snapshot=value['source_snapshot']
    assert snapshot==value['source_snapshot']
    qa.append({'receipt':ref(path),'command':value['command'],'exit_code':0})
    add(path)
    for key in ['stdout','stderr','source_snapshot']: add(checked(value[key]))
    if 'tests' in suffix:
        groups=[tuple(map(int,row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',checked(value['stdout']).read_text(encoding='utf8'))]
        assert groups and all(row[1]==row[2]==0 for row in groups)
        if suffix=='focused-tests': assert sorted(row[0] for row in groups)==[1,2,3,8]
        else: assert groups==[(1,0,0)]
        tests.append({'scope':suffix,'package_group_results':groups,'passed':sum(row[0] for row in groups),'failed':0,'ignored':0})
assert [row['passed'] for row in tests]==[14,1,1]
add(Path(__file__))
out.mkdir()
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts): z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(artifacts)
    for name in z.namelist(): assert hashlib.sha256(z.read(name)).hexdigest()==artifacts[name]['sha256']
write(out/'manifest.json',{'schema':'src06-selected-hb-input-evidence.v1','Source_snapshot':snapshot,
    'assembly':ref(assembly_path),'artifacts':list(artifacts.values()),'historical_references':list(historical.values()),
    'archive':ref(archive),'archive_member_count':len(artifacts),
    'archive_scope':'48 full actual before/after files and direct/formatter diffs; original45 Source01 and47 Source02 custody plus six API corrections and five lint/fixture corrections; finite held provenance/91 literal Original ranges; independent Source/application/correction reviews; six final and eight genuine historical QA receipts/logs/Source indexes. No recursive older packets, full Source clone or large Native objects.',
    'gates_updated':False})
write(out/'summary.json',{'schema':'src06-selected-hb-input-summary.v1',
    'status':'Actual ordinary selected HB inputs and retained weather/output handoff connected; full Setup/GetHeatBalanceInput pending',
    'Source_snapshot':snapshot,'behavior':[
        'The same retained ordinary session supplies actual Station EIO before its existing weather selection. The HB initializer borrows that same weather environment/minutes, EIO, InputProcessor/unused identities and six shared argument arrays.',
        'ProjectControl, SiteAtmosphere, Spectral/Material/Hysteresis/FrameDivider, regular Construction, Shadowing and Zone/implicit Space getters execute before the existing physical geometry return. Sole early Space controls are borrowed; no duplicate Sizing/Simulation controls are introduced.',
        'Raw Building/Construction/Zone/NoMass projections preserve loader origin and genuine IDF positional field counts. Material properties and current CTF/LU/Solar mathematics remain the existing numerical producers.',
        'Reached construction usage and Zone constructor owners are retained, with genuine ordered GrossArea-weighted centroid accumulation and guarded divisions over existing surface geometry. Full SurfaceTmp/final-sort/Space-range/min-max/report lifecycle remains incomplete.',
        'Output:Variable getter owns local scratch and exact reset/unused erase/partial ReqVar prefixes. The sole prescan/time-binding registry is extended, and four unmatched Zone output setup/dictionary/total operations use the genuine retained MTD file host.',
        'MINREPORTFREQUENCY and clipping settings are acquired once in actual early SystemVariables order. Report-input failure or later initializer errors retain reached owners, EIO and MTD bytes. Sole globals and Zone owners move to HeatBalanceState only after successful initialization.',
    ],'QA':qa,'historical_QA':historical_QA,'tests':{'selections':tests,'passed':16,'failed':0,'ignored':0,'new_bodies':0,'new_binaries':0},
    'validation_scope':'One four-package filtered lib command runs14 existing tests; normalCLI1 and actual CI_FORCE_TIME_STEP=Y CLI1. One fmt/source-quality/all-target workspace Clippy. No full workspace-test repeat or new Native execution; earlier unit passes are not recounted.',
    'limitations':[
        'Selected getter assembly is not a complete GetHeatBalanceInput, SetupSimulation, InitHeatBalance, surface geometry lifecycle, radiation/inside solver or HVAC completion.',
        'Current eager weather allocation and eager CTF/Solar preparation remain known limitations until genuine Setup/BeginSim orchestration is connected.',
        'Matched OutVar/report-dictionary writers, RE2 keys, nonblank output schedule and nonempty minimum-report-frequency branches remain explicitly unavailable after their genuine reached prefixes. Positive excluded input families are not widened.',
        'Three top-comment02 changes preserve01 tokens. Two inherited whole-payload equality annotations apply to01 or02 only after the exact comment inverse, as qualified in independent review; bundled fmath custody is local and not falsely labeled Git-tracked.',
        'Generic apply01 rejected genuine new-file before=None during prevalidation, without canonical writes; apply02 records the preserved author failure and reverified clean Git base. This was not a Rust/QA failure.',
        'Actual Source01 Clippy and focused compiler runs failed101 before tests. Source02 fixes six API/import/error-wrapper/legacy-literal/caller sites. Source02 Clippy failed101 on five style issues; focused tests failed101 on an old staged IDF that omitted its converted Building, after10 partial passes and before runtime3. Source03 preserves exact output bytes/ASCII characters, consumes the same borrowed host and fixes that fixture without weakening production validation. All old receipts/custody are retained; final tests are from Source03 only.',
        'Whole ordinary235456 mismatches/2754 unavailable and DesignDay nine strict failures/eight UNPAIRED remain unchanged. SRC06 four gates remain unverified; A14/54 B14/64 unchanged.',
    ],'independent_Source_review':assembly['independent_Source_review'],'independent_application_review':ref(review_path),
    'manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False})
plan_path=root/'energyplus_porting_plan/plan.json'
plan=load(plan_path); task=next(row for row in plan['tasks'] if row['id']=='SRC-06')
assert all(task[key]=='미확인' for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_hb_input' not in task
task['actual_selected_ordinary_hb_input']=ref(out/'summary.json');write(plan_path,plan)
card=root/'energyplus_porting_plan/cards/SRC-06.md';text=card.read_text(encoding='utf8')
assert text.count('아래 20개 요약')==1;text=text.replace('아래 20개 요약','아래 21개 요약')
needle='\n기존 Weather03·absent site/station';assert text.count(needle)==1
text=text.replace(needle,'| 실제 HB 입력 / 기상·출력 소유자 전달 | [요약](../evidence/SRC-06-ordinary-hb-input/summary.json) · [색인](../evidence/SRC-06-ordinary-hb-input/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-hb-input/evidence.zip) | 동일 IP·기상·EIO/MTD의 ProjectControl/Site/Material/Construction/Shadowing/Zone 입력과 기존 geometry 사용. 전체 GetHBInput/SurfaceTmp/Setup·수치 완료는 아님. |\n'+needle)
needle='\n## 이력과 증거 보존';assert text.count(needle)==1
text=text.replace(needle,'\n## 실제 HB 입력 연결 단위의 QA\n\nSource `'+snapshot['sha256']+'`에서 fmt·source-quality·all-target workspace Clippy와 기존 테스트 **16 passed / 0 failed / 0 ignored**를 확인했다. raw IDF 필드 개수1·compiler 보고 입력8·runtime3·입력/오류2를 네 패키지의 한 Cargo 선택으로 묶어14개를 실행했고, 일반 CLI1·실제 `CI_FORCE_TIME_STEP=Y` CLI1을 확인했다. 실제 Station→Building→Site→Shadow EIO 순서·MTD와 출력 getter의 local scratch/unused/오류 prefix를 검사했다. Source01 컴파일 실패101, Source02 Clippy와 오래된 staged-IDF 불일치 실패101·부분 성공10개를 보존했다. API/import/기존 호출부와 동일 출력·문자 집합의 lint 문법 및 해당 fixture를 수정한 최종 Source03에서 확인했으며 생산 검증은 완화하지 않았다. 새 본문·binary·전체 workspace 중복 실행·새 Native 실행은 없다. 앞 단위의 성공은 합산하지 않으며 모든 gate와 A/B 완료 수는 그대로다.\n'+needle)
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'archive_members':len(artifacts),'archive_bytes':archive.stat().st_size,'tests':tests},ensure_ascii=False))

import json,re,hashlib,difflib
from pathlib import Path
ROOT=Path.cwd(); unit=ROOT/'.runtime/porting/SRC-06/ordinary-hb-input-assembly-01'
m=json.loads((unit/'manifest.json').read_bytes())
def tokens(s):
    result=[]; i=0
    while i<len(s):
        if s[i].isspace(): i+=1; continue
        if s.startswith('//',i):
            j=s.find('\n',i); i=len(s) if j<0 else j+1; continue
        if s.startswith('/*',i):
            depth=1; i+=2
            while depth:
                if s.startswith('/*',i): depth+=1;i+=2
                elif s.startswith('*/',i): depth-=1;i+=2
                else: i+=1
            continue
        match=re.match(r'(?:br|r)(#*)"',s[i:])
        if match:
            end='"'+match.group(1);j=s.index(end,i+len(match.group(0)))+len(end)
            result.append(s[i:j]);i=j;continue
        start=i
        if s[i]=='"' or (s[i]=="'" and re.match(r"'(?:[^'\\\n]|\\(?:.|x[0-9a-fA-F]{2}|u\{[0-9a-fA-F]+\}))'",s[i:])):
            quote=s[i];i+=1
            while i<len(s):
                if s[i]=='\\':i+=2
                elif s[i]==quote:i+=1;break
                else:i+=1
            result.append(s[start:i]);continue
        match=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?(?:[A-Za-z_][A-Za-z_0-9]*)?',s[i:])
        if match: result.append(match.group(0));i+=len(match.group(0));continue
        result.append(s[i]);i+=1
    return result
def strip_commas(ts): return [t for i,t in enumerate(ts) if not(t==',' and i+1<len(ts) and ts[i+1] in (')',']','}'))]
def formatting_normal_form(ts):
    # This is a preservation screen, not a Rust parser: full punctuation deltas
    # must additionally be read as actual formatter output before acceptance.
    result=[]; imports=[]; i=0
    while i<len(ts):
        if ts[i]=='pub' and i+3<len(ts) and ts[i+1]=='mod' and ts[i+3]==';':
            imports.append(['pub','mod',ts[i+2]]);i+=4;continue
        if ts[i]=='pub' and i+6<len(ts) and ts[i+1]=='(' and ts[i+3]==')' and ts[i+4]=='mod' and ts[i+6]==';':
            imports.append(ts[i:i+6]);i+=7;continue
        if ts[i]=='use':
            j=ts.index(';',i)
            imports.append(sorted(t for t in ts[i:j] if t not in ('{','}',',',';',':')));i=j+1;continue
        if ts[i]=='mod' and i+2<len(ts) and ts[i+2]==';':
            imports.append(['mod',ts[i+1]]);i+=3;continue
        if ts[i] not in ('{','}',',',';'): result.append(ts[i])
        i+=1
    return result,sorted(imports)
rows=[]
for r in m['files']:
    a=(ROOT/r['accepted_proposal']['path']).read_text(encoding='utf-8');b=(ROOT/r['after']['path']).read_text(encoding='utf-8')
    ta=tokens(a);tb=tokens(b)
    row={'path':r['canonical_path'],'formatter_diff_bytes':r['held_to_actual_diff']['size_bytes'],'tokens_same':ta==tb,'trailing_comma_only':strip_commas(ta)==strip_commas(tb)}
    na,ia=formatting_normal_form(ta);nb,ib=formatting_normal_form(tb)
    row['nonformat_tokens_and_imports_same']=na==nb and ia==ib
    if not row['nonformat_tokens_and_imports_same']:
        sm=difflib.SequenceMatcher(None,na,nb,autojunk=False)
        row['token_deltas']=[{'operation':op,'old':na[i:j],'new':nb[k:l]} for op,i,j,k,l in sm.get_opcodes() if op!='equal']
        row['imports_old']=ia;row['imports_new']=ib
    rows.append(row)
if __name__=='__main__':
    print(json.dumps({'changed':sum(bool(r['formatter_diff_bytes']) for r in rows),'failed_preservation_screen':[r for r in rows if not r['nonformat_tokens_and_imports_same']],'rows':rows},indent=2))

"""Incremental actual47 application review; previous41 full reads reused."""
import json,hashlib,difflib,subprocess
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'.runtime/porting/SRC-06';UNIT=BASE/'ordinary-hb-input-assembly-02';OUT=BASE/'Header-ordinary-hb-input-application-review-02'
def ref(p):
    p=Path(p);b=p.read_bytes();return {'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
mp=UNIT/'manifest.json';assert ref(mp)['sha256']=='1f3340abd98595022b4def0ab6d2904d3be611ec1766b113063fc7b473cf7018'
m=json.loads(mp.read_bytes());app=json.loads((ROOT/m['apply']['path']).read_bytes());prov=app['additional_provenance']
old=json.loads((ROOT/prov['prior_actual_assembly']['path']).read_bytes());cor=json.loads((ROOT/prov['correction_packet']['path']).read_bytes())
oldrows={r['canonical_path']:r for r in old['files']};cors={r['canonical_path']:r for r in cor['files']};apps={r['canonical_path']:r for r in app['files']}
refs={}
def walk(x):
    if isinstance(x,dict):
        if all(k in x for k in ('path','sha256','size_bytes')):
            if x['path'] not in refs:
                assert ref(ROOT/x['path'])==x,x['path'];refs[x['path']]=x
        for k,v in x.items():
            if k!='after_apply':walk(v)
    elif isinstance(x,list):
        for v in x:walk(v)
walk(m);walk(prov)
assert len(m['files'])==47 and len(oldrows)==45 and len(cors)==6
paths={r['canonical_path'] for r in m['files']}
assert paths==set(oldrows)|set(cors)==set(apps)
assert m['HEAD']==app['HEAD']==old['HEAD']==cor['HEAD']==subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','-z']).decode().split('\0')
assert {r[3:].replace('\\','/') for r in status if r}==paths
def text(path):return (ROOT/path).read_bytes().decode('utf-8').replace('\r\n','\n')
preserved=[];corrected=[]
for r in m['files']:
    path=r['canonical_path'];after=(ROOT/r['after']['path']).read_bytes()
    assert (ROOT/path).read_bytes()==after
    assert {k:r[k] for k in ('canonical_path','existed_before','before','accepted_proposal','after_apply')}==apps[path]
    assert r['after_apply']['sha256']==r['after']['sha256'] and r['after_apply']['size_bytes']==r['after']['size_bytes'],('fmt02 mutation',path)
    if path in cors:
        assert r['accepted_proposal']==cors[path]['proposal']
        assert after==(ROOT/cors[path]['proposal']['path']).read_bytes(),('exact correction',path)
        assert r['held_to_actual_diff']['size_bytes']==0,('new formatter delta',path)
        corrected.append(path)
    else:
        assert after==(ROOT/oldrows[path]['after']['path']).read_bytes(),('unaffected preservation',path)
        assert r['before']['sha256']==oldrows[path]['before']['sha256']
        preserved.append(path)
    before=text(r['before']['path']);proposal=text(r['accepted_proposal']['path']);final=text(r['after']['path'])
    for key,first in (('complete_actual_diff',before),('held_to_actual_diff',proposal)):
        expected=''.join(difflib.unified_diff(first.splitlines(True),final.splitlines(True),fromfile=path,tofile=path))
        assert expected==text(r[key]['path']),(key,path)
    assert before.count('#[test]')==final.count('#[test]')
assert len(preserved)==41 and len(corrected)==6
report={'schema':'src06-independent-hb-input-actual-application-review.v2','accepted':True,'findings':[],
 'actual_assembly':ref(mp),'actual_application':m['apply'],'preparation_manifest':m['accepted_packet'],
 'correction_preparation_manifest':prov['correction_packet'],'previous_actual_assembly':prov['prior_actual_assembly'],
 'previous_application_review':prov['prior_application_review'],'independent_correction_Source_review':prov['independent_correction_Source_review'],
 'verification':{'direct_refs_hash_and_sizes':len(refs),'final_current_files_equal_saved47':47,'complete_final_diffs_regenerated':47,'held_to_final_diffs_regenerated':47,'canonical_changed_path_set_exact':47,'noncorrected_complete_files_byte_exact_Source01':41,'exact_correction_applications':6,'new_corrected_file_formatter_deltas':0,'fmt02_after_apply_equal_final_files':47,'new_test_bodies':0,'new_test_binaries':0},
 'corrected_files':corrected,'preserved_files':preserved,
 'final_corrected_files':[r['canonical'] for r in m['files'] if r['canonical_path'] in cors],
 'review_basis':'Reuse complete prior Source01 caller/getter/test and formatter reads for41 raw-byte-identical files. Six correction full Source/diffs/API contracts were independently reviewed; actual six final files equal those proposals and their formatter deltas are empty. All47 complete final diffs and all47 held-to-final diffs independently regenerated exactly.',
 'qualifications':['Source01 original manifests/actual101 compiler and Clippy failures remain immutable history; no prior tests were inferred.','This certifies actual47 application and formatter preservation, not future QA/test/compiler PASS.','Preparation02 inherited equality annotation qualification remains as documented in original Source review.','Full HB/InitHB/Setup/scientific gates and unsupported requested-output boundaries remain unchanged.'],
 'canonical_edits_compiler_formatter_Cargo_Native_engine_or_tests_executed_by_reviewer':False,'verification_Source':ref(Path(__file__))}
OUT.mkdir(exist_ok=False);(OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':ref(OUT/'review.json'),'verified':report['verification']},ensure_ascii=False))

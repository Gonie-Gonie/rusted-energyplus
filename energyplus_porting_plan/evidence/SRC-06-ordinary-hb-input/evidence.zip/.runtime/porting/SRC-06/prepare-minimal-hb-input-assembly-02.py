"""HELD Source author only. Writes exclusively beneath the fresh runtime prep."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path.cwd()
OUT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
HB = 'crates/ep_runtime/src/heat_balance/'
RUN = 'crates/ep_run/src/'
P = {}
AUTH = {}

def read(path):
    return Path(path).read_text(encoding='utf-8').replace('\r\n', '\n')

def manifest(name, expected):
    path = Path('.runtime/porting/SRC-06') / name / 'manifest.json'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path
    value = json.loads(path.read_text(encoding='utf-8'))
    AUTH[name] = {'path': path.as_posix(), 'sha256': expected, 'size_bytes': path.stat().st_size}
    return value

H = manifest('ordinary-heat-balance-input-prep-01', '3e88c2e4fee2e7b44f05bd07fd1f5b139dd3022e1709eca7c81ba04d7ff9322b')
Z = manifest('ordinary-building-zone-input-prep-02', '3ef48803bf8148d5ef7696fc390f9f30c01cf3791420ab09f4928b7c332272b5')
M = manifest('ordinary-material-input-prep-03', '9998b66114608bf83001fedec454204b6f25bf46022def15fa7ff76f1a1f5430')
O = manifest('ordinary-output-variable-getter-prep-02', '73f120ffa19045221a2709738f0f11c71a0338a725d0c29982463c53fe503705')
W = manifest('ordinary-weather-environment-handoff-prep-01', '63cb1d8493dafae86fd135ebfe7eb10d255b39729a44c5036856ff56cf7e83d4')
A = manifest('ordinary-run-prefix-assembly-01', 'fb5be68e4d8a57e76076cb273803b669fc2d1439eb235854f0fb290ec17d719a')

def row(m, path):
    return next(r for r in m['files'] if r['canonical_path'] == path)

def checked(ref):
    data = Path(ref['path']).read_bytes()
    assert len(data) == ref['size_bytes'] and hashlib.sha256(data).hexdigest() == ref['sha256'], ref
    return data.decode('utf-8').replace('\r\n', '\n')

def proposed(m, path):
    return checked(row(m, path)['proposal'])

def copy(m, path):
    P[path] = proposed(m, path)

def current(path):
    return P[path] if path in P else read(path)

def replace(path, old, new):
    value = current(path)
    assert value.count(old) == 1, (path, old[:100], value.count(old))
    P[path] = value.replace(old, new, 1)

def merge(m, path):
    """Apply only exact parent edits, locating bounded unchanged context."""
    r = row(m, path)
    before = checked(r.get('before', r.get('base'))).splitlines(keepends=True)
    after = checked(r['proposal']).splitlines(keepends=True)
    value = current(path)
    edits = [x for x in difflib.SequenceMatcher(None, before, after, autojunk=False).get_opcodes() if x[0] != 'equal']
    for _kind, i, j, a, b in reversed(edits):
        old, new = ''.join(before[i:j]), ''.join(after[a:b])
        if old and value.count(old) == 1:
            value = value.replace(old, new, 1)
            continue
        located = False
        for width in (3, 2, 1):
            left, right = ''.join(before[max(0, i-width):i]), ''.join(before[j:j+width])
            match = left + old + right
            if match and value.count(match) == 1:
                value = value.replace(match, left + new + right, 1)
                located = True
                break
        assert located, (path, old[:120], new[:120])
    P[path] = value

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip().startswith('ac15758c')
assert not OUT.exists(), 'fresh author output required'
for r in A['files']:
    assert Path(r['canonical_path']).read_bytes() == Path(r['after']['path']).read_bytes(), r['canonical_path']

# The actual weather return handoff is retained byte-exact; no cloned session.
for r in W['files']:
    if r.get('before'):
        assert Path(r['canonical_path']).read_bytes() == Path(r['before']['path']).read_bytes()
    copy(W, r['canonical_path'])

# Only consumed getter children are registered; no future InitHB/deferred CTF.
for suffix in ['selected_heat_balance_input.rs', 'selected_heat_balance_input/input.rs',
               'selected_heat_balance_input/construction.rs', 'selected_heat_balance_input/zone.rs',
               'selected_heat_balance_input/zone/input.rs', 'selected_heat_balance_input/zone/storage.rs']:
    copy(Z, HB + suffix)
for suffix in ['selected_heat_balance_input/input/schema.rs', 'selected_heat_balance_input/building.rs',
               'selected_heat_balance_input/control.rs']:
    copy(H, HB + suffix)
for suffix in ['selected_material_data.rs', 'selected_material_data/input.rs', 'selected_material_data/report.rs']:
    copy(M, HB + suffix)
copy(Z, RUN + 'ordinary_heat_balance_input.rs')
copy(M, RUN + 'ordinary_material_input.rs')
copy(O, HB + 'source_output_registration/requested_input.rs')

# One sole focused SpaceControls owner introduced by the actual run prefix.
replace(HB + 'selected_heat_balance_input.rs', '    pub(crate) do_space_heat_balance_sizing: bool,\n    pub(crate) do_space_heat_balance_simulation: bool,\n', '')
replace(HB + 'selected_heat_balance_input.rs', 'zone_air_solution: SelectedZoneAirSolution::ThirdOrder, do_space_heat_balance_sizing: false,\n            do_space_heat_balance_simulation: false, simulate_contaminants: false,',
        'zone_air_solution: SelectedZoneAirSolution::ThirdOrder, simulate_contaminants: false,')
replace(HB + 'selected_heat_balance_input.rs', "    pub(crate) project: &'a mut SelectedProjectData,\n", "    pub(crate) project: &'a mut SelectedProjectData,\n    pub(crate) space_controls: &'a mut super::selected_heat_balance_space_controls::SelectedHeatBalanceSpaceControls,\n")
P[HB + 'selected_heat_balance_input/control.rs'] = P[HB + 'selected_heat_balance_input/control.rs'].replace('self.do_space_heat_balance_sizing', 'owners.space_controls.sizing').replace('self.do_space_heat_balance_simulation', 'owners.space_controls.simulation')

# Material reads the actual early globals in place. No temporary custody move.
material = P[HB + 'selected_material_data.rs']
start = material.index("impl CtfInitializationContext<'_> {")
tail = material[start:]
body_start = tail.index('        let reports = &mut self.reports;')
body = tail[body_start:].replace('        let reports = &mut self.reports;', '        let reports = &mut *self.reports;\n        let globals = reports.selected_heat_balance_globals.as_ref()\n            .ok_or_else(|| unavailable("missing actual early globals"))?;', 1)
P[HB + 'selected_material_data.rs'] = material[:start] + "impl CtfInitializationContext<'_> {\n    pub(crate) fn get_selected_material_data(&mut self, model: &TypedModel) -> Result<(), RuntimeError> {\n" + body
P[HB + 'selected_material_data.rs'] = P[HB + 'selected_material_data.rs'].replace('reports.heat_balance_manager_current_module_object', 'reports.heat_balance_current_module_object')

# Merge only reviewed metadata additions into the actual current raw parser.
for path in ['crates/ep_raw_model/src/idf_order.rs', RUN + 'ordinary_equipment_input/fields.rs']:
    # The Material parent already includes the HB metadata; consume its delta.
    merge(M, path)
    merge(Z, path)
    merge(O, path)
for path in [HB + 'selected_project_data.rs', HB + 'selected_project_data/environment.rs']:
    merge(H, path)

# Output:Variable typed local getter custody (no shared scratch).
opmodel = proposed(O, 'crates/ep_model/src/report_inputs.rs')
canonical_model = current('crates/ep_model/src/report_inputs.rs')
type_start = opmodel.index('/// Input-only getObjectItem projection for OutputProcessor')
P['crates/ep_model/src/report_inputs.rs'] = canonical_model + '\n' + opmodel[type_start:]
replace('crates/ep_model/src/report_inputs.rs', '    pub legacy_variable_dictionary_sections: i32,\n', '    pub legacy_variable_dictionary_sections: i32,\n    /// Actual ordered local Output:Variable getter operands.\n    pub output_variables: Vec<SourceOutputVariableInput>,\n')
replace('crates/ep_model/src/report_inputs.rs', '            legacy_variable_dictionary_sections: -1,\n', '            legacy_variable_dictionary_sections: -1,\n            output_variables: Vec::new(),\n')
compiler = proposed(O, 'crates/ep_compiler/src/compiler/report_inputs.rs')
# Parent GainChain included the same pure raw projection; use the complete
# reviewed final compiler file only after separately checking current inverse.
P['crates/ep_compiler/src/compiler/report_inputs.rs'] = compiler

# Keep every current live timestep binding and add only actually consumed OP
# registration storage/methods. Future integer, meters and OutVar are excluded.
old_output = current(HB + 'source_output_registration.rs')
op = proposed(O, HB + 'source_output_registration.rs')
op = op.replace('mod meters;\n', '').replace('mod integer;\n', '').replace('pub(crate) use meters::{SourceExteriorEnergyDeclaration, SourceMeter};\n', '')
a, b = op.index('/// A real variable'), op.index('#[derive(Clone, Copy)]\npub(crate) struct SourceRealOutputDeclaration')
op = op[:a] + op[b:]
op = op.replace('pub(crate) enum SourceOutputUnits { None, W, J, Deg, M2, WPerM2, Rad }', 'pub(crate) enum SourceOutputUnits { C, MPerS, Deg }')
op = op.replace('pub(crate) enum SourceOutputStoreType { Average, Sum }', 'pub(crate) enum SourceOutputStoreType { Average }')
for line in ['    pub(crate) out_vars: Vec<SourceRealOutputVariable>,\n', '    pub(crate) meters: Vec<SourceMeter>,\n', '    pub(crate) meter_map: BTreeMap<String, usize>,\n']:
    op = op.replace(line, '')
op = op.replace('report_number_counter: 0, out_vars: Vec::new(), meters: Vec::new(),\n            meter_map: BTreeMap::new(), max_num_subcategories: 1,', 'report_number_counter: 0, max_num_subcategories: 1,')
op = op.replace('pub(crate) struct SourceOutputRegistration {\n', 'pub(crate) struct SourceOutputRegistration {\n    pub(crate) time_pointers: SelectedOutputTimePointers,\n')
op = op.replace('output_initialized: false, get_output_input: true,', 'time_pointers: SelectedOutputTimePointers::default(),\n            output_initialized: false, get_output_input: true,')
live = old_output[:old_output.index('/// Sole selected OutputProcessor storage;')]
op_header_end = op.index('/// Actual output file/system host')
P[HB + 'source_output_registration.rs'] = live + '\n' + op[:op_header_end] + op[op_header_end:]
replace(HB + 'source_output_registration.rs', 'mod requested_input;\n', 'mod requested_input;\nmod host;\npub use host::SourceMtdFileHost;\n')

# The real MTD file is retained outside Clone reports, disjoint from EIO.
P[HB + 'source_output_registration/host.rs'] = '''//! Actual MTD stream and process MINREPORTFREQUENCY custody.
use super::SourceOutputFileHost;
use std::fs::{File, OpenOptions};
use std::io;
use std::path::PathBuf;

/// Sole real MTD stream for the reached OutputProcessor initialization.
#[derive(Debug)]
pub struct SourceMtdFileHost {
    path: PathBuf,
    file: Option<File>,
    minimum_report_frequency: String,
}
impl SourceMtdFileHost {
    /// Retain the chosen path and acquire the actual process setting once.
    /// This constructor does not open MTD before InitializeOutput.
    ///
    /// # Errors
    /// Rejects an actual non-Unicode MINREPORTFREQUENCY value.
    pub fn from_process_environment(path: impl Into<PathBuf>) -> io::Result<Self> {
        let minimum_report_frequency = match std::env::var("MINREPORTFREQUENCY") {
            Ok(value) => value,
            Err(std::env::VarError::NotPresent) => String::new(),
            Err(std::env::VarError::NotUnicode(_)) => return Err(io::Error::new(
                io::ErrorKind::InvalidInput, "MINREPORTFREQUENCY is not a Unicode string")),
        };
        Ok(Self { path: path.into(), file: None, minimum_report_frequency })
    }
    /// Flush an actually opened MTD without opening an unreached file.
    ///
    /// # Errors
    /// Returns the actual retained stream's OS error.
    pub fn flush_reached(&mut self) -> io::Result<()> {
        use std::io::Write;
        if let Some(file) = &mut self.file { file.flush()?; }
        Ok(())
    }
}
impl SourceOutputFileHost for SourceMtdFileHost {
    fn ensure_mtd_open(&mut self) -> io::Result<()> {
        if self.file.is_none() {
            self.file = Some(OpenOptions::new().read(true).write(true).create(true)
                .truncate(true).open(&self.path)?);
        }
        Ok(())
    }
    fn minimum_report_frequency(&self) -> &str { &self.minimum_report_frequency }
}
'''

# Focus the genuine default ShadowCalculation getter without activating Solar.
shadow_path = Path('.runtime/porting/SRC-06/ordinary-solar-init-caller-prep-01/proposed') / (HB + 'solar_shading/input.rs')
shadow = read(shadow_path)
assert hashlib.sha256(shadow_path.read_bytes()).hexdigest() == '7e7b3d534eef29dd20d755281b60630284300e9ca11fa3a0501f8f36a1781eae'
shadow = shadow.replace('use super::*;', 'use super::super::ctf_initialization_context::CtfInitializationContext;\nuse super::super::radiation::ordinary::{OrdinaryRadiationError, OrdinaryRadiationUnavailable};')
shadow = shadow.replace('        input: crate::heat_balance::radiation::ordinary::OrdinaryRadiationInput,\n        context:', '        context:')
shadow = shadow.replace('        input.require_default_shadowing_input()?;\n', '')
P[HB + 'selected_heat_balance_input/shadowing.rs'] = shadow
replace(HB + 'selected_heat_balance_input.rs', 'pub(crate) mod zone;\n', 'pub(crate) mod zone;\npub(crate) mod shadowing;\n')

# Retain only Source constructor fields actually used by Zone/Space getters.
replace(HB + 'selected_heat_balance_globals.rs', 'pub(crate) struct SelectedHeatBalanceGlobals {\n', 'pub(crate) struct SelectedHeatBalanceGlobals {\n    /// Actual GetZoneData/GetSpaceData counts, independently initialized zero.\n    pub(crate) num_of_zones: i32,\n    pub(crate) num_of_spaces: i32,\n    pub(crate) num_of_space_types: i32,\n')

# Shared reports retain all reached getter prefixes until initializer success.
replace(HB + 'ctf_initialization_context.rs', '    /// Distinct HeatBalanceManager getter module carrier, not dataIPShortCut.\n', '''    /// Raw HB getter operands from the same admitted source model.
    pub heat_balance_input: Option<super::selected_heat_balance_input::SelectedHeatBalanceInput>,
    /// Sole actual ProjectControl/Construction flags and argument state.
    pub(crate) heat_balance_input_state: super::selected_heat_balance_input::SelectedHeatBalanceInputState,
    pub(crate) heat_balance_input_errors_found: bool,
    /// Raw Material operands, retaining original loader format/order.
    pub selected_material_input: Option<super::selected_material_data::SelectedMaterialInput>,
    pub(crate) selected_material_data: super::selected_material_data::SelectedMaterialData,
    /// Actual partial Zone/Space arrays, moved only after initializer success.
    pub(crate) selected_zone_input: Option<super::selected_heat_balance_input::zone::SelectedZoneInputOwners>,
    /// Sole reached GetShadowingInput result; later Solar must consume this owner.
    pub(crate) shadowing_input: Option<super::selected_heat_balance_input::shadowing::SourceShadowingInput>,
    /// Distinct HeatBalanceManager getter module carrier, not dataIPShortCut.
''')

ctx = proposed(Z, HB + 'ctf_initialization_context.rs')
extra = ctx[ctx.index("impl CtfInitializationContext<'_> {\n    pub(crate) fn get_selected_project_control_data"):]
extra = extra.replace('project: &mut reports.selected_project_data, environment,', '''project: reports.selected_project_data.as_mut().ok_or_else(|| hb_input_error(E::Unavailable("missing sole project owner")))?,
            space_controls: &mut reports.heat_balance_space_controls, environment,''')
extra = extra.replace('heat_balance_manager_current_module_object', 'heat_balance_current_module_object')
extra = extra.replace('        globals: &mut super::selected_heat_balance_globals::SelectedHeatBalanceGlobals,\n', '')
extra = extra.replace('        let zone = reports.selected_zone_input.get_or_insert_with(SelectedZoneInputOwners::default);', '''        let globals = reports.selected_heat_balance_globals.as_mut().ok_or_else(|| hb_input_error(E::Unavailable("missing sole early globals")))?;
        let zone = reports.selected_zone_input.get_or_insert_with(SelectedZoneInputOwners::default);''')
P[HB + 'ctf_initialization_context.rs'] = current(HB + 'ctf_initialization_context.rs') + '\n' + extra
P[HB + 'ctf_initialization_context.rs'] += '''
impl CtfInitializationContext<'_> {
    pub(crate) fn initialize_selected_heat_balance_input(&mut self, model: &TypedModel,
        environment: &mut crate::weather::day::WeatherEnvironmentState, minutes: i32,
        host: &mut dyn super::source_output_registration::SourceOutputFileHost) -> Result<(), crate::RuntimeError> {
        self.get_selected_project_control_data(environment)?;
        self.initialize_source_site_atmosphere(environment)?;
        self.get_selected_material_data(model)?;
        self.read_selected_construction_arguments(model)?;
        let settings = super::selected_heat_balance_input::shadowing::ShadowingSystemSettings::from_process_environment()
            .map_err(super::radiation::ordinary::OrdinaryRadiationError::from)?;
        let mut owner = super::selected_heat_balance_input::shadowing::SourceShadowingInput::new(settings);
        let result = owner.get_at_building_boundary(self);
        self.reports.shadowing_input = Some(owner);
        result?;
        self.get_selected_zone_data(model, minutes, host)
    }
}
'''

# Register only reached modules and pure raw bridges.
replace(HB + 'mod.rs', 'pub(crate) mod selected_heat_balance_globals;\n', 'pub(crate) mod selected_heat_balance_globals;\npub mod selected_heat_balance_input;\npub mod selected_material_data;\n')
replace(RUN + 'lib.rs', 'mod ordinary_equipment_input;\n', 'mod ordinary_equipment_input;\nmod ordinary_heat_balance_input;\nmod ordinary_material_input;\n')

# The private initializer receives genuine borrowed owners, not Ready flags.
replace(HB + 'initialization.rs', 'pub(crate) struct OrdinaryInitializationInputs {', "pub(crate) struct OrdinaryInitializationInputs<'a> {")
replace(HB + 'initialization.rs', '    pub(crate) equipment: Option<super::ordinary_equipment::OrdinaryEquipmentInput>,\n', '''    pub(crate) equipment: Option<super::ordinary_equipment::OrdinaryEquipmentInput>,
    pub(crate) source: Option<SourceHeatBalanceInputOwners<'a>>,
''')
replace(HB + 'initialization.rs', 'const ENERGYPLUS_INITIAL_CONVECTION_COEFFICIENT', '''pub(crate) struct SourceHeatBalanceInputOwners<'a> {
    pub(crate) environment: &'a mut crate::weather::day::WeatherEnvironmentState,
    pub(crate) minutes: i32,
    pub(crate) output_host: &'a mut super::source_output_registration::SourceMtdFileHost,
}

const ENERGYPLUS_INITIAL_CONVECTION_COEFFICIENT''')
replace(HB + 'initialization.rs', '    inputs: OrdinaryInitializationInputs,\n', "    inputs: OrdinaryInitializationInputs<'_>,\n")
replace(HB + 'initialization.rs', '        equipment: equipment_input,\n        radiation: radiation_input,', '        equipment: equipment_input,\n        radiation: radiation_input,\n        source,')
replace(HB + 'initialization.rs', '    if let Some(actual) = initialization.as_deref_mut() {\n        actual.prepare_report_input_cache', '''    let source_input_reached = source.is_some();
    if let Some(source) = source {
        let actual = initialization.as_deref_mut().ok_or_else(|| RuntimeError::WarmupUnavailable {
            reason: "source HB input requires its actual context".into() })?;
        actual.initialize_selected_heat_balance_input(&model.typed, source.environment, source.minutes, source.output_host)?;
    }
    if let Some(actual) = initialization.as_deref_mut() {
        actual.prepare_report_input_cache''')
replace(HB + 'initialization.rs', '                .map(|surface| {\n                    let geometry', '''                .map(|surface| {
                    if source_input_reached {
                        initialization.as_deref_mut().ok_or_else(|| RuntimeError::WarmupUnavailable {
                            reason: "surface construction requires actual input owner".into() })?
                            .mark_selected_surface_construction_used(surface.construction)?;
                    }
                    let geometry''')
replace(HB + 'initialization.rs', '    let equipment = equipment_input\n', '''    if source_input_reached {
        let layout = super::inside_convection_layout::InsideConvectionLayout::from_typed_model(&model.typed)
            .map_err(|_| RuntimeError::WarmupUnavailable { reason: "actual CTF surface domain".into() })?;
        let actual = initialization.as_deref_mut().ok_or_else(|| RuntimeError::WarmupUnavailable {
            reason: "actual input owner before CTF assignment".into() })?;
        for group in layout.groups() {
            for id in &group.surfaces {
                let surface = model.typed.surfaces.iter().find(|s| s.id == *id)
                    .ok_or_else(|| RuntimeError::WarmupUnavailable { reason: "actual CTF surface identity".into() })?;
                actual.mark_selected_surface_ctf_construction_used(surface.construction)?;
            }
        }
    }
    let equipment = equipment_input
''')
# Copy only the finite geometry commit from the reviewed Zone proposal. The
# original existing physical calculation/cache path above remains unchanged.
zone_initializer = proposed(Z, HB + 'initialization.rs')
ga = zone_initializer.index('        let actual_surface_geometry = surfaces.iter().map(')
gb = zone_initializer.index('        Some(geometry)', ga)
geometry_commit = zone_initializer[ga:gb].replace('deferred', 'selected')
replace(HB + 'initialization.rs', '    if let Some(input) = radiation_input {\n', '    if source_input_reached {\n' + geometry_commit + '    }\n    if let Some(input) = radiation_input {\n')
replace(HB + 'initialization.rs', '    state.ordinary_equipment = equipment;\n', '''    // No fallible initialization work follows the sole-owner move.
    if source_input_reached {
        let actual = initialization.as_deref_mut().ok_or_else(|| RuntimeError::WarmupUnavailable {
            reason: "completed source HB initialization requires retained context".into() })?;
        if actual.reports.selected_heat_balance_globals.is_none() || actual.reports.selected_zone_input.is_none() {
            return Err(RuntimeError::WarmupUnavailable { reason: "missing source owners after geometry".into() });
        }
        state.selected_heat_balance_globals = actual.reports.selected_heat_balance_globals.take();
        state.selected_zone_input = actual.reports.selected_zone_input.take();
    }
    state.ordinary_equipment = equipment;
''')
replace(HB + 'initialization/schedule_cache.rs', '    inputs: super::OrdinaryInitializationInputs,\n', "    inputs: super::OrdinaryInitializationInputs<'_>,\n")
replace(HB + 'state.rs', 'pub struct HeatBalanceState {\n', '''pub struct HeatBalanceState {
    pub(crate) selected_heat_balance_globals: Option<super::selected_heat_balance_globals::SelectedHeatBalanceGlobals>,
    pub(crate) selected_zone_input: Option<super::selected_heat_balance_input::zone::SelectedZoneInputOwners>,
''')
replace(HB + 'initialization/state_shell.rs', '    HeatBalanceState {\n', '    HeatBalanceState {\n        selected_heat_balance_globals: None,\n        selected_zone_input: None,\n')

# Runtime supplies the same weather session through Native's bounded callback.
runtime = 'crates/ep_runtime/src/runtime.rs'
text = current(runtime)
# All old internal callers remain legacy-compatible with no source host.
text = text.replace('        None,\n    )\n}', '        None,\n        None,\n    )\n}')
text = text.replace('        Some(reporting),\n    )', '        Some(reporting),\n        None,\n    )')
text = text.replace('    reporting: Option<HeatBalanceOrdinaryWarmupReportInputs>,\n', '    reporting: Option<HeatBalanceOrdinaryWarmupReportInputs>,\n    mut source_output_host: Option<&mut crate::heat_balance::source_output_registration::SourceMtdFileHost>,\n')
text = text.replace('        driver.prepare_initial_phase(initial_phase)?;', '''        if let (Some(host), Some(actual), HeatBalanceWeatherDriver::Production(weather)) =
            (source_output_host.as_deref_mut(), initialization.as_deref_mut(), driver) {
            let _ = host; // The retained host is consumed later by actual Zone registration.
            weather.prepare_initial_phase_with_source_context(initial_phase, actual)?;
        } else { driver.prepare_initial_phase(initial_phase)?; }''')
old = '''                initialize_heat_balance_state_with_initialization_context_and_equipment_profiled(
                    model,
                    options.initial_zone_air_temperature_c,
                    ctf_coefficients,
                    &schedule_cache,
                    &mut schedule_cache_profile,
                    context,
                    crate::heat_balance::initialization::OrdinaryInitializationInputs {
                        equipment: equipment_input,
                        radiation: radiation_input,
                    },
                )?'''
new = '''                let mut initialize = |source| initialize_heat_balance_state_with_initialization_context_and_equipment_profiled(
                    model, options.initial_zone_air_temperature_c, ctf_coefficients, &schedule_cache,
                    &mut schedule_cache_profile, context,
                    crate::heat_balance::initialization::OrdinaryInitializationInputs {
                        equipment: equipment_input, radiation: radiation_input, source,
                    });
                match (source_output_host.as_deref_mut(), weather_driver) {
                    (Some(host), Some(HeatBalanceWeatherDriver::Production(weather))) =>
                        weather.with_source_environment_mut(|environment, minutes| initialize(Some(
                            crate::heat_balance::initialization::SourceHeatBalanceInputOwners {
                                environment, minutes, output_host: host,
                            })))?,
                    (Some(_), _) => return Err(RuntimeError::WarmupUnavailable {
                        reason: "source HB input requires the actual production weather session".into() }),
                    (None, _) => initialize(None)?,
                }'''
assert old in text
text = text.replace(old, new, 1)
at = text.index('#[expect(\n    clippy::too_many_arguments,', text.index('pub fn simulate_heat_balance_zone_air_temperatures_with_production_weather_and_warmup_reporting'))
new_entry = '''/// Ordinary source-input path using the actual weather, EIO and MTD owners.
/// Existing manual/diagnostic entrypoints preserve their initialization behavior.
///
/// # Errors
/// Returns the actual input, output, weather or existing heat-balance failure.
pub fn simulate_heat_balance_zone_air_temperatures_with_source_heat_balance_input(
    model: &SimulationModel, weather: &ProductionWeatherTimestepSeries,
    options: HeatBalanceSimulationOptions,
    context: &mut crate::heat_balance::ctf_initialization_context::CtfInitializationContext<'_>,
    reporting: HeatBalanceOrdinaryWarmupReportInputs,
    host: &mut crate::heat_balance::source_output_registration::SourceMtdFileHost,
) -> Result<HeatBalanceSimulation, RuntimeError> {
    simulate_heat_balance_zone_air_temperatures_internal(model, &[], None,
        Some(HeatBalanceWeatherDriver::Production(weather)), options, &[],
        Some(context), Some(reporting), Some(host))
}

'''
text = text[:at] + new_entry + text[at:]
P[runtime] = text

# Actual file/context host pair has disjoint custody; failed runtime retains both.
outputs = RUN + 'ctf_initialization_outputs.rs'
replace(outputs, '    initialization_files: Option<SourceInitializationFiles>,\n', '    initialization_files: Option<SourceInitializationFiles>,\n    mtd: Option<ep_runtime::heat_balance::source_output_registration::SourceMtdFileHost>,\n')
replace(outputs, '            initialization_files: None,\n', '            initialization_files: None,\n            mtd: None,\n')
replace(outputs, '        if first_entry {\n            self.reports.source_initialization_input = Some(input);', '''        if first_entry {
            self.mtd = Some(ep_runtime::heat_balance::source_output_registration::SourceMtdFileHost::from_process_environment(
                output_dir.join("eplusrs.mtd")).map_err(|error| error.to_string())?);
            self.reports.source_initialization_input = Some(input);''')
context = current(outputs)
ca = context.index('    pub(crate) fn context(&mut self)')
cb = context.index('    pub(crate) fn persist(', ca)
method = context[ca:cb]
method = method.replace('pub(crate) fn context(&mut self) -> CtfInitializationContext<\'_> {', '''pub(crate) fn context_with_mtd(&mut self) -> Result<(CtfInitializationContext<'_>,
        &mut ep_runtime::heat_balance::source_output_registration::SourceMtdFileHost), String> {''')
method = method.replace('        CtfInitializationContext {', '        let mtd = self.mtd.as_mut().ok_or("actual MTD host missing")?;\n        Ok((CtfInitializationContext {', 1)
method = method.replace('        }\n    }\n', '        }, mtd))\n    }\n', 1)
P[outputs] = context[:cb] + method + context[cb:]
replace(outputs, '        // Write the genuine error prefix first,', '''        if let Some(host) = self.mtd.as_mut() { host.flush_reached().map_err(|error| error.to_string())?; }
        // Write the genuine error prefix first,''')

# Pure raw projections join the same retained input before actual getters run.
pipe = RUN + 'pipeline.rs'
replace(pipe, '    reporting_prescan_input:\n        Option<ep_runtime::heat_balance::source_output_prescan::SourceReportingPreScanInput>,\n', '''    reporting_prescan_input:
        Option<ep_runtime::heat_balance::source_output_prescan::SourceReportingPreScanInput>,
    heat_balance_input: Option<ep_runtime::heat_balance::selected_heat_balance_input::SelectedHeatBalanceInput>,
    material_input: Option<ep_runtime::heat_balance::selected_material_data::SelectedMaterialInput>,
''')
replace(pipe, '    Ok(PreparedRuntimeInputs {\n', '''    let (heat_balance_input, material_input) = if let Some(input) = selected_input_processor.as_ref() {
        (Some(crate::ordinary_heat_balance_input::resolve(raw_model, input)?),
         Some(crate::ordinary_material_input::resolve(raw_model, input)?))
    } else { (None, None) };
    Ok(PreparedRuntimeInputs {
        heat_balance_input,
        material_input,
''')
replace(pipe, '            if let Some(raw) = runtime_inputs.reporting_prescan_input.take() {\n', '''            initialization.reports.heat_balance_input = runtime_inputs.heat_balance_input.take();
            initialization.reports.selected_material_input = runtime_inputs.material_input.take();
            if let Some(raw) = runtime_inputs.reporting_prescan_input.take() {
''')
replace(pipe, '            let mut initialization = ctf_outputs.context();\n            let simulation = if let Some(reporting) = runtime_inputs.ordinary_warmup_reporting {', '''            let simulation = if let Some(reporting) = runtime_inputs.ordinary_warmup_reporting {
                let (mut initialization, host) = ctf_outputs.context_with_mtd()?;''')
replace(pipe, 'ep_runtime::simulate_heat_balance_zone_air_temperatures_with_production_weather_and_warmup_reporting(\n                    model, weather_series, options, &mut initialization, reporting,', 'ep_runtime::simulate_heat_balance_zone_air_temperatures_with_source_heat_balance_input(\n                    model, weather_series, options, &mut initialization, reporting, host,')
replace(pipe, '''            } else {
                simulate_heat_balance_zone_air_temperatures_with_production_weather_and_initialization_context(''', '''            } else {
                let mut initialization = ctf_outputs.context();
                simulate_heat_balance_zone_air_temperatures_with_production_weather_and_initialization_context(''')

# WIP only: the final sealer will add existing-body tests and finite provenance.
OUT.mkdir(parents=True)
for path, value in P.items():
    out = OUT / 'proposed' / path
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(value, encoding='utf-8', newline='\n')
    if Path(path).exists():
        before = OUT / 'before' / path
        before.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(Path(path).read_bytes())
(OUT / 'dependencies.json').write_text(json.dumps(AUTH, indent=2)+'\n', encoding='utf-8')
(OUT / 'status.json').write_text(json.dumps({'status':'UNSEALED WIP Source only', 'canonical_mutated':False,
    'targets_executed':False, 'files':len(P)}, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'output':str(OUT), 'files':len(P), 'status':'UNSEALED WIP'}))

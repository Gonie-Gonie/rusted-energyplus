"""Freeze finite HELD HB input Source; never applies canonical code or runs targets."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

OUT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
REF = Path('.reference/energyplus-src/26.1.0')
COMMIT = '6f2e40d10250a105b49966baa24d843711e61048'
HEAD = '6d1b2e248a568dc63acb37d8a0b545efc4849364'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'])
assert not (OUT/'manifest.json').exists()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'sha256': sha(raw), 'size_bytes': len(raw)}
def checked(item):
    raw = Path(item['path']).read_bytes()
    assert len(raw) == item['size_bytes'] and sha(raw) == item['sha256'], item
    return raw
def text(raw): return raw.decode('utf-8').replace('\r\n', '\n')
def diff(before, after, name):
    return ''.join(difflib.unified_diff(text(before).splitlines(keepends=True),
        text(after).splitlines(keepends=True), fromfile='a/'+name if before else '/dev/null',
        tofile='b/'+name)).encode('utf-8')
def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')

dependencies = json.loads((OUT/'dependencies.json').read_text(encoding='utf-8'))
rebase = json.loads((OUT/'prefix-checks-rebase.json').read_text(encoding='utf-8'))
dependencies['ordinary-run-prefix-checks-assembly-01'] = rebase['actual_assembly']
solar_manifest = Path('.runtime/porting/SRC-06/ordinary-solar-init-caller-prep-01/manifest.json')
dependencies['selected_shadowing_input_authority'] = ref(solar_manifest)
parents = {}
for name, item in dependencies.items():
    parents[name] = json.loads(checked(item))

files, test_files = [], []
for proposal in sorted((OUT/'proposed').rglob('*.rs')):
    name = proposal.relative_to(OUT/'proposed').as_posix()
    canonical, before_path = Path(name), OUT/'before'/name
    existed = canonical.exists()
    before, after = canonical.read_bytes() if existed else b'', proposal.read_bytes()
    if existed:
        assert before_path.read_bytes() == before, name
        assert subprocess.check_output(['git', 'show', HEAD+':'+name]) == before, name
    else:
        assert not before_path.exists(), name
    assert before != after, name
    path = OUT/'diffs'/(name.replace('/', '__')+'.diff')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(diff(before, after, name))
    matches = []
    for parent_name, parent in parents.items():
        for row in parent.get('files', parent.get('source_proposals', [])):
            if row.get('canonical_path') != name: continue
            original = row.get('proposal')
            if original is None: continue
            raw = checked(original)
            matches.append({'dependency': parent_name, 'proposal': original,
                'whole_payload_equal_after_LF_normalization': text(raw) == text(after)})
    row = {'canonical_path': name, 'existed_before': existed,
        'before': ref(before_path) if existed else None,
        'proposal': ref(proposal), 'complete_diff': ref(path),
        'source_provenance': matches}
    files.append(row)
    pattern = r'#\[test\]\s*(?:#\[[\s\S]*?\]\s*)*(?:pub(?:\([^)]*\))?\s+)?fn\s+(\w+)'
    old_tests, new_tests = re.findall(pattern, text(before)), re.findall(pattern, text(after))
    assert old_tests == new_tests, (name, old_tests, new_tests)
    if new_tests:
        test_files.append({'canonical_path': name, 'existing_test_names': new_tests,
            'count_before': len(old_tests), 'count_after': len(new_tests)})

# Reuse finite literal archives by reference; no recursive historical Source clone.
ranges = []
for name, parent in parents.items():
    if name in ('ordinary-run-prefix-assembly-01', 'ordinary-run-prefix-checks-assembly-01'):
        continue
    for row in parent.get('Original_ranges', parent.get('Original', [])):
        source = row.get('source_path', row.get('historical_path', row.get('Original_path', '')))
        first = row.get('first_line', row.get('start_line'))
        last = row.get('last_line', row.get('end_line'))
        literal = row.get('literal', row.get('literal_archive'))
        if name == 'selected_shadowing_input_authority' and (source, first, last) not in [
            (str(REF.as_posix())+'/src/EnergyPlus/SolarShading.cc', 380, 828),
            (str(REF.as_posix())+'/src/EnergyPlus/SolarShading.hh', 438, 469),
            (str(REF.as_posix())+'/src/EnergyPlus/HeatBalanceManager.cc', 1800, 1820)]:
            continue
        checked(literal)
        source = source.removeprefix(REF.as_posix()+'/')
        item = {'source_path': source, 'first_line': first, 'last_line': last,
            'literal': literal, 'dependency': name,
            'custody': row.get('custody', 'exact reference Git blob'),
            'full_source_sha256': row.get('full_source_sha256'),
            'full_source_size_bytes': row.get('full_source_size_bytes')}
        if not any((r['source_path'], r['first_line'], r['last_line']) == (source, first, last) for r in ranges):
            ranges.append(item)
for source, first, last, purpose in [
    ('src/EnergyPlus/DataSystemVariables.cc', 276, 330, 'actual early MinReportFrequency/clipping/MinimalShadowing acquisition order'),
    ('src/EnergyPlus/DataSystemVariables.hh', 96, 132, 'actual retained constructor settings'),
    ('src/EnergyPlus/SurfaceGeometry.cc', 548, 608, 'actual Zone centroid reset, ordered GrossArea accumulation and guarded division')]:
    blob = subprocess.check_output(['git', '-C', str(REF), 'show', COMMIT+':'+source])
    literal = b''.join(blob.splitlines(keepends=True)[first-1:last])
    path = OUT/'Original'/(Path(source).name+f'.{first}-{last}.txt')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(literal)
    ranges.append({'source_path': source, 'first_line': first, 'last_line': last,
        'literal': ref(path), 'purpose': purpose})
blobs = {}
for row in ranges:
    source = row['source_path']
    if source not in blobs:
        if row.get('custody') == 'literal bundled local dependency; not tracked by reference Git':
            raw = (REF/source).read_bytes()
            assert sha(raw) == row['full_source_sha256'] and len(raw) == row['full_source_size_bytes']
            blobs[source] = raw
        else:
            blobs[source] = subprocess.check_output(['git', '-C', str(REF), 'show', COMMIT+':'+source])
    expected = b''.join(blobs[source].splitlines(keepends=True)[row['first_line']-1:row['last_line']])
    assert text(checked(row['literal'])) == text(expected), row

readme = '''# HELD minimal ordinary heat-balance input assembly

Source only, based on clean pushed `6d1b2e248a568dc63acb37d8a0b545efc4849364`.
No canonical file, compiler, formatter, Cargo, Native engine, target or gate was changed by this packet.
Root must review and apply before any QA result can exist. All execution results remain pending.

## Actual consumed route

The existing ordinary CLI caller retains its same InputProcessor/unused set, shared shortcut,
preScan, live OutputProcessor time bindings, Project/global/Space controls, EIO and weather session.
Raw HB/Material projections carry values, loader origin and physical IDF field counts only;
they do not perform getter queries, erase unused inputs or clone a schema owner.

The source-context weather prepare reaches the actual zero-object WeatherStation producer
and EIO before existing ordinary GetNextEnvironment. The initializer then invokes actual
ProjectControl → SiteAtmosphere → Spectral/Material/Hysteresis/FrameDivider → regular
Construction → Shadowing → Zone/implicit Space input operations before existing geometry.
These are selected consumed input operations, not complete GetHeatBalanceInput or SetupSimulation.

ProjectControl borrows the sole early Space controls rather than retaining duplicate booleans.
Material reuses existing typed material/property storage; no second thermal property or CTF calculation.
Construction retains actual input order and usage flags. Selected geometry assigns IsUsed,
then actual opaque CTF assignment traversals assign IsUsedCTF. The existing surface/zone physical
geometry returns run once. Zone centroid uses literal SurfaceGeometry557–597 zero reset,
Space/class order, GrossArea products and guarded coordinate divisions from those surface returns.
The same returned ceiling height, volume and floor area are retained. Zone min/max writes,
full raw SurfaceTmp lifecycle and the rest of SetupZoneGeometry remain incomplete.

MINREPORTFREQUENCY and clipping settings are acquired once at the real early selected
processEnvironmentVariables boundary; the same ProjectSystemVariables are borrowed later.
The Output getter uses local four-alpha/one-numeric arrays, exact unused identities and
flag-before-getter/partial ReqVar retention. It does not mutate IPShortCut scratch.
No-bracket variable names retain trailing whitespace; bracket stripping trims only the six
Source ASCII whitespace characters. ThisOneOnTheList borrows the actual sole preScan.

The MTD host retains a chosen path and real File outside Clone reports, opens only at
InitializeOutput, and flushes only a reached stream after diagnostic/EIO prefix persistence.
Actual first-registration owners and four unmatched Zone dictionary/setup/total writes execute.
Requested report-dictionary/OutVar writers, RE2 keys, nonblank schedule and nonempty minimum
frequency branches remain explicit unavailable after their genuine reached prefixes.
This packet does not claim an unmatched Zone output variable has a retained OutVar binding.

On failure, input/global/Zone/Material/Shadow owners and real output prefixes stay on reports.
Only after all fallible initializer operations succeed are the sole globals and Zone owners
moved into HeatBalanceState. Material input/getter state remains retained on reports.
Legacy None/manual/diagnostic initializer routes and current CTF/LU/Solar numerical producers
remain intact. No deferred InitHB initializer or speculative dispatcher/cadence flags are copied.

## Existing test coverage and later validation

No test body or binary is added. Existing raw admission helper checks HB/Material raw custody
without unused erasure. The existing report-context test includes one local Output getter table:
success/bracket-vs-no-bracket behavior, regex partial push, and minimum-frequency pre-query stop.
Compiler report bodies retain current Source-origin tests and gain actual Output:Variable
IDF ordering/default/physical-alpha checks. Existing weather constructor coverage is extended.
The existing ordinary CLI checks actual ordered Station/Building/Site/Shadow EIO and reached
empty MTD. Existing direct-CTF test constructors supply an empty new output input vector.

Root should run one fmt/quality/all-target Clippy and the finite existing focused selections
in validation-plan.json, with the ordinary CLI normal and actual CI=Y variants.
No new Native execution or full-workspace duplicate is required for this Source-input slice.

## Limits preserved

Full SetupSimulation kickoff/DesignDay HB orchestration, full GetSurfaceData/geometry owner
lifecycle, GetHeatBalanceInput suffix/final fatal, exact InitHB timing, interior radiation,
inside solver/dispatcher cadence and HVAC remain incomplete. Current eager weather allocation
and current eager CTF initialization are explicitly retained limitations. Positive unsupported
families/fields are not widened, no Native endpoints enter production, and no scientific or
whole-startup PASS is asserted. All four SRC06 gates and plan counters remain unchanged.

## Finite provenance

manifest.json records every exact current base, full proposal and direct diff. Reused held
parents are finite metadata references; exact copied payloads are distinguished from narrow
merges by whole-byte/LF-normalized correspondence. Root's actual five-file pre-weather
continuation is preserved in the two overlapping context/output files. Original literal
ranges retain exact Git or explicitly qualified bundled-local custody and are reused directly; no giant Native raw, binary, full Source clone,
recursive provenance closure or invented future receipt is included.
'''
(OUT/'README.md').write_text(readme, encoding='utf-8', newline='\n')
validation = {
    'executed': False, 'new_test_bodies': 0, 'new_test_binaries': 0,
    'existing_test_functions_before_after': test_files,
    'focused_commands': [
        ['cargo','test','-p','ep_runtime','--lib','early_report_scan_is_shared_and_prescanned_owner_is_not_replayed'],
        ['cargo','test','-p','ep_runtime','--lib','ordinary_cache_uses_real_registry_columns_and_postlude_before_lifecycle'],
        ['cargo','test','-p','ep_runtime','--lib','source_constructor_defaults_and_allocation_are_distinct'],
        ['cargo','test','-p','ep_compiler','--lib','compiler::report_inputs::tests'],
        ['cargo','test','-p','ep_run','--lib','raw_equipment_admission_preserves_empty_presence_and_rejects_positive_or_field_branches'],
        ['cargo','test','-p','ep_run','--lib','actual_fatal_prefix_survives_runtime_failure_and_summary'],
        ['cargo','test','-p','ep_run','--test','arbitrary_run','one_zone_runtime_writes_stable_output_layout']
    ], 'ordinary_CLI_real_CI_FORCE_TIME_STEP_Y_repeat': True,
    'no_new_Native_or_full_workspace_duplicate_required_for_this_unit': True}
dump(OUT/'validation-plan.json', validation)
record = {
    'schema': 'src06-minimal-hb-input-held-assembly.v1',
    'status': 'HELD Source only; awaiting Root and independent review, no application or QA',
    'HEAD': HEAD, 'clean_Git_base_verified': True, 'Original_commit': COMMIT,
    'files': files, 'dependencies': dependencies, 'prefix_checks_rebase': ref(OUT/'prefix-checks-rebase.json'),
    'Original_ranges': ranges, 'README': ref(OUT/'README.md'),
    'validation_plan': ref(OUT/'validation-plan.json'),
    'authoring_Source': [ref(path) for path in [
        '.runtime/porting/SRC-06/prepare-minimal-hb-input-assembly-03.py',
        '.runtime/porting/SRC-06/refine-minimal-hb-input-assembly-04.py',
        '.runtime/porting/SRC-06/refine-minimal-hb-input-assembly-05.py',
        '.runtime/porting/SRC-06/refine-minimal-hb-input-assembly-06.py',
        '.runtime/porting/SRC-06/rebase-minimal-hb-input-assembly-07.py',
        '.runtime/porting/SRC-06/seal-minimal-hb-input-assembly-09.py']],
    'historical_failed_seal_preserved': ref('.runtime/porting/SRC-06/seal-minimal-hb-input-assembly-08.py'),
    'historical_failed_authors_preserved': [ref('.runtime/porting/SRC-06/prepare-minimal-hb-input-assembly-'+version+'.py') for version in ['01','02']],
    'source_only_execution': True, 'canonical_mutated': False,
    'compiler_formatter_Cargo_Native_or_targets_executed': False,
    'new_test_bodies': 0, 'new_test_binaries': 0, 'gates_updated': False,
    'full_GetHeatBalanceInput_InitHB_Setup_or_scientific_PASS_claim': False,
}
dump(OUT/'manifest.json', record)
dump(OUT/'status.json', {'status': record['status'], 'manifest': ref(OUT/'manifest.json'),
    'files': len(files), 'Original_ranges': len(ranges), 'canonical_mutated': False, 'targets_executed': False})
print(json.dumps({'manifest': ref(OUT/'manifest.json'), 'files':len(files), 'Original_ranges':len(ranges),
    'existing_test_bodies_added':0}, ensure_ascii=False))

from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

root = Path.cwd()
out = root/'.runtime/porting/SRC-06/Owner-ordinary-hb-lint-corrections-Source-review-02'
assert not out.exists()
def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
checked = []
def check(item):
    actual=ref(root/item['path'])
    assert all(item[key]==actual[key] for key in actual if key in item), item['path']
    checked.append(actual)
packet = root/'.runtime/porting/SRC-06/ordinary-hb-lint-corrections-prep-02/manifest.json'
assert ref(packet)['sha256'] == '2d3262a35caecb007d04acfe00a1511cb2d6f538d9847eca71855271c2dcf0e6'
value = json.loads(packet.read_bytes())
for key in ['parent_actual_assembly','actual_failed_Clippy','actual_failed_focused_tests','parent_lint_preparation','author']:
    check(value[key])
parent = json.loads((root/value['parent_actual_assembly']['path']).read_bytes())
parent_rows = {row['canonical_path']:row for row in parent['files']}
old = json.loads((root/value['parent_lint_preparation']['path']).read_bytes())
assert value['files'][:4] == old['files']
assert len(value['files']) == 5
details=[]
for index,row in enumerate(value['files']):
    name=row['canonical_path']
    for key in ['before','proposal','complete_diff']:check(row[key])
    before=(root/row['before']['path']).read_bytes()
    after=(root/row['proposal']['path']).read_bytes()
    assert (root/name).read_bytes()==before, name
    generated=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=name,tofile=name)).encode()
    assert generated==(root/row['complete_diff']['path']).read_bytes(), name
    assert len(re.findall(rb'#\[test\]',before))==len(re.findall(rb'#\[test\]',after))
    if index<4:
        assert parent_rows[name]['canonical']['sha256']==row['before']['sha256']
    else:
        committed=subprocess.run(['git','show',f"{parent['HEAD']}:{name}"],capture_output=True,check=True).stdout
        assert committed.replace(b'\r\n',b'\n')==before.replace(b'\r\n',b'\n')
    a,b=before.decode(),after.decode()
    if name.endswith(('building.rs','control.rs')):
        # Inverse every changed complete format invocation; preserve all bytes.
        pattern=re.compile(r'writeln!\((\s*eio,\s*)"(! <(?:Building Information|Zone Air Solution Algorithm|HVACSystemRootFindingAlgorithm)>[^"\n]*)"(\s*)\)')
        restored,count=pattern.subn(lambda m:'write!('+m[1]+'"'+m[2]+'\\n"'+m[3]+')',b)
        assert count==(1 if name.endswith('building.rs') else 2) and restored==a
        claim='Only three aggregate fixed-text header invocations change macro form; identical final newline bytes and the same fallible output owner.'
    elif name.endswith('requested_input.rs'):
        new=".trim_end_matches([' ', '\\u{000c}', '\\n', '\\r', '\\t', '\\u{000b}'])"
        old=".trim_end_matches(|ch| matches!(ch, ' ' | '\\u{000c}' | '\\n' | '\\r' | '\\t' | '\\u{000b}'))"
        assert b.count(new)==1 and b.replace(new,old)==a
        claim='Exact same six characters, bracket-only split and no-bracket return unchanged; array Pattern preserves character predicate.'
    elif name.endswith('/runtime.rs'):
        restored=b.replace('source_output_host: Option<','mut source_output_host: Option<').replace('match (source_output_host, weather_driver)','match (source_output_host.as_deref_mut(), weather_driver)')
        assert restored==a
        manager=(root/'crates/ep_runtime/src/heat_balance/manager.rs').read_text(encoding='utf-8')
        assert 'fn init_heat_balance_source_order_path<T>(execute: impl FnOnce() -> T)' in manager
        assert b.count('source_output_host')==3
        claim='Sole host first inspected by is_some then consumed once by FnOnce initialization; no later use, clone, new file or second host.'
    else:
        old='HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;Zone,z;'
        new='HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;Building,b,,,,,MinimalShadowing;Zone,z;'
        assert b.count(new)==1 and b.replace(new,old)==a
        assert '"Building":{"b":{"solar_distribution":"MinimalShadowing"}}' in a
        claim='Only existing staged IDF gains converted epJSON Building b with six physical fields; four blank defaults and explicit MinimalShadowing. Strict admission and every assertion retained.'
    details.append({'canonical_path':name,'complete_diff_regenerated_exactly':True,'complete_inverse_exact':True,'finding':claim})
failures=[]
for key in ['actual_failed_Clippy','actual_failed_focused_tests']:
    receipt=json.loads((root/value[key]['path']).read_bytes())
    assert receipt['exit_code']==101 and receipt['source_bytes_match_before_and_after'] is True
    for stream in ['stdout','stderr']:check(receipt[stream])
    failures.append({'receipt':value[key],'actual_exit_code':101,'Source_stable':True})
out.mkdir()
review={
 'schema':'src06-independent-hb-lint-corrections-Source-review.v1','accepted':True,
 'status':'accepted-HELD-Source-only-not-compile-or-test-certification',
 'preparation':ref(packet),'parent_preparation_four_payloads_byte_exact':True,
 'files':details,'all_checked_references':checked,
 'actual_FnOnce_contract':ref(root/'crates/ep_runtime/src/heat_balance/manager.rs'),
 'genuine_failed_QA_retained':failures,
 'scope':'Five files only: equivalent fixed-text IO/ASCII trim/sole-host move plus genuine existing fixture repair. No numerical formulas, raw positive-family admission, assertions or test-body count changed.',
 'blocking_findings':[],'new_test_bodies':0,'canonical_writes':False,
 'formatter_or_compiler_or_tests_or_engine_executed':False,'gate_or_numeric_PASS':False,
 'reviewer':'Owner independent of Root author','review_author':ref(Path(__file__)),
}
(out/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
print(json.dumps(ref(out/'review.json')))

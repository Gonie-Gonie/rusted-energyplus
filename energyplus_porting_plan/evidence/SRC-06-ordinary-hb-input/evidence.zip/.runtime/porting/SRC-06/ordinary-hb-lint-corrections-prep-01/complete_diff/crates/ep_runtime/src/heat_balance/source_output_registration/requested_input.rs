--- crates/ep_runtime/src/heat_balance/source_output_registration/requested_input.rs
+++ crates/ep_runtime/src/heat_balance/source_output_registration/requested_input.rs
@@ -158,7 +158,7 @@
         return name;
     };
     without_units
-        .trim_end_matches(|ch| matches!(ch, ' ' | '\u{000c}' | '\n' | '\r' | '\t' | '\u{000b}'))
+        .trim_end_matches([' ', '\u{000c}', '\n', '\r', '\t', '\u{000b}'])
 }
 
 impl SourceOutputRegistration {

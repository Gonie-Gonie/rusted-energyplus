--- crates/ep_runtime/src/runtime.rs
+++ crates/ep_runtime/src/runtime.rs
@@ -390,7 +390,7 @@
         &mut crate::heat_balance::ctf_initialization_context::CtfInitializationContext<'_>,
     >,
     reporting: Option<HeatBalanceOrdinaryWarmupReportInputs>,
-    mut source_output_host: Option<
+    source_output_host: Option<
         &mut crate::heat_balance::source_output_registration::SourceMtdFileHost,
     >,
 ) -> Result<HeatBalanceSimulation, RuntimeError> {
@@ -493,7 +493,7 @@
                 &schedule_cache,
             );
             let mut state = if let Some(context) = initialization.as_deref_mut() {
-                match (source_output_host.as_deref_mut(), weather_driver) {
+                match (source_output_host, weather_driver) {
                     (Some(host), Some(HeatBalanceWeatherDriver::Production(weather))) =>
                         weather.with_source_environment_mut(|environment, minutes|
                             initialize_heat_balance_state_with_initialization_context_and_equipment_profiled(

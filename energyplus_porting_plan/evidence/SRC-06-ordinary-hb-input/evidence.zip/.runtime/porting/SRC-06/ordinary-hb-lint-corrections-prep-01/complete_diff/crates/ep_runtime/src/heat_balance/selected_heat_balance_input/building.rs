--- crates/ep_runtime/src/heat_balance/selected_heat_balance_input/building.rs
+++ crates/ep_runtime/src/heat_balance/selected_heat_balance_input/building.rs
@@ -125,9 +125,9 @@
             owners.project.min_number_of_warmup_days = 1;
             ("NOT ENTERED".into(), "NOT ENTERED".into())
         };
-        write!(
+        writeln!(
             eio,
-            "! <Building Information>, Building Name,North Axis {{deg}},Terrain,  Loads Convergence Tolerance Value,Temperature Convergence Tolerance Value,  Solar Distribution,Maximum Number of Warmup Days,Minimum Number of Warmup Days\n"
+            "! <Building Information>, Building Name,North Axis {{deg}},Terrain,  Loads Convergence Tolerance Value,Temperature Convergence Tolerance Value,  Solar Distribution,Maximum Number of Warmup Days,Minimum Number of Warmup Days"
         )?;
         writeln!(
             eio,

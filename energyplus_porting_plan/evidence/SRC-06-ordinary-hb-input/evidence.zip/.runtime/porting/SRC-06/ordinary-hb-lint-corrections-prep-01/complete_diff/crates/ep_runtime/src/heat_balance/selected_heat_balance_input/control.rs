--- crates/ep_runtime/src/heat_balance/selected_heat_balance_input/control.rs
+++ crates/ep_runtime/src/heat_balance/selected_heat_balance_input/control.rs
@@ -153,9 +153,9 @@
             self.zone_air_solution = SelectedZoneAirSolution::Euler;
             zone_label = "EulerMethod".into();
         }
-        write!(
-            eio,
-            "! <Zone Air Solution Algorithm>, Algorithm {{ThirdOrderBackwardDifference | AnalyticalSolution | EulerMethod}}, Space Heat Balance Sizing, Space Heat Balance Simulation\n"
+        writeln!(
+            eio,
+            "! <Zone Air Solution Algorithm>, Algorithm {{ThirdOrderBackwardDifference | AnalyticalSolution | EulerMethod}}, Space Heat Balance Sizing, Space Heat Balance Simulation"
         )?;
         writeln!(
             eio,
@@ -214,9 +214,9 @@
         )?;
         absent(owners, "HVACSystemRootFindingAlgorithm")?;
         self.root_algorithm = "RegulaFalsi".into();
-        write!(
-            eio,
-            "! <HVACSystemRootFindingAlgorithm>, Value {{RegulaFalsi | Bisection | BisectionThenRegulaFalsi | RegulaFalsiThenBisection}}\n"
+        writeln!(
+            eio,
+            "! <HVACSystemRootFindingAlgorithm>, Value {{RegulaFalsi | Bisection | BisectionThenRegulaFalsi | RegulaFalsiThenBisection}}"
         )?;
         writeln!(
             eio,

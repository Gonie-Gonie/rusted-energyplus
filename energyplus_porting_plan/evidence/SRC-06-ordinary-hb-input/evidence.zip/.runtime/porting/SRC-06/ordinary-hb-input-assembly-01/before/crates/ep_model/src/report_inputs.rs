//! Input-only owners read by General::ScanForReports; no report is generated here.

/// The five actual object families visited by the first report scan.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ReportInputObjectType {
    /// Output:Surfaces:List.
    SurfacesList,
    /// Output:Surfaces:Drawing.
    SurfacesDrawing,
    /// Output:VariableDictionary.
    VariableDictionary,
    /// Output:Constructions.
    Constructions,
    /// Output:EnergyManagementSystem; preserving report input does not activate EMS.
    EnergyManagementSystem,
}

impl ReportInputObjectType {
    /// Canonical source object type.
    #[must_use]
    pub const fn source_name(self) -> &'static str {
        match self {
            Self::SurfacesList => "Output:Surfaces:List",
            Self::SurfacesDrawing => "Output:Surfaces:Drawing",
            Self::VariableDictionary => "Output:VariableDictionary",
            Self::Constructions => "Output:Constructions",
            Self::EnergyManagementSystem => "Output:EnergyManagementSystem",
        }
    }
}

/// A real input object's default-applied getObjectItem alpha projection.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReportInputObject {
    /// Original epJSON key, or the actual IdfParser-generated unnamed identity.
    pub object_name: String,
    /// Source family; records retain actual order within each family.
    pub object_type: ReportInputObjectType,
    /// Actual uppercase/default-applied alpha values; unused positions are empty.
    pub alphas: [String; 3],
    /// Actual blank facts, including a default substituted for missing/empty input.
    pub alpha_blank: [bool; 3],
    /// Which alpha values came from an IDD default.
    pub default_applied: [bool; 3],
    /// Actual supplied/minimum-field alpha count; defaults do not extend this.
    pub num_alphas: u8,
    /// True for direct epJSON, false for the validated staged-IDF order overlay.
    pub is_epjson: bool,
}

impl ReportInputObject {
    /// Exact field label used by ScanForReports' surface-list warning.
    #[must_use]
    pub fn report_type_field_name(&self) -> &'static str {
        if self.is_epjson {
            "report_type"
        } else {
            "Report Type"
        }
    }
}

/// Input-only report objects; no cache or observed report outcome is supplied.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReportInputs {
    /// Actual object order within each source family; cross-family scan order is fixed.
    pub objects: Vec<ReportInputObject>,
    /// Actual getNumSectionsFound result for the legacy dictionary section; -1 absent.
    pub legacy_variable_dictionary_sections: i32,
}

impl Default for ReportInputs {
    fn default() -> Self {
        Self {
            objects: Vec::new(),
            legacy_variable_dictionary_sections: -1,
        }
    }
}

/// Actual selected loader name members retained separately from normalized IDs.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CtfReportNames {
    /// Regular names keep the JSON key; NoMass/AirGap getObjectItem names are uppercase.
    pub materials: Vec<(crate::MaterialId, String)>,
    /// Ordinary Construction getObjectItem Name members, in true producer order.
    pub constructions: Vec<(crate::ConstructionId, String)>,
}

/// Genuine first SimulationControl getObjectItem alpha projection for the two
/// sizing flags consumed by SetPredefinedTables. Other control fields are separate.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SimulationControlSizingInput {
    /// Actual first unique object's epJSON/IdfParser identity.
    pub object_name: String,
    /// Actual uppercase/default-applied zone and system sizing alpha owners.
    pub alphas: [String; 2],
    /// Actual missing/empty field facts before default substitution.
    pub alpha_blank: [bool; 2],
    /// Actual IDD No substitution facts, independent of the resulting value.
    pub default_applied: [bool; 2],
}

/// Input-only prerequisite for the complete predefined registry.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct PredefinedTableSizing {
    /// None means no actual SimulationControl getter invocation was required.
    pub first_object: Option<SimulationControlSizingInput>,
}

impl PredefinedTableSizing {
    /// Literal GetProjectData false reset followed by the two actual YES tests.
    #[must_use]
    pub fn actual_flags(&self) -> (bool, bool) {
        let mut do_zone_sizing = false;
        let mut do_system_sizing = false;
        if let Some(input) = &self.first_object {
            if input.alphas[0] == "YES" {
                do_zone_sizing = true;
            }
            if input.alphas[1] == "YES" {
                do_system_sizing = true;
            }
        }
        (do_zone_sizing, do_system_sizing)
    }
}

//! Heat-balance state initialization and diagnostic CTF seeding helpers.

mod schedule_cache;
mod state_shell;
pub(crate) use state_shell::install_ctf_metadata;
mod construction_input;
use construction_input::InitialConstructionData;

#[cfg(test)]
pub(crate) use schedule_cache::initialize_heat_balance_state_with_ctf_coefficients_and_schedule_cache;
pub use schedule_cache::{
    initialize_heat_balance_state, initialize_heat_balance_state_with_ctf_coefficients,
    initialize_heat_balance_state_with_initialization_context,
};
pub(crate) use schedule_cache::{
    initialize_heat_balance_state_with_ctf_coefficients_and_schedule_cache_profiled,
    initialize_heat_balance_state_with_initialization_context_and_equipment_profiled,
    initialize_heat_balance_state_with_initialization_context_profiled,
};

use crate::error::RuntimeError;
use crate::geometry::{
    InitializedGeometryOwners, InitializedZoneGeometry, opaque_geometry_owners,
    zone_geometry_properties,
};
use crate::heat_balance::ctf::{
    ConstructionCtfCoefficientOverride, all_resistive_surface_ctf_state,
    construction_ctf_coefficients_by_name, steady_ctf_coefficient_w_per_m2_k,
    steady_surface_ctf_state, surface_ctf_state_from_coefficient_rows,
};
use crate::heat_balance::inside_convection::zone_surface_convection_sums_for_indices;
use crate::heat_balance::state::{
    HeatBalanceState, HeatBalanceSurfaceIndexes, SurfaceExteriorReportTerms,
    SurfaceHeatBalanceState, SurfaceOutsideBalanceDiagnostics, ZoneAirTemperatureCoefficients,
    ZoneHeatBalanceState,
};
use crate::heat_balance::surface_boundary::resolve_surface_boundary_target;
use crate::heat_balance::surface_manager::ConstructionThermalDataCache;
use crate::heat_balance::zone_air_correction::ENERGYPLUS_DEFAULT_ZONE_AIR_HUMIDITY_RATIO;
use crate::heat_balance::zone_predictor_corrector::energyplus_zone_air_temperature_coefficients;
use crate::psychrometrics::energyplus_standard_zone_air_heat_capacity_j_per_k;
use crate::schedules::{InternalGainSchedulePhaseOperations, ScheduleSeriesCache};
use ep_model::SimulationModel;
use state_shell::finish_heat_balance_state;

/// Actual optional raw-admission projections for the one existing initializer.
#[derive(Default)]
pub(crate) struct OrdinaryInitializationInputs {
    pub(crate) equipment: Option<super::ordinary_equipment::OrdinaryEquipmentInput>,
    pub(crate) radiation: Option<super::radiation::ordinary::OrdinaryRadiationInput>,
}

const ENERGYPLUS_INITIAL_CONVECTION_COEFFICIENT_W_PER_M2_K: f64 = 3.076;
fn initialize_heat_balance_state_with_ctf_coefficients_from_schedule_cache(
    model: &SimulationModel,
    initial_zone_air_temperature_c: f64,
    ctf_coefficients: &[ConstructionCtfCoefficientOverride],
    schedule_cache: &ScheduleSeriesCache,
    operations: Option<&mut InternalGainSchedulePhaseOperations>,
    initialization: Option<
        &mut crate::heat_balance::ctf_initialization_context::CtfInitializationContext<'_>,
    >,
    inputs: OrdinaryInitializationInputs,
) -> Result<HeatBalanceState, RuntimeError> {
    initialize_heat_balance_state_with_ctf_coefficients_from_schedule_cache_mode(
        model, initial_zone_air_temperature_c, ctf_coefficients, schedule_cache,
        operations, initialization, inputs, false, None,
    )
}

/// Actual selected GetHeatBalanceInput material/geometry stage. This leaves
/// CTF/public/history owners unavailable until the reached InitHeatBalance.
pub(crate) fn prepare_heat_balance_state_for_setup(
    model: &SimulationModel,
    initial_zone_air_temperature_c: f64,
    schedule_cache: &ScheduleSeriesCache,
    initialization: &mut crate::heat_balance::ctf_initialization_context::CtfInitializationContext<'_>,
    inputs: OrdinaryInitializationInputs,
    source_environment: &mut crate::weather::day::WeatherEnvironmentState,
    source_globals: &mut Option<super::selected_heat_balance_globals::SelectedHeatBalanceGlobals>,
) -> Result<HeatBalanceState, RuntimeError> {
    if source_globals.is_none() {
        return Err(RuntimeError::WarmupUnavailable { reason: "missing genuine pre-Setup globals".into() });
    }
    let mut state = initialize_heat_balance_state_with_ctf_coefficients_from_schedule_cache_mode(
        model, initial_zone_air_temperature_c, &[], schedule_cache,
        None, Some(initialization), inputs, true, Some(source_environment),
    )?;
    // Take the actual caller-owned globals only after all fallible preparation
    // has returned. A failure leaves that sole early owner with the caller.
    state.selected_heat_balance_globals = source_globals.take().ok_or_else(|| RuntimeError::WarmupUnavailable {
        reason: "pre-Setup globals were consumed during preparation".into() })?;
    Ok(state)
}

#[allow(clippy::too_many_arguments)] // Existing initializer plus explicit actual Setup owners.
fn initialize_heat_balance_state_with_ctf_coefficients_from_schedule_cache_mode(
    model: &SimulationModel,
    initial_zone_air_temperature_c: f64,
    ctf_coefficients: &[ConstructionCtfCoefficientOverride],
    schedule_cache: &ScheduleSeriesCache,
    mut operations: Option<&mut InternalGainSchedulePhaseOperations>,
    mut initialization: Option<
        &mut crate::heat_balance::ctf_initialization_context::CtfInitializationContext<'_>,
    >,
    inputs: OrdinaryInitializationInputs,
    defer_ctf: bool,
    source_environment: Option<&mut crate::weather::day::WeatherEnvironmentState>,
) -> Result<HeatBalanceState, RuntimeError> {
    let OrdinaryInitializationInputs {
        equipment: equipment_input,
        radiation: radiation_input,
    } = inputs;
    if defer_ctf && (radiation_input.is_none() || equipment_input.is_none() || !ctf_coefficients.is_empty()) {
        return Err(super::radiation::ordinary::OrdinaryRadiationError::from(
            super::radiation::ordinary::OrdinaryRadiationUnavailable::InputBranch).into());
    }
    if radiation_input.is_some() && initialization.is_none() {
        return Err(super::radiation::ordinary::OrdinaryRadiationError::from(
            super::radiation::ordinary::OrdinaryRadiationUnavailable::MissingInitializationContext,
        )
        .into());
    }
    // GetProjectControlData writes Building terrain before
    // GetSiteAtmosphereData264; GetMaterial/GetConstruct precede geometry.
    let deferred_material_input = if defer_ctf {
        let actual = initialization.as_deref_mut().ok_or_else(|| RuntimeError::WarmupUnavailable {
            reason: "deferred material stage requires real initialization sinks".into() })?;
        let environment = source_environment.ok_or_else(|| RuntimeError::WarmupUnavailable {
            reason: "deferred material stage requires the sole live weather environment".into() })?;
        if !environment.source_weather_station_initialized || environment.source_site_atmosphere_initialized {
            return Err(RuntimeError::WarmupUnavailable { reason: "actual station/site getter call order".into() });
        }
        actual.get_selected_project_control_data(environment)?;
        actual.reports.heat_balance_manager_current_module_object = "Site:HeightVariation".into();
        if actual.reports.selected_input_processor.as_ref().is_none_or(|input|
            input.get_num_objects_found("Site:HeightVariation") != 0) {
            return Err(RuntimeError::WarmupUnavailable { reason: "selected absent Site:HeightVariation requires actual raw input".into() });
        }
        environment.outdoor_environment_parameters.initialize_absent_site_height_variation(actual.eio)
            .map_err(super::ordinary_heat_balance_initialization::environment::parameter_error)?;
        environment.source_site_atmosphere_initialized = true;
        // Genuine spectral/material/hysteresis/frame getter dependency, owned
        // by the separate selected Material packet; no no-op replacement.
        actual.get_selected_material_data(&model.typed)?;
        actual.read_selected_construction_arguments(&model.typed)?;
        let maximum = usize::try_from(actual.reports.selected_simulation_startup.construction_bounds.max_solid_window_layers).ok()
            .filter(|value| *value > 0).ok_or_else(|| RuntimeError::WarmupUnavailable {
                reason: "missing real SetPreConstructionInputParameters bounds".into() })?;
        Some(crate::heat_balance::surface_manager::ConstructionMaterialInputs::from_input(&model.typed, maximum)?)
    } else { None };
    if let Some(actual) = initialization.as_deref_mut() {
        actual.prepare_report_input_cache(&model.typed.report_inputs)?;
    }
    // HeatBalanceManager GetBuildingData1815 precedes GetZoneData and
    // SetupZoneGeometry. Acquire the real selected process operands once at
    // this consumed host boundary; no input getter is replayed by Solar later.
    if let Some(input) = radiation_input.filter(|_| initialization.as_ref().is_some_and(|actual|
        actual.reports.selected_input_processor.is_some())) {
        let actual = initialization.as_deref_mut().ok_or_else(|| RuntimeError::from(
            super::radiation::ordinary::OrdinaryRadiationError::from(
                super::radiation::ordinary::OrdinaryRadiationUnavailable::MissingInitializationContext)))?;
        let settings = super::solar_shading::input::ShadowingSystemSettings::from_process_environment()
            .map_err(super::radiation::ordinary::OrdinaryRadiationError::from)?;
        let mut owner = super::solar_shading::input::SourceShadowingInput::new(settings);
        let result = owner.get_at_building_boundary(input, actual);
        actual.reports.shadowing_input = Some(owner);
        result?;
        // SurfaceGeometry GetSurfaceData1223 reaches AllocateSurfaceWindows
        // before vertex processing. Retain selected actual reveal arrays here,
        // so later geometry failure leaves their real zero-allocated prefix.
        actual.reports.geometry_window_reveal = Some(
            super::solar_shading::GeometryRevealStorage::allocate_at_get_surface_data(model.typed.surfaces.len()));
    }
    // SurfaceGeometry290->298->548: actual admitted surface-data validation
    // precedes GetZoneEquipment, and volume calculation follows the getter.
    // Retain these real geometry/boundary returns for the later surface owner;
    // no second geometry calculation or Native endpoint is used.
    let admitted_surface_data = equipment_input
        .map(|_| {
            if model.typed.surfaces.is_empty() {
                return Err(RuntimeError::WarmupUnavailable {
                    reason: "missing admitted surface data before GetZoneEquipment".into(),
                });
            }
            super::inside_convection_layout::InsideConvectionLayout::from_typed_model(&model.typed)
                .map_err(|_| RuntimeError::WarmupUnavailable {
                    reason: "invalid surface associations before GetZoneEquipment".into(),
                })?;
            model
                .typed
                .surfaces
                .iter()
                .map(|surface| {
                    let geometry = crate::geometry::surface_geometry_properties(&surface.vertices)
                        .map_err(|error| RuntimeError::InvalidSurfaceGeometry {
                            surface_name: surface.name.0.clone(),
                            reason: error.to_string(),
                        })?;
                    let boundary = resolve_surface_boundary_target(&model.typed, surface)?;
                    Ok::<_, RuntimeError>((geometry, boundary))
                })
                .collect::<Result<Vec<_>, _>>()
        })
        .transpose()?;
    let equipment = equipment_input
        .map(|input| {
            super::ordinary_equipment::OrdinaryEquipment::for_geometry(&model.typed, input).map_err(
                |reason| RuntimeError::WarmupUnavailable {
                    reason: format!("ordinary geometry equipment unavailable: {reason}"),
                },
            )
        })
        .transpose()?;
    let ctf_coefficients_by_construction = construction_ctf_coefficients_by_name(ctf_coefficients);
    let mut zones = Vec::with_capacity(model.typed.zones.len());
    let mut zone_geometry_returns = Vec::with_capacity(model.typed.zones.len());
    for zone in &model.typed.zones {
        let geometry = zone_geometry_properties(&model.typed, zone);
        crate::geometry::zone_volume_trace::record(zone.id, &zone.name.0, &geometry);
        let geometry = geometry.map_err(|error| RuntimeError::UnsupportedZoneVolumeGeometry {
            zone_name: zone.name.0.clone(),
            reason: error.to_string(),
        })?;
        let volume_m3 = geometry.volume_m3;
        zone_geometry_returns.push(InitializedZoneGeometry {
            zone_id: zone.id,
            returned: geometry,
        });
        zones.push(ZoneHeatBalanceState {
            zone_id: zone.id,
            zone_name: zone.name.0.clone(),
            mean_air_temperature_c: initial_zone_air_temperature_c,
            zone_timestep_average_air_temperature_c: initial_zone_air_temperature_c,
            previous_mean_air_temperatures_c: [initial_zone_air_temperature_c; 3],
            previous_system_mean_air_temperatures_c: [initial_zone_air_temperature_c; 3],
            previous_system_timestep_count: 1,
            air_humidity_ratio: ENERGYPLUS_DEFAULT_ZONE_AIR_HUMIDITY_RATIO,
            zone_timestep_average_air_humidity_ratio: ENERGYPLUS_DEFAULT_ZONE_AIR_HUMIDITY_RATIO,
            previous_air_humidity_ratios: [ENERGYPLUS_DEFAULT_ZONE_AIR_HUMIDITY_RATIO; 3],
            previous_system_air_humidity_ratios: [ENERGYPLUS_DEFAULT_ZONE_AIR_HUMIDITY_RATIO; 3],
            use_zone_timestep_history: true,
            shorten_timestep_sys: false,
            prior_timestep_seconds: 0.0,
            volume_m3,
            air_heat_capacity_j_per_k: energyplus_standard_zone_air_heat_capacity_j_per_k(
                volume_m3,
                initial_zone_air_temperature_c,
                ENERGYPLUS_DEFAULT_ZONE_AIR_HUMIDITY_RATIO,
            )
            .unwrap_or(0.0),
            // On the admitted solar route, defer the actual physical gain
            // consumer until construction/surface returns and InitSolar.
            // The legacy None route retains its existing call order.
            convective_internal_gain_w: if radiation_input.is_some() {
                0.0
            } else {
                schedule_cache::convective_internal_gain_w_for_initialization(
                    &model.typed,
                    schedule_cache,
                    zone.id,
                    operations.as_deref_mut(),
                )
            },
            opaque_surface_conductance_w_per_k: 0.0,
            opaque_surface_heat_gain_w: 0.0,
            opaque_surface_outside_conduction_w: 0.0,
            sum_ha_w_per_k: 0.0,
            sum_hat_surf_w: 0.0,
            sum_hat_ref_w: 0.0,
            sum_mcp_w_per_k: 0.0,
            sum_mcp_t_w: 0.0,
            sum_sys_mcp_w_per_k: 0.0,
            sum_sys_mcp_t_w: 0.0,
            system_dependent_zone_loads_lagged_w: 0.0,
            zone_air_temperature_coefficients: ZoneAirTemperatureCoefficients::ZERO,
            system_timestep_average_surface_convection_report_w: None,
            system_timestep_average_air_storage_report_w: None,
        });
    }

    // Validate actual declared references before selected public generation
    // can reject an unsupported boundary family. Preserve the existing
    // MissingSurface/ZoneBoundaryTarget contract without widening support.
    let boundary_targets = if let Some(data) = &admitted_surface_data {
        data.iter().map(|(_, boundary)| *boundary).collect()
    } else {
        model
            .typed
            .surfaces
            .iter()
            .map(|surface| resolve_surface_boundary_target(&model.typed, surface))
            .collect::<Result<Vec<_>, _>>()?
    };
    if let Some(actual) = initialization.as_deref_mut() {
        actual.prepare_registry(&model.typed)?;
        crate::heat_balance::ctf_geometry_reports::report_ordinary_surface_nominal_u(
            &model.typed,
            &actual.reports.registry,
            &mut actual.reports.table,
        )
        .map_err(crate::heat_balance::ctf_initialization_context::CtfInitializationError::Owner)?;
    }
    let mut construction_thermal_data = if defer_ctf {
        InitialConstructionData::Input(deferred_material_input.ok_or_else(|| RuntimeError::WarmupUnavailable { reason: "missing prepared actual material owner".into() })?)
    } else if let Some(actual) = initialization.as_deref_mut() {
        InitialConstructionData::Ready(ConstructionThermalDataCache::build_with_initialization_context(
            &model.typed,
            &ctf_coefficients_by_construction,
            actual,
        )?)
    } else {
        InitialConstructionData::Ready(ConstructionThermalDataCache::build(&model.typed, &ctf_coefficients_by_construction)?)
    };
    let (ctf_surface_lifecycle, public_generation) = if let Some(cache) = construction_thermal_data.ready_mut() {
        let construction_cache_token = cache.invalidation_token();
        debug_assert!(!cache.is_invalidated_by(construction_cache_token));
        let lifecycle = cache.take_public_surface_lifecycle().transpose()
            .map_err(RuntimeError::CtfSurfaceLifecycle)?;
        let generation = if lifecycle.is_some() {
            Some(crate::heat_balance::ctf_surface_binding::capture_public_ctf_surface_generation(
                &model.typed,
                cache.public_initialization().ok_or(RuntimeError::CtfSurfaceLifecycle(
                    crate::heat_balance::ctf_surface_lifecycle::CtfSurfaceLifecycleUnavailable::MissingPublicOwner))?,
                cache.generation_context,
            ).map_err(|error| RuntimeError::CtfSurfaceLifecycle(error.into()))?)
        } else { None };
        (lifecycle, generation)
    } else { (None, None) };
    let mut surfaces = model
        .typed
        .surfaces
        .iter()
        .zip(boundary_targets)
        .enumerate()
        .map(|(index, (surface, boundary))| {
            let geometry = if let Some(data) = &admitted_surface_data {
                data[index].0
            } else {
                crate::geometry::surface_geometry_properties(&surface.vertices)
                    .map_err(|error| RuntimeError::InvalidSurfaceGeometry {
                        surface_name: surface.name.0.clone(), reason: error.to_string(),
                    })?
            };
            let area_m2 = geometry.area_m2;
            let azimuth_deg = geometry.azimuth_deg;
            let tilt_deg = geometry.tilt_deg;
            let thermal = construction_thermal_data.data_for_surface(surface)?;
            let conductance_w_per_k = area_m2 / thermal.thermal_resistance_m2_k_per_w;
            let steady_ctf_w_per_m2_k =
                steady_ctf_coefficient_w_per_m2_k(area_m2, thermal.thermal_resistance_m2_k_per_w);
            let ctf = if let Some(generation) = &public_generation {
                let binding = generation
                    .bind_surface(surface.id)
                    .map_err(|error| RuntimeError::CtfSurfaceLifecycle(error.into()))?;
                crate::heat_balance::ctf::surface_ctf_state_from_public_storage(
                    binding.coefficients,
                )
            } else if defer_ctf {
                construction_input::before_ctf_producer()
            } else {
                let thermal = construction_thermal_data.ready()
                    .ok_or_else(|| RuntimeError::WarmupUnavailable { reason: "legacy CTF cache absent".into() })?
                    .data_for_surface(surface)?;
                surface_ctf_state_from_coefficient_rows(
                    &thermal.ctf_coefficients,
                    initial_zone_air_temperature_c,
                )
                .unwrap_or_else(|| {
                    match (
                        thermal.ctf_coefficients.is_empty(),
                        &thermal.ctf02_coefficients.result,
                    ) {
                        (true, Ok(coefficients)) => all_resistive_surface_ctf_state(
                            coefficients,
                            initial_zone_air_temperature_c,
                        ),
                        _ => steady_surface_ctf_state(
                            steady_ctf_w_per_m2_k,
                            initial_zone_air_temperature_c,
                        ),
                    }
                })
            };

            Ok(SurfaceHeatBalanceState {
                solar_heat_gains: super::radiation::ordinary::SurfaceSolarHeatGains::from_initialized_geometry(surface, geometry.cos_tilt),
                surface_id: surface.id,
                zone_id: surface.zone,
                surface_name: surface.name.0.clone(),
                surface_type: surface.surface_type,
                outside_boundary_condition: surface.outside_boundary_condition,
                outside_boundary_condition_object_name: surface
                    .outside_boundary_condition_object
                    .as_ref()
                    .map(|name| name.0.clone()),
                outside_boundary_target_surface_id: boundary.surface_id,
                outside_boundary_target_zone_id: boundary.zone_id,
                construction_id: thermal.construction_id,
                active_construction_id: thermal.construction_id,
                construction_thermal_data_index: thermal.cache_index,
                construction_name: thermal.construction_name.clone(),
                outside_layer_material_id: thermal.outside_layer_material_id,
                outside_layer_material_name: thermal.outside_layer_material_name.clone(),
                outside_layer_roughness: thermal.outside_layer_roughness,
                area_m2,
                azimuth_deg,
                tilt_deg,
                geometry,
                outdoor_environment: super::convection::surface_environment::SurfaceOutdoorEnvironmentState::allocate(
                    geometry.centroid_m.z_m, surface.wind_exposure == ep_model::WindExposure::WindExposed),
                thermal_resistance_m2_k_per_w: thermal.thermal_resistance_m2_k_per_w,
                heat_capacity_j_per_m2_k: thermal.heat_capacity_j_per_m2_k,
                thermal_absorptance: thermal.thermal_absorptance,
                inside_thermal_absorptance: thermal.inside_thermal_absorptance,
                solar_absorptance: thermal.solar_absorptance,
                inside_solar_absorptance: thermal.inside_solar_absorptance,
                conductance_w_per_k,
                inside_convection_coefficient_w_per_m2_k:
                    ENERGYPLUS_INITIAL_CONVECTION_COEFFICIENT_W_PER_M2_K,
                inside_convection_input_inside_face_temperature_c: initial_zone_air_temperature_c,
                inside_convection_input_reference_air_temperature_c: initial_zone_air_temperature_c,
                inside_reference_air_temperature_c: initial_zone_air_temperature_c,
                inside_ctf_outside_temperature_c: initial_zone_air_temperature_c,
                inside_radiant_internal_gain_w_per_m2: 0.0,
                inside_shortwave_absorbed_w_per_m2: 0.0,
                inside_additional_heat_source_w_per_m2: 0.0,
                inside_radiant_hvac_w_per_m2: 0.0,
                inside_net_longwave_w_per_m2: 0.0,
                ctf,
                heat_gain_to_zone_w: 0.0,
                outside_report_terms: SurfaceExteriorReportTerms::default(),
                outside_balance_diagnostics: SurfaceOutsideBalanceDiagnostics::default(),
                inside_face_temperature_c: initial_zone_air_temperature_c,
                outside_face_temperature_c: initial_zone_air_temperature_c,
            })
        })
        .collect::<Result<Vec<_>, RuntimeError>>()?;
    if let Some(input) = radiation_input {
        let actual = initialization.as_deref_mut().ok_or_else(|| {
            RuntimeError::from(super::radiation::ordinary::OrdinaryRadiationError::from(
                super::radiation::ordinary::OrdinaryRadiationUnavailable::MissingInitializationContext,
            ))
        })?;
        let mut owner =
            super::radiation::ordinary::OrdinarySolarRadiation::for_initialized_geometry(
                &model.typed,
                &surfaces,
                input,
            )?;
        // Restore the real reached prefix before propagating any output/domain
        // failure, so the caller's reports/EIO/backend retain the partial owner.
        let result = owner.initialize_solar_at_input_boundary(&model.typed, &surfaces, actual);
        actual.reports.ordinary_solar_radiation = Some(owner);
        result?;
        // These are the present typed-model consumers, not a claim that the
        // full Original ManageInternalHeatGains/GetInternalHeatGainsInput is ported.
        if !defer_ctf {
        for zone in &mut zones {
            zone.convective_internal_gain_w =
                schedule_cache::convective_internal_gain_w_for_initialization(
                    &model.typed,
                    schedule_cache,
                    zone.zone_id,
                    operations.as_deref_mut(),
                );
        }
        }
    }
    if !defer_ctf {
    schedule_cache::initialize_surface_radiant_internal_gains(
        &model.typed,
        schedule_cache,
        &mut surfaces,
        operations,
    );
    }
    let surface_indexes = HeatBalanceSurfaceIndexes::from_model_surfaces(model, &surfaces);
    let actual_surface_geometry = surfaces
        .iter()
        .map(|surface| (surface.surface_id, surface.geometry))
        .collect::<Vec<_>>();
    let initialized_geometry = InitializedGeometryOwners {
        zone_returns: zone_geometry_returns,
        opaque_setup: opaque_geometry_owners(&model.typed, &actual_surface_geometry),
    };

    if !defer_ctf {
    for zone in &mut zones {
        let zone_surface_indexes = surface_indexes.surfaces_for_zone(zone.zone_id);
        zone.opaque_surface_conductance_w_per_k = zone_surface_indexes
            .iter()
            .filter_map(|surface_index| surfaces.get(*surface_index))
            .map(|surface| surface.conductance_w_per_k)
            .sum();
        let (sum_ha_w_per_k, sum_hat_surf_w, sum_hat_ref_w) =
            zone_surface_convection_sums_for_indices(&surfaces, zone_surface_indexes);
        zone.sum_ha_w_per_k = sum_ha_w_per_k;
        zone.sum_hat_surf_w = sum_hat_surf_w;
        zone.sum_hat_ref_w = sum_hat_ref_w;
        zone.zone_air_temperature_coefficients =
            crate::heat_balance::air_manager::get_air_heat_balance_input_compat(|| {
                energyplus_zone_air_temperature_coefficients(
                    zone.sum_ha_w_per_k,
                    zone.sum_hat_surf_w,
                    zone.sum_hat_ref_w,
                    zone.convective_internal_gain_w,
                    zone.sum_mcp_w_per_k + zone.sum_sys_mcp_w_per_k,
                    zone.sum_mcp_t_w + zone.sum_sys_mcp_t_w,
                    zone.air_heat_capacity_j_per_k,
                    0.0,
                    zone.previous_mean_air_temperatures_c,
                )
            });
    }

    }
    let construction_input_properties = construction_thermal_data.material_entries();
    let mut state = finish_heat_balance_state(
        zones,
        initialized_geometry,
        surfaces,
        surface_indexes,
        construction_thermal_data.into_ready(),
        ctf_surface_lifecycle,
    );
    state.construction_input_properties = construction_input_properties;
    state.selected_heat_balance_initialization = defer_ctf.then(Default::default);
    if let Some(owner) = state.selected_heat_balance_initialization.as_mut() {
        let geometry = state.initialized_geometry.opaque_setup.as_ref().map_err(|error| RuntimeError::WarmupUnavailable {
            reason: format!("actual Zone centroid unavailable: {error}") })?;
        owner.zone_outdoor = state.zones.iter().map(|zone| {
            let actual = geometry.zones.iter().find(|row| row.zone_id == zone.zone_id)
                .ok_or_else(|| RuntimeError::WarmupUnavailable { reason: "actual Zone centroid association absent".into() })?;
            Ok(super::ordinary_heat_balance_initialization::environment::ZoneOutdoorEnvironment {
                zone_id: zone.zone_id, name: zone.zone_name.clone(), centroid_m: actual.centroid_m,
                dry_bulb: 0.0, wet_bulb: 0.0, wind_speed: 0.0, wind_direction: 0.0,
            })
        }).collect::<Result<Vec<_>, RuntimeError>>()?;
        owner.window_temperatures = state.surfaces.iter().map(|surface| {
            let mut theta = [0.0; 11]; theta[0] = 296.15;
            (surface.surface_id, theta, 23.0)
        }).collect();
    }
    state.ordinary_equipment = equipment;
    state.selected_daylighting = radiation_input.map(|input| {
        super::daylighting::SelectedDaylighting::new(input.daylighting_input())
    });
    if let Some(actual) = initialization.as_deref_mut() {
        state.empty_internal_gain_providers = actual.reports.empty_internal_gain_providers.take();
    }
    if radiation_input.is_some() {
        state.ordinary_solar_radiation =
            initialization.and_then(|actual| actual.reports.ordinary_solar_radiation.take());
    }
    Ok(state)
}

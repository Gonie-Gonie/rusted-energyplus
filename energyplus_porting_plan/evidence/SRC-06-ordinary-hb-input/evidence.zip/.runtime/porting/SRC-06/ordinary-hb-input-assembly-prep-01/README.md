# HELD minimal ordinary heat-balance input assembly

Source only, based on clean pushed `6d1b2e248a568dc63acb37d8a0b545efc4849364`.
No canonical file, compiler, formatter, Cargo, Native engine, target or gate was changed by this packet.
Root must review and apply before any QA result can exist. All execution results remain pending.

## Actual consumed route

The existing ordinary CLI caller retains its same InputProcessor/unused set, shared shortcut,
preScan, live OutputProcessor time bindings, Project/global/Space controls, EIO and weather session.
Raw HB/Material projections carry values, loader origin and physical IDF field counts only;
they do not perform getter queries, erase unused inputs or clone a schema owner.

The source-context weather prepare reaches the actual zero-object WeatherStation producer
and EIO before existing ordinary GetNextEnvironment. The initializer then invokes actual
ProjectControl → SiteAtmosphere → Spectral/Material/Hysteresis/FrameDivider → regular
Construction → Shadowing → Zone/implicit Space input operations before existing geometry.
These are selected consumed input operations, not complete GetHeatBalanceInput or SetupSimulation.

ProjectControl borrows the sole early Space controls rather than retaining duplicate booleans.
Material reuses existing typed material/property storage; no second thermal property or CTF calculation.
Construction retains actual input order and usage flags. Selected geometry assigns IsUsed,
then actual opaque CTF assignment traversals assign IsUsedCTF. The existing surface/zone physical
geometry returns run once. Zone centroid uses literal SurfaceGeometry557–597 zero reset,
Space/class order, GrossArea products and guarded coordinate divisions from those surface returns.
The same returned ceiling height, volume and floor area are retained. Zone min/max writes,
full raw SurfaceTmp lifecycle and the rest of SetupZoneGeometry remain incomplete.

MINREPORTFREQUENCY and clipping settings are acquired once at the real early selected
processEnvironmentVariables boundary; the same ProjectSystemVariables are borrowed later.
The Output getter uses local four-alpha/one-numeric arrays, exact unused identities and
flag-before-getter/partial ReqVar retention. It does not mutate IPShortCut scratch.
No-bracket variable names retain trailing whitespace; bracket stripping trims only the six
Source ASCII whitespace characters. ThisOneOnTheList borrows the actual sole preScan.

The MTD host retains a chosen path and real File outside Clone reports, opens only at
InitializeOutput, and flushes only a reached stream after diagnostic/EIO prefix persistence.
Actual first-registration owners and four unmatched Zone dictionary/setup/total writes execute.
Requested report-dictionary/OutVar writers, RE2 keys, nonblank schedule and nonempty minimum
frequency branches remain explicit unavailable after their genuine reached prefixes.
This packet does not claim an unmatched Zone output variable has a retained OutVar binding.

On failure, input/global/Zone/Material/Shadow owners and real output prefixes stay on reports.
Only after all fallible initializer operations succeed are the sole globals and Zone owners
moved into HeatBalanceState. Material input/getter state remains retained on reports.
Legacy None/manual/diagnostic initializer routes and current CTF/LU/Solar numerical producers
remain intact. No deferred InitHB initializer or speculative dispatcher/cadence flags are copied.

## Existing test coverage and later validation

No test body or binary is added. Existing raw admission helper checks HB/Material raw custody
without unused erasure. The existing report-context test includes one local Output getter table:
success/bracket-vs-no-bracket behavior, regex partial push, and minimum-frequency pre-query stop.
Compiler report bodies retain current Source-origin tests and gain actual Output:Variable
IDF ordering/default/physical-alpha checks. Existing weather constructor coverage is extended.
The existing ordinary CLI checks actual ordered Station/Building/Site/Shadow EIO and reached
empty MTD. Existing direct-CTF test constructors supply an empty new output input vector.

Root should run one fmt/quality/all-target Clippy and the finite existing focused selections
in validation-plan.json, with the ordinary CLI normal and actual CI=Y variants.
No new Native execution or full-workspace duplicate is required for this Source-input slice.

## Limits preserved

Full SetupSimulation kickoff/DesignDay HB orchestration, full GetSurfaceData/geometry owner
lifecycle, GetHeatBalanceInput suffix/final fatal, exact InitHB timing, interior radiation,
inside solver/dispatcher cadence and HVAC remain incomplete. Current eager weather allocation
and current eager CTF initialization are explicitly retained limitations. Positive unsupported
families/fields are not widened, no Native endpoints enter production, and no scientific or
whole-startup PASS is asserted. All four SRC06 gates and plan counters remain unchanged.

## Finite provenance

manifest.json records every exact current base, full proposal and direct diff. Reused held
parents are finite metadata references; exact copied payloads are distinguished from narrow
merges by whole-byte/LF-normalized correspondence. Root's actual five-file pre-weather
continuation is preserved in the two overlapping context/output files. Original literal
ranges retain exact Git or explicitly qualified bundled-local custody and are reused directly; no giant Native raw, binary, full Source clone,
recursive provenance closure or invented future receipt is included.

//! Extend the existing raw-admission regression at the shared runtime boundary.
use super::*;
use ep_raw_model::parse_epjson_str;
use ep_runtime::heat_balance::ctf_initialization_context::CtfInitializationReports;
use ep_runtime::heat_balance::selected_input_processor::{
    SelectedInputUnavailable, SourceArgumentCounts, SourceObjectDefinition,
};

pub(crate) fn verify_shared_input_boundary() -> Result<(), Box<dyn std::error::Error>> {
    let base = r#""Version":{"v":{"version_identifier":"26.1"}},"Building":{"b":{"solar_distribution":"MinimalShadowing"}},"Timestep":{"t":{"number_of_timesteps_per_hour":4}},"Zone":{"actual zone":{}}"#;
    let diagnostics = r#", "Output:Diagnostics":{"d":{"diagnostics":[{"key":"DisplayAdvancedReportVariables"},{"key":"DisplayAdvancedReportVariables"},{"key":"DisplayAdvancedReportVariables"},{"key":"DisplayAdvancedReportVariables"},{"key":"DisplayAdvancedReportVariables"}]}},"Schedule:Constant":{}"#;
    let raw = parse_epjson_str(&format!("{{{base}{diagnostics}}}"))?;
    let input = resolve(&raw)?;
    assert_eq!(input.get_num_objects_found("zone"), 1);
    assert_eq!(input.get_num_objects_found("Unknown:Count"), 0);
    assert!(input.family("Sizing:Zone").is_none());
    assert_eq!(input.get_num_objects_found("Sizing:Zone"), 0);
    assert!(
        input.family("Sizing:Zone").is_none(),
        "count must not insert"
    );
    assert_eq!(
        input.family("Schedule:Constant"),
        Some(&SourceInputFamily::Objects(vec![]))
    );
    let Some(SourceInputFamily::Objects(shapes)) = input.family("Output:Diagnostics") else {
        return Err("actual diagnostic family shapes missing".into());
    };
    assert_eq!(shapes[0].field_sizes["diagnostics"], 5);
    assert_eq!(shapes[0].object_name, "d");
    assert!(input.has_object("Output:Diagnostics", "d"));
    assert!(input.is_object_unused("Output:Diagnostics", "d"));
    assert!(!input.has_object("Output:Diagnostics", "D"));
    let hb = crate::ordinary_heat_balance_input::resolve(&raw, &input)?;
    assert!(hb.source_is_epjson);
    assert_eq!(hb.objects["Building"][0].object_name, "b");
    assert_eq!(hb.objects["Zone"][0].object_name, "actual zone");
    assert_eq!(hb.objects["Building"][0].idf_max_fields, None);
    assert!(hb.objects["Construction"].is_empty());
    let material = crate::ordinary_material_input::resolve(&raw, &input)?;
    assert!(material.source_is_epjson);
    assert!(material.regular.is_empty() && material.no_mass.is_empty());
    assert!(input.is_object_unused("Building", "b"),
        "raw custody must not masquerade as a reached getter");
    assert!(input.is_object_unused("Zone", "actual zone"));
    let initial_counts = SourceArgumentCounts {
        alphas: 5,
        numerics: 9,
    };
    assert_eq!(input.get_max_schema_args()?, initial_counts);

    let mut reports = CtfInitializationReports::default();
    reports.input_processor_shortcut.current_module_object = "retained caller".into();
    reports.initialize_input_processor(input)?;
    let scratch = &reports.input_processor_shortcut;
    assert_eq!(scratch.current_module_object, "retained caller");
    for array in [&scratch.alpha_args, &scratch.alpha_field_names] {
        assert_eq!(array.len(), initial_counts.alphas);
        assert!(array.iter().all(String::is_empty));
    }
    assert_eq!(scratch.numeric_args.len(), initial_counts.numerics);
    assert!(
        scratch
            .numeric_args
            .iter()
            .all(|value| value.to_bits() == 0)
    );
    assert_eq!(scratch.numeric_field_names.len(), initial_counts.numerics);
    assert!(scratch.numeric_field_names.iter().all(String::is_empty));
    assert_eq!(
        scratch.alpha_field_blanks,
        vec![false; initial_counts.alphas]
    );
    assert_eq!(
        scratch.numeric_field_blanks,
        vec![false; initial_counts.numerics]
    );

    let Some(input) = reports.selected_input_processor.as_mut() else {
        return Err("actual caller lost moved input".into());
    };
    let sizing_counts = SourceArgumentCounts {
        alphas: 16,
        numerics: 23,
    };
    assert_eq!(input.get_object_def_max_args("sIzInG:zOnE")?, sizing_counts);
    assert_eq!(input.family("Sizing:Zone"), Some(&SourceInputFamily::Null));
    assert_eq!(input.get_num_objects_found("Sizing:Zone"), 0);
    assert_eq!(input.get_max_schema_args()?, sizing_counts);
    assert_eq!(
        reports.input_processor_shortcut.alpha_args.len(),
        5,
        "later null insertion must not resize the already allocated shared arrays"
    );
    assert!(matches!(
        input.get_object_def_max_args("Unknown:Definition"),
        Err(SelectedInputUnavailable::Definition(_))
    ));
    assert!(input.family("Unknown:Definition").is_none());

    for addition in [r#", "Unrepresented:Empty":{}"#, r#", "Branch":{"b":{}}"#] {
        assert!(resolve(&parse_epjson_str(&format!("{{{base}{addition}}}"))?).is_err());
    }
    let previous_scratch = reports.input_processor_shortcut.clone();
    let oversized = SelectedInputProcessor::from_admitted_input(
        vec![SourceObjectDefinition {
            object_type: "oversized".into(),
            alpha_fields: usize::MAX,
            numeric_fields: 1,
            alpha_extensions: 0,
            numeric_extensions: 0,
            extension: None,
        }],
        BTreeMap::from([("oversized".into(), SourceInputFamily::Objects(vec![]))]),
    )?;
    assert_eq!(
        reports.initialize_input_processor(oversized),
        Err(SelectedInputUnavailable::Size)
    );
    assert_eq!(reports.input_processor_shortcut, previous_scratch);
    assert!(
        reports
            .selected_input_processor
            .as_ref()
            .is_some_and(|input| input.family("oversized").is_some()),
        "input must remain retained when allocation sizing stops"
    );
    // Direct-JSON pre-scan keeps lexical spelling separately from getter alphas.
    let raw = parse_epjson_str(&format!(
        r#"{{{base},"Output:Variable":{{
        "z":{{"variable_name":"case var [W]","key_value":"key"}},
        "a":{{"variable_name":"CaSe VaR  ","key_value":"KeY"}},
        "b":{{"variable_name":"CASE VAR","key_value":"*"}},
        "c":{{"variable_name":"Tabbed\t  ","key_value":"  "}},
        "d":{{"variable_name":"Fallback","key_value":""}}
    }},"Output:Table:SummaryReports":{{"s":{{"reports":[{{"report_name":"AllSummary"}}]}}}}}}"#
    ))?;
    let projection = resolve_reporting_prescan(&raw)?;
    assert_eq!(
        projection
            .variables
            .iter()
            .map(|row| row.object_name.as_str())
            .collect::<Vec<_>>(),
        ["a", "b", "c", "d", "z"]
    );
    assert_eq!(projection.variables[0].variable_name, "CaSe VaR  ");
    assert_eq!(projection.variables[2].key, "  ");
    assert_eq!(projection.variables[4].variable_name, "case var [W]");
    let input = resolve(&raw)?;
    let unused = input.clone();
    let mut outputs = crate::ctf_initialization_outputs::CtfRunOutputs::new("26.1");
    let mut context = outputs.context();
    context.reports.initialize_input_processor(input)?;
    context.reports.reporting_prescan_input = Some(projection.clone());
    context.backend.state.doing_input_processing = true;
    let scratch = context.reports.input_processor_shortcut.clone();
    context.post_input_processing()?;
    assert!(!context.backend.state.doing_input_processing);
    let mut expected_scratch = scratch;
    expected_scratch.current_module_object = "Output:PreprocessorMessage".into();
    assert_eq!(context.reports.input_processor_shortcut, expected_scratch);
    assert_eq!(
        context.reports.selected_input_processor.as_ref(),
        Some(&unused)
    );
    let prescan = &context.reports.output_prescan;
    assert_eq!(prescan.max_considered_output_variables, 10000);
    assert_eq!(prescan.num_considered_output_variables, 5);
    assert_eq!(prescan.output_variables_for_simulation.len(), 3);
    let keys = &prescan.output_variables_for_simulation["case var"];
    assert_eq!(keys.variable_name, "CaSe VaR");
    assert_eq!(keys.keys.len(), 2);
    assert_eq!(keys.keys["key"].key, "KeY");
    assert_eq!(keys.keys["key"].variable_name, "CaSe VaR");
    assert_eq!(keys.keys["*"].variable_name, "CASE VAR");
    assert!(prescan.find_item("unlisted key", "CASE VAR"));
    assert!(prescan.find_item("  ", "tabbed\t"));
    assert!(!prescan.find_item("", "tabbed\t"));
    assert!(!prescan.find_item("  ", "tabbed"));
    assert!(prescan.find_item("anything", "fallback"));
    assert!(!prescan.find_item("anything", "case var [W]"));
    context.post_input_processing()?;
    assert_eq!(
        context
            .reports
            .output_prescan
            .num_considered_output_variables,
        10
    );
    let retained = context.reports.output_prescan.clone();
    assert!(
        context
            .reports
            .output_prescan
            .add_record("bad.regex", "unreached")
            .is_err()
    );
    assert_eq!(context.reports.output_prescan, retained);
    let mut bad_projection = projection;
    bad_projection.variables[1].key = "bad.regex".into();
    context.reports.reporting_prescan_input = Some(bad_projection);
    assert!(context.post_input_processing().is_err());
    assert_eq!(
        context
            .reports
            .output_prescan
            .num_considered_output_variables,
        11
    );
    assert!(!context.reports.output_prescan.find_item("*", "unreached"));
    assert_eq!(
        context.reports.selected_input_processor.as_ref(),
        Some(&unused)
    );
    Ok(())
}

"""Source-only WIP refinement; preserves initial author bytes in the prep."""
from pathlib import Path
import shutil
ROOT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
HB = 'crates/ep_runtime/src/heat_balance/'
RUN = 'crates/ep_run/src/'

def get(name):
    return (ROOT/'proposed'/name).read_text(encoding='utf-8')
def put(name, text):
    target = ROOT/'proposed'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        archive = ROOT/'initial-author-output'/name
        archive.parent.mkdir(parents=True, exist_ok=True)
        assert not archive.exists(), name
        archive.write_bytes(target.read_bytes())
    elif Path(name).exists():
        before = ROOT/'before'/name
        before.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(Path(name).read_bytes())
    target.write_text(text, encoding='utf-8', newline='\n')
def change(name, old, new):
    value = get(name)
    assert value.count(old) == 1, (name, old[:90], value.count(old))
    put(name, value.replace(old, new, 1))

name = HB+'selected_material_data.rs'
change(name, '        let globals = reports.selected_heat_balance_globals.as_ref()\n            .ok_or_else(|| unavailable("missing actual early globals"))?;\n', '')

# Full current compiler behavior/tests stay authoritative. Add only the new
# Output:Variable projection and the reviewed existing-body assertions.
name = 'crates/ep_compiler/src/compiler/report_inputs.rs'
old = get(name)
current = Path(name).read_text(encoding='utf-8')
a = old.index('    fn parse_output_variable_inputs')
b = old.index('    pub(super) fn parse_report_inputs', a)
projection = old[a:b]
marker = '    pub(super) fn parse_report_inputs'
assert current.count(marker) == 1
current = current.replace(marker, projection+marker, 1)
current = current.replace('        self.parse_predefined_table_sizing(model);\n', '        self.parse_predefined_table_sizing(model);\n        self.parse_output_variable_inputs(model);\n', 1)
old_json = 'r#"{"Output:VariableDictionary":{"dictionary":{"key_field":"IDF"}},"Output:Surfaces:Drawing":{"drawing":{"report_type":"dxf:wireframe"}},"Output:Constructions":{"ctf":{"details_type_1":"Constructions"}}}"#'
new_json = 'r#"{"Output:VariableDictionary":{"dictionary":{"key_field":"IDF"}},"Output:Surfaces:Drawing":{"drawing":{"report_type":"dxf:wireframe"}},"Output:Constructions":{"ctf":{"details_type_1":"Constructions"}},"Output:Variable":{"a":{"variable_name":"Zone Mean Air Temperature"},"b":{"key_value":"MiXeD","variable_name":"Other Equipment Radiant Heating Rate [W]","reporting_frequency":"Daily","schedule_name":""}}}"#'
assert old_json in current
current = current.replace(old_json, new_json, 1)
a = old.index('        let variables = &model.report_inputs.output_variables;')
b = old.index('        Ok(())', a)
assert '        assert_eq!(model.report_inputs.objects[2].alphas[0], "CONSTRUCTIONS");\n' in current
current = current.replace('        assert_eq!(model.report_inputs.objects[2].alphas[0], "CONSTRUCTIONS");\n', '        assert_eq!(model.report_inputs.objects[2].alphas[0], "CONSTRUCTIONS");\n'+old[a:b], 1)
a = old.index('        // Eleven generated unnamed identities')
b = old.index('        Ok(())', a)
close = current.rindex('        Ok(())')
current = current[:close]+old[a:b]+current[close:]
put(name, current)

name = HB+'source_output_registration.rs'
value = get(name).replace('//! Reached OutputProcessor registration storage;', '// Reached OutputProcessor registration storage;').replace('//! Original OutputProcessor.cc139-193', '// Original OutputProcessor.cc139-193')
value = value.replace('pub(crate) struct SourceRealRegistrationPrefix {\n    pub(crate) dd_var_num: usize,\n    pub(crate) request_indexes: Vec<usize>,\n    pub(crate) this_one_on_the_list: bool,\n}\n\n', '')
value = value.replace(') -> Result<SourceRealRegistrationPrefix, OrdinaryRadiationError> {', ') -> Result<bool, OrdinaryRadiationError> {')
value = value.replace('let dd_var_num = self.add_dictionary_variable(declaration);', 'self.add_dictionary_variable(declaration);')
value = value.replace('Ok(SourceRealRegistrationPrefix { dd_var_num, request_indexes, this_one_on_the_list })', 'Ok(this_one_on_the_list)')
value = value.replace('if prefix.this_one_on_the_list {', 'if prefix {')
put(name, value)

name = 'crates/ep_runtime/src/runtime.rs'
value = get(name)
a = value.index('        if let (Some(host), Some(actual), HeatBalanceWeatherDriver::Production(weather)) =')
b = value.index('\n    }\n    let initial_dry_bulb_c', a)
value = value[:a]+'''        match (source_output_host.is_some(), driver) {
            (true, HeatBalanceWeatherDriver::Production(weather)) => {
                let actual = initialization.as_deref_mut().ok_or_else(|| RuntimeError::WarmupUnavailable {
                    reason: "source weather input requires actual initialization owners".into() })?;
                weather.prepare_initial_phase_with_source_context(initial_phase, actual)?;
            }
            (true, _) => return Err(RuntimeError::WarmupUnavailable {
                reason: "source HB input requires the actual production weather session".into() }),
            (false, _) => driver.prepare_initial_phase(initial_phase)?,
        }'''+value[b:]
a = value.index('                let mut initialize = |source|')
b = value.index('\n            } else {\n                initialize_heat_balance_state_with_ctf_coefficients', a)
value = value[:a]+'''                match (source_output_host.as_deref_mut(), weather_driver) {
                    (Some(host), Some(HeatBalanceWeatherDriver::Production(weather))) =>
                        weather.with_source_environment_mut(|environment, minutes|
                            initialize_heat_balance_state_with_initialization_context_and_equipment_profiled(
                                model, options.initial_zone_air_temperature_c, ctf_coefficients,
                                &schedule_cache, &mut schedule_cache_profile, context,
                                crate::heat_balance::initialization::OrdinaryInitializationInputs {
                                    equipment: equipment_input, radiation: radiation_input,
                                    source: Some(crate::heat_balance::initialization::SourceHeatBalanceInputOwners {
                                        environment, minutes, output_host: host,
                                    }),
                                }))?,
                    (Some(_), _) => return Err(RuntimeError::WarmupUnavailable {
                        reason: "source HB input requires the actual production weather session".into() }),
                    (None, _) => initialize_heat_balance_state_with_initialization_context_and_equipment_profiled(
                        model, options.initial_zone_air_temperature_c, ctf_coefficients,
                        &schedule_cache, &mut schedule_cache_profile, context,
                        crate::heat_balance::initialization::OrdinaryInitializationInputs {
                            equipment: equipment_input, radiation: radiation_input, source: None,
                        })?,
                }'''+value[b:]
put(name, value)

# Preserve reached geometry even if existing CTF/Solar subsequently fails. The
# actual opaque return is computed once and reused by State initialization.
name = HB+'initialization.rs'
value = get(name)
a = value.index('    if source_input_reached {\n        let actual_surface_geometry = surfaces.iter()')
b = value.index('    if let Some(input) = radiation_input {', a)
block = value[a:b]
body = block[len('    if source_input_reached {\n'):-len('    }\n')]
body = body.replace('let actual_surface_geometry = surfaces.iter().map(|surface| (surface.surface_id, surface.geometry)).collect::<Vec<_>>();', '''let data = admitted_surface_data.as_ref().ok_or_else(|| RuntimeError::WarmupUnavailable {
            reason: "source Zone geometry requires actual admitted surface returns".into() })?;
        let actual_surface_geometry = model.typed.surfaces.iter().zip(data)
            .map(|(surface, (geometry, _))| (surface.id, *geometry)).collect::<Vec<_>>();''')
value = value[:a]+value[b:]
mark = '    // Validate actual declared references before selected public generation'
assert value.count(mark) == 1
value = value.replace(mark, '    let selected_opaque_geometry = if source_input_reached {\n'+body+'        Some(geometry)\n    } else { None };\n\n'+mark, 1)
value = value.replace('opaque_setup: opaque_geometry_owners(&model.typed, &actual_surface_geometry),', 'opaque_setup: selected_opaque_geometry.unwrap_or_else(|| opaque_geometry_owners(&model.typed, &actual_surface_geometry)),')
put(name, value)

name = RUN+'ctf_initialization_outputs.rs'
value = get(name)
flush = '        if let Some(host) = self.mtd.as_mut() { host.flush_reached().map_err(|error| error.to_string())?; }\n'
assert value.count(flush) == 1
value = value.replace(flush, '')
anchor = '        if let Some(files) = self.initialization_files.as_mut() {\n            files.flush_reached().map_err(|e| e.to_string())?;\n        }\n'
assert value.count(anchor) == 1
value = value.replace(anchor, anchor+flush, 1)
put(name, value)

# Existing direct/legacy Solar test inputs explicitly keep the legacy route.
name = 'crates/ep_runtime/src/runtime/tests/ctf_ordinary_outputs.rs'
value = Path(name).read_text(encoding='utf-8')
assert value.count('                    equipment: None,\n') == 1
value = value.replace('                    equipment: None,\n', '                    equipment: None,\n                    source: None,\n', 1)
put(name, value)

# The existing CLI body proves the newly consumed real prefix without another
# engine test body. Existing output expectations gain only reached MTD.
name = 'crates/ep_run/tests/arbitrary_run/output_manifest.rs'
value = Path(name).read_text(encoding='utf-8')
value = value.replace('["eplusrs.audit", "eplusrs.bnd", "eplusrs.eso", "eplusrs.mtr"]', '["eplusrs.audit", "eplusrs.bnd", "eplusrs.eso", "eplusrs.mtr", "eplusrs.mtd"]')
put(name, value)
name = 'crates/ep_run/tests/arbitrary_run.rs'
value = Path(name).read_text(encoding='utf-8')
anchor = '    assert!(eio.starts_with("Program Version,"));\n'
assert value.count(anchor) == 1
value = value.replace(anchor, anchor+'''    let sections = ["! <Weather Station>", "! <Building Information>",
        "! <Site:HeightVariation>", "! <Shadowing/Sun Position Calculations Annual Simulations>"];
    let mut offset = 0;
    for section in sections {
        let relative = eio[offset..].find(section).ok_or_else(|| format!("missing reached EIO section {section}"))?;
        offset += relative + section.len();
    }
    assert!(std::fs::read(output_dir.join("eplusrs.mtd"))?.is_empty(),
        "actual InitializeOutput opens MTD without fabricated unmatched-variable records");
''',1)
put(name, value)
print('Refined held WIP; no canonical, compiler or targets executed.')

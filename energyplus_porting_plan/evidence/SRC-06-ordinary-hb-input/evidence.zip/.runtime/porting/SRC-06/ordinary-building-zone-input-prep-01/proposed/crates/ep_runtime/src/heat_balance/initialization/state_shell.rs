//! Final assembly of initialized heat-balance state and cache diagnostics.

use crate::heat_balance::state::{
    HeatBalanceState, HeatBalanceSurfaceIndexes, SurfaceHeatBalanceState, ZoneHeatBalanceState,
};
use crate::heat_balance::surface_manager::ConstructionThermalDataCache;

pub(super) fn finish_heat_balance_state(
    zones: Vec<ZoneHeatBalanceState>,
    initialized_geometry: crate::geometry::InitializedGeometryOwners,
    surfaces: Vec<SurfaceHeatBalanceState>,
    surface_indexes: HeatBalanceSurfaceIndexes,
    construction_thermal_data: Option<ConstructionThermalDataCache>,
    ctf_surface_lifecycle: Option<super::super::ctf_surface_lifecycle::CtfSurfaceLifecycle>,
) -> HeatBalanceState {
    let mut state = HeatBalanceState {
        timestep_index: 0,
        zones,
        initialized_geometry,
        warmup_convergence: None,
        ordinary_inside_temperatures: None,
        ordinary_equipment: None,
        construction_input_properties: Vec::new(),
        selected_heat_balance_initialization: None,
        selected_zone_input: None,
        selected_internal_heat_gains: Default::default(),
        selected_heat_balance_globals: Default::default(),
        selected_surface_initialization: Default::default(),
        selected_inside_convection: None,
        empty_internal_gain_providers: None,
        selected_daylighting: None,
        ordinary_solar_radiation: None,
        zone_air_environment_guard: Default::default(),
        surfaces,
        surface_indexes,
        construction_cache_hash: 0,
        construction_ctf01_layers: Vec::new(), construction_ctf02_coefficients: Vec::new(),
        construction_ctf03_initial: Vec::new(), construction_ctf04_first_assembly: Vec::new(),
        construction_ctf06_first_exponential: Vec::new(), construction_ctf05_first_inverse: Vec::new(),
        construction_ctf07_first_gammas: Vec::new(), construction_ctf08_first_private_coefficients: Vec::new(),
        construction_ctf09_retry_driver: Vec::new(), construction_ctf10_public_initialization: None,
        ctf_surface_lifecycle,
        ctf_history_caller_clock: Default::default(),
        construction_cache_build_wall_seconds: 0.0,
        construction_cache_entry_count: 0, construction_cache_no_mass_count: 0,
        construction_cache_massive_ctf_count: 0, construction_cache_eio_seeded_count: 0,
        construction_cache_rust_generated_count: 0,
        variable_system_timestep_placeholder: true,
        hvac_iteration_count: 0,
        plant_iteration_count: 0,
        last_ctf_history_slot_terms: Vec::new(),
        last_ctf_history_slot_terms_after_advance: Vec::new(),
        last_inside_surface_iteration_count: 0,
        last_inside_surface_iteration_max_delta_c: f64::NAN,
        last_inside_surface_iteration_max_delta_surface_name: None,
    };
    if let Some(cache) = construction_thermal_data { install_ctf_metadata(&mut state, cache); }
    state
}

pub(crate) fn install_ctf_metadata(state: &mut HeatBalanceState, mut construction_thermal_data: ConstructionThermalDataCache) {
    state.construction_cache_hash = construction_thermal_data.coefficient_cache_hash;
    state.construction_ctf01_layers = construction_thermal_data.layer_preprocessing();
    state.construction_ctf02_coefficients = construction_thermal_data.all_resistive_coefficients();
    state.construction_ctf03_initial = construction_thermal_data.initial_discretizations();
    state.construction_ctf04_first_assembly = construction_thermal_data.first_assemblies();
    state.construction_ctf06_first_exponential = construction_thermal_data.first_exponentials();
    state.construction_ctf05_first_inverse = construction_thermal_data.first_inverses();
    state.construction_ctf07_first_gammas = construction_thermal_data.first_gammas();
    state.construction_ctf08_first_private_coefficients = construction_thermal_data
            .first_private_coefficients();
    state.construction_ctf09_retry_driver = construction_thermal_data.take_retry_initializations();
    state.construction_ctf10_public_initialization = construction_thermal_data
            .take_public_initialization();
    state.construction_cache_build_wall_seconds = construction_thermal_data.build_wall_seconds;
    state.construction_cache_entry_count = construction_thermal_data.len();
    state.construction_cache_no_mass_count = construction_thermal_data.no_mass_construction_ids.len();
    state.construction_cache_massive_ctf_count = construction_thermal_data
            .massive_ctf_construction_ids
            .len();
    state.construction_cache_eio_seeded_count = construction_thermal_data.eio_seeded_count();
    state.construction_cache_rust_generated_count = construction_thermal_data.rust_generated_count();
}

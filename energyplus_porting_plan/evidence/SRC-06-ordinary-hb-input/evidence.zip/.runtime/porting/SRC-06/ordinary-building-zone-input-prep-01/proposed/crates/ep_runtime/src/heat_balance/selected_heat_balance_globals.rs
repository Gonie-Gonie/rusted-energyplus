//! Actual selected DataGlobal/HybridModel constructor owners.
//!
//! Input DoZoneSizing/DoSystemSizing are separate owners. No input switch,
//! weather clock, allocation count or observed fixture sets these fields.

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedHeatBalanceGlobals {
    /// DataGlobals.hh109-111 constructor0; written by actual Zone/Space getters.
    pub(crate) num_of_zones: i32,
    pub(crate) num_spaces: i32,
    pub(crate) num_space_types: i32,
    /// DataGlobals.hh124; actual GetProjectData may later set it true.
    pub(crate) do_pure_load_calc: bool,
    /// DataGlobals.hh180, actual isInputObjectUsed DOAS count writer.
    pub(crate) air_loop_hvac_doas_used_in_sim: bool,
    /// DataGlobals.hh149, actual repeated CheckIfAnyEMS writer.
    pub(crate) any_energy_management_system_in_model: bool,
    /// DataGlobals.hh155, actual CheckIfAnyPlant writer.
    pub(crate) any_plant_in_model: bool,
    /// DataGlobals.hh162, actual CheckIfAnySlabs writer.
    pub(crate) any_slabs_in_model: bool,
    /// DataGlobals.hh163, actual CheckIfAnyBasements writer.
    pub(crate) any_basements_in_model: bool,
    /// DataGlobals.hh156, actual ideal-condenser setpoint count writer.
    pub(crate) any_ideal_cond_ent_setpoint_in_model: bool,
    /// DataGlobals.hh117; written by the real sizing caller, not DoZoneSizing.
    pub(crate) zone_sizing_calculation: bool,
    /// DataGlobals.hh118; written by the real sizing caller, not DoSystemSizing.
    pub(crate) system_sizing_calculation: bool,
    /// DataGlobals.hh129; SimulationManager233/240 is the actual caller writer.
    pub(crate) doing_sizing: bool,
    /// DataGlobals.hh158 and160, independently retained constructor members.
    pub(crate) component_load_report_requested: bool,
    pub(crate) load_component_pulse_now: bool,
    /// HybridModel.hh126; the admitted input excludes its positive getter.
    pub(crate) hybrid_model_people_count: bool,
}

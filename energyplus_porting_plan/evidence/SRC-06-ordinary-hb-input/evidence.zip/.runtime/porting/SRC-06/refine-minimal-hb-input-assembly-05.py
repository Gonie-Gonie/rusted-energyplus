"""Finite Source-only review corrections and existing-body coverage, no targets."""
from pathlib import Path

ROOT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
HB = 'crates/ep_runtime/src/heat_balance/'
def get(name):
    path = ROOT/'proposed'/name
    return (path if path.exists() else Path(name)).read_text(encoding='utf-8')
def put(name, value):
    path = ROOT/'proposed'/name
    if path.exists():
        archive = ROOT/'review-refinement-04'/name
        archive.parent.mkdir(parents=True, exist_ok=True)
        if not archive.exists():
            archive.write_bytes(path.read_bytes())
    else:
        before = ROOT/'before'/name
        before.parent.mkdir(parents=True, exist_ok=True)
        assert not before.exists(), name
        before.write_bytes(Path(name).read_bytes())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding='utf-8', newline='\n')
def change(name, old, new):
    value = get(name)
    assert value.count(old) == 1, (name, old[:90], value.count(old))
    put(name, value.replace(old, new, 1))

name = 'crates/ep_run/tests/arbitrary_run.rs'
value = get(name).replace('! <Weather Station>', '! <Environment:Weather Station>')
value = value.replace('! <Site:HeightVariation>', '! <Environment:Site Atmospheric Variation>')
put(name, value)

# DataSystemVariables292 acquires the setting at the real early process boundary;
# OutputProcessor473 subsequently reads this sole retained string, never the OS.
name = HB+'selected_project_data.rs'
change(name, '    pub(crate) minimal_shadowing: bool,\n',
    '    pub(crate) minimal_shadowing: bool,\n    pub(crate) minimum_report_frequency: String,\n')
name = HB+'selected_project_data/environment.rs'
change(name, '        update("DeveloperFlag", &mut self.system.developer_flag)?;',
    '''        let minimum_report_frequency = get("MINREPORTFREQUENCY")?;
        if !minimum_report_frequency.is_empty() {
            self.system.minimum_report_frequency = minimum_report_frequency;
        }
        update("DeveloperFlag", &mut self.system.developer_flag)?;''')
name = HB+'source_output_registration/host.rs'
put(name, '''//! Sole actual MTD stream; process settings remain on their real shared owner.
use super::SourceOutputFileHost;
use std::fs::{File, OpenOptions};
use std::io;
use std::path::PathBuf;

/// Sole real MTD stream for the reached OutputProcessor initialization.
#[derive(Debug)]
pub struct SourceMtdFileHost {
    path: PathBuf,
    file: Option<File>,
}
impl SourceMtdFileHost {
    /// Retain the caller's chosen path without opening an unreached file.
    pub fn new(path: impl Into<PathBuf>) -> Self {
        Self { path: path.into(), file: None }
    }
    /// Flush an actually opened MTD without opening an unreached file.
    ///
    /// # Errors
    /// Returns the actual retained stream's OS error.
    pub fn flush_reached(&mut self) -> io::Result<()> {
        use std::io::Write;
        if let Some(file) = &mut self.file { file.flush()?; }
        Ok(())
    }
}
impl SourceOutputFileHost for SourceMtdFileHost {
    fn ensure_mtd_open(&mut self) -> io::Result<()> {
        if self.file.is_none() {
            self.file = Some(OpenOptions::new().read(true).write(true).create(true)
                .truncate(true).open(&self.path)?);
        }
        Ok(())
    }
}
''')
name = HB+'source_output_registration.rs'
change(name, '    fn minimum_report_frequency(&self) -> &str;\n', '')
name = HB+'source_output_registration/requested_input.rs'
value = get(name)
value = value.replace("    processor: &'a mut SelectedInputProcessor,\n", "    processor: &'a mut SelectedInputProcessor,\n    minimum_report_frequency: &'a str,\n")
value = value.replace("pub(crate) fn new(reports: &'a ReportInputs, processor: &'a mut SelectedInputProcessor) -> Self {\n        Self { reports, processor }", "pub(crate) fn new(reports: &'a ReportInputs, processor: &'a mut SelectedInputProcessor,\n        minimum_report_frequency: &'a str) -> Self {\n        Self { reports, processor, minimum_report_frequency }")
value = value.replace('host: &impl SourceOutputFileHost, _eio:', '_host: &impl SourceOutputFileHost, _eio:')
value = value.replace('if !host.minimum_report_frequency().is_empty()', 'if !input.minimum_report_frequency.is_empty()')
value = value.replace('Actual system MinReportFrequency is retained on its sole host.', 'Actual system MinReportFrequency is borrowed from its sole early owner.')
put(name, value)
name = HB+'selected_heat_balance_input/zone.rs'
value = get(name).replace('    fn minimum_report_frequency(&self) -> &str { self.0.minimum_report_frequency() }\n', '')
value = value.replace("    pub(crate) report_input: &'a ReportInputs,\n", "    pub(crate) report_input: &'a ReportInputs,\n    pub(crate) minimum_report_frequency: &'a str,\n")
value = value.replace('SourceReportVariableInput::new(owners.report_input, &mut *owners.input)',
    'SourceReportVariableInput::new(owners.report_input, &mut *owners.input, owners.minimum_report_frequency)')
put(name, value)
name = HB+'ctf_initialization_context.rs'
change(name, '            report_input: &model.report_inputs, minutes_in_time_step, host, eio: self.eio };',
    '''            report_input: &model.report_inputs,
            minimum_report_frequency: &reports.selected_project_data.as_ref()
                .ok_or_else(|| hb_input_error(E::Unavailable("missing sole system variables")))?.system.minimum_report_frequency,
            minutes_in_time_step, host, eio: self.eio };''')
name = 'crates/ep_run/src/ctf_initialization_outputs.rs'
change(name, '''self.mtd = Some(ep_runtime::heat_balance::source_output_registration::SourceMtdFileHost::from_process_environment(
                output_dir.join("eplusrs.mtd")).map_err(|error| error.to_string())?);''',
    '''self.mtd = Some(ep_runtime::heat_balance::source_output_registration::SourceMtdFileHost::new(
                output_dir.join("eplusrs.mtd")));''')

# Keep all existing explicit ReportInputs constructors valid; no new test bodies.
for name in [HB+'ctf_geometry_reports_tests.rs', HB+'ctf_direct_initialization_tests.rs']:
    value = get(name)
    assert value.count('        legacy_variable_dictionary_sections: -1,\n') == 1
    value = value.replace('        legacy_variable_dictionary_sections: -1,\n',
        '        legacy_variable_dictionary_sections: -1,\n        output_variables: Vec::new(),\n', 1)
    put(name, value)

# Extend an existing conventional context test with one finite getter/retention
# table. Inputs below are authored unit operands, not Native endpoint fixtures.
name = HB+'ctf_geometry_reports_tests.rs'
value = get(name)
anchor = '    assert_eq!(context.backend.state.tracking.total_warning_errors, 0);\n    Ok(())\n}'
assert value.count(anchor) == 1
table = r'''
    use crate::heat_balance::source_output_registration::{SourceOutputFileHost,
        SourceOutputRegistration, SourceOutputUnits, SourceOutputStoreType,
        SourceRealOutputDeclaration, SourceReportVariableInput};
    use crate::heat_balance::source_output_prescan::SourceOutputPreScan;
    struct AuthoredMtd { opens: usize }
    impl SourceOutputFileHost for AuthoredMtd {
        fn ensure_mtd_open(&mut self) -> std::io::Result<()> { self.opens += 1; Ok(()) }
    }
    for (minimum, regex, expected_requests, used) in [
        ("", false, 2, true), ("", true, 1, true), ("Daily", false, 0, false),
    ] {
        let input = ReportInputs { output_variables: [
            ("first", if regex { "bad.regex" } else { "*" }, "BRACKET \t [W]"),
            ("second", "MiXeD", "NO BRACKET \t "),
        ].into_iter().map(|(identity, key, name)| ep_model::SourceOutputVariableInput {
            object_name: identity.into(), key: key.into(), variable_name: name.into(),
            reporting_frequency: "Hourly".into(), schedule_name: String::new(),
            alpha_blank: [false, false, true, true], default_applied: [false, false, true, false],
            num_alphas: 2, is_epjson: true,
        }).collect(), ..ReportInputs::default() };
        let mut source = SelectedInputProcessor::from_admitted_input(
            vec![SourceObjectDefinition { object_type: "Output:Variable".into(), alpha_fields: 4,
                numeric_fields: 0, alpha_extensions: 0, numeric_extensions: 0, extension: None }],
            std::collections::BTreeMap::from([("Output:Variable".into(), SourceInputFamily::Objects(
                input.output_variables.iter().map(|row| SourceObjectShape { object_name: row.object_name.clone(),
                    field_sizes: std::collections::BTreeMap::new() }).collect()))]),
        ).map_err(|error| error.to_string())?;
        let scratch = context.reports.input_processor_shortcut.clone();
        let mut output = SourceOutputRegistration::default();
        let mut host = AuthoredMtd { opens: 0 };
        let mut eio = Vec::new();
        let mut operands = SourceReportVariableInput::new(&input, &mut source, minimum);
        let result = output.setup_unmetered_zone_real(&mut operands, &SourceOutputPreScan::default(),
            SourceRealOutputDeclaration { name: "UNMATCHED AUTHORED VARIABLE", key: "ZONE",
                units: SourceOutputUnits::C, store_type: SourceOutputStoreType::Average },
            15, &mut host, &mut eio);
        assert_eq!(result.is_ok(), minimum.is_empty() && !regex);
        assert_eq!(host.opens, 1);
        assert!(output.output_initialized);
        assert!(!output.get_output_input);
        assert_eq!(output.time_step_zone_sec.to_bits(), 900.0_f64.to_bits());
        assert_eq!(output.requested_variables.len(), expected_requests);
        assert_eq!(source.is_object_unused("Output:Variable", "first"), !used);
        assert!(source.is_object_unused("Output:Variable", "second") == (regex || !used));
        assert_eq!(context.reports.input_processor_shortcut, scratch,
            "the real Output getter uses only local 4A/1N argument arrays");
        assert!(eio.is_empty());
        if minimum.is_empty() && !regex {
            assert_eq!(output.requested_variables[0].name, "BRACKET");
            assert_eq!(output.requested_variables[1].name, "NO BRACKET \t ");
            assert!(output.requested_variables[0].key.is_empty());
            assert_eq!(output.requested_variables[1].key, "MiXeD");
            assert_eq!(output.num_real_variables_setup, 1);
            assert_eq!(output.num_total_real_variables, 1);
        } else {
            assert!(output.dictionary_variables.is_empty());
            assert_eq!(output.num_real_variables_setup, 0);
            if regex { assert_eq!(output.requested_variables[0].key, "bad.regex");
                assert!(output.requested_variables[0].name.is_empty()); }
        }
    }
'''
value = value.replace(anchor, '    assert_eq!(context.backend.state.tracking.total_warning_errors, 0);\n'+table+'    Ok(())\n}', 1)
put(name, value)

# Real raw custody projections are exercised in the existing admission helper.
name = 'crates/ep_run/src/ordinary_input_processor_tests.rs'
value = get(name)
anchor = '    let initial_counts = SourceArgumentCounts {\n'
assert value.count(anchor) == 1
addition = '''    let hb = crate::ordinary_heat_balance_input::resolve(&raw, &input)?;
    assert!(hb.source_is_epjson);
    assert_eq!(hb.objects["Building"][0].object_name, "b");
    assert_eq!(hb.objects["Zone"][0].object_name, "actual zone");
    assert_eq!(hb.objects["Building"][0].idf_max_fields, None);
    assert!(hb.objects["Construction"].is_empty());
    let material = crate::ordinary_material_input::resolve(&raw, &input)?;
    assert!(material.source_is_epjson);
    assert!(material.regular.is_empty() && material.no_mass.is_empty());
    assert!(input.is_object_unused("Building", "b"),
        "raw custody must not masquerade as a reached getter");
    assert!(input.is_object_unused("Zone", "actual zone"));
'''
put(name, value.replace(anchor, addition+anchor, 1))
print('Refined HELD only; process setting has one early owner; existing test bodies extended.')

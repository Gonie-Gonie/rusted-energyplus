import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-hb-input-corrections-prep-01'
PARENT = ROOT / '.runtime/porting/SRC-06/ordinary-hb-input-assembly-01/manifest.json'

def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def check(item):
    assert ref(ROOT / item['path']) == item, item['path']

assert not OUT.exists(), 'immutable fresh preparation only'
parent = json.loads(PARENT.read_text(encoding='utf-8'))
assert len(parent['files']) == 45
for row in parent['files']:
    check(row['canonical'])
    check(row['after'])

edits = {
 'crates/ep_compiler/src/compiler/report_inputs.rs': [
    ('mod ctf_report_name_tests {\n    use crate::compile_raw_model;\n    use ep_raw_model::parse_epjson_str;',
     'mod ctf_report_name_tests {\n    use crate::compile_raw_model;\n    use ep_raw_model::{parse_epjson_str, parse_epjson_str_with_idf_order};')],
 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/construction.rs': [
    ('match material.kind {', 'match material.kind() {')],
 'crates/ep_runtime/src/weather_day/production/source_environment.rs': [
    ('fn output_error(error: SurfaceOutdoorInitializationError) -> RuntimeError {\n    match error {\n        SurfaceOutdoorInitializationError::Io(error) => WarmupOutputError::Io(error).into(),\n        SurfaceOutdoorInitializationError::Format(reason) => {\n            WarmupOutputError::Format(reason).into()\n        }\n    }\n}',
     'fn output_error(error: SurfaceOutdoorInitializationError) -> RuntimeError {\n    let output = match error {\n        SurfaceOutdoorInitializationError::Io(error) => WarmupOutputError::Io(error),\n        SurfaceOutdoorInitializationError::Format(reason) => WarmupOutputError::Format(reason),\n    };\n    RuntimeError::WarmupOutput(Box::new(output))\n}')],
 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/shadowing.rs': [
    ('use std::io::Write;\n', '')],
 'crates/ep_runtime/src/heat_balance/report_scan.rs': [
    ('fn last_ordered_options_and_ems_assignments_replace_earlier_values() {\n        let input = ReportInputs {\n            legacy_variable_dictionary_sections: 1,',
     'fn last_ordered_options_and_ems_assignments_replace_earlier_values() {\n        let input = ReportInputs {\n            legacy_variable_dictionary_sections: 1,\n            output_variables: Vec::new(),')],
 'crates/ep_runtime/src/runtime/tests/part03.rs': [
    ('            ],\n            None,\n            None,\n        )?;\n\n        let floor_initial_slots = simulation',
     '            ],\n            None,\n            None,\n            None,\n        )?;\n\n        let floor_initial_slots = simulation')],
}

payloads = {}
inverse = []
for name, replacements in edits.items():
    data = (ROOT / name).read_bytes()
    newline = b'\r\n' if b'\r\n' in data else b'\n'
    after = data
    actual_replacements = []
    for before_text, after_text in replacements:
        before = before_text.encode().replace(b'\n', newline)
        replacement = after_text.encode().replace(b'\n', newline)
        assert after.count(before) == 1, (name, before_text)
        after = after.replace(before, replacement)
        actual_replacements.append((before, replacement))
    restored = after
    for before, replacement in reversed(actual_replacements):
        if replacement:
            assert restored.count(replacement) == 1, name
            restored = restored.replace(replacement, before)
        else:
            assert name.endswith('/shadowing.rs')
            restored = restored.replace(b'use super::super::radiation::ordinary::{OrdinaryRadiationError, OrdinaryRadiationUnavailable};'+newline,
                b'use super::super::radiation::ordinary::{OrdinaryRadiationError, OrdinaryRadiationUnavailable};'+newline+before, 1)
    assert restored == data, name
    assert len(re.findall(rb'#\[test\]', data)) == len(re.findall(rb'#\[test\]', after)), name
    payloads[name] = (data, after)
    inverse.append({'canonical_path': name, 'complete_before_restored_exactly': True, 'literal_edit_count': len(replacements)})

# Finite inventory: all seven runtime ReportInputs literals and all seven
# private simulation calls were located with rg and directly read. These
# snippets are custody, not a substitute for Root's actual compile checks.
inventory = {
 'ReportInputs_literal_inventory': [
    {'path': 'crates/ep_runtime/src/heat_balance/ctf_direct_initialization_tests.rs', 'line_before': 43, 'coverage': 'explicit output_variables already present'},
    {'path': 'crates/ep_runtime/src/heat_balance/ctf_geometry_reports_tests.rs', 'line_before': 291, 'coverage': 'explicit output_variables already present'},
    {'path': 'crates/ep_runtime/src/heat_balance/ctf_geometry_reports_tests.rs', 'line_before': 437, 'coverage': 'actual output_variables plus default remainder'},
    {'path': 'crates/ep_runtime/src/heat_balance/report_scan.rs', 'line_before': 383, 'coverage': 'default remainder'},
    {'path': 'crates/ep_runtime/src/heat_balance/report_scan.rs', 'line_before': 661, 'coverage': 'default remainder'},
    {'path': 'crates/ep_runtime/src/heat_balance/report_scan.rs', 'line_before': 688, 'coverage': 'default remainder'},
    {'path': 'crates/ep_runtime/src/heat_balance/report_scan.rs', 'line_before': 743, 'coverage': 'this correction adds explicit empty output_variables'},
 ],
 'simulation_private_call_inventory': [
    {'path': 'crates/ep_runtime/src/runtime.rs', 'lines_before': [201,277,297,317,339,365], 'coverage': 'all six existing calls already pass nine operands, including final optional SourceMtdFileHost'},
    {'path': 'crates/ep_runtime/src/runtime/tests/part03.rs', 'lines_before': [1087], 'coverage': 'this correction adds ninth None; prior options/CTF operands unchanged'},
 ],
 'other_finite_checks': [
    'Both existing compiler modules using parse_epjson_str_with_idf_order now import it in their own lexical scope.',
    'The single reached material.kind field access is corrected to existing Material::kind(); match branches unchanged.',
    'Both source_environment output-error arms retain the same WarmupOutputError value through the genuine explicit RuntimeError::WarmupOutput(Box). No new From implementation or error swallowing.',
    'Only the one unused Write import is removed; real EIO writes remain on the same borrowed dyn Write.',
 ],
}

OUT.mkdir(parents=True)
rows = []
for name, (before, after) in payloads.items():
    archived = OUT / 'before' / name
    proposed = OUT / 'proposed' / name
    diff = OUT / 'diffs' / (name.replace('/', '__')+'.diff')
    for path in [archived, proposed, diff]:
        path.parent.mkdir(parents=True, exist_ok=True)
    archived.write_bytes(before)
    proposed.write_bytes(after)
    diff.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile=name, tofile=name)).encode())
    rows.append({'canonical_path': name, 'before': ref(archived), 'proposal': ref(proposed), 'complete_diff': ref(diff)})
inventory_path = OUT / 'inventory.json'
inventory_path.write_text(json.dumps(inventory, indent=2)+'\n', encoding='utf-8')
failures = []
for directory in sorted((ROOT / '.runtime/porting/SRC-06').glob('ordinary-hb-input-*-01')):
    receipt = directory / 'receipt.json'
    if receipt.is_file():
        value = json.loads(receipt.read_text(encoding='utf-8'))
        if value.get('exit_code') == 101:
            failures.append({'receipt': ref(receipt), 'exit_code': 101,
                'stdout': value['stdout'], 'stderr': value['stderr']})
assert len(failures) == 2, len(failures)
contracts = [ref(ROOT / name) for name in [
    'crates/ep_model/src/objects/materials.rs', 'crates/ep_model/src/report_inputs.rs',
    'crates/ep_runtime/src/error.rs', 'crates/ep_runtime/src/runtime.rs']]
manifest = {
    'schema': 'src06-hb-input-compile-corrections-preparation.v1',
    'status': 'HELD-Source-only-six-compile-corrections-not-applied-or-validated',
    'HEAD': subprocess.run(['git','rev-parse','HEAD'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip(),
    'parent_actual_assembly': ref(PARENT), 'parent_actual_file_count': 45,
    'files': rows, 'complete_literal_inverse': inverse, 'inventory': ref(inventory_path),
    'current_Rust_API_contracts': contracts, 'genuine_failed_QA_preserved': failures,
    'new_test_bodies': 0, 'new_test_binaries': 0,
    'scope': 'Only actual compiler/API/field/argument compatibility corrections. Scientific formulas, defaults, raw admission, getter order, output ownership and previous assertions are unchanged.',
    'canonical_writes': False, 'tests_executed': False, 'compiler_executed': False,
    'numeric_or_gate_PASS': False, 'author': ref(__file__),
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps(ref(OUT / 'manifest.json')))

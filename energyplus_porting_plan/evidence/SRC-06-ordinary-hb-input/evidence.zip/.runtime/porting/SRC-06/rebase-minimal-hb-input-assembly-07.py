"""Rebase only two overlaps onto Root's actual formatted pre-weather continuation."""
from pathlib import Path
import difflib
import hashlib
import json
ROOT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
authority = Path('.runtime/porting/SRC-06/ordinary-run-prefix-checks-assembly-01/manifest.json')
source = json.loads(authority.read_text(encoding='utf-8'))
def checked(ref):
    raw = Path(ref['path']).read_bytes()
    assert len(raw) == ref['size_bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256'], ref
    return raw
records = []
for name in ['crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs',
             'crates/ep_run/src/ctf_initialization_outputs.rs']:
    row = next(row for row in source['files'] if row['canonical_path'] == name)
    before, after = checked(row['before']), checked(row['after'])
    assert Path(name).read_bytes() == after
    proposal = ROOT/'proposed'/name
    base = ROOT/'before'/name
    assert base.read_bytes() == before, name
    archive = ROOT/'before-prefix-checks'/name
    archive.parent.mkdir(parents=True, exist_ok=True)
    assert not archive.exists()
    archive.write_bytes(before)
    proposal_archive = ROOT/'proposal-before-prefix-checks'/name
    proposal_archive.parent.mkdir(parents=True, exist_ok=True)
    proposal_archive.write_bytes(proposal.read_bytes())
    value = proposal.read_text(encoding='utf-8')
    old = before.decode('utf-8').splitlines(keepends=True)
    new = after.decode('utf-8').splitlines(keepends=True)
    for _, i, j, a, b in reversed([row for row in difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes() if row[0] != 'equal']):
        match, replacement = ''.join(old[i:j]), ''.join(new[a:b])
        if match and value.count(match) == 1:
            value = value.replace(match, replacement, 1)
            continue
        for width in (3, 2, 1):
            left, right = ''.join(old[max(0, i-width):i]), ''.join(old[j:j+width])
            if value.count(left+match+right) == 1:
                value = value.replace(left+match+right, left+replacement+right, 1)
                break
        else:
            raise AssertionError((name, match[:100]))
    base.write_bytes(after)
    proposal.write_text(value, encoding='utf-8', newline='\n')
    records.append({'canonical_path': name, 'base': row['after'],
        'preserved_delta': row['complete_actual_diff']})
(ROOT/'prefix-checks-rebase.json').write_text(json.dumps({
    'actual_assembly': {'path': authority.as_posix(), 'sha256': hashlib.sha256(authority.read_bytes()).hexdigest(),
        'size_bytes': authority.stat().st_size},
    'files': records,
    'canonical_mutated': False, 'targets_executed': False}, indent=2)+'\n', encoding='utf-8')
print('Only two HELD overlap proposals rebased; actual source_run_available and all Root test additions preserved.')

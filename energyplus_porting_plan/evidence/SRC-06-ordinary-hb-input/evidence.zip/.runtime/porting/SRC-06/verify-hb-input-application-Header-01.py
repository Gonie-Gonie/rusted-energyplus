"""Finite actual application/formatter preservation review; no canonical writes."""
import json, hashlib, difflib, subprocess, importlib.util
from pathlib import Path
ROOT=Path.cwd(); BASE=ROOT/'.runtime/porting/SRC-06'
UNIT=BASE/'ordinary-hb-input-assembly-01'
OUT=BASE/'Header-ordinary-hb-input-application-review-01'
def ref(p):
    p=Path(p);b=p.read_bytes()
    return {'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
actual=ref(UNIT/'manifest.json')
assert actual['sha256']=='cd6f2e17066bc214f47b98b9bba7baee78b03fbb01c264b91b1c3b5e094fd528'
m=json.loads((UNIT/'manifest.json').read_bytes());refs={}
def walk(x):
    if isinstance(x,dict):
        if all(k in x for k in ('path','sha256','size_bytes')):
            if x['path'] not in refs:
                assert ref(ROOT/x['path'])==x,x['path'];refs[x['path']]=x
        for k,v in x.items():
            if k!='after_apply':walk(v)
    elif isinstance(x,list):
        for v in x:walk(v)
walk(m)
packet=json.loads((ROOT/m['accepted_packet']['path']).read_bytes()); applied=json.loads((ROOT/m['apply']['path']).read_bytes())
pr={r['canonical_path']:r for r in packet['files']}; ar={r['canonical_path']:r for r in applied['files']}
assert len(m['files'])==len(pr)==len(ar)==45
assert m['HEAD']==packet['HEAD']==applied['HEAD']=='6d1b2e248a568dc63acb37d8a0b545efc4849364'
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==m['HEAD']
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','-z']).decode().split('\0')
changed={r[3:].replace('\\','/') for r in status if r}
assert changed==set(pr), ('changed set',sorted(changed-set(pr)),sorted(set(pr)-changed))
def text(p):return (ROOT/p).read_bytes().decode('utf-8').replace('\r\n','\n')
for row in m['files']:
    path=row['canonical_path']; held=pr[path]
    assert row['accepted_proposal']==held['proposal']
    assert {k:row[k] for k in ('canonical_path','existed_before','before','accepted_proposal','after_apply')}==ar[path]
    assert row['after_apply']['sha256']==row['accepted_proposal']['sha256']
    assert row['after_apply']['size_bytes']==row['accepted_proposal']['size_bytes']
    assert row['after']['sha256']==row['canonical']['sha256']
    before=text(row['before']['path']);proposal=text(row['accepted_proposal']['path']);after=text(row['after']['path'])
    if held['before']:
        assert row['before']['sha256']==held['before']['sha256'] and row['before']['size_bytes']==held['before']['size_bytes']
    else: assert before=='' and row['existed_before'] is False
    for key,old in (('complete_actual_diff',before),('held_to_actual_diff',proposal)):
        regenerated=''.join(difflib.unified_diff(old.splitlines(True),after.splitlines(True),fromfile=path,tofile=path))
        assert regenerated==text(row[key]['path']),(key,path)
    assert before.count('#[test]')==after.count('#[test]'),('new test body',path)
screen_source=BASE/'inspect-hb-format-tokens-Header-01.py'
spec=importlib.util.spec_from_file_location('header_hb_format_screen',screen_source);screen=importlib.util.module_from_spec(spec);spec.loader.exec_module(screen)
assert len(screen.rows)==45
assert all(r['nonformat_tokens_and_imports_same'] for r in screen.rows)
formatted=[r['path'] for r in screen.rows if r['formatter_diff_bytes']]
assert len(formatted)==37
report={
 'schema':'src06-independent-hb-input-actual-application-review.v1','accepted':True,'findings':[],
 'actual_assembly':actual,'actual_application':m['apply'],'preparation_manifest':m['accepted_packet'],'previous_Source_review':m['independent_Source_review'],
 'verification':{'unique_direct_references_SHA_and_sizes':len(refs),'accepted_literal_applications_exact':45,'saved_after_and_current_canonical_exact':45,'complete_actual_diffs_regenerated':45,'complete_held_to_actual_formatter_diffs_regenerated':45,'changed_canonical_path_set_exact':45,'formatted_files':formatted,'formatted_file_count':37,'new_test_bodies':0},
 'formatter_preservation':{
  'result':'Preserved all substantive identifiers, ordered expressions/operators, string/char/raw literals, signatures and control-flow keywords; only formatter layout/punctuation/block presentation and import/module ordering differ.',
  'method':'Full saved files and all90 complete diffs authenticated/regenerated; all45 token streams compared with string contents preserved, plus explicit formatter punctuation/import/module normalization. This is a Source preservation check, not a Rust parser or compiler result.',
  'token_screen_Source':ref(screen_source),'per_file_preservation':screen.rows},
 'final_files':[r['canonical'] for r in m['files']],
 'qualifications':[
  'In preparation02, allthree changed payloads differ only in top documentation comments; inherited whole dependency equality annotations apply to01 or after exact comment inverse, as qualified by previous Source review.',
  'Actual assembly is applied and formatted; actual compiler/lint/test results are outside this independent Source review.',
  'Full GetHeatBalanceInput/GetSurfaceData/InitHeatBalance/Setup and requested OutVar writer remain incomplete; no new Native or numerical parity or gate PASS is certified.',
  'One bundled fmath literal has local dependency custody, not reference Git; no Original or historical giant artifact scan repeated.'
 ],
 'canonical_edits_compiler_formatter_Cargo_Native_engine_or_tests_executed_by_reviewer':False,'gates_updated':False,
 'verification_Source':ref(Path(__file__))}
OUT.mkdir(exist_ok=False)
(OUT/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':ref(OUT/'review.json'),'files':45,'formatter_changed':37,'direct_references':len(refs)},ensure_ascii=False))

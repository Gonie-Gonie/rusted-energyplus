"""Freeze a comment-only immutable successor; all 45 production payloads remain held."""
from pathlib import Path
import difflib
import hashlib
import json
OLD = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
OUT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-02')
assert not OUT.exists()
parent = OLD/'manifest.json'
assert hashlib.sha256(parent.read_bytes()).hexdigest() == '1f394fc212f5c7fb211ab3ab71a2a55c8c33cba84458208d0907d75efa18f0d8'
record = json.loads(parent.read_text(encoding='utf-8'))
def ref(path):
    raw = path.read_bytes()
    return {'path':path.as_posix(), 'sha256':hashlib.sha256(raw).hexdigest(), 'size_bytes':len(raw)}
edits = {
 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs': (
    '//! Actual selected HeatBalanceManager input operations, before its geometry stage.\n//! This is a held caller dependency, not a replacement for GetHeatBalanceInput.\n',
    '//! Selected HB input operations consumed by the ordinary source-context route.\n//! Full GetHeatBalanceInput and InitHeatBalance orchestration remain incomplete.\n'),
 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/input.rs': (
    '//! Two real local-argument callers; IP remains the sole count/identity/unused owner.\n',
    '//! Source-backed local arguments; IP remains the sole count/identity/unused owner.\n'),
 'crates/ep_run/src/ordinary_heat_balance_input.rs': (
    '//! Raw operands for the two genuine HB getter hooks; no second query service.\n',
    '//! Raw operands for the consumed selected HB getters; no second query service.\n'),
}
rows=[]
for row in record['files']:
    name=row['canonical_path']
    if name not in edits: continue
    old=Path(row['proposal']['path']).read_bytes()
    old_text=old.decode('utf-8')
    before,after=edits[name]
    assert old_text.count(before)==1
    value=old_text.replace(before,after,1)
    assert value.replace(after,before,1)==old_text
    path=OUT/'proposed'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(value,encoding='utf-8',newline='\n')
    full=OUT/'diffs'/(name.replace('/','__')+'.diff')
    full.parent.mkdir(parents=True,exist_ok=True)
    canonical=Path(row['before']['path']).read_text(encoding='utf-8') if row['before'] else ''
    full.write_text(''.join(difflib.unified_diff(canonical.splitlines(keepends=True),value.splitlines(keepends=True),
        fromfile='a/'+name if canonical else '/dev/null',tofile='b/'+name)),encoding='utf-8',newline='\n')
    delta=OUT/'parent-diffs'/(name.replace('/','__')+'.diff')
    delta.parent.mkdir(parents=True,exist_ok=True)
    delta.write_text(''.join(difflib.unified_diff(old_text.splitlines(keepends=True),value.splitlines(keepends=True),
        fromfile='parent01/'+name,tofile='proposed02/'+name)),encoding='utf-8',newline='\n')
    rows.append({'canonical_path':name,'parent_proposal':row['proposal'],'proposal':ref(path),'exact_parent_diff':ref(delta)})
    row['proposal']=ref(path)
    row['complete_diff']=ref(full)
record['parent_manifest']=ref(parent)
record['comment_only_successor']={'changes':rows,'other_complete_payloads_byte_exact':len(record['files'])-len(rows),
    'logic_math_test_or_caller_changes':False,'whole_inverse_of_each_comment_edit_verified':True}
record['authoring_Source'].append(ref(Path('.runtime/porting/SRC-06/prepare-minimal-hb-input-comments-10.py')))
path=OUT/'manifest.json'
path.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'manifest':ref(path),'files':len(record['files']),'changed_comments':len(rows)}))

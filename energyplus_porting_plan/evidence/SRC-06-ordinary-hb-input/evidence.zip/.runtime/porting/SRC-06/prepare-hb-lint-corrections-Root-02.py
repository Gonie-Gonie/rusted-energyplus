"""Preserve lint01; add only the genuine mismatched staged-IDF fixture repair."""
from pathlib import Path
import difflib
import hashlib
import json

root=Path.cwd();base=root/'.runtime/porting/SRC-06'
out=base/'ordinary-hb-lint-corrections-prep-02';assert not out.exists()
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
parent_path=base/'ordinary-hb-lint-corrections-prep-01/manifest.json'
assert ref(parent_path)['sha256']=='2217d11368027578e891636524d26027f1010191828a1e1b82dd9e3b357f4c9b'
value=json.loads(parent_path.read_bytes())
actual_path=root/value['parent_actual_assembly']['path'];actual=json.loads(actual_path.read_bytes())
for row in actual['files']: assert ref(root/row['canonical_path'])==row['canonical']
name='crates/ep_run/src/ordinary_equipment_input.rs'
data=(root/name).read_bytes();before=data.decode('utf8')
old='HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;Zone,z;'
new='HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;Building,b,,,,,MinimalShadowing;Zone,z;'
assert before.count(old)==1;after=before.replace(old,new);assert after.replace(new,old)==before
refs={}
for key,payload in [('before',data),('proposal',after.encode()),('complete_diff',''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile=name,tofile=name)).encode())]:
    path=out/key/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(payload);refs[key]=ref(path)
value['files'].append({'canonical_path':name,**refs,'whole_inverse_exact':True})
value['parent_lint_preparation']=ref(parent_path)
value['author']=ref(Path(__file__))
value['actual_failed_focused_tests']=ref(base/'ordinary-hb-input-focused-tests-02/receipt.json')
receipt=json.loads((root/value['actual_failed_focused_tests']['path']).read_bytes())
assert receipt['exit_code']==101 and receipt['source_bytes_match_before_and_after'] is True
value['rationale'].append('The existing admission test staged IDF omitted Building b, although its converted epJSON contains Building b with MinimalShadowing. Add its genuine six positional fields with four blank defaults; retain strict count/identity validation and every existing assertion. Actual Source02 passed compiler8/raw1/ep_run fatal1, failed this one test, and did not reach runtime3; those partial results are not relabeled final.')
value['other_lint_proposals_byte_exact']=4
(out/'manifest.json').write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'packet':ref(out/'manifest.json'),'files':len(value['files'])}))

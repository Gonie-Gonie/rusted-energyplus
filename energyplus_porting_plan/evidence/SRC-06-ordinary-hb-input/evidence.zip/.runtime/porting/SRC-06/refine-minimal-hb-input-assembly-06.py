"""HELD finite source correction: actual centroid and early clipping custody."""
from pathlib import Path
ROOT = Path('.runtime/porting/SRC-06/ordinary-hb-input-assembly-prep-01')
HB = 'crates/ep_runtime/src/heat_balance/'
def get(name): return (ROOT/'proposed'/name).read_text(encoding='utf-8')
def put(name, value):
    path = ROOT/'proposed'/name
    archive = ROOT/'review-refinement-05'/name
    archive.parent.mkdir(parents=True, exist_ok=True)
    assert not archive.exists(), name
    archive.write_bytes(path.read_bytes())
    path.write_text(value, encoding='utf-8', newline='\n')

name = HB+'initialization.rs'
value = get(name)
old = '''            let shape = opaque.zones.iter().find(|row| row.zone_id == id)
                .ok_or_else(|| RuntimeError::WarmupUnavailable { reason: "actual Zone centroid association absent".into() })?;
'''
assert value.count(old) == 1
value = value.replace(old, '''            if !opaque.zones.iter().any(|row| row.zone_id == id) {
                return Err(RuntimeError::WarmupUnavailable { reason: "actual Zone geometry association absent".into() });
            }
''', 1)
old = '            zone.centroid_m = Some(shape.centroid_m);\n'
assert value.count(old) == 1
value = value.replace(old, '''            // SurfaceGeometry557-597: reset, then actual Space/opaque-class
            // traversal using already returned Surface.Centroid/GrossArea.
            let layout = super::inside_convection_layout::InsideConvectionLayout::from_typed_model(&model.typed)
                .map_err(|_| RuntimeError::WarmupUnavailable { reason: "actual Zone centroid traversal".into() })?;
            let mut centroid = [0.0; 3];
            let mut total_surface_area = 0.0;
            zone.centroid_m = Some(centroid);
            for group in layout.groups().iter().filter(|group| group.zone_id == id) {
                for surface_id in &group.surfaces {
                    let (_, geometry) = actual_surface_geometry.iter().find(|row| row.0 == *surface_id)
                        .ok_or_else(|| RuntimeError::WarmupUnavailable { reason: "actual Zone centroid surface return".into() })?;
                    centroid[0] += geometry.centroid_m.x_m * geometry.gross_area_m2;
                    centroid[1] += geometry.centroid_m.y_m * geometry.gross_area_m2;
                    centroid[2] += geometry.centroid_m.z_m * geometry.gross_area_m2;
                    total_surface_area += geometry.gross_area_m2;
                    zone.centroid_m = Some(centroid);
                }
            }
            if total_surface_area > 0.0 {
                centroid[0] /= total_surface_area;
                centroid[1] /= total_surface_area;
                centroid[2] /= total_surface_area;
                zone.centroid_m = Some(centroid);
            }
''', 1)
put(name, value)

# These flags are real DataSystemVariables, not a second ShadowingInput copy.
name = HB+'selected_project_data.rs'
value = get(name)
old = '    pub(crate) minimum_report_frequency: String,\n'
assert value.count(old) == 1
value = value.replace(old, old+'    pub(crate) shadowing_clipping: super::selected_heat_balance_input::shadowing::ShadowingSystemSettings,\n', 1)
put(name, value)
name = HB+'selected_project_data/environment.rs'
value = get(name)
old = '        update("MinimalShadowing", &mut self.system.minimal_shadowing)?;'
assert value.count(old) == 1
value = value.replace(old, '''        update("SutherlandHodgman", &mut self.system.shadowing_clipping.sutherland_hodgman)?;
        update("SlaterBarsky", &mut self.system.shadowing_clipping.slater_barsky)?;
'''+old, 1)
put(name, value)
name = HB+'selected_heat_balance_input/shadowing.rs'
value = get(name)
a = value.index('impl ShadowingSystemSettings {')
b = value.index('\n/// The sole selected SolarShading', a)
value = value[:a]+'''impl Default for ShadowingSystemSettings {
    fn default() -> Self { Self { sutherland_hodgman: true, slater_barsky: false } }
}
'''+value[b:]
value = value.replace('    pub(crate) settings: ShadowingSystemSettings,\n', '')
value = value.replace('pub(crate) fn new(settings: ShadowingSystemSettings) -> Self {\n        Self { settings, shading_method:', 'pub(crate) fn new() -> Self {\n        Self { shading_method:')
old = '        let shortcut = &mut context.reports.input_processor_shortcut;'
assert value.count(old) == 1
value = value.replace(old, '''        let settings = &context.reports.selected_project_data.as_ref()
            .ok_or(OrdinaryRadiationUnavailable::MissingInitializationContext)?.system.shadowing_clipping;
'''+old, 1)
value = value.replace('self.settings.sutherland_hodgman', 'settings.sutherland_hodgman')
value = value.replace('self.settings.slater_barsky', 'settings.slater_barsky')
put(name, value)
name = HB+'ctf_initialization_context.rs'
value = get(name)
old = '''        let settings = super::selected_heat_balance_input::shadowing::ShadowingSystemSettings::from_process_environment()
            .map_err(super::radiation::ordinary::OrdinaryRadiationError::from)?;
        let mut owner = super::selected_heat_balance_input::shadowing::SourceShadowingInput::new(settings);'''
assert value.count(old) == 1
value = value.replace(old, '        let mut owner = super::selected_heat_balance_input::shadowing::SourceShadowingInput::new();', 1)
put(name, value)
name = HB+'ctf_geometry_reports_tests.rs'
value = get(name)
old = '        assert!(source.is_object_unused("Output:Variable", "second") == (regex || !used));'
assert value.count(old) == 1
value = value.replace(old, '        assert_eq!(source.is_object_unused("Output:Variable", "second"), regex || !used);', 1)
put(name, value)
print('HELD only: actual centroid accumulation and one early clipping-settings owner.')

"""Promote only the two weather-input metadata fixes, keeping the diagnostic dispatcher isolated."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';WORK=BASE/'ordinary-provider-assembly-Root-66/workspace'
OUT=BASE/'reviewed-weather-metadata-promotion-Root-03'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert not OUT.exists() and not git('status','--porcelain=v1','-z')
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip()=='b6bf54c615449e0d6ebd0b7b127bc4b50a0119cd'
paths=['crates/ep_raw_model/src/idf_order.rs','crates/ep_run/src/ordinary_equipment_input/fields.rs'];rows=[]
peer=BASE/'Fix-ordinary-provider-union66-Source-review-02/review.json';review=json.loads(peer.read_bytes());assert review.get('status',review.get('decision','')).startswith('ACCEPTED')
test=WORK/'.runtime/porting/SRC-06/provider-assembly-existing-raw-model-tests-66/receipt.json';t=json.loads(test.read_bytes());assert t['exit_code']==0 and t['source_bytes_match_before_and_after']
run=WORK/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-66/receipt.json';r=json.loads(run.read_bytes());assert r['exit_code']==6 and r['source_bytes_match_before_and_after']
assert t['source_snapshot']==r['source_snapshot']
diagnostics=ROOT/'.runtime/porting/SRC-06/through-primary-diagnostic-A-24H-Root-66/output/diagnostics.json';d=json.loads(diagnostics.read_bytes());errors=[x['message']for x in d['diagnostics']if x['severity']=='error'];assert errors==['GetHeatBalanceInput: actual thermal weather accumulation5870-6386; before first PierceSET reset']
snapshot=json.loads((WORK/r['source_snapshot']['path']).read_bytes());assert len(snapshot['files'])==4412 and not snapshot['bytes_normalized']
pipeline='crates/ep_run/src/pipeline.rs';pipeline_before=(ROOT/pipeline).read_bytes();assert pipeline_before==(BASE/'ordinary-provider-assembly-Root-62/workspace'/pipeline).read_bytes()
for row in snapshot['files']:
 path=row['historical_path'];b=(WORK/row['archive']['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['archive']['sha256'] and (WORK/path).read_bytes()==b
 if path in paths:continue
 if path==pipeline:
  assert b==(BASE/'ordinary-provider-assembly-Root-63/workspace'/path).read_bytes() and b!=pipeline_before
 else:assert (ROOT/path).read_bytes()==b
for path in paths:
 a=(ROOT/path).read_bytes();b=(WORK/path).read_bytes();assert a==git('show',head+':'+path) and a!=b and b'\r\n'not in b and a.count(b'#[test]')==b.count(b'#[test]')
 rows.append(dict(path=path,before_sha256=hashlib.sha256(a).hexdigest(),before_bytes=len(a),after_sha256=hashlib.sha256(b).hexdigest(),after_bytes=len(b)))
OUT.mkdir()
for row in rows:
 path=row['path'];p=ROOT/path;old=OUT/'before'/path;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(p.read_bytes());p.write_bytes((WORK/path).read_bytes())
assert (ROOT/pipeline).read_bytes()==pipeline_before
v=dict(schema='src06-canonical-weather-idf-metadata-correction.v1',status='Only two metadata Sources applied; commit/push pending',base_HEAD=head,changes=rows,actual_existing_raw_package_tests=ref(test),actual_held_A_execution=ref(run),diagnostics=ref(diagnostics),actual_A_exit=6,actual_A_frontier=errors[0],independent_Source_peer=ref(peer),diagnostic_compiler_input_snapshot=t['source_snapshot'],diagnostic_workspace=WORK.relative_to(ROOT).as_posix(),compiler_inputs=4412,canonical_pipeline_unchanged=dict(path=pipeline,sha256=hashlib.sha256(pipeline_before).hexdigest(),bytes=len(pipeline_before)),intentional_diagnostic_pipeline_difference=ref(WORK/pipeline),new_test_bodies=0,existing_raw_tests_passed=16,full_suite_rerun=False,EOF_domain='Exact metadata transport requires semicolon-terminated RunPeriod and SizingPeriod:DesignDay; their EOF-only domain is explicitly unavailable. Other family EOF behavior unchanged.',pipeline_activation=False,whole_Native_numeric_PASS=False,gate_changes=False,A='14/54',B='14/64',author_Source=ref(Path(__file__).resolve()))
p=OUT/'promotion.json';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

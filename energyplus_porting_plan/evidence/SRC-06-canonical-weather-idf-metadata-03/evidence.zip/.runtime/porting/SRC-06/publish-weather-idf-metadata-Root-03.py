"""Publish bounded weather input corrections and actual failure-prefix evidence."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06'
PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-weather-idf-metadata-03'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 p=base/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b)));return b
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert not PUBLIC.exists()
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip()=='b6bf54c615449e0d6ebd0b7b127bc4b50a0119cd'
promotion=BASE/'reviewed-weather-metadata-promotion-Root-03/promotion.json';p=json.loads(promotion.read_bytes())
assert ref(promotion)['sha256']=='aeebe32949a644945b71c1d83ce24d6976af6c1846131f2d18b6c87e1709c0af'
expected={row['path'] for row in p['changes']}
assert set(git('diff','--name-only').decode().splitlines())==expected and not git('diff','--cached','--name-only')
for row in p['changes']:
 b=(ROOT/row['path']).read_bytes();a=git('show',head+':'+row['path'])
 assert hashlib.sha256(b).hexdigest()==row['after_sha256'] and hashlib.sha256(a).hexdigest()==row['before_sha256'] and b'\r\n' not in b and a.count(b'#[test]')==b.count(b'#[test]')
read(p['canonical_pipeline_unchanged']);assert git('show',head+':crates/ep_run/src/pipeline.rs')==(ROOT/'crates/ep_run/src/pipeline.rs').read_bytes()
payload={}
def add(q):
 q=q.resolve();b=q.read_bytes();key=q.relative_to(ROOT).as_posix();assert key not in payload or payload[key]==b;payload[key]=b;return ref(q)
def add_ref(r,base=ROOT):read(r,base);return add(base/r['path'])
add(promotion);add_ref(p['author_Source']);add(Path(__file__).resolve())
actual=[]
for n in [63,64,65,66]:
 w=BASE/f'ordinary-provider-assembly-Root-{n}/workspace'
 q=w/f'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-{n}/receipt.json';r=json.loads(q.read_bytes());assert r['exit_code']==6 and r['source_bytes_match_before_and_after'];actual.append(add(q))
 for key in ['stdout','stderr','source_snapshot']:add_ref(r[key],w)
 add(BASE/f'ordinary-provider-assembly-Root-{n}/manifest.json')
q=ROOT/p['actual_existing_raw_package_tests']['path'];r=json.loads(q.read_bytes());assert r['exit_code']==0 and r['source_bytes_match_before_and_after'];tests=add(q);w=BASE/'ordinary-provider-assembly-Root-66/workspace'
for key in ['stdout','stderr','source_snapshot']:add_ref(r[key],w)
assert 'test result: ok. 16 passed; 0 failed; 0 ignored;' in read(r['stdout'],w).decode()
q=BASE/'canonical-existing-A-24H-metadata-regression-Root-03/receipt.json';r=json.loads(q.read_bytes());assert r['exit_code']==0 and r['source_bytes_match_before_and_after'];regression=add(q)
for key in ['stdout','stderr','source_snapshot']:add_ref(r[key])
o=BASE/'canonical-A-24H-metadata-regression-Root-03/output';rs=json.loads((o/'run-summary.json').read_bytes());assert rs['exit_code']==0
for name in ['run-summary.json','diagnostics.json','input/input-hashes.json']:add(o/name)
peers=[]
for name in ['Audit-ordinary-location-idf-metadata-admission-Source-review-01','Audit-ordinary-run-period-idf-metadata-Source-review-01','Audit-ordinary-run-period-idf-metadata-Source-review-02','Audit-ordinary-design-day-idf-metadata-Source-review-01','Fix-ordinary-provider-union63-diagnostic-Source-review-02','Fix-ordinary-provider-union64-Source-review-01','Fix-ordinary-provider-union65-Source-review-01','Fix-ordinary-provider-union66-Source-review-02','Fix-ordinary-provider-union63-A-24H-first-frontier-review-02','Fix-ordinary-provider-union64-A-24H-first-frontier-review-01','Fix-ordinary-provider-union65-A-24H-first-frontier-review-01','Fix-ordinary-provider-union66-A-24H-first-frontier-review-03']:
 peers.append(add(BASE/name/'review.json'))
for name in ['ordinary-location-idf-metadata-admission-held-Reviewer-01','ordinary-run-period-idf-metadata-held-Reviewer-02','ordinary-design-day-idf-metadata-held-Reviewer-01']:add(BASE/name/'manifest.json')
ledger=json.loads((BASE/'Fix-ordinary-provider-union66-A-24H-first-frontier-review-03/review.json').read_bytes())
for row in ledger['artifacts']:add_ref(row['actual'])
for row in ledger['same_actual_input_and_conversion']:add_ref(row['actual66'])
PUBLIC.mkdir();z=PUBLIC/'evidence.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for key,b in sorted(payload.items()):
  item=zipfile.ZipInfo(key,date_time=(2026,10,17,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(item,b)
with zipfile.ZipFile(z) as archive:
 assert archive.testzip() is None and set(archive.namelist())==set(payload)
 for key,b in payload.items():assert archive.read(key)==b
summary=dict(schema='src06-canonical-weather-idf-metadata.v1',status='Reviewed weather IDF metadata corrected; genuine Source diagnostic reaches first normal-weather report; whole port and Native parity pending',Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,changed_Rust_files=2,new_test_bodies=0,promotion=ref(promotion),actual_genuine_Source_failure_prefix_commands=actual,existing_raw_package_tests=tests,existing_raw_tests_passed=16,canonical_legacy_A24H_regression=regression,independent_reviews=peers,evidence_archive=ref(z),archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for k,b in sorted(payload.items())],scope=['Site:Location accepts only its actually staged and validated IDF field count.','RunPeriod stages the actual positional field count with Native minimum7; SizingPeriod:DesignDay stages the actual positional count with minimum0. Optional field capacity is not used as a substitute for input field count.','RunPeriod and SizingPeriod:DesignDay require semicolon termination for exact metadata; their EOF-only domain is explicitly unavailable. Other family EOF behavior is unchanged.','Two existing test bodies were extended; the existing raw-model package16 tests pass without new test bodies.','The genuine Source diagnostic passed the three prior input gates, completed warmup20 and entered Primary weather simulation. It stops at actual thermal weather accumulation5870-6386 before the first PierceSET reset.'],validation_scope='Canonical unchanged legacy dispatcher A-24H succeeds after the two input corrections. This is a regression check only. Genuine Source A-24H still exits6 at its first unsupported thermal report; no genuine Source24h completion or Native numeric PASS is asserted. Full workspace tests were not repeated for these two metadata files.',coverage_limit='Existing clock/day observers record zero for the genuine Source path and generic stage snapshots describe metadata only; actual CTF LOG/EIO and the independently reviewed caller chain establish Source entry. Broader observer coverage remains pending.',reconstruction='Canonical Git holds both changed LF Rust files. Compact archive binds actual receipts/logs, compiled input hash censuses, packet manifests and independent reviews. It adds no complete offline replay claim and omits the734MB legacy fulltrace.',pipeline_activation=False,canonical_pipeline= p['canonical_pipeline_unchanged'],whole_Native_numeric_PASS=False,full_suite_rerun=False,gate_changes=False,A='14/54',B='14/64',retained_whole_old_comparison=dict(mismatches=235456,required_unavailable_or_unpaired=2754),author_Source=ref(Path(__file__).resolve()))
q=PUBLIC/'summary.json';q.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8',newline='\n')
relative='evidence/SRC-06-canonical-weather-idf-metadata-03/summary.json'
paragraph='Site:Location·RunPeriod·SizingPeriod:DesignDay의 실제 IDF 필드 수 전달을 수정했습니다. 선택 필드의 전체 용량으로 입력 개수를 대체하지 않으며, RunPeriod와 DesignDay의 세미콜론 없는 EOF 입력은 정확한 메타데이터를 보장할 수 없어 명시적으로 미지원 처리합니다. 기존 raw-model 테스트 16개와 기본 실행 경로 A-24H 회귀 실행이 통과했습니다. 새 테스트 본문과 전체 테스트 반복은 없습니다. 별도 실제 Source 경로는 세 입력 오류를 넘고 20일 워밍업 후 본 기상 실행에 진입했으며, 첫 열적 복원력 누적 보고에서 미지원으로 종료합니다. 실제 Source 24시간 완료·기본 파이프라인 전환·Native 수치 동등성을 뜻하지 않습니다. A14/54·B14/64와 기존 전체 FAIL을 유지합니다.'
for name in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']:
 q=ROOT/'energyplus_porting_plan'/name;s=q.read_text(encoding='utf8');assert 'canonical-weather-idf-metadata-03' not in s;link='../'+relative if name.startswith('cards/') else relative;s+='\n\n[날씨 입력 메타데이터 수정과 실제 실행 기록](%s). %s\n'%(link,paragraph);q.write_text(s,encoding='utf8',newline='\n')
q=ROOT/'energyplus_porting_plan/plan.json';before=json.loads(q.read_bytes());after=json.loads(q.read_bytes());task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_weather_idf_metadata_03';assert key not in task;task[key]=dict(path=(PUBLIC/'summary.json').relative_to(ROOT).as_posix(),sha256=ref(PUBLIC/'summary.json')['sha256'],size_bytes=(PUBLIC/'summary.json').stat().st_size);check=json.loads(json.dumps(after));del next(x for x in check['tasks'] if x['id']=='SRC-06')[key];assert check==before;q.write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(ref(PUBLIC/'summary.json')));print(json.dumps(ref(z)));print('archive_entries',len(payload))

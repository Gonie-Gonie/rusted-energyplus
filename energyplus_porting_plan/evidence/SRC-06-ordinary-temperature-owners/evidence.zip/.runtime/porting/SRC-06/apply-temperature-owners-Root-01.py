"""Apply twelve reviewed source payloads plus one actual Native-only test fixture."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-temperature-owner-application-01'


def ref(path):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else path.as_posix(),
            'sha256': digest, 'size_bytes': path.stat().st_size}


def pinned(path, digest):
    actual = ref(ROOT / path)
    assert actual['sha256'] == digest, path
    return actual


def load(row):
    actual = ref(ROOT / row['path'])
    assert actual['sha256'] == row['sha256']
    assert 'size_bytes' not in row or actual['size_bytes'] == row['size_bytes']
    return json.loads((ROOT / row['path']).read_bytes())


def write(name, value):
    path = OUT / name
    with path.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
    return ref(path)


owner_ref = pinned('.runtime/porting/SRC-06/ordinary-temperature-owner-prep-04/manifest.json',
                   '1a218751703dc734a13802ee8c49c2706183fba53531f81aabcd48eab0789f82')
owner = load(owner_ref)
peer_ref = pinned('.runtime/porting/SRC-06/Header-ordinary-temperature-owner-Source-review-04/review.json',
                  '24362bc802a13ab3ed7519ddc00afcb56d5a09884b2a0d2d8954c1ee54c5c3b3')
peer = load(peer_ref)
assert peer['accepted'] and peer['preparation'] == owner_ref
comparison_ref = pinned('.runtime/porting/SRC-06/ordinary-temperature-comparison-prep-02/manifest.json',
                        'b13af4f39661bfe71cb78b7cd043dd80f4c41a07b8909464fd025eca20470959')
load(comparison_ref)
root_facts_ref = pinned('.runtime/porting/SRC-06/ordinary-temperature-native-factual-Root-02/review.json',
                       '3948120e6c098142b35f01c35186cdc9e9ebc5489909a26dd9a117c5d62bf227')
header_facts_ref = pinned('.runtime/porting/SRC-06/Header-ordinary-temperature-native-facts-02/review.json',
                         '4c98858241956574055ae902ce2b61b350c020d35603d3b0a80e89417b720729')
root_facts, header_facts = load(root_facts_ref), load(header_facts_ref)
for facts in [root_facts, header_facts]:
    assert facts['status'] == 'ACCEPTED_SELECTED_ORIGINAL_ASSIGNMENT_BOUNDARIES' and facts['mismatches'] == 0
    assert facts['capture']['sha256'] == 'cedd5f677b02aa683e62d44c1a08f6a96c175b9b72968da246ef659d0583a19c'
    assert facts['checker']['sha256'] == 'b7cc84be7abcb973a9066cc13df929e1b8172f72881e107b27159a34894b208d'
    assert facts['observed_events'] == 58039 and facts['whole_ordinary_equivalence_certified'] is False
    load(facts['selected_cases'])
for key in ['checkpoint_counts', 'validated_pairs', 'actual_native_arguments', 'actual_terminal_summary']:
    assert root_facts[key] == header_facts[key]
fixture_source = ROOT / root_facts['selected_cases']['path']
assert fixture_source.read_bytes() == (ROOT / header_facts['selected_cases']['path']).read_bytes()
draft_ref = pinned('.runtime/porting/SRC-06/ordinary-temperature-comparison-prep-02/ordinary-native-owner-replay-test.draft.rs',
                   '2be29c49036e2321c12e37eca073c20df45a47e77e948589977c98e7b370dd38')
custody_ref = pinned('D:/CodexBuild/rusted-energyplus/SRC-06/ordinary-temperature-native-capture-01/custody.json',
                     '30ff05ba2d3ca4d909af9ccee82dcedeaec41cc74ff320df2b075036c1ba04ae')
custody = load(custody_ref)
execution_ref = pinned('.runtime/porting/SRC-06/ordinary-temperature-native-capture-command-01/receipt.json',
                       '66c26eaa694d0b478cdd2779bb4c00ae641dea25b98f3ce1b0aaa7e634087129')
execution = load(execution_ref)
assert execution['exit_code'] == 0 and execution['source_bytes_match_before_and_after']
assert custody['transport_custody_accepted'] and custody['actual_native_child_count'] == 1
assert custody['input_executable_Source_DLL_bytes_unchanged'] and not custody['guard_errors']
assert root_facts['actual_native_arguments'] == [custody['actual_helper_argv'][0], *custody['actual_native_argv']]
spec = importlib.util.spec_from_file_location('temperature_recorder', ROOT / 'tools/porting/record_command.py')
recorder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recorder)
before = recorder.source_snapshot()
assert before == owner['actual_before_Source_snapshot'] == execution['source_snapshot']
proposals = owner['source_proposals']
assert len(proposals) == 12
for row in proposals:
    destination = ROOT / row['canonical_path']
    if row['new_destination_absent']:
        assert not destination.exists()
    else:
        assert ref(destination) == row['actual_before']
    assert ref(ROOT / row['proposed']['path']) == row['proposed']
    if not row['new_destination_absent']:
        assert ref(ROOT / row['before_archive']['path']) == row['before_archive']
for row in owner['Original_ranges']:
    source = ROOT / row['Source']['path']
    assert ref(source) == row['Source']
    literal = b''.join(source.read_bytes().splitlines(keepends=True)[row['first_line'] - 1:row['last_line']])
    assert literal == (ROOT / row['literal_archive']['path']).read_bytes()
fixture_destination = ROOT / 'crates/ep_runtime/src/heat_balance/fixtures/ordinary_temperature_selected_cases.json'
assert not fixture_destination.exists()
OUT.mkdir(exist_ok=False)
review = write('Root-Source-and-Native-acceptance.json', {
    'schema': 'src06-temperature-owner-Root-application-acceptance.v1', 'accepted': True,
    'owner_preparation': owner_ref, 'independent_owner_Source_review': peer_ref,
    'comparison_preparation': comparison_ref, 'Root_actual_facts': root_facts_ref,
    'Header_actual_facts': header_facts_ref, 'actual_capture_custody': custody_ref,
    'actual_capture_execution': execution_ref, 'actual_fixture': ref(fixture_source),
    'replay_Source': draft_ref, 'before_Source': before,
    'scope': 'Actual assignment/reset/default SpaceMAT consumer and independent Old owner operations; existing diagnostic A solver retained',
    'actual_reference_branch': -1, 'explicit_ZoneMeanAirTemp_0_observed': False,
    'solver_dispatcher_cadence_or_whole_ordinary_certified': False, 'gates_updated': False})
application = []
for row in proposals:
    destination = ROOT / row['canonical_path']
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((ROOT / row['proposed']['path']).read_bytes())
    application.append({'canonical_path': row['canonical_path'], 'actual_before': row['actual_before'],
                        'reviewed_proposal': row['proposed'], 'actual_after': ref(destination)})
test_file = ROOT / 'crates/ep_runtime/src/heat_balance/ordinary_inside_temperatures_tests.rs'
draft = (ROOT / draft_ref['path']).read_text(encoding='utf8')
draft = draft.replace('// HELD, uncompiled draft for the private ordinary_inside_temperatures::tests module.\n// Final fixture path/bytes and this test must be reviewed after actual Native facts.\n// Each input below comes from an observed BEFORE owner; no production solver runs.',
                      '// Replay actual selected Native before/after owners through the private\n// retained-temperature operations. Native values are test data only.')
draft = draft.replace('// This file is intentionally absent until Root approves the genuine facts.',
                      '// The frozen fixture contains actual before/after Native observations.')
test_file.write_bytes(test_file.read_bytes().rstrip() + b'\n\n' + draft.encode('utf8'))
fixture_destination.parent.mkdir(parents=True, exist_ok=True)
fixture_destination.write_bytes(fixture_source.read_bytes())
after = recorder.source_snapshot()
record = write('application.json', {
    'schema': 'src06-temperature-owner-actual-application.v1', 'accepted_Source_and_Native': review,
    'before_Source': before, 'after_unformatted_Source': after, 'application': application,
    'replay_test_after_append': ref(test_file), 'canonical_Native_fixture': ref(fixture_destination),
    'fixture_exact_actual_selected_cases': True, 'expected_values_used_in_production': False,
    'tests_executed': False, 'whole_ordinary_PASS_claimed': False, 'gates_updated': False,
    'application_Source': ref(Path(__file__))})
print(json.dumps({'application': record, 'after_Source': after, 'fixture': ref(fixture_destination)}))

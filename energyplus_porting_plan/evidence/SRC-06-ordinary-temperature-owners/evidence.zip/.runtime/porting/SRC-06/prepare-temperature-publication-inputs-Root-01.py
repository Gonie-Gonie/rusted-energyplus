"""Close actual QA metadata and prepare the finite publication inputs."""
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/porting/SRC-06'

def ref(path):
    return dict(path=path.relative_to(ROOT).as_posix(),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest(), size_bytes=path.stat().st_size)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())

def main():
    peer_path, peer_sha = sys.argv[1].rsplit('#', 1)
    peer = ROOT / peer_path
    assert ref(peer)['sha256'] == peer_sha and read(peer)['accepted'] is True
    quality = {key: BASE / f'ordinary-temperature-integrated-{name}-command-01/receipt.json'
               for key, name in [('fmt_check', 'fmt-check'), ('workspace_clippy', 'clippy'), ('workspace_test', 'workspace')]}
    receipts = {key: read(path) for key, path in quality.items()}
    source = receipts['fmt_check']['source_snapshot']
    for receipt in receipts.values():
        assert receipt['exit_code'] == 0 and receipt['launch_error'] is None
        assert receipt['source_bytes_match_before_and_after'] is True
        assert receipt['source_snapshot'] == source
    stdout = (ROOT / receipts['workspace_test']['stdout']['path']).read_text(encoding='utf-8')
    results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)
    totals = {key: sum(int(row[i]) for row in results) for i, key in enumerate(('passed', 'failed', 'ignored'))}
    assert results and totals['passed'] > 0 and totals['failed'] == 0
    fixture = ROOT / 'crates/ep_runtime/src/heat_balance/fixtures/ordinary_temperature_selected_cases.json'
    assert ref(fixture)['sha256'] == 'b70b45958198a374e8cfb37e42a8b1dc6287e99e46529aaeb8b8bcfde468caf8'
    owner = read(BASE / 'ordinary-temperature-owner-prep-04/manifest.json')
    current = [ref(ROOT / row['canonical_path']) for row in owner['source_proposals']] + [ref(fixture)]
    facts_path = BASE / 'ordinary-temperature-native-factual-Root-02/review.json'
    facts = read(facts_path)
    closure = read(BASE / 'Root-ordinary-temperature-provider-review-01/runtime-closure.json')
    summary = {
        'schema': 'src06-actual-selected-ordinary-temperature-owners.v1',
        'status': 'pass-selected-retained-temperature-operations-and-input-prerequisites-only',
        'Original': {'version': '26.1.0', 'commit': '6f2e40d10250a105b49966baa24d843711e61048'},
        'implementation_parent': receipts['fmt_check']['repository_before']['head'],
        'final_Rust_Source': source,
        'Source_members': len(read(ROOT / source['path'])['files']),
        'selected_current_sources': current,
        'implemented': [
            'Persistent independent current Zone ZT, existing Space MAT/ZT/ZTAV owners and complete SurfTempInsOld array.',
            'Begin-environment air reset, actual existing solver-return retention, MAT commit before sensible/humidity reporting and disabled-space MAT/ZT copy after correction; ZTAV retained independently.',
            'Complete associated SpaceMAT map supplies inside reference air; complete Old <- In copy occurs before the existing radiation stage.',
            'Exact complete typed associations/cardinality checked before writes; stale IDs, missing prefix and invalid retained input reject explicitly.',
            'Actual six raw user-convection family counts and HeatBalanceAlgorithm N2/default0.1 retained through the ordinary A caller; no convection consumer activation.',
        ],
        'actual_Native': {
            'one_engine_child_exit_code': 0,
            'Source_build': closure['native_build'],
            'helper_provenance_only': closure['helper_binary'],
            'provider_review': closure['provider_review'],
            'complete_capture': facts['capture'],
            'complete_capture_gzip': ref(BASE / 'ordinary-temperature-native-archive-01/A-24H.observation.json.gz'),
            'Root_facts': ref(facts_path),
            'independent_facts': ref(BASE / 'Header-ordinary-temperature-native-facts-02/review.json'),
            'observed_events': facts['observed_events'],
            'validated_pairs': facts['validated_pairs'],
            'mismatches': facts['mismatches'],
            'observed_reference_flag': -1,
            'explicit_reference_flag0_observations': 0,
            'actual_algorithm': 'ThirdOrder (0)',
            'actual_zones_spaces_surfaces': [1, 1, 6],
            'engine_rerun_for_checker_repair': False,
        },
        'actual_Rust_replay': {
            'test': 'actual_native_before_owners_replay_selected_retained_temperature_operations',
            'fixture': ref(fixture), 'genuine_cases': 19, 'scalar_bits_classes_in_fixture': 661,
            'selection': 'Allocation1, reset2, reference4, Old4, MAT4, disabled-space-group4; actual kickoff/warmup/run phases where observed.',
            'production_Native_answers_used': False,
            'scope': 'Test-local actual BEFORE owners drive genuine private assignment/map methods; every selected AFTER scalar is compared by binary64 bits/class.',
        },
        'raw_input_prerequisite': {
            'preparation': ref(BASE / 'ordinary-convection-input-prep-02/manifest.json'),
            'application': ref(BASE / 'ordinary-convection-input-application-02/application.json'),
            'independent_Source_review': ref(BASE / 'Header-ordinary-convection-input-Source-review-02/review.json'),
            'independent_applied_review': ref(peer),
            'rules': 'Six actual zero family counts; unique HeatBalanceAlgorithm; absent/null/blank N2 retains Original constructor0.1; explicit finite positive number retained. Unsupported inputs and invalid retained values stop before inside-entry writes.',
            'tests': 'One28-case raw-input table plus existing production-route retention/prefix regression;0.375 verifies retention only.',
        },
        'actual_quality': {
            key: {'receipt': ref(quality[key]), 'command': receipt['command'],
                  'exit_code': receipt['exit_code'], 'source_stable': receipt['source_bytes_match_before_and_after']}
            for key, receipt in receipts.items()
        },
        'workspace_test_totals': totals,
        'iteration_quality_history': {'runtime_ordinary_passed': 36, 'run_controls_passed': 2,
                                     'scope': 'Earlier owner-only focused tests; final workspace validates the later raw input delta too.'},
        'retained_failure': {
            'receipt': ref(BASE / 'ordinary-temperature-native-factual-command-Root-01/receipt.json'),
            'cause': 'First checker admitted only explicit ZoneMeanAirTemp0 but actual Original constructor flag was Invalid-1. Full Original getter default branch returns the same actual SpaceMAT.',
            'repair': 'Reviewed successor admits only -1/0 for selected SpaceMAT branch; same immutable raw capture reused, no numerical rule, endpoint or target run changed.',
        },
        'remaining': [
            'Rust production uses its existing SimplifiedAnalytical diagnostic solver; actual Native capture uses ThirdOrder. No solver or whole ordinary call-order equivalence follows from assignment replay.',
            'One shared SpaceAir owner with dispatcher, independent SurfTempInTmp allocation/reset/solve production, actual no-equipment/readiness/Node allocation producers and real ordinary dispatcher activation.',
            'Actual radiation enclosure/cache lifecycle, post-radiation positive completed-iteration30 refresh, immediate CTF term rebuild and original inside convergence loop.',
            'True zone algorithm/HVAC handoff, full ZTAV averaging, multiple-space actual coverage and explicit reference flag0 actual coverage.',
            'Whole Native stream validates all observed assignment pairs; bounded Rust replay selects19 cases and first reference surface per phase, not every Native invocation.',
        ],
        'full_card_gates_changed': False,
        'completed_cards': {'A': {'passed': 14, 'total': 54}, 'B': {'passed': 14, 'total': 64}},
        'archive_policy': 'Three adjacent files: summary.json, manifest.json, evidence.zip. Only indexed finite bytes are bundled. Large binaries/maps/core/toolchain, whole Rust Source maps/payloads and unindexed historical parents are provenance-only; no transitive replay claim.',
    }
    out = BASE / 'temperature-owner-publication-inputs-01'
    out.mkdir(exist_ok=False)
    write(out / 'summary-root.json', summary)
    records = [Path(__file__), BASE / 'apply-temperature-owners-Root-01.py',
               BASE / 'apply-convection-inputs-Root-02.py', BASE / 'close-temperature-provider-Root-01.py',
               BASE / 'review-ordinary-temperature-providers-Header-01.py', peer,
               BASE / 'Header-ordinary-convection-input-Source-review-02/review.json',
               ROOT / 'crates/ep_runtime/src/heat_balance/inside_convection_dispatcher.rs',
               ROOT / 'tools/porting/record_command.py', ROOT / 'tools/porting/native_pe.py',
               ROOT / '.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py']
    for directory in ['ordinary-convection-input-application-02', 'ordinary-convection-input-format-command-02',
                      'ordinary-temperature-runtime-affected-command-01', 'ordinary-temperature-run-affected-command-01',
                      'Root-convection-input-formatter-review-02']:
        records.extend(path for path in sorted((BASE / directory).iterdir()) if path.is_file())
    records.extend(path for path in sorted(peer.parent.iterdir()) if path.is_file() and path != peer)
    inputs = {'schema': 'src06-temperature-publication-inputs.v1', 'summary': ref(out / 'summary-root.json'),
              'Source_snapshot': source, 'current_sources': current,
              'quality_receipts': {key: ref(path) for key, path in quality.items()},
              'actual_records': [ref(path) for path in records],
              'input_preparation': ref(BASE / 'ordinary-convection-input-prep-02/manifest.json'),
              'provenance_only': [closure['helper_binary'], closure['Source_snapshot']]}
    write(out / 'actual-inputs.json', inputs)
    print(json.dumps({'summary': ref(out / 'summary-root.json'), 'inputs': ref(out / 'actual-inputs.json'), 'workspace': totals}))

if __name__ == '__main__':
    main()

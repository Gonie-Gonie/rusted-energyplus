"""HELD raw-input delta on actual formatted owner04 + frozen Native replay."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
PARENT = ROOT / '.runtime/porting/SRC-06/ordinary-convection-input-prep-01'
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-convection-input-prep-02'


def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}


def replace(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new)


assert ref(PARENT / 'manifest.json')['sha256'] == 'e9915fe72e4796d8f6dd204c84ce68bcfe98389372a8082d70f116402031fe0f'
parent = json.loads((PARENT / 'manifest.json').read_text(encoding='utf-8'))
old_rows = {row['canonical_path']: row for row in parent['source_proposals']}
before = {path: (ROOT / path).read_text(encoding='utf-8') for path in old_rows}
actual_refs = {path: ref(ROOT / path) for path in before}
prior = {path: (ROOT / row['proposed']['path']).read_text(encoding='utf-8') for path, row in old_rows.items()}
fixture = ROOT / 'crates/ep_runtime/src/heat_balance/fixtures/ordinary_temperature_selected_cases.json'
fixture_ref = ref(fixture)
assert fixture_ref['sha256'] == 'b70b45958198a374e8cfb37e42a8b1dc6287e99e46529aaeb8b8bcfde468caf8'
assert not OUT.exists(), 'Do not overwrite a prior preparation'
after = dict(before)

path = 'crates/ep_run/src/warmup_report_controls.rs'
after[path] = replace(after[path], 'use ep_runtime::HeatBalanceOrdinaryWarmupReportInputs;',
    'use ep_runtime::HeatBalanceOrdinaryWarmupReportInputs;\nuse ep_runtime::heat_balance::inside_convection_dispatcher::NoUserConvectionInput;')
block = prior[path].split('    // GetUserConvCoeffs queries', 1)[1].split('    Ok(HeatBalanceOrdinaryWarmupReportInputs {', 1)[0]
after[path] = replace(after[path], '    Ok(HeatBalanceOrdinaryWarmupReportInputs {',
    '    // GetUserConvCoeffs queries' + block + '    Ok(HeatBalanceOrdinaryWarmupReportInputs {')
after[path] = replace(after[path], '        do_space_heat_balance_for_simulation,\n    })',
    '        do_space_heat_balance_for_simulation,\n        no_user_convection_input,\n        low_hconv_limit_w_per_m2_k,\n    })')
after[path] = replace(after[path], '                do_space_heat_balance_for_simulation: false,\n            }',
    '                do_space_heat_balance_for_simulation: false,\n                no_user_convection_input: NoUserConvectionInput::new([0; 6])?,\n                low_hconv_limit_w_per_m2_k: 0.1,\n            }')
table = prior[path].split('    #[test]\n    fn ordinary_convection_raw_inputs_preserve_defaults_values_and_reject_unsupported()', 1)[1]
assert table.endswith('}\n')
after[path] = after[path].rstrip()[:-1] + '\n    #[test]\n    fn ordinary_convection_raw_inputs_preserve_defaults_values_and_reject_unsupported()' + table

path = 'crates/ep_runtime/src/heat_balance/state.rs'
after[path] = replace(after[path], '    pub do_space_heat_balance_for_simulation: bool,\n}',
    '''    pub do_space_heat_balance_for_simulation: bool,
    /// Actual six-family getter counts, admitted by the existing no-user type.
    pub no_user_convection_input: super::inside_convection_dispatcher::NoUserConvectionInput,
    /// Actual HeatBalanceAlgorithm N2 or retained Source constructor default.
    pub low_hconv_limit_w_per_m2_k: f64,
}''')

path = 'crates/ep_runtime/src/runtime.rs'
after[path] = replace(after[path], '            input.do_space_heat_balance_for_simulation,\n        )',
    '            input.do_space_heat_balance_for_simulation,\n            input.no_user_convection_input,\n            input.low_hconv_limit_w_per_m2_k,\n        )')

path = 'crates/ep_runtime/src/heat_balance/ordinary_inside_temperatures.rs'
after[path] = replace(after[path], 'use super::inside_convection_dispatcher::SpaceAirTemperatures;',
    'use super::inside_convection_dispatcher::{NoUserConvectionInput, SpaceAirTemperatures};')
after[path] = replace(after[path], '    pub(crate) space_air: SpaceAirTemperatures,\n',
    '''    pub(crate) space_air: SpaceAirTemperatures,
    /// Actual raw no-user input admission retained for the future dispatcher.
    pub(crate) no_user_convection_input: NoUserConvectionInput,
    /// Actual project input owner; this unit does not activate its consumer.
    pub(crate) low_hconv_limit_w_per_m2_k: f64,
''')
after[path] = replace(after[path], '    fn allocate(layout: InsideConvectionLayout) -> Result<Self, Unavailable> {\n',
    '''    fn allocate(
        layout: InsideConvectionLayout,
        no_user_convection_input: NoUserConvectionInput,
        low_hconv_limit_w_per_m2_k: f64,
    ) -> Result<Self, Unavailable> {
        validate_convection_inputs(no_user_convection_input, low_hconv_limit_w_per_m2_k)?;
''')
after[path] = replace(after[path], '            space_air: SpaceAirTemperatures::allocate(&layout),\n',
    '            space_air: SpaceAirTemperatures::allocate(&layout),\n            no_user_convection_input,\n            low_hconv_limit_w_per_m2_k,\n')
validation = prior[path].split('fn validate_convection_inputs(', 1)[1].split('fn admit_config(', 1)[0]
after[path] = replace(after[path], 'fn admit_config(', 'fn validate_convection_inputs(' + validation + 'fn admit_config(')
after[path] = replace(after[path], '    space_simulation: bool,\n) -> Result<(), Unavailable>',
    '    space_simulation: bool,\n    no_user_convection_input: NoUserConvectionInput,\n    low_hconv_limit_w_per_m2_k: f64,\n) -> Result<(), Unavailable>')
after[path] = replace(after[path], '    let owner = OrdinaryInsideTemperatures::allocate(layout)?;',
    '''    let owner = OrdinaryInsideTemperatures::allocate(
        layout, no_user_convection_input, low_hconv_limit_w_per_m2_k,
    )?;''')
after[path] = replace(after[path], '    owner.validate_zones(zones)?;\n    let current',
    '    owner.validate_zones(zones)?;\n    validate_convection_inputs(owner.no_user_convection_input, owner.low_hconv_limit_w_per_m2_k)?;\n    let current')

path = 'crates/ep_runtime/src/heat_balance/ordinary_inside_temperatures_tests.rs'
after[path] = replace(after[path], 'OrdinaryInsideTemperatures::allocate(layout()?)',
    'OrdinaryInsideTemperatures::allocate(layout()?, NoUserConvectionInput::new([0; 6])?, 0.1)')
after[path] = replace(after[path], '        two_spaces(SpaceId(1)).map_err(|_| "invalid input layout")?,\n    )',
    '        two_spaces(SpaceId(1)).map_err(|_| "invalid input layout")?,\n        NoUserConvectionInput::new([0; 6])?, 0.1,\n    )')
# These are authored constructor inputs, not Native expected temperatures. The
# frozen fixture, all its checks and every Native-replay comment remain exact.
after[path] = replace(after[path], 'OrdinaryInsideTemperatures::allocate(layout).map_err',
    'OrdinaryInsideTemperatures::allocate(layout, NoUserConvectionInput::new([0; 6])?, 0.1).map_err')
marker = '// Replay actual selected Native before/after owners through the private'
assert replace(after[path].split(marker, 1)[1],
    'OrdinaryInsideTemperatures::allocate(layout, NoUserConvectionInput::new([0; 6])?, 0.1).map_err',
    'OrdinaryInsideTemperatures::allocate(layout).map_err') == before[path].split(marker, 1)[1]

path = 'crates/ep_runtime/src/runtime/tests/warmup_ordinary_reports.rs'
after[path] = replace(after[path], 'do_space_heat_balance_for_simulation:false})?',
    '''do_space_heat_balance_for_simulation:false,
                    no_user_convection_input:crate::heat_balance::inside_convection_dispatcher::NoUserConvectionInput::new([0;6])?,
                    low_hconv_limit_w_per_m2_k:0.375})?''')
after[path] = replace(after[path], '        assert_eq!(temperatures.inside_old.len(),simulation.state.surfaces.len());',
    '''        assert_eq!(temperatures.inside_old.len(),simulation.state.surfaces.len());
        assert_eq!(temperatures.no_user_convection_input.counts(),[0;6]);
        assert_eq!(temperatures.low_hconv_limit_w_per_m2_k.to_bits(),0.375_f64.to_bits());''')
validation = prior[path].split('    let original_low_limit = owner.low_hconv_limit_w_per_m2_k;', 1)[1].split('    let original_id = state.surfaces.first()', 1)[0]
after[path] = replace(after[path], '    let original_id = state.surfaces.first()',
    '    let original_low_limit = owner.low_hconv_limit_w_per_m2_k;' + validation + '    let original_id = state.surfaces.first()')

# Validate every actual base before any preparation output. No canonical write.
for path in before:
    assert ref(ROOT / path) == actual_refs[path]
assert ref(fixture) == fixture_ref
OUT.mkdir(parents=True)
rows = []
for index, path in enumerate(before):
    base = OUT / 'actual-bases' / path
    proposed = OUT / 'proposed' / path
    base.parent.mkdir(parents=True, exist_ok=True)
    proposed.parent.mkdir(parents=True, exist_ok=True)
    base.write_bytes((ROOT / path).read_bytes())
    proposed.write_bytes(after[path].encode('utf-8'))
    if path.endswith('/ordinary_inside_temperatures_tests.rs'):
        assert proposed.read_bytes().split(marker.encode(), 1)[1].replace(
            b'OrdinaryInsideTemperatures::allocate(layout, NoUserConvectionInput::new([0; 6])?, 0.1).map_err',
            b'OrdinaryInsideTemperatures::allocate(layout).map_err') == base.read_bytes().split(marker.encode(), 1)[1]
    diff = OUT / f'{index:02}.diff'
    diff.write_text(''.join(difflib.unified_diff(before[path].splitlines(True), after[path].splitlines(True),
        fromfile='a/' + path, tofile='b/' + path)), encoding='utf-8', newline='\n')
    rows.append({'canonical_path': path, 'actual_before': actual_refs[path],
        'before_archive': ref(base), 'proposed': ref(proposed), 'direct_diff': ref(diff)})
    assert ref(ROOT / path) == actual_refs[path]
assert ref(fixture) == fixture_ref
readme = OUT / 'README.md'
readme.write_text('''# Held actual-owner04 convection input prerequisite

Fresh six-file delta on actual canonical owner04 after formatting and the actual
19-case Native replay addition. Preparation01 is preserved as anticipated history.
No canonical writes, Rust compilation, formatting or tests were run here.

Semantics remain preparation01: six actual RawModel family counts use existing
NoUserConvectionInput; HeatBalanceAlgorithm N2 retains constructor/blank0.1 or
finite positive input; the existing ordinary runtime validates and retains both.
No readiness/dispatcher/radiation/cadence/temperature algorithm activation occurs.
The independent opt-in scope still rejects overrides of its fixed0.1 setting.

The sole Native replay change is allocate(layout, authored zero counts, authored
0.1). Inverting that exact call change restores its entire prior suffix byte-for-
byte as UTF-8 text. Actual fixture b70b4595 remains unchanged; no expected values
are altered or introduced into production. Original ranges reuse the exact ten
literal archives preserved in01, with full Original Source hashes retained.

After review/application, run affected ep_run warmup_report_controls, ep_runtime
ordinary_inside_temperatures and the existing ordinary-A production regression,
then coordinate one integrated quality run. Existing actual36 focused results
precede this proposed delta and do not validate it.
''', encoding='utf-8', newline='\n')
manifest = {'schema': 'src06-ordinary-convection-input-Source-preparation.v2',
    'status': 'held-Source-only-unexecuted-actual-canonical-bases',
    'historical_preparation01': ref(PARENT / 'manifest.json'),
    'actual_owner04_application_history': ref(ROOT / '.runtime/porting/SRC-06/ordinary-temperature-owner-application-01/application.json'),
    'source_proposals': rows, 'Original_ranges': parent['Original_ranges'],
    'canonical_Native_fixture_unchanged': fixture_ref,
    'Native_replay_delta': 'Only private allocate receives authored NoUserConvectionInput::new([0; 6])? and0.1; all other Native replay Source text preserved exactly',
    'new_canonical_writes': False, 'targets_executed': False, 'QA_executed': False,
    'README': ref(readme), 'author_Source': ref(Path(__file__).resolve())}
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(ref(OUT / 'manifest.json')))

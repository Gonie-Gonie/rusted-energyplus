import collections
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
CAPTURE = Path('D:/CodexBuild/rusted-energyplus/SRC-06/ordinary-temperature-native-capture-01/A-24H.observation.json')
PARSER = ROOT / '.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def ref(path):
    return {'path': path.resolve().as_posix(), 'sha256': sha(path), 'size_bytes': path.stat().st_size}

def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'duplicate JSON key')
        out[key] = value
    return out

need(sha(CAPTURE) == 'cedd5f677b02aa683e62d44c1a08f6a96c175b9b72968da246ef659d0583a19c', 'actual capture changed')
need(sha(PARSER) == '8e7f05196fe567c052352d4d0fe501eb02a0f8e5a623c20f7dcd3db669f6bab8', 'reviewed parser changed')
spec = importlib.util.spec_from_file_location('reference_inventory_stream', PARSER)
stream = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stream)
counts, examples = collections.Counter(), {}
all_events = 0

def visit(event):
    global all_events
    all_events += 1
    if event['checkpoint'] not in ['temperature_reference_returned', 'temperature_reference_stored']:
        return
    clock = event['clock']
    phase = ('kickoff' if clock['KickOffSimulation'] else
             'warmup_first_day' if clock['WarmupFlag'] and clock['DayOfSim'] == 1 else
             'warmup_later_day' if clock['WarmupFlag'] else 'run')
    flag = event['owners']['surface']['SurfTAirRef']
    key = (event['checkpoint'], phase, flag)
    counts[key] += 1
    examples.setdefault(key, {'event_ordinal': event['event_ordinal'], 'procedure': event['procedure'],
                             'invocation_ordinal': event['invocation_ordinal'],
                             'surface': event['owners']['surface']['index']})

terminal = stream.read(CAPTURE, need, unique, visit)
need(terminal['summary']['retained_events'] == all_events, 'full stream event count differs')
out = {'schema': 'src06-actual-reference-branch-inventory.v1',
       'capture': ref(CAPTURE), 'reader': ref(Path(__file__)), 'stream_parser': ref(PARSER),
       'complete_stream_events': all_events,
       'counts': [dict(checkpoint=key[0], phase=key[1], actual_SurfTAirRef=key[2],
                       count=count, first_actual_witness=examples[key])
                  for key, count in sorted(counts.items())],
       'actual_terminal_summary': terminal['summary'],
       'Native_engine_rerun': False, 'Native_assignment_facts_checked': False,
       'Rust_replay_executed': False, 'numerical_PASS_claimed': False, 'gates_updated': False}
output = Path(__file__).with_name('inventory.json')
need(not output.exists(), 'fresh inventory output required')
output.write_text(json.dumps(out, indent=2, allow_nan=False) + '\n', encoding='utf8')
print(json.dumps({'inventory': ref(output), 'complete_stream_events': all_events, 'counts': out['counts']}))

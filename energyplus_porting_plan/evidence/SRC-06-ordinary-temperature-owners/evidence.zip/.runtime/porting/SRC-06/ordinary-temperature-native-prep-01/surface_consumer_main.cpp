#include "surface_consumer_observer.hh"
#include <EnergyPlus/api/EnergyPlusPgm.hh>
#include <CLI/CLI11.hpp>
#include <nlohmann/json.hpp>
#include <filesystem>
#include <exception>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

int main(int argc, char **argv)
{
#ifdef _WIN32
    (void)argc;
    (void)argv;
    auto const args = CLI::detail::compute_win32_argv();
#else
    std::vector<std::string> const args(argv, std::next(argv, static_cast<std::ptrdiff_t>(argc)));
#endif
    if (args.size() < 5 || args[1] != "--surface-observation-file" || args[3] != "--") {
        std::cerr << "usage: helper --surface-observation-file FRESH.json -- ACTUAL_ENERGYPLUS_ARGS\n";
        return 64;
    }
    // Preserve every genuine native option after the explicit transport separator.
    std::vector<std::string> native_args{args[0]};
    native_args.insert(native_args.end(), args.begin() + 4, args.end());
    auto const output_path = std::filesystem::absolute(args[2]);
    if (std::filesystem::exists(output_path) || !std::filesystem::is_directory(output_path.parent_path())) {
        std::cerr << "observation file must be fresh with an existing parent\n";
        return 64;
    }
    std::ofstream output(output_path, std::ios::binary);
    if (!output) return 74;
    output << "{\"schema\":\"ctf10-surface-consumer-native-observation.v1\",\"actual_native_arguments\":"
           << nlohmann::json(native_args).dump() << ",\"events\":[";
    SurfaceConsumerObservation::Capture capture(output);
    SurfaceConsumerObservation::Binding binding(capture);
    bool returned = false;
    int native_exit = 0; // Unavailable unless the actual engine entry returns.
    char const *exception_class = nullptr;
    try {
        native_exit = ::EnergyPlusPgm(native_args);
        returned = true;
    } catch (std::exception const &) {
        exception_class = "std::exception";
    } catch (...) {
        exception_class = "unknown-exception";
    }
    bool const complete_transport = SurfaceConsumerObservation::finish(capture, returned, native_exit, exception_class);
    if (!complete_transport) return 74;
    if (!returned) return 70;
    return native_exit;
}

// Narrow passive owner capture. No heat-balance expression is evaluated here.
#include "surface_consumer_observer.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataHeatBalSurface.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataSurfaces.hh>
#include <EnergyPlus/HeatBalanceSurfaceManager.hh>
#include <EnergyPlus/ZoneTempPredictorCorrector.hh>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cstring>
#include <exception>
#include <limits>
#include <ostream>

#if !defined(__MINGW32__) || !defined(_WIN64) || __GNUC__ != 13 || __GNUC_MINOR__ != 2
#error "Original private-state reference requires verified GCC13.2 Windows ABI"
#endif
#if defined(_GLIBCXX_DEBUG) || defined(__FAST_MATH__) || defined(NDEBUG)
#error "Reference requires original assertions, nondebug containers and no fast math"
#endif
#if !defined(EP_psych_errors) || defined(EP_psych_stats)
#error "Reference definitions must match the genuine original core"
#endif

namespace SurfaceConsumerObservation {
namespace {
using json = nlohmann::json;
using AirOwner = EnergyPlus::ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData;
thread_local Capture *active = nullptr;
thread_local Scope *current_scope = nullptr;
char const *procedure_name(Procedure p) noexcept
{
    switch (p) {
    case Procedure::Manage: return "ManageSurfaceHeatBalance";
    case Procedure::Initialize: return "InitSurfaceHeatBalance";
    case Procedure::InitializeHistories: return "InitThermalAndFluxHistories";
    case Procedure::UpdateHistories: return "UpdateThermalHistories";
    case Procedure::InsideCTF: return "CalcHeatBalanceInsideSurf2CTFOnly";
    case Procedure::Report: return "ReportSurfaceHeatBalance";
    case Procedure::HVACManage: return "ManageHVAC";
    case Procedure::HVACSimulate: return "SimHVAC";
    case Procedure::ZoneAirDispatch: return "ManageZoneAirUpdates";
    case Procedure::ZoneCorrectAll: return "correctZoneAirTemps";
    case Procedure::ZoneTemperature: return "correctAirTemp";
    case Procedure::ZoneHumidity: return "correctHumRat";
    case Procedure::ZonePush: return "pushZoneTimestepHistory";
    case Procedure::SystemPush: return "pushSystemTimestepHistory";
    case Procedure::ZoneRevert: return "revertZoneTimestepHistory";
    case Procedure::ZoneUpdate: return "updateTemperatures";
    default: return "unknown-observer-procedure";
    }
}
bool increment(std::uint64_t &counter) noexcept
{
    if (counter == std::numeric_limits<std::uint64_t>::max()) {
        active->counter_overflow = true;
        return false;
    }
    ++counter;
    return true;
}
json scalar(double value)
{
    static_assert(sizeof(double) == sizeof(std::uint64_t));
    static_assert(std::numeric_limits<double>::is_iec559);
    std::uint64_t bits;
    std::memcpy(&bits, &value, sizeof(bits));
    char text[17];
    char const *hex = "0123456789abcdef";
    for (unsigned i = 0; i < 16; ++i) text[i] = hex[(bits >> ((15 - i) * 4)) & 15];
    text[16] = '\0';
    auto const magnitude = bits & 0x7fffffffffffffffULL;
    bool const negative = (bits >> 63) != 0;
    char const *kind = magnitude > 0x7ff0000000000000ULL ? "nan" :
        magnitude == 0x7ff0000000000000ULL ? (negative ? "negative_infinity" : "positive_infinity") :
        magnitude == 0 ? (negative ? "negative_zero" : "positive_zero") : "finite";
    return {{"value_bits", text}, {"value_class", kind}};
}
json clock(EnergyPlus::EnergyPlusData const &state)
{
    auto const &g = *state.dataGlobal;
    auto const &e = *state.dataEnvrn;
    auto const &h = *state.dataHVACGlobal;
    return {{"state_address", reinterpret_cast<std::uintptr_t>(&state)},
        {"environment_index", e.CurEnvirNum}, {"environment_name", e.EnvironmentName},
        {"CalendarYear", g.CalendarYear}, {"Month", e.Month}, {"DayOfMonth", e.DayOfMonth},
        {"DayOfSim", g.DayOfSim}, {"HourOfDay", g.HourOfDay}, {"TimeStep", g.TimeStep},
        {"KindOfSim", static_cast<int>(g.KindOfSim)}, {"CurrentTime", scalar(g.CurrentTime)},
        {"TimeStepZone", scalar(g.TimeStepZone)}, {"TimeStepZoneSec", scalar(g.TimeStepZoneSec)},
        {"TimeStepSys", scalar(h.TimeStepSys)}, {"TimeStepSysSec", scalar(h.TimeStepSysSec)},
        {"SysTimeElapsed", scalar(h.SysTimeElapsed)}, {"FracTimeStepZone", scalar(h.FracTimeStepZone)},
        {"FirstTimeStepSysFlag", h.FirstTimeStepSysFlag}, {"ShortenTimeStepSys", h.ShortenTimeStepSys},
        {"UseZoneTimeStepHistory", h.UseZoneTimeStepHistory}, {"NumOfSysTimeSteps", h.NumOfSysTimeSteps},
        {"KickOffSimulation", g.KickOffSimulation}, {"WarmupFlag", g.WarmupFlag},
        {"BeginSimFlag", g.BeginSimFlag}, {"BeginEnvrnFlag", g.BeginEnvrnFlag},
        {"BeginDayFlag", g.BeginDayFlag}, {"BeginHourFlag", g.BeginHourFlag},
        {"BeginTimeStepFlag", g.BeginTimeStepFlag}, {"ZoneSizingCalc", g.ZoneSizingCalc},
        {"InsideSurfIterations", state.dataHeatBal->InsideSurfIterations}};
}
json air_fields(AirOwner const &owner)
{
    return {{"MAT", scalar(owner.MAT)}, {"ZT", scalar(owner.ZT)}, {"ZTAV", scalar(owner.ZTAV)}};
}
template<class Owners> json air_array(Owners const &owners)
{
    json out{{"allocated", owners.allocated()}, {"count", owners.size()}, {"values", nullptr}};
    if (!owners.allocated()) return out;
    out["values"] = json::array();
    for (int index = 1; index <= owners.isize(); ++index) {
        AirOwner const &owner = owners(index);
        out["values"].push_back({{"index", index},
            {"address", reinterpret_cast<std::uintptr_t>(&owner)}, {"fields", air_fields(owner)}});
    }
    return out;
}
json air_copy(EnergyPlus::EnergyPlusData const &state, int zone, int space, AirOwner const *member)
{
    auto const &z = state.dataZoneTempPredictorCorrector->zoneHeatBalance;
    auto const &s = state.dataZoneTempPredictorCorrector->spaceHeatBalance;
    auto const &zg = state.dataHeatBal->Zone;
    auto const &sg = state.dataHeatBal->space;
    json out{{"NumOfZones", state.dataGlobal->NumOfZones}, {"numSpaces", state.dataGlobal->numSpaces},
        {"ZoneAirSolutionAlgo", static_cast<int>(state.dataHeatBal->ZoneAirSolutionAlgo)},
        {"doSpaceHeatBalance", state.dataHeatBal->doSpaceHeatBalance},
        {"doSpaceHeatBalanceSizing", state.dataHeatBal->doSpaceHeatBalanceSizing},
        {"doSpaceHeatBalanceSimulation", state.dataHeatBal->doSpaceHeatBalanceSimulation},
        {"DoingSizing", state.dataGlobal->DoingSizing},
        {"zone_owners", air_array(z)}, {"space_owners", air_array(s)},
        {"zone_geometry_allocated", zg.allocated()}, {"zone_geometry_count", zg.size()},
        {"space_geometry_allocated", sg.allocated()}, {"space_geometry_count", sg.size()},
        {"zone_geometry", json::array()}, {"space_geometry", json::array()}};
    if (zg.allocated()) for (int i = 1; i <= zg.isize(); ++i)
        out["zone_geometry"].push_back({{"index", i}, {"Name", zg(i).Name}, {"spaceIndexes", zg(i).spaceIndexes}});
    if (sg.allocated()) for (int i = 1; i <= sg.isize(); ++i)
        out["space_geometry"].push_back({{"index", i}, {"Name", sg(i).Name}, {"zoneNum", sg(i).zoneNum}});
    AirOwner const *selected = nullptr;
    if (space == 0 && zone > 0 && z.allocated() && zone <= z.isize()) selected = &z(zone);
    if (space > 0 && s.allocated() && space <= s.isize()) selected = &s(space);
    json selection{{"requested_zone", zone}, {"requested_space", space},
        {"member_address", member ? json(reinterpret_cast<std::uintptr_t>(member)) : json(nullptr)},
        {"selected_owner_available", selected != nullptr},
        {"selected_owner_kind", selected ? json(space == 0 ? "Zone" : "Space") : json(nullptr)},
        {"selected_owner_address", selected ? json(reinterpret_cast<std::uintptr_t>(selected)) : json(nullptr)},
        {"member_matches_selected", member && selected ? json(member == selected) : json(nullptr)},
        {"space_in_zone_spaceIndexes", nullptr}, {"space_geometry_zone_matches", nullptr}};
    if (space > 0 && zone > 0 && zg.allocated() && zone <= zg.isize()) {
        auto const &indices = zg(zone).spaceIndexes;
        selection["space_in_zone_spaceIndexes"] = std::find(indices.begin(), indices.end(), space) != indices.end();
    }
    if (space > 0 && sg.allocated() && space <= sg.isize())
        selection["space_geometry_zone_matches"] = sg(space).zoneNum == zone;
    out["selection"] = selection;
    return out;
}
template<class Array> json real_at(Array const &values, int index)
{
    if (!values.allocated() || !values.contains(index)) return nullptr;
    return scalar(values(index));
}
// Same complete allocated-array traversal as Native05; no AllHT-only filter.
template<class Array> json allocated_array_copy(Array const &values)
{
    json out{{"allocated", values.allocated()}, {"lower", nullptr}, {"upper", nullptr}, {"values", nullptr},
        {"array_address", reinterpret_cast<std::uintptr_t>(&values)},
        {"storage_address", values.data() ? json(reinterpret_cast<std::uintptr_t>(values.data())) : json(nullptr)}};
    if (!values.allocated()) return out;
    out["lower"] = values.l(); out["upper"] = values.u(); out["values"] = json::array();
    for (int index = values.l(); index <= values.u(); ++index)
        out["values"].push_back({{"index", index}, {"value", scalar(values(index))}});
    return out;
}
json surface_copy(EnergyPlus::EnergyPlusData const &state, int surface)
{
    auto const &values = state.dataSurface->Surface;
    json out{{"requested_surface", surface}, {"available", false}};
    if (!values.allocated() || surface < 1 || surface > values.isize()) return out;
    auto const &s = values(surface);
    auto const &ref = state.dataSurface->SurfTAirRef;
    out["available"] = true;
    out["index"] = surface; out["Zone"] = s.Zone; out["spaceNum"] = s.spaceNum;
    out["SurfTAirRef"] = ref.allocated() && ref.contains(surface) ? json(static_cast<int>(ref(surface))) : json(nullptr);
    out["RefAirTemp"] = real_at(state.dataHeatBalSurfMgr->RefAirTemp, surface);
    out["SurfTempEffBulkAir"] = real_at(state.dataHeatBal->SurfTempEffBulkAir, surface);
    return out;
}
json surface_geometry(EnergyPlus::EnergyPlusData const &state)
{
    auto const &values = state.dataSurface->Surface;
    json out{{"allocated", values.allocated()}, {"count", values.size()}, {"values", nullptr},
        {"AllHTSurfaceList", state.dataSurface->AllHTSurfaceList}};
    if (!values.allocated()) return out;
    out["values"] = json::array();
    for (int index = 1; index <= values.isize(); ++index) {
        auto const &s = values(index);
        out["values"].push_back({{"index", index}, {"Name", s.Name}, {"Zone", s.Zone}, {"spaceNum", s.spaceNum},
            {"Class", static_cast<int>(s.Class)}, {"HeatTransferAlgorithm", static_cast<int>(s.HeatTransferAlgorithm)}});
    }
    return out;
}
} // namespace
Binding::Binding(Capture &capture) noexcept : previous(active) { active = &capture; }
Binding::~Binding() noexcept { active = previous; }
Scope::Scope(EnergyPlus::EnergyPlusData &, Procedure p) noexcept
    : procedure(p), parent(current_scope), exceptions_on_entry(std::uncaught_exceptions())
{
    current_scope = this;
    if (active) {
        auto &calls = active->procedure_calls[static_cast<unsigned>(procedure)];
        if (increment(calls)) ordinal = calls;
    }
}
Scope::~Scope() noexcept
{
    if (active) {
        auto &counts = std::uncaught_exceptions() > exceptions_on_entry ? active->scope_unwinds : active->scope_normal_exits;
        increment(counts[static_cast<unsigned>(procedure)]);
    }
    current_scope = parent;
}
void record_temperatures(EnergyPlus::EnergyPlusData &state, char const *checkpoint, int zone, int space,
    AirOwner const *member, int surface, bool full_surface_arrays,
    std::initializer_list<RealField> reals, std::initializer_list<IntegerField> integers) noexcept
{
    if (!active) return;
    if (!increment(active->attempted_events)) return;
    auto const ordinal = active->attempted_events;
    try {
        json event{{"event_ordinal", ordinal}, {"checkpoint", checkpoint},
            {"temperature_owner_protocol", "src06-ordinary-temperature-owner-native.v1"}, {"clock", clock(state)},
            {"procedure", current_scope ? json(procedure_name(current_scope->procedure)) : json(nullptr)},
            {"invocation_ordinal", current_scope ? json(current_scope->ordinal) : json(nullptr)},
            {"parent_procedure", current_scope && current_scope->parent ? json(procedure_name(current_scope->parent->procedure)) : json(nullptr)},
            {"parent_invocation_ordinal", current_scope && current_scope->parent ? json(current_scope->parent->ordinal) : json(nullptr)},
            {"locals", json::object()}, {"owners", {{"air", air_copy(state, zone, space, member)},
                {"surface", surface != 0 ? surface_copy(state, surface) : json(nullptr)},
                {"surface_arrays", nullptr}, {"surface_geometry", nullptr}}}, {"counted_as_PASS", false}};
        for (auto const &r : reals) event["locals"][r.name] = scalar(r.value);
        for (auto const &i : integers) event["locals"][i.name] = i.value;
        if (full_surface_arrays) {
            event["owners"]["surface_arrays"] = {
                {"SurfTempIn", allocated_array_copy(state.dataHeatBalSurf->SurfTempIn)},
                {"SurfTempInsOld", allocated_array_copy(state.dataHeatBalSurf->SurfTempInsOld)}};
            event["owners"]["surface_geometry"] = surface_geometry(state);
        }
        auto const bytes = event.dump();
        if (!active->first_event) active->output << ',';
        active->output << bytes;
        if (!active->output) {
            active->stream_failed = true;
            increment(active->stream_failed_events);
            return;
        }
        active->first_event = false;
        increment(active->retained_events);
    } catch (...) {
        increment(active->copy_failures);
        if (active->first_failed_event == 0) active->first_failed_event = ordinal;
        active->last_failed_event = ordinal;
    }
}
bool finish(Capture &capture, bool returned, int exit_code, char const *caught) noexcept
{
    try {
        json names = json::array();
        for (unsigned i = 0; i < static_cast<unsigned>(Procedure::Count); ++i)
            names.push_back(procedure_name(static_cast<Procedure>(i)));
        json summary{{"temperature_owner_protocol", "src06-ordinary-temperature-owner-native.v1"},
            {"capture_selection", "allocation-reset-MAT-commit-disabled-space-copy-reference-8809-only"},
            {"actual_engine_entry_returned", returned}, {"actual_engine_exit_code", returned ? json(exit_code) : json(nullptr)},
            {"outer_caught_exception_class", caught ? json(caught) : json(nullptr)}, {"procedure_names", names},
            {"procedure_calls", capture.procedure_calls}, {"scope_normal_exits", capture.scope_normal_exits},
            {"scope_unwinds", capture.scope_unwinds}, {"attempted_events", capture.attempted_events},
            {"retained_events", capture.retained_events}, {"copy_failures", capture.copy_failures},
            {"first_failed_event", capture.first_failed_event}, {"last_failed_event", capture.last_failed_event},
            {"stream_failed_events", capture.stream_failed_events}, {"counter_overflow", capture.counter_overflow},
            {"stream_failed", capture.stream_failed}, {"full_ZTAV_accumulation_observed", false},
            {"all_source_calls_or_complete_history_lifecycle_certified", false},
            {"numeric_profiles_chosen", false}, {"integration_PASS_claimed", false}};
        capture.output << "],\"summary\":" << summary.dump() << '}';
        capture.output.flush();
        return static_cast<bool>(capture.output) && !capture.stream_failed && !capture.counter_overflow && capture.copy_failures == 0;
    } catch (...) { return false; }
}
} // namespace SurfaceConsumerObservation

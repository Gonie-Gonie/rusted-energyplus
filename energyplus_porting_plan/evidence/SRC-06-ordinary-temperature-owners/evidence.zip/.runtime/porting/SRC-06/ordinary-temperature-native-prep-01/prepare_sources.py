"""Emit one held, narrow Original temperature observer. No target is imported/run."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
PARENT = ROOT / '.runtime/porting/CTF-10/surface-consumer-native-prep-06'
ORIGINAL = ROOT / '.reference/energyplus-src/26.1.0/src/EnergyPlus'
PARENT_SHA = '96f2cfd23045889e0164a9b007af796b64c0f59dea3bb35d131fbc2fa8252fc3'
EXPECTED = {
    'HeatBalanceSurfaceManager.cc': '0d50903b9cebab76608a76c8643a4686f94f053c82030d7577d652971b67f73c',
    'ZoneTempPredictorCorrector.cc': '9b0aff100fff104dcf9268b46328c1bda5452a28894a6ecb1385bb63ef975ab6',
    'HVACManager.cc': '1a0db29afb07a4fc7ff5619a1419ca7f5bdf13251917c616ad2dd9c3a9355954',
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(data),
            'size_bytes': len(data), 'line_count': len(data.splitlines())}

def write(name, text):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode('utf-8'))
    return path

def diff(before, after, old_name, new_name):
    return ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                      fromfile=old_name, tofile=new_name))

assert sha((PARENT / 'manifest.json').read_bytes()) == PARENT_SHA
old_hb = json.loads((PARENT / 'additions.json').read_bytes())
old_callers = json.loads((PARENT / 'zone-caller-additions.json').read_bytes())
originals = {name: (ORIGINAL / name).read_bytes() for name in EXPECTED}
for name, data in originals.items():
    assert sha(data) == EXPECTED[name], name

# Only exact existing include and Scope blocks survive from Native06. No legacy
# record/record_zone call or full-history/42-field payload is carried forward.
selected = {
    'HeatBalanceSurfaceManager.cc': [x for x in old_hb if '#include' in x['insertion'] or '::Scope ' in x['insertion']],
    **{name: [x for x in rows if '#include' in x['insertion'] or '::Scope ' in x['insertion']]
       for name, rows in old_callers.items()},
}
scope_counts = {name: sum('::Scope ' in x['insertion'] for x in rows) for name, rows in selected.items()}
assert scope_counts == {'HeatBalanceSurfaceManager.cc': 6, 'ZoneTempPredictorCorrector.cc': 8, 'HVACManager.cc': 2}
new_rows = []

def add(name, line, tag, statement):
    anchor = originals[name].decode('utf-8').splitlines(True)[line - 1]
    row = {'after_original_line': line, 'tag': tag, 'source_anchor': anchor,
           'insertion': f'// TEMPERATURE_OWNER_OBSERVER_BEGIN {tag}\n{statement}\n// TEMPERATURE_OWNER_OBSERVER_END {tag}\n'}
    selected[name].append(row)
    new_rows.append({'Original': name, **row})

def call(tag, args='0, 0, nullptr, 0, true'):
    return f'    ::SurfaceConsumerObservation::record_temperatures(state, "{tag}", {args});'

hb = 'HeatBalanceSurfaceManager.cc'
zt = 'ZoneTempPredictorCorrector.cc'
add(hb, 1444, 'temperature_surface_allocation_complete', call('temperature_surface_allocation_complete'))
add(hb, 2230, 'temperature_air_reset_before', call('temperature_air_reset_before'))
add(hb, 2249, 'temperature_air_reset_after', call('temperature_air_reset_after'))
for line, tag in [(4117, 'temperature_mat_commit_before'), (4118, 'temperature_mat_commit_after')]:
    add(zt, line, tag, call(tag, 'zoneNum, spaceNum, this, 0, false, {}, {{"useZoneTimeStepHistory", useZoneTimeStepHistory}}'))
for line, tag in [(3842, 'temperature_space_copy_before'), (3845, 'temperature_space_copy_after')]:
    add(zt, line, tag, call(tag, 'zoneNum, spaceNum, &thisSpaceHB, 0, false, {}, {{"useZoneTimeStepHistory", useZoneTimeStepHistory}}'))

# Original optional input is emitted only when present; an absent optional is
# represented by its false presence witness and no invented integer value.
def inside_call(tag, args, reals='{}'):
    base = f'{{{{"FirstZone", FirstZone}}, {{"LastZone", LastZone}}, {{"IZSurfs_size", static_cast<std::int64_t>(IZSurfs.size())}}, {{"ZoneToResimulate_present", static_cast<int>(ZoneToResimulate.present())}}'
    with_value = base + ', {"ZoneToResimulate", ZoneToResimulate()}}'
    without_value = base + '}'
    return ('    if (ZoneToResimulate.present()) {\n'
            f'        ::SurfaceConsumerObservation::record_temperatures(state, "{tag}", {args}, {reals}, {with_value});\n'
            '    } else {\n'
            f'        ::SurfaceConsumerObservation::record_temperatures(state, "{tag}", {args}, {reals}, {without_value});\n'
            '    }')

for line, tag in [(8739, 'temperature_reference_returned'), (8741, 'temperature_reference_stored')]:
    add(hb, line, tag, inside_call(tag, 'zoneNum, spaceNum, nullptr, surfNum, false', '{{"RefAirTemp", RefAirTemp}}'))
for line, tag in [(8808, 'temperature_old_copy_before'), (8809, 'temperature_old_copy_after')]:
    add(hb, line, tag, inside_call(tag, '0, 0, nullptr, 0, true'))

diff_refs = []
derived_refs = []
inverse_rows = []
for name, rows in selected.items():
    original = originals[name].decode('utf-8')
    lines = original.splitlines(True)
    # Stable sorting keeps the inherited Scope block before any later same-line addition.
    rows.sort(key=lambda x: x['after_original_line'])
    buckets = {}
    for row in rows:
        assert lines[row['after_original_line'] - 1] == row['source_anchor'], row['tag']
        assert '::record(' not in row['insertion'] and '::record_zone(' not in row['insertion']
        buckets.setdefault(row['after_original_line'], []).append(row['insertion'])
    derived = ''.join(line + ''.join(buckets.get(i, [])) for i, line in enumerate(lines, 1))
    restored = derived
    for row in rows:
        assert restored.count(row['insertion']) == 1, row['tag']
        restored = restored.replace(row['insertion'], '', 1)
    assert restored == original, name
    out_name = name.replace('.cc', '.surface_consumer.cc')
    derived_refs.append(ref(write(out_name, derived)))
    diff_refs.append(ref(write('diffs/' + name + '.Original.diff', diff(original, derived, name, out_name))))
    inverse_rows.append({'Original': ref(ORIGINAL / name), 'derived': derived_refs[-1],
                         'complete_inverse_byte_exact': True, 'inherited_scope_count': scope_counts[name]})

# Actual global engine entry and ordinary argument transport remain exact Native05/06.
(OUT / 'surface_consumer_main.cpp').write_bytes((PARENT / 'surface_consumer_main.cpp').read_bytes())
for name in ('surface_consumer_observer.cc', 'surface_consumer_observer.hh'):
    before = (PARENT / name).read_bytes().decode('utf-8')
    after = (OUT / name).read_bytes().decode('utf-8')
    diff_refs.append(ref(write('diffs/' + name + '.Native06.diff', diff(before, after, 'Native06/' + name, name))))
write('source-additions.json', json.dumps(selected, indent=2, ensure_ascii=False) + '\n')
write('boundary-contract.json', json.dumps({
    'protocol': 'src06-ordinary-temperature-owner-native.v1',
    'new_Original_boundaries': new_rows,
    'owner_fields': ['MAT', 'ZT', 'ZTAV'],
    'full_arrays': ['SurfTempIn', 'SurfTempInsOld'],
    'full_ZTAV_accumulation_observed': False,
    'ZTM_is_outside_selected_fields_and_is_written_at_Original3844': True,
}, indent=2) + '\n')
payload_names = ['surface_consumer_main.cpp', 'surface_consumer_observer.hh', 'surface_consumer_observer.cc',
                 'HeatBalanceSurfaceManager.surface_consumer.cc', 'ZoneTempPredictorCorrector.surface_consumer.cc',
                 'HVACManager.surface_consumer.cc', 'ordinary_temperature_reference.cmake']
assert len(new_rows) == 11
manifest = {
    'schema': 'src06-ordinary-temperature-native-Source-preparation.v1',
    'status': 'held-Source-only-no-configure-build-engine-execution',
    'parent_Native06_manifest': ref(PARENT / 'manifest.json'),
    'Rust_Source_snapshot': {'path': '.runtime/porting/source-objects/d7/d70e015d5808030720233b32aa8d3b7777a414a3ad6625423c6df8f9b899e914',
                             'sha256': 'd70e015d5808030720233b32aa8d3b7777a414a3ad6625423c6df8f9b899e914'},
    'target': 'ordinary_temperature_owner_helper',
    'scope': 'unchanged ordinary A-24H full engine input; all actual calls at eleven selected temperature boundaries',
    'payload': [ref(OUT / name) for name in payload_names],
    'unchanged_Original_target_TUs': [ref(ORIGINAL / 'api/EnergyPlusPgm.cc'), ref(ORIGINAL / 'CommandLineInterface.cc')],
    'inherited_inputs': [ref(PARENT / 'additions.json'), ref(PARENT / 'zone-caller-additions.json'),
                         ref(PARENT / 'surface_consumer_main.cpp')],
    'Original_inverse_checks': inverse_rows,
    'complete_diffs': diff_refs,
    'source_additions': ref(OUT / 'source-additions.json'),
    'boundary_contract': ref(OUT / 'boundary-contract.json'),
    'authoring_Source': ref(Path(__file__).resolve()),
    'README': ref(OUT / 'README.md'),
    'new_tag_count': 11, 'inherited_Scope_count': 16,
    'legacy_history_payload_collected': False, 'legacy_42_field_payload_collected': False,
    'full_ZTAV_accumulation_observed': False,
    'Source_inverse_checked': True, 'Native_target_imported_or_executed': False,
    'canonical_Rust_or_Original_modified': False, 'integration_PASS_claimed': False, 'gates_updated': False,
}
write('manifest.json', json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifest': ref(OUT / 'manifest.json'), 'new_tag_count': 11, 'target_TUs': 7}))

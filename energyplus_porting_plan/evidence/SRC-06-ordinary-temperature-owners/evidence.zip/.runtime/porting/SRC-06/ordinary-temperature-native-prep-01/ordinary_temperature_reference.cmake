# One additive seven-TU target. The caller first includes the current project chain.
if(NOT DEFINED ORDINARY_TEMPERATURE_SOURCE_DIR OR NOT DEFINED ORDINARY_TEMPERATURE_OUTPUT_DIR)
  message(FATAL_ERROR "Temperature capture requires explicit reviewed Source and fresh D output directories")
endif()
if(CMAKE_SOURCE_DIR STREQUAL PROJECT_SOURCE_DIR)
  get_property(_ordinary_temperature_scheduled GLOBAL PROPERTY ORDINARY_TEMPERATURE_SCHEDULED)
  if(NOT _ordinary_temperature_scheduled)
    set_property(GLOBAL PROPERTY ORDINARY_TEMPERATURE_SCHEDULED TRUE)
    function(ordinary_temperature_add_reference)
      if(NOT TARGET energypluslib)
        message(FATAL_ERROR "Temperature capture requires genuine unchanged energypluslib")
      endif()
      get_target_property(_ordinary_temperature_defs energypluslib COMPILE_DEFINITIONS)
      get_directory_property(_ordinary_temperature_dir_defs DIRECTORY "${CMAKE_SOURCE_DIR}/src/EnergyPlus" COMPILE_DEFINITIONS)
      list(APPEND _ordinary_temperature_defs ${_ordinary_temperature_dir_defs})
      list(FILTER _ordinary_temperature_defs EXCLUDE REGEX "-NOTFOUND$")
      list(REMOVE_DUPLICATES _ordinary_temperature_defs)
      add_executable(ordinary_temperature_owner_helper
        "${ORDINARY_TEMPERATURE_SOURCE_DIR}/surface_consumer_main.cpp"
        "${ORDINARY_TEMPERATURE_SOURCE_DIR}/HeatBalanceSurfaceManager.surface_consumer.cc"
        "${ORDINARY_TEMPERATURE_SOURCE_DIR}/surface_consumer_observer.cc"
        "${ORDINARY_TEMPERATURE_SOURCE_DIR}/ZoneTempPredictorCorrector.surface_consumer.cc"
        "${ORDINARY_TEMPERATURE_SOURCE_DIR}/HVACManager.surface_consumer.cc"
        "${CMAKE_SOURCE_DIR}/src/EnergyPlus/api/EnergyPlusPgm.cc"
        "${CMAKE_SOURCE_DIR}/src/EnergyPlus/CommandLineInterface.cc")
      target_include_directories(ordinary_temperature_owner_helper PRIVATE
        "$<TARGET_PROPERTY:energypluslib,INCLUDE_DIRECTORIES>" "${ORDINARY_TEMPERATURE_SOURCE_DIR}")
      target_compile_definitions(ordinary_temperature_owner_helper PRIVATE ${_ordinary_temperature_defs} ENERGYPLUS_STATIC_API)
      target_link_libraries(ordinary_temperature_owner_helper PRIVATE energypluslib project_options project_fp_options project_warnings bcrypt)
      target_compile_features(ordinary_temperature_owner_helper PRIVATE cxx_std_20)
      set_target_properties(ordinary_temperature_owner_helper PROPERTIES
        RUNTIME_OUTPUT_DIRECTORY "${ORDINARY_TEMPERATURE_OUTPUT_DIR}")
      target_link_options(ordinary_temperature_owner_helper PRIVATE
        "-Wl,-Map,${ORDINARY_TEMPERATURE_OUTPUT_DIR}/ordinary_temperature_owner_helper.map")
    endfunction()
    cmake_language(DEFER CALL ordinary_temperature_add_reference)
  endif()
endif()

#pragma once

#include <array>
#include <cstdint>
#include <initializer_list>
#include <iosfwd>

namespace EnergyPlus { struct EnergyPlusData;
namespace ZoneTempPredictorCorrector { struct ZoneSpaceHeatBalanceData; } }

namespace SurfaceConsumerObservation {

// Ordering is exact Native06. A count records an actual entered scope, not a return.
enum class Procedure { Manage, Initialize, InitializeHistories, UpdateHistories, InsideCTF, Report, HVACManage, HVACSimulate, ZoneAirDispatch, ZoneCorrectAll, ZoneTemperature, ZoneHumidity, ZonePush, SystemPush, ZoneRevert, ZoneUpdate, Count };
struct RealField { char const *name; double value; };
struct IntegerField { char const *name; std::int64_t value; };
struct Capture {
    explicit Capture(std::ostream &output) noexcept : output(output) {}
    std::ostream &output;
    std::array<std::uint64_t, static_cast<unsigned>(Procedure::Count)> procedure_calls{};
    std::array<std::uint64_t, static_cast<unsigned>(Procedure::Count)> scope_normal_exits{};
    std::array<std::uint64_t, static_cast<unsigned>(Procedure::Count)> scope_unwinds{};
    std::uint64_t attempted_events = 0;
    std::uint64_t retained_events = 0;
    std::uint64_t copy_failures = 0;
    std::uint64_t first_failed_event = 0;
    std::uint64_t last_failed_event = 0;
    std::uint64_t stream_failed_events = 0;
    bool counter_overflow = false;
    bool first_event = true;
    bool stream_failed = false;
};
class Binding {
public:
    explicit Binding(Capture &) noexcept;
    ~Binding() noexcept;
    Binding(Binding const &) = delete;
    Binding &operator=(Binding const &) = delete;
private:
    Capture *previous;
};
class Scope {
public:
    Scope(EnergyPlus::EnergyPlusData &, Procedure) noexcept;
    ~Scope() noexcept;
    Scope(Scope const &) = delete;
    Scope &operator=(Scope const &) = delete;
    Procedure procedure;
    std::uint64_t ordinal = 0;
    Scope *parent = nullptr;
private:
    int exceptions_on_entry;
};
// Copy actual selected owners only; this function never calls a model producer.
void record_temperatures(EnergyPlus::EnergyPlusData &, char const *checkpoint,
    int zone = 0, int space = 0,
    EnergyPlus::ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData const *member = nullptr,
    int surface = 0, bool full_surface_arrays = false,
    std::initializer_list<RealField> reals = {},
    std::initializer_list<IntegerField> integers = {}) noexcept;
bool finish(Capture &, bool engine_returned, int engine_exit_code,
            char const *caught_exception_class) noexcept;
} // namespace SurfaceConsumerObservation

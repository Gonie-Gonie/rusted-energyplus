# Narrow ordinary temperature owner observation: held Source only

This is one seven-TU Native observer for the unchanged ordinary A-24H full
engine run. It does not run a Rust owner, change production, replace an
Original calculation, select a numerical tolerance, or claim integration PASS.
The Source is prepared for Root and independent review before execution.

The complete HBSM, ZTP and HVACManager TUs come from the pinned 26.1.0 Originals.
Their sixteen Scope blocks and three includes are exact existing Native06
insertions. All other Native05/06 record sites are omitted. Eleven new passive
checkpoint kinds stream actual selected temperature owners; there is no full
history, forty-two-field air payload, sampling, event cap, shortened simulation,
or fixed call-count assumption. Removing every listed insertion restores each
Original TU byte for byte. The small main is byte-exact Native05/06: the actual
global EnergyPlusPgm entry and all ordinary arguments after -- are preserved.

| New checkpoint | Insert after actual Original line | Meaning |
| --- | --- | --- |
| temperature_surface_allocation_complete | HBSM1444 | Actual separately allocated In/Old after their zero initialization |
| temperature_air_reset_before | HBSM2230 | Before Zone2233 and Space2245 constructor resets |
| temperature_air_reset_after | HBSM2249 | After both constructor loops, before surface bulk initialization2251 |
| temperature_mat_commit_before / after | ZTP4117 / 4118 | Actual selected member immediately around MAT = ZT, before humidity4128 |
| temperature_space_copy_before / after | ZTP3842 / 3845 | Actual disabled-space/sizing branch around ZT/ZTM/MAT copy; selected ZTAV is retained |
| temperature_reference_returned / stored | HBSM8739 / 8741 | One real getter return, then actual RefAirTemp and SurfTempEffBulkAir stores |
| temperature_old_copy_before / after | HBSM8808 / 8809 | Complete allocated In/Old around full-array assignment, before radiation8811 |

All event scalar DTOs contain authoritative value_bits and value_class.
Each event includes raw environment/zone/system clock owners, actual current
and parent procedure/invocation ordinals, selected locals, and actual allocated
Zone/Space MAT/ZT/ZTAV arrays. Air EPVector selection uses allocated/count and
one-based actual indices. Requested member pointers are compared with the
actual allocated element; unavailable owners remain explicit. Actual Space
geometry.zoneNum and each Zone.spaceIndexes are retained, including selection
association witnesses. Reset events reacquire actual owners on each call and
do not retain references across placement new.

Full-array events retain allocation, complete l/u/index rows, array object and
actual data storage addresses for both In and Old, plus actual surface geometry
and AllHTSurfaceList. No non-HT allocated element is filtered out. Shared-MAT
events retain actual surface Zone/spaceNum/SurfTAirRef, the getter's returned
RefAirTemp local, and both stored owners. The getter is never called twice.
Only actual ZoneMeanAirTemp selects Space MAT (DataSurfaces221-225); adjacent
and supply branches must not be asserted equivalent to Space MAT. HBSM events
also retain actual FirstZone/LastZone/IZSurfs_size and optional resimulation
presence; its integer value is emitted only when the actual optional is present.

The collector streams only these selected checkpoints. Scope construction
retains exact Native06 procedure ordering and actual per-procedure entry
ordinals; destruction separately counts normal scope exits and unwinds. Those
are scope facts, not fabricated caller returns. Stream/copy failures, failed
ordinals, overflow and engine return/exception custody remain explicit. A valid
Original fatal or exception is not converted to ordinary success. The retained
legacy outer JSON schema comes from the unchanged main; every selected event
and summary carries src06-ordinary-temperature-owner-native.v1.

Full ZTAV accumulation is outside this unit. The selected field is observed
at allocation/reset/commit/copy/consumer/Old boundaries, with preservation
checked only at the actual bounded assignment. Original HVAC408 and413 do
write Zone and Space ZTAV later; the new observer does not observe or certify
those weighted accumulation boundaries. Original3844 writes ZTM, which is
outside the selected three fields and must not be asserted unchanged.

Held Rust owner03 admits only the existing SimplifiedAnalytical, one-pass,
noninterleaved/nonadaptive A route, inactive space sizing/simulation and no
surface correction/rebalance. Its returned solver ZT is separate from MAT.
The compatibility B route is Deferred/interleaved/adaptive ThirdOrder and is
not admitted. This capture can establish genuine Original owner/copy facts;
it cannot certify A as an Original correctAirTemp numerical port or claim B
lifecycle coverage. Rust application/rebase remains a later reviewed action.

Root will use the independently prepared additive build launcher to include
the current project include chain and this recipe, preserving all current744
compile registrations while adding exactly seven target TUs. Do not include
the held Native06 recipe, which would add a second unbuilt target. The new
recipe requires ORDINARY_TEMPERATURE_SOURCE_DIR and a fresh
ORDINARY_TEMPERATURE_OUTPUT_DIR on D for exe/map. Reuse the existing genuine
core and third-party archives; do not rebuild or overwrite historical helpers.
Actual provider/map/PE and core-preservation checks remain required build facts.

After Root's Source/build acceptance, run one actual normal-engine capture,
with the existing A-24H input, IDD and weather identities, into a fresh D unit
directory. The command shape is: new-derived-helper.exe
--surface-observation-file D:/NEW-UNIT/A-24H.observation.json -- -i EXISTING_IDD
-w EXISTING_A24_WEATHER -d D:/NEW-UNIT/A-24H
energyplus_porting_plan/cases/A-24H/input.idf. The exact current configure,
compile, derivative and input paths belong to the separate reviewed launcher;
these placeholders are not an execution receipt. No engine command is run here.

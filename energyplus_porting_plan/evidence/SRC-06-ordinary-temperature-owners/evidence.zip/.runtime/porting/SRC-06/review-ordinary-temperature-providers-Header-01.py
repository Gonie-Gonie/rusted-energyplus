"""One actual read-only map/PE/provider review; never call a helper or build."""
from pathlib import Path
from collections import Counter
import hashlib, importlib.util, json, mmap, re, subprocess, sys

ROOT=Path(__file__).resolve().parents[3]
BUILD=ROOT/'.runtime/ep261-gcc13-o0'
OUT=ROOT/'.runtime/porting/SRC-06/Header-ordinary-temperature-provider-review-01'
OUT.mkdir(exist_ok=False)
digests={}
def ref(p):
    p=Path(p).resolve()
    if p not in digests:
        with p.open('rb') as f: digests[p]=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else p.as_posix(),sha256=digests[p],size_bytes=p.stat().st_size)
def check(r):
    p=ROOT/r['path'];v=ref(p);assert v['sha256']==r['sha256'],p
    if 'size_bytes'in r:assert v['size_bytes']==r['size_bytes'],p
    return p
def load(r):return json.loads(check(r).read_bytes())
def write(name,value):
    p=OUT/name;p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf8');return ref(p)
def norm(p):return str(p).replace('\\','/').lower()

build_ref=dict(path='.runtime/porting/SRC-06/ordinary-temperature-native-build-01/native-build.json',sha256='3137526b5c860c6662cfb6f80339e963f1e2c462580ea05715cd6cf718dec8f2')
b=load(build_ref)
assert b['status']=='built-actual-seven-TU-core-preserved' and b['engine_executed'] is False
assert b['native_source_manifest']['sha256']=='d74663fe849903dbb6a6c4f648ef2c2e6e422ced08e8bd49fb25fff809b51660'
prep=load(b['native_source_manifest'])
for row in prep['payload']+prep['unchanged_Original_target_TUs']+[x['Original']for x in prep['Original_inverse_checks']]:check(row)
for row in load(b['protected_before']):check(row)
binary=check(b['helper_binary']);linkmap=check(b['map_file'])
assert b['core_archive_before']==b['core_archive_after'];check(b['core_archive_after'])
freeze=ROOT/'.runtime/porting/SRC-05/cold-guard-native-build-01/frozen-build-inputs.json'
assert ref(freeze)['sha256']=='ce5d01f106323a9354cc656ee81e07fef06b8e50b9280e8e8e1600d88342a3c5'
frozen_core=[]
def find_core(v):
    if isinstance(v,dict):
        if v.get('path','').endswith('/Products/libenergypluslib.a'):frozen_core.append(v)
        for x in v.values():find_core(x)
    elif isinstance(v,list):
        for x in v:find_core(x)
find_core(json.loads(freeze.read_bytes()))
assert frozen_core and all(x==b['core_archive_before'] for x in frozen_core)
old=load(b['old_registration_archive']);now=json.loads((BUILD/'compile_commands.json').read_bytes())
oldc=Counter(json.dumps(x,sort_keys=True)for x in old);nowc=Counter(json.dumps(x,sort_keys=True)for x in now)
assert len(old)==744 and len(now)==751 and not oldc-nowc
assert nowc-oldc==Counter(json.dumps(x,sort_keys=True)for x in b['new_registration_rows'])
receipts={k:load(v)for k,v in b['build_commands'].items()}
for x in receipts.values():
    assert x['exit_code']==0 and x['launch_error'] is None and x['source_bytes_match_before_and_after'] is True
    assert x['source_snapshot']['sha256']==b['Source_snapshot']['sha256']
    check(x['stdout']);check(x['stderr'])
assert receipts['configure']['finished_utc']<=receipts['dry_run']['started_utc']<=receipts['dry_run']['finished_utc']<=receipts['compile']['started_utc']
steps=lambda x:re.findall(r'^\[\d+/\d+\] (.+)$',check(x['stdout']).read_text(encoding='utf8'),re.MULTILINE)
assert steps(receipts['compile'])==steps(receipts['dry_run']) and len(steps(receipts['compile']))==8
objects={}
for row in b['new_registration_rows']:
    p=Path(row['output']);check(next(x['object']for x in b['target_objects_and_map_LOADs']if check(x['object'])==p))
    objects[Path(row['file']).name]=p.relative_to(BUILD).as_posix()
specs=[]
def add(prefix,source,exact=False):specs.append(dict(prefix=prefix,source=source,owner=objects[source],exact=exact))
for name in ['ManageSurfaceHeatBalance','InitSurfaceHeatBalance','InitThermalAndFluxHistories','UpdateThermalHistories','CalcHeatBalanceInsideSurf2CTFOnly','ReportSurfaceHeatBalance']:
    add('EnergyPlus::HeatBalanceSurfaceManager::'+name+'(','HeatBalanceSurfaceManager.surface_consumer.cc')
for name in ['ManageZoneAirUpdates','correctZoneAirTemps']:
    add('EnergyPlus::ZoneTempPredictorCorrector::'+name+'(','ZoneTempPredictorCorrector.surface_consumer.cc')
for name in ['correctAirTemp','correctHumRat','pushZoneTimestepHistory','pushSystemTimestepHistory','revertZoneTimestepHistory','updateTemperatures']:
    add('EnergyPlus::ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData::'+name+'(','ZoneTempPredictorCorrector.surface_consumer.cc')
for name in ['ManageHVAC','SimHVAC']:add('EnergyPlus::HVACManager::'+name+'(','HVACManager.surface_consumer.cc')
add('EnergyPlusPgm(','EnergyPlusPgm.cc')
add('EnergyPlus::CommandLineInterface::ProcessArgs(','CommandLineInterface.cc')
add('SurfaceConsumerObservation::record_temperatures(','surface_consumer_observer.cc')
add('SurfaceConsumerObservation::finish(','surface_consumer_observer.cc')
add('main','surface_consumer_main.cpp',True)
specs.append(dict(prefix='EnergyPlus::DataSurfaces::SurfaceData::getInsideAirTemperature(',source='DataSurfaces.cc',owner='Products/libenergypluslib.a(DataSurfaces.cc.obj)',exact=False))
selected=[];loads=[];section=pending=None
section_re=re.compile(r'^\s+(\.text\S*)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(.+?)\s*$')
continued_re=re.compile(r'^\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)\s+(.+?)\s*$')
symbol_re=re.compile(r'^\s+(0x[0-9a-fA-F]+)\s+(.+?)\s*$')
with linkmap.open(encoding='utf8')as f:
    for number,line in enumerate(f,1):
        line=line.rstrip('\n');m=section_re.match(line)
        if m:section=dict(name=m[1],start=int(m[2],16),size=int(m[3],16),owner=m[4],literal=line,line=number);pending=None
        elif re.match(r'^\s+\.text\S*\s*$',line):pending=dict(name=line.strip(),name_literal=line,name_line=number)
        elif pending and (m:=continued_re.match(line)):
            section=dict(**pending,start=int(m[1],16),size=int(m[2],16),owner=m[3],literal=line,line=number);pending=None
        if line.startswith('LOAD ')and('ordinary_temperature_owner_helper.dir/'in line or line=='LOAD Products/libenergypluslib.a'):
            loads.append(dict(line=number,literal=line))
        m=symbol_re.match(line)
        if not(m and section and section['start']<=int(m[1],16)<section['start']+section['size']):continue
        address,name=int(m[1],16),m[2]
        for row in selected:
            if row['section']==section and address>row['address'] and 'end'not in row:row['end']=address
        for spec in specs:
            matched=name==spec['prefix'] if spec['exact']else name.startswith(spec['prefix'])and'::{'not in name and' [clone 'not in name
            if matched:
                assert norm(section['owner'])==norm(spec['owner']),(name,section['owner'],spec['owner'])
                selected.append(dict(spec=spec,symbol=name,address=address,address_hex=m[1],section=dict(section),literal=line,line=number))
assert len(loads)==8 and all(sum(x['spec']==s for x in selected)==1 for s in specs),(len(loads),[s['prefix']for s in specs if sum(x['spec']==s for x in selected)!=1])
for row in selected:row.setdefault('end',row['section']['start']+row['section']['size'])
pe_source=ROOT/'tools/porting/native_pe.py';assert ref(pe_source)['sha256']=='afef047aec5a0bb5be90b6da155688b9bbaa672dd4dd90615569396d306cba56'
spec=importlib.util.spec_from_file_location('actual_accepted_native_pe',pe_source);pe=importlib.util.module_from_spec(spec);spec.loader.exec_module(pe)
mapping=pe.inspect(binary);assert mapping['sha256']==b['helper_binary']['sha256']
pe_ref=write('actual-PE.json',mapping)
with binary.open('rb')as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as data:
    for row in selected:
        rva=row['address']-mapping['image_base'];length=row['end']-row['address'];assert length>0
        sections=[s for s in mapping['sections']if not s['debug']and s['characteristics']&0x20000000 and s['rva']<=rva and rva+length<=s['rva']+s['raw_size']];assert len(sections)==1
        s=sections[0];offset=s['raw_offset']+rva-s['rva'];payload=data[offset:offset+length]
        row.update(code_bytes_sha256=hashlib.sha256(payload).hexdigest(),code_byte_count=length,PE_section=s['name'],PE_raw_offset=offset)
addr=ROOT/'.runtime/reference-tools/winlibs-gcc13.2.0-ucrt-r3/mingw64/bin/addr2line.exe'
assert ref(addr)['sha256']=='2a09b9eb95ea235075831caf186c746c1e4a2c566a2b065f13ce8912df3b5885'
command=[str(addr),'-f','-C','-e',str(binary),*[x['address_hex']for x in selected]]
directory=OUT/'addr2line-command-01'
result=subprocess.run([sys.executable,'-X','utf8','-B',str(ROOT/'tools/porting/record_command.py'),'--output-dir',str(directory),'--',*command],cwd=ROOT)
receipt=json.loads((directory/'receipt.json').read_bytes());assert result.returncode==receipt['exit_code']==0 and receipt['command']==command
assert receipt['source_snapshot']['sha256']==b['Source_snapshot']['sha256']and receipt['source_bytes_match_before_and_after']is True
resolved=check(receipt['stdout']).read_text(encoding='utf8').splitlines();assert len(resolved)==2*len(selected)
for i,row in enumerate(selected):
    assert resolved[2*i]==row['symbol'],(resolved[2*i],row['symbol'])
    location=resolved[2*i+1].replace('\\','/');match=re.search(r'^(.*):(\d+)(?: \(discriminator \d+\))?$',location);assert match,location
    path=Path(match[1]);assert path.name==row['spec']['source']and path.is_file(),location
    source_line=int(match[2]);assert 1<=source_line<=len(path.read_bytes().splitlines())
    row.update(actual_addr2line_function=resolved[2*i],actual_addr2line_location=location,actual_source=ref(path),actual_source_line=source_line)
providers_ref=write('actual-address-bound-providers.json',selected)
review=dict(schema='src06-ordinary-temperature-native-provider-review.v1',accepted=True,native_build=build_ref,helper_binary=b['helper_binary'],native_source_manifest=b['native_source_manifest'],Source_snapshot=b['Source_snapshot'],actual_PE=pe_ref,actual_address_bound_providers=providers_ref,actual_addr2line_execution=ref(directory/'receipt.json'),actual_build_commands=b['build_commands'],frozen_SRC05_build_inputs=ref(freeze),actual_core_archive=b['core_archive_after'],core_archive_matches_accepted_SRC05_baseline=True,old744_registration_rows_exact=True,new_compile_rows=7,actual_only_seven_compiles_and_one_link=True,selected_providers=len(selected),fresh_target_objects=len(objects),actual_target_and_core_LOADs=loads,all_selected_map_addresses_bound_to_actual_executable_PE_bytes=True,all_selected_providers_addr2line_bind_actual_Source=True,PE_sections=len(mapping['sections']),PE_directories=len(mapping['data_directories']),runtime_reference_counts=mapping['runtime_references']['counts'],provider_extent_caveat='Next mapped text symbol in same actual input text section, otherwise input section end; may include local code or padding. Static provenance is not an engine inner invocation trace.',unscanned_historical_objects_byte_exact_claimed=False,helper_executed=False,scientific_PASS_claimed=False,gates_updated=False,review_Source=ref(Path(__file__)))
print(json.dumps(dict(review=write('review.json',review),providers=len(selected))))

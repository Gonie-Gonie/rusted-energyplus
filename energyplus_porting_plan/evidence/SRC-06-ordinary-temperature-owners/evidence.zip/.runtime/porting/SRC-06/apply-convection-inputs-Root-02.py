"""Apply the reviewed finite raw-input proposal to its exact actual bases."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "tools/porting"))
import record_command as rec

def ref(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}

def verify(row):
    path = (ROOT / row["path"]).resolve()
    assert path.is_relative_to(ROOT) and path.is_file(), row
    actual = ref(path)
    assert actual["sha256"] == row["sha256"], row
    if "size_bytes" in row:
        assert actual["size_bytes"] == row["size_bytes"], row
    return path

def write(path, value):
    with path.open("xb") as stream:
        stream.write(rec.json_bytes(value))

def main():
    peer_path, peer_sha = sys.argv[1].rsplit("#", 1)
    peer = {"path": peer_path, "sha256": peer_sha}
    verify(peer)
    manifest = {"path": ".runtime/porting/SRC-06/ordinary-convection-input-prep-02/manifest.json",
                "sha256": "5177d499aad7287fcfd8972583519230d6aa27ffabe3fa85a7b20ae0ba9f087f"}
    payload = json.loads(verify(manifest).read_text(encoding="utf-8"))
    proposals = payload["source_proposals"]
    assert len(proposals) == 6
    for proposal in proposals:
        assert proposal["canonical_path"] == proposal["actual_before"]["path"]
        for key in ("actual_before", "before_archive", "proposed", "direct_diff"):
            verify(proposal[key])
        assert verify(proposal["actual_before"]).read_bytes() == verify(proposal["before_archive"]).read_bytes()
    checked_originals = {}
    for row in payload["Original_ranges"]:
        original = row["Original"]
        if original["path"] not in checked_originals:
            checked_originals[original["path"]] = verify(original).read_bytes().splitlines(keepends=True)
        lines = checked_originals[original["path"]]
        assert b"".join(lines[row["first_line"] - 1:row["last_line"]]) == verify(row["literal_archive"]).read_bytes()
    fixture = payload["canonical_Native_fixture_unchanged"]
    verify(fixture)
    before = rec.source_snapshot()
    assert before["sha256"] == "c63873e58b93a9c9581266d057ce93530c06ac5db959f270c122a6f72a00e0eb", before
    out = ROOT / ".runtime/porting/SRC-06/ordinary-convection-input-application-02"
    out.mkdir(exist_ok=False)
    write(out / "Root-Source-acceptance.json", {
        "schema": "src06-raw-convection-input-Root-Source-acceptance.v1",
        "status": "accepted-before-canonical-mutation", "preparation": manifest,
        "independent_review": peer, "source_before": before,
        "review_scope": "Six complete direct diffs and exact bases; actual six-family raw counts; unique project N2 finite-positive value/default; retained validation before writes; one raw table and existing state regression; Native19 replay unchanged except authored constructor inputs",
        "Original_ranges_checked": len(payload["Original_ranges"]),
        "fixture_unchanged": fixture,
        "no_new_dispatcher_or_algorithm_activation": True,
        "no_scientific_gate_change": True,
    })
    for proposal in proposals:
        (ROOT / proposal["canonical_path"]).write_bytes(verify(proposal["proposed"]).read_bytes())
    verify(fixture)
    after = rec.source_snapshot()
    write(out / "application.json", {
        "schema": "src06-raw-convection-input-application.v1", "preparation": manifest,
        "Root_acceptance": ref(out / "Root-Source-acceptance.json"),
        "independent_review": peer, "source_before": before, "source_after": after,
        "applied_paths": [ref(ROOT / row["canonical_path"]) for row in proposals],
        "fixture_unchanged": fixture, "targets_executed": False,
    })
    print(json.dumps(ref(out / "application.json")))

if __name__ == "__main__":
    main()

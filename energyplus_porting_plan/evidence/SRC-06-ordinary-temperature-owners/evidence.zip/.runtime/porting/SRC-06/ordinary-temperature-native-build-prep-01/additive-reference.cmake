include("C:/Users/GonieGonie/Documents/GitHub/rusted-energyplus/.runtime/porting/SRC-05/cold-guard-native-invocation-plan-01/additive-reference.cmake")
include("C:/Users/GonieGonie/Documents/GitHub/rusted-energyplus/.runtime/porting/SRC-06/ordinary-temperature-native-prep-01/ordinary_temperature_reference.cmake")

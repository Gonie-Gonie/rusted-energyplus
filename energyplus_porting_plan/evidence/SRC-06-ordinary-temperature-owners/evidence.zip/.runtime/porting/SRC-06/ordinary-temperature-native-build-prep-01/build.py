#!/usr/bin/env python3
"""Held seven-TU additive Native build; Root executes after Source review."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
PREP = ROOT / '.runtime/porting/SRC-06/ordinary-temperature-native-prep-01'
MANIFEST_SHA = 'd74663fe849903dbb6a6c4f648ef2c2e6e422ced08e8bd49fb25fff809b51660'
BUILD = ROOT / '.runtime/ep261-gcc13-o0'
ORIGINAL = ROOT / '.reference/energyplus-src/26.1.0'
TOOLS = ROOT / '.runtime/reference-tools'
CMAKE = TOOLS / 'cmake-4.4.4/cmake-4.4.4-windows-x86_64/bin/cmake.exe'
NINJA = TOOLS / 'ninja-1.13.2/ninja.exe'
RECORDER = ROOT / 'tools/porting/record_command.py'
CORE = BUILD / 'Products/libenergypluslib.a'
TARGET = 'ordinary_temperature_owner_helper'
UNIT = Path('D:/CodexBuild/rusted-energyplus/SRC-06/ordinary-temperature-native-build-01')
META = ROOT / '.runtime/porting/SRC-06/ordinary-temperature-native-build-01'
OLD_INCLUDE = ROOT / '.runtime/porting/SRC-05/cold-guard-native-invocation-plan-01/additive-reference.cmake'
SNAPSHOT = 'd70e015d5808030720233b32aa8d3b7777a414a3ad6625423c6df8f9b899e914'


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def ref(path):
    path = Path(path).resolve()
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else path.as_posix(),
            'sha256': sha(path), 'size_bytes': path.stat().st_size}


def checked(row):
    path = ROOT / row['path']
    assert sha(path) == row['sha256'], path
    if 'size_bytes' in row:
        assert path.stat().st_size == row['size_bytes'], path
    return path


def write(path, value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())
    return ref(path)


def cache():
    result = {}
    for line in (BUILD / 'CMakeCache.txt').read_text(encoding='utf-8').splitlines():
        if line and not line.startswith(('#', '//')) and '=' in line:
            key, value = line.split('=', 1)
            result[key] = value
    return result


def commands():
    return json.loads((BUILD / 'compile_commands.json').read_bytes())


def normalized(value):
    return str(value).replace('\\', '/').lower()


def run(name, argv):
    directory = META / (name + '-command-01')
    outer = subprocess.run([sys.executable, '-X', 'utf8', '-B', str(RECORDER),
                            '--output-dir', str(directory), '--', *map(str, argv)], cwd=ROOT)
    receipt_path = directory / 'receipt.json'
    receipt = json.loads(receipt_path.read_bytes())
    assert outer.returncode == receipt['exit_code'] == 0, (name, outer.returncode)
    assert receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after'] is True
    assert receipt['source_snapshot']['sha256'] == SNAPSHOT
    assert receipt['command'] == list(map(str, argv)), name
    return ref(receipt_path), checked(receipt['stdout']).read_text(encoding='utf-8')


def compile_plan(stdout, rows):
    steps = re.findall(r'^\[\d+/\d+\] (.+)$', stdout, re.MULTILINE)
    assert len(steps) == 8, ('expected only seven compiles and one link', len(steps))
    for step, row in zip(steps[:7], rows):
        step = normalized(step)
        assert ' -c ' in step and 'g++.exe' in step
        assert normalized(row['file']) in step, row['file']
        output = normalized(Path(row['output']).relative_to(BUILD))
        assert output in step and normalized(TARGET + '.dir') in step
    link = normalized(steps[-1])
    assert 'g++.exe' in link and ' -c ' not in link
    assert normalized(UNIT / 'bin' / (TARGET + '.exe')) in link
    assert normalized('Products/libenergypluslib.a') in link
    assert normalized(UNIT / 'bin' / (TARGET + '.map')) in link
    for row in rows:
        assert normalized(Path(row['output']).relative_to(BUILD)) in link
    return steps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-approval', required=True, help='Root accepted Native Source review path#sha256')
    args = parser.parse_args()
    approval_path, digest = args.source_approval.rsplit('#', 1)
    approval_ref = {'path': approval_path, 'sha256': digest}
    approval = json.loads(checked(approval_ref).read_bytes())
    assert approval.get('accepted') is True or approval.get('status') == 'ACCEPTED_SOURCE_ONLY'
    approval_manifest = approval.get('native_source_manifest', approval.get('native_preparation'))
    assert approval_manifest['sha256'] == MANIFEST_SHA
    manifest_path = PREP / 'manifest.json'
    assert sha(manifest_path) == MANIFEST_SHA
    manifest = json.loads(manifest_path.read_bytes())
    source_refs = manifest['payload'] + manifest['unchanged_Original_target_TUs']
    source_refs += [row['Original'] for row in manifest['Original_inverse_checks']]
    for row in source_refs:
        checked(row)
    assert not UNIT.exists() and not META.exists(), 'Fresh build/output unit required'
    assert not list(BUILD.glob('CMakeFiles/' + TARGET + '.dir/**/*')), 'New target objects must not preexist'
    old_rows = commands()
    assert len(old_rows) == 744 and all(TARGET + '.dir' not in r['output'] for r in old_rows)
    old_cache = cache()
    assert normalized(old_cache['CMAKE_PROJECT_INCLUDE:UNINITIALIZED']) == normalized(OLD_INCLUDE)
    assert old_cache['CMAKE_BUILD_TYPE:STRING'] == 'RelWithDebInfo'
    assert old_cache['CMAKE_CXX_FLAGS:STRING'] == '-Wa,-mbig-obj -ffp-contract=off'
    assert old_cache['CMAKE_CXX_FLAGS_RELWITHDEBINFO:STRING'] == '-O0 -g -DNDEBUG'
    assert normalized(old_cache['CMAKE_HOME_DIRECTORY:INTERNAL']) == normalized(ORIGINAL)
    # Protect the consumed core archive and actual private headers; no claim about unscanned historical objects.
    protected_paths = sorted((ORIGINAL / 'src/EnergyPlus').rglob('*.hh'))
    protected_paths += [OLD_INCLUDE, RECORDER, HERE / 'additive-reference.cmake', HERE / 'build.py', CMAKE, NINJA]
    protected = [ref(p) for p in protected_paths]
    core_before = ref(CORE)
    META.mkdir(parents=True)
    (UNIT / 'bin').mkdir(parents=True)
    old_rows_ref = write(META / 'compile-commands-before.json', old_rows)
    old_cache_ref = write(META / 'cache-before.json', old_cache)
    protected_ref = write(META / 'protected-before.json', protected)
    configure_argv = [CMAKE, '-S', ORIGINAL, '-B', BUILD, '-G', 'Ninja',
                      '-DCMAKE_PROJECT_INCLUDE=' + (HERE / 'additive-reference.cmake').as_posix(),
                      '-DORDINARY_TEMPERATURE_SOURCE_DIR=' + PREP.as_posix(),
                      '-DORDINARY_TEMPERATURE_OUTPUT_DIR=' + (UNIT / 'bin').as_posix()]
    configure, _ = run('configure', configure_argv)
    current = commands()
    old_keys = Counter(json.dumps(r, sort_keys=True) for r in old_rows)
    new_keys = Counter(json.dumps(r, sort_keys=True) for r in current)
    assert not (old_keys - new_keys), 'Existing compile registration changed'
    extra = new_keys - old_keys
    new_rows = [r for r in current if TARGET + '.dir' in r['output']]
    assert len(current) == 751 and sum(extra.values()) == len(new_rows) == 7
    assert Counter(json.dumps(r, sort_keys=True) for r in new_rows) == extra
    expected = [PREP / name for name in ['surface_consumer_main.cpp', 'HeatBalanceSurfaceManager.surface_consumer.cc',
                'surface_consumer_observer.cc', 'ZoneTempPredictorCorrector.surface_consumer.cc', 'HVACManager.surface_consumer.cc']]
    expected += [ORIGINAL / 'src/EnergyPlus/api/EnergyPlusPgm.cc', ORIGINAL / 'src/EnergyPlus/CommandLineInterface.cc']
    assert {normalized(r['file']) for r in new_rows} == {normalized(p) for p in expected}
    # Preserve the recipe's source order for the seven fresh actual compile operations.
    new_rows.sort(key=lambda r: [normalized(p) for p in expected].index(normalized(r['file'])))
    for row in new_rows:
        assert not Path(row['output']).exists(), row['output']
        for token in ['-ffp-contract=off', '-O0', '-g', '-UNDEBUG', '-std=c++20']:
            assert token in row['command'], token
        assert '-ffast-math' not in row['command']
    new_cache = cache()
    allowed = {'CMAKE_PROJECT_INCLUDE:UNINITIALIZED', 'ORDINARY_TEMPERATURE_SOURCE_DIR:UNINITIALIZED',
               'ORDINARY_TEMPERATURE_OUTPUT_DIR:UNINITIALIZED'}
    assert {k:v for k,v in old_cache.items() if k not in allowed} == {k:v for k,v in new_cache.items() if k not in allowed}
    dry_run, dry_stdout = run('dry-run', [NINJA, '-C', BUILD, '-n', '-v', TARGET])
    dry_steps = compile_plan(dry_stdout, new_rows)
    assert ref(CORE) == core_before
    compile_receipt, actual_stdout = run('compile', [CMAKE, '--build', BUILD, '--target', TARGET, '--parallel', '1', '--verbose'])
    actual_steps = compile_plan(actual_stdout, new_rows)
    assert actual_steps == dry_steps, 'Actual command list differs from accepted dry run'
    for row in source_refs + protected:
        checked(row)
    core_after = ref(CORE)
    assert core_after == core_before
    binary = UNIT / 'bin' / (TARGET + '.exe')
    link_map = UNIT / 'bin' / (TARGET + '.map')
    with binary.open('rb') as f:
        assert f.read(2) == b'MZ'
    assert link_map.is_file()
    load_lines = []
    with link_map.open(encoding='utf-8') as f:
        for line in f:
            if line.startswith('LOAD '):
                load_lines.append(line.rstrip('\n'))
    providers = []
    for row in new_rows:
        relative = Path(row['output']).relative_to(BUILD).as_posix()
        witnesses = [line for line in load_lines if normalized(relative) in normalized(line)]
        assert len(witnesses) == 1, relative
        providers.append({'object': ref(row['output']), 'map_lines': witnesses})
    result = {'schema':'src06-ordinary-temperature-native-build.v1', 'status':'built-actual-seven-TU-core-preserved',
              'native_source_manifest':ref(manifest_path), 'Source_snapshot':{'sha256':SNAPSHOT},
              'source_approval':approval_ref, 'helper_binary':ref(binary), 'map_file':ref(link_map),
              'build_commands':{'configure':configure, 'dry_run':dry_run, 'compile':compile_receipt},
              'core_archive_before':core_before, 'core_archive_after':core_after,
              'old_registration_archive':old_rows_ref, 'old_cache_archive':old_cache_ref,
              'protected_before':protected_ref, 'old_registration_rows_exact':744,
              'new_registration_rows':new_rows, 'new_registration_count':7,
              'target_objects_and_map_LOADs':providers, 'actual_only_seven_compiles_one_link':True,
              'provider_address_binding_requires_separate_Root_review':True,
              'all_protected_refs_unchanged':True, 'unscanned_historical_objects_byte_exact_claimed':False,
              'engine_executed':False, 'integration_PASS_claimed':False, 'gates_updated':False}
    print(json.dumps({'native_build':write(META / 'native-build.json', result)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

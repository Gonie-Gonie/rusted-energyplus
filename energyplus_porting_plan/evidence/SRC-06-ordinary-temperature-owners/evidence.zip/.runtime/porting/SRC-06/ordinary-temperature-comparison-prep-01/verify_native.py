"""Read every selected passive Original event; never run an engine or Rust solver."""
import argparse
import collections
import copy
import hashlib
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PARSER = ROOT / '.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'
POLICY = Path(__file__).with_name('policy.json')
PROTOCOL = 'src06-ordinary-temperature-owner-native.v1'
PROCEDURE_NAMES = [
    'ManageSurfaceHeatBalance', 'InitSurfaceHeatBalance', 'InitThermalAndFluxHistories',
    'UpdateThermalHistories', 'CalcHeatBalanceInsideSurf2CTFOnly', 'ReportSurfaceHeatBalance',
    'ManageHVAC', 'SimHVAC', 'ManageZoneAirUpdates', 'correctZoneAirTemps', 'correctAirTemp',
    'correctHumRat', 'pushZoneTimestepHistory', 'pushSystemTimestepHistory',
    'revertZoneTimestepHistory', 'updateTemperatures',
]
PAIRS = {
    'temperature_air_reset_before': 'temperature_air_reset_after',
    'temperature_mat_commit_before': 'temperature_mat_commit_after',
    'temperature_space_copy_before': 'temperature_space_copy_after',
    'temperature_reference_returned': 'temperature_reference_stored',
    'temperature_old_copy_before': 'temperature_old_copy_after',
}
PROCEDURES = {
    'temperature_air_reset_before': 'InitThermalAndFluxHistories',
    'temperature_mat_commit_before': 'correctAirTemp',
    'temperature_space_copy_before': 'correctZoneAirTemps',
    'temperature_reference_returned': 'CalcHeatBalanceInsideSurf2CTFOnly',
    'temperature_old_copy_before': 'CalcHeatBalanceInsideSurf2CTFOnly',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def ref(path):
    return {'path': path.resolve().as_posix(), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'Duplicate JSON key: ' + key)
        out[key] = value
    return out


def scalar(value):
    need(type(value) is dict and set(value) == {'value_bits', 'value_class'}, 'Missing raw scalar')
    bits = value['value_bits']
    need(type(bits) is str and re.fullmatch('[0-9a-f]{16}', bits), 'Invalid scalar bits')
    integer = int(bits, 16)
    mag = integer & 0x7fffffffffffffff
    neg = integer >> 63
    kind = ('nan' if mag > 0x7ff0000000000000 else
            ('negative_infinity' if neg else 'positive_infinity') if mag == 0x7ff0000000000000 else
            ('negative_zero' if neg else 'positive_zero') if mag == 0 else 'finite')
    need(value['value_class'] == kind, 'Scalar class does not match raw bits')
    return value


def walk_scalars(value):
    if type(value) is dict:
        if 'value_bits' in value or 'value_class' in value:
            scalar(value)
        else:
            for child in value.values():
                walk_scalars(child)
    elif type(value) is list:
        for child in value:
            walk_scalars(child)


def air(event, allocation=False):
    value = event['owners']['air']
    need(value['NumOfZones'] == 1 and value['numSpaces'] > 0, 'Existing one-zone A admission differs')
    need(not value['doSpaceHeatBalance'] and not value['doSpaceHeatBalanceSizing'] and not value['doSpaceHeatBalanceSimulation']
         and not value['DoingSizing'], 'Active Space/sizing branch is outside this unit')
    need(value['zone_geometry_allocated'] and value['space_geometry_allocated'], 'Missing actual geometry')
    zones, spaces = value['zone_geometry'], value['space_geometry']
    need(len(zones) == value['zone_geometry_count'] == 1 and zones[0]['index'] == 1, 'Zone geometry count/order differs')
    need(len(spaces) == value['space_geometry_count'] == value['numSpaces'], 'Space geometry count differs')
    indices = zones[0]['spaceIndexes']
    need(len(indices) == len(set(indices)) and sorted(indices) == list(range(1, len(spaces) + 1)), 'Actual zone-space membership differs')
    need(all(row['index'] == i and row['zoneNum'] == 1 for i, row in enumerate(spaces, 1)), 'Actual Space association differs')
    for key, count in [('zone_owners', 1), ('space_owners', len(spaces))]:
        owner = value[key]
        if allocation and not owner['allocated']:
            need(owner['count'] == 0 and owner['values'] is None, 'Unallocated owner has invented rows')
            continue
        need(owner['allocated'] and owner['count'] == count and len(owner['values']) == count, 'Missing complete allocated air owner')
        for index, row in enumerate(owner['values'], 1):
            need(row['index'] == index and type(row['address']) is int and row['address'] > 0, 'Air address/index unavailable')
            need(set(row['fields']) == {'MAT', 'ZT', 'ZTAV'}, 'Selected air field set differs')
            for item in row['fields'].values():
                scalar(item)
    selection = value['selection']
    zone, space = selection['requested_zone'], selection['requested_space']
    if zone:
        need(zone == 1 and selection['selected_owner_available'], 'Selected owner unavailable')
        row = value['space_owners' if space else 'zone_owners']['values'][space - 1 if space else zone - 1]
        need(selection['selected_owner_address'] == row['address'], 'Selected address does not bind actual array member')
        need(selection['selected_owner_kind'] == ('Space' if space else 'Zone'), 'Selected owner kind differs')
        if selection['member_address'] is not None:
            need(selection['member_matches_selected'] is True and selection['member_address'] == row['address'], 'Actual this pointer differs')
        if space:
            need(space in indices and selection['space_in_zone_spaceIndexes'] is True
                 and selection['space_geometry_zone_matches'] is True, 'Selected actual Space association differs')
    return value


def arrays(event):
    result = event['owners']['surface_arrays']
    need(type(result) is dict and set(result) == {'SurfTempIn', 'SurfTempInsOld'}, 'Full temperature arrays missing')
    for value in result.values():
        need(value['allocated'] and type(value['lower']) is int and type(value['upper']) is int, 'Temperature allocation unavailable')
        need(value['upper'] >= value['lower'] and len(value['values']) == value['upper'] - value['lower'] + 1, 'Full allocated bounds differ')
        need([r['index'] for r in value['values']] == list(range(value['lower'], value['upper'] + 1)), 'Allocated array traversal differs')
        need(type(value['storage_address']) is int and value['storage_address'] > 0, 'Array storage address unavailable')
        need(type(value['array_address']) is int and value['array_address'] > 0, 'Array object address unavailable')
        for row in value['values']:
            scalar(row['value'])
    inside, old = result['SurfTempIn'], result['SurfTempInsOld']
    need(inside['storage_address'] != old['storage_address'], 'Old and In storage alias')
    need(inside['array_address'] != old['array_address'], 'Old and In array objects alias')
    geometry = event['owners']['surface_geometry']
    need(geometry['allocated'] and geometry['count'] == len(geometry['values']) == len(inside['values']), 'Full surface geometry missing')
    need([r['index'] for r in geometry['values']] == [r['index'] for r in inside['values']], 'Surface/temperature index correspondence differs')
    need(all(r['Zone'] == 1 and r['spaceNum'] in event['owners']['air']['zone_geometry'][0]['spaceIndexes'] for r in geometry['values']), 'Surface association differs')
    return result


def same_pair_identity(before, after):
    for key in ['clock', 'procedure', 'invocation_ordinal', 'parent_procedure', 'parent_invocation_ordinal', 'locals']:
        need(before[key] == after[key], 'Pair identity differs: ' + key)
    need(before['event_ordinal'] + 1 == after['event_ordinal'], 'Selected pair is not adjacent')
    need(before['procedure'] == PROCEDURES[before['checkpoint']], 'Unexpected actual caller')


def check_pair(before, after):
    same_pair_identity(before, after)
    tag = before['checkpoint']
    first, last = air(before), air(after)
    expected = copy.deepcopy(first)
    if tag == 'temperature_air_reset_before':
        for key in ['zone_owners', 'space_owners']:
            for row in expected[key]['values']:
                row['fields'] = {key: {'value_bits': '4037000000000000', 'value_class': 'finite'} for key in ['MAT', 'ZT', 'ZTAV']}
        need(arrays(before) == arrays(after), 'Air reconstruction overwrote independent surface arrays')
    elif tag == 'temperature_mat_commit_before':
        selection = first['selection']
        need(selection['member_matches_selected'] is True, 'Commit actual member witness missing')
        key = 'space_owners' if selection['requested_space'] else 'zone_owners'
        index = selection['requested_space'] - 1 if selection['requested_space'] else selection['requested_zone'] - 1
        fields = expected[key]['values'][index]['fields']
        fields['MAT'] = copy.deepcopy(fields['ZT'])
    elif tag == 'temperature_space_copy_before':
        selection = first['selection']
        need(selection['requested_space'] > 0 and selection['member_matches_selected'] is True, 'Space copy witness missing')
        fields = expected['space_owners']['values'][selection['requested_space'] - 1]['fields']
        zone = first['zone_owners']['values'][selection['requested_zone'] - 1]['fields']
        fields['ZT'], fields['MAT'] = copy.deepcopy(zone['ZT']), copy.deepcopy(zone['MAT'])
    elif tag == 'temperature_reference_returned':
        surface = before['owners']['surface']
        need(surface['available'] and surface['SurfTAirRef'] == 0 and surface['Zone'] == 1, 'ZoneMeanAirTemp actual surface branch missing')
        selection = first['selection']
        need(surface['spaceNum'] == selection['requested_space'] and surface['spaceNum'] > 0, 'Returned refair uses wrong Space')
        returned = scalar(before['locals']['RefAirTemp'])
        mat = first['space_owners']['values'][surface['spaceNum'] - 1]['fields']['MAT']
        need(returned == mat, 'Actual getter return differs from associated Space MAT')
        expected_surface = copy.deepcopy(surface)
        expected_surface['RefAirTemp'] = expected_surface['SurfTempEffBulkAir'] = returned
        need(after['owners']['surface'] == expected_surface and after['locals']['RefAirTemp'] == returned, 'Refair store differs from actual returned value')
    elif tag == 'temperature_old_copy_before':
        incoming, outgoing = arrays(before), arrays(after)
        need(outgoing['SurfTempIn'] == incoming['SurfTempIn'], 'Old copy changed incoming In')
        target = copy.deepcopy(incoming['SurfTempInsOld'])
        target['lower'], target['upper'], target['values'] = (incoming['SurfTempIn'][key] for key in ['lower', 'upper', 'values'])
        need(outgoing['SurfTempInsOld'] == target, 'Complete Old assignment differs from incoming In')
        need(before['locals'] == after['locals'], 'Old-copy actual zone/resimulation context changed')
    else:
        need(False, 'Unknown selected pair')
    need(last == expected, 'Copied/retained full selected air owners differ at ' + tag)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--capture-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    capture = args.capture.resolve()
    need(sha(capture) == args.capture_sha256, 'Actual capture hash differs')
    need(not args.output_dir.exists(), 'Fresh output directory required')
    need(sha(PARSER) == '8e7f05196fe567c052352d4d0fe501eb02a0f8e5a623c20f7dcd3db669f6bab8', 'Reviewed streaming parser changed')
    need(sha(POLICY) == '8567b4707d8de8dbecd53e0c1a55b4f93dbfa34e42bc19daaafa59e2b0812989', 'Frozen comparison policy changed')
    spec = importlib.util.spec_from_file_location('temperature_stream_events', PARSER)
    stream = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stream)
    counts, pairs, observed_invocations = collections.Counter(), collections.Counter(), collections.Counter()
    state = {'ordinal': 0, 'pending': None, 'space_group': None}
    cases = {}

    def visit(event):
        state['ordinal'] += 1
        need(event['event_ordinal'] == state['ordinal'] and event['temperature_owner_protocol'] == PROTOCOL, 'Event ledger/protocol differs')
        need(event['counted_as_PASS'] is False and event['invocation_ordinal'] > 0, 'Observer claimed result or lost actual invocation')
        need(event['procedure'] in PROCEDURE_NAMES and type(event['invocation_ordinal']) is int, 'Unknown actual procedure or ordinal')
        observed_invocations[event['procedure']] = max(observed_invocations[event['procedure']], event['invocation_ordinal'])
        parent, parent_ordinal = event['parent_procedure'], event['parent_invocation_ordinal']
        if parent is None:
            need(parent_ordinal is None, 'Absent actual parent has an invented ordinal')
        else:
            need(parent in PROCEDURE_NAMES and type(parent_ordinal) is int and parent_ordinal > 0, 'Unknown actual parent or ordinal')
            observed_invocations[parent] = max(observed_invocations[parent], parent_ordinal)
        walk_scalars(event)
        tag = event['checkpoint']
        counts[tag] += 1
        if state['space_group'] is not None and state['pending'] is None:
            need(tag == 'temperature_space_copy_before', 'Incomplete actual disabled-space copy group')
        if tag == 'temperature_surface_allocation_complete':
            need(state['pending'] is None, 'Allocation interrupted a required pair')
            air(event, allocation=True)
            for value in arrays(event).values():
                need(all(row['value']['value_bits'] == '0000000000000000' for row in value['values']), 'Actual constructor surface zeros differ')
            cases.setdefault((tag, 'allocation'), {'event': event})
        elif tag in PAIRS:
            need(state['pending'] is None, 'Unclosed selected before boundary')
            state['pending'] = event
        else:
            before = state['pending']
            need(before is not None and PAIRS[before['checkpoint']] == tag, 'Missing selected before boundary')
            check_pair(before, event)
            pairs[before['checkpoint']] += 1
            clock = before['clock']
            phase = ('kickoff' if clock['KickOffSimulation'] else
                     'warmup_first_day' if clock['WarmupFlag'] and clock['DayOfSim'] == 1 else
                     'warmup_later_day' if clock['WarmupFlag'] else 'run')
            if before['checkpoint'] == 'temperature_space_copy_before':
                group = state['space_group']
                if group is None:
                    group = {'before': before, 'actual_member_pair_ordinals': []}
                    state['space_group'] = group
                first = group['before']
                for key in ['clock', 'procedure', 'invocation_ordinal', 'parent_procedure', 'parent_invocation_ordinal']:
                    need(before[key] == first[key], 'Space copy group crossed actual invocation/clock')
                indices = first['owners']['air']['zone_geometry'][0]['spaceIndexes']
                index = len(group['actual_member_pair_ordinals'])
                if index:
                    previous_air = group['previous_after']['owners']['air']
                    current_air = before['owners']['air']
                    need({k: v for k, v in previous_air.items() if k != 'selection'} ==
                         {k: v for k, v in current_air.items() if k != 'selection'},
                         'Selected air owners changed between actual Space copy members')
                need(before['owners']['air']['selection']['requested_space'] == indices[index], 'Space copy group actual traversal order differs')
                group['actual_member_pair_ordinals'].append([before['event_ordinal'], event['event_ordinal']])
                group['previous_after'] = event
                if index + 1 == len(indices):
                    # Both aggregate endpoints are genuinely observed full-owner
                    # DTOs. No projected intermediate or endpoint is manufactured.
                    cases.setdefault(('temperature_space_copy_group', phase),
                                     {'before': group['before'], 'after': event,
                                      'actual_member_pair_ordinals': group['actual_member_pair_ordinals']})
                    state['space_group'] = None
            else:
                cases.setdefault((before['checkpoint'], phase), {'before': before, 'after': event})
            state['pending'] = None

    terminal = stream.read(capture, need, unique, visit)
    need(terminal['schema'] == 'ctf10-surface-consumer-native-observation.v1', 'Actual transport schema differs')
    need(state['pending'] is None and state['space_group'] is None, 'Unclosed final pair/group')
    summary = terminal['summary']
    need(summary['temperature_owner_protocol'] == PROTOCOL and summary['actual_engine_entry_returned'] is True
         and summary['actual_engine_exit_code'] == 0 and summary['outer_caught_exception_class'] is None, 'Actual engine did not return zero')
    need(summary['attempted_events'] == summary['retained_events'] == state['ordinal'], 'Transport event count differs')
    for key in ['copy_failures', 'first_failed_event', 'last_failed_event', 'stream_failed_events']:
        need(summary[key] == 0, 'Observer copy/stream failure: ' + key)
    need(summary['counter_overflow'] is False and summary['stream_failed'] is False, 'Observer overflow or stream failure')
    need(summary['procedure_names'] == PROCEDURE_NAMES, 'Actual procedure name/order differs')
    for key in ['procedure_calls', 'scope_normal_exits', 'scope_unwinds']:
        need(type(summary[key]) is list and len(summary[key]) == len(PROCEDURE_NAMES)
             and all(type(value) is int and value >= 0 for value in summary[key]), 'Actual procedure counter shape differs')
    need(summary['procedure_calls'] == summary['scope_normal_exits'] and all(value == 0 for value in summary['scope_unwinds']), 'Actual procedure scope did not close normally')
    for name, count in zip(PROCEDURE_NAMES, summary['procedure_calls']):
        need(observed_invocations[name] <= count, 'Observed invocation exceeds actual procedure count: ' + name)
    need(counts['temperature_surface_allocation_complete'] > 0 and all(pairs[tag] > 0 for tag in PAIRS), 'Required active boundary missing')
    need(summary['full_ZTAV_accumulation_observed'] is False and summary['integration_PASS_claimed'] is False, 'Observer scope expanded')
    output = args.output_dir.resolve()
    output.mkdir(parents=True)
    fixture = {'schema': 'src06-actual-native-temperature-transition-cases.v1', 'actual_capture': ref(capture),
               'selection': 'First actual pair of each selected operation in each observed kickoff/warmup/run phase; no generated endpoint',
               'cases': [dict(operation=key[0], phase=key[1], **value) for key, value in cases.items()]}
    (output / 'selected-cases.json').write_text(json.dumps(fixture, indent=2, allow_nan=False) + '\n', encoding='utf8')
    report = {'schema': 'src06-actual-native-temperature-owner-factual-review.v1', 'status': 'ACCEPTED_SELECTED_ORIGINAL_ASSIGNMENT_BOUNDARIES',
              'capture': ref(capture), 'policy': ref(POLICY), 'checker': ref(Path(__file__)), 'stream_parser': ref(PARSER),
              'actual_native_arguments': terminal['actual_native_arguments'], 'actual_terminal_summary': summary,
              'observed_events': state['ordinal'], 'checkpoint_counts': dict(counts), 'validated_pairs': dict(pairs),
              'maximum_observed_invocations_and_parents': dict(observed_invocations),
              'selected_cases': ref(output / 'selected-cases.json'), 'mismatches': 0,
              'Rust_comparison_executed': False, 'whole_ordinary_equivalence_certified': False,
              'zone_solver_equivalence_certified': False, 'full_ZTAV_average_lifecycle_certified': False,
              'dispatcher_or_cadence_certified': False, 'gates_updated': False}
    (output / 'review.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf8')
    print(json.dumps({'review': ref(output / 'review.json'), 'events': state['ordinal'], 'pairs': dict(pairs)}))


if __name__ == '__main__':
    main()

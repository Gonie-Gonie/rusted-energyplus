"""Prepare one held A-owner rebase only; never write production or run Rust/Native."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-temperature-owner-prep-04'
PARENT = ROOT / '.runtime/porting/SRC-06/ordinary-temperature-owner-prep-03/manifest.json'
SOURCE = dict(path='.runtime/porting/source-objects/d7/d70e015d5808030720233b32aa8d3b7777a414a3ad6625423c6df8f9b899e914', sha256='d70e015d5808030720233b32aa8d3b7777a414a3ad6625423c6df8f9b899e914')


def ref(path):
    data = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(data).hexdigest(), size_bytes=len(data))


def checked(row):
    path = ROOT / row['path']
    assert ref(path)['sha256'] == row['sha256'], row
    if 'size_bytes' in row:
        assert path.stat().st_size == row['size_bytes'], row
    return path.read_bytes()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    return ref(path)


def dump(path, value):
    return write(path, (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode())


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old[:100], text.count(old), count)
    return text.replace(old, new)


def diff(before, after, name, new=False):
    return ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='/dev/null' if new else name, tofile=name)).encode()


def main():
    assert not OUT.exists(), 'single fresh held preparation required'
    assert ref(PARENT)['sha256'] == '8628027002d006c75c50c5248608246a44e74e853c465adddbc2b9e6098e00d0'
    parent = json.loads(PARENT.read_bytes())
    source_map = json.loads(checked(SOURCE))
    members = {r['historical_path']: r for r in source_map['files']}
    before, proposed, prior = {}, {}, {}
    for row in parent['source_proposals']:
        name = row['canonical_path']
        path = ROOT / name
        if row['actual_before'] is None:
            assert not path.exists(), name
            before[name] = b''
        else:
            before[name] = path.read_bytes()
            assert hashlib.sha256(before[name]).hexdigest() == members[name]['archive']['sha256'], name
        prior[name] = checked(row['proposed'])
        proposed[name] = prior[name]
    warmup = 'crates/ep_runtime/src/runtime/tests/warmup_ordinary_reports.rs'
    for row in parent['source_proposals']:
        if row['actual_before'] is not None:
            old = checked(row['before_archive'])
            if row['canonical_path'] == warmup:
                assert replace(old.decode(), 'wind_direction_deg=-0.0;', 'wind_direction_deg= -0.0;').encode() == before[warmup]
                proposed[warmup] = replace(proposed[warmup].decode(), 'wind_direction_deg=-0.0;', 'wind_direction_deg= -0.0;').encode()
            else:
                assert old == before[row['canonical_path']], row['canonical_path']
    for name in ['crates/ep_runtime/src/heat_balance/surface_loop.rs', 'crates/ep_runtime/src/runtime/tests/part04.rs']:
        before[name] = (ROOT / name).read_bytes()
        assert hashlib.sha256(before[name]).hexdigest() == members[name]['archive']['sha256'], name
        proposed[name] = before[name]

    owner_path = 'crates/ep_runtime/src/heat_balance/ordinary_inside_temperatures.rs'
    owner = proposed[owner_path].decode()
    owner = replace(owner, 'use ep_model::{SurfaceId, TypedModel, ZoneId};', 'use ep_model::{SurfaceId, TypedModel, ZoneId};\nuse std::collections::BTreeMap;')
    owner = replace(owner, '.any(|(s, association)| s.zone_id != association.zone_id)',
        '.any(|(s, association)| (s.surface_id, s.zone_id) != (association.surface_id, association.zone_id))')
    owner = replace(owner, 'if current != owner.layout || surfaces.len() != owner.inside_old.len()',
        'if current != owner.layout || surfaces.len() != owner.layout.surfaces().len()\n        || surfaces.len() != owner.inside_old.len()')
    owner = replace(owner, '''    pub(crate) fn after_full_correction(
        &mut self,
        zones: &mut [ZoneHeatBalanceState],
    ) -> Result<(), Unavailable> {
        self.validate_zones(zones)?;
        // The admitted A solver has already returned its current ZT. Preserve
        // the real temperature -> report -> humidity sequence before space copy.
        zones[0].mean_air_temperature_c = self.zone_zt.1;
        self.space_air.copy_zone_after_correction(''', '''    pub(crate) fn commit_zone_mat(
        &self,
        zones: &mut [ZoneHeatBalanceState],
    ) -> Result<(), Unavailable> {
        self.validate_zones(zones)?;
        // Original4118: actual retained ZT -> MAT before sensible report/humidity.
        zones[0].mean_air_temperature_c = self.zone_zt.1;
        Ok(())
    }

    pub(crate) fn after_full_correction(
        &mut self,
        zones: &[ZoneHeatBalanceState],
    ) -> Result<(), Unavailable> {
        self.validate_zones(zones)?;
        // Original3843-3845: disabled-space copy after the full correction returns.
        // ZTAV remains its independent previous owner.
        self.space_air.copy_zone_after_correction(''')
    owner = replace(owner, '    pub(crate) fn capture_inside_entry(\n', '''    fn reference_air_by_layout(&self) -> Result<BTreeMap<SurfaceId, f64>, Unavailable> {
        let rows = self.space_air.rows();
        if rows.len() != self.layout.spaces().len()
            || rows.iter().zip(self.layout.spaces())
                .any(|(row, &(space, zone))| (row.space_id, row.zone_id) != (space, zone))
        {
            return Err(Unavailable::OrdinaryTemperatureOwner);
        }
        self.layout.surfaces().iter().map(|surface| {
            let row = rows.iter().find(|row| row.space_id == surface.space_id
                && row.zone_id == surface.zone_id).ok_or(Unavailable::OrdinaryTemperatureOwner)?;
            Ok((surface.surface_id, row.mat))
        }).collect()
    }

    pub(crate) fn prepare_inside_entry(
        &mut self,
        model: &TypedModel,
        zones: &[ZoneHeatBalanceState],
        surfaces: &mut [SurfaceHeatBalanceState],
    ) -> Result<BTreeMap<SurfaceId, f64>, Unavailable> {
        validate(self, model, zones, surfaces)?;
        let reference_air = self.reference_air_by_layout()?;
        // HBSM8739-8741, DataSurfaces221-225: commit actual SpaceMAT before Old.
        // Complete typed layout and array association are checked before any write.
        for surface in surfaces.iter_mut() {
            surface.inside_reference_air_temperature_c = reference_air[&surface.surface_id];
        }
        self.capture_inside_entry(surfaces)?;
        Ok(reference_air)
    }

    pub(crate) fn capture_inside_entry(
''')
    proposed[owner_path] = owner.encode()

    timestep_path = 'crates/ep_runtime/src/heat_balance/timestep.rs'
    timestep = proposed[timestep_path].decode()
    timestep = replace(timestep, '''    if let Some(owner) = &mut state.ordinary_inside_temperatures {
        owner.capture_inside_entry(&state.surfaces).map_err(Error::from)?;
    }
    let interleaved_surface_zone_balance_result =''', '''    let ordinary_reference_air_temperatures = if let Some(owner) = &mut state.ordinary_inside_temperatures {
        Some(owner.prepare_inside_entry(model, &state.zones, &mut state.surfaces).map_err(Error::from)?)
    } else {
        None
    };
    let interleaved_surface_zone_balance_result =''')
    timestep = replace(timestep, '''                    false,
                );

                if runtime_config''', '''                    false,
                    ordinary_reference_air_temperatures.as_ref(),
                );

                if runtime_config''')
    timestep = replace(timestep, '''                        false,
                    );
                }
                None''', '''                        false,
                        None,
                    );
                }
                None''')
    timestep = replace(timestep, '''                // Native uncontrolled MAT -> sensible demand report -> humidity.''', '''                if let Some(owner) = &state.ordinary_inside_temperatures {
                    owner.commit_zone_mat(&mut state.zones).map_err(Error::from)?;
                }
                // Native uncontrolled MAT -> sensible demand report -> humidity.''')
    timestep = replace(timestep, 'owner.after_full_correction(&mut state.zones)', 'owner.after_full_correction(&state.zones)')
    proposed[timestep_path] = timestep.encode()

    loop_path = 'crates/ep_runtime/src/heat_balance/surface_loop.rs'
    loop_text = proposed[loop_path].decode()
    loop_text = replace(loop_text, '''            use_inside_ctf_outside_temperature_for_conduction_report,
        );
        if freeze_outside''', '''            use_inside_ctf_outside_temperature_for_conduction_report,
            None,
        );
        if freeze_outside''')
    loop_text = replace(loop_text, '''    use_inside_ctf_outside_temperature_for_conduction_report: bool,
) {
    for surface_iteration_index''', '''    use_inside_ctf_outside_temperature_for_conduction_report: bool,
    // Some is a complete caller-validated surface -> actual SpaceMAT snapshot.
    ordinary_reference_air_temperatures: Option<&BTreeMap<SurfaceId, f64>>,
) {
    for surface_iteration_index''')
    loop_text = replace(loop_text, '            surface.inside_reference_air_temperature_c = zone_temperature_c;', '''            let reference_air_temperature_c = match ordinary_reference_air_temperatures {
                Some(temperatures) => temperatures[&surface.surface_id],
                None => zone_temperature_c,
            };
            surface.inside_reference_air_temperature_c = reference_air_temperature_c;''')
    loop_text = replace(loop_text, '''                        previous_inside_face_temperature_c,
                        zone_temperature_c,
                    )''', '''                        previous_inside_face_temperature_c,
                        reference_air_temperature_c,
                    )''')
    loop_text = replace(loop_text, '''                    reference_air_temperature_c: zone_temperature_c,
                });''', '''                    reference_air_temperature_c,
                });''')
    loop_text = replace(loop_text, '''                    CtfInsideFaceBalanceInput {
                        reference_air_temperature_c: zone_temperature_c,''', '''                    CtfInsideFaceBalanceInput {
                        reference_air_temperature_c,''')
    proposed[loop_path] = loop_text.encode()
    part4 = 'crates/ep_runtime/src/runtime/tests/part04.rs'
    proposed[part4] = replace(proposed[part4].decode(), '            false,\n        );\n\n        let surface = &state.surfaces[0];', '            false,\n            None,\n        );\n\n        let surface = &state.surfaces[0];', 2).encode()

    warm = proposed[warmup].decode()
    warm = replace(warm, 'assert_selected_temperature_resets_and_prefix(&mut simulation.state)?;',
        'assert_selected_temperature_resets_and_prefix(&model.typed, &mut simulation.state)?;')
    warm = replace(warm, '''fn assert_selected_temperature_resets_and_prefix(
    state: &mut crate::heat_balance::state::HeatBalanceState,''', '''fn assert_selected_temperature_resets_and_prefix(
    model: &TypedModel,
    state: &mut crate::heat_balance::state::HeatBalanceState,''')
    warm = replace(warm, '''    let owner = state.ordinary_inside_temperatures.as_mut().ok_or("missing owner")?;
    let zone = state.zones.first_mut().ok_or("missing actual zone")?;''', '''    let owner = state.ordinary_inside_temperatures.as_mut().ok_or("missing owner")?;
    let original_id = state.surfaces.first().ok_or("missing actual surface")?.surface_id;
    let stale_id = ep_model::SurfaceId(original_id.0.wrapping_add(1));
    state.surfaces[0].surface_id = stale_id;
    owner.inside_old[0].0 = stale_id;
    let old_before_validation = owner.inside_old.iter()
        .map(|&(id, value)| (id, value.to_bits())).collect::<Vec<_>>();
    let surfaces_before_validation = state.surfaces.iter().map(|surface|
        (surface.surface_id, surface.inside_face_temperature_c.to_bits(),
         surface.inside_reference_air_temperature_c.to_bits())).collect::<Vec<_>>();
    assert!(owner.prepare_inside_entry(model, &state.zones, &mut state.surfaces).is_err());
    assert_eq!(owner.inside_old.iter().map(|&(id, value)| (id, value.to_bits()))
        .collect::<Vec<_>>(), old_before_validation);
    assert_eq!(state.surfaces.iter().map(|surface|
        (surface.surface_id, surface.inside_face_temperature_c.to_bits(),
         surface.inside_reference_air_temperature_c.to_bits())).collect::<Vec<_>>(), surfaces_before_validation);
    state.surfaces[0].surface_id = original_id;
    owner.inside_old[0].0 = original_id;
    let last_surface = state.surfaces.pop().ok_or("missing surface prefix")?;
    let last_old = owner.inside_old.pop().ok_or("missing Old prefix")?;
    let old_prefix = owner.inside_old.iter().map(|&(id, value)| (id, value.to_bits())).collect::<Vec<_>>();
    let ref_air_prefix = state.surfaces.iter().map(|surface|
        surface.inside_reference_air_temperature_c.to_bits()).collect::<Vec<_>>();
    assert!(owner.prepare_inside_entry(model, &state.zones, &mut state.surfaces).is_err());
    assert_eq!(owner.inside_old.iter().map(|&(id, value)| (id, value.to_bits()))
        .collect::<Vec<_>>(), old_prefix);
    assert_eq!(state.surfaces.iter().map(|surface| surface.inside_reference_air_temperature_c.to_bits())
        .collect::<Vec<_>>(), ref_air_prefix);
    state.surfaces.push(last_surface);
    owner.inside_old.push(last_old);
    let zone = state.zones.first_mut().ok_or("missing actual zone")?;''')
    warm = replace(warm, '''    owner.after_full_correction(&mut state.zones).map_err(|_| "correction unavailable")?;''', '''    let spaces_before_commit = owner.space_air.clone();
    owner.commit_zone_mat(&mut state.zones).map_err(|_| "MAT commit unavailable")?;
    assert_eq!(owner.space_air, spaces_before_commit);
    assert_eq!(state.zones[0].mean_air_temperature_c.to_bits(), (-0.0_f64).to_bits());
    assert_eq!(state.zones[0].zone_timestep_average_air_temperature_c, 15.0);
    owner.after_full_correction(&state.zones).map_err(|_| "correction unavailable")?;''')
    warm = replace(warm, '''    owner.after_full_correction(&mut state.zones).map_err(|_| "reset ZT unavailable")?;''', '''    owner.commit_zone_mat(&mut state.zones).map_err(|_| "reset ZT unavailable")?;
    owner.after_full_correction(&state.zones).map_err(|_| "reset space copy unavailable")?;''')
    proposed[warmup] = warm.encode()
    tests_path = 'crates/ep_runtime/src/heat_balance/ordinary_inside_temperatures_tests.rs'
    proposed[tests_path] += b'''
#[test]
fn distinct_space_mat_supplies_complete_surface_map_and_rejects_stale_association()
-> Result<(), Box<dyn std::error::Error>> {
    let two_spaces = |second| InsideConvectionLayout::new(
        vec![ZoneId(7)], vec![(SpaceId(3), ZoneId(7)), (second, ZoneId(7))],
        vec![
            InsideConvectionAssociation {surface_id: SurfaceId(8), zone_id: ZoneId(7), space_id: SpaceId(3)},
            InsideConvectionAssociation {surface_id: SurfaceId(9), zone_id: ZoneId(7), space_id: second},
        ],
        vec![
            InsideConvectionGroup {zone_id: ZoneId(7), space_id: SpaceId(3), surfaces: vec![SurfaceId(8)]},
            InsideConvectionGroup {zone_id: ZoneId(7), space_id: second, surfaces: vec![SurfaceId(9)]},
        ],
    );
    let mut owner = OrdinaryInsideTemperatures::allocate(
        two_spaces(SpaceId(1)).map_err(|_| "invalid input layout")?
    ).map_err(|_| "allocation unavailable")?;
    let mut rows = owner.space_air.rows().to_vec();
    rows[0].mat = 11.0;
    rows[1].mat = 29.0;
    rows[1].ztav = -0.0;
    owner.space_air.write_all(&owner.layout, &rows)?;
    owner.retain_solution(ZoneId(7), 99.0).map_err(|_| "solution unavailable")?;
    let before = owner.clone();
    assert_eq!(owner.reference_air_by_layout().map_err(|_| "map unavailable")?,
        BTreeMap::from([(SurfaceId(8), 11.0), (SurfaceId(9), 29.0)]));
    assert_eq!(owner, before);
    owner.layout = two_spaces(SpaceId(2)).map_err(|_| "invalid stale input layout")?;
    assert!(owner.reference_air_by_layout().is_err());
    assert_eq!(owner.space_air.rows(), rows);
    Ok(())
}
'''

    # Validate the finite chosen bases and all existing immutable Original bytes first.
    original_rows = []
    for row in parent['Original_ranges']:
        checked(row['Source']); checked(row['literal_archive'])
        if row['Source']['path'].endswith('ZoneTempPredictorCorrector.cc') and row['first_line'] == 4112:
            continue
        original_rows.append(row)
    extras = [
        ('DataHeatBalance.hh', 429, 432, 'literal constructor23 and surface23 constants'),
        ('ZoneTempPredictorCorrector.cc', 4112, 4165, 'MAT before report/humidity then actual correctAirTemp return'),
        ('HeatBalanceSurfaceManager.cc', 8704, 8742, 'zone/space surface traversal and RefAir/TempEffBulkAir commit before Old'),
        ('DataSurfaces.cc', 199, 266, 'full real getInsideAirTemperature; selected ZoneMeanAirTemp reads actual SpaceMAT'),
    ]
    range_bytes = []
    for name, start, end, purpose in extras:
        path = ROOT / '.reference/energyplus-src/26.1.0/src/EnergyPlus' / name
        lines = path.read_bytes().splitlines(keepends=True)
        range_bytes.append((ref(path), start, end, purpose, b''.join(lines[start - 1:end])))
    for name, data in before.items():
        path = ROOT / name
        assert (path.read_bytes() == data) if name in members else not path.exists(), name
    rows = []
    for index, name in enumerate(proposed):
        old = write(OUT / 'before' / name, before[name]) if name in members else None
        payload = write(OUT / 'proposed' / name, proposed[name])
        delta = write(OUT / 'diffs' / f'{index:02d}.diff', diff(before[name], proposed[name], name, new=name not in members))
        item = dict(canonical_path=name, new_destination_absent=name not in members,
                    actual_before=ref(ROOT / name) if name in members else None,
                    before_archive=old, proposed=payload, source_diff=delta)
        if name in prior:
            item['parent_proposal'] = next(r['proposed'] for r in parent['source_proposals'] if r['canonical_path'] == name)
            item['from_parent03_diff'] = write(OUT / 'from-parent03-diffs' / f'{index:02d}.diff', diff(prior[name], proposed[name], name))
        rows.append(item)
    for source, start, end, purpose, data in range_bytes:
        literal = write(OUT / 'ranges' / f'{Path(source["path"]).name}.{start}-{end}.literal', data)
        original_rows.append(dict(Source=source, first_line=start, last_line=end, purpose=purpose, literal_archive=literal))
    readme = write(OUT / 'README.md', b'''# Ordinary A temperature owner04: one held rebase and minimal shared-MAT connection

The prior eight existing bases were checked against current Source_d70. Seven
are exact03; only warmup_ordinary_reports wind_direction_deg spacing changed.
Two new existing bases supply surface_loop and its two direct runtime test calls.
Twelve proposals (ten existing/two new) retain the exact current production bases.

Constructor/reset is ZoneZT/MAT/ZTAV23 and SpaceMAT/ZT/ZTAV23. Independent Old
starts0 and is not BeginEnv-reset. The actual existing one-pass SimplifiedAnalytical
predictor retains its own return as ZT. MAT commits before sensible report/humidity;
disabled-space ZT/MAT copy follows full correction while SpaceZTAV is preserved.
ZoneZTAV existing production updates are unchanged; no new ZTAV lifecycle is inferred.

At inside entry, validate typed zone/space/surface identities and the complete
SpaceAirTemperatures array, derive all surface RefAir values from actual SpaceMAT,
commit RefAir, then copy Old<-In. Radiation and existing inside solve follow.
Only admitted noninterleaved A receives that full snapshot. Interleaved, rebalance
and both direct legacy tests pass None. Outside zone-map/quick-outside values remain
unchanged. This connects the real retained SpaceMAT consumer without activating
InitIntConvCoeff, dispatcher readiness, cadence30 or a legacy TARP equivalence claim.

Authored tests cover distinct two-space MAT versus retained zoneZT, stale full
space association and simultaneous surface/Old ID rejection before any write,
MAT-before-space-copy, signed-zero Old independence, wrong zone prefix, reset
and admission. They have not run. The separate held conventional table-test
draft consumes Root-approved actual Native BEFORE/AFTER owners for reset, Old,
MAT, aggregate disabled-space copy and shared-MAT snapshot only. Its fixture and
expected observations are unknown here; the draft is not in source_proposals.
No Native solution may be supplied to the production solver.

Application remains held until new genuine Native Space/Old8809/RefAir facts,
Root and independent Source review and input scope are accepted. Original solver
and full ordinary/run/handoff parity remain gaps. After approved application,
run affected owner/ordinary-report/legacy-surface/input-control tests, then one
consolidated fmt/Clippy/workspace verification. No current or future receipts,
test counts, Native output values, numerical PASS or gate changes are supplied.
''')
    shared_name = 'crates/ep_runtime/src/heat_balance/inside_convection_dispatcher.rs'
    native_draft = write(OUT / 'ordinary-native-owner-replay-test.draft.rs',
        Path(__file__).with_name('ordinary-native-owner-replay-test.draft.rs').read_bytes())
    manifest = dict(
        schema='src06-ordinary-temperature-owner-Source-preparation.v1', status='held-Source-only-unexecuted',
        parent_preparation=ref(PARENT), actual_before_Source_snapshot=SOURCE,
        actual_review_time_Git_HEAD=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        source_proposals=rows, Original_ranges=original_rows, own_sources=[ref(Path(__file__)), readme, native_draft],
        shared_space_owner_Source=dict(actual_current=ref(ROOT / shared_name), immutable_archive=members[shared_name]['archive']),
        rebase_only_actual_before_change=dict(canonical_path=warmup, before='wind_direction_deg=-0.0;', after='wind_direction_deg= -0.0;'),
        all_ten_current_existing_bases_verified=True, both_new_destinations_absent=True,
        current_full_Source_payload_cloned=False, current_Source_map_members_rehashed_in_full=False,
        direct_diff_scope='MAT/correction phases, validated shared SpaceMAT snapshot and exact surface IDs, two-space/stale-ID tests, two legacy None arguments; other proposal payloads exact03',
        Native_operation_replay=dict(fixture=None, expected_observations=None,
            held_conventional_test_draft=native_draft, draft_in_source_proposals=False,
            pending_actual_boundaries=['constructor/reset', 'Old copy at Original8809', 'ZT-to-MAT commit', 'disabled-space copy preserving ZTAV', 'SpaceMAT-to-surface RefAir'],
            production_Native_solution_injection_allowed=False, full_solver_parity_claimed=False),
        planned_affected_test_filters=['heat_balance::ordinary_inside_temperatures::tests',
            'ordinary_a_records_warmup_and_every_run_step_reports_only_complete_first_day',
            'surface_balance_pass_can_freeze', 'warmup_report_controls::tests'],
        planned_integrated_quality='one fmt/Clippy/workspace validation after affected tests and accepted application',
        application_authority_supplied=False, tests_executed=False, targets_executed=False,
        canonical_mutation=False, Native_or_Rust_results_read_during_authorship=False,
        numerical_PASS_claimed=False, whole_ordinary_PASS_claimed=False, gates_updated=False)
    for name, data in before.items():
        path = ROOT / name
        assert (path.read_bytes() == data) if name in members else not path.exists(), name
    result = dump(OUT / 'manifest.json', manifest)
    print(json.dumps(result))


if __name__ == '__main__':
    main()

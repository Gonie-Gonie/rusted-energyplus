"""Bind actual provider facts and pinned runtime inputs before one Native run."""
import hashlib
import json
import mmap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/Root-ordinary-temperature-provider-review-01'


def ref(path):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else path.as_posix(),
            'sha256': digest, 'size_bytes': path.stat().st_size}


def checked(row):
    path = ROOT / row['path']
    actual = ref(path)
    assert actual['sha256'] == row['sha256']
    assert 'size_bytes' not in row or actual['size_bytes'] == row['size_bytes']
    return path


def load(row):
    return json.loads(checked(row).read_bytes())


def write(name, value):
    path = OUT / name
    with path.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
    return ref(path)


build_ref = ref(ROOT / '.runtime/porting/SRC-06/ordinary-temperature-native-build-01/native-build.json')
assert build_ref['sha256'] == '3137526b5c860c6662cfb6f80339e963f1e2c462580ea05715cd6cf718dec8f2'
build = load(build_ref)
peer_ref = ref(ROOT / '.runtime/porting/SRC-06/Header-ordinary-temperature-provider-review-01/review.json')
assert peer_ref['sha256'] == 'c8117d0ea3f0ceefd876c8abea356fb4c1fd526489c80f17359232eae69c0f5a'
peer = load(peer_ref)
assert peer['accepted'] and peer['helper_binary'] == build['helper_binary']
assert peer['native_build']['sha256'] == build_ref['sha256']
prep = load(build['native_source_manifest'])
mapping = json.loads((OUT / 'pe.json').read_bytes())
assert mapping == load(peer['actual_PE'])
assert mapping['sha256'] == build['helper_binary']['sha256']
assert mapping['machine'] == 0x8664 and len(mapping['sections']) == 20
providers = load(peer['actual_address_bound_providers'])
assert len(providers) == 22
expected_sources = {row['path']: row['sha256'] for row in prep['payload'] + prep['unchanged_Original_target_TUs']}
expected_sources['.reference/energyplus-src/26.1.0/src/EnergyPlus/DataSurfaces.cc'] = 'c80eaefe852c5deebdb5f6eab35a58b0d7500d887218cbcdeaacb8573e4044ff'
wanted_lines = {}
with checked(build['helper_binary']).open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
    for row in providers:
        source = row['actual_source']
        assert expected_sources[source['path']] == source['sha256']
        checked(source)
        rva = row['address'] - mapping['image_base']
        length = row['end'] - row['address']
        sections = [s for s in mapping['sections'] if s['characteristics'] & 0x20000000
                    and s['rva'] <= rva and rva + length <= s['rva'] + s['raw_size']]
        assert len(sections) == 1 and length == row['code_byte_count'] > 0
        section = sections[0]
        offset = section['raw_offset'] + rva - section['rva']
        assert offset == row['PE_raw_offset'] and section['name'] == row['PE_section']
        assert hashlib.sha256(data[offset:offset + length]).hexdigest() == row['code_bytes_sha256']
        assert row['section']['start'] <= row['address'] < row['end'] <= row['section']['start'] + row['section']['size']
        assert row['section']['owner'] == row['spec']['owner']
        wanted_lines[row['line']] = row['literal']
        wanted_lines[row['section']['line']] = row['section']['literal']
with checked(build['map_file']).open(encoding='utf8') as stream:
    for number, line in enumerate(stream, 1):
        if number in wanted_lines:
            assert line.rstrip('\n') == wanted_lines.pop(number)
assert not wanted_lines
addr = load(peer['actual_addr2line_execution'])
assert addr['exit_code'] == 0 and addr['source_bytes_match_before_and_after']
assert addr['source_snapshot'] == prep['Rust_Source_snapshot']
resolved = checked(addr['stdout']).read_text(encoding='utf8').splitlines()
assert len(resolved) == 2 * len(providers)
for index, row in enumerate(providers):
    assert resolved[2 * index] == row['symbol'] == row['actual_addr2line_function']
    assert resolved[2 * index + 1].replace('\\', '/') == row['actual_addr2line_location']
assert build['core_archive_before'] == build['core_archive_after']
assert build['core_archive_after']['sha256'] == '32d873007f14c3f8e3c66c6280ebd508c7cb595cea28f4a20f47ac745113a694'
provider_ref = write('review.json', {
    'schema': 'src06-ordinary-temperature-Root-provider-acceptance.v1', 'accepted': True,
    'native_build': build_ref, 'binary': build['helper_binary'], 'native_source_manifest': build['native_source_manifest'],
    'independent_provider_review': peer_ref, 'independent_full_PE': ref(OUT / 'pe.json'),
    'actual_address_bound_providers': peer['actual_address_bound_providers'],
    'actual_addr2line_execution': peer['actual_addr2line_execution'],
    'all_22_actual_provider_byte_ranges_and_map_lines_rechecked': True,
    'full_PE_independently_recomputed_equal': True, 'core_matches_accepted_SRC05_baseline': True,
    'helper_executed': False, 'scientific_PASS_claimed': False, 'gates_updated': False,
    'review_Source': ref(Path(__file__))})
dll_dir = ROOT / '.runtime/reference-tools/winlibs-gcc13.2.0-ucrt-r3/mingw64/bin'
pins = {'libgcc_s_seh-1.dll': '403b4169b307d0bfb27a9cbcccbca491efe634eb0462fc1f3fc5ace373bd2827',
        'libstdc++-6.dll': '748b10c9f25828fbc78e8eaf50355e7f178d0ed0438d2c396565b56c5bd4ac0a',
        'libwinpthread-1.dll': 'a086938c9612746fda0ab8640b8d21e8d36bc3e53c1e8e70f9896888b41607dd'}
dlls = [ref(dll_dir / name) for name in pins]
assert all(row['sha256'] == pins[Path(row['path']).name] for row in dlls)
roles = [{'role': role, 'execution': build['build_commands'][key]}
         for role, key in [('configure', 'configure'), ('dry_run', 'dry_run'), ('compile', 'compile')]]
for row in roles:
    receipt = load(row['execution'])
    assert receipt['exit_code'] == 0 and receipt['launch_error'] is None
    assert receipt['source_bytes_match_before_and_after'] and receipt['source_snapshot'] == prep['Rust_Source_snapshot']
closure = write('runtime-closure.json', {
    'schema': 'src06-ordinary-temperature-native-runtime-closure.v1', 'accepted': True,
    'native_build': build_ref, 'native_source_manifest': build['native_source_manifest'],
    'helper_binary': build['helper_binary'], 'Source_snapshot': prep['Rust_Source_snapshot'],
    'pinned_runtime_DLLs': dlls, 'provider_review': provider_ref, 'build_commands': roles})
print(json.dumps({'provider_review': provider_ref, 'runtime_closure': closure}))

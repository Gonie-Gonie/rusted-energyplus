//! Final assembly of initialized heat-balance state and cache diagnostics.

use crate::heat_balance::state::{
    HeatBalanceState, HeatBalanceSurfaceIndexes, SurfaceHeatBalanceState, ZoneHeatBalanceState,
};
use crate::heat_balance::surface_manager::ConstructionThermalDataCache;

pub(super) fn finish_heat_balance_state(
    zones: Vec<ZoneHeatBalanceState>,
    initialized_geometry: crate::geometry::InitializedGeometryOwners,
    surfaces: Vec<SurfaceHeatBalanceState>,
    surface_indexes: HeatBalanceSurfaceIndexes,
    mut construction_thermal_data: ConstructionThermalDataCache,
    ctf_surface_lifecycle: Option<super::super::ctf_surface_lifecycle::CtfSurfaceLifecycle>,
) -> HeatBalanceState {
    HeatBalanceState {
        timestep_index: 0,
        zones,
        initialized_geometry,
        warmup_convergence: None,
        ordinary_inside_temperatures: None,
        zone_air_environment_guard: Default::default(),
        surfaces,
        surface_indexes,
        construction_cache_hash: construction_thermal_data.coefficient_cache_hash,
        construction_ctf01_layers: construction_thermal_data.layer_preprocessing(),
        construction_ctf02_coefficients: construction_thermal_data.all_resistive_coefficients(),
        construction_ctf03_initial: construction_thermal_data.initial_discretizations(),
        construction_ctf04_first_assembly: construction_thermal_data.first_assemblies(),
        construction_ctf06_first_exponential: construction_thermal_data.first_exponentials(),
        construction_ctf05_first_inverse: construction_thermal_data.first_inverses(),
        construction_ctf07_first_gammas: construction_thermal_data.first_gammas(),
        construction_ctf08_first_private_coefficients: construction_thermal_data
            .first_private_coefficients(),
        construction_ctf09_retry_driver: construction_thermal_data.take_retry_initializations(),
        construction_ctf10_public_initialization: construction_thermal_data
            .take_public_initialization(),
        ctf_surface_lifecycle,
        ctf_history_caller_clock: Default::default(),
        construction_cache_build_wall_seconds: construction_thermal_data.build_wall_seconds,
        construction_cache_entry_count: construction_thermal_data.len(),
        construction_cache_no_mass_count: construction_thermal_data.no_mass_construction_ids.len(),
        construction_cache_massive_ctf_count: construction_thermal_data
            .massive_ctf_construction_ids
            .len(),
        construction_cache_eio_seeded_count: construction_thermal_data.eio_seeded_count(),
        construction_cache_rust_generated_count: construction_thermal_data.rust_generated_count(),
        variable_system_timestep_placeholder: true,
        hvac_iteration_count: 0,
        plant_iteration_count: 0,
        last_ctf_history_slot_terms: Vec::new(),
        last_ctf_history_slot_terms_after_advance: Vec::new(),
        last_inside_surface_iteration_count: 0,
        last_inside_surface_iteration_max_delta_c: f64::NAN,
        last_inside_surface_iteration_max_delta_surface_name: None,
    }
}

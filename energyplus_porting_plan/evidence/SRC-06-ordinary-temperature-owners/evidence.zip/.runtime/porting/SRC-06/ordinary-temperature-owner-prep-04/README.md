# Ordinary A temperature owner04: one held rebase and minimal shared-MAT connection

The prior eight existing bases were checked against current Source_d70. Seven
are exact03; only warmup_ordinary_reports wind_direction_deg spacing changed.
Two new existing bases supply surface_loop and its two direct runtime test calls.
Twelve proposals (ten existing/two new) retain the exact current production bases.

Constructor/reset is ZoneZT/MAT/ZTAV23 and SpaceMAT/ZT/ZTAV23. Independent Old
starts0 and is not BeginEnv-reset. The actual existing one-pass SimplifiedAnalytical
predictor retains its own return as ZT. MAT commits before sensible report/humidity;
disabled-space ZT/MAT copy follows full correction while SpaceZTAV is preserved.
ZoneZTAV existing production updates are unchanged; no new ZTAV lifecycle is inferred.

At inside entry, validate typed zone/space/surface identities and the complete
SpaceAirTemperatures array, derive all surface RefAir values from actual SpaceMAT,
commit RefAir, then copy Old<-In. Radiation and existing inside solve follow.
Only admitted noninterleaved A receives that full snapshot. Interleaved, rebalance
and both direct legacy tests pass None. Outside zone-map/quick-outside values remain
unchanged. This connects the real retained SpaceMAT consumer without activating
InitIntConvCoeff, dispatcher readiness, cadence30 or a legacy TARP equivalence claim.

Authored tests cover distinct two-space MAT versus retained zoneZT, stale full
space association and simultaneous surface/Old ID rejection before any write,
MAT-before-space-copy, signed-zero Old independence, wrong zone prefix, reset
and admission. They have not run. The separate held conventional table-test
draft consumes Root-approved actual Native BEFORE/AFTER owners for reset, Old,
MAT, aggregate disabled-space copy and shared-MAT snapshot only. Its fixture and
expected observations are unknown here; the draft is not in source_proposals.
No Native solution may be supplied to the production solver.

Application remains held until new genuine Native Space/Old8809/RefAir facts,
Root and independent Source review and input scope are accepted. Original solver
and full ordinary/run/handoff parity remain gaps. After approved application,
run affected owner/ordinary-report/legacy-surface/input-control tests, then one
consolidated fmt/Clippy/workspace verification. No current or future receipts,
test counts, Native output values, numerical PASS or gate changes are supplied.

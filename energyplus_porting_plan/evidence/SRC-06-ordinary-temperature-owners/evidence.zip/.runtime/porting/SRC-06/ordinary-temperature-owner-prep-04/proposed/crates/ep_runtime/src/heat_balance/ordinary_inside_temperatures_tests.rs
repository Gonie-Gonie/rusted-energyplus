use super::*;
use crate::heat_balance::inside_convection_layout::{
    InsideConvectionAssociation, InsideConvectionGroup,
};
use ep_model::SpaceId;

fn layout() -> Result<InsideConvectionLayout, Box<dyn std::error::Error>> {
    Ok(InsideConvectionLayout::new(
        vec![ZoneId(7)],
        vec![(SpaceId(3), ZoneId(7)), (SpaceId(1), ZoneId(7))],
        vec![InsideConvectionAssociation {
            surface_id: SurfaceId(8), zone_id: ZoneId(7), space_id: SpaceId(3),
        }],
        vec![
            InsideConvectionGroup {zone_id: ZoneId(7), space_id: SpaceId(1), surfaces: vec![]},
            InsideConvectionGroup {zone_id: ZoneId(7), space_id: SpaceId(3), surfaces: vec![SurfaceId(8)]},
        ],
    ).map_err(|_| "invalid authored layout")?)
}

#[test]
fn solved_zt_is_separate_from_space_and_old_and_wrong_zone_retains_prefix()
-> Result<(), Box<dyn std::error::Error>> {
    let mut owner = OrdinaryInsideTemperatures::allocate(layout()?)
        .map_err(|_| "allocation unavailable")?;
    assert_eq!(owner.inside_old, vec![(SurfaceId(8), 0.0)]);
    assert_eq!(owner.space_air.rows()[0].space_id, SpaceId(3));
    let mut declared = owner.space_air.rows().to_vec();
    declared[0].mat = -7.0;
    declared[0].zt = 31.0;
    declared[0].ztav = -0.0;
    owner.space_air.write_all(&owner.layout, &declared)?;
    owner.retain_solution(ZoneId(7), f64::from_bits(0x8000_0000_0000_0000))
        .map_err(|_| "actual solution unavailable")?;
    let before = owner.clone();
    assert!(owner.retain_solution(ZoneId(2), 400.0).is_err());
    assert_eq!(owner, before);
    assert_eq!(owner.zone_zt.1.to_bits(), (-0.0_f64).to_bits());
    assert_eq!(owner.space_air.rows()[0].mat, -7.0);
    assert_eq!(owner.space_air.rows()[0].zt, 31.0);
    assert_eq!(owner.space_air.rows()[0].ztav.to_bits(), (-0.0_f64).to_bits());
    Ok(())
}

#[test]
fn adaptive_and_multiple_inside_passes_are_explicitly_unavailable() {
    let options = super::super::state::HeatBalanceSimulationOptions::hourly_samples(1);
    let config = options.zone_air_algorithm.runtime_config();
    assert!(admit_config(config, 1).is_ok());
    assert!(admit_config(config, 2).is_err());
    let compatibility = super::super::algorithm::CompatibilityHeatBalanceAlgorithm::SourceOrder1ZoneOpaqueCompat.runtime_config();
    assert!(admit_config(compatibility, 1).is_err());
}

#[test]
fn distinct_space_mat_supplies_complete_surface_map_and_rejects_stale_association()
-> Result<(), Box<dyn std::error::Error>> {
    let two_spaces = |second| InsideConvectionLayout::new(
        vec![ZoneId(7)], vec![(SpaceId(3), ZoneId(7)), (second, ZoneId(7))],
        vec![
            InsideConvectionAssociation {surface_id: SurfaceId(8), zone_id: ZoneId(7), space_id: SpaceId(3)},
            InsideConvectionAssociation {surface_id: SurfaceId(9), zone_id: ZoneId(7), space_id: second},
        ],
        vec![
            InsideConvectionGroup {zone_id: ZoneId(7), space_id: SpaceId(3), surfaces: vec![SurfaceId(8)]},
            InsideConvectionGroup {zone_id: ZoneId(7), space_id: second, surfaces: vec![SurfaceId(9)]},
        ],
    );
    let mut owner = OrdinaryInsideTemperatures::allocate(
        two_spaces(SpaceId(1)).map_err(|_| "invalid input layout")?
    ).map_err(|_| "allocation unavailable")?;
    let mut rows = owner.space_air.rows().to_vec();
    rows[0].mat = 11.0;
    rows[1].mat = 29.0;
    rows[1].ztav = -0.0;
    owner.space_air.write_all(&owner.layout, &rows)?;
    owner.retain_solution(ZoneId(7), 99.0).map_err(|_| "solution unavailable")?;
    let before = owner.clone();
    assert_eq!(owner.reference_air_by_layout().map_err(|_| "map unavailable")?,
        BTreeMap::from([(SurfaceId(8), 11.0), (SurfaceId(9), 29.0)]));
    assert_eq!(owner, before);
    owner.layout = two_spaces(SpaceId(2)).map_err(|_| "invalid stale input layout")?;
    assert!(owner.reference_air_by_layout().is_err());
    assert_eq!(owner.space_air.rows(), rows);
    Ok(())
}

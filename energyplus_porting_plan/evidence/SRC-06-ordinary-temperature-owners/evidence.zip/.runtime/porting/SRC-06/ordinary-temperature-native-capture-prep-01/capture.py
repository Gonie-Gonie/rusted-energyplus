"""Root-reviewed single actual Native capture; no retries, dry/fake engine or math."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[4]
NATIVE_PREP = ROOT / '.runtime/porting/SRC-06/ordinary-temperature-native-prep-01/manifest.json'
NATIVE_PREP_SHA = 'd74663fe849903dbb6a6c4f648ef2c2e6e422ced08e8bd49fb25fff809b51660'
OUT = Path('D:/CodexBuild/rusted-energyplus/SRC-06/ordinary-temperature-native-capture-01')
MAX_RAW_BYTES = 4 * 1024**3
DLL_NAMES = {'libgcc_s_seh-1.dll', 'libstdc++-6.dll', 'libwinpthread-1.dll'}
FIXED = [
    {'path': 'energyplus_porting_plan/cases/A-24H/input.idf',
     'sha256': 'db66ac75d3ed26b6e7cd35c6f09b02a05110e800a16713eccee47e387d6c3755', 'size_bytes': 9275},
    {'path': '.runtime/energyplus/26.1.0/WeatherData/USA_CO_Golden-NREL.724666_TMY3.epw',
     'sha256': 'c184b947cd34d41c6d6474d63d66dbb82bc0e6cae4c888edcf837348282bce7f', 'size_bytes': 1623506},
    {'path': '.runtime/energyplus/26.1.0/Energy+.idd',
     'sha256': '7d30c281aa21d63555c753a953124da03d88b6b149dc19e3649f2cbe6c944c68', 'size_bytes': 4613646},
]

def path(value):
    return (ROOT / value).resolve()

def ref(file):
    file = file.resolve()
    with file.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    name = file.relative_to(ROOT).as_posix() if file.is_relative_to(ROOT) else str(file)
    return {'path': name, 'sha256': digest, 'size_bytes': file.stat().st_size}

def verify(row):
    actual = ref(path(row['path']))
    assert actual['sha256'] == row['sha256'] and actual['size_bytes'] == row['size_bytes'], row['path']
    return actual

def bound(value):
    name, digest = value.rsplit('#', 1)
    actual = ref(path(name))
    assert actual['sha256'] == digest
    return actual, json.loads(path(name).read_bytes())

def write(file, value):
    with file.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--native-build', required=True, help='actual JSON path#sha256')
    parser.add_argument('--runtime-closure', required=True, help='Root accepted actual JSON path#sha256')
    args = parser.parse_args()
    build_ref, build = bound(args.native_build)
    closure_ref, closure = bound(args.runtime_closure)
    prep_ref = ref(NATIVE_PREP)
    assert prep_ref['sha256'] == NATIVE_PREP_SHA
    prep = json.loads(NATIVE_PREP.read_bytes())
    assert closure['schema'] == 'src06-ordinary-temperature-native-runtime-closure.v1'
    assert closure['accepted'] is True and closure['native_build'] == build_ref
    assert closure['native_source_manifest'] == build['native_source_manifest'] == prep_ref
    assert closure['helper_binary'] == build['helper_binary']
    assert closure['Source_snapshot'] == prep['Rust_Source_snapshot']
    binary = path(closure['helper_binary']['path'])
    dlls = closure['pinned_runtime_DLLs']
    assert len(dlls) == 3 and {path(x['path']).name for x in dlls} == DLL_NAMES
    loader_dir = ROOT / '.runtime/reference-tools/winlibs-gcc13.2.0-ucrt-r3/mingw64/bin'
    assert {path(x['path']).parent for x in dlls} == {loader_dir.resolve()}
    provider_ref = verify(closure['provider_review'])
    provider = json.loads(path(provider_ref['path']).read_bytes())
    assert provider['accepted'] is True and provider['native_build'] == build_ref
    assert provider['binary'] == closure['helper_binary'] and provider['native_source_manifest'] == prep_ref
    roles = closure['build_commands']
    assert [x['role'] for x in roles] == ['configure', 'dry_run', 'compile']
    command_refs = []
    for row in roles:
        command_refs.append(verify(row['execution']))
        receipt = json.loads(path(row['execution']['path']).read_bytes())
        assert receipt['schema'] == 'recorded-porting-command.v1' and receipt['exit_code'] == 0
        assert receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after'] is True
        assert receipt['source_snapshot'] == closure['Source_snapshot']
    # No arbitrary input/native flags are accepted. Seven ordinary native argv
    # elements are exactly Native05's option sequence, with a fresh output dir.
    native_argv = ['-i', str(path(FIXED[2]['path'])), '-w', str(path(FIXED[1]['path'])),
                   '-d', str(OUT / 'A-24H'), str(path(FIXED[0]['path']))]
    assert len(native_argv) == 7
    argv = [str(binary), '--surface-observation-file', str(OUT / 'A-24H.observation.json'), '--', *native_argv]
    # PATH is prefixed with the pinned toolchain. Reject earlier Windows DLL
    # search locations that could silently shadow these three selected files.
    system = Path(os.environ['SystemRoot'])
    earlier_dirs = {binary.parent, ROOT, system / 'System32', system / 'System', system}
    assert not any((directory / name).exists() for directory in earlier_dirs for name in DLL_NAMES)
    env = dict(os.environ)
    inherited_path = env.get('PATH', '')
    env['PATH'] = str(loader_dir.resolve()) + os.pathsep + inherited_path
    guards = [prep_ref, build_ref, closure_ref, provider_ref, *command_refs,
              *prep['payload'], *prep['unchanged_Original_target_TUs'],
              closure['helper_binary'], *dlls, *FIXED, ref(Path(__file__))]
    before_guards = [verify(row) for row in guards]
    assert not OUT.exists(), 'Fresh fixed capture directory required; retained outputs are never overwritten'
    OUT.mkdir(parents=True)
    write(OUT / 'before.json', {
        'schema': 'src06-ordinary-temperature-native-capture-before.v1',
        'native_build': build_ref, 'runtime_closure': closure_ref, 'native_source_manifest': prep_ref,
        'provider_review': provider_ref, 'Source_snapshot': closure['Source_snapshot'],
        'actual_native_argv': native_argv, 'actual_helper_argv': argv, 'cwd': str(ROOT),
        'pinned_runtime_DLLs': dlls, 'loader_PATH_prefix': str(loader_dir.resolve()),
        'inherited_PATH': inherited_path, 'actual_PATH': env['PATH'],
        'no_named_DLL_shadows_in_exe_cwd_system_directories': True,
        'guards': before_guards, 'maximum_raw_bytes_postcheck_only': MAX_RAW_BYTES,
    })
    start = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    native_exit, launch_error = None, None
    with (OUT / 'native-stdout.log').open('xb') as stdout, (OUT / 'native-stderr.log').open('xb') as stderr:
        try:
            # Exactly one actual normal-engine child. No timeout, retry, shell,
            # alternate fixture, synthetic data, or shortened-engine option.
            native_exit = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr).returncode
        except OSError as error:
            launch_error = {'type': type(error).__name__, 'message': str(error)}
    elapsed = time.monotonic() - tick
    finish = datetime.now(timezone.utc).isoformat()
    after_guards, guard_errors = [], []
    for row in guards:
        try:
            after_guards.append(verify(row))
        except (AssertionError, OSError) as error:
            guard_errors.append({'path': row['path'], 'error': str(error)})
    raw = OUT / 'A-24H.observation.json'
    raw_ref = ref(raw) if raw.is_file() else None
    raw_within_limit = raw_ref is not None and 0 < raw_ref['size_bytes'] <= MAX_RAW_BYTES
    normal = OUT / 'A-24H'
    normal_outputs = [ref(file) for file in sorted(normal.rglob('*')) if file.is_file()] if normal.is_dir() else []
    accepted = native_exit == 0 and launch_error is None and not guard_errors and raw_within_limit and bool(normal_outputs)
    custody = {
        'schema': 'src06-ordinary-temperature-native-capture-custody.v1',
        'native_build': build_ref, 'runtime_closure': closure_ref, 'native_source_manifest': prep_ref,
        'provider_review': provider_ref, 'Source_snapshot': closure['Source_snapshot'],
        'before': ref(OUT / 'before.json'), 'actual_native_argv': native_argv, 'actual_helper_argv': argv,
        'cwd': str(ROOT), 'started_utc': start, 'finished_utc': finish, 'elapsed_seconds': elapsed,
        'actual_native_child_count': 1, 'native_exit_code': native_exit, 'launch_error': launch_error,
        'native_stdout': ref(OUT / 'native-stdout.log'), 'native_stderr': ref(OUT / 'native-stderr.log'),
        'raw_observation': raw_ref, 'maximum_raw_bytes_postcheck_only': MAX_RAW_BYTES,
        'raw_within_limit': raw_within_limit, 'normal_engine_outputs': normal_outputs,
        'after_guards': after_guards, 'guard_errors': guard_errors,
        'input_executable_Source_DLL_bytes_unchanged': not guard_errors and after_guards == before_guards,
        'transport_custody_accepted': accepted, 'Native_owner_facts_checked': False,
        'Rust_comparison_performed': False, 'whole_ordinary_PASS_claimed': False, 'gates_updated': False,
    }
    write(OUT / 'custody.json', custody)
    print(json.dumps({'custody': ref(OUT / 'custody.json'), 'transport_custody_accepted': accepted}), flush=True)
    raise SystemExit(0 if accepted else 1)

if __name__ == '__main__':
    main()

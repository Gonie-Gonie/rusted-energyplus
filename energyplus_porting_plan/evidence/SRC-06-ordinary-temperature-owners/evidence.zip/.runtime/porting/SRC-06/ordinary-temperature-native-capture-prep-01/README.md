# One actual future temperature capture: held Source only

capture.py is a single Root-reviewed actual launch driver. It has not been
executed or imported. Root must first close the real seven-TU build/provider
review, then invoke it inside tools/porting/record_command.py with two immutable
runtime operands: --native-build ACTUAL_JSON#SHA and --runtime-closure
ACTUAL_JSON#SHA. Neither future hash nor successful receipt is prefilled.

The actual build JSON exposes native_source_manifest and helper_binary refs.
The small Root runtime closure uses schema
src06-ordinary-temperature-native-runtime-closure.v1 and contains accepted=true,
native_build, native_source_manifest, helper_binary, Source_snapshot,
pinned_runtime_DLLs, provider_review, and build_commands. Every ref has
path/sha256/size_bytes. build_commands has ordered configure/dry_run/compile
roles, each with an execution ref to its real closed recorded command receipt.
The provider_review actual JSON contains accepted=true and exact joins for
native_build, binary and native_source_manifest. These are actual reviewed
bindings, not an invitation to supply synthetic receipts. Root builds these
small records from the real build once; the capture driver does not repeat the
core/archive/map/protected inventory scan.

Before launch, the driver authenticates those runtime JSON refs and their joins,
mandatory Native Source preparation d74663fe, its current payload and two
Original entry/CLI TUs, the actual executable, three real loader DLLs and exact
existing A-24H input/weather/IDD hashes. It prefixes PATH with the pinned
toolchain and rejects matching DLL shadows in earlier exe/cwd/system locations.
It accepts no arbitrary simulation flags or alternative input paths. Seven
native arguments retain Native05's -i/-w/-d/input sequence; only the output path
and accepted new executable differ. subprocess.run executes that actual helper
exactly once with structured argv, no shell/timeout/retry/dry/fake/shortened run.

The fixed D:/CodexBuild/rusted-energyplus/SRC-06/
ordinary-temperature-native-capture-01 directory must be absent. before.json,
native stdout/stderr, the complete selected observation and every generated
normal-engine file are retained there. Post-run guards repeat only current
inputs/executable/Source/DLL and small binding refs. Raw capture size is checked
against four GiB after execution and hashed completely; oversize or nonzero
results are retained and return failure, never truncated or retried. custody.json
records direct child argv/time/exit, raw/log/output refs and guard results even
when those postchecks fail. Native owner facts, Rust comparison and integration
PASS remain unclaimed. The outer Root recorder supplies its actual command,
Source snapshot and repository custody.

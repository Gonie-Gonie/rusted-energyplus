# Held actual-owner04 convection input prerequisite

Fresh six-file delta on actual canonical owner04 after formatting and the actual
19-case Native replay addition. Preparation01 is preserved as anticipated history.
No canonical writes, Rust compilation, formatting or tests were run here.

Semantics remain preparation01: six actual RawModel family counts use existing
NoUserConvectionInput; HeatBalanceAlgorithm N2 retains constructor/blank0.1 or
finite positive input; the existing ordinary runtime validates and retains both.
No readiness/dispatcher/radiation/cadence/temperature algorithm activation occurs.
The independent opt-in scope still rejects overrides of its fixed0.1 setting.

The sole Native replay change is allocate(layout, authored zero counts, authored
0.1). Inverting that exact call change restores its entire prior suffix byte-for-
byte as UTF-8 text. Actual fixture b70b4595 remains unchanged; no expected values
are altered or introduced into production. Original ranges reuse the exact ten
literal archives preserved in01, with full Original Source hashes retained.

After review/application, run affected ep_run warmup_report_controls, ep_runtime
ordinary_inside_temperatures and the existing ordinary-A production regression,
then coordinate one integrated quality run. Existing actual36 focused results
precede this proposed delta and do not validate it.

"""Package this finite temperature unit; never run an engine, compiler or test."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / '.runtime/porting/SRC-06'
CAPTURE = Path('D:/CodexBuild/rusted-energyplus/SRC-06/ordinary-temperature-native-capture-01')
ROOTS = [
    'ordinary-temperature-native-prep-01', 'ordinary-temperature-native-build-prep-01',
    'ordinary-temperature-native-capture-prep-01', 'ordinary-temperature-owner-prep-04',
    'ordinary-temperature-comparison-prep-02', 'ordinary-temperature-native-build-01',
    'ordinary-temperature-native-build-command-01', 'ordinary-temperature-native-capture-command-01',
    'ordinary-temperature-owner-application-01', 'ordinary-temperature-format-command-01',
    'ordinary-temperature-native-factual-command-Root-01',
    'ordinary-temperature-native-factual-command-Root-02', 'ordinary-temperature-native-factual-Root-02',
    'Header-ordinary-temperature-native-factual-command-02', 'Header-ordinary-temperature-native-facts-02',
    'Root-ordinary-temperature-Native-Source-review-01', 'Header-ordinary-temperature-Native-Source-review-01',
    'Root-ordinary-temperature-build-Source-review-01', 'Root-ordinary-temperature-capture-Source-review-01',
    'Root-ordinary-temperature-factual-checker-Source-review-01',
    'Header-ordinary-temperature-Native-checker-Source-review-01',
    'Header-ordinary-temperature-Native-checker-Source-review-02',
    'Header-ordinary-temperature-comparison-policy-review-01',
    'Native-author-temperature-factual-checker-Source-review-01',
    'Native-author-ordinary-temperature-replay-Source-review-01',
    'Header-ordinary-temperature-owner-Source-review-04', 'Header-ordinary-temperature-owner-application-review-01',
    'Header-ordinary-temperature-provider-review-01', 'Root-ordinary-temperature-provider-review-01',
    'Header-ordinary-temperature-native-custody-review-01', 'Header-ordinary-temperature-native-factual-release-02',
    'Header-reference-branch-inventory-01', 'Header-reference-branch-inventory-command-01',
    'ordinary-temperature-native-archive-01',
]
GZIP = BASE / 'ordinary-temperature-native-archive-01/A-24H.observation.json.gz'
GZIP_SHA = 'ae9ebfda3417dc78d35506498a78a0bdee3602ca72dbb0c7e56b6914b30dcab4'
FORBIDDEN = {'.exe', '.dll', '.a', '.lib', '.o', '.obj', '.map', '.pdb', '.pyc', '.pyd'}


def need(value, message):
    if not value:
        raise ValueError(message)


def checked(row):
    path = Path(row['path'])
    path = path.resolve() if path.is_absolute() else (ROOT / path).resolve()
    need(path.is_file() and path.suffix.lower() not in FORBIDDEN and path.stat().st_size <= 32 * 1024 * 1024,
         'Disallowed/oversize pinned payload: ' + str(path))
    data = path.read_bytes()
    need(hashlib.sha256(data).hexdigest() == row['sha256'], 'Pinned bytes changed: ' + str(path))
    need('size_bytes' not in row or len(data) == row['size_bytes'], 'Pinned size changed: ' + str(path))
    return path, data


def read_ref(value):
    path, digest = value.rsplit('#', 1)
    row = {'path': path, 'sha256': digest}
    resolved, data = checked(row)
    return row, resolved, data


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', required=True, help='Root-authored actual inputs JSON path#SHA256')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    input_ref, input_path, input_bytes = read_ref(args.inputs)
    inputs = json.loads(input_bytes)
    need(inputs['schema'] == 'src06-temperature-publication-inputs.v1', 'Inputs schema differs')
    output = args.output_dir.resolve()
    need(not output.exists(), 'Fresh output directory required')
    need(not any(output == (BASE / name).resolve() or output.is_relative_to((BASE / name).resolve())
                 for name in ROOTS), 'Output must be outside selected evidence roots')
    members = {}

    def add(path, pinned=None, name=None):
        path = Path(path).resolve()
        need(path.is_file() and path.suffix.lower() not in FORBIDDEN, 'Disallowed payload: ' + str(path))
        need(path.stat().st_size <= 32 * 1024 * 1024, 'Payload exceeds finite per-file limit: ' + str(path))
        need(not path.is_relative_to(ROOT / '.runtime/porting/source-objects'), 'Source maps/payload objects are descriptor-only')
        data = checked(pinned)[1] if pinned is not None else path.read_bytes()
        name = name or path.relative_to(ROOT).as_posix()
        need(not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name, 'Invalid ZIP member name')
        if name in members:
            need(members[name][0] == path and members[name][1] == data, 'Conflicting ZIP member')
        else:
            members[name] = (path, data)

    def tree(path):
        path = Path(path)
        need(path.is_dir(), 'Missing finite evidence root: ' + str(path))
        for item in sorted(path.rglob('*')):
            if item.is_file():
                add(item)

    def preparation(row, include_tree=False):
        path, data = checked(row)
        if include_tree:
            tree(path.parent)
        value = json.loads(data)
        for original in value['Original_ranges']:
            add(checked(original['literal_archive'])[0], original['literal_archive'])
        return value

    for name in ROOTS:
        tree(BASE / name)
    owner = preparation({'path': str(BASE / 'ordinary-temperature-owner-prep-04/manifest.json'),
                         'sha256': '1a218751703dc734a13802ee8c49c2706183fba53531f81aabcd48eab0789f82'})
    for row in owner['own_sources']:
        add(checked(row)[0], row)
    if inputs.get('input_preparation') is not None:
        raw_path = checked(inputs['input_preparation'])[0]
        need(not output.is_relative_to(raw_path.parent), 'Output must be outside input preparation')
        raw = preparation(inputs['input_preparation'], include_tree=True)
        for key in ['README', 'author_Source']:
            add(checked(raw[key])[0], raw[key])
    custody_ref = {'path': str(CAPTURE / 'custody.json'),
                   'sha256': '30ff05ba2d3ca4d909af9ccee82dcedeaec41cc74ff320df2b075036c1ba04ae'}
    custody = json.loads(checked(custody_ref)[1])
    native = json.loads(checked(custody['native_source_manifest'])[1])
    for row in native['Original_inverse_checks']:
        add(checked(row['Original'])[0], row['Original'])
    for row in native['unchanged_Original_target_TUs']:
        add(checked(row)[0], row)
    for name in ['verify_native.py', 'policy.json']:
        add(BASE / 'ordinary-temperature-comparison-prep-01' / name)
    for row in [custody['before'], custody['native_stdout'], custody['native_stderr']] + custody['normal_engine_outputs']:
        path, _ = checked(row)
        add(path, row, 'native-capture/' + path.relative_to(CAPTURE).as_posix())
    add(CAPTURE / 'custody.json', custody_ref, name='native-capture/custody.json')
    need(len(custody['normal_engine_outputs']) == 17, 'Expected complete 17-file normal output set')
    need(members[GZIP.relative_to(ROOT).as_posix()][1] and hashlib.sha256(GZIP.read_bytes()).hexdigest() == GZIP_SHA,
         'Closed complete raw gzip changed')
    need(sum(path == GZIP.resolve() for path, _ in members.values()) == 1, 'Complete raw gzip must appear once')

    _, snapshot_bytes = checked(inputs['Source_snapshot'])
    snapshot = json.loads(snapshot_bytes)
    rows = {row['historical_path']: row for row in snapshot['files']}
    required = {row['canonical_path'] for row in owner['source_proposals']}
    fixture = 'crates/ep_runtime/src/heat_balance/fixtures/ordinary_temperature_selected_cases.json'
    current = inputs['current_sources']
    need(len(current) == 13 and {row['path'] for row in current} == required | {fixture}, 'Expected exact current12+fixture')
    for row in current:
        if row['path'] != fixture:
            need(rows[row['path']]['archive']['sha256'] == row['sha256'], 'Selected Source-map binding differs')
        else:
            need(row['sha256'] == 'b70b45958198a374e8cfb37e42a8b1dc6287e99e46529aaeb8b8bcfde468caf8', 'Actual Native fixture changed')
        add(checked(row)[0], row)
    need(set(inputs['quality_receipts']) == {'fmt_check', 'workspace_clippy', 'workspace_test'}, 'Three actual QA roles required')
    for row in inputs['quality_receipts'].values():
        path, data = checked(row)
        receipt = json.loads(data)
        need(receipt['exit_code'] == 0 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after'] is True,
             'Actual QA did not close zero/stable')
        need(receipt['source_snapshot']['sha256'] == inputs['Source_snapshot']['sha256'], 'QA/current Source differs')
        add(path, row)
        for key in ['stdout', 'stderr']:
            add(checked(receipt[key])[0], receipt[key])
    for row in inputs['actual_records']:
        add(checked(row)[0], row)
    _, summary = checked(inputs['summary'])
    json.loads(summary)
    add(input_path, input_ref, 'publication/actual-inputs.json')
    add(Path(__file__), name='publication/package.py')
    add(Path(__file__).with_name('README.md'), name='publication/README.md')
    need(len(members) <= 512, 'Finite ZIP member limit exceeded')
    index = [{'member_path': name, 'source_path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}
             for name, (path, data) in sorted(members.items())]
    output.mkdir(parents=True)
    (output / 'summary.json').write_bytes(summary)
    with zipfile.ZipFile(output / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, (_, data) in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    with zipfile.ZipFile(output / 'evidence.zip') as archive:
        need(archive.namelist() == [row['member_path'] for row in index], 'ZIP member order differs')
        for row in index:
            data = archive.read(row['member_path'])
            need(len(data) == row['size_bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'ZIP roundtrip differs')
    zip_bytes = (output / 'evidence.zip').read_bytes()
    manifest = {'schema': 'src06-finite-temperature-owner-publication.v1', 'actual_inputs': input_ref,
                'summary': {'path': 'summary.json', 'sha256': hashlib.sha256(summary).hexdigest(), 'size_bytes': len(summary)},
                'evidence_zip': {'path': 'evidence.zip', 'sha256': hashlib.sha256(zip_bytes).hexdigest(), 'size_bytes': len(zip_bytes)},
                'members': index, 'selected_current_Source_descriptor': inputs['Source_snapshot'],
                'provenance_only': inputs.get('provenance_only', []) + [native['parent_Native06_manifest'], owner['parent_preparation']],
                'outbound_reference_policy': 'Only indexed ZIP members and the two adjacent JSON files are bundled. Unindexed historical parents, binaries, maps, objects, core/toolchain and Source maps are provenance-only; no transitive replay/closure claim.',
                'complete_compressed_native_capture_included_once': True, 'full_Rust_Source_payload_archived': False,
                'engine_tests_or_compilers_executed': False, 'whole_ordinary_PASS_claimed': False, 'gates_updated': False}
    (output / 'manifest.json').write_bytes(encode(manifest))
    print(json.dumps({'output_dir': str(output), 'members': len(index), 'zip_sha256': manifest['evidence_zip']['sha256'],
                      'zip_size_bytes': len(zip_bytes)}))


if __name__ == '__main__':
    main()

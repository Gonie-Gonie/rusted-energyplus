# Finite temperature owner publication Source

This held script has not run. It emits exactly `summary.json`, `manifest.json`
and `evidence.zip` into a fresh staging directory after Root reviews the Source
and the actual input references. It runs no engine, compiler or tests.

Invocation: `python -X utf8 -B package.py --inputs ACTUAL.json#SHA256 --output-dir FRESH_STAGING_DIRECTORY`.

Root supplies an immutable JSON with schema `src06-temperature-publication-inputs.v1`:

- `summary`: a pinned Root-authored JSON file. Its bytes are copied unchanged;
  the packager supplies no completion percentages or numerical/gate claims.
- `Source_snapshot`: the pinned final command Source-map descriptor. The script
  reads its selected file rows, without opening or archiving its payload objects.
- `current_sources`: exactly the twelve owner04 canonical paths and the genuine
  Native JSON fixture, each `{path, sha256, size_bytes}`. The six raw-input paths
  overlap these twelve; use their genuine final application/formatter bytes.
- `quality_receipts`: `fmt_check`, `workspace_clippy`, `workspace_test`, each a
  pinned genuine closed-zero receipt with the same final Source. Actual argv and
  complete stdout/stderr remain unchanged; no focused repeats are requested.
- `actual_records`: pinned file references for actual applications, formatter
  reviews, affected commands/logs, input Source reviews and their authoring
  sources. Future hashes or receipts must not be invented. Add all corresponding
  closed raw-input application records after they exist.
- Optional `input_preparation`: the pinned cohesive raw-input prep02 manifest.
  This adds only its finite directory and ten direct Original literal ranges.
- Optional `provenance_only`: descriptor references to excluded historical or
  large artifacts. These are recorded without dereferencing them.

Fixed finite roots retain Native Source/build/capture preparation, complete
derived and three inverse Original TUs, both seven-TU unchanged Original files,
owner04 before/proposal/diffs and its twelve Original literal ranges, exact
checker/policy successor02, known failed checker01 and Root receipt, provider PE
and 22 address-bound proofs, closure/capture custody, all seventeen normal engine
outputs, Root/Header facts/cases/reviews, and the complete closed raw gzip once.
The Source record-command launcher and pending formatter/input application
sources can be supplied as `actual_records` without adding historical closures.

ZIP names are sorted with fixed 1980 timestamps, Unix regular-file mode0644 and
DEFLATE level6. Every member has a path/SHA256/size index in the outer manifest
and is read back fully for CRC/hash verification. There are no recursive JSON
reference walks. Large executables, maps, objects, cores, raw uncompressed capture
and full Rust Source payloads are excluded. Unindexed references in historical
records remain provenance-only; this is a bounded audit packet, not a complete
toolchain/build replay or whole ordinary parity certificate.

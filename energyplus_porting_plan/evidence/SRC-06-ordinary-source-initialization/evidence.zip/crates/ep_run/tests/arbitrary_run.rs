//! Integration tests for the arbitrary-run pipeline.

#![allow(clippy::expect_used, clippy::unwrap_used)]

use std::path::{Path, PathBuf};

use ep_run::{
    PartialRunPolicy, RunConfig, RunExitCode, RunMode, RunOutputFormat, RunResultState,
    SupportStatus, TraceLevel, TraceSelection, run_arbitrary_idf,
};

#[path = "arbitrary_run/common.rs"]
mod common;
use common::{read_json, unique_case_dir, write_text};

#[path = "arbitrary_run/direct_zone_coupled.rs"]
mod direct_zone_coupled;
#[path = "arbitrary_run/exit_codes.rs"]
mod exit_codes;
#[path = "arbitrary_run/ideal_loads.rs"]
mod ideal_loads;

#[allow(dead_code)]
#[path = "arbitrary_run/fixtures.rs"]
mod fixtures;

use fixtures::*;

#[allow(dead_code)]
#[path = "arbitrary_run/output_manifest.rs"]
mod output_manifest;

use output_manifest::{
    BLOCKED_AFTER_SUPPORT_MANIFEST, SUPPORTED_RUNTIME_MANIFEST, assert_ordinary_output_manifest,
    assert_output_manifest,
};

#[test]
fn one_zone_runtime_writes_stable_output_layout() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("one-zone-runtime")?;
    let input_path = case_dir.join("one-zone.epJSON");
    let weather_path = case_dir.join("weather.epw");
    let output_dir = case_dir.join("out");
    write_text(&input_path, ONE_ZONE_EPJSON)?;
    write_text(&weather_path, ONE_DAY_EPW)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: Some(weather_path),
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(2),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Success);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedCompatibility
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );

    assert_output_layout(&output_dir, true)?;
    assert_ordinary_output_manifest(&output_dir)?;
    let eio = std::fs::read_to_string(output_dir.join("eplusrs.eio"))?;
    assert!(eio.starts_with("Program Version,"));
    assert_eq!(
        std::fs::read(output_dir.join("eplusrs.audit"))?,
        b"  Processing Schedule Input -- Start\n  Processing Schedule Input -- Complete\n"
    );
    if std::env::var("CI_FORCE_TIME_STEP").as_deref() == Ok("Y") {
        assert!(
            eio.contains(" Timesteps per Hour,  2, 30"),
            "the actual CLI must reach the forced Project timestep"
        );
    }
    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "success");
    assert_eq!(
        summary["support"]["runtime_class"],
        "one-zone-heat-balance-compatibility"
    );
    assert_eq!(
        summary["support"]["matched_capability_ids"][0],
        "official_1zone_uncontrolled_declared_heat_balance"
    );
    assert_eq!(
        summary["support"]["matched_capabilities"][0]["evidence_cases"][0],
        "official_1zone_uncontrolled_dynamic_conformance_candidate_001"
    );
    assert_eq!(
        summary["support"]["failed_capability_ids"]
            .as_array()
            .expect("failed capability ids should be an array")
            .len(),
        0
    );
    let support = read_json(&output_dir.join("support-assessment.json"))?;
    assert_eq!(
        support["matched_capability_ids"][0],
        "official_1zone_uncontrolled_declared_heat_balance"
    );
    assert_eq!(
        support["failed_capability_ids"]
            .as_array()
            .expect("support failed capability ids should be an array")
            .len(),
        0
    );
    assert_eq!(summary["rust_runtime"]["samples"], 2);
    assert_eq!(
        summary["rust_runtime"]["runtime_class"],
        "one-zone-heat-balance-compatibility"
    );
    assert_eq!(summary["source_order_gate"]["matches"], true);
    assert_eq!(
        summary["source_order_gate"]["expected_source_order_stages"][0],
        "get-heat-balance-input"
    );
    assert!(
        summary["source_order_gate"]["expected_source_order_stages"]
            .as_array()
            .expect("source-order stages should be an array")
            .iter()
            .any(|stage| stage == "manage-zone-air-updates")
    );
    assert_eq!(
        summary["source_order_gate"]["actual_executed_source_order_stages"],
        summary["source_order_gate"]["expected_source_order_stages"]
    );
    assert_eq!(
        summary["rust_runtime"]["source_order_stages"][0],
        "get-heat-balance-input"
    );
    Ok(())
}

#[test]
fn weather_runtime_selects_run_period_start_after_leading_epw_decoy()
-> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("weather-record-start-offset")?;
    let input_path = case_dir.join("one-zone-july-run-period.epJSON");
    let output_dir = case_dir.join("out");
    let weather_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../data/conformance_cases/weather_record_start_offset_nonactual_001")
        .join("weather_record_start_offset_nonactual.epw")
        .canonicalize()?;
    let mut input_text = ONE_ZONE_EPJSON.trim_end().trim_end_matches('}').to_string();
    input_text.push_str(
        r#",
  "RunPeriod": {
    "Weather Record Offset Run Period": {
      "begin_month": 7,
      "begin_day_of_month": 1,
      "begin_year": 2016,
      "end_month": 7,
      "end_day_of_month": 2,
      "end_year": 2016,
      "day_of_week_for_start_day": "Friday",
      "first_hour_interpolation_starting_values": "Hour24",
      "use_weather_file_holidays_and_special_days": "No",
      "use_weather_file_daylight_saving_period": "No",
      "apply_weekend_holiday_rule": "No",
      "use_weather_file_rain_indicators": "No",
      "use_weather_file_snow_indicators": "No",
      "treat_weather_as_actual": "No"
    }
  }
}"#,
    );
    write_text(&input_path, &input_text)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: Some(weather_path),
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(2),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Success);
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );
    let results = read_json(&output_dir.join("results").join("result-store.json"))?;
    let outdoor_dry_bulb = results["series"]
        .as_array()
        .expect("result series should be an array")
        .iter()
        .find(|series| {
            series["key"] == "Environment"
                && series["variable_name"] == "Site Outdoor Air Drybulb Temperature"
        })
        .expect("outdoor dry-bulb result series should exist");
    assert_eq!(outdoor_dry_bulb["samples"], 2);

    // Timestep defaults to six samples per hour. Under the explicit Hour24
    // policy, the first selected hour interpolates from July 1 hour 24 (12.4 C)
    // to hour 1 (10.1 C); the June 30 decoy records never enter this average.
    let average_interpolation_weight = (1_u32..=6)
        .map(|timestep| f64::from(timestep) / 6.0)
        .sum::<f64>()
        / 6.0;
    let expected_first =
        12.4 * (1.0 - average_interpolation_weight) + 10.1 * average_interpolation_weight;
    let expected_last =
        10.1 * (1.0 - average_interpolation_weight) + 10.2 * average_interpolation_weight;
    let actual_first = outdoor_dry_bulb["first"]
        .as_f64()
        .expect("first outdoor dry-bulb value should be numeric");
    let actual_last = outdoor_dry_bulb["last"]
        .as_f64()
        .expect("last outdoor dry-bulb value should be numeric");
    assert!(
        (actual_first - expected_first).abs() <= 1.0e-12,
        "unexpected first selected dry-bulb average: expected {expected_first}, found {actual_first}"
    );
    assert!(
        (actual_last - expected_last).abs() <= 1.0e-12,
        "unexpected second selected dry-bulb average: expected {expected_last}, found {actual_last}"
    );
    assert!(actual_first > 0.0 && actual_last > 0.0);
    Ok(())
}

#[test]
fn unsupported_air_loop_blocks_before_runtime() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("unsupported-air-loop")?;
    let input_path = case_dir.join("air-loop.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, AIR_LOOP_EPJSON)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Unsupported);
    assert_eq!(outcome.support_status, SupportStatus::Unsupported);
    assert_eq!(outcome.run_result_state, RunResultState::RunBlocked);
    assert_output_layout(&output_dir, false)?;
    assert_output_manifest(&output_dir, BLOCKED_AFTER_SUPPORT_MANIFEST)?;
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "unsupported");
    assert_eq!(summary["support"]["status"], "unsupported");
    assert!(summary["rust_runtime"].is_null());

    let support_report = std::fs::read_to_string(output_dir.join("support-report.md"))?;
    assert!(support_report.contains("Broad HVAC air-loop semantics are not ported."));
    Ok(())
}

#[test]
fn unsupported_plant_loop_blocks_before_runtime() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("unsupported-plant-loop")?;
    let input_path = case_dir.join("plant-loop.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, PLANT_LOOP_EPJSON)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Unsupported);
    assert_eq!(outcome.support_status, SupportStatus::Unsupported);
    assert_eq!(outcome.run_result_state, RunResultState::RunBlocked);

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "unsupported");
    assert!(summary["rust_runtime"].is_null());

    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains("UnsupportedPlantObject"));
    let support_report = std::fs::read_to_string(output_dir.join("support-report.md"))?;
    assert!(support_report.contains("Plant objects are typed for graph diagnostics"));
    Ok(())
}

#[test]
fn unsupported_ems_blocks_before_runtime() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("unsupported-ems")?;
    let input_path = case_dir.join("ems.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, EMS_EPJSON)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Unsupported);
    assert_eq!(outcome.support_status, SupportStatus::Unsupported);
    assert_eq!(outcome.run_result_state, RunResultState::RunBlocked);
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );

    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains("UnsupportedEMS"));
    let support_report = std::fs::read_to_string(output_dir.join("support-report.md"))?;
    assert!(support_report.contains("Runtime-modifying plugin/network features are not ported."));
    Ok(())
}

#[test]
fn unsupported_plugins_airflow_and_autosizing_block_before_runtime()
-> Result<(), Box<dyn std::error::Error>> {
    for (name, fixture, diagnostic_code, report_phrase) in [
        (
            "unsupported-python-plugin",
            PYTHON_PLUGIN_EPJSON,
            "UnsupportedPythonPlugin",
            "Runtime-modifying plugin/network features are not ported.",
        ),
        (
            "unsupported-airflow-network",
            AIRFLOW_NETWORK_EPJSON,
            "UnsupportedAirflowNetwork",
            "Runtime-modifying plugin/network features are not ported.",
        ),
        (
            "unsupported-autosizing",
            AUTOSIZING_EPJSON,
            "UnsupportedSizing",
            "Sizing workflows are not ported.",
        ),
    ] {
        assert_unsupported_fixture_blocks_before_runtime(
            name,
            fixture,
            diagnostic_code,
            report_phrase,
        )?;
    }
    Ok(())
}

#[test]
fn missing_weather_blocks_heat_balance_before_runtime() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("missing-weather")?;
    let input_path = case_dir.join("one-zone.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, ONE_ZONE_EPJSON)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Args);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedCompatibility
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "args");
    assert_eq!(
        summary["support"]["runtime_class"],
        "one-zone-heat-balance-compatibility"
    );
    assert!(summary["rust_runtime"].is_null());
    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains("MissingWeatherFile"));
    Ok(())
}

#[test]
fn invalid_epjson_returns_import_parse_failure() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("invalid-epjson")?;
    let input_path = case_dir.join("invalid.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, "{ not valid epjson")?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::ImportParse);
    assert_eq!(outcome.support_status, SupportStatus::Unsupported);
    assert_eq!(outcome.run_result_state, RunResultState::RunBlocked);

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "import-parse");
    assert!(!output_dir.join("support-assessment.json").exists());
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );
    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains("RawModelParseFailed"));
    Ok(())
}

#[test]
fn unresolved_model_reference_returns_compile_reference_failure()
-> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("compile-reference")?;
    let input_path = case_dir.join("missing-zone-reference.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, MISSING_SURFACE_ZONE_EPJSON)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::CompileReference);
    assert_eq!(outcome.support_status, SupportStatus::Unsupported);
    assert_eq!(outcome.run_result_state, RunResultState::RunBlocked);
    for file in [
        "run-summary.json",
        "diagnostics.json",
        "support-assessment.json",
        "support-report.md",
        "model/raw-model-summary.json",
        "model/typed-model-summary.json",
        "reports/run-report.md",
        "reports/compatibility-boundary.md",
    ] {
        assert!(
            output_dir.join(file).is_file(),
            "missing output artifact {file}"
        );
    }
    assert!(!output_dir.join("model").join("graph-summary.json").exists());
    assert!(
        !output_dir
            .join("model")
            .join("execution-plan.json")
            .exists()
    );
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "compile-reference");
    assert_eq!(summary["exit_code"], 3);
    assert_eq!(summary["support"]["status"], "unsupported");
    assert!(summary["rust_runtime"].is_null());

    let diagnostics = read_json(&output_dir.join("diagnostics.json"))?;
    let diagnostics = diagnostics["diagnostics"]
        .as_array()
        .expect("diagnostics should be an array");
    assert!(diagnostics.iter().any(|diagnostic| {
        diagnostic["severity"] == "error"
            && diagnostic["code"] == "MissingReference"
            && diagnostic["stage"] == "compile"
            && diagnostic["object_type"] == "BuildingSurface:Detailed"
            && diagnostic["object_name"] == "Wall One"
            && diagnostic["field"] == "zone_name"
    }));
    Ok(())
}

#[test]
fn fail_on_warning_promotes_warning_to_non_success() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("fail-on-warning")?;
    let input_path = case_dir.join("one-zone-output-request.epJSON");
    let weather_path = case_dir.join("weather.epw");
    let output_dir = case_dir.join("out");
    let mut input_text = ONE_ZONE_EPJSON.trim_end().trim_end_matches('}').to_string();
    input_text.push_str(
        r#",
  "Output:Variable": {
    "Zone Air Temperature Request": {
      "key_value": "*",
      "variable_name": "Zone Mean Air Temperature",
      "reporting_frequency": "Hourly"
    }
  }
}"#,
    );
    write_text(&input_path, &input_text)?;
    write_text(&weather_path, ONE_DAY_EPW)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: Some(weather_path),
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: true,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(2),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Unsupported);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedCompatibility
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );
    assert_output_layout(&output_dir, true)?;

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "unsupported");
    assert!(!summary["rust_runtime"].is_null());
    assert_eq!(summary["config"]["fail_on_warning"], true);

    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains("UnsupportedObjectIgnored"));
    Ok(())
}

#[test]
fn partial_output_request_runs_when_allowed() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("partial-output-request")?;
    let input_path = case_dir.join("one-zone-output-request.epJSON");
    let weather_path = case_dir.join("weather.epw");
    let output_dir = case_dir.join("out");
    let mut input_text = ONE_ZONE_EPJSON.trim_end().trim_end_matches('}').to_string();
    input_text.push_str(
        r#",
  "Output:Variable": {
    "Zone Air Temperature Request": {
      "key_value": "*",
      "variable_name": "Zone Mean Air Temperature",
      "reporting_frequency": "Hourly"
    }
  }
}"#,
    );
    write_text(&input_path, &input_text)?;
    write_text(&weather_path, ONE_DAY_EPW)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: Some(weather_path),
        output_dir: output_dir.clone(),
        mode: RunMode::Diagnostic,
        partial_policy: PartialRunPolicy::Allow,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(2),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Success);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedDiagnosticOnly
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::PartialSupportedRun
    );
    assert_output_layout(&output_dir, true)?;
    assert_output_manifest(&output_dir, SUPPORTED_RUNTIME_MANIFEST)?;

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "success");
    assert_eq!(summary["support"]["status"], "supported-diagnostic-only");
    assert_eq!(
        summary["support"]["run_result_state"],
        "partial_supported_run"
    );
    assert_eq!(summary["support"]["conformance_claim"], false);
    assert_eq!(summary["config"]["partial_policy"], "allow");

    let support = read_json(&output_dir.join("support-assessment.json"))?;
    assert_eq!(support["run_result_state"], "partial_supported_run");
    assert_eq!(
        support["ignored_raw_only_objects"][0]["object_type"],
        "Output:Variable"
    );
    assert_eq!(
        support["ignored_raw_only_objects"][0]["status"],
        "ignored_reporting_objects"
    );
    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains("UnsupportedObjectIgnored"));
    Ok(())
}

#[test]
fn dry_run_skips_runtime_oracle_and_compare() -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("dry-run")?;
    let input_path = case_dir.join("one-zone.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, ONE_ZONE_EPJSON)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: true,
        oracle_baseline: true,
        compare_oracle: true,
        json_stdout: false,
        oracle_root: None,
        hours: Some(2),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Success);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedCompatibility
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "success");
    assert_eq!(summary["message"], "dry run completed");
    assert_eq!(summary["config"]["dry_run"], true);
    assert_eq!(summary["config"]["oracle_baseline"], true);
    assert_eq!(summary["config"]["compare_oracle"], true);
    assert_eq!(summary["oracle_status"], "skipped-dry-run");
    assert_eq!(summary["compare_status"], "skipped-dry-run");
    assert!(summary["rust_runtime"].is_null());
    assert!(summary["oracle"].is_null());
    assert!(summary["comparison"].is_null());
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );
    assert!(!output_dir.join("oracle").join("eplusout.eso").exists());
    assert!(
        !output_dir
            .join("compare")
            .join("compare-summary.json")
            .exists()
    );
    Ok(())
}

#[test]
fn ideal_loads_diagnostic_mode_keeps_exact_direct_model_on_release_runtime()
-> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("ideal-loads-diagnostic")?;
    let input_path = case_dir.join("ideal-loads.epJSON");
    let weather_path = case_dir.join("weather.epw");
    let output_dir = case_dir.join("out");
    write_text(&input_path, IDEAL_LOADS_EPJSON)?;
    write_text(&weather_path, ONE_DAY_EPW)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: Some(weather_path),
        output_dir: output_dir.clone(),
        mode: RunMode::Diagnostic,
        partial_policy: PartialRunPolicy::Allow,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Success);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedCompatibility
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );
    assert_output_layout(&output_dir, true)?;

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(
        summary["support"]["runtime_class"],
        "ideal-loads-direct-zone-coupled-compatibility"
    );
    assert_eq!(
        summary["support"]["matched_capability_ids"][0],
        "ideal_loads_no_oa_sensible"
    );
    assert_eq!(
        summary["rust_runtime"]["runtime_class"],
        "ideal-loads-direct-zone-coupled-compatibility"
    );
    assert_eq!(
        summary["rust_runtime"]["zone_demand_source"],
        "rust-predictor-source-setpoint-thresholds"
    );
    assert_eq!(
        summary["rust_runtime"]["fixture_demand_injection_used"],
        false
    );
    assert_eq!(summary["rust_runtime"]["samples"], 1);
    assert_eq!(summary["source_order_gate"]["matches"], true);
    assert!(
        summary["rust_runtime"]["source_order_stages"]
            .as_array()
            .expect("source order stages should be an array")
            .iter()
            .any(|stage| stage == "calc-purch-air-loads")
    );
    let plan = read_json(&output_dir.join("model").join("execution-plan.json"))?;
    assert_eq!(plan["source_order_gate"]["matches"], true);
    assert_eq!(
        plan["source_order_gate"]["actual_executed_source_order_stages"],
        plan["source_order_gate"]["expected_source_order_stages"]
    );
    assert!(
        plan["source_order_gate"]["expected_source_order_stages"]
            .as_array()
            .expect("source-order stages should be an array")
            .iter()
            .any(|stage| stage == "manage-zone-air-updates")
    );
    let results = std::fs::read_to_string(output_dir.join("results").join("result-store.json"))?;
    assert!(results.contains("Zone Ideal Loads Zone Total Heating Rate"));
    assert!(results.contains("System Node Temperature"));
    Ok(())
}

#[test]
fn ideal_loads_compatibility_mode_runs_state_backed_direct_runtime()
-> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir("ideal-loads-compatibility")?;
    let input_path = case_dir.join("ideal-loads.epJSON");
    let weather_path = case_dir.join("weather.epw");
    let output_dir = case_dir.join("out");
    write_text(&input_path, IDEAL_LOADS_EPJSON)?;
    write_text(&weather_path, ONE_DAY_EPW)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: Some(weather_path),
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Success);
    assert_eq!(
        outcome.support_status,
        SupportStatus::SupportedCompatibility
    );
    assert_eq!(
        outcome.run_result_state,
        RunResultState::SupportedCompatibilityRun
    );

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "success");
    assert_eq!(
        summary["support"]["runtime_class"],
        "ideal-loads-direct-zone-coupled-compatibility"
    );
    assert_eq!(
        summary["rust_runtime"]["runtime_class"],
        "ideal-loads-direct-zone-coupled-compatibility"
    );
    assert_eq!(
        summary["rust_runtime"]["zone_demand_source"],
        "rust-predictor-source-setpoint-thresholds"
    );
    assert_eq!(
        summary["rust_runtime"]["fixture_demand_injection_used"],
        false
    );
    assert_eq!(summary["source_order_gate"]["matches"], true);
    assert_output_layout(&output_dir, true)?;
    Ok(())
}

fn assert_unsupported_fixture_blocks_before_runtime(
    name: &str,
    fixture: &str,
    diagnostic_code: &str,
    report_phrase: &str,
) -> Result<(), Box<dyn std::error::Error>> {
    let case_dir = unique_case_dir(name)?;
    let input_path = case_dir.join("input.epJSON");
    let output_dir = case_dir.join("out");
    write_text(&input_path, fixture)?;

    let outcome = run_arbitrary_idf(&RunConfig {
        input_path,
        weather_path: None,
        output_dir: output_dir.clone(),
        mode: RunMode::Compatibility,
        partial_policy: PartialRunPolicy::Deny,
        output_format: RunOutputFormat::RustNative,
        overwrite: true,
        keep_intermediate: true,
        trace_level: TraceLevel::Normal,
        trace_selection: TraceSelection::default(),
        fail_on_warning: false,
        dry_run: false,
        oracle_baseline: false,
        compare_oracle: false,
        json_stdout: false,
        oracle_root: None,
        hours: Some(1),
    })?;

    assert_eq!(outcome.exit_code, RunExitCode::Unsupported);
    assert_eq!(outcome.support_status, SupportStatus::Unsupported);
    assert_eq!(outcome.run_result_state, RunResultState::RunBlocked);
    assert_output_manifest(&output_dir, BLOCKED_AFTER_SUPPORT_MANIFEST)?;
    assert!(
        !output_dir
            .join("results")
            .join("result-store.json")
            .exists()
    );

    let summary = read_json(&output_dir.join("run-summary.json"))?;
    assert_eq!(summary["status"], "unsupported");
    assert_eq!(summary["support"]["run_result_state"], "run_blocked");
    assert!(summary["rust_runtime"].is_null());
    let diagnostics = std::fs::read_to_string(output_dir.join("diagnostics.json"))?;
    assert!(diagnostics.contains(diagnostic_code));
    let support_report = std::fs::read_to_string(output_dir.join("support-report.md"))?;
    assert!(support_report.contains(report_phrase));
    Ok(())
}

fn assert_output_layout(
    output_dir: &Path,
    expects_runtime_artifacts: bool,
) -> Result<(), Box<dyn std::error::Error>> {
    for directory in [
        "input", "model", "results", "reports", "logs", "oracle", "compare",
    ] {
        assert!(
            output_dir.join(directory).is_dir(),
            "missing output directory {directory}"
        );
    }

    for file in [
        "run-summary.json",
        "diagnostics.json",
        "support-assessment.json",
        "support-report.md",
        "eplusrs.err",
        "input/original.epJSON",
        "input/converted.epJSON",
        "input/input-hashes.json",
        "model/raw-model-summary.json",
        "model/typed-model-summary.json",
        "reports/run-report.md",
        "reports/compatibility-boundary.md",
        "logs/command.log",
    ] {
        assert!(
            output_dir.join(file).is_file(),
            "missing output artifact {file}"
        );
    }

    if expects_runtime_artifacts {
        for file in [
            "model/graph-summary.json",
            "model/execution-plan.json",
            "results/result-store.json",
            "results/selected-outputs.csv",
            "results/meters.csv",
        ] {
            assert!(
                output_dir.join(file).is_file(),
                "missing runtime artifact {file}"
            );
        }
    }
    Ok(())
}

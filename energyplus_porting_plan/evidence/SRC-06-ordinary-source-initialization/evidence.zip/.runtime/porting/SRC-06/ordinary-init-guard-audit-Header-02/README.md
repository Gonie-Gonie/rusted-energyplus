# Complete EnergyPlusData initialization Source audit

Pinned Original commit: 6f2e40d10250a105b49966baa24d843711e61048 (26.1.0).

Both guards contain exactly 249 ordered member calls. Every actual field type and concrete BaseGlobalStruct method was resolved; all 498 method ranges and member declarations are retained. 249 complete selected Original files match the pinned Git blobs after CRLF normalization. The earlier 01 index retains seven explicitly unresolved name/extension cases; 02 resolves the six global/nested name collisions and AirflowNetwork Solver.hpp from their actual concrete BaseGlobalStruct definitions. No unresolved handler is treated as empty.

| Guard | Literal empty bodies | Nonempty bodies |
| --- | ---: | --- |
| init_constant_state | 246 | 3: Psych, Fluid, Schedule |
| init_state | 244 | 5: Simulation, EMS, Fluid, Schedule, Curve |

No extra nonempty direct handler beyond the existing six logical modules was found. Psych's init_state is itself literally empty; InitializePsychRoutines belongs to init_constant_state. Empty means the real method body has no executable C++ tokens after comment/literal masking, never an inference from manager names or zero inputs. BaseGlobalStruct methods are pure virtual; no inherited generic no-op was assumed.

Both Original guard booleans default false and are set true before the first handler. A reached error retains that flag and every preceding effect; a second invocation returns immediately until real clear_state resets it. These are call guards, not proof that all positive input routines or constructor fields are ready. The caller invokes constant initialization then input initialization at SimulationManager210/211.

The eight nonempty phase/member requirements are listed in review.json. Omitting only literal-empty method calls is justified by this Source inventory; it does not implement missing selected constructors, filesystem outputs, psychrometric cache policy, real queries or unsupported positive branches. This audit certifies Source resolution and required ordering only. It does not certify the current Rust assembly's full execution/initialization, numerical parity, Setup or gates.

No canonical files, compiler, Cargo, tests, engine or Native capture were run or changed.

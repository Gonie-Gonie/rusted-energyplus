//! Real selected empty cost/fault/curve getter work on the sole input owner.
//! Full startup/Setup callers must consume this module before any application.
use super::selected_input_processor::SelectedInputProcessor;
use std::collections::BTreeMap;

const FAULT_FAMILIES: [&str; 16] = [
    "FaultModel:TemperatureSensorOffset:OutdoorAir",
    "FaultModel:HumiditySensorOffset:OutdoorAir",
    "FaultModel:EnthalpySensorOffset:OutdoorAir",
    "FaultModel:TemperatureSensorOffset:ReturnAir",
    "FaultModel:EnthalpySensorOffset:ReturnAir",
    "FaultModel:Fouling:Coil", "FaultModel:ThermostatOffset",
    "FaultModel:HumidistatOffset", "FaultModel:Fouling:AirFilter",
    "FaultModel:TemperatureSensorOffset:ChillerSupplyWater",
    "FaultModel:TemperatureSensorOffset:CondenserSupplyWater",
    "FaultModel:Fouling:CoolingTower",
    "FaultModel:TemperatureSensorOffset:CoilSupplyAir",
    "FaultModel:Fouling:Boiler", "FaultModel:Fouling:Chiller",
    "FaultModel:Fouling:EvaporativeCooler",
];
const CURVE_FAMILIES: [&str; 22] = [
    "Curve:Biquadratic", "Curve:Cubic", "Curve:Quartic", "Curve:Quadratic",
    "Curve:QuadLinear", "Curve:QuintLinear", "Curve:QuadraticLinear",
    "Curve:CubicLinear", "Curve:Linear", "Curve:Bicubic", "Curve:Triquadratic",
    "Curve:Exponent", "Table:Lookup", "Curve:FanPressureRise",
    "Curve:ExponentialSkewNormal", "Curve:Sigmoid", "Curve:RectangularHyperbola1",
    "Curve:RectangularHyperbola2", "Curve:ExponentialDecay",
    "Curve:DoubleExponentialDecay", "Curve:ChillerPartLoadWithLift",
    "AirflowNetwork:MultiZone:WindPressureCoefficientValues",
];

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum SelectedSetupServiceError {
    Positive(&'static str), Size,
}
impl std::fmt::Display for SelectedSetupServiceError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Positive(family) => write!(f, "positive {family} producer unavailable"),
            Self::Size => f.write_str("selected setup service count exceeds storage"),
        }
    }
}
impl std::error::Error for SelectedSetupServiceError {}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SelectedCostEstimate {
    get_cost_input: bool,
    do_cost_estimate: bool,
    selected_monetary_unit: i32,
    cost_line_items: Option<Vec<()>>,
    current_building_adjustments: [f64; 9],
    reference_building_adjustments: [f64; 9],
    monetary_units: Option<Vec<()>>,
}
impl Default for SelectedCostEstimate {
    fn default() -> Self {
        Self { get_cost_input: true, do_cost_estimate: false, selected_monetary_unit: 0,
            cost_line_items: None, current_building_adjustments: [0.,0.,0.,0.,0.,0.,0.,1.,0.],
            reference_building_adjustments: [0.,0.,0.,0.,0.,0.,0.,1.,0.], monetary_units: None }
    }
}
impl SelectedCostEstimate {
    pub(crate) fn simulate(&mut self, input: &SelectedInputProcessor,
        kickoff_simulation: bool) -> Result<(), SelectedSetupServiceError> {
        if self.get_cost_input {
            let count = input.get_num_objects_found("ComponentCost:LineItem");
            if count == 0 { self.do_cost_estimate = false; }
            else {
                self.do_cost_estimate = true; // Source168, before allocation.
                return Err(SelectedSetupServiceError::Positive("ComponentCost:LineItem"));
            }
            self.get_cost_input = false; // Source124 after genuine getter return.
        }
        if kickoff_simulation { return Ok(()); }
        if self.do_cost_estimate {
            return Err(SelectedSetupServiceError::Positive("CalcCostEstimate"));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedFaults {
    run_once: bool, errors_found: bool, any_faults: bool,
    number_of_faults: usize, faulty_economizers: usize,
    other_fault_counts: [usize; 11],
    fault_arrays: [Option<Vec<()>>; 12],
}
impl SelectedFaults {
    pub(crate) fn check_and_read(&mut self, input: &SelectedInputProcessor)
        -> Result<(), SelectedSetupServiceError> {
        // Source229-234 allocates locals even before its RunOnce return237.
        // Numeric Array1D(10) is uninitialized in the selected non-INIT build;
        // None retains that defined storage distinction, rather than inventing0.
        let locals = (vec![String::new();10],vec![false;10],vec![false;10],
            vec![String::new();10],vec![String::new();10],vec![None::<f64>;10]);
        if self.run_once { return Ok(()); }
        self.number_of_faults = 0;
        self.faulty_economizers = 0;
        for (index, family) in FAULT_FAMILIES.iter().enumerate() {
            let count = input.get_num_objects_found(family);
            self.number_of_faults = self.number_of_faults.checked_add(count)
                .ok_or(SelectedSetupServiceError::Size)?;
            if index <= 4 {
                self.faulty_economizers = self.faulty_economizers.checked_add(count)
                    .ok_or(SelectedSetupServiceError::Size)?;
            } else { self.other_fault_counts[index-5] = count; }
        }
        self.any_faults = self.number_of_faults > 0;
        if !self.any_faults {
            self.run_once = true; // Source295 only after actual16queries.
            drop(locals);
            return Ok(());
        }
        Err(SelectedSetupServiceError::Positive("FaultModel input"))
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SelectedBtwxtManager {
    independent_variable_references: BTreeMap<String, ()>,
    table_files: BTreeMap<std::path::PathBuf, ()>,
    grid_map: BTreeMap<String, usize>,
    grids: Vec<()>,
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SelectedCurves {
    curve_value_begin_timestep: bool,
    friction_factor_error: bool,
    show_fallback_message: bool,
    curves: Vec<()>,
    curve_map: BTreeMap<String, i32>,
    btwxt: SelectedBtwxtManager,
    pressure_curves: Option<Vec<()>>,
}
impl Default for SelectedCurves {
    fn default() -> Self {
        Self { curve_value_begin_timestep: false, friction_factor_error: false,
            show_fallback_message: true, curves: Vec::new(), curve_map: BTreeMap::new(),
            btwxt: SelectedBtwxtManager::default(), pressure_curves: None }
    }
}
impl SelectedCurves {
    fn get_curve_input(&mut self, input: &SelectedInputProcessor)
        -> Result<(), SelectedSetupServiceError> {
        let alpha_args = vec![String::new();14]; // Source689 actual local shape.
        let numeric_args = vec![None::<f64>;10000]; // Source690 non-INIT local.
        let counts: [usize;22] = std::array::from_fn(|i|
            input.get_num_objects_found(CURVE_FAMILIES[i]));
        if let Some(index) = counts.iter().position(|&count| count > 0) {
            return Err(SelectedSetupServiceError::Positive(CURVE_FAMILIES[index]));
        }
        // All actual analytic/WPC loops have zero iterations; no curve is added.
        if input.get_num_objects_found("Table:IndependentVariable") > 0 {
            return Err(SelectedSetupServiceError::Positive("Table:IndependentVariable"));
        }
        let variable_list_count = input.get_num_objects_found("Table:IndependentVariableList");
        let variable_list_limits: BTreeMap<String,Vec<(f64,f64)>> = BTreeMap::new();
        let variable_list_normalization_targets: BTreeMap<String,Vec<f64>> = BTreeMap::new();
        if variable_list_count > 0 {
            return Err(SelectedSetupServiceError::Positive("Table:IndependentVariableList"));
        }
        self.btwxt.table_files.clear(); // Source2718 genuine getter tail.
        drop((alpha_args,numeric_args,variable_list_limits,variable_list_normalization_targets));
        Ok(())
    }
    fn get_pressure_system_input(&mut self, input: &SelectedInputProcessor)
        -> Result<(), SelectedSetupServiceError> {
        let locals = (vec![String::new();1],vec![None::<f64>;5]);
        let count = input.get_num_objects_found("Curve:Functional:PressureDrop");
        self.pressure_curves = Some(vec![();count]); // Actual zero allocation3443.
        if count > 0 {
            return Err(SelectedSetupServiceError::Positive("Curve:Functional:PressureDrop"));
        }
        drop(locals);
        Ok(())
    }
    pub(crate) fn initialize_state(&mut self, input: &SelectedInputProcessor)
        -> Result<(), SelectedSetupServiceError> {
        self.get_curve_input(input)?;
        self.get_pressure_system_input(input)
    }
    pub(crate) fn initialize_reporting(&self, _any_energy_management_system: bool)
        -> Result<(), SelectedSetupServiceError> {
        // Source2857-2923 traverses these two real collections (and again when
        // AnyEMS true); an actually empty owner produces zero registrations.
        if !self.curves.is_empty() || self.pressure_curves.as_ref().is_some_and(|rows| !rows.is_empty()) {
            return Err(SelectedSetupServiceError::Positive("InitCurveReporting"));
        }
        // The caller supplies its genuine AnyEMS. Both guarded loops still have
        // zero iterations for either value over these actual empty collections.
        Ok(())
    }
}

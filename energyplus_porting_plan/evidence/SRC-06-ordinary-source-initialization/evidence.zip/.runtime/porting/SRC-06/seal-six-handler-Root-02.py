"""Seal the clock-handoff successor, retaining every earlier Source/QA archive."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-six-handler-assembly-03'
assert not (out / 'manifest.json').exists()
apply_path = out / 'apply.json'
applied = json.loads(apply_path.read_bytes())
assert len(applied['paths']) == len(applied['before_refs']) == len(applied['activated_proposals']) == 37

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def store(path, data):
    assert not path.exists()
    path.write_bytes(data)
    return ref(path)

files = []
for index, name in enumerate(applied['paths']):
    before_ref = applied['before_refs'][index]
    before_path = root / before_ref['path']
    assert ref(before_path) == before_ref
    before = before_path.read_bytes()
    canonical = root / name
    after = canonical.read_bytes()
    proposal = root / applied['activated_proposals'][index]['path']
    assert ref(proposal) == applied['activated_proposals'][index]
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after))
    diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='HEAD/' + name, tofile=name)).encode()
    held_diff = ''.join(difflib.unified_diff(proposal.read_text(encoding='utf8').splitlines(True), after.decode().splitlines(True), fromfile='held/' + name, tofile=name)).encode()
    files.append({'canonical': ref(canonical), 'before': before_ref,
        'after': store(out / f'{index:02}.after', after),
        'complete_diff': store(out / f'{index:02}.diff', diff),
        'held_to_actual_diff': store(out / f'{index:02}.held.diff', held_diff),
        'test_bodies_before': len(re.findall(rb'#\[test\]', before)),
        'test_bodies_after': len(re.findall(rb'#\[test\]', after))})
reference = root / '.reference/energyplus-src/26.1.0'
pin = '6f2e40d10250a105b49966baa24d843711e61048'
name = 'src/EnergyPlus/ZoneEquipmentManager.cc'
original = (reference / name).read_bytes()
assert subprocess.check_output(['git', '-C', str(reference), 'show', pin + ':' + name]).replace(b'\r\n', b'\n') == original.replace(b'\r\n', b'\n')
literal = store(out / 'ZoneEquipmentManager.cc-174-192.source', b''.join(original.splitlines(keepends=True)[173:192]))
manifest = {
    'schema': 'src06-six-handler-canonical-assembly.v1', 'base_head': applied['base_head'],
    'files': files, 'apply': ref(apply_path),
    'held_manifest': applied['held_manifest'], 'independent_held_review': applied['independent_review'],
    'parent': ref(base / 'ordinary-six-handler-assembly-02/manifest.json'),
    'author': ref(Path(__file__)), 'new_test_bodies': 0,
    'Original_ranges': [{'historical_source': ref(reference / name), 'line_start': 174, 'line_end': 192,
        'literal': literal, 'authentication': 'Complete Original file matches Git ' + pin + ' after CRLF normalization'}],
    'scope': 'The genuine GetProjectData timestep now reaches the existing admitted equipment clock operand before geometry. No family-admission or equation change.',
    'full_Setup_completed': False, 'gates_updated': False,
}
path = out / 'manifest.json'
path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
print(json.dumps({'manifest': ref(path), 'paths': len(files)}))

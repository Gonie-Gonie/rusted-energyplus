"""Activate the independently reviewed finite Source initialization packet."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-six-handler-assembly-01'
parser = argparse.ArgumentParser()
parser.add_argument('--held-sha256', required=True)
parser.add_argument('--review', required=True)
parser.add_argument('--review-sha256', required=True)
args = parser.parse_args()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def checked(row):
    path = root / row['path']
    actual = ref(path)
    assert actual['sha256'] == row['sha256'], row
    assert actual['size_bytes'] == row.get('size_bytes', actual['size_bytes']), row
    return path

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

held_path = base / 'ordinary-six-handler-assembly-prep-01/manifest.json'
assert ref(held_path)['sha256'] == args.held_sha256
held = json.loads(held_path.read_bytes())
review_path = root / args.review
assert ref(review_path)['sha256'] == args.review_sha256
review = json.loads(review_path.read_bytes())
assert review['accepted'] is True
head = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert head == held['review_time_git_HEAD'] == '7997dfe273a2e19ede3cc13c92dffd27de124665'
assert subprocess.check_output(['git', 'status', '--porcelain']) == b''
assert not out.exists()

rows = list(held['files'])
project = json.loads(checked(next(row for row in held['dependencies'] if '/ordinary-project-data-prep-02/' in row['path'])).read_bytes())
fluid = json.loads(checked(next(row for row in held['dependencies'] if '/ordinary-fluid-properties-prep-01/' in row['path'])).read_bytes())
prefix = 'crates/ep_runtime/src/heat_balance/'
project_names = {
    prefix + 'selected_project_data.rs',
    prefix + 'selected_project_data/input.rs',
    prefix + 'selected_project_data/input/schema.rs',
    prefix + 'selected_project_data/getter.rs',
    prefix + 'selected_project_data/environment.rs',
    prefix + 'selected_heat_balance_globals.rs',
    'crates/ep_run/src/ordinary_project_data.rs',
}
fluid_names = {prefix + 'selected_fluid_properties.rs', *(
    prefix + 'selected_fluid_properties/' + name + '.rs'
    for name in ['owners', 'limits', 'glycol_data', 'water_steam_data']
)}
dependencies = [row for row in project['files'] if row['canonical_path'] in project_names]
dependencies += [row for row in fluid['files'] if row['canonical_path'] in fluid_names]
assert len(dependencies) == 12
assert {row['canonical_path']: row.get('proposed') or row.get('proposal') for row in dependencies} == {
    row['canonical_path']: row['payload'] for row in held['dependency_files']
}
rows += dependencies
assert len(rows) == 34 and len({row['canonical_path'] for row in rows}) == 34

payloads = []
for row in rows:
    name = row['canonical_path']
    destination = root / name
    assert destination.resolve().is_relative_to((root / 'crates').resolve())
    proposal = checked(row.get('proposed') or row.get('proposal'))
    before = destination.read_bytes() if destination.is_file() else b''
    if before:
        authority = row.get('base_authority')
        assert authority is not None and authority['path'] == name, name
        assert ref(destination) == authority, name
        assert checked(row['base']).read_bytes() == before.replace(b'\r\n', b'\n')
        assert subprocess.check_output(['git', 'show', head + ':' + name]) == before
    after = proposal.read_bytes()
    assert after != before, name
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after)), name
    payloads.append((name, before, after, ref(proposal)))

out.mkdir()
for index, (name, before, after, proposal_ref) in enumerate(payloads):
    (out / f'{index:02}.before').write_bytes(before)
    destination = root / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(after)
write(out / 'apply.json', {
    'schema': 'src06-six-handler-activation.v1',
    'base_head': head,
    'held_manifest': ref(held_path),
    'independent_review': ref(review_path),
    'paths': [name for name, _, _, _ in payloads],
    'activated_proposals': [row for _, _, _, row in payloads],
    'exact_dependency_count': len(dependencies),
    'new_test_bodies': 0,
    'new_test_binaries': 0,
    'author': ref(Path(__file__)),
    'full_Setup_completed': False,
    'gates_updated': False,
})
print(json.dumps({'apply': ref(out / 'apply.json'), 'paths': len(payloads)}))

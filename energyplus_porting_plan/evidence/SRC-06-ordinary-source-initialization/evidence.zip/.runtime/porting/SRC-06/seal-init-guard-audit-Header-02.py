"""Seal a Source audit conclusion and bounded dependency notes; no targets."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path.cwd()
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-init-guard-audit-Header-02'
REF = ROOT / '.reference/energyplus-src/26.1.0'
COMMIT = '6f2e40d10250a105b49966baa24d843711e61048'

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

index_ref = ref(OUT / 'source-index.json')
assert index_ref['sha256'] == 'ef6bc5553179eac819dd42187eab5f21559e3dd80f554376dd4c289307ae86fc'
index = json.loads((OUT / 'source-index.json').read_bytes())
assert [row['member'] for row in index['lists']['init_constant_state']['calls']] == [row['member'] for row in index['lists']['init_state']['calls']]
assert all(len(group['calls']) == 249 for group in index['lists'].values())
assert all(row['method']['resolution'] == 'resolved' for group in index['lists'].values() for row in group['calls'])
assert index['counts'] == {'init_constant_state': {'literal-empty-body': 246, 'nonempty-body-requires-semantic-review': 3}, 'init_state': {'nonempty-body-requires-semantic-review': 5, 'literal-empty-body': 244}}
for group in index['lists'].values():
    for row in group['calls']:
        assert ref(ROOT / row['declaration']['literal']['path']) == row['declaration']['literal']
        assert ref(ROOT / row['method']['range']['literal']['path']) == row['method']['range']['literal']

supplement = []
for relative, first, last in [
    ('src/EnergyPlus/Data/BaseData.hh', 55, 61),
    ('src/EnergyPlus/Data/EnergyPlusData.hh', 603, 614),
    ('src/EnergyPlus/Data/EnergyPlusData.cc', 311, 316),
    ('src/EnergyPlus/SimulationManager.cc', 203, 216),
    ('src/EnergyPlus/Psychrometrics.cc', 110, 134),
    ('src/EnergyPlus/PsychCacheData.hh', 75, 154),
    ('src/EnergyPlus/Psychrometrics.hh', 72, 82),
    ('src/EnergyPlus/ScheduleManager.cc', 312, 327),
]:
    actual = (REF / relative).read_bytes()
    pinned = subprocess.run(['git', '-C', str(REF), 'show', COMMIT + ':' + relative], check=True, capture_output=True).stdout
    selected = b''.join(actual.splitlines(True)[first - 1:last])
    selected_git = b''.join(pinned.splitlines(True)[first - 1:last])
    assert selected.replace(b'\r\n', b'\n') == selected_git.replace(b'\r\n', b'\n')
    target = OUT / 'Original' / ('supplement-' + Path(relative).name + '-' + str(first) + '-' + str(last) + '.txt')
    if target.exists():
        assert target.read_bytes() == selected
    else:
        target.write_bytes(selected)
    supplement.append({'Original_file': (REF / relative).relative_to(ROOT).as_posix(), 'first_line': first, 'last_line': last, 'literal': ref(target), 'pinned_git_exact_CRLF_normalized': True})

dependencies = []
for name in [
    'Header-ordinary-project-data-Source-review-02/review.json',
    'Header-ordinary-fluid-properties-Source-review-01/review.json',
    'Header-ordinary-run-services-Source-review-01/review.json',
    'ordinary-simulation-startup-checks-prep-02/manifest.json',
    'ordinary-schedule-manager-prep-02/manifest.json',
    'ordinary-audit-file-host-prep-02/manifest.json',
]:
    path = ROOT / '.runtime/porting/SRC-06' / name
    if path.exists(): dependencies.append(ref(path))
    else: raise FileNotFoundError(path)

requirements = [
    {'phase': 'init_constant_state', 'ordinal': 3, 'member': 'dataPsychrometrics', 'actual_callee': 'Psychrometrics::InitializePsychRoutines', 'required_selected_effect': 'Under actual EP_cache macros, fill each complete Twb/Psat/Tsat/Tsat_HPb cache with its literal constructor cell; ordinary dataPsychCache init methods are separately literal empty.', 'qualification': 'Compile-time EP_nocache policy must remain explicit. Twb and both Tsat fillers use zero-tag/value cells; Psat uses iTdb=-1000 and +0. No cache numerical PASS follows from this audit.'},
    {'phase': 'init_constant_state', 'ordinal': 4, 'member': 'dataFluid', 'actual_callee': 'Fluid::InitConstantFluidPropertiesData', 'required_selected_effect': 'Always construct Steam/Water owners, literal arrays and limits; optional PERFORMANCE_OPT ratios obey actual compile policy.', 'qualification': 'Reuse independently reviewed Fluid ca779 packet; Source-uninitialized Steam superheated matrices remain explicitly unknown, never manufactured zero.'},
    {'phase': 'init_constant_state', 'ordinal': 5, 'member': 'dataSched', 'actual_callee': 'Sched::InitConstantScheduleData', 'required_selected_effect': 'Create real builtin Constant-0.0/Constant-1.0 schedules and MissingDaySchedule-0.0 with indices 0/1/0 and isUsed=true.', 'qualification': 'Same retained schedule owner; builtin indices are not user ScheduleId(0/1).'},
    {'phase': 'init_state', 'ordinal': 1, 'member': 'dataSimulationManager', 'actual_callee': 'SimulationManager::OpenOutputFiles then GetProjectData', 'required_selected_effect': 'Reset StdOutputRecordCount, actual ESO/EIO/MTR/BND ensure_open and version headers in order, then same live input/global/weather/HVAC getter and six EIO sections.', 'qualification': 'Real output-control flags and OS failures must be preserved. Audit is not opened here. Actual loader format, same scratch/unused owner and weather allocation order remain mandatory.'},
    {'phase': 'init_state', 'ordinal': 2, 'member': 'dataEMSMgr', 'actual_callee': 'EMSManager::CheckIfAnyEMS', 'required_selected_effect': 'Perform actual ordered family count writes, active callback/API/external HVAC operands, then genuine ScanForReports and no-EMS warning or real EDD branch.', 'qualification': 'Zero family input is not a no-op; scan cache/scratch/used identities and reached backend failures are retained. Positive EMS/EDD remains outside selected scope unless implemented.'},
    {'phase': 'init_state', 'ordinal': 4, 'member': 'dataFluid', 'actual_callee': 'Fluid::GetFluidPropertiesData', 'required_selected_effect': 'Real cache/ethylene/propylene initialization, eight count/four exact-case section queries, actual zero-user input/limits branch.', 'qualification': 'Same reviewed sole Fluid and SelectedInputProcessor owners; positive user fluids remain unsupported.'},
    {'phase': 'init_state', 'ordinal': 5, 'member': 'dataSched', 'actual_callee': 'Sched::ProcessScheduleInput', 'required_selected_effect': 'Actual once flag/prefix counts/local arrays, genuine audit ensure_open at 718, real selected constant input and outputs.', 'qualification': 'Audit host outlives Err, has true real File semantics and failure latch, never sink/no-op. Unsupported schedule families remain explicit unavailable.'},
    {'phase': 'init_state', 'ordinal': 6, 'member': 'dataCurveManager', 'actual_callee': 'Curve::GetCurveInput then GetPressureSystemInput', 'required_selected_effect': '22 actual analytic/WPC counts, real unconditional table queries/clears/maps, pressure count and actual allocated empty PressureCurve even at zero.', 'qualification': 'Reuse independently reviewed zero-domain run-services Source; positive curves are not certified.'},
]

readme = '''# Complete EnergyPlusData initialization Source audit

Pinned Original commit: 6f2e40d10250a105b49966baa24d843711e61048 (26.1.0).

Both guards contain exactly 249 ordered member calls. Every actual field type and concrete BaseGlobalStruct method was resolved; all 498 method ranges and member declarations are retained. 249 complete selected Original files match the pinned Git blobs after CRLF normalization. The earlier 01 index retains seven explicitly unresolved name/extension cases; 02 resolves the six global/nested name collisions and AirflowNetwork Solver.hpp from their actual concrete BaseGlobalStruct definitions. No unresolved handler is treated as empty.

| Guard | Literal empty bodies | Nonempty bodies |
| --- | ---: | --- |
| init_constant_state | 246 | 3: Psych, Fluid, Schedule |
| init_state | 244 | 5: Simulation, EMS, Fluid, Schedule, Curve |

No extra nonempty direct handler beyond the existing six logical modules was found. Psych's init_state is itself literally empty; InitializePsychRoutines belongs to init_constant_state. Empty means the real method body has no executable C++ tokens after comment/literal masking, never an inference from manager names or zero inputs. BaseGlobalStruct methods are pure virtual; no inherited generic no-op was assumed.

Both Original guard booleans default false and are set true before the first handler. A reached error retains that flag and every preceding effect; a second invocation returns immediately until real clear_state resets it. These are call guards, not proof that all positive input routines or constructor fields are ready. The caller invokes constant initialization then input initialization at SimulationManager210/211.

The eight nonempty phase/member requirements are listed in review.json. Omitting only literal-empty method calls is justified by this Source inventory; it does not implement missing selected constructors, filesystem outputs, psychrometric cache policy, real queries or unsupported positive branches. This audit certifies Source resolution and required ordering only. It does not certify the current Rust assembly's full execution/initialization, numerical parity, Setup or gates.

No canonical files, compiler, Cargo, tests, engine or Native capture were run or changed.
'''
readme_path = OUT / 'README.md'
assert not readme_path.exists()
readme_path.write_text(readme, encoding='utf-8', newline='\n')
review = {'schema': 'src06-complete-init-guard-independent-Source-audit.v1', 'accepted': True, 'Original_git_commit': COMMIT, 'source_index': index_ref, 'README': ref(readme_path), 'counts': index['counts'], 'calls_per_phase': 249, 'resolved_method_count': 498, 'unresolved_method_count': 0, 'authenticated_complete_Original_files': 249, 'findings': [], 'minimal_additional_nonempty_direct_handlers_beyond_existing_six': [], 'nonempty_phase_member_requirements': requirements, 'supporting_literal_ranges': supplement, 'prior_selected_callee_Source_reviews_and_preparations': dependencies, 'guard_semantics': {'constructor_flags_false': True, 'flag_set_before_any_handler': True, 'error_preserves_true_flag_and_reached_prefix': True, 'repeat_call_returns_until_actual_clear_state': True, 'literal_empty_calls_do_not_imply_constructor_or_positive_input_readiness': True}, 'qualification': ['Complete actual method resolution, not proof from zero inputs or names.', 'Both full call lists and real method bounds authenticated; semantic requirements apply only to represented selected callee domains.', 'Current Rust assembly was not supplied or inspected by this audit and is not certified complete.', 'No full positive input, cache numeric parity, whole Setup or gate PASS claim.'], 'canonical_mutated': False, 'compiler_engine_or_targets_executed': False, 'gates_PASS': False, 'audit_author': ref(ROOT / '.runtime/porting/SRC-06/audit-init-guards-Header-02.py'), 'seal_author': ref(Path(__file__))}
review_path = OUT / 'review.json'
assert not review_path.exists()
review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'review': ref(review_path), 'README': ref(readme_path), 'index': index_ref, 'requirements': len(requirements)}))

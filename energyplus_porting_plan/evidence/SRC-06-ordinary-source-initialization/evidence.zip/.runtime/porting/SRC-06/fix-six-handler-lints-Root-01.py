"""Preserve exact Original fluid literals and derive the same empty Curve default."""
from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
parent_path = base / 'ordinary-six-handler-assembly-01/manifest.json'
parent = json.loads(parent_path.read_bytes())
receipt_path = base / 'ordinary-six-handler-clippy-01/receipt.json'
receipt = json.loads(receipt_path.read_bytes())
assert receipt['exit_code'] == 101 and receipt['source_bytes_match_before_and_after'] is True
assert not (base / 'ordinary-six-handler-assembly-02').exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

for row in parent['files']:
    assert ref(root / row['canonical']['path']) == row['canonical']

glycol = root / 'crates/ep_runtime/src/heat_balance/selected_fluid_properties/glycol_data.rs'
curve = root / 'crates/ep_runtime/src/heat_balance/setup_postludes.rs'
original_glycol = glycol.read_bytes()
insertion = (b'// These are Original measured property-table decimals, not mathematical constants.\n'
             b'#![allow(clippy::approx_constant)]\n')
marker = b'//! Literal FluidProperties.cc built-in concentration/temperature table rows.\n'
assert original_glycol.count(marker) == 1
glycol.write_bytes(original_glycol.replace(marker, marker + insertion))
assert glycol.read_bytes().replace(insertion, b'') == original_glycol

original_curve = curve.read_bytes()
old_derive = b'#[derive(Clone, Debug, PartialEq)]\npub(crate) struct SelectedCurves'
new_derive = b'#[derive(Clone, Debug, Default, PartialEq)]\npub(crate) struct SelectedCurves'
manual = b'''impl Default for SelectedCurves {
    fn default() -> Self {
        Self {
            btwxt: SelectedBtwxtManager::default(),
            pressure_curves: None,
        }
    }
}
'''
assert original_curve.count(old_derive) == original_curve.count(manual) == 1
changed_curve = original_curve.replace(old_derive, new_derive).replace(manual, b'')
assert changed_curve.replace(new_derive, old_derive).replace(b'impl SelectedCurves {', manual + b'impl SelectedCurves {') == original_curve
curve.write_bytes(changed_curve)

path = base / 'ordinary-six-handler-lint-fix-01.json'
assert not path.exists()
path.write_bytes((json.dumps({
    'schema': 'src06-six-handler-lint-fix.v1', 'parent': ref(parent_path),
    'failed_QA': ref(receipt_path), 'author': ref(Path(__file__)),
    'changed_files': [ref(glycol), ref(curve)],
    'proof': [
        'Glycol: removing only scoped lint attribute/comment restores whole exact file; every Original table literal is unchanged.',
        'Curve: derive(Default) uses the identical field defaults in declaration order; inverse restores whole manual implementation and exact file.',
        'All other34 full canonical files remain parent-exact; no body/bin/number/input/ordering/algorithm changed.',
    ], 'gates_updated': False,
}, indent=2) + '\n').encode())
print(json.dumps({'fix': ref(path)}))

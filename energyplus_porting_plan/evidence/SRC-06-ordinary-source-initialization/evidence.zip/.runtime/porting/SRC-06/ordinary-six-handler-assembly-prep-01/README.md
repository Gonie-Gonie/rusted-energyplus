# HELD six-handler startup assembly

Source only against committed 7997dfe273a2e19ede3cc13c92dffd27de124665. Nothing applied, formatted, compiled, tested or run. This packet has exactly 22 authored proposals plus 12 unchanged authoritative dependency payloads (34 distinct paths). Apply only these rows; never copy historical context, metadata, pipeline or raw-format rows wholesale from a dependency packet.

The complete249-member Source closure permits omission only of literal-empty methods: constants Psych→Fluid→Schedule; input Simulation(OpenOutputFiles→GetProjectData)→EMS→emptyPsych→Fluid→Schedule→Curve. Each parent guard becomes true before dispatch and stays true after an error. Reentry returns before owner creation when both guards are true. Actual process environment is resolved once before the preserved PostIP call, using the current selected ReverseDD capture; this is not a certificate of every process-environment reader.

Actual Files are non-Clone read/write/create/truncate streams at caller-supplied output paths. OpenOutputFiles resets StdOutputRecordCount then opens/prints ESO→EIO→MTR→BND. Audit opens only at ProcessScheduleInput718. OS errors retain path/cause and reach the real fatal backend. No new Source flush is inserted: explicit flushing is only the existing Rust run-persistence/close boundary after the reached error/console prefix is written. Later HB reuses the exact already-open EIO, with no successful sink or buffered fallback.

The same retained constructor WeatherDayState receives actual GetProjectData writes before any live WeatherSession/Today/Tomorrow allocation. The effective timestep is written to the same mutable SimulationModel, then the actual time-axis profiles, weather session and derived schedule cache. Ordinary cache creation/trace happens once after this normalization; nonordinary paths preserve their earlier preparation. Successful session construction moves the state and clears its old Option; failures retain partial state. Effective detailed/advanced/doPure controls replace the existing raw reporting projection, including the same radiation input's private advanced flag. DeveloperFlag is joined to the existing backend carrier.

Startup activation is only the actually consumed EMS/HVAC slice; later construction bounds, time-pointer checks, sizing and Setup methods remain immutable HELD dependencies. Curve contains only its consumed input getters/storage; Cost/Fault/reporting remain held. The unchanged Fluid constructor includes its actual allocated cache, literal tables and explicit unknown Steam storage. Source schedule types/constants now retain exact raw identities, validate permanent association and reset locals→erase unused identity before consumed getter values. Other actual InputProcessor objects are not claimed consumed.

Existing ordinary admission remains unchanged: non-divisor timestep repair is available through the direct selected getter API but not newly admitted by the ordinary pipeline. CI_FORCE_TIME_STEP=2 and present-empty Timestep schema6 do reach effective handoff. Actual DDONLY/annual or DoWeathSim=false results stop explicitly before the current RunPeriod-only executor. Whole startup, downstream Setup, positive EMS/user-fluid/nonconstant/Curve branches, Native numerical parity and gates are not certified by this Source packet.

Two existing test bodies are expanded: Psych cache clearing retains actual saved scalar state/default tags; real output test forces MTR open failure, verifies ESO/EIO prefix + no unreached BND/Audit, retained guards and no retry/truncation, then actual six-handler EIO/Audit completion and effective reporting handoff. The existing full weather-state canary receives the added ForceBeginEnvResetSuppress field. No new test body, fixture, Native run or numerical expected value was introduced.

The before/diff archives are LF-normalized text; base_authority pins authentic raw bytes and records their real line endings. Do not claim raw inverse equality across normalization. Dependency payloads are copied byte-exact. Root must independently review/apply, run actual fmt/quality/Clippy/affected tests and preserve genuine failures in a successor if found.

Exact application rows:
- crates/ep_runtime/src/heat_balance/source_initialization.rs
- crates/ep_runtime/src/heat_balance/source_initialization/files.rs
- crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs
- crates/ep_runtime/src/heat_balance/setup_postludes.rs
- crates/ep_runtime/src/heat_balance/radiation/ordinary.rs
- crates/ep_runtime/src/heat_balance/state.rs
- crates/ep_runtime/src/psychrometrics/psy02_state.rs
- crates/ep_runtime/src/psychrometrics.rs
- crates/ep_runtime/src/psychrometrics/psy02_state/tests.rs
- crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs
- crates/ep_run/src/ordinary_schedule_input.rs
- crates/ep_runtime/src/weather_day/context.rs
- crates/ep_runtime/src/weather_day/tests.rs
- crates/ep_runtime/src/weather_day/lifecycle.rs
- crates/ep_runtime/src/weather_day/production.rs
- crates/ep_runtime/src/time_axis.rs
- crates/ep_runtime/src/runtime.rs
- crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs
- crates/ep_runtime/src/heat_balance/mod.rs
- crates/ep_run/src/ctf_initialization_outputs.rs
- crates/ep_run/src/pipeline.rs
- crates/ep_run/src/lib.rs
- crates/ep_runtime/src/heat_balance/selected_project_data.rs
- crates/ep_runtime/src/heat_balance/selected_project_data/input.rs
- crates/ep_runtime/src/heat_balance/selected_project_data/input/schema.rs
- crates/ep_runtime/src/heat_balance/selected_project_data/getter.rs
- crates/ep_runtime/src/heat_balance/selected_project_data/environment.rs
- crates/ep_runtime/src/heat_balance/selected_heat_balance_globals.rs
- crates/ep_run/src/ordinary_project_data.rs
- crates/ep_runtime/src/heat_balance/selected_fluid_properties.rs
- crates/ep_runtime/src/heat_balance/selected_fluid_properties/owners.rs
- crates/ep_runtime/src/heat_balance/selected_fluid_properties/limits.rs
- crates/ep_runtime/src/heat_balance/selected_fluid_properties/glycol_data.rs
- crates/ep_runtime/src/heat_balance/selected_fluid_properties/water_steam_data.rs

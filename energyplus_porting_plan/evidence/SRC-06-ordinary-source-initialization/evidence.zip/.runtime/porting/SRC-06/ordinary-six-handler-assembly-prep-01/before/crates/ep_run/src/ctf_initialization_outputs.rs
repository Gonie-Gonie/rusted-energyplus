//! Real Rust ordinary-run initialization owners, independent of runtime Result.
//!
//! These are Rust-owned header strings and explicit absent optional adapters;
//! Native version/header/callback/SQLite byte parity is not claimed.

use ep_runtime::heat_balance::ctf_initialization_context::{
    CtfInitializationContext, CtfInitializationReports,
};
use ep_runtime::heat_balance::error_backend::{
    SourceErrorBackend, SourceErrorState, SourceErrorTracking,
};
use std::path::Path;

pub(crate) struct CtfRunOutputs {
    reports: CtfInitializationReports,
    state: SourceErrorState,
    error: Vec<u8>,
    console: Vec<u8>,
    eio: Vec<u8>,
    reached: bool,
}

impl CtfRunOutputs {
    pub(crate) fn new(typed_input_version: &str) -> Self {
        Self {
            reports: CtfInitializationReports::default(),
            state: SourceErrorState {
                output_error_header: true,
                version_string: concat!("rusted-energyplus ", env!("CARGO_PKG_VERSION")).into(),
                idd_version_string: format!("Rust typed input version {typed_input_version}"),
                // Compilation has returned; construction generation precedes the
                // ordinary warmup/run loops. This caller has no sizing/kickoff path.
                doing_input_processing: false,
                print_console_output: true,
                kickoff_simulation: false,
                developer_flag: false,
                warmup_flag: false,
                doing_sizing: false,
                tracking: SourceErrorTracking {
                    match_counts: [0; 20],
                    abort_processing: false,
                    total_severe_errors: 0,
                    last_severe_error: String::new(),
                    total_severe_errors_during_warmup: 0,
                    total_severe_errors_during_sizing: 0,
                    total_warning_errors: 0,
                    total_warning_errors_during_warmup: 0,
                    total_warning_errors_during_sizing: 0,
                },
            },
            error: Vec::new(),
            console: Vec::new(),
            eio: Vec::new(),
            reached: false,
        }
    }

    pub(crate) fn context(&mut self) -> CtfInitializationContext<'_> {
        self.reached = true;
        CtfInitializationContext {
            reports: &mut self.reports,
            eio: &mut self.eio,
            backend: SourceErrorBackend {
                state: &mut self.state,
                error_stream: Some(&mut self.error),
                console: &mut self.console,
                // RunConfig owns no SQLite, callback or optional output-unit adapter.
                // The actual buffered console stream is exported separately from
                // CLI JSON stdout, rather than silently replacing it with a no-op.
                out_unit1: None,
                out_unit2: None,
                f_message: None,
                message_callback: None,
                error_callback: None,
                sqlite: None,
            },
        }
    }

    pub(crate) fn persist(&self, output_dir: &Path) -> Result<(), String> {
        if !self.reached {
            return Ok(());
        }
        // Write the genuine error prefix first, including when runtime returned Err.
        // Later summary rendering reads this independent exact-byte artifact.
        for (name, bytes) in [
            ("eplusrs.ctf.err", &self.error),
            ("eplusrs.eio", &self.eio),
            ("eplusrs.ctf.log", &self.console),
        ] {
            std::fs::write(output_dir.join(name), bytes)
                .map_err(|error| format!("failed to write {name}: {error}"))?;
        }
        Ok(())
    }
}

/// Preserve the reached Source prefix before the ordinary structured summary.
pub(crate) fn write_error_summary(output_dir: &Path, summary: &str) -> Result<(), String> {
    let path = output_dir.join("eplusrs.ctf.err");
    let mut bytes = match std::fs::read(&path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Vec::new(),
        Err(error) => return Err(format!("failed to read {}: {error}", path.display())),
    };
    bytes.extend_from_slice(summary.as_bytes());
    std::fs::write(output_dir.join("eplusrs.err"), bytes)
        .map_err(|error| format!("failed to write eplusrs.err: {error}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn actual_fatal_prefix_survives_runtime_failure_and_summary()
    -> Result<(), Box<dyn std::error::Error>> {
        let dir = std::env::temp_dir().join(format!(
            "ep-run-ctf-prefix-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_nanos()
        ));
        std::fs::create_dir(&dir)?;
        let mut output = CtfRunOutputs::new("authored test input version");
        {
            let mut context = output.context();
            context
                .backend
                .show_severe_error("authored reached severe")?;
            assert!(
                context
                    .backend
                    .show_fatal_error("authored reached fatal")
                    .is_err()
            );
        }
        let prefix = output.error.clone();
        assert!(!prefix.is_empty());
        // Genuine ShowFatalError preserves AbortProcessing and throws FatalError.
        assert!(!output.state.tracking.abort_processing);
        output.persist(&dir)?;
        write_error_summary(&dir, "actual structured runtime failure\n")?;
        let combined = std::fs::read(dir.join("eplusrs.err"))?;
        assert_eq!(&combined[..prefix.len()], prefix.as_slice());
        assert_eq!(
            &combined[prefix.len()..],
            b"actual structured runtime failure\n"
        );
        assert_eq!(std::fs::read(dir.join("eplusrs.ctf.err"))?, prefix);
        for name in [
            "eplusrs.ctf.err",
            "eplusrs.err",
            "eplusrs.eio",
            "eplusrs.ctf.log",
        ] {
            std::fs::remove_file(dir.join(name))?;
        }
        std::fs::remove_dir(dir)?;
        Ok(())
    }
}

"""Publish the actual bounded startup activation and genuine QA history."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = root / 'energyplus_porting_plan/evidence/SRC-06-ordinary-source-initialization'
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def load(path): return json.loads(path.read_bytes())
def write(path, value): path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value, list):
        for child in value: yield from walk(child)

assembly_paths = [base / f'ordinary-six-handler-assembly-{i:02}/manifest.json' for i in [1, 2, 3]]
assemblies = [load(path) for path in assembly_paths]
assert ref(assembly_paths[-1])['sha256'] == '9b67f879a5812159134f010b398050b4142355b52ea855e6148f76c84bc721af'
held_path = base / 'ordinary-six-handler-assembly-prep-01/manifest.json'
held = load(held_path)
assert ref(held_path)['sha256'] == 'd43a19500b3341b7b7719343f21d505d3f07935e8d627eb9446e0f2d5a807a5d'
review_paths = [base / name / 'review.json' for name in [
    'Owner-ordinary-six-handler-Source-review-01',
    'Owner-ordinary-six-handler-application-review-01',
    'Owner-ordinary-six-handler-application-review-02',
    'Owner-ordinary-six-handler-application-review-03',
]]
assert ref(review_paths[-2])['sha256'] == 'fbc0245d28407077ee9a6ef68f7c74a929207af784c90c25f78ec1344db9d5dc'
assert ref(review_paths[-1])['sha256'] == 'b734493f2606b9e43da40aca238caf57cc281bb963ebd8485e24bfde42ccfc8a'
assert all(load(path)['accepted'] is True for path in review_paths)

archives = {}
for manifest in assemblies:
    for row in manifest['files']:
        for key in ['before', 'after']:
            archives[row[key]['sha256']] = root / row[key]['path']
for row in held['files']:
    for key in ['base', 'proposed']:
        if row[key] is not None:
            archives[row[key]['sha256']] = root / row[key]['path']

artifacts = {}
historical = []
def add(path):
    value = ref(path)
    artifacts[value['path']] = value
    return value

def checked(row):
    path = root / row['path']
    if not path.is_file() or ref(path)['sha256'] != row['sha256']:
        path = archives[row['sha256']]
        historical.append({'historical_reference': row, 'exact_archive': ref(path),
            'qualification': 'Historical canonical reference resolved to the immutable full assembly/held bytes with the identical SHA.'})
    value = ref(path)
    assert value['sha256'] == row['sha256']
    assert value['size_bytes'] == row.get('size_bytes', value['size_bytes'])
    return path

for path in [*assembly_paths, held_path, *review_paths,
    base / 'ordinary-six-handler-assembly-01/apply.json',
    base / 'ordinary-six-handler-assembly-03/apply.json',
    base / 'ordinary-six-handler-assembly-01/cli-test-extension.json',
    base / 'ordinary-six-handler-lint-fix-01.json']:
    add(path)
    for row in walk(load(path)): add(checked(row))
for row in assemblies[-1]['files']:
    assert ref(root / row['canonical']['path']) == row['canonical']

# Only the six dependency manifests, their finite literal Original ranges/schema,
# and exact active payloads are copied. Their other historical Rust proposals are
# provenance references, not active code or a recursively bundled dependency tree.
for dependency in held['dependencies']:
    path = checked(dependency)
    value = load(path)
    add(path)
    for key in ['Original_ranges', 'official_schema', 'four_complete_schema_definitions']:
        for row in walk(value.get(key)): add(checked(row))
for row in held['dependency_files']: add(checked(row['payload']))
guard_path = checked(held['Source_guard_audit'])
add(guard_path)
for row in walk(load(guard_path)): add(checked(row))
for path in [
    base / 'ordinary-six-handler-assembly-prep-01/templates/source_initialization.rs',
    base / 'ordinary-six-handler-assembly-prep-01/templates/files.rs',
    base / 'run-ci-force-time-step-Root-01.ps1',
]: add(path)

qa = []
tests = []
final_source = None
runtime_source = None
commands = [
    ('fmt-03', ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'fmt', '--all', '--', '--check'], True),
    ('clippy-03', ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings'], True),
    ('quality-03', ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'scripts/quality/source-quality-gate.ps1'], True),
    ('runtime-tests-01', ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'test', '-p', 'ep_runtime', '--lib', '--', 'psychrometrics::psy02_state::tests', 'weather::day::lifecycle_tests', 'weather::day::tests'], False),
    ('input-output-tests-02', ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'test', '-p', 'ep_run', '--lib', '--', 'actual_fatal_prefix_survives_runtime_failure_and_summary', 'raw_equipment_admission'], True),
    ('cli-tests-02', ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', 'test', '-p', 'ep_run', '--test', 'arbitrary_run', 'one_zone_runtime_writes_stable_output_layout'], True),
    ('ci-timestep-tests-02', ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', '.runtime/porting/SRC-06/run-ci-force-time-step-Root-01.ps1'], True),
]
for suffix, command, is_final in commands:
    path = base / f'ordinary-six-handler-{suffix}/receipt.json'
    value = load(path)
    assert value['command'] == command and value['exit_code'] == 0
    assert value['source_bytes_match_before_and_after'] is True and value['launch_error'] is None
    if is_final:
        if final_source is None: final_source = value['source_snapshot']
        assert final_source == value['source_snapshot']
    else:
        runtime_source = value['source_snapshot']
    qa.append({'receipt': ref(path), 'final_Source': is_final,
        'qualification': 'Final assembly03' if is_final else 'Actual assembly02: the16 cache/weather tests passed before the final equipment-clock handoff fix. Every tested psychrometric/weather file remains whole-byte exact; only Source initialization equipment-clock adapter and existing equipment input clock method changed. These16 tests were not redundantly rerun or relabeled final Source.'})
    add(path)
    for key in ['stdout', 'stderr', 'source_snapshot']: add(checked(value[key]))
    if 'tests-' in suffix:
        groups = [tuple(map(int, group)) for group in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', checked(value['stdout']).read_text(encoding='utf8'))]
        assert groups and all(group[1] == group[2] == 0 for group in groups)
        tests.append({'scope': suffix, 'passed': sum(group[0] for group in groups), 'failed': 0, 'ignored': 0})
assert [row['passed'] for row in tests] == [16, 2, 1, 1]
assert final_source != runtime_source
prior_source = load(base / 'ordinary-six-handler-clippy-01/receipt.json')['source_snapshot']
failed_path = base / 'ordinary-six-handler-clippy-01/receipt.json'
failed = load(failed_path)
assert failed['exit_code'] == 101 and failed['source_snapshot'] == prior_source
assert failed['source_bytes_match_before_and_after'] is True
add(failed_path)
for key in ['stdout', 'stderr', 'source_snapshot']: add(checked(failed[key]))
history = []
for suffix in ['fmt-01', 'quality-01', 'fmt-02', 'clippy-02', 'input-output-tests-01', 'cli-tests-01', 'ci-timestep-tests-01']:
    path = base / f'ordinary-six-handler-{suffix}/receipt.json'
    value = load(path)
    assert value['source_bytes_match_before_and_after'] is True
    assert value['exit_code'] == (1 if suffix == 'ci-timestep-tests-01' else 0)
    history.append({'receipt': ref(path), 'exit_code': value['exit_code'], 'Source_snapshot': value['source_snapshot'],
        'qualification': 'Historical actual QA; CI wrapper exit1 contains Cargo test exit101 and GeometryOrTimestep from raw6/effective2 mismatch. Immutable failed case custody is in assembly03 apply.' if suffix == 'ci-timestep-tests-01' else 'Historical earlier-Source success; not counted again in the20 selected passing checks.'})
    add(path)
    for key in ['stdout', 'stderr', 'source_snapshot']: add(checked(value[key]))
add(Path(__file__))

out.mkdir()
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts): z.write(root / name, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(artifacts)
    for name in z.namelist(): assert hashlib.sha256(z.read(name)).hexdigest() == artifacts[name]['sha256']

write(out / 'manifest.json', {
    'schema': 'src06-source-initialization-evidence.v1', 'Source_snapshot': final_source,
    'assembly': ref(assembly_paths[-1]), 'independent_reviews': [ref(path) for path in review_paths],
    'artifacts': list(artifacts.values()), 'historical_references': historical,
    'archive': ref(archive), 'archive_member_count': len(artifacts),
    'archive_scope': '37 active before/after/full diffs, finite dependency Source literals/schema, guard audit metadata, independent reviews, actual QA receipts/logs/Source snapshot indexes and24 complete failed CI case files. Other historical dependency Rust proposals and249 complete guard-closure files remain referenced provenance; not a transitive whole-workspace/Native replay bundle.',
    'gates_updated': False,
})
behavior = [
    'Actual ordinary environment preparation precedes PostIP; 249-member guard audit justifies omitting only literal-empty direct methods.',
    'Genuine constant Psych(cache-only)/Fluid/Schedule then input Simulation(OpenOutputFiles/GetProjectData)/EMS/emptyPsych/Fluid/Schedule/Curve dispatch on the same retained owners. Guards set before dispatch and survive failure.',
    'Actual ESO/EIO/MTR/BND open/header order and Schedule-only Audit opening; OS fatal error prefix and opened files remain retained; repeated guards do not retry/truncate; later HB borrows the same already-open EIO.',
    'Same pre-weather state receives Project writes, moves only after successful weather preparation; effective timestep updates same compiled model/time-axis before actual weather allocation and the single derived cache/trace.',
    'The existing admitted equipment operand receives that same actual effective timestep before GetZoneEquipment allocation; admitted family inventory remains unchanged. Actual forced-timestep CLI caught and verifies this handoff.',
    'Effective developer/detailed/advanced/doPure reporting controls reach existing backend/reporting/radiation carriers; raw Schedule identities erase exact unused-input entries with local scratch only.',
    'Existing test bodies/output-contract helper expanded; no new test body/bin. Other runtime output contracts and legacy preparation preserved.',
]
write(out / 'summary.json', {
    'schema': 'src06-source-initialization-summary.v1',
    'status': 'Actual bounded ordinary six-handler initialization activated; whole startup/Setup remains incomplete',
    'Source_snapshot': final_source, 'prior_QA_Source_snapshot': prior_source, 'cache_weather_QA_Source_snapshot': runtime_source,
    'behavior': behavior, 'QA': qa,
    'tests': {'selections': tests, 'passed': 20, 'failed': 0, 'ignored': 0, 'new_bodies': 0, 'new_binaries': 0},
    'historical_failed_QA': {'receipt': ref(failed_path), 'exit_code': 101,
        'qualification': 'Three Clippy approximate-constant findings on genuine glycol0.318 table entries plus derivable Curve Default. No Original decimal changed; actual failed Source/receipt/log preserved.'},
    'historical_QA': history,
    'independent_reviews': [ref(path) for path in review_paths],
    'limitations': [
        'Ordinary raw admission unchanged; nondivisor repair available only through selected getter API. Effective DDONLY/annual/DoWeathSim=false explicitly unavailable before current RunPeriod executor.',
        'Positive EMS/user-fluid/nonconstant schedule/Curve, later startup checks/sizing/Setup/HB/HVAC are incomplete.',
        'Selected Rust behavior regression, not new Native numerical equivalence or whole parser/startup certification.',
        'Whole ordinary235456 mismatches/2754 unavailable and DesignDay nine-field strict failure/eight UNPAIRED fields unchanged.',
        'SRC06 four gates remain unverified; A14/54 B14/64 unchanged.',
    ],
    'validation_scope': 'Final assembly03 fmt/quality/all-target workspace Clippy and4 input/output/CLI checks including actual CI_FORCE_TIME_STEP=Y. The16 cache/weather checks passed on assembly02; their full tested Source files are unchanged and were not rerun. Historical earlier passes are not counted again. No new body/bin or repeated whole-workspace4974 tests.',
    'manifest': ref(out / 'manifest.json'), 'archive': ref(archive), 'gates_updated': False,
})
plan_path = root / 'energyplus_porting_plan/plan.json'
plan = load(plan_path)
task = next(row for row in plan['tasks'] if row['id'] == 'SRC-06')
assert all(task[key] == '미확인' for key in ['scope_review', 'unit_gate', 'integration_gate', 'production_gate'])
assert 'actual_selected_ordinary_source_initialization' not in task
task['actual_selected_ordinary_source_initialization'] = ref(out / 'summary.json')
write(plan_path, plan)
card = root / 'energyplus_porting_plan/cards/SRC-06.md'
text = card.read_text(encoding='utf8')
assert text.count('아래 17개 요약') == 1
text = text.replace('아래 17개 요약', '아래 18개 요약')
needle = '\n기존 Weather03·absent site/station'
assert text.count(needle) == 1
row = '| 실제 여섯 초기화 handler / 파일·시간 전달 | [요약](../evidence/SRC-06-ordinary-source-initialization/summary.json) · [색인](../evidence/SRC-06-ordinary-source-initialization/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-source-initialization/evidence.zip) | 실제 guard·Psych/Fluid/Schedule·Project/EMS/Curve 호출, 동일 EIO·오류 prefix와 effective timestep/reporting 전달. 전체 startup/Setup 완료나 Native 수치 동등성은 아님. |\n'
text = text.replace(needle, row + needle)
needle = '\n## 이력과 증거 보존'
assert text.count(needle) == 1
text = text.replace(needle, '\n## 실제 초기화 연결 단위의 QA\n\n최종 Source `' + final_source['sha256'] + '`에서 fmt·source-quality·all-target workspace Clippy와 입력·출력 오류 2개·일반 CLI 1개·실제 `CI_FORCE_TIME_STEP=Y` CLI 1개를 확인했다. 캐시·기상 소유자 16개는 직전 Source `' + runtime_source['sha256'] + '`에서 통과했고 해당 전체 파일 bytes가 그대로여서 반복하지 않았다. 선택 검증 합계 **20 passed / 0 failed / 0 ignored**이며 과거 중복 성공은 합산하지 않는다. 새 테스트 본문·binary는 없다. 강제 timestep 실행이 raw6/effective2 장비 입력 불일치를 실제로 발견했고, 원본 GetZoneEquipment의 global timestep을 전달해 수정했다. 첫 Clippy exit101과 강제 CLI wrapper exit1(내부 Cargo101), 실패 당시의 24개 입력·출력 파일은 별도 Source와 로그로 보존했다. 전체 workspace 반복 실행·새 Native 수치 PASS는 없다. 모든 gate와 A/B 완료 수는 그대로다.\n' + needle)
card.write_bytes(text.encode())
print(json.dumps({'summary': ref(out / 'summary.json'), 'archive_members': len(artifacts),
    'archive_bytes': archive.stat().st_size, 'tests': tests}, ensure_ascii=False))

"""Author HELD finite Source only. No import, Rust, engine or canonical writes."""
from pathlib import Path
import hashlib,json,difflib,subprocess

ROOT=Path.cwd()
OUT=ROOT/'.runtime/porting/SRC-06/ordinary-six-handler-assembly-prep-01'
def ref(p):
    p=Path(p);b=p.read_bytes()
    return {'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def read(p): return Path(p).read_text(encoding='utf-8-sig')
def replace(s,a,b):
    assert s.count(a)==1,(a[:100],s.count(a))
    return s.replace(a,b)
def save(path,text):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(text.encode('utf-8'));return ref(p)
rows=[]
def proposal(path,text,base=None):
    original=read(base) if base is not None else ''
    br=save(OUT/'before'/path,original) if base else None
    pr=save(OUT/'proposed'/path,text)
    diff=''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    dr=save(OUT/'diffs'/(path+'.diff'),diff)
    rows.append({'canonical_path':path,'base':br,'base_authority':ref(base) if base else None,'proposed':pr,'complete_diff':dr})
def canonical(path,edit): proposal(path,edit(read(ROOT/path)),ROOT/path)
def dep_rows(name):
    p=ROOT/'.runtime/porting/SRC-06'/name/'manifest.json'
    return p,json.loads(read(p))['files']
def selected(name,path):
    p,rows=dep_rows(name);row=next(r for r in rows if r['canonical_path']==path)
    return ROOT/(row.get('proposed') or row.get('proposal'))['path']

# Private selected errors remain genuine objects behind a public error boundary.
source=read(OUT/'templates/source_initialization.rs')
source=replace(source,'    /// A real repeated EMS/report scan failed or reached an unsupported branch.\n    Startup(StartupError),\n    /// Built-in Fluid initialization or its actual selected getter failed.\n    Fluid(SelectedFluidError),\n    /// Actual selected ScheduleManager initialization failed.\n    Schedule(SelectedScheduleError),\n    /// Actual selected Curve initialization reached an unsupported positive branch.\n    Curve(SelectedSetupServiceError),',
'''    /// A selected member handler failed; the actual typed cause remains retained.
    Handler {
        /// Actual selected member whose call failed.
        handler: &'static str,
        /// Unmodified typed error retained behind the public boundary.
        source: Box<dyn std::error::Error>,
    },''')
source=replace(source,'from_error!(StartupError, Startup);\nfrom_error!(SelectedFluidError, Fluid);\nfrom_error!(SelectedScheduleError, Schedule);\nfrom_error!(SelectedSetupServiceError, Curve);',
'''impl From<StartupError> for SourceInitializationError {
    fn from(source:StartupError)->Self { Self::Handler { handler:"EMS",source:Box::new(source) } }
}
impl From<SelectedFluidError> for SourceInitializationError {
    fn from(source:SelectedFluidError)->Self { Self::Handler { handler:"Fluid",source:Box::new(source) } }
}
impl From<SelectedScheduleError> for SourceInitializationError {
    fn from(source:SelectedScheduleError)->Self { Self::Handler { handler:"Schedule",source:Box::new(source) } }
}
impl From<SelectedSetupServiceError> for SourceInitializationError {
    fn from(source:SelectedSetupServiceError)->Self { Self::Handler { handler:"Curve",source:Box::new(source) } }
}''')
source=replace(source,'            Self::Startup(e) => std::fmt::Display::fmt(e,f),\n            Self::Fluid(e) => std::fmt::Display::fmt(e,f),\n            Self::Schedule(e) => std::fmt::Display::fmt(e,f),\n            Self::Curve(e) => std::fmt::Display::fmt(e,f),','            Self::Handler { handler,source } => write!(f,"{handler}: {source}"),')
source=replace(source,'            Self::Project(e) => Some(e), Self::Startup(e) => Some(e), Self::Fluid(e) => Some(e),\n            Self::Schedule(e) => Some(e), Self::Curve(e) => Some(e), Self::Io(e) => Some(e),','            Self::Project(e) => Some(e), Self::Handler { source,.. } => Some(source.as_ref()), Self::Io(e) => Some(e),')
proposal('crates/ep_runtime/src/heat_balance/source_initialization.rs',source)
proposal('crates/ep_runtime/src/heat_balance/source_initialization/files.rs',read(OUT/'templates/files.rs'))

# Only consumed EMS/HVAC fields and the genuine CheckIfAnyEMS body are activated.
# Later construction/time-pointer/check functions remain immutable held Source.
def rust_item(source, marker):
    start=source.index(marker); brace=source.index('{',start); depth=0
    for end in range(brace,len(source)):
        if source[end]=='{': depth+=1
        elif source[end]=='}':
            depth-=1
            if depth==0: return source[start:end+1]
    raise AssertionError(marker)
startup_path='crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs'
startup_base=selected('ordinary-project-data-prep-01',startup_path); full=read(startup_base)
runtime_hvac=full[full.index('/// The sixteen actual'):full.index('/// Sole actual preconstruction')]
ems=rust_item(full,'    pub(crate) fn check_if_any_ems(')
startup='''//! Actual consumed EMS and HVAC startup owner slice; later checks remain held.
use super::error_backend::{SourceErrorBackend,SourceErrorBackendFailure};
use super::report_scan::{ReportScanDiagnostic,ReportScanFailure,ReportScanState,ReportScanUnavailable,SourceReportScanInput,try_scan_for_reports,try_scan_for_reports_with_input};
use super::selected_heat_balance_globals::SelectedHeatBalanceGlobals;
use super::selected_input_processor::{SelectedInputProcessor,SourceInputProcessorShortCut};
use ep_model::ReportInputs;
#[derive(Debug)]
pub(crate) enum StartupError { Backend(SourceErrorBackendFailure),Scan(ReportScanUnavailable),Unavailable(&'static str) }
impl From<SourceErrorBackendFailure> for StartupError { fn from(value:SourceErrorBackendFailure)->Self { Self::Backend(value) } }
impl std::fmt::Display for StartupError { fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result {
    match self { Self::Backend(e)=>std::fmt::Display::fmt(e,f),Self::Scan(e)=>write!(f,"startup report request unavailable: {e:?}"),Self::Unavailable(e)=>write!(f,"selected simulation startup unavailable: {e}") }
} }
impl std::error::Error for StartupError { fn source(&self)->Option<&(dyn std::error::Error+'static)> { match self { Self::Backend(e)=>Some(e),Self::Scan(_)|Self::Unavailable(_)=>None } } }
'''+runtime_hvac+'''
#[derive(Clone,Debug,Default,PartialEq)]
pub(crate) struct SelectedSimulationStartup {
    pub(crate) runtime_language:SelectedRuntimeLanguage,
    pub(crate) hvac_globals:SelectedHvacGlobals,
}
impl SelectedSimulationStartup {
'''+ems+'\n}\n'
proposal(startup_path,startup,startup_base)

curve_path='crates/ep_runtime/src/heat_balance/setup_postludes.rs'
curve_base=selected('ordinary-run-services-prep-01',curve_path);full=read(curve_base)
curve='''//! Actual consumed CurveManager input-state slice; Cost/Fault remain held.
use super::selected_input_processor::SelectedInputProcessor;
use std::collections::BTreeMap;
'''+full[full.index('const CURVE_FAMILIES'):full.index('#[derive(Clone, Debug, PartialEq)]\npub(crate) struct SelectedCostEstimate')]
curve+=full[full.index('#[derive(Clone, Debug, Default, PartialEq)]\npub(crate) struct SelectedBtwxtManager'):full.index('    pub(crate) fn initialize_reporting(')]+'}\n'
curve=replace(curve,'    Positive(&\'static str), Size,','    Positive(&\'static str),')
curve=replace(curve,'            Self::Size => f.write_str("selected setup service count exceeds storage"),\n','')
curve=replace(curve,rust_item(curve,'pub(crate) struct SelectedBtwxtManager'),'''pub(crate) struct SelectedBtwxtManager {
    table_files:BTreeMap<std::path::PathBuf,()>,
}''')
curve=replace(curve,rust_item(curve,'pub(crate) struct SelectedCurves'),'''pub(crate) struct SelectedCurves {
    btwxt:SelectedBtwxtManager,
    pressure_curves:Option<Vec<()>>,
}''')
curve=replace(curve,rust_item(curve,'impl Default for SelectedCurves'),'''impl Default for SelectedCurves {
    fn default()->Self { Self { btwxt:SelectedBtwxtManager::default(),pressure_curves:None } }
}''')
# No Curve arithmetic/getter body changed; only unconsumed types/method removed.
proposal(curve_path,curve,curve_base)

canonical('crates/ep_runtime/src/heat_balance/radiation/ordinary.rs',lambda s:replace(s,'impl OrdinaryRadiationInput {','''impl OrdinaryRadiationInput {
    /// Actual GetProjectData/environment flag, applied before the first Solar owner.
    pub(crate) fn apply_source_advanced_reporting(&mut self,value:bool) {
        self.advanced_report_variables=value;
    }
'''))
canonical('crates/ep_runtime/src/heat_balance/state.rs',lambda s:replace(s,'/// Input-only selected GetProjectData facts for the explicit ordinary A caller.','/// Selected GetProjectData facts; the actual startup replaces effective report controls.'))

def psy(s):
    s=replace(s,'impl EnergyPlusPsychrometricsState {\n','''impl EnergyPlusPsychrometricsState {
    /// InitializePsychRoutines fills the four cache arrays without resetting scalars.
    /// Empty sparse storage denotes every exact default slot, including Psat -1000.
    pub(crate) fn initialize_source_caches(&mut self) {
        for slots in &mut self.slots { slots.clear(); }
    }

''')
    return s
canonical('crates/ep_runtime/src/psychrometrics/psy02_state.rs',psy)
canonical('crates/ep_runtime/src/psychrometrics.rs',lambda s:replace(s,'/// Synchronizes the weather caller control without replacing the cache owner.','''/// The genuine default-build InitializePsychRoutines cache-only operation.
pub(crate) fn initialize_source_psychrometric_caches() {
    psy02_state::with_state(EnergyPlusPsychrometricsState::initialize_source_caches);
}

/// Synchronizes the weather caller control without replacing the cache owner.'''))
canonical('crates/ep_runtime/src/psychrometrics/psy02_state/tests.rs',lambda s:replace(s,'''    assert_eq!(
        state.final_caches(),
        EnergyPlusPsychrometricFinalCaches::default()
    );
}''','''    assert_eq!(
        state.final_caches(),
        EnergyPlusPsychrometricFinalCaches::default()
    );
    // Reached InitializePsychRoutines must reset arrays, not constructor-reset
    // scalar saved pressures/controls that real property routes already changed.
    state.evaluate(EnergyPlusPsychrometricFunction::Twb,&[30.0,0.008,101325.0]).unwrap();
    state.evaluate(EnergyPlusPsychrometricFunction::TsatHPb,&[50000.0,101325.0]).unwrap();
    state.set_controls(Some(true),Some(0.0002));
    let retained_scalars=state.snapshot();
    let populated=state.final_caches();
    assert!(!populated.twb.is_empty() && !populated.psat.is_empty());
    assert!(!populated.tsat_pb.is_empty() && !populated.tsat_h_pb.is_empty());
    state.initialize_source_caches();
    assert_eq!(state.snapshot(),retained_scalars);
    assert_eq!(state.final_caches(),EnergyPlusPsychrometricFinalCaches::default());
    assert!(matches!(default_slot(1,17),EnergyPlusPsychrometricCacheSlot::Psat { i_tdb:-1000,value,.. } if value.to_bits()==0));
    assert!(matches!(default_slot(2,17),EnergyPlusPsychrometricCacheSlot::TsatPb { i_h:0,i_pb:0,value,.. } if value.to_bits()==0));
}'''))

# Schedule audit behavior is exact02; only its independent trait location and
# permanent raw identities/actual unused erasures are added here.
path='crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs'
base=selected('ordinary-audit-file-host-prep-02',path);s=read(base)
s=replace(s,'use super::setup_file_host::ScheduleAuditFileHost;','use super::source_initialization::ScheduleAuditFileHost;')
s=s.replace('    /// Getter uppercase name.\n    pub name: String,','    /// Exact original object-map identity used by InputProcessor unused tracking.\n    pub object_name: String,\n    /// Getter uppercase name.\n    pub name: String,',1)
s=replace(s,'    /// Getter uppercase name, separate from built-in schedule names/indices.','    /// Exact original object-map identity used by InputProcessor unused tracking.\n    pub object_name: String,\n    /// Getter uppercase name, separate from built-in schedule names/indices.')
s=replace(s,'        let locals = (vec![String::new(); max_alphas]','        let mut locals = (vec![String::new(); max_alphas]')
s=replace(s,'        let audit_path = audit_files.audit_path().to_path_buf();','''        for (family,names) in [
            ("ScheduleTypeLimits",declarations.types.iter().map(|row|row.object_name.as_str()).collect::<Vec<_>>()),
            ("Schedule:Constant",declarations.constants.iter().map(|row|row.object_name.as_str()).collect::<Vec<_>>()),
        ] {
            for (index,name) in names.iter().enumerate() {
                if !input.has_object(family,name) || names[..index].contains(name) {
                    return Err(SelectedScheduleError::Unavailable("raw object identity association"));
                }
            }
        }
        let audit_path = audit_files.audit_path().to_path_buf();''')
reset='''            // getObjectItem resets all six getter-local arrays before unused erase.
            locals.0.fill(String::new()); locals.1.fill(String::new());
            locals.2.fill(String::new()); locals.3.fill(0.0);
            locals.4.fill(true); locals.5.fill(true);
'''
s=replace(s,'        for row in &declarations.types {\n','        for row in &declarations.types {\n'+reset+'            input.mark_object_as_used("ScheduleTypeLimits",&row.object_name);\n')
s=replace(s,'        for row in &declarations.constants {\n','        for row in &declarations.constants {\n'+reset+'            input.mark_object_as_used("Schedule:Constant",&row.object_name);\n')
proposal(path,s,base)
path='crates/ep_run/src/ordinary_schedule_input.rs';base=selected('ordinary-schedule-manager-prep-02',path);s=read(base)
s=replace(s,'    super::ordinary_equipment_input::resolve(raw)?;\n','    // Caller already passed the same raw model through the sole ordinary admission.\n')
s=replace(s,'            name: name.0.to_ascii_uppercase(), lower:','            object_name: name.0.clone(), name: name.0.to_ascii_uppercase(), lower:')
s=replace(s,'            name: name.0.to_ascii_uppercase(), type_name:','            object_name: name.0.clone(), name: name.0.to_ascii_uppercase(), type_name:')
proposal(path,s,base)

# Narrow merge of only Project's genuine new weather fields on current Source;
# held InitHB's unrelated environmental arrays are not falsely activated.
def context_weather(s):
    s=replace(s,'    /// Source reporting switch.\n    pub do_output_reporting: bool,','    /// Source reporting switch.\n    pub do_output_reporting: bool,') if False else s
    # Current context already has the three run flags from the DD unit.
    assert 'pub do_des_day_sim: bool' in s and 'pub do_output_reporting: bool' in s
    assert 'force_begin_env_reset_suppress' not in s
    s=replace(s,'pub struct WeatherEnvironmentState {','pub struct WeatherEnvironmentState {\n    /// Actual DataEnvironment constructor false; GetProjectData may override it.\n    pub force_begin_env_reset_suppress: bool,')
    s=replace(s,'impl Default for WeatherEnvironmentState {\n    fn default() -> Self {\n        Self {','impl Default for WeatherEnvironmentState {\n    fn default() -> Self {\n        Self {\n            force_begin_env_reset_suppress: false,')
    return s
canonical('crates/ep_runtime/src/weather_day/context.rs',context_weather)
canonical('crates/ep_runtime/src/weather_day/tests.rs',lambda s:replace(s,'        environment: WeatherEnvironmentState {\n','        environment: WeatherEnvironmentState {\n            force_begin_env_reset_suppress: true,\n'))

def lifecycle(s):
    a='''        let mut cursor = RawEpwCursorOwner::open_from_bytes('''
    b='''        let mut state=WeatherDayState::default();
        Self::new_from_state(bytes,configuration,&mut state,false)
    }

    pub(super) fn new_from_project_state(bytes:Vec<u8>,configuration:WeatherEnvironmentConfiguration,
        state:&mut WeatherDayState)->Result<Self,WeatherDayError> {
        Self::new_from_state(bytes,configuration,state,true)
    }

    fn new_from_state(bytes:Vec<u8>,configuration:WeatherEnvironmentConfiguration,
        state:&mut WeatherDayState,preserve_project:bool)->Result<Self,WeatherDayError> {
        if preserve_project && state.global.time_steps_in_hour != configuration.steps() as i32 {
            return Err(WeatherDayError::admission("Project/weather timestep association"));
        }
        let mut cursor = RawEpwCursorOwner::open_from_bytes('''
    s=replace(s,a,b)
    s=replace(s,'''        let mut state = WeatherDayState::default();
        configuration
            .solar_controls
            .apply_to(&mut state.environment);''','''        if !preserve_project {
            configuration.solar_controls.apply_to(&mut state.environment);
        }''')
    s=replace(s,'''        state.global.time_steps_in_hour = configuration.steps() as i32;
        state.global.time_step_zone = 1.0 / f64::from(configuration.steps());
        state.global.time_step_zone_sec = state.global.time_step_zone * 3600.0;
        state.global.minutes_in_time_step = 60 / configuration.steps() as i32;''','''        if !preserve_project {
            state.global.time_steps_in_hour = configuration.steps() as i32;
            state.global.time_step_zone = 1.0 / f64::from(configuration.steps());
            state.global.time_step_zone_sec = state.global.time_step_zone * 3600.0;
            state.global.minutes_in_time_step = 60 / configuration.steps() as i32;
        }''')
    s=replace(s,'        state.global.do_weath_sim = true;','        if !preserve_project { state.global.do_weath_sim = true; }')
    s=replace(s,'        Ok(Self {\n            state,','        Ok(Self {\n            state:std::mem::take(state),')
    return s
canonical('crates/ep_runtime/src/weather_day/lifecycle.rs',lifecycle)
def production(s):
    s=replace(s,'        Ok(Self {\n            session: RefCell::new(WeatherSession::new(bytes, configuration)?),','''        Ok(Self::from_session(WeatherSession::new(bytes,configuration)?))
    }

    /// Consume the actual Project-initialized owner only after successful allocation.
    ///
    /// # Errors
    /// Retains partial preparation in the supplied owner on failure.
    pub fn from_initialized_project_state(bytes:Vec<u8>,configuration:WeatherEnvironmentConfiguration,
        state:&mut super::WeatherDayState)->Result<Self,WeatherDayError> {
        Ok(Self::from_session(WeatherSession::new_from_project_state(bytes,configuration,state)?))
    }

    fn from_session(session:WeatherSession)->Self {
        Self {
            session:RefCell::new(session),''')
    s=replace(s,'            current_step_stamp: RefCell::new(None),\n        })','            current_step_stamp: RefCell::new(None),\n        }')
    return s
canonical('crates/ep_runtime/src/weather_day/production.rs',production)
canonical('crates/ep_runtime/src/time_axis.rs',lambda s:replace(s,'fn time_axis_timestep_profile_for_zone_timesteps(', 'pub(crate) fn time_axis_timestep_profile_for_zone_timesteps('))
canonical('crates/ep_runtime/src/runtime.rs',lambda s:replace(s,'''    let zone_steps_per_hour = model.typed.timestep.number_of_timesteps_per_hour.max(1);
    let seconds_per_timestep''','''    let zone_steps_per_hour = match weather_driver {
        Some(HeatBalanceWeatherDriver::Production(weather))=>weather.zone_steps_per_hour(),
        _=>model.typed.timestep.number_of_timesteps_per_hour.max(1),
    };
    let seconds_per_timestep'''))

def context(s):
    pos='    /// Full allocated predefined string-entry owner.'
    fields='''    /// Actual parent guards, set before each member sequence.
    pub source_initialization_guards: super::source_initialization::SourceInitializationGuards,
    /// Real raw operands retained even if initialization stops.
    pub source_initialization_input: Option<super::source_initialization::SourceInitializationInput>,
    /// Sole pre-weather owner, moved into the real session after successful allocation.
    pub(crate) source_initialization_weather: Option<crate::weather::day::WeatherDayState>,
    /// Actual StdOutputRecordCount reset at OpenOutputFiles1747.
    pub source_standard_output_record_count: i32,
    /// Same DataGlobal owner later moved into the first genuine HeatBalanceState.
    pub(crate) selected_heat_balance_globals: Option<super::selected_heat_balance_globals::SelectedHeatBalanceGlobals>,
    /// Sole startup/HVAC/RuntimeLanguage owner.
    pub(crate) selected_simulation_startup: Option<super::selected_simulation_startup::SelectedSimulationStartup>,
    /// Sole retained GetProjectData owner.
    pub(crate) selected_project_data: Option<super::selected_project_data::SelectedProjectData>,
    /// Sole Fluid constructor/constant/input owner.
    pub(crate) selected_fluid_properties: Option<super::selected_fluid_properties::SelectedFluidProperties>,
    /// Sole real built-in and selected constant schedules.
    pub(crate) selected_schedule_manager: Option<super::selected_schedule_manager::SelectedScheduleManager>,
    /// Sole selected CurveManager retained collections.
    pub(crate) selected_curves: Option<super::setup_postludes::SelectedCurves>,
    /// Distinct HeatBalanceManager getter module carrier, not dataIPShortCut.
    pub(crate) heat_balance_current_module_object: String,
'''
    return replace(s,pos,fields+pos)
canonical('crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs',context)
def mods(s):
    s=replace(s,'pub mod selected_input_processor;','''pub mod selected_input_processor;
pub(crate) mod selected_fluid_properties;
pub(crate) mod selected_heat_balance_globals;
pub mod selected_project_data;
pub mod selected_schedule_manager;
pub(crate) mod selected_simulation_startup;
pub(crate) mod setup_postludes;
pub mod source_initialization;''')
    return s
canonical('crates/ep_runtime/src/heat_balance/mod.rs',mods)

def outputs(s):
    s=replace(s,'use std::path::Path;','''use std::path::Path;
use ep_runtime::heat_balance::source_initialization::{
    SourceInitializationFiles,SourceInitializationFilePaths,SourceInitializationInput,
};''')
    s=replace(s,'    reached: bool,','    reached: bool,\n    initialization_files: Option<SourceInitializationFiles>,')
    s=replace(s,'            reached: false,','            reached: false,\n            initialization_files: None,')
    s=replace(s,"    pub(crate) fn context(&mut self) -> CtfInitializationContext<'_> {",'''    pub(crate) fn prepare_source_environment(&mut self,output_dir:&Path,input:SourceInitializationInput)->Result<(),String> {
        self.reached=true;
        let first_entry=self.initialization_files.is_none();
        if first_entry {
        self.reports.source_initialization_input=Some(input);
        self.initialization_files=Some(SourceInitializationFiles::new(SourceInitializationFilePaths {
            eso:output_dir.join("eplusrs.eso"),eio:output_dir.join("eplusrs.eio"),
            mtr:output_dir.join("eplusrs.mtr"),bnd:output_dir.join("eplusrs.bnd"),
            audit:output_dir.join("eplusrs.audit"),
        }));
        }
        let mut backend=SourceErrorBackend { state:&mut self.state,error_stream:Some(&mut self.error),
            console:&mut self.console,out_unit1:None,out_unit2:None,f_message:None,
            message_callback:None,error_callback:None,sqlite:None };
        if first_entry { self.reports.prepare_source_environment(&mut backend).map_err(|e|e.to_string())?; }
        Ok(())
    }

    pub(crate) fn initialize_source_state(&mut self,report_inputs:&ep_model::ReportInputs)->Result<(),String> {
        let mut backend=SourceErrorBackend { state:&mut self.state,error_stream:Some(&mut self.error),
            console:&mut self.console,out_unit1:None,out_unit2:None,f_message:None,
            message_callback:None,error_callback:None,sqlite:None };
        let files=self.initialization_files.as_mut().ok_or("actual initialization files missing")?;
        self.reports.initialize_source_state(files,report_inputs,&mut backend).map_err(|e|e.to_string())
    }

    pub(crate) fn source_zone_timesteps_per_hour(&self)->Result<u32,String> {
        self.reports.source_zone_timesteps_per_hour().map_err(|e|e.to_string())
    }

    pub(crate) fn apply_source_reporting_controls(&self,reporting:&mut ep_runtime::HeatBalanceOrdinaryWarmupReportInputs)->Result<(),String> {
        self.reports.apply_source_reporting_controls(reporting).map_err(|e|e.to_string())
    }

    pub(crate) fn initialize_source_weather(&mut self,bytes:Vec<u8>,configuration:ep_runtime::weather::day::WeatherEnvironmentConfiguration)
        ->Result<ep_runtime::weather::day::ProductionWeatherTimestepSeries,String> {
        self.reports.initialize_source_weather(bytes,configuration).map_err(|e|e.to_string())
    }

    pub(crate) fn context(&mut self) -> CtfInitializationContext<'_> {''')
    s=replace(s,'            eio: &mut self.eio,','''            eio:match self.initialization_files.as_mut() {
                Some(files)=>files.eio_writer().unwrap_or(&mut self.eio),
                None=>&mut self.eio,
            },''')
    # No successful fallback: context is requested after successful guard return;
    # the method must still expose a fallible capability rather than unwrap fallback.
    s=replace(s,'Some(files)=>files.eio_writer().unwrap_or(&mut self.eio),','Some(files)=>files.eio_stream(),')
    s=replace(s,'    pub(crate) fn persist(&self, output_dir: &Path)', '    pub(crate) fn persist(&mut self, output_dir: &Path)')
    # Existing run-persistence boundary only: no Source OpenOutputFiles flush is added.
    s=replace(s,'        Ok(())\n    }\n}\n\n/// Preserve the reached Source prefix','''        if let Some(files)=self.initialization_files.as_mut() {
            files.flush_reached().map_err(|e|e.to_string())?;
        }
        Ok(())
    }
}

/// Preserve the reached Source prefix''')
    s=replace(s,'            std::fs::write(output_dir.join(name), bytes)','''            if name=="eplusrs.eio" && self.initialization_files.is_some() { continue; }
            std::fs::write(output_dir.join(name), bytes)''')
    # Extend the existing real-output failure body; no new test or fake sink.
    marker='''        std::fs::remove_dir(dir)?;
        Ok(())'''
    s=replace(s,marker,'''        std::fs::remove_dir(&dir)?;
        let raw=ep_raw_model::parse_epjson_str(r#"{
            "Version":{"v":{"version_identifier":"26.1"}},
            "Building":{"b":{"solar_distribution":"MinimalShadowing"}},
            "Timestep":{"t":{}},"Zone":{"z":{}},
            "Output:Diagnostics":{"d":{"diagnostics":[{"key":"DisplayAdvancedReportVariables"}]}}
        }"#)?;
        let make_input=||->Result<_,String> {
            let input=crate::ordinary_input_processor::resolve(&raw)?;
            let operands=SourceInitializationInput {
                project:crate::ordinary_project_data::resolve(&raw,raw.is_epjson(),&input)?,
                schedules:crate::ordinary_schedule_input::resolve(&raw)?,
                ..SourceInitializationInput::default()
            };
            Ok((input,operands))
        };
        std::fs::create_dir(&dir)?;
        std::fs::create_dir(dir.join("eplusrs.mtr"))?;
        let mut failure=CtfRunOutputs::new("26.1");
        let (input,operands)=make_input()?;
        failure.reports.initialize_input_processor(input)?;
        failure.prepare_source_environment(&dir,operands)?;
        let error=failure.initialize_source_state(&ep_model::ReportInputs::default()).err().ok_or("actual MTR open did not fail")?;
        assert!(error.contains("eplusrs.mtr"));
        assert!(failure.reports.source_initialization_guards.init_constant_state_called);
        assert!(failure.reports.source_initialization_guards.init_state_called);
        assert!(failure.reports.selected_input_processor.as_ref().ok_or("moved IP missing")?.is_object_unused("Version","v"));
        let version_line=format!("Program Version,{}\\n",failure.state.version_string).into_bytes();
        assert_eq!(std::fs::read(dir.join("eplusrs.eso"))?,version_line);
        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?,version_line);
        assert!(!dir.join("eplusrs.bnd").exists());
        assert!(!dir.join("eplusrs.audit").exists());
        // Both actual guards remain true after fatal. Reentry neither retries
        // the failed file nor truncates already reached output/header prefixes.
        failure.initialize_source_state(&ep_model::ReportInputs::default())?;
        assert!(failure.source_zone_timesteps_per_hour().is_err());
        failure.persist(&dir)?;
        assert!(String::from_utf8(std::fs::read(dir.join("eplusrs.ctf.err"))?)?.contains("OpenOutputFiles: Could not open file"));
        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?,version_line);
        drop(failure);
        for name in ["eplusrs.eso","eplusrs.eio","eplusrs.ctf.err","eplusrs.ctf.log"] {
            std::fs::remove_file(dir.join(name))?;
        }
        std::fs::remove_dir(dir.join("eplusrs.mtr"))?;
        let mut success=CtfRunOutputs::new("26.1");
        let (input,operands)=make_input()?;
        success.reports.initialize_input_processor(input)?;
        success.prepare_source_environment(&dir,operands)?;
        success.initialize_source_state(&ep_model::ReportInputs::default())?;
        let steps=success.source_zone_timesteps_per_hour()?;
        assert!(matches!(steps,2|6)); // Source schema6, or real CI_FORCE_TIME_STEP2.
        let ip=success.reports.selected_input_processor.as_ref().ok_or("sole IP missing")?;
        assert!(!ip.is_object_unused("Version","v"));
        assert!(!ip.is_object_unused("Timestep","t"));
        assert!(!ip.is_object_unused("Output:Diagnostics","d"));
        assert!(ip.is_object_unused("Building","b"),"later HB getter must not be fabricated");
        let mut reporting=crate::warmup_report_controls::resolve(&raw)?;
        reporting.advanced_report_variables=false;
        success.apply_source_reporting_controls(&mut reporting)?;
        assert!(reporting.advanced_report_variables,"effective actual diagnostic owner reaches HB");
        success.persist(&dir)?;
        let actual_eio=std::fs::read(dir.join("eplusrs.eio"))?;
        let eio=String::from_utf8(actual_eio.clone())?;
        for section in ["! <Version>","! <Timesteps per Hour>","! <System Convergence Limits>","! <Simulation Control>","! <Performance Precision Tradeoffs>","! <Output Reporting Tolerances>"] {
            assert!(eio.contains(section),"actual Project EIO section {section}");
        }
        assert_eq!(std::fs::read(dir.join("eplusrs.audit"))?,b"  Processing Schedule Input -- Start\\n  Processing Schedule Input -- Complete\\n");
        success.initialize_source_state(&ep_model::ReportInputs::default())?;
        success.persist(&dir)?;
        assert_eq!(std::fs::read(dir.join("eplusrs.eio"))?,actual_eio);
        drop(success);
        for name in ["eplusrs.eso","eplusrs.eio","eplusrs.mtr","eplusrs.bnd","eplusrs.audit","eplusrs.ctf.err","eplusrs.ctf.log"] {
            std::fs::remove_file(dir.join(name))?;
        }
        std::fs::remove_dir(dir)?;
        Ok(())''')
    return s
canonical('crates/ep_run/src/ctf_initialization_outputs.rs',outputs)

def pipeline(s):
    s=replace(s,'struct PreparedRuntimeInputs {','''struct PendingOrdinaryWeather {
    bytes:Vec<u8>,
    configuration:WeatherEnvironmentConfiguration,
}

struct PreparedRuntimeInputs {''')
    s=replace(s,'    weather_series: Option<ProductionWeatherTimestepSeries>,','''    weather_series: Option<ProductionWeatherTimestepSeries>,
    pending_ordinary_weather:Option<PendingOrdinaryWeather>,
    source_initialization_input:Option<ep_runtime::heat_balance::source_initialization::SourceInitializationInput>,''')
    s=replace(s,'    schedule_cache: ScheduleSeriesCache,','    schedule_cache: Option<ScheduleSeriesCache>,')
    s=replace(s,'    let (time_axis, weather_series, zone_timestep_schedule_cache) =','    let mut pending_ordinary_weather=None;\n    let (time_axis, weather_series, zone_timestep_schedule_cache) =')
    s=replace(s,'''            let weather_series = ProductionWeatherTimestepSeries::from_bytes(
                std::fs::read(weather_path).map_err(|error| error.to_string())?,
                configuration,
            )
            .map_err(|error| format!("failed to open live EPW owner: {error}"))?;''','''            let bytes=std::fs::read(weather_path).map_err(|error|error.to_string())?;
            let weather_series=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {
                pending_ordinary_weather=Some(PendingOrdinaryWeather { bytes,configuration });
                None
            } else {
                Some(ProductionWeatherTimestepSeries::from_bytes(bytes,configuration)
                    .map_err(|error|format!("failed to open live EPW owner: {error}"))?)
            };''')
    s=replace(s,'                Some(weather_series),','                weather_series,')
    s=replace(s,'''    let schedule_cache = precompute_schedule_cache_for_time_axis(&model.typed, &time_axis);
    ep_runtime::schedules::production_trace::record_cache(
        ep_runtime::schedules::production_trace::ScheduleCacheOrigin::PipelineHourlyPrepared,
        &schedule_cache,
    );
    ep_runtime::psychrometrics::production_trace::register_time_axis(&time_axis);''','''    let schedule_cache=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {
        // No disposable cache or trace is produced from the pre-Project timestep.
        None
    } else {
        let cache=precompute_schedule_cache_for_time_axis(&model.typed,&time_axis);
        ep_runtime::schedules::production_trace::record_cache(
            ep_runtime::schedules::production_trace::ScheduleCacheOrigin::PipelineHourlyPrepared,&cache);
        ep_runtime::psychrometrics::production_trace::register_time_axis(&time_axis);
        Some(cache)
    };''')
    s=replace(s,'    Ok(PreparedRuntimeInputs {\n        sample_count,','''    let source_initialization_input=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {
        // Pure raw projection only; actual counts/getters still use the moved IP.
        let input=crate::ordinary_input_processor::resolve(raw_model)?;
        Some(ep_runtime::heat_balance::source_initialization::SourceInitializationInput {
            project:crate::ordinary_project_data::resolve(raw_model,raw_model.is_epjson(),&input)?,
            schedules:crate::ordinary_schedule_input::resolve(raw_model)?,
            cli_dd_only:false,cli_annual:false,
            reverse_design_days:pending_ordinary_weather.as_ref().ok_or("missing actual pending weather")?.configuration.reverse_design_days,
        })
    } else { None };
    Ok(PreparedRuntimeInputs {
        pending_ordinary_weather,source_initialization_input,
        sample_count,''')
    # Root PostIP already passes the one actual IP projection. Avoid the temporary
    # second resolve above by reusing the same local owner below in a later finite pass.
    s=replace(s,'fn execute_rust_runtime(\n    simulation_model: Option<&SimulationModel>,','fn execute_rust_runtime(\n    simulation_model: Option<&mut SimulationModel>,')
    s=replace(s,'''                        execute_rust_runtime(
                            simulation_model.as_ref(),''','''                        execute_rust_runtime(
                            simulation_model.as_mut(),''')
    s=replace(s,'    capture_geometry: bool,\n    ctf_outputs: &mut CtfRunOutputs,','    capture_geometry: bool,\n    ctf_outputs: &mut CtfRunOutputs,\n    output_dir:&Path,')
    s=replace(s,'                            &mut ctf_outputs,\n                        )','                            &mut ctf_outputs,\n                            &config.output_dir,\n                        )')
    # Reorder actual owner movement/PostIP before accessing delayed weather.
    start=s.index('            let weather_series = runtime_inputs.weather_series.as_ref().ok_or_else(|| {',s.index('fn execute_rust_runtime('))
    end=s.index('            let simulation = if let Some(reporting)',start)
    old=s[start:end]
    init_start=old.index('            let mut initialization = ctf_outputs.context();')
    postip=old[init_start:]
    assert 'post_input_processing' in postip
    before='''            {
'''+postip+'''            }
            {
                ctf_outputs.initialize_source_state(&model.typed.report_inputs)?;
                let pending=runtime_inputs.pending_ordinary_weather.take().ok_or("missing delayed weather input")?;
                let steps=ctf_outputs.source_zone_timesteps_per_hour()?;
                model.typed.timestep.number_of_timesteps_per_hour=steps;
                let profile=ep_runtime::time_axis::time_axis_timestep_profile(&model.typed);
                runtime_inputs.time_axis.zone_timestep=profile.zone_timestep;
                runtime_inputs.time_axis.system_timestep=profile.system_timestep;
                if let Some(reporting)=runtime_inputs.ordinary_warmup_reporting.as_mut() {
                    ctf_outputs.apply_source_reporting_controls(reporting)?;
                }
                let weather=ctf_outputs.initialize_source_weather(pending.bytes,pending.configuration)?;
                let cache=precompute_schedule_cache_for_time_axis(&model.typed,&runtime_inputs.time_axis);
                ep_runtime::schedules::production_trace::record_cache(
                    ep_runtime::schedules::production_trace::ScheduleCacheOrigin::PipelineHourlyPrepared,&cache);
                ep_runtime::psychrometrics::production_trace::register_time_axis(&runtime_inputs.time_axis);
                runtime_inputs.schedule_cache=Some(cache);
                runtime_inputs.weather_series=Some(weather);
            }
            let weather_series=runtime_inputs.weather_series.as_ref().ok_or("missing actual weather series")?;
            let options=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {
                HeatBalanceSimulationOptions::hourly_samples_with_model_warmup(model,sample_count)
            } else { HeatBalanceSimulationOptions::hourly_samples(sample_count) };
            let mut initialization=ctf_outputs.context();
'''
    s=s[:start]+before+s[end:]
    # Use one IP projection for both actual retained ownership and raw association.
    a=s.index('    let source_initialization_input=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {',s.index('fn prepare_runtime_inputs('))
    s=s[:a]+s[a:].replace('''        let input=crate::ordinary_input_processor::resolve(raw_model)?;
        Some''','''        Some''',1)
    s=replace(s,'project:crate::ordinary_project_data::resolve(raw_model,raw_model.is_epjson(),&input)?,','project:crate::ordinary_project_data::resolve(raw_model,raw_model.is_epjson(),selected_input_processor.as_ref().ok_or("missing real IP projection")?)?,')
    marker='    let source_initialization_input=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {'
    s=replace(s,marker,'''    let selected_input_processor=if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {
        Some(crate::ordinary_input_processor::resolve(raw_model)?)
    } else { None };
'''+marker)
    a='''        selected_input_processor: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility
        {
            Some(crate::ordinary_input_processor::resolve(raw_model)?)
        } else {
            None
        },'''
    s=replace(s,a,'        selected_input_processor,')
    # Real ordinary initialization precedes all derived-cache metadata reads. Other
    # runtime classes keep their already prepared cache and old execution path.
    a=s.index('            {\n            let mut initialization = ctf_outputs.context();',s.index('fn execute_rust_runtime('))
    b=s.index('            let weather_series=runtime_inputs.weather_series.as_ref()',a)
    initialization='''            let input=runtime_inputs.source_initialization_input.take().ok_or("actual source initialization input missing")?;
            ctf_outputs.prepare_source_environment(output_dir,input)?;
'''+s[a:b]
    s=s[:a]+s[b:]
    s=replace(s,'''    let schedule_cache_sample_count = runtime_inputs.schedule_cache.sample_count();
    let schedule_cache_profile = runtime_inputs.schedule_cache.profile();''','''    if runtime_class==RuntimeClass::OneZoneHeatBalanceCompatibility {
'''+initialization+'''    }
    let cache=runtime_inputs.schedule_cache.as_ref().ok_or("actual runtime schedule cache missing")?;
    let schedule_cache_sample_count=cache.sample_count();
    let schedule_cache_profile=cache.profile();''')
    return s
canonical('crates/ep_run/src/pipeline.rs',pipeline)
canonical('crates/ep_run/src/lib.rs',lambda s:replace(s,'mod ordinary_input_processor;','mod ordinary_input_processor;\nmod ordinary_project_data;\nmod ordinary_schedule_input;'))

# Frozen exact dependencies are referenced, not recursively recopied.
deps=[]
for name in ['ordinary-simulation-startup-checks-prep-02','ordinary-project-data-prep-02','ordinary-fluid-properties-prep-01','ordinary-schedule-manager-prep-02','ordinary-audit-file-host-prep-02','ordinary-run-services-prep-01']:
    p=ROOT/'.runtime/porting/SRC-06'/name/'manifest.json';deps.append(ref(p))
dependency_files=[]
for name,paths in [
    ('ordinary-project-data-prep-02',[
        'crates/ep_runtime/src/heat_balance/selected_project_data.rs',
        'crates/ep_runtime/src/heat_balance/selected_project_data/input.rs',
        'crates/ep_runtime/src/heat_balance/selected_project_data/input/schema.rs',
        'crates/ep_runtime/src/heat_balance/selected_project_data/getter.rs',
        'crates/ep_runtime/src/heat_balance/selected_project_data/environment.rs',
        'crates/ep_runtime/src/heat_balance/selected_heat_balance_globals.rs',
        'crates/ep_run/src/ordinary_project_data.rs']),
    ('ordinary-fluid-properties-prep-01',[
        'crates/ep_runtime/src/heat_balance/selected_fluid_properties.rs',
        'crates/ep_runtime/src/heat_balance/selected_fluid_properties/owners.rs',
        'crates/ep_runtime/src/heat_balance/selected_fluid_properties/limits.rs',
        'crates/ep_runtime/src/heat_balance/selected_fluid_properties/glycol_data.rs',
        'crates/ep_runtime/src/heat_balance/selected_fluid_properties/water_steam_data.rs']),
]:
    for path in paths:
        dependency_files.append({'canonical_path':path,'payload':ref(selected(name,path)),
            'authority_manifest':ref(ROOT/'.runtime/porting/SRC-06'/name/'manifest.json'),
            'canonical_must_be_absent':not (ROOT/path).exists()})
assert len(rows)==22 and len(dependency_files)==12
all_paths=[r['canonical_path'] for r in rows+dependency_files]
assert len(all_paths)==len(set(all_paths))==34
for row in rows:
    row['canonical_present_at_review']=(ROOT/row['canonical_path']).exists()
    if row['canonical_present_at_review']:
        assert row['base_authority']==ref(ROOT/row['canonical_path'])
    original=read(ROOT/row['base']['path']) if row['base'] else ''
    proposed=read(ROOT/row['proposed']['path'])
    expected=''.join(difflib.unified_diff(original.splitlines(True),proposed.splitlines(True),fromfile='a/'+row['canonical_path'],tofile='b/'+row['canonical_path']))
    assert expected==read(ROOT/row['complete_diff']['path'])
assert rust_item(startup,'    pub(crate) fn check_if_any_ems(')==ems
curve_parent=read(curve_base)
for method in ['    fn get_curve_input(','    fn get_pressure_system_input(','    pub(crate) fn initialize_state(']:
    assert rust_item(curve,method)==rust_item(curve_parent,method)
test_delta=[]
for row in rows:
    before=read(ROOT/row['base']['path']) if row['base'] else ''
    after=read(ROOT/row['proposed']['path'])
    if '#[test]' in before or '#[test]' in after:
        assert before.count('#[test]')==after.count('#[test]')
        test_delta.append({'canonical_path':row['canonical_path'],'before':before.count('#[test]'),'after':after.count('#[test]')})
readme='''# HELD six-handler startup assembly

Source only against committed 7997dfe273a2e19ede3cc13c92dffd27de124665. Nothing applied, formatted, compiled, tested or run. This packet has exactly 22 authored proposals plus 12 unchanged authoritative dependency payloads (34 distinct paths). Apply only these rows; never copy historical context, metadata, pipeline or raw-format rows wholesale from a dependency packet.

The complete249-member Source closure permits omission only of literal-empty methods: constants Psych→Fluid→Schedule; input Simulation(OpenOutputFiles→GetProjectData)→EMS→emptyPsych→Fluid→Schedule→Curve. Each parent guard becomes true before dispatch and stays true after an error. Reentry returns before owner creation when both guards are true. Actual process environment is resolved once before the preserved PostIP call, using the current selected ReverseDD capture; this is not a certificate of every process-environment reader.

Actual Files are non-Clone read/write/create/truncate streams at caller-supplied output paths. OpenOutputFiles resets StdOutputRecordCount then opens/prints ESO→EIO→MTR→BND. Audit opens only at ProcessScheduleInput718. OS errors retain path/cause and reach the real fatal backend. No new Source flush is inserted: explicit flushing is only the existing Rust run-persistence/close boundary after the reached error/console prefix is written. Later HB reuses the exact already-open EIO, with no successful sink or buffered fallback.

The same retained constructor WeatherDayState receives actual GetProjectData writes before any live WeatherSession/Today/Tomorrow allocation. The effective timestep is written to the same mutable SimulationModel, then the actual time-axis profiles, weather session and derived schedule cache. Ordinary cache creation/trace happens once after this normalization; nonordinary paths preserve their earlier preparation. Successful session construction moves the state and clears its old Option; failures retain partial state. Effective detailed/advanced/doPure controls replace the existing raw reporting projection, including the same radiation input's private advanced flag. DeveloperFlag is joined to the existing backend carrier.

Startup activation is only the actually consumed EMS/HVAC slice; later construction bounds, time-pointer checks, sizing and Setup methods remain immutable HELD dependencies. Curve contains only its consumed input getters/storage; Cost/Fault/reporting remain held. The unchanged Fluid constructor includes its actual allocated cache, literal tables and explicit unknown Steam storage. Source schedule types/constants now retain exact raw identities, validate permanent association and reset locals→erase unused identity before consumed getter values. Other actual InputProcessor objects are not claimed consumed.

Existing ordinary admission remains unchanged: non-divisor timestep repair is available through the direct selected getter API but not newly admitted by the ordinary pipeline. CI_FORCE_TIME_STEP=2 and present-empty Timestep schema6 do reach effective handoff. Actual DDONLY/annual or DoWeathSim=false results stop explicitly before the current RunPeriod-only executor. Whole startup, downstream Setup, positive EMS/user-fluid/nonconstant/Curve branches, Native numerical parity and gates are not certified by this Source packet.

Two existing test bodies are expanded: Psych cache clearing retains actual saved scalar state/default tags; real output test forces MTR open failure, verifies ESO/EIO prefix + no unreached BND/Audit, retained guards and no retry/truncation, then actual six-handler EIO/Audit completion and effective reporting handoff. The existing full weather-state canary receives the added ForceBeginEnvResetSuppress field. No new test body, fixture, Native run or numerical expected value was introduced.

The before/diff archives are LF-normalized text; base_authority pins authentic raw bytes and records their real line endings. Do not claim raw inverse equality across normalization. Dependency payloads are copied byte-exact. Root must independently review/apply, run actual fmt/quality/Clippy/affected tests and preserve genuine failures in a successor if found.

Exact application rows:\n'''+''.join('- '+path+'\n' for path in all_paths)
readme_ref=save(OUT/'README.md',readme)
manifest={'schema':'src06-held-six-handler-assembly.v1','status':'HELD_SOURCE_ONLY_NOT_APPLIED_OR_COMPILED',
    'files':rows,'dependency_files':dependency_files,'dependencies':deps,'README':readme_ref,
    'base_text_encoding':'before/diffs LF normalized; base_authority authentic raw SHA/size',
    'existing_test_counts':test_delta,'new_test_bodies':0,
    'exact_retained_function_checks':['EMS check_if_any_ems whole literal function exact Project01','Curve get_curve_input/get_pressure_system_input/initialize_state whole literal functions exact Rootservices01'],
    'Source_guard_audit':ref(ROOT/'.runtime/porting/SRC-06/ordinary-init-guard-audit-Header-02/review.json'),
    'author':ref(Path(__file__)),'review_time_git_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'canonical_mutated':False,'Cargo_compiler_tests_Native_executed':False,'scientific_PASS':False,'full_Setup_completed':False,'gates_updated':False}
save(OUT/'manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':ref(OUT/'manifest.json'),'proposed_files':len(rows)}))

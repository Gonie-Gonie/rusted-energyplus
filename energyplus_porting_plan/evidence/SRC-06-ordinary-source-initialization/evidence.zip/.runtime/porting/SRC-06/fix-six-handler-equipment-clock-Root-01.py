"""Feed the actual Project-normalized clock into the existing equipment operand."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-six-handler-assembly-03'
assert not out.exists()
parent_path = base / 'ordinary-six-handler-assembly-02/manifest.json'
parent = json.loads(parent_path.read_bytes())
failed_path = base / 'ordinary-six-handler-ci-timestep-tests-01/receipt.json'
failed = json.loads(failed_path.read_bytes())
assert failed['exit_code'] == 1 and failed['source_bytes_match_before_and_after'] is True

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def replace(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new)

for row in parent['files']:
    assert ref(root / row['canonical']['path']) == row['canonical']
out.mkdir()
case = Path('C:/Users/GonieGonie/AppData/Local/Temp/rusted-energyplus-ep-run-one-zone-runtime-8676-1791817922247665400-0')
assert case.is_dir() and (case / 'out/diagnostics.json').is_file()
assert 'GeometryOrTimestep' in (case / 'out/diagnostics.json').read_text(encoding='utf8')
custody = out / 'failed-ci-case'
shutil.copytree(case, custody)
case_files = []
for path in sorted(case.rglob('*')):
    if path.is_file():
        copy = custody / path.relative_to(case)
        assert path.read_bytes() == copy.read_bytes()
        case_files.append({'historical_path': str(path), 'archive': ref(copy)})

name = 'crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'
equipment = root / name
before = equipment.read_bytes()
assert subprocess.check_output(['git', 'show', parent['base_head'] + ':' + name]) == before
text = before.decode()
text = replace(text, 'impl OrdinaryEquipmentInput {\n', '''impl OrdinaryEquipmentInput {
    /// GetZoneEquipment uses the effective DataGlobal clock after GetProjectData.
    /// This updates only that operand; the admitted family inventory is unchanged.
    pub(crate) fn apply_source_timestep(&mut self, steps: usize) -> Result<(), Unavailable> {
        if steps == 0 || steps > 60 || 60 % steps != 0 {
            return Err(Unavailable::GeometryOrTimestep);
        }
        self.timesteps_per_hour = steps;
        Ok(())
    }

''')
proposal = out / '36.equipment-proposed'
proposal.write_bytes(text.encode())
before_path = out / '36.before'
before_path.write_bytes(before)
equipment.write_bytes(text.encode())

initialization = root / 'crates/ep_runtime/src/heat_balance/source_initialization.rs'
text = initialization.read_text(encoding='utf8')
text = replace(text, '        reporting.detailed = project.system.report_detailed_warmup_convergence;', '''        if let Some(input) = reporting.equipment_input.as_mut() {
            let steps = usize::try_from(self.source_zone_timesteps_per_hour()?)
                .map_err(|_| SourceInitializationError::Association("equipment timestep representation"))?;
            input.apply_source_timestep(steps).map_err(|source| SourceInitializationError::Handler {
                handler: "geometry equipment timestep",
                source: Box::new(source),
            })?;
        }
        reporting.detailed = project.system.report_detailed_warmup_convergence;''')
initialization.write_bytes(text.encode())

first = base / 'ordinary-six-handler-assembly-01'
applied = json.loads((first / 'apply.json').read_bytes())
applied['before_refs'] = [row['before'] for row in parent['files']] + [ref(before_path)]
applied['paths'].append(name)
applied['activated_proposals'].append(ref(proposal))
applied['parent_apply'] = ref(first / 'apply.json')
applied['equipment_clock_fix'] = {
    'failed_QA': ref(failed_path), 'failed_case': case_files,
    'author': ref(Path(__file__)),
    'scope': 'Only the effective timestep operand changes after actual Project initialization; family inventory, raw admission and numerical equations remain unchanged.',
    'Original': 'ZoneEquipmentManager.cc185 consumes actual DataGlobal TimeStepsInHour*24, not the raw Timestep field.',
}
path = out / 'apply.json'
path.write_bytes((json.dumps(applied, indent=2) + '\n').encode())
print(json.dumps({'apply': ref(path), 'paths': len(applied['paths']), 'failed_case_files': len(case_files)}))

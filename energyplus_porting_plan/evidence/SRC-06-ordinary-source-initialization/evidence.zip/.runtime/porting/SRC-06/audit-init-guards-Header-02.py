"""Source-only index of complete EnergyPlusData initialization guards and actual methods."""
from pathlib import Path
import bisect
import collections
import hashlib
import json
import re
import subprocess

ROOT = Path.cwd()
REFERENCE = ROOT / '.reference/energyplus-src/26.1.0'
SOURCE = REFERENCE / 'src/EnergyPlus'
OUT = ROOT / '.runtime/porting/SRC-06/ordinary-init-guard-audit-Header-02'
COMMIT = '6f2e40d10250a105b49966baa24d843711e61048'

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def mask(text):
    # Preserve offsets/newlines while excluding C++ comments, ordinary/raw literals.
    expression = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|(?:u8|u|U|L)?R"(?P<delim>[^ ()\\\t\r\n]{0,16})\([\s\S]*?\)(?P=delim)"|(?:u8|u|U|L)?"(?:\\[\s\S]|[^"\\])*"|(?:u8|u|U|L)?\x27(?:\\[\s\S]|[^\x27\\])*\x27')
    return expression.sub(lambda match: ''.join('\n' if char == '\n' else ' ' for char in match.group()), text)

def end_pair(text, start, opening='{', closing='}'):
    assert text[start] == opening
    depth = 0
    for offset in range(start, len(text)):
        if text[offset] == opening: depth += 1
        elif text[offset] == closing:
            depth -= 1
            if depth == 0: return offset
    raise ValueError(('unclosed Source delimiter', start))

cache = {}
def load(path):
    if path not in cache:
        raw = path.read_bytes()
        text = raw.decode('utf-8-sig')
        cache[path] = {'raw': raw, 'text': text, 'masked': mask(text), 'starts': [0] + [match.end() for match in re.finditer('\n', text)]}
    return cache[path]

def location(path, start, end):
    data = load(path)
    return {'Original_file': path.relative_to(ROOT).as_posix(), 'first_line': bisect.bisect_right(data['starts'], start), 'last_line': bisect.bisect_right(data['starts'], end)}

def literal(row, prefix):
    path = ROOT / row['Original_file']
    raw = path.read_bytes()
    selected = b''.join(raw.splitlines(keepends=True)[row['first_line'] - 1:row['last_line']])
    target = OUT / 'Original' / (prefix + '-' + path.name + '-' + str(row['first_line']) + '-' + str(row['last_line']) + '.txt')
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_bytes(selected)
    return {**row, 'literal': ref(target)}

state_cc = SOURCE / 'Data/EnergyPlusData.cc'
state_hh = SOURCE / 'Data/EnergyPlusData.hh'
cc, hh = load(state_cc), load(state_hh)
members = {}
for match in re.finditer(r'std::unique_ptr\s*<\s*([\w:]+)\s*>\s+(\w+)\s*;', hh['masked']):
    members[match[2]] = {'cpp_type': match[1], 'declaration': location(state_hh, match.start(), match.end() - 1)}

lists = {}
for phase in ('init_constant_state', 'init_state'):
    signature = re.search(r'void\s+EnergyPlusData::' + phase + r'\s*\([^)]*\)\s*\{', cc['masked'])
    start = cc['masked'].find('{', signature.start())
    end = end_pair(cc['masked'], start)
    body = cc['masked'][start:end + 1]
    rows = []
    for ordinal, call in enumerate(re.finditer(r'this->(\w+)->' + phase + r'\s*\(\s*state\s*\)\s*;', body), 1):
        member = call[1]
        rows.append({'ordinal': ordinal, 'member': member, **members.get(member, {'cpp_type': None, 'declaration': None}), 'call': location(state_cc, start + call.start(), start + call.end() - 1)})
    lists[phase] = {'guard_function': location(state_cc, signature.start(), end), 'calls': rows}

types = {row['cpp_type'].split('::')[-1] for group in lists.values() for row in group['calls'] if row['cpp_type']}
class_candidates = collections.defaultdict(list)
out_of_line = collections.defaultdict(list)
source_paths = sorted(SOURCE.rglob('*.hh')) + sorted(SOURCE.rglob('*.cc')) + sorted(SOURCE.rglob('*.hpp')) + sorted(SOURCE.rglob('*.cpp'))
for path in source_paths:
    data = load(path)
    text = data['masked']
    if path.suffix in ('.hh', '.hpp'):
        for match in re.finditer(r'\b(?:struct|class)\s+(\w+)\s*(?:final\s*)?(?::[^;{}]+)?\{', text):
            if match[1] not in types or 'BaseGlobalStruct' not in match[0]: continue
            opening = text.find('{', match.start())
            closing = end_pair(text, opening)
            methods = {}
            for method in re.finditer(r'\bvoid\s+(init_constant_state|init_state)\s*\(', text[opening + 1:closing]):
                absolute = opening + 1 + method.start()
                prefix = text[opening + 1:absolute]
                if prefix.count('{') != prefix.count('}'): continue
                paren = text.find('(', absolute)
                paren_end = end_pair(text, paren, '(', ')')
                suffix = re.search(r'[;{]', text[paren_end + 1:closing])
                if suffix is None: continue
                delimiter = paren_end + 1 + suffix.start()
                if text[delimiter] == '{':
                    finish = end_pair(text, delimiter)
                    methods[method[1]] = {'kind': 'inline', 'range': location(path, absolute, finish), 'empty_literal_body': not text[delimiter + 1:finish].strip(), 'body': data['text'][delimiter + 1:finish]}
                else:
                    methods[method[1]] = {'kind': 'out-of-line-declaration', 'range': location(path, absolute, delimiter)}
            class_candidates[match[1]].append({'class_range': location(path, match.start(), closing), 'methods': methods})
    if 'init_' in text:
        for match in re.finditer(r'\bvoid\s+([\w:]+)::(init_constant_state|init_state)\s*\(', text):
            bare = match[1].split('::')[-1]
            if bare not in types: continue
            paren = text.find('(', match.start())
            paren_end = end_pair(text, paren, '(', ')')
            suffix = re.search(r'[;{]', text[paren_end + 1:])
            if suffix is None: continue
            opening = paren_end + 1 + suffix.start()
            if text[opening] != '{': continue
            finish = end_pair(text, opening)
            out_of_line[(bare, match[2])].append({'kind': 'out-of-line-definition', 'range': location(path, match.start(), finish), 'empty_literal_body': not text[opening + 1:finish].strip(), 'body': data['text'][opening + 1:finish]})

resolved = {}
for phase, group in lists.items():
    for row in group['calls']:
        key = (row['cpp_type'], phase)
        if key not in resolved:
            bare = row['cpp_type'].split('::')[-1] if row['cpp_type'] else None
            candidates = class_candidates.get(bare, [])
            if len(candidates) != 1:
                result = {'resolution': 'unresolved', 'reason': 'class missing or ambiguous', 'class_candidates': candidates}
            else:
                candidate = candidates[0]
                method = candidate['methods'].get(phase)
                if method is None:
                    result = {'resolution': 'unresolved', 'reason': 'no direct method; inherited resolution required', 'class_range': candidate['class_range']}
                elif method['kind'] == 'out-of-line-declaration':
                    definitions = out_of_line.get((bare, phase), [])
                    if len(definitions) != 1:
                        result = {'resolution': 'unresolved', 'reason': 'out-of-line definition missing or ambiguous', 'class_range': candidate['class_range'], 'declaration': method, 'definition_candidates': definitions}
                    else:
                        result = {'resolution': 'resolved', 'class_range': candidate['class_range'], 'declaration': method['range'], **definitions[0]}
                else:
                    result = {'resolution': 'resolved', 'class_range': candidate['class_range'], **method}
            resolved[key] = result
        row['method'] = resolved[key]

assert not OUT.exists()
OUT.mkdir()
for phase, group in lists.items():
    group['guard_function'] = literal(group['guard_function'], phase + '-guard')
    for row in group['calls']:
        row['declaration'] = literal(row['declaration'], phase + '-' + str(row['ordinal']).zfill(3) + '-member') if row['declaration'] else None
        method = row['method']
        if method['resolution'] == 'resolved':
            method = dict(method)
            method['range'] = literal(method['range'], phase + '-' + str(row['ordinal']).zfill(3) + '-method')
            method['classification'] = 'literal-empty-body' if method['empty_literal_body'] else 'nonempty-body-requires-semantic-review'
            row['method'] = method

# Authenticate the complete selected source files through one finite git batch;
# bodies are not certified from method/member names or zero object counts.
required_paths = {state_cc, state_hh, SOURCE / 'Data/BaseData.hh'}
for group in lists.values():
    for row in group['calls']:
        if row['method']['resolution'] == 'resolved':
            required_paths.add(ROOT / row['method']['range']['Original_file'])
            required_paths.add(ROOT / row['method']['class_range']['Original_file'])
relative_paths = sorted(path.relative_to(REFERENCE).as_posix() for path in required_paths)
request = ''.join(COMMIT + ':' + name + '\n' for name in relative_paths).encode()
batch = subprocess.run(['git', '-C', str(REFERENCE), 'cat-file', '--batch'], input=request, capture_output=True, check=True).stdout
offset = 0
source_auth = []
for relative in relative_paths:
    newline = batch.index(b'\n', offset)
    header = batch[offset:newline].split()
    assert len(header) == 3 and header[1] == b'blob', (relative, header)
    size = int(header[2])
    data = batch[newline + 1:newline + 1 + size]
    offset = newline + 2 + size
    local = (REFERENCE / relative).read_bytes()
    assert local.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n'), relative
    source_auth.append({'Original_file': (REFERENCE / relative).relative_to(ROOT).as_posix(), 'git_blob': header[0].decode(), 'complete_file_matches_pinned_git_after_CRLF_normalization': True})
assert offset == len(batch)

counts = {}
for phase, group in lists.items():
    counts[phase] = dict(collections.Counter(row['method'].get('classification', 'unresolved') for row in group['calls']))
index = {'schema': 'src06-complete-EnergyPlusData-init-guard-Source-index.v1', 'Original_git_commit': COMMIT, 'lists': lists, 'counts': counts, 'complete_selected_files_authenticated': source_auth, 'no_op_rule': 'Only a resolved actual method whose body contains no C++ tokens after comments and literal masking is classified literal-empty-body. This index does not infer no-op from member name or zero family inputs.', 'unresolved_is_no_op': False, 'current_Rust_guard_completion_claimed': False, 'compiler_engine_or_targets_executed': False, 'canonical_mutated': False}
(OUT / 'source-index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'index': ref(OUT / 'source-index.json'), 'counts': counts, 'authenticated_Original_files': len(source_auth), 'nonempty_or_unresolved': {phase: [{'ordinal': row['ordinal'], 'member': row['member'], 'cpp_type': row['cpp_type'], 'method': row['method']} for row in group['calls'] if row['method'].get('classification') != 'literal-empty-body'] for phase, group in lists.items()}}, ensure_ascii=False))

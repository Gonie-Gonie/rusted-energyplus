$ErrorActionPreference = 'Stop'
$env:CI_FORCE_TIME_STEP = 'Y'
Write-Output 'Actual inherited CI_FORCE_TIME_STEP=Y; Source GetProjectData forces TimeStepsInHour=2.'
& 'C:/Users/GonieGonie/.cargo/bin/cargo.exe' test -p ep_run --test arbitrary_run one_zone_runtime_writes_stable_output_layout
if ($LASTEXITCODE -ne 0) { throw "Actual CLI test failed: $LASTEXITCODE" }

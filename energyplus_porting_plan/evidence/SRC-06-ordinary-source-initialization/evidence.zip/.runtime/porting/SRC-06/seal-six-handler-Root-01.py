"""Archive actual canonical Source before QA without changing any gate."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import re

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
parser = argparse.ArgumentParser()
parser.add_argument('--version', required=True, type=int)
args = parser.parse_args()
first = base / 'ordinary-six-handler-assembly-01'
applied = json.loads((first / 'apply.json').read_bytes())
out = base / f'ordinary-six-handler-assembly-{args.version:02}'
assert not (out / 'manifest.json').exists()
out.mkdir(exist_ok=True)

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def store(path, data):
    assert not path.exists()
    path.write_bytes(data)
    return ref(path)

files = []
for index, name in enumerate(applied['paths']):
    before_path = first / f'{index:02}.before'
    before = before_path.read_bytes()
    canonical = root / name
    after = canonical.read_bytes()
    proposal = root / applied['activated_proposals'][index]['path']
    assert ref(proposal) == applied['activated_proposals'][index]
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after))
    after_ref = store(out / f'{index:02}.after', after)
    diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='HEAD/' + name, tofile=name)).encode()
    format_diff = ''.join(difflib.unified_diff(proposal.read_text(encoding='utf8').splitlines(True), after.decode().splitlines(True), fromfile='held/' + name, tofile=name)).encode()
    files.append({
        'canonical': ref(canonical), 'before': ref(before_path), 'after': after_ref,
        'complete_diff': store(out / f'{index:02}.diff', diff),
        'held_to_actual_diff': store(out / f'{index:02}.held.diff', format_diff),
        'test_bodies_before': len(re.findall(rb'#\[test\]', before)),
        'test_bodies_after': len(re.findall(rb'#\[test\]', after)),
    })
manifest = {
    'schema': 'src06-six-handler-canonical-assembly.v1',
    'base_head': applied['base_head'], 'files': files,
    'apply': ref(first / 'apply.json'),
    'held_manifest': applied['held_manifest'],
    'independent_held_review': applied['independent_review'],
    'author': ref(Path(__file__)), 'new_test_bodies': 0,
    'full_Setup_completed': False, 'gates_updated': False,
}
if args.version > 1:
    manifest['parent'] = ref(base / f'ordinary-six-handler-assembly-{args.version - 1:02}/manifest.json')
path = out / 'manifest.json'
path.write_bytes((json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'manifest': ref(path), 'paths': len(files)}))

"""Update existing CLI output assertions for actual newly opened files."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path.cwd()
out = root / '.runtime/porting/SRC-06/ordinary-six-handler-assembly-01'
apply_path = out / 'apply.json'
applied = json.loads(apply_path.read_bytes())
assert len(applied['paths']) == 34
assert not (out / 'cli-test-extension.json').exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def replace(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new)

names = [
    'crates/ep_run/tests/arbitrary_run.rs',
    'crates/ep_run/tests/arbitrary_run/output_manifest.rs',
]
proposals = []
for name in names:
    path = root / name
    before = path.read_bytes()
    assert subprocess.check_output(['git', 'show', applied['base_head'] + ':' + name]) == before
    text = before.decode().replace('\r\n', '\n')
    if name.endswith('arbitrary_run.rs'):
        text = replace(text,
            '    BLOCKED_AFTER_SUPPORT_MANIFEST, SUPPORTED_RUNTIME_MANIFEST, assert_output_manifest,',
            '    BLOCKED_AFTER_SUPPORT_MANIFEST, SUPPORTED_RUNTIME_MANIFEST, assert_output_manifest,\n    assert_ordinary_output_manifest,')
        marker = '    assert_output_manifest(&output_dir, SUPPORTED_RUNTIME_MANIFEST)?;'
        first = text.index(marker)
        text = text[:first] + text[first:].replace(marker,
            '    assert_ordinary_output_manifest(&output_dir)?;\n'
            '    let eio = std::fs::read_to_string(output_dir.join("eplusrs.eio"))?;\n'
            '    assert!(eio.starts_with("Program Version,"));\n'
            '    assert_eq!(std::fs::read(output_dir.join("eplusrs.audit"))?,\n'
            '        b"  Processing Schedule Input -- Start\\n  Processing Schedule Input -- Complete\\n");\n'
            '    if std::env::var("CI_FORCE_TIME_STEP").as_deref() == Ok("Y") {\n'
            '        assert!(eio.contains(" Timesteps per Hour,  2, 30"),\n'
            '            "the actual CLI must reach the forced Project timestep");\n'
            '    }', 1)
    else:
        text = replace(text,
            'fn output_file_manifest(output_dir: &Path) -> Result<Vec<String>, Box<dyn std::error::Error>> {',
            '''// The ordinary caller reaches real OpenOutputFiles and Schedule audit.
// Diagnostic/IdealLoads callers retain their existing explicit output contract.
pub(crate) fn assert_ordinary_output_manifest(
    output_dir: &Path,
) -> Result<(), Box<dyn std::error::Error>> {
    let mut expected = SUPPORTED_RUNTIME_MANIFEST.to_vec();
    expected.extend(["eplusrs.audit", "eplusrs.bnd", "eplusrs.eso", "eplusrs.mtr"]);
    expected.sort_unstable();
    assert_output_manifest(output_dir, &expected)
}

fn output_file_manifest(output_dir: &Path) -> Result<Vec<String>, Box<dyn std::error::Error>> {''')
    after = text.encode()
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after))
    proposals.append((name, before, after))

rows = []
for name, before, after in proposals:
    index = len(applied['paths'])
    before_path = out / f'{index:02}.before'
    before_path.write_bytes(before)
    proposal = out / f'{index:02}.cli-proposed'
    proposal.write_bytes(after)
    (root / name).write_bytes(after)
    applied['paths'].append(name)
    applied['activated_proposals'].append(ref(proposal))
    rows.append({'canonical_path': name, 'before': ref(before_path), 'proposed': ref(proposal)})
extension_path = out / 'cli-test-extension.json'
extension_path.write_bytes((json.dumps({'schema': 'src06-six-handler-cli-test-extension.v1',
    'files': rows, 'author': ref(Path(__file__)), 'new_test_bodies': 0, 'new_test_binaries': 0,
    'scope': 'Only the first existing ordinary CLI test uses the extended output contract; other runtime manifests are unchanged.'}, indent=2) + '\n').encode())
applied['cli_test_extension'] = ref(extension_path)
apply_path.write_bytes((json.dumps(applied, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'extension': ref(extension_path), 'total_paths': len(applied['paths'])}))

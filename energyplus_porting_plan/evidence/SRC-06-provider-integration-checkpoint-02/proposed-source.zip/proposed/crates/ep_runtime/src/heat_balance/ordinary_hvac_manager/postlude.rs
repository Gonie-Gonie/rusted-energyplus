//! Actual UpdateZoneListAndGroupLoads2199-2236 using the sole existing load arrays.
use super::{Error, SourceHvacManager, SourceHvacOwners};
fn reset(values: &mut Option<Vec<f64>>, number: i32) -> Result<(), Error> {
    let at = number
        .checked_sub(1)
        .and_then(|n| usize::try_from(n).ok())
        .ok_or(Error::Unavailable("actual ZoneList report ordinal"))?;
    *values
        .as_deref_mut()
        .and_then(|rows| rows.get_mut(at))
        .ok_or(Error::Unavailable("actual ZoneList report allocation2210"))? = 0.0;
    Ok(())
}
impl SourceHvacManager {
    pub(crate) fn update_source_zone_list_and_group_loads(
        &self,
        o: &mut SourceHvacOwners<'_, '_>,
    ) -> Result<(), Error> {
        for number in 1..=o.zones.num_zone_lists {
            let reports = &mut o.control.zone_air_group_loads;
            reset(&mut reports.list_heat_energy, number)?;
            reset(&mut reports.list_cool_energy, number)?;
            reset(&mut reports.list_heat_rate, number)?;
            reset(&mut reports.list_cool_rate, number)?;
        }
        if o.zones.num_zone_lists > 0 {
            return Err(Error::Unavailable(
                "actual ZoneList record2217: positive GetZoneData list body unported",
            ));
        }
        if o.zones.num_zone_groups > 0 {
            return Err(Error::Unavailable(
                "actual ZoneGroup record2229: positive GetZoneData group body unported",
            ));
        }
        Ok(())
    }
}

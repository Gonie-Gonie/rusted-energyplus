//! Literal getPowerManagerInput214-420 genuine zero-load-center route.
use super::manager::meter_index;
use super::*;
use crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError as Error;
impl FacilityElectricService {
    pub(super) fn get_source_power_manager_input(
        &mut self,
        o: &mut SourceFacilityElectricOwners<'_, '_>,
    ) -> Result<(), Error> {
        self.number_of_load_centers = o
            .input
            .get_num_objects_found("ElectricLoadCenter:Distribution");
        if self.number_of_load_centers > 0 {
            return Err(Error::Unavailable(
                "actual ElectPowerLoadCenter constructor224",
            ));
        }
        let mut errors_found = false;
        let lists = o
            .input
            .get_num_objects_found("ElectricLoadCenter:Generators");
        if lists > 0 {
            o.backend.show_severe_error("ElectricLoadCenter:Generators input object requires an ElectricLoadCenterDistribution input object.")?;
            errors_found = true;
        }
        let mut inverters = o
            .input
            .get_num_objects_found("ElectricLoadCenter:Inverter:Simple");
        inverters += o
            .input
            .get_num_objects_found("ElectricLoadCenter:Inverter:FunctionOfPower");
        inverters += o
            .input
            .get_num_objects_found("ElectricLoadCenter:Inverter:LookUpTable");
        if inverters > 0 {
            o.backend.show_severe_error("ElectricLoadCenter:Inverter:* input objects require an ElectricLoadCenter:Distribution input object.")?;
            errors_found = true;
        }
        let mut storage = o
            .input
            .get_num_objects_found("ElectricLoadCenter:Storage:Simple");
        storage += o
            .input
            .get_num_objects_found("ElectricLoadCenter:Storage:Battery");
        if storage > 0 {
            o.backend.show_severe_error("ElectricLoadCenter:Storage:* input objects require an ElectricLoadCenter:Distribution input object.")?;
            errors_found = true;
        }
        let mut generators = o
            .input
            .get_num_objects_found("Generator:InternalCombustionEngine");
        generators += o.input.get_num_objects_found("Generator:CombustionTurbine");
        generators += o.input.get_num_objects_found("Generator:MicroCHP");
        generators += o.input.get_num_objects_found("Generator:FuelCell");
        generators += o.input.get_num_objects_found("Generator:Photovoltaic");
        generators += o.input.get_num_objects_found("Generator:WindTurbine");
        if generators > 0 {
            o.backend.show_severe_error("Electric generator input objects require an ElectricLoadCenter:Distribution input object.")?;
            errors_found = true;
        }
        if errors_found {
            return match o.backend.show_fatal_error(
                "Simulation halted because of missing input objects related to ElectricLoadCenter.",
            ) {
                Ok(never) => match never {},
                Err(error) => Err(Error::Fatal(error)),
            };
        }
        let any_electricity_present = meter_index(o.registration, "ELECTRICITY:FACILITY")?;
        let plant_profile = o.input.get_num_objects_found("LoadProfile:Plant");
        if any_electricity_present > -1 || plant_profile > 0 {
            return Err(Error::Unavailable(
                "actual default ElectPowerLoadCenter(state,0) constructor269 before append/countwrite",
            ));
        }
        self.number_of_transformers = o
            .input
            .get_num_objects_found("ElectricLoadCenter:Transformer");
        if self.number_of_transformers > 0 {
            o.shortcut.current_module_object = "ElectricLoadCenter:Transformer".into();
            return Err(Error::Unavailable("actual transformer GetObjectItem283"));
        }
        // Conditional output registration/report capacity/storage/check children
        // are genuinely not reached when the actual numLoadCenters_ is zero.
        if self.number_of_load_centers > 0 {
            return Err(Error::Unavailable(
                "actual positive facility output registration323",
            ));
        }
        Ok(())
    }
}

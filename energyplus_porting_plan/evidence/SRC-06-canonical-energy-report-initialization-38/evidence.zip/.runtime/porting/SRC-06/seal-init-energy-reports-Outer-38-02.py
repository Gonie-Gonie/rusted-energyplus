"""Seal private corrected38 composite after the narrow literal/member peer."""
from pathlib import Path
import argparse,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
I=D/'source-init-energy-reports-draft-Outer-38-02';O=D/'source-init-energy-reports-held-Outer-38-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',r.get('size_bytes',v['bytes']));return p
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));return ref(p)
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(a):
 assert not O.exists();dr=ref(I/'draft.json');assert dr['sha256']=='f926d2674dea19743fd4ae1f262439c90ac75eaff9d0cf6685f0743b1e880c01';d=json.loads(checked(dr).read_bytes())
 pr=dict(path=a.peer,sha256=a.peer_sha);peer=json.loads(checked(pr).read_bytes());pr=ref(checked(pr));assert peer['accepted'] and not peer.get('findings',[]) and contains(peer,dr)
 m=json.loads(checked(d['original_failed_producer']).read_bytes());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==m['base_HEAD']
 oldplan=json.loads(checked(m['complete_final_compiler_Source_plan']).read_bytes());plan=json.loads(checked(d['complete_proposed_compiler_Source_plan']).read_bytes());old={r['path']:r for r in oldplan['entries']};assert plan['inputs']==4508 and plan['Rust_sources']==4495 and len(plan['entries'])==4508
 f=json.loads(checked(d['failed_actual_B']).read_bytes());assert f['exit_code']==101 and f['source_bytes_match_before_and_after'];obs={r['historical_path']:r for r in json.loads(checked(f['source_snapshot']).read_bytes())['files']};assert set(old)==set(obs)
 changed=[]
 for row in plan['entries']:
  path=row['path'];assert (old[path]['final_sha256'],old[path]['final_bytes'])==(obs[path]['archive']['sha256'],obs[path]['size_bytes'])
  source=checked(row['source']).read_bytes();assert (hashlib.sha256(source).hexdigest(),len(source))==(row['final_sha256'],row['final_bytes'])
  if row!=old[path]:changed.append(path)
 assert changed==['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_energy_initialization.rs']
 plan['schema']='src06-complete-Source38-02-final-compiler-input-plan.v1';plan['corrected_draft']=dr;plan['narrow_correction_peer']=pr
 planref=write(O/'complete-final-compiler-Source-plan.json',plan)
 pat=re.compile(rb'initialize_source_energy_reports\(|initialize_source_equipment_energy_connections\(|load_source_zone_equipment_energy_readings\(|report_source_zone_energy_topology\(|get_source_internal_variable_value\(|SourceSystemReportOwners\s*\{');rows=[]
 for row in plan['entries']:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  for line,text in enumerate(checked(row['source']).read_bytes().splitlines(),1):
   if pat.search(text):rows.append(dict(path=row['path'],line=line,text=text.decode('utf-8')))
 prior_census=json.loads(checked(m['whole4495_Rust_API_census']).read_bytes());assert rows==prior_census['rows']
 census=write(O/'whole-crates-final-API-census.json',dict(complete_plan=planref,whole_crates=True,Rust_sources=4495,fixture_bodies_excluded=True,rows=rows,original38_rows_whole_equal=True))
 result=copy.deepcopy(m);result.update(schema='src06-held-init-energy-reports-Source38-02.v1',status='HELD corrected Source38: original full semantics carried plus independent two-identifier compile correction; Root actual02 pending',original_draft=dr,independent_full_semantic_peer=pr,peer_scope='The independent02 peer verifies exactly two member identifiers and carries original a962 full semantic review for all unchanged formulas/branches/API. It is not relabeled as a second full independent semantic review.',carried_original_full_semantic_peer=m['independent_full_semantic_peer'],original_failed_producer=d['original_failed_producer'],original_failed_draft=m['original_draft'],original_failed_compiler_plan=m['complete_final_compiler_Source_plan'],original_failed_B=d['failed_actual_B'],original_failed_snapshot=d['failed_actual_snapshot'],initial_application=d['initial_application'],initial_application_Source=d['initial_application_Source'],correction=d['correction'],complete_final_compiler_Source_plan=planref,files=d['files'],whole4495_Rust_API_census=census,author_Source=ref(Path(__file__)),Source_only_parses=5,Source_only_fresh_corrected_parses=1,Source_only_unchanged_original_parses=4)
 result['original4507_parent_readback']=dict(kind='INLINE_HISTORICAL_ORIGINAL38_SEAL_READBACK_NOT_CURRENT_LIVE_CLAIM',producer=d['original_failed_producer'],readback=result.pop('full4507_parent_readback'))
 result['full4508_failed_snapshot_readback']=dict(kind='INLINE_VERIFIED_FAILED_ACTUAL_SNAPSHOT_NOT_A_FILE_REFERENCE',snapshot=d['failed_actual_snapshot'],inputs=4508,Rust_sources=4495,all_failed_archive_wholes_authenticated_against_original_plan=True,all_final_proposal_wholes_rehashed=True,only_one_newfile_entry_changed=True)
 out=O/'manifest.json';write(out,result);print(json.dumps(ref(out)));print(json.dumps(planref))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--peer',required=True);p.add_argument('--peer-sha',required=True);main(p.parse_args())

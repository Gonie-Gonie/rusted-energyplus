"""Private immutable compile correction: two existing-owner field identifiers only."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'source-init-energy-reports-draft-Outer-38-02'
P='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_energy_initialization.rs'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];r=ref(p);assert r['sha256']==v['sha256'] and r['bytes']==v.get('bytes',v.get('size_bytes',r['bytes']));return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def diff(p,a,b,tag):return save(p,''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='before-'+tag,tofile='after-'+tag)).encode())
mp=D/'source-init-energy-reports-held-Outer-38/manifest.json';mr=ref(mp);assert mr['sha256']=='0c3649aeb6317c639a1a8be922ad030c2ff6b4c705c496659e9c2deb6cc3044b';m=json.loads(mp.read_bytes())
failure=D/'canonical-source-energy-report-initialization-B-NOLIMIT-24H-command-Root-38/receipt.json';fr=ref(failure);assert fr['sha256']=='f5eff2ad1af4d9c973e309514e25e6326195e92b3a5c50a23769f47dda5ed673';fv=json.loads(failure.read_bytes());assert fv['exit_code']==101 and fv['launch_error'] is None and fv['source_bytes_match_before_and_after']
checked(fv['stderr']);messages=[json.loads(line) for line in checked(fv['stdout']).read_bytes().splitlines() if line.startswith(b'{')];errors=[v['message'] for v in messages if v.get('reason')=='compiler-message' and v['message']['level']=='error'];assert len(errors)==2 and all(e['code']['code']=='E0609' and 'no field `number_supply_paths`' in e['message'] for e in errors)
app=D/'Root-energy-report-initialization-application-38/receipt.json';av=json.loads(app.read_bytes());assert av['accepted'] and av['producer']==mr;checked(av['author_Source'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==m['base_HEAD'] and not O.exists()
oldplan=json.loads(checked(m['complete_final_compiler_Source_plan']).read_bytes());index={r['path']:r for r in oldplan['entries']};snap=json.loads(checked(fv['source_snapshot']).read_bytes());obs={r['historical_path']:r for r in snap['files']};assert set(obs)==set(index) and len(index)==4508
for p,row in index.items():assert (row['final_sha256'],row['final_bytes'])==(obs[p]['archive']['sha256'],obs[p]['size_bytes'])
files=copy.deepcopy(m['files']);row=next(r for r in files if r['canonical_path']==P);old=checked(row['proposed']).read_bytes();assert (R/P).read_bytes()==old
needle=b'self.number_supply_paths';replacement=b'self.number_of_supply_paths';assert old.count(needle)==2 and replacement not in old;new=old.replace(needle,replacement);assert new.replace(replacement,needle)==old and len(new)==len(old)+6
owner=next(r for r in files if r['canonical_path'].endswith('/ordinary_equipment.rs'));owner_bytes=checked(owner['proposed']).read_bytes();assert b'number_of_supply_paths: usize' in owner_bytes and b'number_supply_paths:' not in owner_bytes
original_proposal=row['proposed'];row['proposed']=save(O/'proposed'/P,new)
empty=checked(row['before']).read_bytes();assert not empty and row['before_absent']
row['forward_diff']=diff(O/'diffs/05.forward.diff',empty,new,'new-Source38-child');row['inverse_diff']=diff(O/'diffs/05.inverse.diff',new,empty,'new-Source38-child')
proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert proc.returncode==0
row['Source_only_parse']=dict(exit_code=proc.returncode,stdout=save(O/'parse/05.stdout',proc.stdout),stderr=save(O/'parse/05.stderr',proc.stderr))
for f in files:
 if f['canonical_path']!=P:assert f==next(x for x in m['files'] if x['canonical_path']==f['canonical_path'])
cforward=diff(O/'correction.forward.diff',old,new,'two-field-identifiers');cinverse=diff(O/'correction.inverse.diff',new,old,'two-field-identifiers')
module=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_bytes());ns={'re':re};exec(compile(ast.Module(body=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='apply'],type_ignores=[]),'<literal-apply>','exec'),ns)
assert ns['apply'](old,checked(cforward).read_bytes())==new and ns['apply'](new,checked(cinverse).read_bytes())==old
final=copy.deepcopy(oldplan)
for r in final['entries']:
 if r['path']==P:r.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'],origin='Source38-02 exact two real-owner field identifier compile correction')
final.update(schema='src06-complete-Source38-02-compiler-input-plan.v1',original_failed38_plan=m['complete_final_compiler_Source_plan'],actual_failed38_receipt=fr,actual_failed38_snapshot=fv['source_snapshot'])
planref=write(O/'complete-proposed-compiler-Source-plan.json',final)
correction=write(O/'correction.json',dict(genuine_compile_finding='Two E0609 field accesses used number_supply_paths; the existing genuine owner member is number_of_supply_paths. Original Source-only syntax/semantic review did not establish contextual member correctness.',original_proposal=original_proposal,corrected_proposal=row['proposed'],original_owner_proposal=owner['proposed'],literal_before='self.number_supply_paths',literal_after='self.number_of_supply_paths',literal_replacements=2,byte_delta=6,forward_diff=cforward,inverse_diff=cinverse,whole_inverse_exact=True,other4_proposals_whole_unchanged=True,no_API_formula_branch_order_or_retained_state_change=True,failed_receipt=fr,failed_stderr=fv['stderr'],first_failed_snapshot=fv['source_snapshot'],initial_application=ref(app),initial_application_Source=av['author_Source']))
draft=dict(schema='src06-init-energy-reports-compile-corrected-draft38-02.v1',status='FROZEN narrow compile correction; independent correction peer pending',base_HEAD=m['base_HEAD'],original_failed_producer=mr,original_failed_draft=m['original_draft'],original_full_semantic_peer=m['independent_full_semantic_peer'],original_failed_plan=m['complete_final_compiler_Source_plan'],failed_actual_B=fr,failed_actual_snapshot=fv['source_snapshot'],initial_application=ref(app),initial_application_Source=av['author_Source'],correction=correction,files=files,complete_proposed_compiler_Source_plan=planref,inputs=4508,Rust_sources=4495,selected_existing=4,selected_new=1,new_test_bodies=0,actual_test_bodies_executed=0,Source_only_parse_fresh=1,unchanged_original_parse_carried=4,author_Source=ref(Path(__file__)),canonical_Cargo_Native_tests_or_publication_mutations=False)
dr=write(O/'draft.json',draft);print(json.dumps(dr));print(json.dumps(planref));print(json.dumps(correction))

"""Prepare isolated38 on committed actual37, no canonical/Cargo changes."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'source-init-energy-reports-draft-Outer-38';HEAD='8301ebaab8f3c521f1b15233de07874bf2ba78e2';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))
def main():
 assert not (O/'draft.json').exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
 mp=D/'source-energy-report-structure-held-Outer-37/manifest.json';pm=json.loads(mp.read_bytes());pr=pm['complete_final_compiler_Source_plan'];assert pr['sha256']=='8c6b325dd5f1ce54433d430823ae8c6e21366e6fbb96a91102cad117aa1bc14c'
 parent=json.loads(checked(pr).read_bytes());entries=parent['entries'];index={r['path']:r for r in entries};assert len(index)==4507 and parent['Rust_sources']==4494
 ar=ref(D/'Root-source-energy-report-structure-actual-review-37/review.json');assert ar['sha256']=='8cb34d64a3103bd6467d08bedd13082e2e14f2fe793ff8edfb20787781049c24';actual=json.loads(checked(ar).read_bytes());assert actual['accepted'] and not actual.get('findings',[])
 command=json.loads(checked(actual['actual_B']).read_bytes());snapshot=command['source_snapshot'];observed={r['historical_path']:r for r in json.loads(checked(snapshot).read_bytes())['files']};assert set(observed)==set(index)
 for path,row in index.items():
  b=checked(row['source']).read_bytes();assert (len(b),hashlib.sha256(b).hexdigest())==(row['final_bytes'],row['final_sha256']);assert (R/path).read_bytes()==b
  assert (row['final_sha256'],row['final_bytes'])==(observed[path]['archive']['sha256'],observed[path]['size_bytes'])
 proposals={}
 def before(path):return checked(index[path]['source']).read_bytes()
 def replace(path,a,z):
  b=proposals.get(path,(before(path),before(path)))[1];assert b.count(a.encode())==1,(path,a[:100]);proposals[path]=(before(path),b.replace(a.encode(),z.encode(),1))
 eq='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';replace(eq,'mod source_energy_report;\n','mod source_energy_report;\nmod source_energy_initialization;\n')
 op='crates/ep_runtime/src/heat_balance/source_output_registration/metered_variables.rs'
 added='''
impl SourceOutputRegistration {
    /// Native4208-4257 for the actual Invalid/Integer/Real metadata domain.
    /// Existing getters dereference the retained live Which, never Value.
    pub(crate) fn get_source_internal_variable_value<L: super::SourceRealOutputOwners + super::SourceIntegerOutputOwners>(
        &self, variable_type: Option<SourceOutputVariableType>, variable_index: i32, owners: &L,
    ) -> Result<f64, Error> {
        let Some(variable_type) = variable_type else { return Ok(0.0); };
        if variable_index < 0 || usize::try_from(variable_index).map_or(true, |n| n >= self.out_vars.len()) {
            return Err(Error::Unavailable("actual GetInternalVariableValue4241 index fatal diagnostic"));
        }
        let index = usize::try_from(variable_index).map_err(|_|Error::Unavailable("actual GetInternalVariableValue zero-based index"))?;
        match variable_type {
            SourceOutputVariableType::Integer => Ok(f64::from(*self.read_registered_integer(index, owners).map_err(Error::Output)?)),
            SourceOutputVariableType::Real => Ok(*self.read_registered_real(index, owners).map_err(Error::Output)?),
        }
    }
}
'''
 proposals[op]=(before(op),before(op)+added.encode())
 init='crates/ep_runtime/src/heat_balance/ordinary_system_reports/initialization.rs';old=before(init).decode();start=old.index('    pub(crate) fn initialize_source_energy_reports(')
 # All remaining private helpers in this file belong solely to Init; preserve
 # the complete allocation/Create prefix and narrow only this actual child.
 new='''    #[allow(clippy::too_many_arguments)]
    pub(crate) fn initialize_source_energy_reports(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
        hvac: &SelectedHvacGlobals,
        equipment: &mut OrdinaryEquipment,
        air_loop: &SourceAirLoopData,
        zones: &SelectedZoneInputOwners,
        registry: &PredefinedRegistry,
        table: &mut PredefinedStringTable,
        registration: &SourceOutputRegistration,
    ) -> Result<(), Error> {
        if !self.vent_report_structure_created { return Ok(()); }
        if self.one_time_flag_init_energy_reports {
            equipment.initialize_source_equipment_energy_connections(globals.num_of_zones, hvac, air_loop)?;
            // Native783-800 captures all six actual arrays after both passes.
            let zone_comps = air_loop.zone_comp_to_plant.as_ref().map_or(0, Vec::len);
            let zone_subcomps = air_loop.zone_sub_comp_to_plant.as_ref().map_or(0, Vec::len);
            let zone_subsubcomps = air_loop.zone_sub_sub_comp_to_plant.as_ref().map_or(0, Vec::len);
            let air_comps = air_loop.air_sys_comp_to_plant.as_ref().map_or(0, Vec::len);
            let air_subcomps = air_loop.air_sys_sub_comp_to_plant.as_ref().map_or(0, Vec::len);
            let air_subsubcomps = air_loop.air_sys_sub_sub_comp_to_plant.as_ref().map_or(0, Vec::len);
            self.one_time_flag_init_energy_reports = false;
            for _row in 1..=zone_comps { return Err(Error::Unavailable("actual InitEnergyReports805 ZoneCompToPlant.PlantLoopType")); }
            for _row in 1..=zone_subcomps { return Err(Error::Unavailable("actual InitEnergyReports826 ZoneSubCompToPlant.PlantLoopType")); }
            for _row in 1..=zone_subsubcomps { return Err(Error::Unavailable("actual InitEnergyReports847 ZoneSubSubCompToPlant.PlantLoopType")); }
            for _row in 1..=air_comps { return Err(Error::Unavailable("actual InitEnergyReports867 AirSysCompToPlant.PlantLoopType")); }
            for _row in 1..=air_subcomps { return Err(Error::Unavailable("actual InitEnergyReports888 AirSysSubCompToPlant.PlantLoopType")); }
            for _row in 1..=air_subsubcomps { return Err(Error::Unavailable("actual InitEnergyReports909 AirSysSubSubCompToPlant.PlantLoopType")); }
            self.report_source_air_loop_topology(hvac)?;
            equipment.report_source_zone_energy_topology(globals.num_of_zones, zones, registry, table)?;
            self.report_source_air_distribution_units(equipment)?;
            self.one_time_flag_init_energy_reports = false;
        }
        if hvac.number_of_primary_air_systems > 0 {
            return Err(Error::Unavailable("actual InitEnergyReports940 PrimaryAirSystems live row"));
        }
        equipment.load_source_zone_equipment_energy_readings(globals.num_of_zones, registration)?;
        // Native LoopSideKeys is Demand0, Supply1; both count loops remain real.
        for _loop_side in [0_i32, 1_i32] {
            for _plant in 1..=hvac.number_plant_loops { return Err(Error::Unavailable("actual InitEnergyReports1011 VentRepPlant live row")); }
            for _plant in 1..=hvac.number_condenser_loops { return Err(Error::Unavailable("actual InitEnergyReports1028 VentRepCond live row")); }
        }
        Ok(())
    }
    fn report_source_air_loop_topology(&self, hvac: &SelectedHvacGlobals) -> Result<(), Error> {
        if hvac.number_of_primary_air_systems > 0 {
            return Err(Error::Unavailable("actual reportAirLoopToplogy4947 PrimaryAirSystems live row"));
        }
        Ok(())
    }
    fn report_source_air_distribution_units(&self, equipment: &OrdinaryEquipment) -> Result<(), Error> {
        if equipment.source_air_distribution_units().is_some_and(|rows| !rows.is_empty()) {
            return Err(Error::Unavailable("actual reportAirDistributionUnits5282 ADU.Name/ZoneName first table entry"));
        }
        Ok(())
    }
}
'''
 proposals[init]=(before(init),(old[:start]+new).encode())
 remaining='crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/remaining.rs'
 replace(remaining,'''                .initialize_source_energy_reports(&mut Self::system_owners(
                    o,
                    &manager.simulation.air_loop,
                )),''','''                .initialize_source_energy_reports(
                    o.globals, o.hvac, o.equipment, &manager.simulation.air_loop,
                    o.zones, o.predefined_registry, o.predefined_table, &*output.registration,
                ),''')
 child='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_energy_initialization.rs';assert child not in index and not (R/child).exists();proposals[child]=(b'',(O/'proposed'/child).read_bytes())
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal apply>','exec'),ns)
 files=[]
 for i,(path,(b,z)) in enumerate(proposals.items(),1):
  if b:assert b==subprocess.check_output(['git','show',f'{HEAD}:{path}'],cwd=R)
  orig=path if b else '/dev/null';fd=''.join(difflib.unified_diff(b.decode().splitlines(True),z.decode().splitlines(True),fromfile=orig,tofile=path)).encode();iv=''.join(difflib.unified_diff(z.decode().splitlines(True),b.decode().splitlines(True),fromfile=path,tofile=orig)).encode();assert ns['apply'](b,fd)==z and ns['apply'](z,iv)==b
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=z,capture_output=True);assert q.returncode==0,(path,q.stderr)
  files.append(dict(canonical_path=path,before_absent=not b,before=save(O/'before'/path,b),proposed=save(O/'proposed'/path,z),literal_inverse=save(O/'literal-inverse'/path,b),forward_diff=save(O/'diffs'/f'{i:02}.forward.diff',fd),inverse_diff=save(O/'diffs'/f'{i:02}.inverse.diff',iv),Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))))
 final=copy.deepcopy(entries);selected={r['canonical_path']:r['proposed'] for r in files}
 for row in final:
  if row['path'] in selected:
   r=selected[row['path']];row.update(final_sha256=r['sha256'],final_bytes=r['bytes'],source=r,origin='Source38 real InitEnergyReports child')
 r=selected[child];final.append(dict(path=child,final_sha256=r['sha256'],final_bytes=r['bytes'],source=r,origin='Source38 same-equipment initialization/live Which/topology child'));final.sort(key=lambda r:r['path']);assert len(final)==4508 and sum(r['path'].endswith('.rs') for r in final)==4495
 for row in final:
  if row['path'] not in selected:assert row==index[row['path']]
 plan=write(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-proposed-Source38-compiler-input-plan.v1',base_HEAD=HEAD,accepted37_actual_review=ar,actual37_parent_snapshot=snapshot,prior_plan=pr,inputs=4508,Rust_sources=4495,selected_existing=4,selected_new=1,entries=final))
 spans={'src/EnergyPlus/SystemReports.cc':[(114,1044),(5213,5281)],'src/EnergyPlus/OutputProcessor.cc':[(4208,4257)],'src/EnergyPlus/UtilityRoutines.hh':[(439,470)],'src/EnergyPlus/DataZoneEquipment.hh':[(280,376),(385,448)]}
 authorities=[]
 for path,xs in spans.items():
  p=N/path;b=p.read_bytes();assert b==subprocess.check_output(['git','-C',str(N),'show',f'{PIN}:{path}']);lines=b.decode().splitlines(keepends=True);ss=[]
  for a,z in xs:ss.append(dict(first=a,last=z,source=save(O/'Native'/f'{p.stem}-{a}-{z}.txt',''.join(lines[a-1:z]).encode())))
  authorities.append(dict(whole=ref(p),Native_path=path,pinned_Git=PIN,extents=ss))
 contexts=[]
 for path in ['crates/ep_runtime/src/heat_balance/ordinary_system_reports.rs','crates/ep_runtime/src/heat_balance/ordinary_system_reports/state.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_equipment_types.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_controlled_equipment.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_energy_report.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_setup_reporting.rs','crates/ep_runtime/src/heat_balance/source_output_registration/bound_real.rs','crates/ep_runtime/src/heat_balance/source_output_registration/bound_integer.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/simulation/state.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs']:
  contexts.append(dict(canonical_path=path,whole=save(O/'contexts'/path,checked(index[path]['source']).read_bytes())))
 pat=re.compile(rb'initialize_source_energy_reports\(|initialize_source_equipment_energy_connections\(|load_source_zone_equipment_energy_readings\(|report_source_zone_energy_topology\(|get_source_internal_variable_value\(|SourceSystemReportOwners\s*\{');rows=[]
 for row in final:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  for line,t in enumerate(checked(row['source']).read_bytes().splitlines(),1):
   if pat.search(t):rows.append(dict(path=row['path'],line=line,text=t.decode('utf-8')))
 cr=write(O/'whole-crates-final-API-census.json',dict(complete_plan=plan,whole_crates=True,Rust_sources=4495,fixture_bodies_excluded=True,rows=rows))
 draft=dict(schema='src06-init-energy-reports-draft38.v1',status='FROZEN_SOURCE_FOR_FULL_INDEPENDENT_PEER_NOT_APPLIED',base_HEAD=HEAD,accepted37_actual_review=ar,actual_observed_B=actual['actual_B'],actual_parent_snapshot=snapshot,parent_producer=ref(mp),prior_complete_compiler_Source_plan=pr,complete_proposed_compiler_Source_plan=plan,files=files,Source_files=5,existing_Source_files=4,new_Source_files=1,literal_applications=10,Source_only_parses=5,full4507_parent_readback=dict(all_archived_actual_snapshot_live_wholes_exact=True,selected4_existing_Git_wholes_exact=True,all_unselected_parent_entries_preserved=True),whole4495_Rust_API_census=cr,Native_commit=PIN,Native_authorities=authorities,concrete_same_owner_contexts=contexts,read_only_map=ref(D/'init-energy-reports-readonly-map-Peer-38/plan.json'),contract=dict(scope='Native InitEnergyReports130-1044 normal controlled closure and topology5213-5273. Both exact full allocated List searches overwrite actual Config.EquipListIndex; first pass selected list, later loading/topology direct zone-parallel List.',ordering='Cool then Heat equality/ADU-index stores; true SupplyPath and AirLoop scalar predicates; all six dedup/plant loops remain inside each actual inlet independently of ADU branch; captures after two passes then false801, six pointer scans, Air/Zone/ADU topology then false935; subsequent live meter loads every invocation.',Which='Actual OP4208 Invalid->0; checked zero-based Real/Integer index then EXISTING read_registered_real/integer direct Which on SAME equipment. No OutVar.value/request/frequency/schedule filtering or multiplier; scalar return is assigned immediately to existing MeterData.current_meter_reading.',topology='Every actual Zone.Name row/increment before IsControlled; same direct List EquipData.TypeOf/Name and row writes zone/type/name/increment before actual optional child count. All on same predefined registry/table.',positive_boundaries='Actual positive SAP first member, primary-air fields, MatchPlantSys, EnergyTransfer FindDemandSideMatch AFTER its flag/type/name reads, unrepresented subrows/connection arrays/plant first fields remain typed at actual operation. Native unusual AirSysSubSub dedup uses SubCompNum; preserved, not normalized.',owner='No new retained state/projection/cache/owner or broad generic SystemReportOwners change. Only actual Init caller direct mutableEquipment/OP and shared count/topology operands. Existing two generic constructors preserved.',validation='Source-only syntax/literal/API/owner custody; Root owns sole Cargo/actual B+A24. No new tests or FP/cache/tolerance/policy/gate changes. Full diagnostic/plant/children/SystemReports or B620 completion not claimed.'),new_test_bodies=0,Cargo_main_Native_tests_or_publication_mutations=False,author_Source=ref(Path(__file__)))
 out=O/'draft.json';write(out,draft);print(json.dumps(ref(out)));print(json.dumps(plan))
if __name__=='__main__':main()

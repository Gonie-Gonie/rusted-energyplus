from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-energy-report-initialization-application-38';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-init-energy-reports-held-Outer-38/manifest.json');assert mr['sha256']=='0c3649aeb6317c639a1a8be922ad030c2ff6b4c705c496659e9c2deb6cc3044b';m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];assert pr['sha256']=='a96263b1e642b31573c5fab4d6ee696bce15b642a3ecc9bf82b3282922477d71';peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peerfiles={v['canonical_path']:v for v in peer['files']};draft=json.loads(checked(m['original_draft']));draftfiles={v['canonical_path']:v for v in draft['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='8301ebaab8f3c521f1b15233de07874bf2ba78e2' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4507 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(draftfiles[n]['proposed'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==5 and len(new)==1 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==4 and extent_count==6
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted37_actual_review','parent_producer','prior_complete_compiler_Source_plan','whole4495_Rust_API_census','original_draft']:checked(m[k])
parent_readback=m['full4507_parent_readback'];assert parent_readback['inputs']==4507 and parent_readback['Rust_sources']==4494 and all(v is True for k,v in parent_readback.items() if k not in ['kind','inputs','Rust_sources'])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4508 and sum(n.endswith('.rs') for n in rows)==4495
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
assert m['integration_contract']==draft['contract'] and m['all_parent_cohort_test_main_feature_Cargo_inputs_unchanged']
equipment=selected['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'];assert checked(equipment['before']).rsplit(b'#[cfg(test)]',1)[-1]==checked(equipment['proposed']).rsplit(b'#[cfg(test)]',1)[-1]
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Full independent five Source38 semantics, literal applications and exact proposal wholes; Root authenticates committed37 parent4507 and complete4508/4495 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4507,final_inputs=4508,final_Rust_sources=4495,selected_Rust=5,new_Rust=1,literal_applications=10,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read four existing forward diffs and complete new equipment initialization body, Native full Init114-1044/topology5213-5281, OP4208-4257, Utility exact FindItemInList, and real Config/List/Which/flag/owner contexts. Two full allocated list searches overwrite Config.EquipListIndex in Native order; cooling then heating outlet comparisons store actual ADU index before SupplyPath/air-loop guards. All six connection dedup and plant loops remain per inlet independently of ADU false. Counts captured after both passes, FALSE801 then pointer guards, Air/Zone/ADU topology then FALSE935. Every invocation uses actual direct List(zone), real metadata type/index, immutable Which of same equipment then immediate currentMeterReading assignment. Native Invalid0 precedes index checks; real/integer zero-based checked paths use existing reader, no Value snapshot/request/frequency/multiplier. Every Zone.Name topology row increments before controlled condition and component rows write zone/type/name before child guard. Actual Init caller alone borrows true live owners; other generic constructors unchanged. No new physical state, floating formulas, tests, tolerance or gate change. Positive SAP/primary/child/plant, Meter/Schedule domains and complete B/system-report equivalence are not claimed. Actual B/A38 pending.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

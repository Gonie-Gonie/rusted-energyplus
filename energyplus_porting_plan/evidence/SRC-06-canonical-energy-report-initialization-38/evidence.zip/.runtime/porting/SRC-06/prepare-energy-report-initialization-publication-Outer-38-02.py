"""Private publisher02 preparation; preserve original38 compile failure explicitly."""
from pathlib import Path
import ast,copy,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'publish-energy-report-initialization-checkpoint-Outer-38.py';NEW=D/'publish-energy-report-initialization-checkpoint-Outer-38-02.py'
O=D/'energy-report-initialization-publication-prepared-Outer-38-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();p.relative_to(R);r=ref(p);assert r['sha256']==v['sha256'] and r['bytes']==v.get('bytes',v.get('size_bytes',r['bytes']));return p
def load(p):return json.loads(p.read_bytes())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));return ref(p)
assert not NEW.exists() and not O.exists();before=OLD.read_bytes().decode('utf-8');assert ref(OLD)['sha256']=='bf5382d940c8f214654680090b6d1b020f7bdc8bdce2bd2ff9ce6bd912f5a97b'
s=before.replace('ACTUAL38_AND','ACTUAL38_02_AND').replace("BACK=D/'energy-report-initialization-publication-readback-Outer-38'","BACK=D/'energy-report-initialization-publication-readback-Outer-38-02'").replace('Root-38/output','Root-38-02/output')
old="accepted(t['independent_peer'])\n";new=old+" accepted(t['original_full_semantic_peer']);failed=load(checked(t['initial_failed_compilation']['receipt']));assert failed['exit_code']==101 and failed['launch_error'] is None and failed['source_bytes_match_before_and_after']\n";assert s.count(old)==1;s=s.replace(old,new)
old="archive_entries=len(files),publisher_Source=ref(Path(__file__)),Native_BND_reported_IO_comparison=native"
new="archive_entries=len(files),publisher_Source=ref(Path(__file__)),initial_failed_compilation=t['initial_failed_compilation'],compile_correction=t['compile_correction'],original_full_semantic_peer=t['original_full_semantic_peer'],independent_correction_peer_scope=t['independent_correction_peer_scope'],Native_BND_reported_IO_comparison=native";assert s.count(old)==1;s=s.replace(old,new)
old="for p in [apppath,checked(actual['author_Source']),checked(app['author_Source']),checked(actual['launcher_Source'])]:add(p)"
new="for p in [apppath,checked(actual['author_Source']),checked(app['author_Source']),checked(actual['launcher_Source']),checked(actual['comparison_helper_Source'])]:add(p)";assert s.count(old)==1;s=s.replace(old,new)
ast.parse(s);NEW.write_bytes(s.encode('utf-8'));O.mkdir()
parent37=D/'publish-energy-report-structure-checkpoint-Audit-37.py';assert ref(parent37)['sha256']=='042079808d871c4da2b9a36c783bf0283906f13b89bd06b2d5170d36bd41ace6'
for filename,a,b in [('publisher-from38-forward.diff',before,s),('publisher-from38-inverse.diff',s,before),('publisher-from37-forward.diff',parent37.read_bytes().decode(),s),('publisher-from37-inverse.diff',s,parent37.read_bytes().decode())]:
 (O/filename).write_bytes(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='publisher-before',tofile='publisher-after')).encode('utf-8'))
base=D/'energy-report-initialization-publication-prepared-Outer-38/publication-template.json';t=copy.deepcopy(load(base));mp=D/'source-init-energy-reports-held-Outer-38-02/manifest.json';m=load(mp);assert ref(mp)['sha256']=='768f053e86b0ef874ca8f9d139a4cd9144c34d462bca60e33504d90b9c4f791f'
draft=load(checked(m['original_draft']));correction=load(checked(m['correction']));failure=load(checked(m['original_failed_B']));finite={}
def add(v):p=checked(v);r=ref(p);assert p.suffix.lower()!='.zip' and r['bytes']<64*1024*1024;finite[r['path']]=r
for v in t['finite_archive_inputs']:add(v)
for v in [ref(mp),m['complete_final_compiler_Source_plan'],m['independent_full_semantic_peer'],m['original_draft'],m['correction'],m['author_Source'],m['whole4495_Rust_API_census'],m['original_failed_B'],m['original_failed_snapshot'],m['initial_application'],m['initial_application_Source'],draft['author_Source'],draft['complete_proposed_compiler_Source_plan'],correction['forward_diff'],correction['inverse_diff'],ref(OLD),ref(base),ref(Path(__file__))]:add(v)
for v in [failure['stdout'],failure['stderr']]:add(v)
for f in m['files']:
 for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(f[key])
 for key in ['stdout','stderr']:add(f['Source_only_parse'][key])
for p in O.glob('publisher-*.diff'):add(ref(p))
t.update(schema='src06-energy-report-initialization-publication-template38-02.v1',status='WAITING_FOR_ROOT_ACTUAL38_02_AND_FULL_READ',publisher_Source=ref(NEW),producer=ref(mp),complete_plan=m['complete_final_compiler_Source_plan'],independent_peer=m['independent_full_semantic_peer'],original_full_semantic_peer=m['carried_original_full_semantic_peer'],independent_correction_peer_scope=m['peer_scope'],expected_actual_review_path='.runtime/porting/SRC-06/Root-source-energy-report-initialization-actual-review-38-02/review.json',finite_archive_inputs=list(finite.values()),initial_failed_compilation=dict(receipt=m['original_failed_B'],stdout=ref(checked(failure['stdout'])),stderr=ref(checked(failure['stderr'])),source_snapshot=m['original_failed_snapshot'],initial_application=m['initial_application'],initial_application_Source=m['initial_application_Source'],exit_code=101,engine_executed=False,compiler_errors=2,error_code='E0609',scope='Original38 failed actual CLI compilation before engine execution. Preserved unmodified; not described as successful execution.'),compile_correction=m['correction'])
t['summary_template']['qualification']='The original38 actual CLI compile failed with two E0609 nonexistent member accesses before engine execution. Corrected02 changes exactly two field identifiers; original full semantic peer and narrow correction peer retain distinct scope. Only accepted Root38-02 B/A execution supplies current frontier and BND observation. Accepted37 A24 original5352 proof transfers only after strict equal37 comparisons. No new test, Native run, cohort, formula/cache/tolerance or gate change.'
p=O/'publication-template.json';tr=write(p,t);result=dict(status='PREPARED_ONLY_ACTUAL38_02_PENDING_NOT_READY',publisher=ref(NEW),template=tr,delta_from_original38=ref(O/'publisher-from38-forward.diff'),full_delta_from_authenticated37=ref(O/'publisher-from37-forward.diff'),finite_input_entries=len(finite),finite_input_total_bytes=sum(v['bytes'] for v in finite.values()),initial_failed_compile_preserved=True,canonical_mutations=0,Cargo_Native_or_tests_executed=False)
print(json.dumps(result));print(json.dumps(write(O/'prepared.json',result)))

"""Private READY-template finalization only after Root accepts actual38-02."""
from pathlib import Path
import argparse,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();p.relative_to(R);r=ref(p);assert r['sha256']==v['sha256'] and r['bytes']==v.get('bytes',v.get('size_bytes',r['bytes']));return p
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(a):
 p=D/'energy-report-initialization-publication-prepared-Outer-38-02/publication-template.json';assert ref(p)['sha256']=='3922a3939abb6b3a8d7f96ac8045d97c36e9f3483d3729c065f91b67135829cb';t=json.loads(p.read_bytes());assert t['status']=='WAITING_FOR_ROOT_ACTUAL38_02_AND_FULL_READ'
 ar=dict(path=t['expected_actual_review_path'],sha256=a.actual_sha);v=json.loads(checked(ar).read_bytes());ar=ref(checked(ar));assert v['accepted'] and not v['findings'] and v['same4508_archived_inputs_exact_final_plan'] and v['selected5_final_sources_exact']
 for row in [t['producer'],t['complete_plan'],t['independent_peer'],t['accepted_parent_review']]:assert contains(v,row)
 assert v['actual_test_bodies_executed']==v['new_test_bodies']==0 and v['original_tolerance_RMSE_5352_proof_transferred']
 assert v['whole_JSON_equal37_after_exactly_two_owned_path_field_bridges'] and v['full_runtime_equal37_after_two_owned_path_bridges']
 for key,scope in [('actual_B','B'),('actual_A24','A')]:
  c=json.loads(checked(v[key]).read_bytes());assert c['launch_error'] is None and c['source_bytes_match_before_and_after'] and (c['exit_code'] in (0,6) if scope=='B' else c['exit_code']==0);assert c['command'][c['command'].index('--porting-scope')+1]==scope
 app=json.loads(checked(v['application']).read_bytes());assert app['accepted'] and not app['findings'] and app['base_HEAD']==t['base_HEAD']
 native=v['B_Node_lifecycle_observation'];assert native['full_BND_body_bytes_equal'] and native['Native_BND_finite_copy']['sha256']==native['Native_original_BND']['sha256']
 fixed={row['path']:row for row in t['finite_archive_inputs']}
 for row in [ref(p),ref(Path(__file__)),ar,v['application'],app['author_Source'],v['author_Source'],v['launcher_Source'],v['comparison_helper_Source'],native['Native_capture'],native['Native_BND_finite_copy']]:
  q=checked(row);fixed[ref(q)['path']]=ref(q)
 t.update(status='HELD_READY_FOR_ROOT_ACTUAL38_02_AND_FULL_READ',accepted_actual_review=ar,finite_archive_inputs=list(fixed.values()),readiness_author_Source=ref(Path(__file__)))
 o=D/'energy-report-initialization-publication-READY-Outer-38-02';assert not o.exists();o.mkdir();p=o/'publication-template.json';p.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));print(json.dumps(ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--actual-sha',required=True);main(p.parse_args())

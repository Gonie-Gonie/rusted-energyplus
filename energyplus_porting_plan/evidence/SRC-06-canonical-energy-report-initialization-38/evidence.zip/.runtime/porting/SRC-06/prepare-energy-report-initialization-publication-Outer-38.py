"""Prepare only private Source38 publisher/template from authenticated published37."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'publish-energy-report-structure-checkpoint-Audit-37.py'
NEW=D/'publish-energy-report-initialization-checkpoint-Outer-38.py'
O=D/'energy-report-initialization-publication-prepared-Outer-38'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def auth(row):
 p=(R/row['path']).resolve();p.relative_to(R);got=ref(p);assert got['sha256']==row['sha256'] and got['bytes']==row.get('bytes',row.get('size_bytes',got['bytes']));return p
def load(p):return json.loads(p.read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
pt=D/'energy-report-structure-publication-READY-Audit-37-02/publication-template.json';parent=load(pt)
assert ref(OLD)==parent['publisher_Source'] and ref(OLD)['sha256']=='042079808d871c4da2b9a36c783bf0283906f13b89bd06b2d5170d36bd41ace6'
published=R/'energyplus_porting_plan/evidence/SRC-06-canonical-energy-report-structure-37/summary.json';pv=load(published)
assert pv['publisher_Source']==ref(OLD) and pv['Root_actual_review']==parent['accepted_actual_review']
mp=D/'source-init-energy-reports-held-Outer-38/manifest.json';m=load(mp);assert ref(mp)['sha256']=='0c3649aeb6317c639a1a8be922ad030c2ff6b4c705c496659e9c2deb6cc3044b'
assert m['base_HEAD']=='8301ebaab8f3c521f1b15233de07874bf2ba78e2'==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
peer=load(auth(m['independent_full_semantic_peer']));assert peer['accepted'] and not peer['findings']
draft=load(auth(m['original_draft']));assert len(m['files'])==5 and m['existing_Source_files']==4 and m['new_Source_files']==1
assert not NEW.exists() and not O.exists();before=OLD.read_bytes().decode('utf-8');s=before
for a,b in [
 ('engine37','engine38'),('final nine-file','final five-file'),('energy-report-structure','energy-report-initialization'),
 ('Audit-37','Outer-38'),('ACTUAL37','ACTUAL38'),('energy-report-initialization-37','energy-report-initialization-38'),
 ("len(producer['files'])==9 and producer['existing_Source_files']==6 and producer['new_Source_files']==3","len(producer['files'])==5 and producer['existing_Source_files']==4 and producer['new_Source_files']==1"),
 ('(4507,4494)','(4508,4495)'),('same4507_archived_inputs_exact_final_plan','same4508_archived_inputs_exact_final_plan'),
 ('len(observed)==4507','len(observed)==4508'),('selected9_final_sources_exact','selected5_final_sources_exact'),
 ('equal35','equal37'),('accepted35_full5352_proof','accepted37_full5352_proof'),('accepted35_proof','accepted37_proof'),
 ('Accepted35 A24 proof transfer','Accepted37 A24 proof transfer'),('Root-37/output','Root-38/output'),
 ('src06-canonical37-finite','src06-canonical38-finite'),('Six existing and three new production Sources','Four existing and one new production Sources'),
 ('The parent35 A24 proof is separately attributed; no cohort or new Native rerun by37.','The parent37 A24 proof is separately attributed; no cohort or new Native rerun by38.'),
 ('Genuine Source energy report structure on actual connected equipment and metered-variable owners; actual B result recorded','Genuine Source energy report initialization and live Which readings on the same actual equipment owners; actual B result recorded'),
 ('[Source37 energy report structure]','[Source38 energy report initialization]'),
 ('canonical_energy_report_structure_37','canonical_energy_report_initialization_38'),('actual_test_bodies_executed_by37','actual_test_bodies_executed_by38')]:
 assert a in s,a;s=s.replace(a,b)
old="ar=ref(checked(ar))\n";new="ar=ref(checked(ar));assert ar==t['accepted_actual_review']\n";assert s.count(old)==1;s=s.replace(old,new)
old="assert contains(actual,t['accepted_parent_review'])\n"
new=old+" native=actual['B_Node_lifecycle_observation'];assert native['full_BND_body_bytes_equal'] and native['Native_capture']['sha256']=='6845958c28d6eef55ce89100a13f2001d43ae7ca2fb3e86b2c189d2820b4c47f'\n assert native['Native_BND_finite_copy']['sha256']==native['Native_original_BND']['sha256']\n"
assert s.count(old)==1;s=s.replace(old,new)
old="for r in actual['publication_artifacts']:add(checked(r))\n"
new=old+" for key in ['Native_capture','Native_BND_finite_copy']:add(checked(native[key]))\n";assert s.count(old)==1;s=s.replace(old,new)
old="archive_entries=len(files),publisher_Source=ref(Path(__file__)))\n"
new="archive_entries=len(files),publisher_Source=ref(Path(__file__)),Native_BND_reported_IO_comparison=native,Native_BND_qualification='Entire reported BND body only, with only the exact two engine-specific Program Version first lines excluded. Retained genuine Native21 capture and finite whole BND copy; no new engine run or internal thermodynamic Node-state equivalence claim.')\n"
assert s.count(old)==1;s=s.replace(old,new)
assert 'ensure_ascii=False' in s and 'equal35' not in s and "len(producer['files'])==9" not in s
ast.parse(s);NEW.write_bytes(s.encode('utf-8'));O.mkdir()
for name,a,b in [('publisher-forward.diff',before,s),('publisher-inverse.diff',s,before)]:
 (O/name).write_bytes(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='authenticated-published37' if name.startswith('publisher-forward') else 'prepared38',tofile='prepared38' if name.startswith('publisher-forward') else 'authenticated-published37')).encode('utf-8'))
finite={}
def add(row):p=auth(row);r=ref(p);assert p.suffix.lower()!='.zip' and r['bytes']<64*1024*1024;finite[r['path']]=r
for k in ['complete_final_compiler_Source_plan','independent_full_semantic_peer','original_draft','author_Source','accepted37_actual_review','prior_complete_compiler_Source_plan','whole4495_Rust_API_census','read_only_map']:add(m[k])
for row in [ref(mp),ref(Path(__file__)),ref(OLD),ref(pt),ref(O/'publisher-forward.diff'),ref(O/'publisher-inverse.diff'),draft['author_Source'],ref(published)]:add(row)
for row in m['files']:
 for k in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(row[k])
 for k in ['stdout','stderr']:add(row['Source_only_parse'][k])
for row in m['Native_authorities']:
 add(row['whole'])
 for e in row['extents']:add(e['source'])
for row in m['concrete_same_owner_contexts']:add(row['whole'])
task=next(x for x in load(R/'energyplus_porting_plan/plan.json')['tasks'] if x['id']=='SRC-06');previous=task['canonical_energy_report_structure_37'];assert auth(previous)==published
t=dict(schema='src06-energy-report-initialization-publication-template.v1',status='WAITING_FOR_ROOT_ACTUAL38_AND_FULL_READ',base_HEAD=m['base_HEAD'],publisher_Source=ref(NEW),producer=ref(mp),complete_plan=m['complete_final_compiler_Source_plan'],independent_peer=m['independent_full_semantic_peer'],accepted_parent_review=m['accepted37_actual_review'],accepted_parent_plan=m['prior_complete_compiler_Source_plan'],expected_actual_review_path='.runtime/porting/SRC-06/Root-source-energy-report-initialization-actual-review-38/review.json',previous_engine_checkpoint=previous,finite_archive_inputs=list(finite.values()),summary_template=dict(A='14/54',B='14/64',gate_changes=False,policy_changes=False,selected_existing_production_Sources=4,new_production_Source_files=1,selected_production_Sources=5,actual_same_Equipment_OutputRegistration_Which_owners=True,new_test_bodies=0,actual_test_bodies_executed=0,scope='Controlled InitEnergyReports uses both exact full allocated-list searches and Config index writes, cooling then heating comparisons, all actual per-inlet connection-array and plant guards, genuine once-flag and predefined topology order, and per-iteration live Which values assigned into the same MeterData. Unrepresented positive children remain typed boundaries.',qualification='Actual B frontier and Native BND reported IO are taken only from accepted Root38 execution. The accepted37 A24 original5352 proof transfers only after current strict equal37 comparisons. No new test, Native engine, cohort, numerical formula, property cache, tolerance or finite gate change.'),doc_appends={
 'cards/SRC-06.md':'실제 장비 목록과 연결 정보를 사용해 에너지 보고 초기화의 두 순회와 표 기록 순서를 연결했다. 반복 보고에서는 같은 Which 참조의 현재 값을 읽어 기존 MeterData에 기록한다. B 실행 결과: `{{actual_B_result}}`. A24의 기존 5,352개 보고값 증거를 이어받으며 새 테스트나 계산식 변경은 없다.',
 'CHECKLIST.md':'에너지 보고 초기화와 현재 계량값 읽기를 기존 파일 4개와 새 파일 1개로 연결했다. 실제 B/A24 한 쌍으로 확인하고, 추가 테스트나 Native 재실행 없이 게이트 수를 유지한다.',
 'STATE_CONTRACTS.md':'두 번의 정확한 목록 검색은 실제 Config 인덱스를 각각 갱신한다. 같은 Equipment·OutputRegistration·표 소유자를 빌리며, 일회성 플래그와 표 기록 순서 및 매 반복의 직접 Which 읽기를 보존한다. 보고값 사본이나 대체 상태는 추가하지 않는다.'})
for text in t['doc_appends'].values():assert '?' not in text and '\ufffd' not in text
p=O/'publication-template.json';write(p,t)
result=dict(status='PREPARED_ONLY_ACTUAL38_PENDING_NOT_READY',authenticated_published37=ref(published),authenticated_parent_publisher=ref(OLD),authenticated_parent_template=ref(pt),publisher=ref(NEW),template=ref(p),full_forward_diff=ref(O/'publisher-forward.diff'),full_inverse_diff=ref(O/'publisher-inverse.diff'),finite_input_entries=len(finite),finite_input_total_bytes=sum(r['bytes'] for r in finite.values()),canonical_mutations=0,Cargo_Native_or_tests_executed=False)
q=O/'prepared.json';write(q,result);print(json.dumps(result));print(json.dumps(ref(q)))

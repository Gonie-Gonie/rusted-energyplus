from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-energy-report-initialization-application-38-02';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-init-energy-reports-held-Outer-38-02/manifest.json');assert mr['sha256']==sys.argv[1];m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];assert pr['sha256']==sys.argv[2];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peerfiles={v['canonical_path']:v for v in peer['files']};draft=json.loads(checked(m['original_draft']));draftfiles={v['canonical_path']:v for v in draft['files']}
initial_ref=ref(D/'Root-energy-report-initialization-application-38/receipt.json');assert initial_ref['sha256']=='e2416c083d8548ded868dd540c8f72584f01cfa2f4c67b745da687f719d4369f';initial=json.loads(checked(initial_ref));assert initial['accepted'] and not initial['findings']
original=json.loads(checked(initial['producer']));assert initial['producer']['sha256']=='0c3649aeb6317c639a1a8be922ad030c2ff6b4c705c496659e9c2deb6cc3044b'
correction_ref=draft['correction'];correction=json.loads(checked(correction_ref));a=checked(correction['original_proposal']);b=checked(correction['corrected_proposal']);assert a.count(correction['literal_before'].encode())==2 and b==a.replace(correction['literal_before'].encode(),correction['literal_after'].encode()) and len(b)==len(a)+6
assert checked(correction['original_owner_proposal']).count(b'number_of_supply_paths: usize,')==1
failed_ref=correction['failed_receipt'];assert failed_ref['sha256']=='f5eff2ad1af4d9c973e309514e25e6326195e92b3a5c50a23769f47dda5ed673';failed=json.loads(checked(failed_ref));assert failed['exit_code']==101 and failed['launch_error'] is None and failed['source_bytes_match_before_and_after']
errors=[]
for line in checked(failed['stdout']).splitlines():
 try:v=json.loads(line)
 except ValueError:continue
 if v.get('reason')=='compiler-message' and v['message']['level']=='error':errors.append(v['message'])
assert len(errors)==2 and all(v['code']['code']=='E0609' and 'number_supply_paths' in v['message'] for v in errors)
checked(failed['stderr']);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='8301ebaab8f3c521f1b15233de07874bf2ba78e2'
parents={v['historical_path']:v for v in json.loads(checked(original['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
assert len(parents)==4507 and len(inventory)==4508
initial_files={f['canonical_path']:f for f in original['files']}
initial_snap={v['historical_path']:v for v in json.loads(checked(failed['source_snapshot']))['files']};assert set(initial_snap)==inventory
for n,v in initial_snap.items():assert (R/n).read_bytes()==checked(v['archive']) and v['size_bytes']==(R/n).stat().st_size
for n,v in parents.items():assert checked(v['archive'])==(checked(initial_files[n]['before']) if n in initial_files else (R/n).read_bytes())

t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(draftfiles[n]['proposed'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert n not in parents and a==b'' and (R/n).read_bytes()==checked(initial_files[n]['proposed']);new.add(n)
 else:assert a==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1 and (R/n).read_bytes()==checked(initial_files[n]['proposed'])
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==5 and len(new)==1 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==4 and extent_count==6
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted37_actual_review','parent_producer','prior_complete_compiler_Source_plan','whole4495_Rust_API_census','original_draft']:checked(m[k])
assert m['original4507_parent_readback']['readback']==original['full4507_parent_readback'] and m['carried_original_full_semantic_peer']==initial['independent_peer'];carried=json.loads(checked(m['carried_original_full_semantic_peer']));assert carried['accepted'] and not carried['findings'];parent_readback=m['original4507_parent_readback']['readback'];assert parent_readback['inputs']==4507 and parent_readback['Rust_sources']==4494 and all(v is True for k,v in parent_readback.items() if k not in ['kind','inputs','Rust_sources'])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4508 and sum(n.endswith('.rs') for n in rows)==4495
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
assert m['integration_contract']==original['integration_contract'] and m['all_parent_cohort_test_main_feature_Cargo_inputs_unchanged']
equipment=selected['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'];assert checked(equipment['before']).rsplit(b'#[cfg(test)]',1)[-1]==checked(equipment['proposed']).rsplit(b'#[cfg(test)]',1)[-1]
for n,f in selected.items():assert checked(f['proposed'])==(checked(correction['corrected_proposal']) if n in new else checked(initial_files[n]['proposed']))
assert apply(checked(correction['original_proposal']),checked(correction['forward_diff']))==checked(correction['corrected_proposal']) and apply(checked(correction['corrected_proposal']),checked(correction['inverse_diff']))==checked(correction['original_proposal'])
O.mkdir()
for n,f in selected.items():
 p=R/n
 if p.read_bytes()!=checked(f['proposed']):
  assert n==next(f['canonical_path'] for f in original['files'] if f['before_absent']);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Original independent full five Source38 semantics plus independent narrow exact2 field-name correction review; contextual compile101 failure is preserved. Root authenticates committed37 parent4507, exact prior applied4508 and complete final4508/4495 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4507,final_inputs=4508,final_Rust_sources=4495,selected_Rust=5,new_Rust=1,literal_applications=10,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,initial_application=initial_ref,preserved_failed_compile=failed_ref,correction=correction_ref,semantic_review='Root read four existing forward diffs and complete new equipment initialization body, Native full Init114-1044/topology5213-5281, OP4208-4257, Utility exact FindItemInList, and real Config/List/Which/flag/owner contexts. Two full allocated list searches overwrite Config.EquipListIndex in Native order; cooling then heating outlet comparisons store actual ADU index before SupplyPath/air-loop guards. All six connection dedup and plant loops remain per inlet independently of ADU false. Counts captured after both passes, FALSE801 then pointer guards, Air/Zone/ADU topology then FALSE935. Every invocation uses actual direct List(zone), real metadata type/index, immutable Which of same equipment then immediate currentMeterReading assignment. Native Invalid0 precedes index checks; real/integer zero-based checked paths use existing reader, no Value snapshot/request/frequency/multiplier. Every Zone.Name topology row increments before controlled condition and component rows write zone/type/name before child guard. Actual Init caller alone borrows true live owners; other generic constructors unchanged. No new physical state, floating formulas, tests, tolerance or gate change. Positive SAP/primary/child/plant, Meter/Schedule domains and complete B/system-report equivalence are not claimed. Two misspelled supply-path member names are corrected to actual number_of_supply_paths, with whole inverse and all other bytes unchanged; actual B/A38-02 pending.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

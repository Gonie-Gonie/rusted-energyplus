from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={'B': ('canonical-source-energy-report-structure-B-NOLIMIT-24H-command-Root-37/receipt.json', 'c7c980e61b242ad7749f6df5b92576419746e16ae20b316d2b1a897111a72986'), 'A24': ('canonical-source-energy-report-structure-A-24H-command-Root-37/receipt.json', '824b0e923acb7a1e65400024dd60f50a48e33c549fa22a53d86be2344e78f51f')}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-energy-report-initialization-'+case+'-command-Root-38-02'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-energy-report-initialization-'+case+'-Root-38-02/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

"""Seal accepted38 Sources on committed actual37; never apply or run Cargo."""
from pathlib import Path
import argparse,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';I=D/'source-init-energy-reports-draft-Outer-38';O=D/'source-init-energy-reports-held-Outer-38'
HEAD='8301ebaab8f3c521f1b15233de07874bf2ba78e2'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(a):
 assert not O.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
 dr=ref(I/'draft.json');assert dr['sha256']=='cf85ffa6cde678bdbc540df02d055d9b9315a231efcf8916c65c71fca7f0e6ee';m=json.loads(checked(dr).read_bytes())
 peerref=dict(path=a.peer,sha256=a.peer_sha);peer=json.loads(checked(peerref).read_bytes());peerref=ref(checked(peerref));assert peer['accepted'] and not peer.get('findings',[]) and contains(peer,dr)
 ar=m['accepted37_actual_review'];actual=json.loads(checked(ar).read_bytes());assert actual['accepted'] and not actual.get('findings',[])
 parentref=m['prior_complete_compiler_Source_plan'];parent=json.loads(checked(parentref).read_bytes());entries=parent['entries'];index={r['path']:r for r in entries}
 assert len(index)==4507 and parent['Rust_sources']==4494 and actual['complete_compiler_plan']==parentref
 snapshot=m['actual_parent_snapshot'];command=json.loads(checked(actual['actual_B']).read_bytes());assert command['source_snapshot']==snapshot
 observed={r['historical_path']:r for r in json.loads(checked(snapshot).read_bytes())['files']};assert set(observed)==set(index)
 for path,row in index.items():
  b=checked(row['source']).read_bytes();assert (len(b),hashlib.sha256(b).hexdigest())==(row['final_bytes'],row['final_sha256']);assert (R/path).read_bytes()==b,path
  assert (row['final_sha256'],row['final_bytes'])==(observed[path]['archive']['sha256'],observed[path]['size_bytes'])
 files=[];selected={}
 for i,row in enumerate(m['files'],1):
  path=row['canonical_path'];b=checked(row['before']).read_bytes();z=checked(row['proposed']).read_bytes();absent=row['before_absent']
  if absent:assert path not in index and not (R/path).exists() and not b
  else:assert (R/path).read_bytes()==b==checked(index[path]['source']).read_bytes()==subprocess.check_output(['git','show',f'{HEAD}:{path}'],cwd=R)
  out=dict(canonical_path=path,before_absent=absent)
  for key,sub in [('before','before'),('proposed','proposed'),('literal_inverse','literal-inverse')]:out[key]=save(O/sub/path,checked(row[key]).read_bytes())
  for key,tag in [('forward_diff','forward'),('inverse_diff','inverse')]:out[key]=save(O/'diffs'/f'{i:02}.{tag}.diff',checked(row[key]).read_bytes())
  q=row['Source_only_parse'];assert q['exit_code']==0;checked(q['stdout']);checked(q['stderr']);out['Source_only_parse']=q;out['whole_independently_accepted_draft_proposal_exact']=True
  assert checked(out['proposed']).read_bytes()==z and checked(out['literal_inverse']).read_bytes()==b
  files.append(out);selected[path]=out['proposed']
 final=copy.deepcopy(entries)
 for row in final:
  if row['path'] in selected:
   v=selected[row['path']];row.update(final_sha256=v['sha256'],final_bytes=v['bytes'],source=v,origin='Source38 genuine same-owner InitEnergyReports child')
 for row in files:
  if row['before_absent']:
   v=row['proposed'];final.append(dict(path=row['canonical_path'],final_sha256=v['sha256'],final_bytes=v['bytes'],source=v,origin='Source38 genuine connection/Which/topology equipment child'))
 final.sort(key=lambda r:r['path']);assert len(final)==4508 and sum(r['path'].endswith('.rs') for r in final)==4495
 draftplan=json.loads(checked(m['complete_proposed_compiler_Source_plan']).read_bytes());dp={r['path']:r for r in draftplan['entries']};assert set(dp)=={r['path'] for r in final}
 for row in final:
  assert (row['final_sha256'],row['final_bytes'])==(dp[row['path']]['final_sha256'],dp[row['path']]['final_bytes'])
  if row['path'] not in selected:assert row==index[row['path']]
 plan=write(O/'complete-final-compiler-Source-plan.json',dict(schema='src06-complete-Source38-compiler-input-plan.v1',base_HEAD=HEAD,actual37_parent_review=ar,actual37_parent_snapshot=snapshot,prior_plan=parentref,inputs=4508,Rust_sources=4495,selected_existing=4,selected_new=1,entries=final))
 for auth in m['Native_authorities']:
  checked(auth['whole'])
  for e in auth['extents']:checked(e['source'])
 for context in m['concrete_same_owner_contexts']:checked(context['whole']);assert (R/context['canonical_path']).read_bytes()==checked(context['whole']).read_bytes()
 pat=re.compile(rb'initialize_source_energy_reports\(|initialize_source_equipment_energy_connections\(|load_source_zone_equipment_energy_readings\(|report_source_zone_energy_topology\(|get_source_internal_variable_value\(|SourceSystemReportOwners\s*\{');rows=[]
 for row in final:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  for line,t in enumerate(checked(row['source']).read_bytes().splitlines(),1):
   if pat.search(t):rows.append(dict(path=row['path'],line=line,text=t.decode('utf-8')))
 cr=write(O/'whole-crates-final-API-census.json',dict(complete_plan=plan,whole_crates=True,Rust_sources=4495,fixture_bodies_excluded=True,rows=rows))
 result=dict(schema='src06-held-init-energy-reports-Source38.v1',status='HELD full Source peer accepted; Root independent application and actual engine pending',base_HEAD=HEAD,accepted37_actual_review=ar,actual_parent_snapshot=snapshot,parent_producer=m['parent_producer'],prior_complete_compiler_Source_plan=parentref,complete_final_compiler_Source_plan=plan,original_draft=dr,independent_full_semantic_peer=peerref,compiler_inputs=4508,Rust_sources=4495,files=files,Source_files=5,existing_Source_files=4,new_Source_files=1,literal_applications=10,Source_only_parses=5,full4507_parent_readback=dict(kind='INLINE_VERIFIED_PARENT_READBACK_NOT_A_FILE_REFERENCE',inputs=4507,Rust_sources=4494,all_actual_snapshot_archived_live_wholes_exact=True,selected4_committed37_Git_wholes_exact=True,all4503_unselected_parent_entries_preserved=True,known_unselected_Git_comment_CR_bridge_unchanged=True),whole4495_Rust_API_census=cr,Native_commit=m['Native_commit'],Native_authorities=m['Native_authorities'],concrete_same_owner_contexts=m['concrete_same_owner_contexts'],integration_contract=m['contract'],read_only_map=m['read_only_map'],all_parent_cohort_test_main_feature_Cargo_inputs_unchanged=True,new_test_bodies=0,actual_test_bodies_executed=0,author_Source=ref(Path(__file__)),canonical_Source_Cargo_Native_tests_or_publication_mutations=False)
 out=O/'manifest.json';write(out,result);print(json.dumps(ref(out)));print(json.dumps(plan))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--peer',required=True);ap.add_argument('--peer-sha',required=True);main(ap.parse_args())

"""Root-only engine38 publisher: two genuine CLI receipts; never runs Cargo/tests.

Requires a finalized template after the accepted cohort parent and final five-file
packet. No action occurs without --publish. Pending draft metadata cannot publish.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-energy-report-initialization-38'
BACK=D/'energy-report-initialization-publication-readback-Outer-38'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=(R/row['path']).resolve();p.relative_to(R);v=ref(p);assert v['sha256']==row['sha256'] and v['bytes']==row.get('bytes',row.get('size_bytes',v['bytes']));return p
def load(p):return json.loads(p.read_bytes())
def contains(v,row):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(row['path'],row['sha256']) or any(contains(x,row) for x in v.values())
 return isinstance(v,list) and any(contains(x,row) for x in v)
def accepted(row):
 v=load(checked(row));assert v['accepted'] is True and not v.get('findings',[]);return v
def write_json(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def main(a):
 assert a.publish and not PUBLIC.exists() and not BACK.exists()
 tp=(R/a.template).resolve();tp.relative_to(R);t=load(tp);assert t['status']=='HELD_READY_FOR_ROOT_ACTUAL38_AND_FULL_READ'
 assert ref(Path(__file__))==t['publisher_Source'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==t['base_HEAD']
 producer=load(checked(t['producer']));plan=load(checked(t['complete_plan']));assert len(producer['files'])==5 and producer['existing_Source_files']==4 and producer['new_Source_files']==1
 assert (plan['inputs'],plan['Rust_sources'])==(4508,4495)
 accepted(t['independent_peer'])
 parent_review=accepted(t['accepted_parent_review']);assert parent_review['complete_compiler_plan']['sha256']==t['accepted_parent_plan']['sha256']
 ar=dict(path=t['expected_actual_review_path'],sha256=a.actual_sha);actual=accepted(ar);ar=ref(checked(ar));assert ar==t['accepted_actual_review']
 for r in [t['producer'],t['complete_plan'],t['independent_peer']]:assert contains(actual,r),r['path']
 for k in ['same4508_archived_inputs_exact_final_plan','selected5_final_sources_exact','whole_JSON_equal37_after_exactly_two_owned_path_field_bridges','full_runtime_equal37_after_two_owned_path_bridges']:assert actual[k] is True,k
 assert actual['actual_test_bodies_executed']==actual['new_test_bodies']==0
 assert actual['policy_changes']==actual['gate_changes']==0
 assert actual['transferred_reported_series']==58 and actual['transferred_JSON_CSV_scalar_roundtrips']==5352
 assert actual['whole_physical_streams_equal37'] and len(actual['whole_CSV_equal37'])==2
 assert contains(actual,t['accepted_parent_review'])
 native=actual['B_Node_lifecycle_observation'];assert native['full_BND_body_bytes_equal'] and native['Native_capture']['sha256']=='6845958c28d6eef55ce89100a13f2001d43ae7ca2fb3e86b2c189d2820b4c47f'
 assert native['Native_BND_finite_copy']['sha256']==native['Native_original_BND']['sha256']
 runs=[load(checked(actual[k])) for k in ['actual_B','actual_A24']];assert runs[0]['exit_code'] in (0,6) and runs[1]['exit_code']==0
 for run,scope in zip(runs,['B','A']):
  assert run['launch_error'] is None and run['source_bytes_match_before_and_after'] is True and Path(run['cwd']).resolve()==R
  cmd=run['command'];assert cmd[cmd.index('--porting-scope')+1]==scope
  assert not {'--oracle-baseline','--compare-oracle','test','--all-targets'}&set(cmd)
 assert runs[0]['source_snapshot']==runs[1]['source_snapshot']
 observed={r['historical_path']:r for r in load(checked(runs[0]['source_snapshot']))['files']};index={r['path']:r for r in plan['entries']};assert len(index)==len(observed)==4508 and set(index)==set(observed)
 for p,r in index.items():assert (r['final_sha256'],r['final_bytes'])==(observed[p]['archive']['sha256'],observed[p]['size_bytes'])
 for r in producer['files']:
  p=r['canonical_path'];assert (R/p).read_bytes()==checked(r['proposed']).read_bytes()==checked(observed[p]['archive']).read_bytes()
 cases=['B-NOLIMIT-24H','A-24H'];reports=[]
 for case in cases:
  out=D/f'canonical-source-energy-report-initialization-{case}-Root-38/output';sp=out/'run-summary.json';dp=out/'diagnostics.json'
  assert contains(actual,ref(sp)) and contains(actual,ref(dp));reports.append((load(sp),load(dp)))
 bs,bd=reports[0];aa,ad=reports[1];errors=[r['message'] for r in bd['diagnostics'] if r['code']=='RuntimeConvergenceFailure']
 assert bs['exit_code']==runs[0]['exit_code'] and aa['exit_code']==0
 assert aa['rust_runtime']['schema']=='rusted-energyplus.source-runtime.v1' and aa['rust_runtime']['execution']=='actual Source ManageSimulation successful through620'
 assert not any(r['code']=='RuntimeConvergenceFailure' for r in ad['diagnostics'])
 if runs[0]['exit_code']==6:
  assert bs['rust_runtime'] is None and errors==[actual['B_frontier']] and actual['B_runtime_or_fallback_results'] is False
  bresult=actual['B_frontier'];bcompleted=False
 else:
  assert not errors and bs['rust_runtime']['schema']=='rusted-energyplus.source-runtime.v1' and bs['rust_runtime']['execution']=='actual Source ManageSimulation successful through620'
  bresult='Source B-NOLIMIT-24H completed through actual620';bcompleted=True
 base=R/'energyplus_porting_plan';names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md'];docs={n:(base/n).read_bytes() for n in names};pp=base/'plan.json';oldplan=pp.read_bytes();oldvalue=json.loads(oldplan)
 for n,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R) and '\ufffd' not in b.decode('utf-8','strict')
 assert oldplan==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
 previous=load(checked(t['previous_engine_checkpoint']));assert (previous['A'],previous['B'])==('14/54','14/64')
 files={}
 def add(p):
  p=p.resolve();p.relative_to(R);r=ref(p);assert p.suffix.lower()!='.zip' and r['bytes']<64*1024*1024
  assert r['path'] not in files or files[r['path']]['ref']==r;files[r['path']]=dict(path=p,ref=r)
 for r in t['finite_archive_inputs']:add(checked(r))
 for p in [Path(__file__),tp,checked(ar)]:add(p)
 apppath=checked(actual['application']);app=load(apppath);assert app['accepted'] and not app.get('findings',[]) and app['base_HEAD']==head
 for r in [t['producer'],t['complete_plan']]:assert contains(app,r)
 for p in [apppath,checked(actual['author_Source']),checked(app['author_Source']),checked(actual['launcher_Source'])]:add(p)
 for key,run in zip(['actual_B','actual_A24'],runs):
  add(checked(actual[key]))
  for k in ['stdout','stderr','source_snapshot']:add(checked(run[k]))
 for r in actual['publication_artifacts']:add(checked(r))
 for key in ['Native_capture','Native_BND_finite_copy']:add(checked(native[key]))
 for r in producer['files']:add(R/r['canonical_path'])
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan)
 for n,b in docs.items():p=BACK/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 archive=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,item in sorted(files.items()):assert ref(item['path'])==item['ref'];z.write(item['path'],arcname=n)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and set(z.namelist())==set(files)
  for n,item in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==item['ref']['sha256']
 manifest=PUBLIC/'manifest.json';write_json(manifest,dict(schema='src06-canonical38-finite-engine-evidence.v1',archive=ref(archive),entries=[x['ref'] for n,x in sorted(files.items())],scope='Four existing and one new production Sources and exactly two actual B/A CLI receipts. The parent37 A24 proof is separately attributed; no cohort or new Native rerun by38. No historical ZIP recursion, raw Native capture, exe/core, annual output payload or blanket mathematical equivalence claim.'))
 summary=dict(t['summary_template']);summary.update(schema='src06-canonical-energy-report-initialization.v1',status='Genuine Source energy report initialization and live Which readings on the same actual equipment owners; actual B result recorded',producer=t['producer'],independent_peer=t['independent_peer'],complete_compiler_plan=t['complete_plan'],accepted_parent_review=t['accepted_parent_review'],accepted_parent_plan=t['accepted_parent_plan'],canonical_B_CLI=actual['actual_B'],canonical_A24_CLI=actual['actual_A24'],Root_actual_review=ar,actual_B_completed=bcompleted,actual_B_result=bresult,canonical_A24_completed_Source_run=True,accepted_A24_proof_transfer=dict(accepted37_proof=actual['accepted37_full5352_proof'],series=58,samples=5352,physical_files_whole_equal37=len(actual['whole_physical_streams_equal37']),CSV_files_whole_equal37=2,scope='Accepted37 A24 proof transfer. No new Native/72H/annual or internal-state comparison.'),archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),publisher_Source=ref(Path(__file__)),Native_BND_reported_IO_comparison=native,Native_BND_qualification='Entire reported BND body only, with only the exact two engine-specific Program Version first lines excluded. Retained genuine Native21 capture and finite whole BND copy; no new engine run or internal thermodynamic Node-state equivalence claim.')
 sp=PUBLIC/'summary.json';write_json(sp,summary);relative='evidence/SRC-06-canonical-energy-report-initialization-38/summary.json'
 for n,b in docs.items():
  link='../'+relative if n.startswith('cards/') else relative;text=t['doc_appends'][n].replace('{{actual_B_result}}',bresult)
  append='\n\n[Source38 energy report initialization]('+link+'). '+text+'\n'
  assert '\ufffd' not in append and '{{' not in append and (base/n).read_bytes()==b;(base/n).write_bytes(b+append.encode('utf-8'))
 after=json.loads(oldplan);task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_energy_report_initialization_38';assert key not in task
 task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=ref(sp)['sha256'],size_bytes=sp.stat().st_size);inverse=json.loads(json.dumps(after));del next(x for x in inverse['tasks'] if x['id']=='SRC-06')[key];assert inverse==oldvalue and pp.read_bytes()==oldplan;write_json(pp,after)
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(archive),archive_manifest=ref(manifest),archive_entries=len(files),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),actual_engine_CLI_receipts=2,actual_test_bodies_executed_by38=0,Cargo_Native_or_tests_executed=False,gate_changes=False,Git_mutated=False)
 p=BACK/'publication-readback.json';write_json(p,result);print(json.dumps(ref(p)))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--template',required=True);ap.add_argument('--actual-sha',required=True);ap.add_argument('--publish',action='store_true');main(ap.parse_args())

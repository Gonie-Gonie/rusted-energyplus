"""Seal01 successor: account explicitly for formatter-added optional trailing commas."""
from pathlib import Path

path=Path('.runtime/porting/SRC-06/seal-source-report-input-Root-01.py')
source=path.read_text(encoding='utf-8')
old='def tokens(text):return re.findall(r\'"(?:\\\\.|[^"\\\\])*"|[A-Za-z_][A-Za-z_0-9]*|\\d+|[^\\s]\',text)'
assert source.count(old)==1
new='''def tokens(text):
    result=re.findall(r'"(?:\\\\.|[^"\\\\])*"|[A-Za-z_][A-Za-z_0-9]*|\\d+|[^\\s]',text)
    # cargo fmt adds these commas when a signature/call wraps to multiple lines.
    return [value for index,value in enumerate(result)
            if not (value==',' and index+1<len(result) and result[index+1] in [')',']','}'])]
'''
source=source.replace(old,new)
source=source.replace("'IP_context_getter_tokens_unchanged_from_preparation':True", "'IP_context_getter_tokens_equal_after_optional_trailing_comma_normalization':True")
source=source.replace("'seal-source-report-input-Root-01.py'", "'seal-source-report-input-Root-01.py'")
source=source.replace("'extend-source-scan-context-test-Root-01.py',Path(__file__).name", "'extend-source-scan-context-test-Root-01.py','seal-source-report-input-Root-01.py',Path(__file__).name")
exec(compile(source,str(path),'exec'),{'__file__':str(Path(__file__)),'__name__':'__main__'})

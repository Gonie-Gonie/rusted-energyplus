"""Independently compare the entire held metadata table with literal 26.1 schema."""
import hashlib
import json
import re
from pathlib import Path

OUT = Path('.runtime/porting/SRC-06/Root-shared-input-schema-review-01')
PACKET = Path('.runtime/porting/SRC-06/ordinary-input-processor-schema-prep-03')

def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': path.as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def main():
    assert not OUT.exists()
    OUT.mkdir(parents=True)
    manifest_path = PACKET / 'manifest.json'
    manifest = json.loads(manifest_path.read_bytes())
    refs = []
    def verify(obj):
        if isinstance(obj, dict):
            if {'path', 'sha256', 'size_bytes'} <= obj.keys():
                actual = ref(obj['path'])
                assert actual == {key: obj[key] for key in actual}, obj['path']
                refs.append(actual)
            else:
                for value in obj.values(): verify(value)
        elif isinstance(obj, list):
            for value in obj: verify(value)
    verify(manifest)
    official = json.loads(Path(manifest['schema_authority']['path']).read_bytes())['properties']
    excerpt = json.loads(Path(manifest['literal_legacy_idd_excerpt']['path']).read_bytes())
    old = json.loads(Path(manifest['parent_literal_legacy_idd_excerpt']['path']).read_bytes())
    assert len(excerpt) == 87 and len(old) == 60
    for name, value in excerpt.items(): assert value == official[name]['legacy_idd'], name
    assert all(excerpt[name] == value for name, value in old.items())
    proposal = Path(manifest['changes'][0]['proposed']['path']).read_text(encoding='utf-8')
    pattern = r'^\s*\("([^"]+)", (\d+), (\d+), (\d+), (\d+), (None|Some\("[^"]+"\))\),$'
    rows = re.findall(pattern, proposal, re.M)
    assert len(rows) == 87
    assert [row[0] for row in rows] == sorted(excerpt)
    for name, a, n, ae, ne, extension in rows:
        value = official[name]['legacy_idd']
        assert tuple(map(int, (a,n,ae,ne))) == (
            len(value['alphas']['fields']), len(value['numerics']['fields']),
            len(value['alphas'].get('extensions',[])), len(value['numerics'].get('extensions',[]))), name
        assert extension == ('Some(' + json.dumps(value['extension']) + ')' if 'extension' in value else 'None'), name
    inverse = ''.join(line for line in proposal.splitlines(keepends=True)
                      if not any(line.lstrip().startswith('(' + json.dumps(name) + ',') for name in set(excerpt)-set(old)))
    parent = Path(manifest['changes'][0]['parent_proposed']['path']).read_text(encoding='utf-8')
    canonical = Path(manifest['changes'][0]['canonical_path']).read_text(encoding='utf-8')
    # Canonical formatting has changed; the current sixty actual tuples must match.
    canonical_names = re.findall(r'\("([^"]+)"\s*,', canonical)
    # Multiline tuples have an opening '(' on the preceding line.
    canonical_names += re.findall(r'\(\s*\n\s*"([^"]+)"\s*,', canonical)
    assert len(canonical_names) == 60 and set(canonical_names) == set(old)
    assert inverse == parent
    review = {'schema':'src06-independent-schema-review.v1','accepted':True,
        'packet':ref(manifest_path),'checked_references':refs,'checked_complete_legacy_idd_subtrees':87,
        'parent_subtrees_unchanged':60,'added_metadata_definitions':27,
        'whole_parent_text_inverse_exact':True,'current_canonical_definition_names_match_parent':True,
        'scope':'Metadata only; no positive admission/runtime/Setup/numerical activation claim',
        'canonical_writes':False,'author':ref(__file__)}
    path = OUT / 'review.json'
    path.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(ref(path)))

if __name__ == '__main__': main()

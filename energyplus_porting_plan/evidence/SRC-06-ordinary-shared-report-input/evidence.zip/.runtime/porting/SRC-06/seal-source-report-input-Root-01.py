"""Freeze the complete actual shared-report-input assembly after formatting."""
import difflib
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT=Path.cwd()
BASE=Path('.runtime/porting/SRC-06')
OUT=BASE/'ordinary-source-report-input-assembly-01'

def ref(path):
    path=Path(path)
    data=path.read_bytes()
    return {'path':path.as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path):return json.loads(Path(path).read_bytes())
def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def tokens(text):return re.findall(r'"(?:\\.|[^"\\])*"|[A-Za-z_][A-Za-z_0-9]*|\d+|[^\s]',text)

assert not (OUT/'manifest.json').exists()
head=subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip()
rows=[]
for index,row in enumerate(load(OUT/'before-rows.json')):
    target=Path(row['canonical_path'])
    before_path=Path(row['before_path']) if row['before_path'] else None
    before=before_path.read_bytes() if before_path else b''
    original=subprocess.run(['git','show',head+':'+target.as_posix()],capture_output=True)
    if before_path:assert original.returncode==0 and original.stdout==before,target
    else:assert original.returncode!=0,target
    after=target.read_bytes()
    after_path=OUT/f'{index:02}.after'
    after_path.write_bytes(after)
    diff_path=OUT/f'{index:02}.diff'
    diff_path.write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='HEAD/'+target.as_posix() if before_path else '/dev/null',tofile=target.as_posix())),encoding='utf-8',newline='\n')
    old_count=len(re.findall(rb'#\[test\]',before)); new_count=len(re.findall(rb'#\[test\]',after))
    assert old_count==new_count,(target,old_count,new_count)
    rows.append({'canonical':ref(target),'before':ref(before_path) if before_path else None,
        'after':ref(after_path),'complete_diff':ref(diff_path),
        'test_bodies_before':old_count,'test_bodies_after':new_count})
parent=BASE/'ordinary-source-report-scan-prep-03/proposed/crates/ep_runtime/src/heat_balance'
proposed=(parent/'report_scan.rs').read_text(encoding='utf-8')
actual=Path('crates/ep_runtime/src/heat_balance/report_scan.rs').read_text(encoding='utf-8')
child=Path('crates/ep_runtime/src/heat_balance/report_scan/request.rs').read_text(encoding='utf-8')
old_selector=proposed[proposed.index('    let mut do_report = false;'):proposed.index('\n#[cfg(test)]')]
new_selector=child[child.index('    let mut do_report = false;'):]
assert tokens(old_selector)==tokens(new_selector)
old_copier=proposed[proposed.index('fn copy_options('):proposed.index('/// Executes actual cache')]
new_copier=child[child.index('fn copy_options('):child.index('pub(super) fn select<E>')]
assert tokens(old_copier)==tokens(new_copier)
old_start=proposed.index('    if state.get_report_input {',proposed.index('fn try_scan_for_reports_inner<E>'))
new_start=actual.index('    if state.get_report_input {',actual.index('fn try_scan_for_reports_inner<E>'))
assert tokens(proposed[old_start:proposed.index('    let mut do_report = false;',old_start)])==tokens(actual[new_start:actual.index('    request::select',new_start)])
for name in ['selected_input_processor.rs','ctf_initialization_context.rs','report_scan/source_input.rs']:
    assert tokens((parent/name).read_text(encoding='utf-8'))==tokens((Path('crates/ep_runtime/src/heat_balance')/name).read_text(encoding='utf-8')),name
production_parent_lines=actual[:actual.index('#[cfg(test)]')].count('\n')
assert production_parent_lines<=400,production_parent_lines
manifest={'schema':'src06-shared-report-input-canonical-assembly.v1','baseline_head':head,
    'status':'Actual shared report input getters connected; full startup/Setup remains incomplete',
    'files':rows,'scan_preparation':ref(BASE/'ordinary-source-report-scan-prep-03/manifest.json'),
    'schema_preparation':ref(BASE/'ordinary-input-processor-schema-prep-03/manifest.json'),
    'schema_independent_review':ref(BASE/'Root-shared-input-schema-review-01/review.json'),
    'Root_author_scripts':[ref(BASE/name) for name in ['apply-source-report-input-Root-01.py','extend-source-scan-context-test-Root-01.py',Path(__file__).name]],
    'extraction_before_format':ref(OUT/'exact-extraction-proof.json'),
    'final_token_proofs':{'cached_request_selector_unchanged':True,'option_copier_unchanged':True,
        'entire_first_scan_cache_body_unchanged_from_reviewed_preparation':True,
        'IP_context_getter_tokens_unchanged_from_preparation':True},
    'production_parent_lines':production_parent_lines,'new_test_bodies':0,'new_binaries':0,
    'gates_updated':False,'full_unused_input_reporting_parity':False,'Native_numerical_parity':False}
write(OUT/'manifest.json',manifest)
print(json.dumps(ref(OUT/'manifest.json')))

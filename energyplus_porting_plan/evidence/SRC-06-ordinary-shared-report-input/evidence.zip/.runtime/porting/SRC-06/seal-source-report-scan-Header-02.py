"""Preserve Source01 and add only two explicit local argument lint expectations."""
from pathlib import Path
import json,hashlib,difflib
P=Path('.runtime/porting/SRC-06/ordinary-source-report-scan-prep-01')
O=Path('.runtime/porting/SRC-06/ordinary-source-report-scan-prep-02')
assert not O.exists()
def ref(p):
    p=Path(p);b=p.read_bytes();return {'path':p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8'))
m=json.loads((P/'manifest.json').read_bytes());files=[]
attribute='#[expect(clippy::too_many_arguments, reason = "Preserve original report request and explicit shared input borrow")]\n'
for index,row in enumerate(m['files']):
    path=row['canonical_path'];raw=Path(row['proposed']['path']).read_bytes();t=raw.decode('utf-8')
    if path.endswith('/report_scan.rs'):
        for anchor in ['pub(crate) fn try_scan_for_reports_with_input<E>(', 'fn try_scan_for_reports_inner<E>(']:
            assert t.count(anchor)==1;t=t.replace(anchor,attribute+anchor)
        assert t.replace(attribute,'').encode('utf-8')==raw
    else:assert t.encode('utf-8')==raw
    proposed=O/'proposed'/path;put(proposed,t)
    old_copy=O/'parent01'/path;old_copy.parent.mkdir(parents=True,exist_ok=True);old_copy.write_bytes(raw)
    d=O/f'{index:02d}-from-parent.diff';put(d,''.join(difflib.unified_diff(raw.decode('utf-8').splitlines(True),t.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
    base=Path(row['base']['path']).read_bytes() if 'base' in row else b''
    full=O/f'{index:02d}.diff';put(full,''.join(difflib.unified_diff(base.decode('utf-8').splitlines(True),t.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
    new=dict(row);new.update(proposed=ref(proposed),complete_diff=ref(full),parent_proposed=row['proposed'],parent_copy=ref(old_copy),exact_parent_diff=ref(d));files.append(new)
readme=O/'README.md';put(readme,(P/'README.md').read_bytes().decode('utf-8')+'\nSource02 adds only two narrow function-local Clippy too_many_arguments expectations, preserving original report operands plus explicit shared getter borrow. Complete reverse removal reproduces whole Source01 bytes. All other payloads, context integration and tests remain byte-exact01. No compiler/lint/targets executed; inherited broad module allowance is not expanded.\n')
m.update(schema='src06-actual-shared-report-input-scan-preparation.v2',parent_manifest=ref(P/'manifest.json'),files=files,README=ref(readme),author=ref(Path(__file__)),change='two local expected argument-count diagnostics only; runtime/query/test semantics exact01')
put(O/'manifest.json',json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(ref(O/'manifest.json')))

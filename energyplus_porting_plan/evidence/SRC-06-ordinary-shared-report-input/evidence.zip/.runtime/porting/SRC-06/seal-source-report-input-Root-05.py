"""Final assembly successor after correcting two existing-test module paths."""
from pathlib import Path

base=Path('.runtime/porting/SRC-06')
out=base/'ordinary-source-report-input-assembly-02'
assert not out.exists()
out.mkdir()
for name in ['before-rows.json','exact-extraction-proof.json']:
    (out/name).write_bytes((base/'ordinary-source-report-input-assembly-01'/name).read_bytes())
path=base/'seal-source-report-input-Root-04.py'
script=path.read_text(encoding='utf-8')
needle="source=path.read_text(encoding='utf-8')"
assert script.count(needle)==1
script=script.replace(needle,needle+".replace(\"OUT=BASE/'ordinary-source-report-input-assembly-01'\",\"OUT=BASE/'ordinary-source-report-input-assembly-02'\")")
script=script.replace("'seal-source-report-input-Root-03.py',Path(__file__).name", "'seal-source-report-input-Root-03.py','seal-source-report-input-Root-04.py',Path(__file__).name")
exec(compile(script,str(path),'exec'),{'__file__':str(Path(__file__)),'__name__':'__main__'})

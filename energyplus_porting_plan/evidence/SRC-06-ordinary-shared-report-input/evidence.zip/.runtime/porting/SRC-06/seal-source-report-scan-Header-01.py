"""Author finite consumed report-cache integration only; no canonical actions."""
from pathlib import Path
import difflib,hashlib,json
P=Path('.runtime/porting/SRC-06/ordinary-simulation-startup-checks-prep-01')
O=Path('.runtime/porting/SRC-06/ordinary-source-report-scan-prep-01')
assert not O.exists()
def ref(p):
    p=Path(p); b=p.read_bytes(); return {'path':p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def write(p,t):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.encode('utf-8'))
def js(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
parent=json.loads((P/'manifest.json').read_bytes())
paths=['crates/ep_runtime/src/heat_balance/selected_input_processor.rs','crates/ep_runtime/src/heat_balance/report_scan.rs','crates/ep_runtime/src/heat_balance/report_scan/source_input.rs']
for path in paths:
    p=O/'proposed'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((P/'proposed'/path).read_bytes())
    if (P/'before'/path).exists():
        b=O/'before'/path;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes((P/'before'/path).read_bytes())
path='crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs'
raw=Path(path).read_bytes(); text=raw.decode('utf-8')
old='        use super::report_scan::{ReportScanDiagnostic, ReportScanFailure, try_scan_for_reports};\n'
new='''        use super::report_scan::{ReportScanDiagnostic, ReportScanFailure,
            SourceReportScanInput, try_scan_for_reports, try_scan_for_reports_with_input};
'''
assert text.count(old)==1;text=text.replace(old,new)
old='''        let requested = try_scan_for_reports(
            input,
            &mut self.reports.scan,
            "EnergyManagementSystem",
            None,
            None,
            None,
            |diagnostic| match diagnostic {
                ReportScanDiagnostic::Warning(message) => self.backend.show_warning_error(&message),
                ReportScanDiagnostic::Continue(message) => {
                    self.backend.show_continue_error(&message)
                }
            },
        )
'''
new='''        let mut diagnostic = |diagnostic| match diagnostic {
            ReportScanDiagnostic::Warning(message) => self.backend.show_warning_error(&message),
            ReportScanDiagnostic::Continue(message) => self.backend.show_continue_error(&message),
        };
        let result = if let Some(actual_input) = self.reports.selected_input_processor.as_ref() {
            let mut source = SourceReportScanInput::new(actual_input,
                &mut self.reports.input_processor_shortcut, input)
                .map_err(|value| CtfInitializationError::Postlude(CtfInitPostludeError::Scan(value)))?;
            try_scan_for_reports_with_input(input, &mut self.reports.scan,
                "EnergyManagementSystem", None, None, None, &mut source, &mut diagnostic)
        } else {
            try_scan_for_reports(input, &mut self.reports.scan,
                "EnergyManagementSystem", None, None, None, &mut diagnostic)
        };
        let requested = result
'''
assert text.count(old)==1;text=text.replace(old,new)
old='''    /// or diagnostics; it is not relabelled as a newly reached preparation.
'''
new='''    /// or diagnostics; it is not relabelled as a newly reached preparation.
    /// With the admitted input owner, real reached getter writes use its sole
    /// complete shortcut; legacy callers without that owner keep their API.
'''
assert text.count(old)==1;text=text.replace(old,new)
write(O/'proposed'/path,text)
before=O/'before'/path;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw)
paths.append(path)
files=[]
for i,path in enumerate(paths):
    before=O/'before'/path; after=O/'proposed'/path
    a=before.read_bytes().decode('utf-8') if before.exists() else '';b=after.read_bytes().decode('utf-8')
    diff=O/f'{i:02d}.diff';write(diff,''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
    row={'canonical_path':path,'kind':'current-canonical-base' if before.exists() else 'new-child','proposed':ref(after),'complete_diff':ref(diff)}
    if before.exists():
        row['base']=ref(before)
        assert before.read_bytes()==Path(path).read_bytes()
    files.append(row)
relevant={'General.cc','InputProcessing/InputProcessor.cc'}
original=[row for row in parent['Original_ranges'] if any(row['Original']['path'].endswith('/'+suffix) for suffix in relevant)]
readme='''# Actual shared input effects in the consumed report cache

Held Source-only integration, not applied/formatted/compiled/tested. Four files: one exact-case section accessor on the sole InputProcessor, existing report_scan wrappers/cache with one expanded existing test, a concrete small input bridge child, and the actual CtfInitializationContext.prepare_report_input_cache consumer.

The actual context path uses the admitted input and sole full shortcut when Some; legacy None keeps the same wrapper. Its existing early cached return preserves all scratch arrays. The five report-family queries, true intervening legacy section lookup and complete six-array getObjectItem resets occur at the existing actual source order. First warning/backend failure stops before the later getter with its written prefix retained. Typed report defaults/blanks/num_alphas/is_epjson come from the existing same-admission projection. No duplicate schema/table/admission list or report cache exists.

The unchanged public Scan APIs and existing no-EMS warning suffix remain; this is a consumed scratch/query prerequisite, not activation or a claim about the complete EMS/startup/RunSimulation/Setup producer. IP unusedInputs bookkeeping is outside this unit. Existing single first-scan test expands full numeric/alpha scratch, blank/default/label writes, exact-case absent/null section sizes, cache retention including signed zero, and a genuine transport error boundary. No new test body/binary/framework is added.

All three IP/report Source payloads are byte-exact the pinned startup held packet. The canonical context base is archived separately; the complete new startup and globals modules are not included or activated here. Root may combine this consumed unit with the independently reviewed single schema87 metadata successor.
'''
write(O/'README.md',readme)
js(O/'manifest.json',{'schema':'src06-actual-shared-report-input-scan-preparation.v1','status':'held-consumed-context-integration-not-applied-or-executed','files':files,'startup_source_parent':ref(P/'manifest.json'),'same_report_and_IP_payloads_as_parent':True,'Original_ranges':original,'schema87_dependency':ref('.runtime/porting/SRC-06/ordinary-input-processor-schema-prep-03/manifest.json'),'README':ref(O/'README.md'),'author':ref(Path(__file__)),'public_legacy_Scan_signatures_preserved':True,'new_test_bodies':0,'startup_or_EMS_activation':False,'canonical_writes':False,'compiler_formatter_tests_engine_or_Native_executed':False,'gates_updated':False})
print(json.dumps(ref(O/'manifest.json')))

"""Emit only a held metadata-table/excerpt successor; no canonical/runtime execution."""
import difflib
import hashlib
import json
import re
from pathlib import Path

ROOT = Path.cwd()
OUT = Path('.runtime/porting/SRC-06/ordinary-input-processor-schema-prep-03')
PARENT = Path('.runtime/porting/SRC-06/ordinary-input-processor-prep-02')
GAIN = Path('.runtime/porting/SRC-06/ordinary-init-surface-gain-chain-prep-01/proposed/crates/ep_runtime/src/heat_balance')
TARGET = 'crates/ep_run/src/ordinary_input_processor/schema.rs'

def ref(path):
    data = Path(path).read_bytes()
    return {'path': Path(path).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode('utf-8') if isinstance(data, str) else data)
    return ref(path)

def save(path, obj):
    return write(path, json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def families(path, name, count):
    text = path.read_text(encoding='utf-8')
    body = re.search(r'const ' + name + r': \[&\x27static str; ' + str(count) + r'\] = \[(.*?)\];', text, re.S)
    assert body, (path, name)
    values = re.findall(r'"([^"]+)"', body.group(1))
    assert len(values) == count and len(set(values)) == count
    return values

def main():
    assert not (OUT / 'manifest.json').exists()
    parent = json.loads((PARENT / 'manifest.json').read_bytes())
    old = json.loads(Path(parent['literal_legacy_idd_excerpt']['path']).read_bytes())
    schema_path = Path(parent['schema_authority']['path'])
    assert ref(schema_path) == parent['schema_authority']
    official = json.loads(schema_path.read_bytes())['properties']
    ihg_path, refri_path = GAIN / 'ordinary_equipment.rs', GAIN / 'empty_internal_gain_providers.rs'
    ihg = families(ihg_path, 'INTERNAL_GAIN_FAMILIES', 10)
    refri = families(refri_path, 'FAMILIES', 18)
    names = sorted(set(old) | set(ihg) | set(refri))
    assert len(old) == 60 and len(names) == 87
    selected = {name: official[name]['legacy_idd'] for name in names}
    assert {name: selected[name] for name in old} == old
    before = (PARENT / 'proposed' / TARGET).read_text(encoding='utf-8')
    tuples = []
    for name, item in selected.items():
        a, n = item['alphas'], item['numerics']
        extension = 'Some(' + json.dumps(item['extension']) + ')' if 'extension' in item else 'None'
        tuples.append(f'        ({json.dumps(name)}, {len(a["fields"])}, {len(n["fields"])}, {len(a.get("extensions", []))}, {len(n.get("extensions", []))}, {extension}),\n')
    start = before.index('    [\n') + len('    [\n')
    end = before.index('    ].into_iter()')
    after = before[:start] + ''.join(tuples) + before[end:]
    # Removing only newly authored tuples restores the complete parent text.
    inverse = ''.join(line for line in after.splitlines(keepends=True)
                      if not any(line.startswith('        (' + json.dumps(name) + ',') for name in set(names) - set(old)))
    assert inverse == before
    proposed = write(OUT / 'proposed' / TARGET, after)
    delta = write(OUT / 'schema.rs.parent.diff', ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='IP02/' + TARGET, tofile='IP-schema03/' + TARGET)))
    excerpt = save(OUT / 'legacy-idd-excerpt.json', selected)
    old_excerpt = Path(parent['literal_legacy_idd_excerpt']['path']).read_text(encoding='utf-8')
    excerpt_delta = write(OUT / 'legacy-idd-excerpt.parent.diff', ''.join(difflib.unified_diff(old_excerpt.splitlines(True), (OUT / 'legacy-idd-excerpt.json').read_text(encoding='utf-8').splitlines(True), fromfile='IP02/legacy-idd-excerpt.json', tofile='IP-schema03/legacy-idd-excerpt.json')))
    readme = write(OUT / 'README.md', '''# Held shared InputProcessor schema extension

This packet adds only the actual legacy_idd definition metadata required by the reached internal-gain and empty refrigeration getters. The same sole schema table grows from 60 to 87 definitions: nine additional internal-gain families (OtherEquipment was already present) and eighteen refrigeration families. Both original declaration-order lists are retained in the manifest; the table remains lexically sorted.

Every complete legacy_idd subtree is copied from the authenticated EnergyPlus 26.1.0 schema. All sixty parent subtrees are unchanged. Removing the twenty-seven new tuple lines restores the complete parent schema module text exactly. The full schema module and complete excerpt diffs are included.

This does not add a positive input admission family, a second schema table, a synthetic count, or a runtime owner. The raw resolver and runtime InputProcessor semantics remain the separately reviewed IP02 dependency; Root's visibility/documentation-only shortcut successor is a separate disjoint change. Owner's gain and refrigeration getter successor consumes these definitions through that same mutable InputProcessor.

Held source only: no canonical file, compiler, formatter, tests, engine, or gate changed. Registration and application require the coherent real caller integration.
''')
    manifest = {
        'schema': 'src06-shared-input-processor-schema-extension.v1',
        'status': 'held-source-only-not-applied-or-executed',
        'parent_preparation': ref(PARENT / 'manifest.json'),
        'changes': [{'canonical_path': TARGET, 'parent_proposed': ref(PARENT / 'proposed' / TARGET), 'proposed': proposed, 'complete_parent_diff': delta}],
        'schema_authority': parent['schema_authority'],
        'parent_literal_legacy_idd_excerpt': parent['literal_legacy_idd_excerpt'],
        'literal_legacy_idd_excerpt': excerpt, 'complete_excerpt_parent_diff': excerpt_delta,
        'family_declaration_sources': [ref(ihg_path), ref(refri_path)],
        'actual_internal_gain_definition_query_order': ihg,
        'actual_refrigeration_count_query_order': refri,
        'parent_definition_count': 60, 'definition_count': 87,
        'added_definitions': sorted(set(names) - set(old)),
        'all_parent_subtrees_exact': True, 'whole_parent_module_inverse_exact': True,
        'positive_admission_changed': False, 'runtime_or_raw_projection_changed': False,
        'README': readme, 'author': ref(Path(__file__)),
        'canonical_writes': False, 'compiler_formatter_tests_engine_or_Native_executed': False, 'gates_updated': False,
    }
    print(json.dumps(save(OUT / 'manifest.json', manifest)))

if __name__ == '__main__':
    main()

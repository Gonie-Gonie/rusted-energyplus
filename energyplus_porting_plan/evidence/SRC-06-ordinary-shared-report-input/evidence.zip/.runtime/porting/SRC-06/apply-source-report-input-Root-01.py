"""Apply reviewed shared report getters, their metadata, and a bounded exact extraction."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT=Path.cwd()
BASE=Path('.runtime/porting/SRC-06')
SCAN=BASE/'ordinary-source-report-scan-prep-03'
SCHEMA=BASE/'ordinary-input-processor-schema-prep-03'
OUT=BASE/'ordinary-source-report-input-assembly-01'

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verified(row):
    path=Path(row['path'])
    assert digest(path)==row['sha256'] and path.stat().st_size==row['size_bytes'],row['path']
    return path

assert not OUT.exists()
assert subprocess.run(['git','status','--porcelain'],check=True,capture_output=True).stdout==b''
assert digest(SCAN/'manifest.json')=='1fc64c89abddf68476b4fda88285dcdf2715a925b9a2781f0251ae128f60fe6a'
assert digest(SCHEMA/'manifest.json')=='553558ce7fc17506746e62dfae00ada1689aaa150e44dd3d191ab4b2eb1a215f'
scan=json.loads((SCAN/'manifest.json').read_bytes())
schema=json.loads((SCHEMA/'manifest.json').read_bytes())
rows=[]
for row in scan['files']:
    path=Path(row['canonical_path'])
    if row.get('base'):
        before=verified(row['base']).read_bytes()
        assert path.read_bytes()==before,path
    else:
        assert not path.exists(),path
        before=None
    rows.append((path,before,verified(row['proposed']).read_bytes()))
schema_row=schema['changes'][0]
schema_path=Path(schema_row['canonical_path'])
rows.append((schema_path,schema_path.read_bytes(),verified(schema_row['proposed']).read_bytes()))
test=Path('crates/ep_runtime/src/heat_balance/ctf_geometry_reports_tests.rs')
rows.append((test,test.read_bytes(),test.read_bytes()))
request=Path('crates/ep_runtime/src/heat_balance/report_scan/request.rs')
assert not request.exists()
rows.append((request,None,None))
OUT.mkdir(parents=True)
before_rows=[]
for number,(path,before,after) in enumerate(rows):
    before_path=OUT/f'{number:02}.before'
    if before is not None:before_path.write_bytes(before)
    before_rows.append({'canonical_path':path.as_posix(),'before_path':before_path.as_posix() if before is not None else None})
    if after is not None:
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(after)
(OUT/'before-rows.json').write_text(json.dumps(before_rows,indent=2)+'\n',encoding='utf-8',newline='\n')

# Move the unchanged request selection and option copier to a bounded child.
# This leaves the parent focused on actual first-scan getter/cache ordering.
path=Path('crates/ep_runtime/src/heat_balance/report_scan.rs')
text=path.read_text(encoding='utf-8')
copy_start=text.index('fn copy_options(')
copy_end=text.index('/// Executes actual cache',copy_start)
copier=text[copy_start:copy_end]
inner=text.index('fn try_scan_for_reports_inner<E>')
start=text.index('    let mut do_report = false;',inner)
end=text.index('\n#[cfg(test)]',start)
selector=text[start:end]
assert selector.endswith('}\n')
child='''//! Unchanged cached report request selection; first-scan effects stay in the parent.
use super::{ReportScanFailure, ReportScanState, ReportScanUnavailable};

'''+copier+'''pub(super) fn select<E>(
    state: &ReportScanState,
    report_name: &str,
    report_key: Option<&str>,
    mut option1: Option<&mut String>,
    mut option2: Option<&mut String>,
) -> Result<bool, ReportScanFailure<E>> {
'''+selector
request.write_text(child,encoding='utf-8',newline='\n')
text=text[:start]+'''    request::select(state, report_name, report_key, option1, option2)
}
'''+text[end:]
text=text[:copy_start]+text[copy_end:]
assert text.count('mod source_input;')==1
text=text.replace('mod source_input;','mod request;\nmod source_input;')
inner=text.index('fn try_scan_for_reports_inner<E>')
body=text.index(') -> Result<bool, ReportScanFailure<E>> {',inner)
signature=text[inner:body].replace('mut option1:','option1:').replace('mut option2:','option2:')
text=text[:inner]+signature+text[body:]
path.write_text(text,encoding='utf-8',newline='\n')
(OUT/'exact-extraction-proof.json').write_text(json.dumps({
    'selector_before_sha256':hashlib.sha256(selector.encode()).hexdigest(),
    'copier_before_sha256':hashlib.sha256(copier.encode()).hexdigest(),
    'selector_exact_bytes_in_unformatted_child':selector in child,
    'copier_exact_bytes_in_unformatted_child':copier in child,
    'reason':'Keep report scan production parent below400 lines without new LOC debt',
    'caller':'same cache body, same five arguments, same generic failure type',
},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Applied7 reviewed payloads; extracted identical cached request code; context regression extension is next.')

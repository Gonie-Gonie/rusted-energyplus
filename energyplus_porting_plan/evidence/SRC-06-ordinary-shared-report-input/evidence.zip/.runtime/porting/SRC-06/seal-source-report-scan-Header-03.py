"""Retain true raw object identities and reached unusedInputs erase; Source only."""
from pathlib import Path
import difflib,hashlib,json
P=Path('.runtime/porting/SRC-06/ordinary-source-report-scan-prep-02')
O=Path('.runtime/porting/SRC-06/ordinary-source-report-scan-prep-03')
assert not O.exists()
def ref(p):
    p=Path(p);b=p.read_bytes();return {'path':p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'size_bytes':len(b)}
def put(p,t):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.encode('utf-8'))
def replace(t,a,b):
    assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
m=json.loads((P/'manifest.json').read_bytes());sources={}
for row in m['files']:sources[row['canonical_path']]=Path(row['proposed']['path']).read_bytes().decode('utf-8')
ip_path='crates/ep_runtime/src/heat_balance/selected_input_processor.rs'
t=sources[ip_path]
t=replace(t,'use std::collections::BTreeMap;','use std::collections::{BTreeMap, BTreeSet};')
t=replace(t,'pub struct SourceObjectShape {\n','''pub struct SourceObjectShape {
    /// Exact original epJSON object-map key, including case and blank spelling.
    pub object_name: String,
''')
t=replace(t,'    families: BTreeMap<String, SourceInputFamily>,\n}\n','''    families: BTreeMap<String, SourceInputFamily>,
    // Source initializeMaps/ObjectInfo lexicographic exact-case identity owner.
    unused_inputs: BTreeSet<(String, String)>,
}
''')
t=replace(t,'    /// Rejects duplicate/empty schema identities or an unrepresented present family.\n','    /// Rejects duplicate schema/object identities or an unrepresented present family.\n')
t=replace(t,'''        Ok(Self {
            definitions: by_name,
            families,
        })''','''        let mut unused_inputs = BTreeSet::new();
        for (object_type, family) in &families {
            if let SourceInputFamily::Objects(objects) = family {
                for object in objects {
                    if !unused_inputs.insert((object_type.clone(), object.object_name.clone())) {
                        return Err(SelectedInputUnavailable::Association);
                    }
                }
            }
        }
        Ok(Self {
            definitions: by_name,
            families,
            unused_inputs,
        })''')
anchor='    /// Actual presence, including null insertion, is observable by subsequent getters.\n'
methods='''    /// Inspect permanent exact-case raw identity, including an already used object.
    /// This does not consult or mutate the distinct unusedInputs owner.
    pub fn has_object(&self, object_type: &str, object_name: &str) -> bool {
        match self.families.get(object_type) {
            Some(SourceInputFamily::Objects(objects)) => objects.iter()
                .any(|object| object.object_name == object_name),
            Some(SourceInputFamily::Null) | None => false,
        }
    }

    /// Actual markObjectAsUsed exact-case erase; absent/already-used is a no-op.
    pub fn mark_object_as_used(&mut self, object_type: &str, object_name: &str) {
        self.unused_inputs.remove(&(object_type.into(), object_name.into()));
    }

    /// Inspect the actual remaining exact-case unused object identity.
    /// False for an absent or already-consumed object, not a readiness decision.
    pub fn is_object_unused(&self, object_type: &str, object_name: &str) -> bool {
        self.unused_inputs.contains(&(object_type.into(), object_name.into()))
    }

'''
t=replace(t,anchor,methods+anchor);sources[ip_path]=t

child_path='crates/ep_runtime/src/heat_balance/report_scan/source_input.rs';t=sources[child_path]
assert t.count("input: &'a crate::heat_balance::selected_input_processor::SelectedInputProcessor")==2
t=t.replace("input: &'a crate::heat_balance::selected_input_processor::SelectedInputProcessor","input: &'a mut crate::heat_balance::selected_input_processor::SelectedInputProcessor")
anchor='            if raw_count != count { return Err(ReportScanUnavailable::SourceInputAssociation); }\n'
extra='''            for (index, object) in reports.objects.iter().enumerate()
                .filter(|(_, object)| object.object_type == kind) {
                if !input.has_object(kind.source_name(), &object.object_name)
                    || reports.objects[..index].iter().any(|prior|
                        prior.object_type == kind && prior.object_name == object.object_name)
                { return Err(ReportScanUnavailable::SourceInputAssociation); }
            }
'''
t=replace(t,anchor,anchor+extra)
anchor='        self.shortcut.numeric_field_names.fill(String::new());\n'
extra='''        // Source1026-1029 erases this exact object AFTER all six resets and
        // BEFORE writing any field. Earlier/later objects keep their own state.
        self.input.mark_object_as_used(object.object_type.source_name(), &object.object_name);
'''
t=replace(t,anchor,anchor+extra);sources[child_path]=t

context_path='crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs'
sources[context_path]=replace(sources[context_path],
'let result = if let Some(actual_input) = self.reports.selected_input_processor.as_ref()',
'let result = if let Some(actual_input) = self.reports.selected_input_processor.as_mut()')

report_path='crates/ep_runtime/src/heat_balance/report_scan.rs';t=sources[report_path]
t=replace(t,'.map(|_| SourceObjectShape { field_sizes: BTreeMap::new() })',
'.map(|row| SourceObjectShape { object_name: row.object_name.clone(), field_sizes: BTreeMap::new() })')
t=replace(t,'SourceInputFamily::Objects(vec![SourceObjectShape { field_sizes: BTreeMap::new() }])',
'SourceInputFamily::Objects(vec![SourceObjectShape { object_name: "authored Building".into(), field_sizes: BTreeMap::new() }])')
assert t.count('SourceReportScanInput::new(&source,')==3
t=t.replace('SourceReportScanInput::new(&source,','SourceReportScanInput::new(&mut source,')
t=replace(t,'        let source = source_input(&failing)?;\n','        let mut source = source_input(&failing)?;\n')
anchor='        assert_eq!(reached, state);\n'
extra='''        for object in &reports.objects {
            assert!(source.has_object(object.object_type.source_name(), &object.object_name));
            assert!(!source.is_object_unused(object.object_type.source_name(), &object.object_name));
        }
        assert!(source.is_object_unused("Building", "authored Building"));
        assert!(!source.is_object_unused("building", "authored Building"));
        source.mark_object_as_used("Building", "not an actual object");
        assert!(source.is_object_unused("Building", "authored Building"));
'''
t=replace(t,anchor,anchor+extra)
t=replace(t,'        let retained = shortcut.clone();\n','        let retained = shortcut.clone();\n        let retained_input = source.clone();\n')
t=replace(t,'        assert_eq!(shortcut, retained);\n','        assert_eq!(shortcut, retained);\n        assert_eq!(source, retained_input);\n')
anchor='        assert!(reached.get_report_input && !reached.dxf_wireframe && !reached.constructions);\n'
extra='''        assert!(!source.is_object_unused("Output:Surfaces:List", &failing.objects[0].object_name));
        for object in &failing.objects[1..] {
            assert!(source.is_object_unused(object.object_type.source_name(), &object.object_name));
        }
'''
t=replace(t,anchor,anchor+extra)
anchor='''        assert_eq!(shortcut.numeric_field_blanks, [true; 5]);
        Ok(())
'''
extra='''        // An equal family count with an incorrect permanent name is rejected
        // before any scratch/unused mutation. Already-used correct names above
        // stayed valid for the cached scan because validation is not on unused.
        let before_input = source.clone();
        let before_scratch = shortcut.clone();
        let mut wrong_identity = failing.clone();
        wrong_identity.objects[0].object_name = "not present in the raw map".into();
        assert!(matches!(SourceReportScanInput::new(&mut source, &mut shortcut, &wrong_identity),
            Err(ReportScanUnavailable::SourceInputAssociation)));
        assert_eq!(source, before_input);
        assert_eq!(shortcut, before_scratch);
'''
t=replace(t,anchor,'        assert_eq!(shortcut.numeric_field_blanks, [true; 5]);\n'+extra+'        Ok(())\n');sources[report_path]=t

raw_path='crates/ep_run/src/ordinary_input_processor.rs';t=Path(raw_path).read_bytes().decode('utf-8')
t=replace(t,'''            let shapes = objects
                .values()
                .map(|object| SourceObjectShape {
''','''            let shapes = objects
                .iter()
                .map(|(name, object)| SourceObjectShape {
                    object_name: name.0.clone(),
''');sources[raw_path]=t
test_path='crates/ep_run/src/ordinary_input_processor_tests.rs';t=Path(test_path).read_bytes().decode('utf-8')
anchor='    assert_eq!(shapes[0].field_sizes["diagnostics"], 5);\n'
t=replace(t,anchor,anchor+'    assert_eq!(shapes[0].object_name, "d");\n    assert!(input.has_object("Output:Diagnostics", "d"));\n    assert!(input.is_object_unused("Output:Diagnostics", "d"));\n    assert!(!input.has_object("Output:Diagnostics", "D"));\n');sources[test_path]=t

files=[]
parent_by_path={r['canonical_path']:r for r in m['files']}
for i,(path,text) in enumerate(sources.items()):
    proposed=O/'proposed'/path;put(proposed,text)
    if path in parent_by_path:
        row=parent_by_path[path]; parent_raw=Path(row['proposed']['path']).read_bytes()
        old=O/'parent02'/path;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(parent_raw)
        base=Path(row['base']['path']).read_bytes() if 'base' in row else None
    else:
        parent_raw=Path(path).read_bytes();old=O/'parent02'/path;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(parent_raw);base=parent_raw
    parentdiff=O/f'{i:02d}-from-parent.diff';put(parentdiff,''.join(difflib.unified_diff(parent_raw.decode('utf-8').splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
    full=O/f'{i:02d}.diff';put(full,''.join(difflib.unified_diff((base or b'').decode('utf-8').splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
    new={'canonical_path':path,'proposed':ref(proposed),'complete_diff':ref(full),'parent_source':ref(old),'exact_parent_diff':ref(parentdiff)}
    if base is not None:
        b=O/'before'/path;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(base);new['base']=ref(b)
        assert base==Path(path).read_bytes()
    files.append(new)
extra_original=[]
root=Path('.reference/energyplus-src/26.1.0/src/EnergyPlus')
for name,first,last in [('InputProcessing/InputProcessor.cc',216,246),('InputProcessing/InputProcessor.hh',202,225),('InputProcessing/InputProcessor.cc',953,972),('InputProcessing/InputProcessor.cc',1011,1031)]:
    src=root/name;data=src.read_bytes();a=O/'Original'/f'{name.replace("/","_")}-{first}-{last}.txt';a.parent.mkdir(parents=True,exist_ok=True);a.write_bytes(b''.join(data.splitlines(keepends=True)[first-1:last]));extra_original.append({'Original':ref(src),'first_line':first,'last_line':last,'literal_archive':ref(a)})
readme=O/'README.md';put(readme,'''# Shared report getter Source03

Held-only successor of immutable02. Source03 adds the required actual unusedInputs owner and reached erase in addition to the complete scratch/cache effects. It has not been applied, formatted, compiled or executed.

Raw projection retains each exact original object-map name. SelectedInputProcessor initializes one sorted exact-case (family,name) unused set from all actual families at initializeMaps; duplicate constructor identities are rejected rather than collapsed. Permanent names remain only on the existing family shape rows. has_object inspects that permanent storage; is_object_unused inspects the separate true unused owner; mark_object_as_used is exact-case and absent/already-used is a no-op. There is no second permanent name index or borrowed count table.

The concrete report bridge borrows the sole input mutably. Before writes it validates every typed report's permanent exact name membership, complete per-family count and duplicate identity rejection; already-used names remain valid. At each actual getObjectItem it resets all six complete arrays, erases the exact current identity, then writes fields/defaults/blanks/labels in source order. A warning failure retains that erase and scratch/cache prefix while later families remain unused. Cached scans do not erase or rewrite anything. Context consumes this true Some route; legacy None remains unchanged.

The same existing report test and raw-input helper are expanded in place: raw name case, consumed versus later unused objects, cached complete input/scratch retention, unknown-name rejection before mutation and actual error boundary. No new test bodies or framework. All inherited02 logic, public Scan signatures and local argument expectations remain; complete parent diffs show every change. This covers actual initializeMaps and these reached report getters only: other future getter erases and full unused-input reporting/RunSimulation/Setup/EMS parity remain unclaimed.
''')
m.update(schema='src06-actual-shared-report-input-scan-preparation.v3',parent_manifest=ref(P/'manifest.json'),files=files,Original_ranges=m['Original_ranges']+extra_original,README=ref(readme),author=ref(Path(__file__)),change='actual exact object names + initializeMaps unused identity set + reached getObjectItem reset/erase/write + mutably borrowed real context',source_unused_reporting_PARITY=False)
put(O/'manifest.json',json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(ref(O/'manifest.json')))

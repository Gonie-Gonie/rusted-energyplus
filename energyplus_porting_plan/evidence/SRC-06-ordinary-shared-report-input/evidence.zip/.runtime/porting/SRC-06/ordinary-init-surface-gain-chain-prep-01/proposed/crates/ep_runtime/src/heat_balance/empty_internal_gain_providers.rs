//! Real empty-provider calls reached by InitInternalHeatGains6935-6942.
//!
//! This owns only the selected real manager fields and collections. The real
//! caller creates the electric facility at SimulationManager222. Numeric gains
//! call this sequence before UpdateInternalGainValues; no absent getter is
//! treated as a successful active equipment producer.

use super::radiation::ordinary::OrdinaryRadiationUnavailable as Unavailable;
use ep_model::TypedModel;

/// Same-admission facts for the eighteen actual refrigeration count queries.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct EmptyInternalGainInput {
    supplied: [Option<usize>; 18],
}

impl EmptyInternalGainInput {
    pub(crate) const FAMILIES: [&'static str; 18] = [
        "Refrigeration:Condenser:Cascade", "Refrigeration:Case",
        "Refrigeration:CaseAndWalkInList", "Refrigeration:CompressorRack",
        "Refrigeration:SecondarySystem", "Refrigeration:TransferLoadList",
        "Refrigeration:WalkIn", "Refrigeration:System", "Refrigeration:TranscriticalSystem",
        "Refrigeration:Condenser:AirCooled", "Refrigeration:Condenser:EvaporativeCooled",
        "Refrigeration:Condenser:WaterCooled", "Refrigeration:GasCooler:AirCooled",
        "Refrigeration:Compressor", "Refrigeration:Subcooler", "Refrigeration:CompressorList",
        "ZoneHVAC:RefrigerationChillerSet", "Refrigeration:AirChiller",
    ];
    pub(crate) fn empty_inventory() -> Self { Self { supplied: [None; 18] } }
    pub(crate) fn retain_family(&mut self, family: &str, count: usize) -> Result<(), Unavailable> {
        if let Some(index) = Self::FAMILIES.iter().position(|&name| name == family) {
            if self.supplied[index].is_some() || count != 0 { return Err(Unavailable::InputBranch); }
            self.supplied[index] = Some(count);
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RefrigerationInputShape {
    // Earlier real getters may already have inserted null. A zero count does
    // not distinguish that from absent. No exact absence claim is invented.
    AbsentOrEarlierNull,
    Null,
    ObjectMap(usize),
}

/// Selected real electric facility fields used by the zone-gain initializer.
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct FacilityElectricService {
    pub(crate) new_environment_internal_gains_flag: bool,
    pub(crate) get_input_flag: bool,
    pub(crate) facility_power_in_transformer_present: bool,
    pub(crate) power_out_transformer: Option<()>,
    pub(crate) number_of_load_centers: usize,
    pub(crate) load_centers: Vec<()>,
}
impl FacilityElectricService {
    fn new() -> Self {
        Self { new_environment_internal_gains_flag: true, get_input_flag: true,
            facility_power_in_transformer_present: false, power_out_transformer: None,
            number_of_load_centers: 0, load_centers: Vec::new() }
    }
    fn reinitialize_zone_gains(&self) -> Result<(), Unavailable> {
        // ElectricPowerServiceManager193-206. All three real branches are
        // skipped on the admitted no-transformer/no-load-center constructor.
        if self.facility_power_in_transformer_present || self.power_out_transformer.is_some()
            || self.number_of_load_centers != 0 || !self.load_centers.is_empty()
        { return Err(Unavailable::InputBranch); }
        Ok(())
    }
}

/// Selected real refrigeration constructor/getter/environment owners.
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct RefrigerationGainOwner {
    pub(crate) input_shapes: [RefrigerationInputShape; 18],
    pub(crate) num_cascade_condensers: usize,
    pub(crate) num_cases: usize,
    pub(crate) num_case_and_walkin_lists: usize,
    pub(crate) num_racks: usize,
    pub(crate) num_secondary_systems: usize,
    pub(crate) num_transfer_load_lists: usize,
    pub(crate) num_walkins: usize,
    pub(crate) num_systems: usize,
    pub(crate) num_transcritical_systems: usize,
    pub(crate) num_air_condensers: usize,
    pub(crate) num_evaporative_condensers: usize,
    pub(crate) num_water_condensers: usize,
    pub(crate) num_gas_coolers: usize,
    pub(crate) num_condensers: usize,
    pub(crate) num_compressors: usize,
    pub(crate) num_subcoolers: usize,
    pub(crate) num_chiller_sets: usize,
    pub(crate) num_air_chillers: usize,
    pub(crate) get_input_flag: bool,
    pub(crate) have_racks: bool,
    pub(crate) have_detailed_refrigeration: bool,
    pub(crate) have_transcritical_refrigeration: bool,
    pub(crate) have_cases_or_walkins: bool,
    pub(crate) have_chillers: bool,
    pub(crate) manage_refrigeration: bool,
    pub(crate) use_system_time_step: bool,
    pub(crate) present_in_zone: Option<Vec<bool>>,
    pub(crate) environment_gain_flag: bool,
}

impl RefrigerationGainOwner {
    fn new(input: EmptyInternalGainInput) -> Self {
        Self { input_shapes: std::array::from_fn(|i| match input.supplied[i] {
                Some(n) => RefrigerationInputShape::ObjectMap(n),
                None => RefrigerationInputShape::AbsentOrEarlierNull,
            }), num_cascade_condensers:0, num_cases:0, num_case_and_walkin_lists:0,
            num_racks:0, num_secondary_systems:0, num_transfer_load_lists:0, num_walkins:0,
            num_systems:0, num_transcritical_systems:0, num_air_condensers:0,
            num_evaporative_condensers:0, num_water_condensers:0, num_gas_coolers:0,
            num_condensers:0, num_compressors:0, num_subcoolers:0, num_chiller_sets:0,
            num_air_chillers:0, get_input_flag:true, have_racks:true,
            have_detailed_refrigeration:true, have_transcritical_refrigeration:true,
            have_cases_or_walkins:true, have_chillers:true, manage_refrigeration:true,
            use_system_time_step:false, present_in_zone:None, environment_gain_flag:true }
    }
    fn count(&self, index: usize) -> usize {
        match self.input_shapes[index] {
            RefrigerationInputShape::ObjectMap(n) => n,
            RefrigerationInputShape::AbsentOrEarlierNull | RefrigerationInputShape::Null => 0,
        }
    }
    fn definition_lookup(&mut self, index: usize) {
        // Real InputProcessor1430-1438: schema-defined absent family insertion.
        // Explicit empty maps and existing null remain their actual shape.
        if self.input_shapes[index] == RefrigerationInputShape::AbsentOrEarlierNull {
            self.input_shapes[index] = RefrigerationInputShape::Null;
        }
    }
    fn get_input(&mut self, model: &TypedModel) -> Result<(), Unavailable> {
        // RefrigeratedCase508-538: literal query order, including the condenser
        // sum before the compressor/subcooler/list/chiller queries. No active
        // case output or schema-extension data exists on this admitted branch.
        self.num_cascade_condensers=self.count(0); self.num_cases=self.count(1);
        self.num_case_and_walkin_lists=self.count(2); self.num_racks=self.count(3);
        self.num_secondary_systems=self.count(4); self.num_transfer_load_lists=self.count(5);
        self.num_walkins=self.count(6); self.num_systems=self.count(7);
        self.num_transcritical_systems=self.count(8); self.num_air_condensers=self.count(9);
        self.num_evaporative_condensers=self.count(10); self.num_water_condensers=self.count(11);
        self.num_gas_coolers=self.count(12);
        self.num_condensers=self.num_air_condensers+self.num_evaporative_condensers
            +self.num_water_condensers+self.num_cascade_condensers;
        self.num_compressors=self.count(13); self.num_subcoolers=self.count(14);
        let number_of_compressor_lists=self.count(15);
        self.num_chiller_sets=self.count(16); self.num_air_chillers=self.count(17);
        if (0..18).any(|index| self.count(index) != 0) || number_of_compressor_lists != 0 {
            return Err(Unavailable::InputBranch);
        }
        self.have_racks=false; self.have_detailed_refrigeration=false;
        self.have_transcritical_refrigeration=false; self.have_cases_or_walkins=false;
        self.have_chillers=false;
        // All positive component/credit/report allocations are skipped.
        self.use_system_time_step=true; // Actual593-599 empty cases/walkins else.
        let steps=model.timestep.number_of_timesteps_per_hour as usize;
        if steps == 0 || steps > 60 || 60 % steps != 0 { return Err(Unavailable::StorageDomain); }
        // Real local DayValues allocation, deallocated at7009 before reports.
        let day_values=vec![std::mem::MaybeUninit::<f64>::uninit();steps*24];
        self.present_in_zone=Some(vec![false;model.zones.len()]);
        // Actual15 getObjectDefMaxArgs calls628-655. Counts did not mutate input;
        // these definition lookups do. Fixed dimensions are literal official
        // schema legacy_idd field counts with max extension size0.
        let mut max_alphas=0; let mut max_numbers=0;
        for (index,alphas,numbers) in [
            (1,15,21),(2,1,0),(3,15,11),(7,13,4),(8,11,4),
            (9,5,6),(10,6,17),(11,6,11),(12,5,9),(13,7,4),
            (15,1,0),(6,9,12),(4,9,14),(16,5,0),(17,12,16),
        ] {
            self.definition_lookup(index);
            max_alphas=max_alphas.max(alphas); max_numbers=max_numbers.max(numbers);
        }
        let alphas=vec![String::new();max_alphas];
        let numbers=vec![0.0;max_numbers];
        let alpha_field_names=vec![String::new();max_alphas];
        let numeric_field_names=vec![String::new();max_numbers];
        let alpha_blanks=vec![true;max_alphas];
        let numeric_blanks=vec![true;max_numbers];
        // Every positive-object body695-7007 is skipped, including all error/
        // diagnostics and internal-gain registrations. Literal local release:
        drop(day_values); drop(alphas); drop(numbers); drop(alpha_field_names);
        drop(numeric_field_names); drop(alpha_blanks); drop(numeric_blanks);
        // Empty orphan checks are skipped. ReportRefrigerationComponents7305
        // traverses only count>0 branches, so produces NO zero-input EIO header.
        Ok(())
    }
    fn check_input(&mut self, model: &TypedModel) -> Result<(), Unavailable> {
        if self.get_input_flag {
            self.get_input(model)?;
            // Actual SetupReportInput: every component count0; all Zone visits
            // read the allocated false present flags and register no variable.
            if self.present_in_zone.as_ref().is_none_or(|rows|
                rows.len()!=model.zones.len() || rows.iter().any(|&value| value)) {
                return Err(Unavailable::StorageDomain);
            }
            self.get_input_flag=false;
            if !self.have_cases_or_walkins && !self.have_chillers {
                self.manage_refrigeration=false;
                return Ok(());
            }
            if !self.have_detailed_refrigeration && !self.have_racks
                && !self.have_transcritical_refrigeration {
                self.manage_refrigeration=false;
                return Ok(());
            }
        }
        Ok(())
    }
    fn figure_zone_gains(&mut self, model: &TypedModel, begin_environment: bool)
        -> Result<(), Unavailable>
    {
        self.check_input(model)?;
        if begin_environment && self.environment_gain_flag {
            // All six positive component gain-reset loops are skipped.
            self.environment_gain_flag=false;
        }
        if !begin_environment { self.environment_gain_flag=true; }
        Ok(())
    }
}

/// Sole selected provider managers; no second numeric gain/cache/config owner.
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct EmptyInternalGainProviders {
    pub(crate) number_of_water_tanks: usize,
    pub(crate) number_of_heat_transfer_pipes: usize,
    pub(crate) number_of_water_equipment: usize,
    pub(crate) number_of_fuel_cells: usize,
    pub(crate) number_of_micro_chps: usize,
    pub(crate) water_tank_get_input_flag: bool,
    pub(crate) water_tank_environment_gain_flag: bool,
    pub(crate) pipe_environment_gain_flag: bool,
    pub(crate) water_use_environment_gain_local_flag: bool,
    pub(crate) fuel_cell_environment_gain_flag: bool,
    pub(crate) micro_chp_environment_gain_flag: bool,
    pub(crate) tdd_environment_gain_flag: bool,
    pub(crate) tdd_pipes: Option<Vec<()>>,
    pub(crate) electric_service: Option<FacilityElectricService>,
    pub(crate) refrigeration: RefrigerationGainOwner,
}

impl EmptyInternalGainProviders {
    pub(crate) fn new(input: EmptyInternalGainInput) -> Self {
        Self { number_of_water_tanks:0, number_of_heat_transfer_pipes:0,
            number_of_water_equipment:0, number_of_fuel_cells:0, number_of_micro_chps:0,
            water_tank_get_input_flag:true, water_tank_environment_gain_flag:true,
            pipe_environment_gain_flag:true, water_use_environment_gain_local_flag:true,
            fuel_cell_environment_gain_flag:true, micro_chp_environment_gain_flag:true,
            tdd_environment_gain_flag:true, tdd_pipes:None, electric_service:None,
            refrigeration:RefrigerationGainOwner::new(input) }
    }
    /// Actual SimulationManager222 creation, before SetupSimulation environments.
    pub(crate) fn create_facility_electric_service(&mut self) {
        self.electric_service=Some(FacilityElectricService::new());
    }
    fn water_thermal_tank_zone_gains(&self, doing_sizing: bool) -> Result<(), Unavailable> {
        if self.number_of_water_tanks == 0 && !doing_sizing { return Ok(()); }
        // The real sizing getter or positive-tank gain body is outside admission.
        Err(Unavailable::InputBranch)
    }
    fn pipe_zone_gains(&self) -> Result<(), Unavailable> {
        if self.number_of_heat_transfer_pipes == 0 { return Ok(()); }
        Err(Unavailable::InputBranch)
    }
    fn water_use_zone_gains(&self) -> Result<(), Unavailable> {
        if self.number_of_water_equipment == 0 { return Ok(()); }
        Err(Unavailable::InputBranch)
    }
    fn fuel_cell_zone_gains(&self) -> Result<(), Unavailable> {
        if self.number_of_fuel_cells == 0 { return Ok(()); }
        Err(Unavailable::InputBranch)
    }
    fn micro_chp_zone_gains(&self) -> Result<(), Unavailable> {
        if self.number_of_micro_chps == 0 { return Ok(()); }
        Err(Unavailable::InputBranch)
    }
    fn tdd_zone_gains(&self) -> Result<(), Unavailable> {
        if self.tdd_pipes.as_ref().is_none_or(Vec::is_empty) { return Ok(()); }
        Err(Unavailable::InputBranch)
    }
    /// Real selected provider sequence, before the caller caches generic gains.
    pub(crate) fn update_zone_gains(&mut self, model: &TypedModel,
        begin_environment: bool, doing_sizing: bool) -> Result<(), Unavailable>
    {
        // Actual no-tank/non-sizing return603-606: GetTankInput flag stays true.
        self.water_thermal_tank_zone_gains(doing_sizing)?;
        // Pipe1645, WaterUse1742, FuelCell3426, MicroCHP1339 each returns on
        // its real constructor count0 BEFORE changing any environment flag.
        // Their actual complete raw inputs are excluded by the shared admission.
        self.pipe_zone_gains()?;
        self.water_use_zone_gains()?;
        self.fuel_cell_zone_gains()?;
        self.micro_chp_zone_gains()?;
        // The sole electric facility must have been created at its real caller.
        let electric=self.electric_service.as_mut().ok_or(Unavailable::StorageDomain)?;
        if electric.new_environment_internal_gains_flag && begin_environment {
            electric.reinitialize_zone_gains()?;
            electric.new_environment_internal_gains_flag=false;
        }
        if !begin_environment { electric.new_environment_internal_gains_flag=true; }
        // FigureTDD1846 returns on real unallocated TDDPipe size0, before flag.
        self.tdd_zone_gains()?;
        self.refrigeration.figure_zone_gains(model,begin_environment)?;
        Ok(())
    }
}

"""Seal successor using rustfmt's validated Windows extended-path output header."""
from pathlib import Path

path=Path('.runtime/porting/SRC-06/seal-source-report-input-Root-01.py')
source=path.read_text(encoding='utf-8')
old='def tokens(text):return re.findall(r\'"(?:\\\\.|[^"\\\\])*"|[A-Za-z_][A-Za-z_0-9]*|\\d+|[^\\s]\',text)'
assert source.count(old)==1
source=source.replace(old,r'''def tokens(text):
    result=re.findall(r'"(?:\\.|[^"\\])*"|[A-Za-z_][A-Za-z_0-9]*|\d+|[^\s]',text)
    return [value for index,value in enumerate(result)
            if not (value==',' and index+1<len(result) and result[index+1] in [')',']','}'])]
''')
old_loop='''for name in ['selected_input_processor.rs','ctf_initialization_context.rs','report_scan/source_input.rs']:
    assert tokens((parent/name).read_text(encoding='utf-8'))==tokens((Path('crates/ep_runtime/src/heat_balance')/name).read_text(encoding='utf-8')),name
'''
new_loop=r'''format_proofs=[]
for name in ['selected_input_processor.rs','ctf_initialization_context.rs','report_scan/source_input.rs']:
    command=['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--emit','stdout',str(parent/name)]
    result=subprocess.run(command,check=True,capture_output=True)
    raw=result.stdout.decode('utf-8').replace('\r\n','\n')
    header, delimiter, payload=raw.partition('\n\n')
    assert delimiter and header.replace('\\','/').endswith((parent/name).as_posix()+':'),header
    actual_source=(Path('crates/ep_runtime/src/heat_balance')/name).read_text(encoding='utf-8')
    assert payload==actual_source,(name,repr(payload[:100]),repr(actual_source[:100]))
    archive=OUT/('rustfmt-'+name.replace('/','__')+'.stdout')
    archive.write_bytes(result.stdout)
    format_proofs.append({'command':command,'exit_code':result.returncode,'complete_stdout':ref(archive),
        'canonical_equals_actual_formatter_source_output':True})
'''
assert source.count(old_loop)==1
source=source.replace(old_loop,new_loop)
source=source.replace("'IP_context_getter_tokens_unchanged_from_preparation':True", "'IP_context_getter_equal_to_actual_read_only_rustfmt_output':True")
source=source.replace("'production_parent_lines':production_parent_lines", "'actual_read_only_formatter_proofs':format_proofs,'production_parent_lines':production_parent_lines")
source=source.replace("'extend-source-scan-context-test-Root-01.py',Path(__file__).name", "'extend-source-scan-context-test-Root-01.py','seal-source-report-input-Root-01.py','seal-source-report-input-Root-02.py','seal-source-report-input-Root-03.py',Path(__file__).name")
exec(compile(source,str(path),'exec'),{'__file__':str(Path(__file__)),'__name__':'__main__'})

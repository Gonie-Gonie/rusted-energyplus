//! Literal General.cc1130–1469 report-cache processing; no output backend activation.

use ep_model::{ReportInputObjectType as Kind, ReportInputs};

/// General's retained report flags/options and the directly written companion flags.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReportScanState {
    /// GeneralData::GetReportInput, initially true and cleared after the first scan.
    pub get_report_input: bool,
    /// GeneralData::SurfVert.
    pub surface_vertices: bool,
    /// GeneralData::SurfDet.
    pub surface_details: bool,
    /// GeneralData::SurfDetWVert.
    pub surface_details_with_vertices: bool,
    /// GeneralData::LineRpt.
    pub lines: bool,
    /// GeneralData::LineRptOption1.
    pub line_option: String,
    /// GeneralData::CostInfo.
    pub cost_info: bool,
    /// GeneralData::ViewFactorInfo.
    pub view_factor_info: bool,
    /// GeneralData::ViewRptOption1.
    pub view_factor_option: String,
    /// GeneralData::DXFReport.
    pub dxf: bool,
    /// GeneralData::DXFOption1/2.
    pub dxf_options: [String; 2],
    /// GeneralData::DXFWFReport.
    pub dxf_wireframe: bool,
    /// GeneralData::DXFWFOption1/2.
    pub dxf_wireframe_options: [String; 2],
    /// GeneralData::VRMLReport.
    pub vrml: bool,
    /// GeneralData::VRMLOption1/2.
    pub vrml_options: [String; 2],
    /// GeneralData::VarDict.
    pub variable_dictionary: bool,
    /// GeneralData::VarDictOption1/2.
    pub variable_dictionary_options: [String; 2],
    /// GeneralData::Constructions.
    pub constructions: bool,
    /// GeneralData::Materials.
    pub materials: bool,
    /// GeneralData::EMSoutput.
    pub ems_output: bool,
    /// DataGlobal::ShowDecayCurvesInEIO.
    pub show_decay_curves_in_eio: bool,
    /// RuntimeLanguage::OutputEMSActuatorAvailSmall/Full.
    pub ems_actuator_availability: [bool; 2],
    /// RuntimeLanguage::OutputEMSInternalVarsSmall/Full.
    pub ems_internal_variable_availability: [bool; 2],
    /// RuntimeLanguage::OutputEMSErrors.
    pub ems_errors: bool,
    /// RuntimeLanguage::OutputFullEMSTrace.
    pub ems_full_trace: bool,
}

impl Default for ReportScanState {
    fn default() -> Self {
        Self {
            get_report_input: true,
            surface_vertices: false,
            surface_details: false,
            surface_details_with_vertices: false,
            lines: false,
            line_option: String::new(),
            cost_info: false,
            view_factor_info: false,
            view_factor_option: String::new(),
            dxf: false,
            dxf_options: Default::default(),
            dxf_wireframe: false,
            dxf_wireframe_options: Default::default(),
            vrml: false,
            vrml_options: Default::default(),
            variable_dictionary: false,
            variable_dictionary_options: Default::default(),
            constructions: false,
            materials: false,
            ems_output: false,
            show_decay_curves_in_eio: false,
            ems_actuator_availability: [false; 2],
            ems_internal_variable_availability: [false; 2],
            ems_errors: false,
            ems_full_trace: false,
        }
    }
}

/// Actual source diagnostic call arguments; a caller must provide its real backend.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReportScanDiagnostic {
    /// ShowWarningError argument; not an inferred Native backend result.
    Warning(String),
    /// ShowContinueError argument, after the actual warning argument.
    Continue(String),
}

/// A source call that cannot be represented as a successful supported request.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ReportScanUnavailable {
    /// Native dereferences absent ReportKey for Surfaces; no success is fabricated.
    MissingSurfacesKey,
}

/// A real diagnostic transport failure stops at the reached call boundary.
#[derive(Debug)]
pub enum ReportScanFailure<E> {
    /// The requested source call is outside its represented argument domain.
    Unavailable(ReportScanUnavailable),
    /// The actual borrowed diagnostic backend returned this failure.
    Diagnostic(E),
}

fn copy_options(a: &mut Option<&mut String>, b: &mut Option<&mut String>, values: &[String; 2]) {
    if let Some(target) = a.as_deref_mut() {
        target.clone_from(&values[0]);
    }
    if let Some(target) = b.as_deref_mut() {
        target.clone_from(&values[1]);
    }
}

/// Executes actual cache assignments and the selected request, preserving option refs.
/// Diagnostic callbacks are real call arguments; full warning/fatal backend parity is
/// a separate prerequisite, and this function makes no whole-Init completion claim.
pub fn scan_for_reports(
    input: &ReportInputs,
    state: &mut ReportScanState,
    report_name: &str,
    report_key: Option<&str>,
    option1: Option<&mut String>,
    option2: Option<&mut String>,
    mut diagnostic: impl FnMut(ReportScanDiagnostic),
) -> Result<bool, ReportScanUnavailable> {
    match try_scan_for_reports(
        input,
        state,
        report_name,
        report_key,
        option1,
        option2,
        |value| {
            diagnostic(value);
            Ok::<(), std::convert::Infallible>(())
        },
    ) {
        Ok(value) => Ok(value),
        Err(ReportScanFailure::Unavailable(value)) => Err(value),
        Err(ReportScanFailure::Diagnostic(never)) => match never {},
    }
}

/// The same literal assignments with a fallible real warning/continue boundary.
/// Failed diagnostics leave GetReportInput and all preceding cache writes at
/// the exact reached prefix; later objects and requests are not evaluated.
pub fn try_scan_for_reports<E>(
    input: &ReportInputs,
    state: &mut ReportScanState,
    report_name: &str,
    report_key: Option<&str>,
    mut option1: Option<&mut String>,
    mut option2: Option<&mut String>,
    mut diagnostic: impl FnMut(ReportScanDiagnostic) -> Result<(), E>,
) -> Result<bool, ReportScanFailure<E>> {
    if state.get_report_input {
        for object in input
            .objects
            .iter()
            .filter(|o| o.object_type == Kind::SurfacesList)
        {
            let a = &object.alphas;
            match a[0].as_str() {
                "LINES" => {
                    state.lines = true;
                    state.line_option.clone_from(&a[1]);
                }
                "VERTICES" => state.surface_vertices = true,
                "DETAILS" | "DETAILED" | "DETAIL" => state.surface_details = true,
                "DETAILSWITHVERTICES" | "DETAILVERTICES" => {
                    state.surface_details_with_vertices = true
                }
                "COSTINFO" => state.cost_info = true,
                "VIEWFACTORINFO" => {
                    state.view_factor_info = true;
                    state.view_factor_option.clone_from(&a[1]);
                }
                "DECAYCURVESFROMCOMPONENTLOADSSUMMARY" => state.show_decay_curves_in_eio = true,
                // Native localMap[unknown] inserts EMPTY; it does not throw int.
                _ => {
                    diagnostic(ReportScanDiagnostic::Warning(format!(
                        "Output:Surfaces:List: No {} supplied.",
                        object.report_type_field_name()
                    )))
                    .map_err(ReportScanFailure::Diagnostic)?;
                    diagnostic(ReportScanDiagnostic::Continue(
                        " Legal values are: \"Lines\", \"Vertices\", \"Details\", \"DetailsWithVertices\", \"CostInfo\", \"ViewFactorIinfo\".".to_string())).map_err(ReportScanFailure::Diagnostic)?;
                }
            }
        }
        for object in input
            .objects
            .iter()
            .filter(|o| o.object_type == Kind::SurfacesDrawing)
        {
            let a = &object.alphas;
            let values = [a[1].clone(), a[2].clone()];
            match a[0].to_ascii_uppercase().as_str() {
                "DXF" => {
                    state.dxf = true;
                    state.dxf_options = values;
                }
                "DXF:WIREFRAME" => {
                    state.dxf_wireframe = true;
                    state.dxf_wireframe_options = values;
                }
                "VRML" => {
                    state.vrml = true;
                    state.vrml_options = values;
                }
                _ => {}
            }
        }
        if input.legacy_variable_dictionary_sections > 0 {
            state.variable_dictionary = true;
            state.variable_dictionary_options = ["REGULAR".to_string(), String::new()];
        }
        for object in input
            .objects
            .iter()
            .filter(|o| o.object_type == Kind::VariableDictionary)
        {
            state.variable_dictionary = true;
            state.variable_dictionary_options =
                [object.alphas[0].clone(), object.alphas[1].clone()];
        }
        for object in input
            .objects
            .iter()
            .filter(|o| o.object_type == Kind::Constructions)
        {
            for alpha in &object.alphas[..if object.num_alphas > 1 { 2 } else { 1 }] {
                if alpha.eq_ignore_ascii_case("CONSTRUCTIONS") {
                    state.constructions = true;
                } else if alpha.eq_ignore_ascii_case("MATERIALS") {
                    state.materials = true;
                }
            }
        }
        for object in input
            .objects
            .iter()
            .filter(|o| o.object_type == Kind::EnergyManagementSystem)
        {
            state.ems_output = true;
            let a = &object.alphas;
            state.ems_actuator_availability = [
                a[0].eq_ignore_ascii_case("NOTBYUNIQUEKEYNAMES"),
                a[0].eq_ignore_ascii_case("VERBOSE"),
            ];
            state.ems_internal_variable_availability = [
                a[1].eq_ignore_ascii_case("NOTBYUNIQUEKEYNAMES"),
                a[1].eq_ignore_ascii_case("VERBOSE"),
            ];
            state.ems_errors =
                a[2].eq_ignore_ascii_case("ERRORSONLY") || a[2].eq_ignore_ascii_case("VERBOSE");
            state.ems_full_trace = a[2].eq_ignore_ascii_case("VERBOSE");
        }
        state.get_report_input = false;
    }

    let mut do_report = false;
    match report_name.to_ascii_uppercase().as_str() {
        "CONSTRUCTIONS" => {
            if let Some(key) = report_key {
                if key.eq_ignore_ascii_case("Constructions") {
                    do_report = state.constructions;
                }
                if key.eq_ignore_ascii_case("Materials") {
                    do_report = state.materials;
                }
            }
        }
        "VIEWFACTORINFO" => {
            do_report = state.view_factor_info;
            if let Some(target) = option1 {
                target.clone_from(&state.view_factor_option);
            }
        }
        "VARIABLEDICTIONARY" => {
            do_report = state.variable_dictionary;
            copy_options(
                &mut option1,
                &mut option2,
                &state.variable_dictionary_options,
            );
        }
        "SURFACES" => match report_key
            .ok_or(ReportScanFailure::Unavailable(
                ReportScanUnavailable::MissingSurfacesKey,
            ))?
            .to_ascii_uppercase()
            .as_str()
        {
            "COSTINFO" => do_report = state.cost_info,
            "DXF" => {
                do_report = state.dxf;
                copy_options(&mut option1, &mut option2, &state.dxf_options);
            }
            "DXF:WIREFRAME" => {
                do_report = state.dxf_wireframe;
                copy_options(&mut option1, &mut option2, &state.dxf_wireframe_options);
            }
            "VRML" => {
                do_report = state.vrml;
                copy_options(&mut option1, &mut option2, &state.vrml_options);
            }
            "VERTICES" => do_report = state.surface_vertices,
            "DETAILS" => do_report = state.surface_details,
            "DETAILSWITHVERTICES" => do_report = state.surface_details_with_vertices,
            "LINES" => {
                do_report = state.lines;
                if let Some(target) = option1 {
                    target.clone_from(&state.line_option);
                }
            }
            _ => {}
        },
        "ENERGYMANAGEMENTSYSTEM" => do_report = state.ems_output,
        _ => {}
    }
    Ok(do_report)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ep_model::ReportInputObject;

    fn row(kind: Kind, alphas: [&str; 3], count: u8) -> ReportInputObject {
        ReportInputObject {
            object_name: "authored direct API input".to_string(),
            object_type: kind,
            alphas: alphas.map(str::to_string),
            alpha_blank: [false; 3],
            default_applied: [false; 3],
            num_alphas: count,
            is_epjson: true,
        }
    }

    #[test]
    fn first_scan_reads_real_a_families_then_later_queries_reuse_cache() {
        let input = ReportInputs {
            objects: vec![
                row(Kind::VariableDictionary, ["IDF", "", ""], 1),
                row(
                    Kind::SurfacesDrawing,
                    ["DXF:WIREFRAME", "TRIANGULATE3DFACE", ""],
                    1,
                ),
                row(Kind::Constructions, ["CONSTRUCTIONS", "", ""], 1),
            ],
            ..ReportInputs::default()
        };
        let mut state = ReportScanState::default();
        assert_eq!(
            scan_for_reports(
                &input,
                &mut state,
                "Constructions",
                Some("Constructions"),
                None,
                None,
                |_| {}
            ),
            Ok(true)
        );
        assert!(!state.get_report_input);
        assert!(state.variable_dictionary && state.dxf_wireframe);
        let mut first = "keep".to_string();
        let mut second = "keep".to_string();
        assert_eq!(
            scan_for_reports(
                &ReportInputs::default(),
                &mut state,
                "Surfaces",
                Some("dxf:wireframe"),
                Some(&mut first),
                Some(&mut second),
                |_| {}
            ),
            Ok(true)
        );
        assert_eq!((first.as_str(), second.as_str()), ("TRIANGULATE3DFACE", ""));
        assert_eq!(state.variable_dictionary_options, ["IDF", ""]);
    }

    #[test]
    fn unknown_surface_list_token_uses_native_map_empty_warning_not_invalid() {
        let input = ReportInputs {
            objects: vec![row(Kind::SurfacesList, ["UNRECOGNIZED", "", ""], 1)],
            ..ReportInputs::default()
        };
        let mut messages = Vec::new();
        let mut state = ReportScanState::default();
        assert_eq!(
            scan_for_reports(
                &input,
                &mut state,
                "Constructions",
                Some("Constructions"),
                None,
                None,
                |message| messages.push(message)
            ),
            Ok(false)
        );
        assert_eq!(messages, vec![
            ReportScanDiagnostic::Warning("Output:Surfaces:List: No report_type supplied.".to_string()),
            ReportScanDiagnostic::Continue(" Legal values are: \"Lines\", \"Vertices\", \"Details\", \"DetailsWithVertices\", \"CostInfo\", \"ViewFactorIinfo\".".to_string()),
        ]);
        assert!(!state.get_report_input);
    }

    #[test]
    fn materials_only_second_alpha_count_and_optional_refs_remain_distinct() {
        let input = ReportInputs {
            objects: vec![row(
                Kind::Constructions,
                ["MATERIALS", "CONSTRUCTIONS", ""],
                1,
            )],
            ..ReportInputs::default()
        };
        let mut state = ReportScanState::default();
        let mut untouched = "caller option".to_string();
        assert_eq!(
            scan_for_reports(
                &input,
                &mut state,
                "Constructions",
                Some("Constructions"),
                Some(&mut untouched),
                None,
                |_| {}
            ),
            Ok(false)
        );
        assert!(state.materials);
        assert_eq!(untouched, "caller option");
        assert_eq!(
            scan_for_reports(
                &input,
                &mut state,
                "Constructions",
                Some("Materials"),
                None,
                None,
                |_| {}
            ),
            Ok(true)
        );
        let mut two_alpha = input;
        two_alpha.objects[0].num_alphas = 2;
        let mut fresh = ReportScanState::default();
        assert_eq!(
            scan_for_reports(
                &two_alpha,
                &mut fresh,
                "Constructions",
                Some("Constructions"),
                None,
                None,
                |_| {}
            ),
            Ok(true)
        );
    }

    #[test]
    fn last_ordered_options_and_ems_assignments_replace_earlier_values() {
        let input = ReportInputs {
            legacy_variable_dictionary_sections: 1,
            objects: vec![
                row(Kind::VariableDictionary, ["IDF", "NAME", ""], 2),
                row(Kind::VariableDictionary, ["REGULAR", "UNSORTED", ""], 2),
                row(
                    Kind::EnergyManagementSystem,
                    ["VERBOSE", "NOTBYUNIQUEKEYNAMES", "VERBOSE"],
                    3,
                ),
                row(
                    Kind::EnergyManagementSystem,
                    ["NONE", "NONE", "ERRORSONLY"],
                    3,
                ),
            ],
        };
        let mut state = ReportScanState::default();
        assert_eq!(
            scan_for_reports(
                &input,
                &mut state,
                "EnergyManagementSystem",
                None,
                None,
                None,
                |_| {}
            ),
            Ok(true)
        );
        assert_eq!(state.variable_dictionary_options, ["REGULAR", "UNSORTED"]);
        assert_eq!(state.ems_actuator_availability, [false; 2]);
        assert_eq!(state.ems_internal_variable_availability, [false; 2]);
        assert!(state.ems_errors);
        assert!(!state.ems_full_trace);
    }

    #[test]
    fn missing_surfaces_key_is_typed_unavailable_after_real_first_cache_read() {
        let mut state = ReportScanState::default();
        assert_eq!(
            scan_for_reports(
                &ReportInputs::default(),
                &mut state,
                "Surfaces",
                None,
                None,
                None,
                |_| {}
            ),
            Err(ReportScanUnavailable::MissingSurfacesKey)
        );
        assert!(!state.get_report_input);
        assert_eq!(
            scan_for_reports(
                &ReportInputs::default(),
                &mut state,
                "unknown",
                None,
                None,
                None,
                |_| {}
            ),
            Ok(false)
        );
    }
}

"""Publish shared report getter integration, retaining failed prior QA explicitly."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import zipfile

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = root / 'energyplus_porting_plan/evidence/SRC-06-ordinary-shared-report-input'
assert not out.exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def load(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())

packets = [
    'ordinary-source-report-input-assembly-02/manifest.json',
    'ordinary-source-report-input-assembly-01/manifest.json',
    'ordinary-source-report-scan-prep-03/manifest.json',
    'ordinary-source-report-scan-prep-02/manifest.json',
    'ordinary-source-report-scan-prep-01/manifest.json',
    'ordinary-input-processor-schema-prep-03/manifest.json',
    'Root-shared-input-schema-review-01/review.json',
    'Owner-source-report-input-assembly-review-02/review.json',
    'Owner-source-report-input-assembly-review-01/review.json',
    'Owner-source-report-scan-Source-review-03/review.json',
]
assembly_path = base / packets[0]
assembly = load(assembly_path)
assert ref(assembly_path)['sha256'] == '3a5baba9bf422b4a8b479d162565a1441fb233bdc7c30a1377d67ae255cc4800'
assert assembly['new_test_bodies'] == 0 and assembly['new_binaries'] == 0
rows = []
def collect(value):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value:
            rows.append(value)
        else:
            for item in value.values():
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)

for name in packets:
    collect(load(base / name))
archives_by_hash = {}
for row in rows:
    path = root / row['path']
    if path.exists() and ref(path)['sha256'] == row['sha256']:
        archives_by_hash.setdefault(row['sha256'], path)

artifacts = {}
historical = []
def add(path):
    row = ref(path)
    assert row['size_bytes'] < 12 * 1024 * 1024
    artifacts[row['path']] = row

def checked(row):
    path = root / row['path']
    actual = ref(path)
    if actual['sha256'] != row['sha256']:
        assert row['path'] == 'crates/ep_runtime/src/heat_balance/ctf_geometry_reports_tests.rs'
        assert row['sha256'] == '806d5ae6d902c2f67a380c1c281f6a1f7a427a7c042f2da62aaa9bfc1c80cc49'
        path = archives_by_hash[row['sha256']]
        actual = ref(path)
        resolution = {'historical_reference': row, 'exact_archive': actual,
                      'qualification': 'Assembly01 test bytes, with two incorrect nested-module imports. Clippy01 failed; assembly02 fixes these imports only.'}
        if resolution not in historical:
            historical.append(resolution)
    assert actual['sha256'] == row['sha256'] and actual['size_bytes'] == row.get('size_bytes', actual['size_bytes'])
    return path

for name in packets:
    add(base / name)
for row in rows:
    add(checked(row))
for name in [packets[6], packets[7], packets[9]]:
    assert load(base / name)['accepted'] is True
for row in assembly['files']:
    assert ref(root / row['canonical']['path']) == row['canonical']
    before = (root / row['before']['path']).read_bytes() if row['before'] else b''
    after = (root / row['after']['path']).read_bytes()
    diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                   fromfile=('HEAD/' + row['canonical']['path']) if row['before'] else '/dev/null',
                   tofile=row['canonical']['path'])).encode()
    assert diff == (root / row['complete_diff']['path']).read_bytes(), row['canonical']['path']
    assert row['test_bodies_before'] == row['test_bodies_after']

qa = []
commands = [
    ('fmt-02', ['fmt', '--all', '--', '--check']),
    ('source-quality-02', None),
    ('clippy-02', ['clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('runtime-tests-01', ['test', '-p', 'ep_runtime', 'report_scan']),
    ('raw-tests-01', ['test', '-p', 'ep_run', '--lib', 'raw_equipment_admission']),
    ('cli-tests-01', ['test', '-p', 'ep_run', '--test', 'arbitrary_run', 'one_zone_runtime_writes_stable_output_layout']),
]
counts = []
for name, args in commands:
    path = base / f'ordinary-source-report-input-{name}/receipt.json'
    value = load(path)
    argv = ['C:/Users/GonieGonie/.cargo/bin/cargo.exe', *args] if args else ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'scripts/quality/source-quality-gate.ps1']
    assert value['command'] == argv and value['exit_code'] == 0 and value['launch_error'] is None
    assert value['source_bytes_match_before_and_after'] is True
    qa.append(ref(path)); add(path)
    for key in ['source_snapshot', 'stdout', 'stderr']:
        add(checked(value[key]))
    if name.endswith('tests-01'):
        stdout = checked(value['stdout']).read_text(encoding='utf8')
        groups = [tuple(map(int, g)) for g in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)]
        assert groups and sum(g[0] for g in groups) > 0 and all(g[1] == g[2] == 0 for g in groups)
        counts.append({'receipt': ref(path), 'passed': sum(g[0] for g in groups), 'failed': 0, 'ignored': 0})
source = load(checked(qa[0]))['source_snapshot']
assert all(load(checked(row))['source_snapshot'] == source for row in qa)
assert [row['passed'] for row in counts] == [6, 1, 1], counts

failed = base / 'ordinary-source-report-input-clippy-01/receipt.json'
failure = load(failed)
assert failure['exit_code'] == 101 and failure['source_bytes_match_before_and_after'] is True
assert failure['source_snapshot'] != source
add(failed)
for key in ['source_snapshot', 'stdout', 'stderr']:
    add(checked(failure[key]))
for name in ['fmt-01', 'source-quality-01']:
    path = base / f'ordinary-source-report-input-{name}/receipt.json'
    value = load(path)
    assert value['exit_code'] == 0 and value['source_snapshot'] == failure['source_snapshot']
    add(path)
    for key in ['source_snapshot', 'stdout', 'stderr']:
        add(checked(value[key]))
add(Path(__file__))
assert sum(r['size_bytes'] for r in artifacts.values()) < 24 * 1024 * 1024
out.mkdir()
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for name in sorted(artifacts):
        zipped.write(root / name, name)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and set(zipped.namelist()) == set(artifacts)
    for name in zipped.namelist():
        data = zipped.read(name)
        assert hashlib.sha256(data).hexdigest() == artifacts[name]['sha256'] and len(data) == artifacts[name]['size_bytes']
write(out / 'manifest.json', {
    'schema': 'src06-shared-report-input-evidence.v1', 'Source_snapshot': source,
    'assembly': ref(assembly_path), 'artifacts': list(artifacts.values()),
    'historical_references': historical, 'archive': ref(archive),
    'archive_member_count': len(artifacts), 'gates_updated': False,
})
summary = {
    'schema': 'src06-shared-report-input-summary.v1',
    'status': 'Actual ordinary report getters use the sole shared input owner; full startup/Setup remains incomplete',
    'Source_snapshot': source, 'QA': qa,
    'tests': {'targeted_groups': counts, 'passed': sum(c['passed'] for c in counts), 'failed': 0, 'ignored': 0, 'new_bodies': 0, 'new_binaries': 0},
    'behavior': [
        'Permanent actual object names and exact-case unused identities retained once in the shared processor',
        'Report getters reset all six entire shared arrays, erase the consumed exact-case identity, then write actual defaults, blank flags and field labels in Source order',
        'Cached requery returns before touching input identities, shared arrays or diagnostics',
        'Early failure preserves reached shared-array writes and consumed identities without running later family getters',
        'Absent exact-case getNumSectionsFound returns -1 without inserting input; known null returns 0',
        'Schema metadata grows from 60 to 87 literal official definitions without widening positive input admission',
        'Existing report selector and option copier are extracted to keep the production parent below 400 lines',
    ],
    'limitations': [
        'No whole unused-input reporting or parser parity claim; other family getters still require integration',
        'No new Native run, numerical comparison, full startup, Setup or surface/HVAC solver claim',
        'Prior whole-workspace test baseline remains 4974 passed, 0 failed and 2 ignored; this unit ran targeted tests only',
        'SRC-06 four gates and A14/54 B14/64 remain unchanged',
    ],
    'historical_failed_QA': {'receipt': ref(failed), 'exit_code': 101, 'qualification': 'Assembly01 had two incorrect test imports. Assembly02 fixes only those imports; final all-target Clippy and targeted tests pass.'},
    'independent_Source_reviews': [ref(base / name) for name in [packets[6], packets[7], packets[9]]],
    'validation_scope': 'One final all-target workspace Clippy and three focused test selections. Existing test bodies extended; no new body or binary and no repeated full-workspace run.',
    'manifest': ref(out / 'manifest.json'), 'archive': ref(archive), 'gates_updated': False,
}
write(out / 'summary.json', summary)
plan_path = root / 'energyplus_porting_plan/plan.json'
plan = load(plan_path)
task = next(row for row in plan['tasks'] if row['id'] == 'SRC-06')
assert all(task[key] == '미확인' for key in ['scope_review', 'unit_gate', 'integration_gate', 'production_gate'])
assert 'actual_selected_ordinary_shared_report_input' not in task
task['actual_selected_ordinary_shared_report_input'] = ref(out / 'summary.json')
write(plan_path, plan)
print(json.dumps({'summary': ref(out / 'summary.json'), 'members': len(artifacts), 'archive_bytes': archive.stat().st_size, 'tests': counts}, ensure_ascii=False))

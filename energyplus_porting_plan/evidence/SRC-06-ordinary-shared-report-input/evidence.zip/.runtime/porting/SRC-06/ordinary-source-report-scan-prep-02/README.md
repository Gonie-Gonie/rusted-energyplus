# Actual shared input effects in the consumed report cache

Held Source-only integration, not applied/formatted/compiled/tested. Four files: one exact-case section accessor on the sole InputProcessor, existing report_scan wrappers/cache with one expanded existing test, a concrete small input bridge child, and the actual CtfInitializationContext.prepare_report_input_cache consumer.

The actual context path uses the admitted input and sole full shortcut when Some; legacy None keeps the same wrapper. Its existing early cached return preserves all scratch arrays. The five report-family queries, true intervening legacy section lookup and complete six-array getObjectItem resets occur at the existing actual source order. First warning/backend failure stops before the later getter with its written prefix retained. Typed report defaults/blanks/num_alphas/is_epjson come from the existing same-admission projection. No duplicate schema/table/admission list or report cache exists.

The unchanged public Scan APIs and existing no-EMS warning suffix remain; this is a consumed scratch/query prerequisite, not activation or a claim about the complete EMS/startup/RunSimulation/Setup producer. IP unusedInputs bookkeeping is outside this unit. Existing single first-scan test expands full numeric/alpha scratch, blank/default/label writes, exact-case absent/null section sizes, cache retention including signed zero, and a genuine transport error boundary. No new test body/binary/framework is added.

All three IP/report Source payloads are byte-exact the pinned startup held packet. The canonical context base is archived separately; the complete new startup and globals modules are not included or activated here. Root may combine this consumed unit with the independently reviewed single schema87 metadata successor.

Source02 adds only two narrow function-local Clippy too_many_arguments expectations, preserving original report operands plus explicit shared getter borrow. Complete reverse removal reproduces whole Source01 bytes. All other payloads, context integration and tests remain byte-exact01. No compiler/lint/targets executed; inherited broad module allowance is not expanded.

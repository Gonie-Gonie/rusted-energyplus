# Held shared InputProcessor schema extension

This packet adds only the actual legacy_idd definition metadata required by the reached internal-gain and empty refrigeration getters. The same sole schema table grows from 60 to 87 definitions: nine additional internal-gain families (OtherEquipment was already present) and eighteen refrigeration families. Both original declaration-order lists are retained in the manifest; the table remains lexically sorted.

Every complete legacy_idd subtree is copied from the authenticated EnergyPlus 26.1.0 schema. All sixty parent subtrees are unchanged. Removing the twenty-seven new tuple lines restores the complete parent schema module text exactly. The full schema module and complete excerpt diffs are included.

This does not add a positive input admission family, a second schema table, a synthetic count, or a runtime owner. The raw resolver and runtime InputProcessor semantics remain the separately reviewed IP02 dependency; Root's visibility/documentation-only shortcut successor is a separate disjoint change. Owner's gain and refrigeration getter successor consumes these definitions through that same mutable InputProcessor.

Held source only: no canonical file, compiler, formatter, tests, engine, or gate changed. Registration and application require the coherent real caller integration.

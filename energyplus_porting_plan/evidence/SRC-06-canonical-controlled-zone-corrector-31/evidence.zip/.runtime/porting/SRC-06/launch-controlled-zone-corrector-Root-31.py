from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-hvac-controlled-node-lifecycle-B-NOLIMIT-24H-command-Root-30/receipt.json','ccd32feea593758b4bbef84559c53dfde9b7bece22f4e95344e0a6b62779057d'),
 'A24':('canonical-source-hvac-controlled-node-lifecycle-A-24H-command-Root-30/receipt.json','ca61ceca4318e271c7cbada2267a71da4943fd6b70946f4fe87bae1f1eae5d38'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-controlled-zone-corrector-'+case+'-command-Root-31'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-controlled-zone-corrector-'+case+'-Root-31/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

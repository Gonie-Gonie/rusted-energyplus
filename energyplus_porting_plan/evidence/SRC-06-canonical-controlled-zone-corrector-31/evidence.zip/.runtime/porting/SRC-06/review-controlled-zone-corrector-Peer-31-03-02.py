"""Fresh independent four-Source corrector peer, including property boundaries."""
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
OUT = D / 'Peer-controlled-zone-corrector-Source-review-31-03-02'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def auth(row):
    p = R / row['path']
    assert ref(p)['sha256'] == row['sha256'], row
    if 'bytes' in row:
        assert ref(p)['bytes'] == row['bytes'], row
    return p

def save(name, b):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(b)
    return ref(p)

def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], check=True, capture_output=True).stdout

assert not OUT.exists()
dp = D / 'source-controlled-zone-corrector-draft-Outer-31-03/draft.json'
assert ref(dp)['sha256'] == '9bb470506d1faa7d698a204757d6b590d142ddeade9021194c984440cc150a2d'
draft = json.loads(dp.read_bytes())
old_path = auth(draft['parent02'])
old = json.loads(old_path.read_bytes())
parent_path = D / 'source-hvac-controlled-node-lifecycle-held-Peer-30/manifest.json'
assert ref(parent_path)['sha256'] == '670e7cb7d4e886d61e4eed7a28df63fa36eb6406dde5747c056dba61d6bf59ab'
parent = json.loads(parent_path.read_bytes())
plan_path = auth(parent['complete_final_compiler_Source_plan'])
plan = json.loads(plan_path.read_bytes())
assert (plan['inputs'], plan['Rust_sources']) == (4503, 4490)
entries = {row['path']: dict(row) for row in plan['entries']}
assert len(entries) == 4503
for name, entry in entries.items():
    b = auth(entry['source']).read_bytes()
    assert (hashlib.sha256(b).hexdigest(), len(b)) == (entry['final_sha256'], entry['final_bytes']), name
tree = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
files = []
old_rows = {row['canonical_path']: row for row in old['files']}
logical = {}
corrections = []
for i, row in enumerate(draft['files'], 1):
    name = row['canonical_path']
    before = auth(row['before']).read_bytes()
    proposed = auth(row['proposed']).read_bytes()
    prior = auth(old_rows[name]['proposed']).read_bytes()
    assert before == auth(entries[name]['source']).read_bytes(), name
    assert ns['apply_literal'](before, auth(row['forward_diff']).read_bytes()) == proposed
    assert ns['apply_literal'](proposed, auth(row['inverse_diff']).read_bytes()) == before
    assert auth(row['literal_inverse']).read_bytes() == before
    if row['whole02_unchanged']:
        assert proposed == prior
    else:
        # Exact author guard text is captured separately and verified by literal
        # removal; no normalization of equations or scientific output.
        marker = b'        // Same conservative boundary' if name.endswith('temperature.rs') else b'        // Conservative raw-temperature'
        start = proposed.index(marker)
        stop = proposed.index(b'        }\n', start) + len(b'        }\n')
        block = proposed[start:stop]
        assert b'if self.zt <= -100.0 || self.zt >= 200.0 {' in block
        assert proposed[:start] + proposed[stop:] == prior
        corrections.append({'canonical_path': name, 'exact_added_guard': save(f'correction/{i:02}-guard.txt', block), 'only_guard_removal_restores_whole02': True})
    parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=proposed, capture_output=True, cwd=R)
    assert parse.returncode == 0, (name, parse.stderr)
    files.append({'canonical_path': name, 'before': row['before'], 'proposed': row['proposed'], 'whole_before_logical30_exact': True, 'two_literal_applications': True, 'fresh_Source_only_parse': {'exit_code': 0, 'stdout': save(f'parse/{i:02}.stdout', parse.stdout), 'stderr': save(f'parse/{i:02}.stderr', parse.stderr)}})
    logical[name] = proposed.decode()
assert len(files) == 4 and len(corrections) == 2
api = []
for name, row in sorted(entries.items()):
    if not name.endswith('.rs'):
        continue
    text = logical.get(name)
    if text is None:
        text = auth(row['source']).read_text(encoding='utf-8')
    terms = [term for term in old['whole_crates_API_census']['patterns'] if term in text]
    if terms:
        api.append({'path': name, 'terms': terms})
old_api_paths = {row['path'] for row in old['whole_crates_API_census']['files']}
actual_api_paths = {row['path'] for row in api}
known30_extra = 'crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/simulation.rs'
assert actual_api_paths == old_api_paths | {known30_extra}
assert known30_extra in {row['canonical_path'] for row in parent['files']}
assert next(row['terms'] for row in api if row['path'] == known30_extra) == ['source_zone_air_node_mut(']
native = []
authorities = {
    'src/EnergyPlus/ZoneTempPredictorCorrector.cc': [(3863, 4166), (4433, 4619), (5133, 5412)],
    'src/EnergyPlus/Psychrometrics.hh': [(513, 547), (615, 666), (679, 716), (1002, 1062), (1215, 1269), (1333, 1388)],
    'src/EnergyPlus/Psychrometrics.cc': [(642, 770)],
    'src/EnergyPlus/DataLoopNode.hh': [(438, 500)],
    'src/EnergyPlus/DataZoneEquipment.hh': [(204, 250)],
    'src/EnergyPlus/DataRoomAirModel.hh': [(73, 84)],
    'src/EnergyPlus/DataZoneEnergyDemands.cc': [(323, 337)],
    'src/EnergyPlus/EnergyPlus.hh': [(158, 170)],
    'third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh': [(338, 355), (486, 505)],
}
for name, ranges in authorities.items():
    b = (N / name).read_bytes()
    assert b == git(N, 'show', PIN + ':' + name)
    lines = b.splitlines(keepends=True)
    extents = [{'first': first, 'last': last, 'source': save('Native-extents/' + Path(name).name + f'.{first}-{last}.txt', b''.join(lines[first - 1:last]))} for first, last in ranges]
    native.append({'Native_path': name, 'whole': save('Native/' + name, b), 'pinned_Git_exact': True, 'extents': extents})
context_names = [
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/demand.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/subsystems.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/environment/fan_zone.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs',
    'crates/ep_runtime/src/heat_balance/zone_predictor_corrector.rs',
    'crates/ep_runtime/src/psychrometrics.rs',
    'crates/ep_runtime/src/psychrometrics/cp_cache.rs',
    'crates/ep_runtime/src/psychrometrics/source_access.rs',
    'crates/ep_runtime/src/psychrometrics/psy02_state.rs',
]
contexts = [{'canonical_path': name, 'whole': save('Source-context/' + name, auth(entries[name]['source']).read_bytes()), 'logical30_complete_plan_exact': True} for name in context_names]
report = {
    'schema': 'src06-independent-full-controlled-zone-corrector-Source-review.v1', 'accepted': True, 'findings': [],
    'reviewed_packet': ref(dp), 'rejected_predecessor02': ref(old_path), 'logical_parent30': ref(parent_path), 'parent_complete_plan': ref(plan_path),
    'scope': 'Fresh whole four-Source numerical/owner/property semantic review. Old20 conversation reads are context only, not a prior formal acceptance. Source30 actual/committed final custody and Source31 compiler/runtime validation remain separate.',
    'files': files, 'literal_applications': 8, 'fresh_Source_only_parses': 4,
    'Native_commit': PIN, 'Native_wholes': native, 'Native_whole_count': len(native), 'strict_Native_extents': sum(len(row['extents']) for row in native), 'concrete_Source_contexts': contexts,
    'full_parent_plan_rehash': {'inputs': 4503, 'Rust_sources': 4490, 'all_immutable_input_wholes_exact': True, 'scope': 'Logical sealed Source30 only, not actual Source30 compile/execution proof'},
    'whole_crates_API_census': {'Rust_sources': 4490, 'all_crates_runtime_tests_included': True, 'patterns': old['whole_crates_API_census']['patterns'], 'files': api, 'old_author_seven_paths_plus_exact_accepted30_convergence_caller': known30_extra, 'old_metadata_omission_is_not_a_Source_finding': True},
    'resolved_genuine_property_finding': {
        'predecessor02_accepted': False,
        'finding': 'Both WFromRh saturation and relative-humidity Psat used the real numeric/cache state without the Native EP_psych_errors miss-path out-of-range warning/CalledFrom transport; computed extreme temperature could continue silently.',
        'author_correction': draft['property_boundary_correction'], 'independent_whole_inverse_checks': corrections,
        'resolution': 'Only two actual caller-local guards bound raw ZT<=-100 or >=200 immediately before those actual property requests. Native earlier writes and all normal operations preserved. Conservative supported-domain boundary, not exact cache-hit/representative/Warmup warning predicate or diagnostic implementation.',
    },
    'owner_proof': [
        'No duplicate Node/Config/cache. Inlet list returns actual Config array slice. Immutable Node view borrows actual T/MassFlow/HumRat. Mutable view retains four previous fields and only adds a disjoint immutable mass reference to that same physical row.',
        'Native signed ordinals are checked only at genuine usize-to-i32 transport and positive-row access. Existing predictor rollback/TempSetPoint writers and cfg(test) Native-cohort callers retain the same methods/fields; whole crate census has no unadapted constructor or duplicate projection.',
    ],
    'sums_proof': [
        'Original reset/gain/non-system/AFN order retained. Corrector-only actual Zone.IsControlled selects retained Config and ordered inlets. Per inlet bind real Node, call normal Cp once with AirHB.airHumRat, compute MassFlow*Cp once, accumulate SumSysMCp then product*Node.Temp.',
        'Zone/list integer product is checked in defined integer domain; actual positive leakage remains first Cp/owner boundary and both system sums divide only after that loop. No per-node multiplier redistribution, filtered count proxy or epsilon.',
        'Full opaque Space-to-Zone HAT order, per-surface h*Area and h*Area*Temp grouping, three reference-temperature cases, controlled fatal and zero-flow fallback agree with pinned Native5283-5412. Windows remain honest first shading-operation boundary.',
    ],
    'temperature_proof': [
        'Real history selection, normal Rho then Cp capacity expression, RoomAir callee then sums remain original. Negative rho typed boundary precedes following Cp/capacity write; no missing fatal result promotion.',
        'Controlled physical SystemZoneNode binding precedes exact coefficient grouping, optional AFN/duct boundaries and literal ThirdOrder helper (no legacy solver/fallback/tolerance). Mixing writes Node.Temp, TempTstatAir, LoadCorrectionFactor1 in order; retained positive nonmixing operations stop before first unrepresented state.',
        'Normal Cp is called again after these writes. SNLoad keeps exact ZoneEnthalpyIn - (Node.Mass/ZoneMult)*Cp*Node.Temp + NonAir/ZoneMult + lagged grouping. Actual pointer aliases use current live fields.',
        'Uncontrolled coefficient/body and genuine SNLoad0 remain. Hybrid boundary, MAT=ZT, actual demand four rate/energy writes, humidity correction, airHumRat handoff, RH calculation and max absolute history change preserve Native order.',
    ],
    'humidity_proof': [
        'Actual Zone.IsControlled selects ordered physical inlet T-independent mass/humidity reads; MoistureMass += (Mass*W)/integerZoneMult, ZoneMass += Mass/ZoneMult in Native order. Plenum/leakage children remain explicit.',
        'Real latentGain plus both fan fields, seconds, normal Rho, vaporization Hg, exact B/A/C grouping and optional AFN/duct boundaries precede literal ThirdOrder humidity solve; no algebraic regrouping.',
        'Negative solved humidity writes0 before saturation; normal WFromRh uses live ZT/RH1/current pressure on same Psat state/cache, then actual saturation upper clamp. RoomAFN/hybrid bounds precede actual physical Node.HumRat then enthalpy H; latent-sizing positive remains first real-operation boundary.',
    ],
    'property_proof': [
        'Normal Rho/H humidity floor and Hg formula match Native; public normal Cp uses genuine saved input/result(-100 cold), equality before floor, ordered last-call writes and the same retained thread-local normal cache. No fast Cp or cache reset/new instance.',
        'Same SourcePsychrometricAccess reaches thread-local PROPERTY_STATE. Psat signed tag/right-shift28/hash, actual tag write, representative reconstruction and value write match Native cache path; WFromRh dew/denominator max1000/floor1e-5 and RH helper equations match normal numerical path.',
        'Existing RH extreme result guard is conservative typed unrepresented PsyRh_error boundary; normal small out-of-range clamp uses Native min/max operand behavior. New caller raw-temperature guards exclude missing Psat diagnostics without pretending to model cache-hit/representative/Warmup/CalledFrom effects.',
        'Retained actual Native build compiler-macro authority belongs to authenticated Source30 parent/original scoped peer. No new Native build/probe or error/stat counter implementation claimed; bounded single-thread Source cache policy unchanged.',
    ],
    'qualification': 'Source31 remains prospective until Root actual30 reaches it. This acceptance covers genuine normal ThirdOrder zone-only paths and explicit unsupported optional/property boundaries, not actual31 execution, all12/fullB or same-state Native corrector numerical equivalence. No new tests or repeated cohort.',
    'new_tests': 0, 'main_Cargo_Native_tests_or_production_mutations': False, 'author_Source': ref(Path(__file__)),
}
print(json.dumps(save('review.json', (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())))

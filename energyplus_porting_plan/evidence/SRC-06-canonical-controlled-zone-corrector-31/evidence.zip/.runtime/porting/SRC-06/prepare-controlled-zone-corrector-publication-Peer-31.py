"""Prepare guarded Source31 publisher after final31 sealer; never publish."""
import ast
import difflib
import hashlib
import json
import re
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
OLD = D / 'publish-hvac-controlled-node-lifecycle-checkpoint-Peer-30.py'
NEW = D / 'publish-controlled-zone-corrector-checkpoint-Peer-31.py'
OUT = D / 'controlled-zone-corrector-publication-prepared-Peer-31'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def checked(row):
    p = R / row['path']
    assert ref(p)['sha256'] == row['sha256']
    if 'bytes' in row:
        assert ref(p)['bytes'] == row['bytes']
    return p

assert ref(OLD)['sha256'] == '26b6e7498563a78412d3c0fb2a9c577598376082ab3e2dab45ab7904928f44de'
assert not NEW.exists() and not OUT.exists()
source = OLD.read_text(encoding='utf-8')
body = source
def replace(before, after, count=1):
    global body
    assert body.count(before) == count, (before, body.count(before), count)
    body = body.replace(before, after)

replace('checkpoint30', 'checkpoint31', 2)
replace('hvac-controlled-node-lifecycle', 'controlled-zone-corrector', 8)
replace('Peer-30', 'Peer-31', 2)
replace('Root-30', 'Root-31', 2)
replace('SRC-06-canonical-controlled-zone-corrector-30', 'SRC-06-canonical-controlled-zone-corrector-31', 2)
replace("    assert contains(peer,producer['original_draft02'])\n    assert producer['independent_semantic_peers']['fourth_and_identity'] == ref(peer_path)\n    original_peer_path = checked(template['accepted_original_three_peer'])\n    original_peer = accepted(original_peer_path,template['accepted_original_three_peer']['sha256'])\n    assert peer['original_three_Source_peer'] == ref(original_peer_path) == producer['independent_semantic_peers']['original_three']\n    assert producer['all4_proposals_whole_unchanged_from_reviewed_draft02'] is True", "    assert contains(peer,producer['original_draft03'])\n    assert producer['independent_full_semantic_peer'] == ref(peer_path)\n    assert producer['all4_proposals_whole_unchanged_from_reviewed_draft03'] is True")
replace('Root-source-controlled-zone-corrector-actual-review-30', 'Root-source-controlled-zone-corrector-actual-review-31')
replace("[template['producer'],ref(peer_path),ref(original_peer_path),template['complete_plan']]", "[template['producer'],ref(peer_path),template['complete_plan']]", 2)
replace('[Path(__file__),template_path,peer_path,original_peer_path,actual_path]', '[Path(__file__),template_path,peer_path,actual_path]')
replace('whole_JSON_equal29_after_exactly_two_owned_path_field_bridges', 'whole_JSON_equal30_after_exactly_two_owned_path_field_bridges')
replace('full_runtime_equal29_after_two_owned_path_bridges', 'full_runtime_equal30_after_two_owned_path_bridges')
replace('src06-canonical30-finite-evidence-archive.v1', 'src06-canonical31-finite-evidence-archive.v1')
replace('4 coherent HVAC physical-Node lifecycle/return-air flag Sources, Native authority, two explicitly scoped semantic peers and actual B/A24.', '4 coherent controlled-zone sums/temperature/humidity and physical-Node borrow Sources, Native authority, one full independent semantic peer and actual B/A24.')
replace("status='Genuine Source controlled HVAC Node lifecycle; B incomplete at actual frontier'", "status='Genuine Source controlled-zone ThirdOrder corrector; B incomplete at actual frontier'")
replace("independent_semantic_peers=producer['independent_semantic_peers']", 'independent_peer=ref(peer_path)')
for before, after in [('accepted29_proof', 'accepted30_proof'), ('accepted29_full5352_proof', 'accepted30_full5352_proof'), ('physical_files_whole_equal29', 'physical_files_whole_equal30'), ('whole_physical_streams_equal29', 'whole_physical_streams_equal30'), ('CSV_files_whole_equal29', 'CSV_files_whole_equal30'), ('whole_CSV_equal29', 'whole_CSV_equal30'), ('Proof transfer from accepted29;', 'Proof transfer from accepted30;')]:
    replace(before, after)
replace('Source HVAC Node 생명주기 검증', 'Source 구역 온습도 보정 검증')
replace("key='canonical_hvac_controlled_node_lifecycle_30'", "key='canonical_controlled_zone_corrector_31'")
ast.parse(body)
producer_path = D / 'source-controlled-zone-corrector-held-Peer-31/manifest.json'
producer = json.loads(producer_path.read_bytes())
assert (producer['compiler_inputs'], producer['Rust_sources']) == (4503, 4490)
assert producer['all4_proposals_whole_unchanged_from_reviewed_draft03']
peer_path = checked(producer['independent_full_semantic_peer'])
peer = json.loads(peer_path.read_bytes())
assert peer['accepted'] and not peer['findings']
assert peer['reviewed_packet'] == producer['original_draft03']
previous = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-hvac-controlled-node-lifecycle-30/summary.json'
assert json.loads(previous.read_bytes())['A'] == '14/54'
NEW.write_text(body, encoding='utf-8', newline='\n')
OUT.mkdir()
finite = {}
def add(p):
    row = ref(p)
    assert p.suffix.lower() != '.zip'
    if row['path'] in finite:
        assert finite[row['path']] == row
    finite[row['path']] = row

for p in [producer_path, peer_path, checked(producer['complete_final_compiler_Source_plan']), checked(producer['full4503_parent_readback']), checked(producer['whole4490_Rust_API_census']), checked(producer['original_draft03']), checked(producer['author_Source']), checked(producer['accepted30_actual_review']), checked(producer['property_boundary_correction']), checked(peer['author_Source']), previous, OLD, NEW, Path(__file__)]:
    add(p)
for row in producer['files']:
    for key in ['before', 'proposed', 'literal_inverse', 'forward_diff', 'inverse_diff']:
        add(checked(row[key]))
    for key in ['stdout', 'stderr']:
        add(checked(row['Source_only_parse'][key]))
for row in producer['Native_authorities']:
    add(checked(row['whole']))
    for extent in row['extents']:
        add(checked(extent['source']))
for row in producer['concrete_same_owner_contexts']:
    add(checked(row['whole']))
for row in peer['resolved_genuine_property_finding']['independent_whole_inverse_checks']:
    add(checked(row['exact_added_guard']))
template = {
    'schema': 'src06-held-canonical31-publication-template.v1', 'status': 'HELD_FOR_ROOT_ACTUAL31_AND_FULL_READ',
    'base_HEAD': producer['base_HEAD'], 'producer': ref(producer_path), 'complete_plan': producer['complete_final_compiler_Source_plan'],
    'accepted_independent_peer': ref(peer_path), 'accepted30_actual_review': producer['accepted30_actual_review'],
    'previous_checkpoint': ref(previous), 'publisher_Source': ref(NEW), 'publisher_parent_Source': ref(OLD),
    'expected_actual_review_path': '.runtime/porting/SRC-06/Root-source-controlled-zone-corrector-actual-review-31/review.json',
    'pending_Root_custody': {
        'application': '.runtime/porting/SRC-06/Root-controlled-zone-corrector-application-31/receipt.json',
        'actual_review_sha256': 'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source': '.runtime/porting/SRC-06/check-source-controlled-zone-corrector-actual-Root-31.py',
        'launcher_Source': '.runtime/porting/SRC-06/launch-controlled-zone-corrector-Root-31.py',
        'B_CLI': '.runtime/porting/SRC-06/canonical-source-controlled-zone-corrector-B-NOLIMIT-24H-command-Root-31/receipt.json',
        'A24_CLI': '.runtime/porting/SRC-06/canonical-source-controlled-zone-corrector-A-24H-command-Root-31/receipt.json',
    },
    'Root_custody_at_publish': 'Byte-authenticate actual aggregate/application, full semantic peer, author Sources, launcher and both actual CLI receipts/artifacts. Static review does not establish executed paths or paired internal Native equivalence.',
    'summary_template': {
        'A': '14/54', 'B': '14/64', 'changed_Rust_sources': 4, 'existing_Rust_sources': 4, 'new_Rust_sources': 0,
        'new_test_functions': 0, 'actual_test_bodies_executed': 0,
        'focused_validation_policy': 'Actual production B then appropriate A24 only. No unrelated test/profile, repeated cohort, new test or alltargets.',
        'scope': producer['scope'],
        'property_boundary_qualification': 'Two actual caller-local raw-temperature bounds conservatively exclude unported Psat diagnostic/CalledFrom operations. They do not model the exact representative/cache-hit/Warmup warning predicate.',
        'full_B_or_finite15_completion_claim': False, 'Native_harness_runtime_or_unit_equivalence_claim': False, 'gate_changes': False, 'policy_changes': False,
    },
    'doc_appends': {
        'CHECKLIST.md': '제어 구역의 실제 공급 Node를 사용하는 ThirdOrder 온도·습도 보정 경로를 연결했습니다. 실제 B 경계와 A24 회귀 결과는 연결된 증거에 기록합니다.',
        'STATE_CONTRACTS.md': '공급 유량 합과 현열·수분 보정은 같은 Config·Node·AirHB 및 정상 Cp·포화압 캐시를 사용합니다. 계산값과 보고 필드의 쓰기 순서를 보존하며, 미구현 포화압 진단 경계는 실제 호출 직전에 명시합니다.',
        'cards/SRC-06.md': '제어 구역 온습도 보정 묶음의 실행 결과를 기록합니다. B의 실제 경계는 `{{actual_B_frontier}}`이며, 전체 B 또는 내부 Native 보정 상태의 수치 동등성 완료를 주장하지 않습니다.',
    },
    'finite_archive_inputs': [row for _, row in sorted(finite.items())], 'finite_archive_input_count': len(finite), 'finite_archive_input_bytes': sum(row['bytes'] for row in finite.values()),
    'publisher_executed': False, 'canonical_docs_mutations': False, 'Cargo_tests_Native_executed': False, 'gate_changes': False,
}
template_path = OUT / 'publication-template.json'
template_path.write_text(json.dumps(template, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
diffs = {}
for name, before, after in [('forward', source.encode(), body.encode()), ('inverse', body.encode(), source.encode())]:
    delta = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=OLD.name, tofile=NEW.name)).encode()
    assert ns['apply_literal'](before, delta) == after
    p = OUT / (name + '.diff')
    p.write_bytes(delta)
    diffs[name] = ref(p)
proof = {'parent': ref(OLD), 'successor': ref(NEW), 'literal_applications': 2, 'diffs': diffs, 'template': ref(template_path), 'scope': 'Source30 two-CLI/no-test publication algorithm with exact31 Source/base/paths/scope, one full semantic peer, corrected03 guards and prior30 proof transfer. No execution.', 'publisher_executed': False, 'canonical_mutations': False}
bridge_path = OUT / 'publisher-parent-bridge.json'
bridge_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'publisher': ref(NEW), 'template': ref(template_path), 'bridge': ref(bridge_path)}))

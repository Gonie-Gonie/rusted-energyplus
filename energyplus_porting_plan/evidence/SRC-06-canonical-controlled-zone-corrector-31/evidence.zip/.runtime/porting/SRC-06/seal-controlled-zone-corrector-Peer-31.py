"""Final Source31 join, gated on actual30 and its committed clean HEAD."""
import argparse
import ast
import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
OUT = D / 'source-controlled-zone-corrector-held-Peer-31'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def auth(row):
    p = R / row['path']
    assert ref(p)['sha256'] == row['sha256'], row
    if 'bytes' in row:
        assert ref(p)['bytes'] == row['bytes'], row
    return p

def load(path, sha):
    p = R / path
    assert ref(p)['sha256'] == sha
    return p, json.loads(p.read_bytes())

def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], check=True, capture_output=True).stdout

def save(name, b):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_bytes(b)
    return ref(p)

def dump(name, value):
    return save(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

a = argparse.ArgumentParser()
a.add_argument('--base-head', required=True)
a.add_argument('--actual30-review', required=True)
a.add_argument('--actual30-sha', required=True)
a.add_argument('--seal', action='store_true')
a = a.parse_args()
assert a.seal and re.fullmatch('[0-9a-f]{40}', a.base_head)
assert git(R, 'rev-parse', 'HEAD').decode().strip() == a.base_head
assert git(R, 'rev-parse', 'origin/main').decode().strip() == a.base_head
assert not git(R, 'status', '--porcelain=v1', '-uno').strip()
assert not OUT.exists()
dp, draft = load('.runtime/porting/SRC-06/source-controlled-zone-corrector-draft-Outer-31-03/draft.json', '9bb470506d1faa7d698a204757d6b590d142ddeade9021194c984440cc150a2d')
pp, peer = load('.runtime/porting/SRC-06/Peer-controlled-zone-corrector-Source-review-31-03-02/review.json', 'eecdee3b60ab1f58efaf89a759016666909be3081632001d54dae73560d842b5')
assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet'] == ref(dp)
ap, actual = load(a.actual30_review, a.actual30_sha)
assert actual['accepted'] and not actual['findings']
assert actual['B_frontier'] == 'GetHeatBalanceInput: positive controlled Zone supply sums5203'
parent_path = auth(actual['producer'])
parent = json.loads(parent_path.read_bytes())
assert ref(parent_path) == peer['logical_parent30']
plan_path = auth(actual['complete_compiler_plan'])
assert ref(plan_path) == peer['parent_complete_plan']
plan = json.loads(plan_path.read_bytes())
assert (plan['inputs'], plan['Rust_sources']) == (4503, 4490)
assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0
receipts = {}
for label, key, code in [('B-NOLIMIT-24H', 'actual_B', 6), ('A-24H', 'actual_A24', 0)]:
    p = auth(actual[key])
    run = json.loads(p.read_bytes())
    assert run['exit_code'] == code and run['source_bytes_match_before_and_after']
    receipts[label] = {'receipt': ref(p), 'exit_code': code, 'snapshot': run['source_snapshot']}
assert receipts['B-NOLIMIT-24H']['snapshot'] == receipts['A-24H']['snapshot']
snapshot_path = auth(receipts['B-NOLIMIT-24H']['snapshot'])
snapshot = json.loads(snapshot_path.read_bytes())
archives = {row['historical_path']: row['archive'] for row in snapshot['files']}
entries = {row['path']: copy.deepcopy(row) for row in plan['entries']}
assert len(entries) == len(archives) == 4503 and set(entries) == set(archives)
readback = []
for name, entry in entries.items():
    b = auth(archives[name]).read_bytes()
    assert b == auth(entry['source']).read_bytes() == (R / name).read_bytes(), name
    assert (hashlib.sha256(b).hexdigest(), len(b)) == (entry['final_sha256'], entry['final_bytes']), name
    readback.append({'path': name, 'actual_archive': archives[name], 'actual_sha256': entry['final_sha256'], 'actual_bytes': len(b), 'whole_live_equal_actual_and_plan': True})
t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
peer_rows = {row['canonical_path']: row for row in peer['files']}
files = []
logical = {}
for i, row in enumerate(draft['files'], 1):
    name = row['canonical_path']
    before = auth(row['before']).read_bytes()
    new = auth(row['proposed']).read_bytes()
    assert before == auth(archives[name]).read_bytes() == (R / name).read_bytes() == git(R, 'show', a.base_head + ':' + name)
    assert row['proposed'] == peer_rows[name]['proposed']
    assert ns['apply_literal'](before, auth(row['forward_diff']).read_bytes()) == new
    assert ns['apply_literal'](new, auth(row['inverse_diff']).read_bytes()) == before
    assert auth(row['literal_inverse']).read_bytes() == before
    parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parse.returncode == 0, (name, parse.stderr)
    proposed = save('proposed/' + name, new)
    files.append({'canonical_path': name, 'before_absent': False, 'before': save('before/' + name, before), 'actual_parent_archive': archives[name], 'proposed': proposed, 'literal_origin_whole': row['proposed'], 'literal_inverse': save('literal-inverse/' + name, before), 'forward_diff': save(f'diffs/{i:02}-forward.diff', auth(row['forward_diff']).read_bytes()), 'inverse_diff': save(f'diffs/{i:02}-inverse.diff', auth(row['inverse_diff']).read_bytes()), 'before_whole_Git_exact_at_base': True, 'Source_only_parse': {'exit_code': 0, 'stdout': save(f'parse/{i:02}.stdout', parse.stdout), 'stderr': save(f'parse/{i:02}.stderr', parse.stderr)}})
    entries[name] = {'path': name, 'final_sha256': proposed['sha256'], 'final_bytes': proposed['bytes'], 'source': proposed, 'origin': 'Whole accepted corrected Source31 draft03 proposal; no semantic rewrite'}
    logical[name] = new.decode()
assert len(files) == 4 and len(entries) == 4503 and sum(x.endswith('.rs') for x in entries) == 4490
assert 'crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs' not in entries
for name in entries:
    if name.endswith('pipeline.json'):
        assert entries[name] == next(row for row in plan['entries'] if row['path'] == name)
terms = peer['whole_crates_API_census']['patterns']
api = []
for name, entry in sorted(entries.items()):
    if not name.endswith('.rs'):
        continue
    text = logical.get(name)
    if text is None:
        text = auth(entry['source']).read_text(encoding='utf-8')
    found = [term for term in terms if term in text]
    if found:
        api.append({'path': name, 'terms': found})
assert api == peer['whole_crates_API_census']['files']
native = []
for row in peer['Native_wholes']:
    name = row['Native_path']
    b = auth(row['whole']).read_bytes()
    assert b == git(N, 'show', PIN + ':' + name) == (N / name).read_bytes()
    lines = b.splitlines(keepends=True)
    extents = []
    for extent in row['extents']:
        first, last = extent['first'], extent['last']
        value = b''.join(lines[first - 1:last])
        assert value == auth(extent['source']).read_bytes()
        extents.append({'first': first, 'last': last, 'source': save('Native-extents/' + Path(name).name + f'.{first}-{last}.txt', value)})
    native.append({'Native_path': name, 'whole': save('Native/' + name, b), 'pinned_Git_exact': True, 'extents': extents})
contexts = []
for row in peer['concrete_Source_contexts']:
    name = row['canonical_path']
    b = auth(row['whole']).read_bytes()
    assert b == auth(archives[name]).read_bytes() == (R / name).read_bytes() == git(R, 'show', a.base_head + ':' + name)
    contexts.append({'canonical_path': name, 'whole': row['whole'], 'actual_parent_archive': archives[name], 'current_and_Git_exact': True})
correction_path = auth(draft['property_boundary_correction'])
assert peer['resolved_genuine_property_finding']['author_correction'] == ref(correction_path)
final_plan = dump('complete-final-compiler-Source-plan.json', {'schema': 'src06-complete-Source31-compiler-input-plan.v1', 'base_HEAD': a.base_head, 'actual30_parent_snapshot': ref(snapshot_path), 'prior_plan': ref(plan_path), 'inputs': 4503, 'Rust_sources': 4490, 'entries': [entries[name] for name in sorted(entries)], 'selected4_exact_draft03': True, 'quarantined_diagnostic_child_absent': True, 'Root_full_readback_required': True})
manifest = {'schema': 'src06-held-coherent-controlled-zone-corrector.v1', 'status': 'HELD Source31 on clean committed actual30; no Source31 runtime claim', 'base_HEAD': a.base_head, 'accepted30_actual_review': ref(ap), 'parent_producer': ref(parent_path), 'actual_parent_receipts': receipts, 'actual_parent_snapshot': ref(snapshot_path), 'prior_complete_compiler_Source_plan': ref(plan_path), 'complete_final_compiler_Source_plan': final_plan, 'compiler_inputs': 4503, 'Rust_sources': 4490, 'original_draft03': ref(dp), 'independent_full_semantic_peer': ref(pp), 'files': files, 'existing_Source_files': 4, 'new_Source_files': 0, 'selected_Source_files': 4, 'literal_applications': 8, 'Source_only_parses': 4, 'all4_proposals_whole_unchanged_from_reviewed_draft03': True, 'full4503_parent_readback': dump('actual30-parent-full-readback.json', readback), 'whole4490_Rust_API_census': dump('API-census.json', {'Rust_sources_examined': 4490, 'all_crates_runtime_tests_included': True, 'hits': api, 'known_prior_metadata_omission_qualified': peer['whole_crates_API_census']['old_author_seven_paths_plus_exact_accepted30_convergence_caller'], 'new_tests': 0}), 'Native_commit': PIN, 'Native_authorities': native, 'concrete_same_owner_contexts': contexts, 'property_boundary_correction': ref(correction_path), 'resolved_genuine_property_finding': peer['resolved_genuine_property_finding'], 'operation_order': {'owner': peer['owner_proof'], 'sums': peer['sums_proof'], 'temperature': peer['temperature_proof'], 'humidity': peer['humidity_proof'], 'property': peer['property_proof']}, 'scope': 'Same retained physical Node/Config/zone AirHB ThirdOrder controlled supply sums, temperature and humidity correction. Actual normal Cp/Psat cache and per-field writes, no legacy facade or numerical mirror. Corrected two actual property-call boundaries retain honest conservative normal-temperature domain.', 'remaining_scope': peer['qualification'], 'validation_policy': 'Root owns actual production B then appropriate A24 transfer; no new tests, repeated cohort, whole-suite, Cargo/Native/main mutation by author.', 'new_test_bodies': 0, 'Cargo_main_tests_or_Native_mutations': False, 'author_Source': ref(Path(__file__))}
print(json.dumps(dump('manifest.json', manifest)))

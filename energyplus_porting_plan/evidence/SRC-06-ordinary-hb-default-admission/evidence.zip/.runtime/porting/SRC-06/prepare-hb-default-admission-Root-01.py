"""Prepare exact supported HB defaults and extend the existing admission test."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

root = Path.cwd()
base = root/'.runtime/porting/SRC-06'
out = base/'ordinary-hb-default-admission-prep-01'
assert not out.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'])
head = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert head == '95451ff6db1ae8f34a71dc62122eba05a4048cb6'

def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(root).as_posix(), 'sha256':hashlib.sha256(data).hexdigest(), 'size_bytes':len(data)}

audit = base/'Owner-ordinary-heat-balance-default-admission-audit-01/audit.json'
assert ref(audit)['sha256'] == 'f2763ad51b14e55989fc2bddd2993cc4a1a05170220fe50e0befde71e5713d8e'
name = 'crates/ep_run/src/ordinary_equipment_input.rs'
before = (root/name).read_bytes()
assert before == subprocess.check_output(['git', 'show', head+':'+name])
text = before.decode()
old = '''                        && field(object, "surface_temperature_upper_limit").is_none_or(blank)
                        && field(
                            object,
                            "maximum_surface_convection_heat_transfer_coefficient_value",
                        )
                        .is_none_or(blank)'''
new = '''                        // Explicit schema defaults have the same retained values as blanks.
                        // Dynamic nondefault high limits still lack downstream consumers.
                        && field(object, "surface_temperature_upper_limit")
                            .is_none_or(|value| blank(value) || number(value) == Some(200.0))
                        && field(
                            object,
                            "maximum_surface_convection_heat_transfer_coefficient_value",
                        )
                        .is_none_or(|value| blank(value) || number(value) == Some(1000.0))'''
assert text.count(old) == 1
text = text.replace(old, new)
needle = '        for (name, input, expected_timestep) in [\n'
extra = '''        for (fields, accepted) in [
            (r#""surface_temperature_upper_limit":200"#, true),
            (
                r#""maximum_surface_convection_heat_transfer_coefficient_value":1000"#,
                true,
            ),
            (
                r#""algorithm":"ConductionTransferFunction","surface_temperature_upper_limit":200,"minimum_surface_convection_heat_transfer_coefficient_value":0.1,"maximum_surface_convection_heat_transfer_coefficient_value":1000"#,
                true,
            ),
            (r#""surface_temperature_upper_limit":201"#, false),
            (
                r#""maximum_surface_convection_heat_transfer_coefficient_value":1001"#,
                false,
            ),
            (r#""surface_temperature_upper_limit":"200""#, false),
            (
                r#""maximum_surface_convection_heat_transfer_coefficient_value":"1000""#,
                false,
            ),
            (
                r#""surface_temperature_upper_limit":null,"maximum_surface_convection_heat_transfer_coefficient_value":" ""#,
                true,
            ),
            (r#""algorithm":"ConductionFiniteDifference""#, false),
            (r#""unknown_high_limit":1000"#, false),
        ] {
            let raw = parse_epjson_str(&format!(
                "{{{base},\\"HeatBalanceAlgorithm\\":{{\\"h\\":{{{fields}}}}}}}"
            ))?;
            assert_eq!(resolve(&raw).is_ok(), accepted, "HB fields {fields}");
        }
'''
assert text.count(needle) == 1
text = text.replace(needle, extra+needle)
after = text.encode()
assert after.count(b'#[test]') == before.count(b'#[test]') == 1
out.mkdir()
refs = {}
for kind, data in [('before',before), ('proposed',after)]:
    path = out/kind/name
    path.parent.mkdir(parents=True)
    path.write_bytes(data)
    refs[kind] = ref(path)
diff = out/'ordinary_equipment_input.rs.diff'
diff.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=name, tofile=name)).encode())
value = {'schema':'src06-hb-default-admission-preparation.v1', 'status':'HELD not applied or tested',
    'base_HEAD':head, 'files':[{'canonical_path':name, 'before':refs['before'], 'proposal':refs['proposed'], 'complete_diff':ref(diff)}],
    'independent_default_audit':ref(audit), 'Original_commit':'6f2e40d10250a105b49966baa24d843711e61048',
    'Original_ranges':json.loads(audit.read_bytes())['Original_ranges'],
    'author':ref(Path(__file__)), 'logic':'Preserve absent/blank admission and admit only finite numeric exact 200/1000 defaults. Nondefault upper/high, numeric strings, unsupported algorithms and fields still rejected. Minimum coefficient and production getter untouched.',
    'existing_test_body_extension':'Ten table rows in the same existing body; independent exact defaults, combined real A values, two nondefaults, two numeric strings, preserved null/blank, unsupported algorithm and unknown field.',
    'new_test_bodies':0, 'new_test_binaries':0, 'targets_executed':[], 'gates_updated':False}
(out/'manifest.json').write_bytes((json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode())
print(json.dumps(ref(out/'manifest.json')))

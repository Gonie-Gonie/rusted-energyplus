"""Root-owned execution only: finite default-admission evidence and two doc edits."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path.cwd()
BASE = ROOT / '.runtime/porting/SRC-06'
OUT = ROOT / 'energyplus_porting_plan/evidence/SRC-06-ordinary-hb-default-admission'
ASSEMBLY = BASE / 'ordinary-hb-default-admission-assembly-01/manifest.json'
REVIEW = BASE / 'Owner-ordinary-hb-default-admission-application-review-01/review.json'
PREFIX = 'ordinary-hb-default-admission'
CARGO = 'C:/Users/GonieGonie/.cargo/bin/cargo.exe'
PS = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File']

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def load(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8'))

def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            yield value
        else:
            for child in value.values():
                yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)

assert not OUT.exists()
assert ref(ASSEMBLY)['sha256'] == '07d32d1aec8250ad86ce61a710b09ba96a8e7b03f10594445cfdb5779fb671f3'
assert ref(REVIEW)['sha256'] == '928f57b1adfe3aeb2c8b3fd55f9464839c62451677da34f492eefee4cad64e2e'
assembly, review = load(ASSEMBLY), load(REVIEW)
assert review['accepted'] is True and review['actual_assembly'] == ref(ASSEMBLY)
held_path = ROOT / assembly['accepted_packet']['path']
assert ref(held_path)['sha256'] == '5a2b1d100d31d2ccef5b3bf20474805b7dc853ab66b1291f172ce66b8ab3c09d'
held = load(held_path)
audit_path = ROOT / held['independent_default_audit']['path']
assert ref(audit_path)['sha256'] == 'f2763ad51b14e55989fc2bddd2993cc4a1a05170220fe50e0befde71e5713d8e'
archives, artifacts, historical = {}, {}, []
for version, keys in [(assembly, ['before', 'after', 'accepted_proposal']), (held, ['before', 'proposal'])]:
    for row in version['files']:
        for key in keys:
            value = row[key]
            archives[value['sha256']] = ROOT / value['path']

def add(path):
    value = ref(path)
    artifacts[value['path']] = value
    return value

def checked(value):
    path = ROOT / value['path']
    if not path.is_file() or ref(path)['sha256'] != value['sha256']:
        path = archives[value['sha256']]
        historical.append({'historical_reference': value, 'exact_archive': ref(path)})
    actual = ref(path)
    assert actual['sha256'] == value['sha256'] and actual['size_bytes'] == value.get('size_bytes', actual['size_bytes'])
    add(path)
    return path

for path in [ASSEMBLY, REVIEW, held_path, audit_path, ROOT / assembly['apply']['path'], ROOT / assembly['independent_Source_review']['path']]:
    add(path)
    for value in walk(load(path)):
        checked(value)
assert len(assembly['files']) == 1 and assembly['files'][0]['canonical_path'] == 'crates/ep_run/src/ordinary_equipment_input.rs'
for row in assembly['files']:
    assert ref(ROOT / row['canonical']['path']) == row['canonical']

def recorded(path, expected_command):
    value = load(path)
    assert value['command'] == expected_command
    assert isinstance(value['exit_code'], int) and value['source_bytes_match_before_and_after'] is True
    add(path)
    for key in ['stdout', 'stderr', 'source_snapshot']:
        checked(value[key])
    checked(value['executed_launcher']['archive'])
    return value

test_name = 'ordinary_equipment_input::tests::raw_equipment_admission_preserves_empty_presence_and_rejects_positive_or_field_branches'
commands = {
    'fmt': [CARGO, 'fmt', '--all', '--', '--check'],
    'quality': PS + ['scripts/quality/source-quality-gate.ps1'],
    'clippy': [CARGO, 'clippy', '-p', 'ep_run', '--all-targets', '--', '-D', 'warnings'],
    'focused-tests': [CARGO, 'test', '-p', 'ep_run', '--lib', test_name, '--', '--exact'],
    'cli-tests': [CARGO, 'test', '-p', 'ep_run', '--test', 'arbitrary_run', 'one_zone_runtime_writes_stable_output_layout'],
    'ci-timestep-tests': PS + ['.runtime/porting/SRC-06/run-ci-force-time-step-Root-01.ps1'],
}
qa, tests, snapshot = [], [], None
for scope, command in commands.items():
    path = BASE / f'{PREFIX}-{scope}-01/receipt.json'
    value = recorded(path, command)
    assert value['exit_code'] == 0 and value['launch_error'] is None
    if snapshot is None:
        snapshot = value['source_snapshot']
    assert snapshot == value['source_snapshot']
    qa.append({'scope': scope, 'receipt': ref(path), 'command': command, 'exit_code': value['exit_code']})
    if 'tests' in scope:
        groups = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (ROOT / value['stdout']['path']).read_text(encoding='utf8'))]
        assert groups == [(1, 0, 0)]
        tests.append({'scope': scope, 'passed': 1, 'failed': 0, 'ignored': 0})
assert len(tests) == 3
add(BASE / 'run-ci-force-time-step-Root-01.ps1')
add(ROOT / 'scripts/quality/source-quality-gate.ps1')

def a_command(output):
    return [CARGO, 'run', '-p', 'ep_cli', '--bin', 'eplus-rs', '--', 'run', 'energyplus_porting_plan/cases/A-24H/input.idf',
            '--weather', '.runtime/energyplus/26.1.0/WeatherData/USA_CO_Golden-NREL.724666_TMY3.epw', '--output-dir', output,
            '--mode', 'compatibility', '--partial', 'deny', '--porting-scope', 'A', '--format', 'rust-native', '--hours', '24',
            '--keep-intermediate', '--trace-level', 'summary', '--json']

executions = []
for role, unit in [('historical_before', 'ordinary-post-hb-outdoor'), ('actual_after', PREFIX)]:
    output = f'.runtime/porting/SRC-06/{unit}-A-24H-cli-01/output'
    path = BASE / f'{unit}-A-24H-cli-command-01/receipt.json'
    value = recorded(path, a_command(output))
    if role == 'historical_before':
        assert ref(path)['sha256'] == '794eca25891b3bf266796ddb3aad745f84a59f54711116cf1030ad9a0fd68b16'
        assert value['exit_code'] == 6 and value['launch_error'] is None
    else:
        assert value['source_snapshot'] == snapshot
    selected, missing = {}, []
    for name in ['run-summary.json', 'diagnostics.json', 'eplusrs.err', 'support-assessment.json', 'support-report.md',
                 'logs/command.log', 'reports/run-report.md', 'reports/compatibility-boundary.md', 'input/input-hashes.json', 'input/converted.epJSON']:
        target = ROOT / output / name
        if target.is_file():
            selected[name] = add(target)
        else:
            missing.append(name)
    summary_path = ROOT / output / 'run-summary.json'
    run = load(summary_path) if summary_path.is_file() else None
    if run is not None:
        assert run['exit_code'] == value['exit_code']
        assert run['support']['conformance_claim'] is False
        assert run['oracle_status'] == 'not-requested' and run['compare_status'] == 'not-requested'
    runtime = {} if run is None else (run.get('rust_runtime') or {})
    executions.append({'role': role, 'receipt': ref(path), 'exit_code': value['exit_code'], 'launch_error': value['launch_error'],
        'Source_snapshot': value['source_snapshot'], 'run_status': None if run is None else run['status'],
        'run_message': None if run is None else run['message'], 'selected_actual_outputs': selected, 'not_emitted_selected_outputs': missing,
        'runtime_samples': runtime.get('samples'), 'runtime_series': runtime.get('series'),
        'sample_count_scope': 'Actual CLI output sample count only; no Source timestep count inferred from input Timestep or sample count.',
        'conformance_claim': None if run is None else run['support']['conformance_claim'],
        'oracle_status': None if run is None else run['oracle_status'], 'compare_status': None if run is None else run['compare_status'],
        'qualification': 'Actual execution result only; not a unit-test count, Native pairing, full Setup or conformance PASS.'})
add(ROOT / 'energyplus_porting_plan/cases/A-24H/input.idf')
add(Path(__file__).resolve())

plan_path, card_path = ROOT / 'energyplus_porting_plan/plan.json', ROOT / 'energyplus_porting_plan/cards/SRC-06.md'
plan, card = load(plan_path), card_path.read_text(encoding='utf8')
task = next(row for row in plan['tasks'] if row['id'] == 'SRC-06')
key = 'actual_selected_ordinary_heat_balance_default_admission'
assert all(task[field] == '미확인' for field in ['scope_review', 'unit_gate', 'integration_gate', 'production_gate']) and key not in task
assert card.count('아래 22개 요약') == 1
row_needle, section_needle = '\n기존 Weather03·absent site/station', '\n## 이력과 증거 보존'
assert card.count(row_needle) == 1 and card.count(section_needle) == 1

OUT.mkdir()
archive = OUT / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts):
        z.write(ROOT / name, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(artifacts) and set(z.namelist()) == set(artifacts)
    for name in z.namelist():
        data = z.read(name)
        assert len(data) == artifacts[name]['size_bytes'] and hashlib.sha256(data).hexdigest() == artifacts[name]['sha256']
write(OUT / 'manifest.json', {'schema': 'src06-hb-default-admission-evidence.v1', 'actual_assembly': ref(ASSEMBLY),
    'Source_snapshot': snapshot, 'artifacts': list(artifacts.values()), 'historical_references': historical,
    'archive': ref(archive), 'archive_member_count': len(artifacts), 'gates_updated': False,
    'scope': 'One current Source/before/after and diffs; actual application and reviews; finite default audit/four Original ranges/schema excerpt; six final QA receipts/full logs/indexes/actual recorder; before-and-after A receipts and finite actual diagnostics. No recursive historical archives, EPW payload, Native binary/map/core or numerical comparison.'})
summary = {'schema': 'src06-hb-default-admission-summary.v1', 'status': 'Exact default-only HeatBalanceAlgorithm ordinary admission connected',
    'Source_snapshot': snapshot, 'actual_assembly': ref(ASSEMBLY), 'independent_application_review': ref(REVIEW),
    'behavior': 'Existing absent/null/blank behavior retained. Finite numeric upper-temperature200 and maximum-HConv1000 are admitted exactly, separately or together; nondefaults, numeric strings, unsupported algorithms/fields remain rejected. Actual production getter and min-HConv math unchanged.',
    'QA': qa, 'tests': {'selections': tests, 'passed': 3, 'failed': 0, 'ignored': 0, 'new_bodies': 0, 'new_binaries': 0},
    'QA_scope': 'fmt/source-quality plus affected ep_run all-target Clippy; one existing admission lib body with ten new rows, normal CLI1 and real CI_FORCE_TIME_STEP=Y CLI1. No full workspace Clippy or test repeat.',
    'A_executions': executions, 'limitations': ['A before/after actual exits and diagnostics are preserved independently of the three passing tests. An A exit0, if observed, is not Native numerical or full Setup equivalence.',
        'Nondefault high/max support, full GetSurfaceData/SetupZoneGeometry/GetHBInput/InitHB/Setup and downstream numerical inside/radiation/HVAC remain pending.',
        'Existing ordinary235456 mismatches/2754 unavailable and DesignDay nine strict failures/eight UNPAIRED are unchanged. Four gates remain unverified; A14/54 and B14/64 unchanged.'],
    'manifest': ref(OUT / 'manifest.json'), 'archive': ref(archive), 'gates_updated': False}
write(OUT / 'summary.json', summary)
task[key] = ref(OUT / 'summary.json')
write(plan_path, plan)
card = card.replace('아래 22개 요약', '아래 23개 요약')
card = card.replace(row_needle, '| HeatBalanceAlgorithm 기본값 admission | [요약](../evidence/SRC-06-ordinary-hb-default-admission/summary.json) · [색인](../evidence/SRC-06-ordinary-hb-default-admission/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-hb-default-admission/evidence.zip) | 실제 numeric200/1000 기본값만 허용. 기존 lib1·일반 CLI1·실제 CI CLI1 확인; A 전후 실제 결과는 별도 보존하며 full Setup·Native 수치 PASS로 확대하지 않음. |\n' + row_needle)
card = card.replace(section_needle, '\n## HeatBalanceAlgorithm 기본값 admission 단위의 QA\n\nSource `' + snapshot['sha256'] + '`에서 fmt·source-quality·영향받는 ep_run all-target Clippy와 기존 테스트 **3 passed / 0 failed / 0 ignored**를 확인했다. 같은 admission 본문에 열 개 표 행을 추가하고 일반 CLI1·실제 CI CLI1을 실행했다. A-24H 전후 실제 exit는 각각 ' + str(executions[0]['exit_code']) + ' / ' + str(executions[1]['exit_code']) + '이며 실제 diagnostics와 함께 보존한다. A 실행은 테스트 수에 더하지 않고 성공·수치 동등성을 미리 가정하지 않는다. 전체 workspace 반복·새 Native 실행은 없으며 모든 gate와 A/B 완료 수는 그대로다.\n' + section_needle)
card_path.write_bytes(card.encode('utf8'))
print(json.dumps({'summary': ref(OUT / 'summary.json'), 'archive': ref(archive), 'members': len(artifacts), 'tests': 3,
                  'A_actual_exit_codes': [row['exit_code'] for row in executions]}, ensure_ascii=False))

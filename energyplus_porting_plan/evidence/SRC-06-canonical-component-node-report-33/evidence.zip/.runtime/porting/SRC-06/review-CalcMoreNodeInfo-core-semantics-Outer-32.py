"""Independent held18 CORE semantics; author verification of my own32 mechanical join."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0';O=D/'Outer-CalcMoreNodeInfo-core-semantic-review-32';NC='6f2e40d10250a105b49966baa24d843711e61048'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def ck(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def load(r):return json.loads(ck(r))
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def main():
 assert not O.exists()
 pr=ref(D/'source-CalcMoreNodeInfo-continuation-draft-Outer-32/draft.json');assert pr['sha256']=='c1a0ebf38d908e6697e9b215202767e2797b192aa5c58896ae4e43f5d0dc41ef';m=load(pr)
 old=load(m['ancestry']['held18_draft']);p31ref=ref(D/'source-controlled-zone-corrector-held-Peer-31/manifest.json');assert p31ref['sha256']=='1cbe6323dffd4bd9ff614fda19640d2399edf06541fbd694254e8b617dceb951';p31=load(p31ref);plan=load(p31['complete_final_compiler_Source_plan']);entries={x['path']:x for x in plan['entries']};assert len(entries)==4503
 corepath='crates/ep_runtime/src/heat_balance/ordinary_equipment/node_reporting.rs';core=next(x for x in m['files'] if x['canonical_path']==corepath);oldcore=next(x for x in old['files'] if x['canonical_path']==corepath)
 assert ck(core['proposed'])==ck(oldcore['proposed']) and core['proposed']['sha256']=='aebbcb07071f27f20dfe95b3a1bca6c1e3afa7e715595fb273689c2fe69e67ad'
 owner=next(x for x in p31['files'] if x['canonical_path'].endswith('/ordinary_equipment.rs'));assert ck(owner['proposed'])==ck(m['unchanged_ordinary_equipment']['whole'])==ck(m['unchanged_ordinary_equipment']['identity_literal_inverse'])
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
 files=[];selected={}
 for i,row in enumerate(m['files'],1):
  p=row['canonical_path'];before=ck(row['before']);after=ck(row['proposed']);assert before==ck(entries[p]['source'])
  assert ns['apply'](before,ck(row['forward_diff']))==after and ns['apply'](after,ck(row['inverse_diff']))==before
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert q.returncode==0
  files.append(dict(canonical_path=p,before=row['before'],proposed=row['proposed'],logical31_before_whole_exact=True,literal_forward_inverse_exact=True,authorship='Other author held18 whole core, independently reviewed here' if p==corepath else 'My mechanical continuation; semantics/API read and author verification only, NOT independent join review',fresh_Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))))
  selected[p]=after
 paths={
  'src/EnergyPlus/NodeInputManager.cc':[(955,1206)],'src/EnergyPlus/NodeInputManager.hh':[(157,185)],
  'src/EnergyPlus/EMSManager.cc':[(1614,1627)],'src/EnergyPlus/DataLoopNode.hh':[(502,513)],
  'src/EnergyPlus/Psychrometrics.hh':[(512,547),(646,716),(1611,1652)],
  'src/EnergyPlus/DataGlobalConstants.hh':[(610,617)],'src/EnergyPlus/ScheduleManager.hh':[(260,270)],
  'third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh':[(1061,1078)],
 }
 native=[]
 for i,(p,spans) in enumerate(paths.items(),1):
  b=(N/p).read_bytes();assert b==subprocess.check_output(['git','show',NC+':'+p],cwd=N);lines=b.splitlines(keepends=True)
  native.append(dict(Native_path=p,whole=save(O/'Native'/f'{i:02}-{Path(p).name}',b),extents=[dict(first=a,last=z,source=save(O/'Native'/f'{i:02}-{a}-{z}.txt',b''.join(lines[a-1:z]))) for a,z in spans]))
 contexts=[]
 cpaths=['crates/ep_runtime/src/psychrometrics.rs','crates/ep_runtime/src/psychrometrics/cp_cache.rs','crates/ep_runtime/src/heat_balance/source_output_registration.rs','crates/ep_runtime/src/heat_balance/source_output_registration/requested_input.rs','crates/ep_runtime/src/heat_balance/selected_schedule_manager/report.rs','crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs','crates/ep_runtime/src/weather_day/context.rs']
 for i,p in enumerate(cpaths,1):
  b=ck(entries[p]['source']);contexts.append(dict(canonical_path=p,whole=save(O/'Source_context'/f'{i:02}-{Path(p).name}',b),logical31_whole_exact=True))
 patterns=['SourceHvacOwners {','struct SourceHvacOwners','calculate_source_more_node_info(','struct SourceNodeReporting','struct SourceMoreNodeData']
 census=[]
 for p,row in sorted(entries.items()):
  if not p.startswith('crates/') or not p.endswith('.rs'):continue
  b=selected[p] if p in selected else ck(row['source']);hits=[dict(line=i,text=s) for i,s in enumerate(b.decode().splitlines(),1) if any(x in s for x in patterns)]
  if hits:census.append(dict(path=p,sha256=sha(b),bytes=len(b),hits=hits))
 constructors=[(r['path'],h['line']) for r in census for h in r['hits'] if 'SourceHvacOwners {' in h['text']];calls=[(r['path'],h['line']) for r in census for h in r['hits'] if 'calculate_source_more_node_info(' in h['text']];assert len(constructors)==2 and len(calls)==3
 result=dict(schema='src06-held18-independent-core-semantic-and-author32-context-review.v1',accepted=True,findings=[],reviewed_packet=pr,
  authorship_boundary='I authored prospective32 MECHANICAL continuation only. I did NOT author held18 core node_reporting.rs. Its whole body is independently reviewed against primary Native here. My own six-file join is only author-verified and its API/borrow semantics assessed; this artifact does NOT call that mechanical join independent. Root remains separate whole/join reviewer.',
  acceptance_scope='Full held18 CalcMoreNodeInfo955-1206 core/cold-state/branch/property semantics with explicit unsupported operations and current logical31 owner/runtime API context. No activation, compiler-typecheck, numerical cohort, fullB or optional property equivalence claim.',
  files=files,author_verified_literal_applications=12,fresh_Source_only_parses=6,held18_core_whole_unchanged=oldcore['proposed'],logical31_parent=p31ref,logical31_complete_plan=p31['complete_final_compiler_Source_plan'],ordinary_equipment_full_30_31_context=owner['proposed'],ordinary_equipment_unchanged=True,
  Native_commit=NC,Native_wholes=native,Native_whole_count=len(native),strict_Native_extents=sum(len(x['extents']) for x in native),concrete_Source_contexts=contexts,
  full_logical31_crates_API_census=dict(Rust_sources=4490,patterns=patterns,files=census,actual_HvacOwners_constructors=constructors,CalcMoreNodeInfo_definition_and_calls=calls),
  cold_state_and_requests=[
   'Same existing NodeOwner.reporting, number_of_nodes, NodeID zero-slot/one-based IDs, physical and MoreNodeInfo allocations. No cloned/default numerical model or fresh psychrometric owner. NodeReporting once ctortrue and std densities None until actual first writes safely preserve Native uninitialized density locals before use, without invented bits.',
   'Once branch captures actual Environment.StdRhoAir then RhoH2O(5.05=InitConvTemp). Eight allocations in WetBulb req/sched, RH req/sched, Dew req/sched, Cp req/sched order, string/fluid reserve, then eight false/null fills in exact order. Unknown allocation cells become real false/null only at those actual writes. Once clears only after full node initialization; zero-node path still performs the same scalar/allocation/fill/flag operations.',
   'Each first-time NodeID(i+1) creates reporting string before physical FluidIndex lookup. Index==0 writes genuine null fluid entry; any other index stops at missing actual glycol fetch, preserving preceding effects. Supported later Water index<=0 follows fallback; positive index stops at actual glycols.size predicate. No fake fluid objects or forced type.',
   'Full requested_variables vector order retained, no used/frequency/simple-string/AnyEMS gating. Matching key or empty key and matching names set same req flag and same real optional reporting_schedule; all matches processed, so last match wins. Current admitted ASCII matching follows SameString intent; generic non-ASCII matching beyond existing Source name policy is not newly certified.',
   'Four independent actual CheckIfNodeMoreInfoSensedByEMS scans use same RuntimeLanguage.number_of_sensors, not AnyEMS. Count0 returns actual localfalse without sensor access; positive count stops at first missing Sensor.UniqueKeyName before claiming false. EMS true override writes and positive Sensor content are unported, explicitly bounded.',
   'Current report bools preserve WetBulb requested-with-schedule, requested-null, then SPM fallback chain. A requested schedule returning false does not fall through to SPM. RH/Dew/Cp request and actual schedule current checks occur in original order before fluid branch. Same ScheduleManager getCurrentVal gives actual EMS override before retained current_value; no new clock evaluation or eager schedule reconstruction.'
  ],
  property_and_fluid_semantics=[
   'Air writes standard-volume flow before density call; uses actual OutBaroPress/T/W, normal humidity floor and exact multiply/divide grouping. Computed rho<0 stops at unported stateful negative-density diagnostic before Density write. This is an honest call boundary, not diagnostic-state equivalence; rho==0 preserves current-volume prior value as Native. Then normal floor-aware enthalpy call.',
   'WetBulb, dewpoint and RH positive requests stop at their actual diagnostic/cache-aware calls AFTER all preceding required writes, not by substituted raw helpers. False branches write actual zeros in original WetBulb/Dew/RH order. Optional normal Cp occurs only at the final specific-heat predicate, never eagerly, else realzero.',
   'Normal Cp delegates existing shared thread-local normal saved pair, independent of fast pair, no reset/new instance. Ordered cold -100 equality returns saved -100 before flooring; miss floors and writes original input/result, preserving ordinary single-thread source call order. Native unsynchronized cross-thread behavior is outside the existing executor boundary.',
   'Normal density/H and CPCW/RhoH2O reuse genuine scalar helpers. H and density retain first-operand humidity floor/NaN behavior; Cp uses existing last-call cache. CPCW ignores its T argument and returns4180. RhoH2O InitConvTemp5.05 retains left-associated polynomial with separate x*x and x*x*x, not powf/reassociation/FMA. No added property cache or tolerance/rounding.',
   'Water index<=0 uses captured standard-water rho for both densities and realCPCW, then writes StdVol/CurrentVol/Density/H/Cp/WetBulb/RH100 in exact order; dewpoint deliberately retained. Positive glycol pointer/state not implemented and stops at actual first predicate/fetch.',
   'Steam Quality1 stops at actual GetSteam before steam property calls. Quality0 writes only StdVol using captured water rho,H=CPCW*T,WetBulb0,RH0; qualityother retains all fields. Electric writes only StdVol/H/WetBulb/RH/Cp zeros. Neither branch invents current-volume/density/dewpoint writes.',
   'Fallback fluid writes standard volume, then HumRat>0 gates normalH, actual optional standard-pressure wetbulb boundary and optional normalCp; HumRat<=0 usesCPCW*T,WetBulb0,Cp0. RelativeHumidity/DewPoint/current density/volume retain prior values because Native does not assign them. No eager property calls before fluid or report predicates.'
  ],
  runtime_context=[
   'Current reporting module whole is unchanged held18. Eight SourceMoreNodeData field visibility changes permit the sibling same-owner writer; original positive SetupNode/reset/live output dispatch/PurchasedAir cases stay whole under exact author inverse, with no replacement table/proxy.',
   'Same actual RuntimeLanguage is borrowed immutably from startup in both SourceHvacOwners constructors; existing mutable schedules/control/availability/fault/physics references remain real. Actual report and remaining call sites pass same environment/registration/schedules/runtime. Full logical31 crate census includes runtime tests, only two constructors and three method definition/calls; no missing direct test initializer was found.',
   'Field-disjoint mutable reporting/more_info and immutable physical Node borrows stay within same NodeOwner. ReportStrings and arrays are used directly, no physical clone. Logical31 ordinary_equipment whole e04dda94 is an unchanged context; all prior30 reset/convergence helpers and31 borrowed Node views remain intact.'
  ],
  qualification='This acceptance adds an independent held18 CORE semantic read; it does not convert author32 composition into independent join review. Final actual31 frontier/committed parent/compiler snapshot and complete Source32 overlay must still be authenticated by Root, with meaningful compile/actual validation. Optional WB/RH/dew/glycol/steam-positive branches are honest boundaries; no generic whole-NodeInputManager or all-input completion claim.',
  main_Cargo_Native_tests_or_publication_mutations=False,author_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'review.json',(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode())))
if __name__=='__main__':main()

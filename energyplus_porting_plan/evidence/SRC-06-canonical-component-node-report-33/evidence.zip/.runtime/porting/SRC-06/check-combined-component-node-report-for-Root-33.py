"""Read-only structural helper for Root's independent combined33 application.

Prepared by Outer; it does not confer independent semantics on Outer's join.
Root imports validate_for_root_application(), supplies its own read statement,
and embeds the returned evidence directly in its application receipt. No extra
review artifact is written, no Source applied, no compiler/test invoked.
"""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0';NC='6f2e40d10250a105b49966baa24d843711e61048'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 p=(R/r['path']).resolve();p.relative_to(R);b=p.read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def load(r):return json.loads(checked(r))
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def native_rows(v):
 if isinstance(v,dict):
  if 'Native_path' in v and isinstance(v.get('whole'),dict):yield v
  for x in v.values():yield from native_rows(x)
 elif isinstance(v,list):
  for x in v:yield from native_rows(x)
def validate_for_root_application(producer_ref,root_author_Source,root_semantic_read_statement):
 assert isinstance(root_semantic_read_statement,str) and len(root_semantic_read_statement.strip())>=40
 checked(root_author_Source)
 m=load(producer_ref);assert m['existing_Source_files']==9 and m['new_Source_files']==0 and len(m['files'])==9
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']
 parent=load(m['actual_parent_plan']);plan=load(m['complete_final_compiler_Source_plan']);entries={x['path']:x for x in plan['entries']};pentries={x['path']:x for x in parent['entries']};assert set(entries)==set(pentries) and len(entries)==plan['inputs']==parent['inputs']
 pr=load(m['accepted_parent_review']);assert pr['accepted'] and not pr.get('findings',[]) and pr['complete_compiler_plan']['sha256']==m['actual_parent_plan']['sha256']
 # Direct accepted main-cohort snapshot, not inherited production receipts.
 assert pr['FP_controls_mutated'] is False and pr['production_science_body_changes']==0
 snap=load(pr['actual_snapshot']);archived={x['historical_path']:x for x in snap['files']};assert set(archived)==set(pentries)
 command=load(pr['actual_focused_test']);assert command['exit_code']==0 and command['launch_error'] is None and command['source_bytes_match_before_and_after'] is True and command['source_snapshot']==pr['actual_snapshot']
 for path,row in pentries.items():
  b=checked(row['source']);assert b==(R/path).read_bytes(),path
  assert (row['final_sha256'],row['final_bytes'])==(sha(b),len(b))==(archived[path]['archive']['sha256'],archived[path]['size_bytes'])
 prepared=load(m['prepared']);rows={x['canonical_path']:x for x in m['files']};assert set(rows)=={x['canonical_path'] for x in prepared['files']}
 prep_rows={x['canonical_path']:x for x in prepared['files']};eq='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';suffix=checked(m['equipment_entire_actual_cohort_suffix'])
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
 selected=[];final={}
 for path,row in sorted(entries.items()):
  if path not in rows:
   assert row==pentries[path];continue
  sr=rows[path];before=checked(sr['before']);after=checked(sr['proposed']);assert before==checked(pentries[path]['source']) and after==checked(row['source'])
  assert before==subprocess.check_output(['git','show',head+':'+path],cwd=R)
  assert ns['apply'](before,checked(sr['forward_diff']))==after and ns['apply'](after,checked(sr['inverse_diff']))==before==checked(sr['literal_inverse'])
  prep=checked(prep_rows[path]['proposed'])
  if path==eq:
   logical=checked(prep_rows[path]['before']);assert before==logical+suffix and after==prep+suffix
  else:assert before==checked(prep_rows[path]['before']) and after==prep
  assert sr['Source_only_parse']['exit_code']==0;checked(sr['Source_only_parse']['stdout']);assert not checked(sr['Source_only_parse']['stderr'])
  selected.append(dict(canonical_path=path,before=sr['before'],proposed=sr['proposed'],two_literal_applications_exact=True,whole_proposed_parser_outputs_authenticated=True))
  final[path]=after
 assert len(selected)==9
 split=prepared['split_authorities'];peer33_ref=split['independent_full33_component_and_history'];core32_ref=split['independent_held18_core_semantics_only'];peer33=load(peer33_ref);core32=load(core32_ref);doc_ref=m['independent_comment_reattachment_peer'];doc=load(doc_ref)
 for v in [peer33,core32,doc]:assert v['accepted'] and not v.get('findings',[])
 d33=load(prepared['component_history_draft']);prior_ref=d33['prior_independent_two_Source_peer'];prior=load(prior_ref);assert prior['accepted'] and not prior.get('findings',[])
 assert contains(doc,m['prepared']) or contains(doc,prepared['only_known_doc_reattachment']['forward_diff'])
 assert contains(peer33,prepared['component_history_draft']) and contains(core32,prepared['node_reporting_draft'])
 native={};extent_count=0
 for v in [peer33,prior,core32]:
  for row in native_rows(v):
   path=row['Native_path'];b=checked(row['whole']);assert b==subprocess.check_output(['git','show',NC+':'+path],cwd=N);native[path]=row['whole']
   for e in row.get('extents',[]):
    a=e.get('first',e.get('first_line'));z=e.get('last',e.get('last_line'));er=e.get('source',e.get('strict_extent'))
    assert a is not None and z is not None and er is not None
    assert checked(er)==b''.join(b.splitlines(keepends=True)[a-1:z]);extent_count+=1
 patterns=['SourceHvacOwners {','struct SourceHvacOwners','calculate_source_more_node_info(','update_source_node_thermal_history(','update_source_plant_node_thermal_history(','inlet_node_air_distribution_unit_number(','calculate_source_component_loads(']
 census=[];rust=0
 for path,row in sorted(entries.items()):
  if not path.startswith('crates/') or not path.endswith('.rs'):continue
  rust+=1;b=final[path] if path in final else checked(row['source']);hits=[dict(line=i,text=s) for i,s in enumerate(b.decode().splitlines(),1) if any(x in s for x in patterns)]
  if hits:census.append(dict(path=path,sha256=sha(b),bytes=len(b),hits=hits))
 constructors=[(x['path'],h['line']) for x in census for h in x['hits'] if 'SourceHvacOwners {' in h['text']];calls=[(x['path'],h['line']) for x in census for h in x['hits'] if 'calculate_source_more_node_info(' in h['text']]
 assert len(constructors)==2 and len(calls)==3 and rust==plan['Rust_sources']
 return dict(schema='src06-Root-application-integrated-independent-join-custody.v1',producer=producer_ref,complete_compiler_plan=m['complete_final_compiler_Source_plan'],accepted_cohort_parent_review=m['accepted_parent_review'],accepted_cohort_parent_plan=m['actual_parent_plan'],actual_parent_snapshot=pr['actual_snapshot'],Root_author_Source=root_author_Source,Root_semantic_read_statement=root_semantic_read_statement,
  authorship='Structural helper prepared by Outer. Root executes it and supplies its own full Source/Native read judgment in its independent application. Outer32 join is not relabelled independent; held18 core semantics and Coil33 three-Source semantics remain distinct.',
  split_authorities=dict(independent33_three=peer33_ref,prior_independent33_two=prior_ref,independent_held18_core_only=core32_ref,independent_doc_move=doc_ref),selected9=selected,literal_applications=18,authenticated_fresh_parse_outputs=9,whole_parent_archive_live_plan_rows=len(entries),all_nonselected_parent_entries_exact=True,exact_cohort_equipment_suffix_preserved=m['equipment_entire_actual_cohort_suffix'],Native_commit=NC,Native_wholes=[dict(Native_path=p,whole=r) for p,r in sorted(native.items())],strict_Native_extents=extent_count,whole_crates_API=dict(Rust_sources=rust,patterns=patterns,files=census,actual_HvacOwners_constructors=constructors,CalcMoreNodeInfo_definition_and_calls=calls),canonical_compiler_test_or_publication_mutations=False,helper_Source=ref(Path(__file__)))

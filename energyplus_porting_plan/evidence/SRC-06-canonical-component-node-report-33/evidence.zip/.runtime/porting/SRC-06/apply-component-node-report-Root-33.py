from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-component-node-report-application-33';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-controlled-component-node-report-held-Outer-33/manifest.json');assert mr['sha256']=='8c8a1b9febe2699e130443450a9e96451f444e005d0137b64f89792da8e4deeb';m=json.loads(checked(mr))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='141e0c2b370ca76ee38882a23fa14015eefd1ebf' and not subprocess.check_output(['git','status','--porcelain'],cwd=R)
hp=D/'check-combined-component-node-report-for-Root-33.py';hr=ref(hp);assert hr['sha256']=='90bd1f41c2530e2b4fbcdada1f1906ad21ede957cd1c4f5195121565d11e337f';ns={'__file__':str(hp),'__name__':'Root_readonly_combined_helper'};exec(compile(checked(hr),str(hp),'exec'),ns)
statement='Root independently read all nine production proposal wholes/diffs and their same-owner caller contexts, Native CalcZoneComponentLoadSums5414-5677 controlled inlet/opaque suffix, GeneralRoutines calcZoneSensibleOutput1679-1702 and existing ordered delta-H kernel, full PlantManager UpdateNodeThermalHistory2943-2983 and Node449/459 constructors, full NodeInputManager CalcMoreNodeInfo955-1206 and EMS1614-1628. Controlled ordered Temp then Mdot then flow>0 delta-H then report accumulation then real InletNodeADUNum lookup; no normal Cp cache or ZoneMult division added, positive ADU child remains boundary. Full physical Node per-row Tlast then Hlast writes on same retained owner precede original plant-positive tail. Node reporting once/cold eight arrays, true input order last schedule wins, four actual NumSensors checks, wetbulb scheduled-false SPM distinction, air/water/steam/electric/invalid branches and retained unwritten fields match Native. Normal shared property operations and optional diagnostic/glycol/steam boundaries remain honest. Existing MoreNodeInfo fields only gain sibling access; actual runtime-language/registration/schedule/environment owners threaded through both real constructors and three method definition/call occurrences. Root owns independent final six-file Source32 mechanical/caller join review; Outer is independent of Coil held18 core only and author of that join, not an invented full independent33+32 peer. Whole accepted main-cohort equipment suffix and every other feature/main/Cargo/fixture input preserved. Only authorized misplaced comment is reattached. No new tests, numerical mirrors, FP/cache reset, oracle production injection or fullB/finite15/card completion claim; actual B/A33 still pending.'
join=ns['validate_for_root_application'](mr,ref(Path(__file__).resolve()),statement)
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};selected={f['canonical_path']:f for f in m['files']};assert len(rows)==4503 and sum(n.endswith('.rs') for n in rows)==4490 and len(selected)==9
test_delta=0
for n,v in rows.items():
 b=checked(v['source']);assert len(b)==v['final_bytes'] and hashlib.sha256(b).hexdigest()==v['final_sha256'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
for f in selected.values():test_delta+=checked(f['proposed']).count(b'#[test]')-checked(f['before']).count(b'#[test]')
assert test_delta==0
O.mkdir()
for n,f in selected.items():
 p=R/n;assert p.stat().st_nlink==1;p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,complete_compiler_plan=m['complete_final_compiler_Source_plan'],accepted_cohort_parent_review=m['accepted_parent_review'],actual_parent_plan=m['actual_parent_plan'],selected=selected,selected_existing_Rust_sources=9,new_Rust_sources=0,new_test_bodies=0,literal_applications=18,all4503_final_plan_inputs_exact_live=True,selected9_parent_Git_whole_equal=True,Root_independent_combined_join=join,split_semantic_authorities=join['split_authorities'],independent_combined_join_accepted=True,Root_semantic_read_statement=statement,Cargo_Native_or_tests_executed=False,actual_B_and_A24_pending=True,author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

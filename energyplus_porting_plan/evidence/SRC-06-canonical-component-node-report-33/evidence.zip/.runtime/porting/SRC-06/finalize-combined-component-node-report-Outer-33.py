"""Finalize isolated HELD nine-file packet only after accepted committed cohort parent.

Never applies canonical Sources, runs Cargo/tests or publishes. Root supplies
the actual accepted parent plan/review and the bounded comment-reattachment peer.
"""
from pathlib import Path
import argparse,ast,copy,difflib,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';P=D/'source-controlled-component-node-report-combined-prepared-Outer-33';O=D/'source-controlled-component-node-report-held-Outer-33'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def ck(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def load(r):return json.loads(ck(r))
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def argref(s,h):
 p=Path(s);p=p.resolve() if p.is_absolute() else (R/p).resolve();assert p.is_relative_to(R);v=ref(p);assert v['sha256']==h;return v
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--expected-parent-head',required=True)
 for name in ['parent-plan','parent-review','doc-peer']:
  ap.add_argument('--'+name,required=True);ap.add_argument('--'+name+'-sha',required=True)
 a=ap.parse_args();assert not O.exists()
 prepared_ref=ref(P/'prepared.json');m=load(prepared_ref);assert ck(m['finalizer_Source'])==Path(__file__).read_bytes()
 parent_ref=argref(a.parent_plan,a.parent_plan_sha);parent=load(parent_ref);review_ref=argref(a.parent_review,a.parent_review_sha);review=load(review_ref)
 assert review['accepted'] and not review.get('findings',[])
 assert review['complete_compiler_plan']['sha256']==parent_ref['sha256']
 doc_ref=argref(a.doc_peer,a.doc_peer_sha);doc=load(doc_ref);assert doc['accepted'] and not doc.get('findings',[])
 assert prepared_ref['sha256'] in json.dumps(doc) or m['only_known_doc_reattachment']['forward_diff']['sha256'] in json.dumps(doc)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==a.expected_parent_head
 assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=normal'],cwd=R)
 prior=load(m['logical_parent_plan']);old_entries={x['path']:x for x in prior['entries']};entries={x['path']:x for x in parent['entries']};assert len(entries)==parent['inputs']
 eq='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';selected={};files=[];changes=[]
 # Authenticate ALL actual committed cohort inputs; keep their complete rows.
 # Deliberately do not assert all unselected Git blobs: the known physical CR
 # bridge is permitted only through exact archived/live bytes, never normalized.
 for path,row in sorted(entries.items()):
  b=ck(row['source']);assert sha(b)==row['final_sha256'] and len(b)==row['final_bytes'];assert b==(R/path).read_bytes(),path
  old=old_entries.get(path)
  if old is None or old['final_sha256']!=row['final_sha256'] or old['final_bytes']!=row['final_bytes']:
   changes.append(dict(path=path,logical31_source=None if old is None else old['source'],accepted_cohort_parent=row['source'],preserved_in_final=path!=eq))
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
 suffix_ref=None
 for i,row in enumerate(m['files'],1):
  path=row['canonical_path'];before=ck(entries[path]['source']);logical=ck(row['before']);proposal=ck(row['proposed'])
  assert before==subprocess.check_output(['git','show',head+':'+path],cwd=R),path
  if path==eq:
   assert before.startswith(logical),'Equipment cohort edits are not the exact known31 prefix plus suffix; stop for explicit new literal bridge.'
   suffix=before[len(logical):];assert suffix,'Expected authenticated consolidated cohort suffix is absent.'
   suffix_ref=save(O/'parent-custody/whole-cohort-equipment-suffix.rs.txt',suffix)
   after=proposal+suffix;assert after[len(proposal):]==suffix
   assert logical+after[len(proposal):]==before
  else:
   assert before==logical,'Unexpected overlap outside equipment test suffix: '+path
   after=proposal
  fd=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode();iv=''.join(difflib.unified_diff(after.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode();assert ns['apply'](before,fd)==after and ns['apply'](after,iv)==before
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert q.returncode==0
  files.append(dict(canonical_path=path,before=save(O/'before'/path,before),proposed=save(O/'proposed'/path,after),literal_inverse=save(O/'literal-inverse'/path,before),forward_diff=save(O/'diffs'/f'{i:02}.forward.diff',fd),inverse_diff=save(O/'diffs'/f'{i:02}.inverse.diff',iv),prepared_proposed=row['proposed'],whole_prepared_proposal_exact=path!=eq,only_equipment_suffix_join=path==eq,Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))));selected[path]=files[-1]['proposed']
 final=[]
 for path,row in sorted(entries.items()):
  v=copy.deepcopy(row)
  if path in selected:v.update(source=selected[path],final_sha256=selected[path]['sha256'],final_bytes=selected[path]['bytes'],origin='HELD combined33 controlled report/history + held32 Node reporting on exact accepted cohort parent')
  final.append(v)
 count=sum(x['path'].startswith('crates/') and x['path'].endswith('.rs') for x in final)
 finalplan=dict(schema='src06-complete-combined33-32-compiler-input-plan.v1',base_HEAD=head,actual_accepted_parent_plan=parent_ref,actual_parent_review=review_ref,inputs=len(final),Rust_sources=count,selected_existing=9,entries=final)
 plan_ref=save(O/'complete-final-compiler-Source-plan.json',(json.dumps(finalplan,ensure_ascii=True,indent=2)+'\n').encode())
 for change in changes:
  if change['path']==eq:change['preserved_in_final']=True;change['exact_cohort_suffix_preserved']=suffix_ref
 result=dict(schema='src06-held-combined33-32-nine-existing-Source.v1',status='HELD exact committed cohort parent; no apply/runtime claim; Root independently reviews final whole/join before mutation',base_HEAD=head,prepared=prepared_ref,actual_parent_plan=parent_ref,accepted_parent_review=review_ref,complete_final_compiler_Source_plan=plan_ref,compiler_inputs=len(final),Rust_sources=count,files=files,existing_Source_files=9,new_Source_files=0,literal_applications=18,Source_only_parses=9,independent_comment_reattachment_peer=doc_ref,split_authorities=m['split_authorities'],only_known_doc_reattachment=m['only_known_doc_reattachment'],all_cohort_changes_relative_to31=changes,equipment_entire_actual_cohort_suffix=suffix_ref,cohort_test_main_feature_and_Cargo_parent_inputs_preserved=True,all_nonselected_complete_parent_entries_whole_exact=True,qualified_authorship='Outer authored composition; held18 core semantics independently reviewed by Outer, full33 independently reviewed by Coil. Root remains independent combined join reviewer; no invented peer or test execution.',validation_policy='Root actual B/A integration as appropriate; no new/habitual test bodies, no final runtime or physical/numeric equivalence claim from this packet.',new_test_bodies=0,Cargo_main_Native_test_or_publication_mutations=False,invocation=sys.argv,author_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'manifest.json',(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode())))
if __name__=='__main__':main()

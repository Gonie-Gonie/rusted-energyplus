"""Independent same-owner thermal-history extension and exact prior33 join."""
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
OUT = D / 'Peer-controlled-component-node-history-Source-review-33-02'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def auth(row):
    p = R / row['path']
    assert ref(p)['sha256'] == row['sha256']
    if 'bytes' in row:
        assert ref(p)['bytes'] == row['bytes']
    return p

def save(name, b):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(b)
    return ref(p)

def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], check=True, capture_output=True).stdout

assert not OUT.exists()
dp = D / 'source-controlled-component-report-draft-Outer-33-02/draft.json'
assert ref(dp)['sha256'] == 'b0be01a3547ea68f36c53b2a56d7f0523a9f0356c0435a416727819f8f1c7cd7'
draft = json.loads(dp.read_bytes())
prior_path = auth(draft['prior_two_Source_draft'])
prior = json.loads(prior_path.read_bytes())
peer_path = auth(draft['prior_independent_two_Source_peer'])
peer = json.loads(peer_path.read_bytes())
assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet'] == ref(prior_path)
extension_path = auth(draft['thermal_history_extension'])
extension = json.loads(extension_path.read_bytes())
parent = json.loads(auth(draft['base_parent31']).read_bytes())
plan_path = auth(parent['complete_final_compiler_Source_plan'])
plan = json.loads(plan_path.read_bytes())
entries = {row['path']: row for row in plan['entries']}
assert (plan['inputs'], plan['Rust_sources']) == (4503, 4490)
t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
files = []
logical = {}
for i, row in enumerate(draft['files'], 1):
    name = row['canonical_path']
    before = auth(row['before']).read_bytes()
    new = auth(row['proposed']).read_bytes()
    assert before == auth(entries[name]['source']).read_bytes()
    assert ns['apply_literal'](before, auth(row['forward_diff']).read_bytes()) == new
    assert ns['apply_literal'](new, auth(row['inverse_diff']).read_bytes()) == before
    assert auth(row['literal_inverse']).read_bytes() == before
    parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parse.returncode == 0, (name, parse.stderr)
    files.append({'canonical_path': name, 'before': row['before'], 'proposed': row['proposed'], 'logical31_parent_whole_exact': True, 'two_literal_applications': True, 'fresh_Source_only_parse': {'exit_code': 0, 'stdout': save(f'parse/{i:02}.stdout', parse.stdout), 'stderr': save(f'parse/{i:02}.stderr', parse.stderr)}})
    logical[name] = new.decode()
old_rows = {row['canonical_path']: row for row in prior['files']}
report_name = next(name for name in logical if name.endswith('/component_report.rs'))
assert logical[report_name].encode() == auth(old_rows[report_name]['proposed']).read_bytes()
equipment_name = 'crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'
fragment = auth(extension['additional_method_fragment']).read_bytes()
assert logical[equipment_name].encode().count(fragment) == 1
assert logical[equipment_name].encode().replace(fragment, b'', 1) == auth(old_rows[equipment_name]['proposed']).read_bytes()
api = []
for name, entry in sorted(entries.items()):
    if not name.endswith('.rs'):
        continue
    text = logical.get(name)
    if text is None:
        text = auth(entry['source']).read_text(encoding='utf-8')
    terms = [term for term in draft['API_census']['patterns'] if term in text]
    if terms:
        api.append({'path': name, 'terms': terms})
assert {row['path'] for row in api} == {row['path'] for row in draft['API_census']['files']}
native = []
for row in extension['Native_authorities']:
    name = row['Native_path']
    b = auth(row['whole']).read_bytes()
    assert b == (N / name).read_bytes() == git(N, 'show', PIN + ':' + name)
    for e in row['extents']:
        assert b''.join(b.splitlines(keepends=True)[e['first'] - 1:e['last']]) == auth(e['source']).read_bytes()
    native.append(row)
contexts = []
for row in extension['concrete_Source_contexts']:
    name = row['canonical_path']
    assert auth(row['whole']).read_bytes() == auth(entries[name]['source']).read_bytes()
    contexts.append(row)
report = {
    'schema': 'src06-independent-controlled-component-node-history-extension-review.v1', 'accepted': True, 'findings': [],
    'reviewed_packet': ref(dp), 'prior_component_prefix_peer': ref(peer_path), 'prior_two_Source_draft': ref(prior_path), 'thermal_history_extension': ref(extension_path),
    'scope': 'Full independent new thermal-history owner/caller semantics plus exact reviewed component/accessor identity. Prior ec9e full component prefix semantic acceptance remains explicit; no invented re-review of unchanged general component suffix.',
    'files': files, 'literal_applications': 6, 'fresh_Source_only_parses': 3,
    'whole_original_component_body_unchanged': True, 'owner_additional_method_removal_restores_whole_prior33': True,
    'Native_commit': PIN, 'Native_wholes': native, 'Native_whole_count': len(native), 'strict_Native_extents': sum(len(row['extents']) for row in native), 'concrete_Source_contexts': contexts,
    'whole_crates_API_census': {'Rust_sources': 4490, 'all_crates_runtime_tests_included': True, 'files': api, 'sole_existing_history_dispatch_call': 'ordinary_hvac_manager/remaining.rs C::UpdatePlantNodeThermalHistory'},
    'semantic_proof': [
        'Actual function is Plant/PlantManager.cc UpdateNodeThermalHistory2943-2983. Real NumOfNodes>0 predicate precedes full actual physical Node allocation traversal, not a count-derived slice or diagnostic NodeStateStore.',
        'Every real row copies temperature_last_timestep=temperature, then enthalpy_last_timestep=enthalpy in Native order. No DefaultNodeValues/whole-record clone, reallocation, new readiness, property/cache/calculation or filtered subset. Existing full48-field SourceNodeData contains both actual initialized fields; direct assignment preserves f64 bits and current values.',
        'Postlude borrows same mutable SourceHvacOwners and same OrdinaryEquipment, invokes copy exactly where old positive Node boundary stood. Existing remaining dispatch already supplies that mutable borrower; whole crate census has no other direct test/production call needing adapter.',
        'Actual positive plant.total_loops && !clock.warmup_flag predicate remains whole unchanged after all Node copies and stops at the unrepresented actual PlantLoop traversal. No claim to implement plant capacitance/storage/history tail.',
        'Native ManageHVAC440 history call precedes non-Warmup DoOutputReporting&&!ZoneSizing CalcMoreNodeInfo452. Current Source dispatcher/caller contexts preserve that order; held32 activation is neither assumed nor implied.',
        'Original component-report proposal remains whole-identical accepted3e152. Removing only the exact665B history method restores entire prior33 owner proposal including genuine ADU accessor. All original owner bytes and future consolidated cfg(test) suffix must still be preserved at final committed-parent literal join.',
    ],
    'nonblocking_source_comment': 'The preexisting HVACManager1769 doc comment precedes the inserted history method and is now adjacent to the correct PlantManager2943 doc line. It does not alter semantics or authority; precise review binds PlantManager only.',
    'final_parent_pending': 'Current proposal intentionally uses logical31 before bytes. Live equipment may now have the Root-authorized cfg(test) cohort suffix; no false whole-current equality asserted here. Final sealer must literal-transplant exact accessor/history fragments onto actual committed cohort equipment and preserve whole suffix, then authenticate complete4503/4490 plan.',
    'validation': 'No actual33/history NodeNative paired-state/fullB claim. No new test, Cargo, Native run, canonical write or gate/policy change.',
    'new_tests': 0, 'Cargo_main_Native_tests_or_production_mutations': False, 'author_Source': ref(Path(__file__)),
}
print(json.dumps(save('review.json', (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())))

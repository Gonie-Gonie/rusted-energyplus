"""Prepare ONLY held33 engine publication metadata; never publishes or runs code."""
from pathlib import Path
import argparse,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'component-node-report-publication-prepared-Outer-33'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def ck(r):
 p=(R/r['path']).resolve();p.relative_to(R);v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def load(r):return json.loads(ck(r).read_bytes())
def put(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes((json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'));return ref(p)
def supplied(path,sha):
 p=(R/path).resolve();p.relative_to(R);r=ref(p);assert r['sha256']==sha;return r
def main(a):
 publisher=ref(D/'publish-component-node-report-checkpoint-Outer-33.py')
 prior=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-controlled-zone-corrector-31/summary.json');assert prior['sha256']=='8ee5e72982e35178e54798faf514019f046771641f48e0203f195bbb30963c2d'
 prev=load(prior);assert (prev['A'],prev['B'])==('14/54','14/64')
 actual31=ref(D/'Root-source-controlled-zone-corrector-actual-review-31/review.json');assert actual31['sha256']=='070e317a31abeeb22031948e6a4a9b28672794e6fc1396944ecfc667cc61affb'
 prepared=ref(D/'source-controlled-component-node-report-combined-prepared-Outer-33/prepared.json');m=load(prepared)
 p33=m['split_authorities']['independent_full33_component_and_history'];p32=m['split_authorities']['independent_held18_core_semantics_only']
 for r in [p33,p32]:v=load(r);assert v['accepted'] and not v['findings']
 docs={
  'CHECKLIST.md':'\uc81c\uc5b4 \uad6c\uc5ed \uc131\ubd84\ubcc4 \uc5f4\uc218\uc9c0\uc640 \ub178\ub4dc \uc774\ub825\u00b7\ucd94\uac00\uc815\ubcf4 \uacc4\uc0b0 \ubb36\uc74c\uc758 B/A \uc2e4\ud589 \uacb0\uacfc\ub97c \uae30\ub85d\ud569\ub2c8\ub2e4.',
  'STATE_CONTRACTS.md':'\uae30\uc874 Config\u00b7\ubb3c\ub9ac Node\uc640 \uc694\uccad\u00b7\uc2a4\ucf00\uc904\u00b7EMS \uc0c1\ud0dc\ub97c \uc7ac\uc0ac\uc6a9\ud558\uace0, Native \ud638\ucd9c\uacfc \uae30\ub85d \uc21c\uc11c\ub97c \ubcf4\uc874\ud569\ub2c8\ub2e4.',
  'cards/SRC-06.md':'B\uc758 \uc2e4\uc81c \uacb0\uacfc: `{{actual_B_result}}`. \uc774\ubc88 \ub2e8\uacc4\ub294 CLI \ub450 \uac74\uc73c\ub85c \uac80\uc99d\ud588\uc73c\uba70, \ud14c\uc2a4\ud2b8 \ucf54\ud638\ud2b8 \uacb0\uacfc\ub294 \ubd80\ubaa8 \uc99d\uac70\ub85c \uad6c\ubd84\ud569\ub2c8\ub2e4.'}
 assert len(set(docs.values()))==3 and all('\ufffd' not in s and '?' not in s for s in docs.values())
 summary=dict(A='14/54',B='14/64',changed_Rust_sources=9,existing_Rust_sources=9,new_Rust_sources=0,new_test_functions=0,actual_test_bodies_executed=0,scope='Controlled component sensible report and real full physical Node temperature/enthalpy history, plus same-owner CalcMoreNodeInfo with actual request/schedule/EMS and fluid branches.',authorship='Full33 three-Source semantics independently reviewed by Coil. Held18 core semantics independently reviewed by Outer, who authored the mechanical32 continuation. Root independently reviews final combined join; no fabricated full-nine independent peer.',focused_validation_policy='Exactly actual production B/A CLI receipts. Consolidated Native-paired corrector cohort belongs to accepted compiler parent and is not executed by this engine checkpoint.',full_B_or_finite15_completion_claim=False,new_Native_harness_run_or_internal_unit_equivalence_claim=False,gate_changes=False,policy_changes=False)
 value=dict(schema='src06-held-engine33-publication-template.v1',status='PENDING_FINAL_COMMITTED_COHORT_PARENT_AND_COMBINED_PACKET',producer=None,complete_plan=None,base_HEAD=None,split_review_authorities=dict(Source33_full_three=p33,held18_core_semantics=p32,Root_independent_combined_join=None),accepted31_actual_review=actual31,previous_engine_checkpoint=prior,publisher_Source=publisher,expected_actual_review_path='.runtime/porting/SRC-06/Root-source-component-node-report-actual-review-33/review.json',pending_Root_custody=dict(application='.runtime/porting/SRC-06/Root-component-node-report-application-33/receipt.json',actual_checker_Source='.runtime/porting/SRC-06/check-source-component-node-report-actual-Root-33.py',launcher_Source='.runtime/porting/SRC-06/launch-component-node-report-Root-33.py',B_CLI='.runtime/porting/SRC-06/canonical-source-component-node-report-B-NOLIMIT-24H-command-Root-33/receipt.json',A24_CLI='.runtime/porting/SRC-06/canonical-source-component-node-report-A-24H-command-Root-33/receipt.json'),summary_template=summary,doc_appends=docs,finite_archive_inputs=[],producer_authorship_split=m['split_authorities'],publisher_executed=False,canonical_docs_mutations=False,Cargo_tests_Native_executed=False,gate_changes=False,author_Source=ref(Path(__file__)))
 if a.draft_only:
  value['prepared_combined_only']=prepared
  print(json.dumps(put(O/'publication-draft.json',value)));return
 assert a.producer and a.producer_sha
 producer_ref=supplied(a.producer,a.producer_sha);producer=load(producer_ref);assert producer['existing_Source_files']==9 and producer['new_Source_files']==0
 planref=producer['complete_final_compiler_Source_plan'];plan=load(planref);assert (plan['inputs'],plan['Rust_sources'])==(4503,4490)
 if a.Root_join_review and a.Root_join_review_sha:
  rootref=supplied(a.Root_join_review,a.Root_join_review_sha);rootreview=load(rootref);assert rootreview['accepted'] and not rootreview.get('findings',[])
  assert producer_ref['sha256'] in json.dumps(rootreview) or prepared['sha256'] in json.dumps(rootreview)
 else:
  assert a.parent_bound;rootref=None;rootreview=None
 parentref=producer['accepted_parent_review'];parent=load(parentref);assert parent['accepted'] and parent['complete_compiler_plan']['sha256']==producer['actual_parent_plan']['sha256']
 value.update(status='HELD_READY_FOR_ROOT_ACTUAL33_AND_FULL_READ' if rootref else 'PARENT_BOUND_PENDING_ROOT_APPLICATION_INDEPENDENT_JOIN_HASH',producer=producer_ref,complete_plan=planref,base_HEAD=producer['base_HEAD'],accepted_cohort_parent_review=parentref,accepted_cohort_parent_plan=producer['actual_parent_plan'])
 value['split_review_authorities']['Root_independent_combined_join']=rootref
 files={}
 def add(r):
  p=ck(r);v=ref(p);assert p.suffix.lower()!='.zip' and v['bytes']<64*1024*1024;assert v['path'] not in files or files[v['path']]==v;files[v['path']]=v
 def collect(v):
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str) and (v['path'].startswith('.runtime/') or v['path'].startswith('.reference/')):
    add(v);return
   for k,x in v.items():
    if k not in {'all_cohort_changes_relative_to31','whole_crates_API_census','full_logical31_crates_API_census'}:collect(x)
  elif isinstance(v,list):
   for x in v:collect(x)
 for r in [producer_ref,planref,parentref,producer['actual_parent_plan'],p33,p32,rootref,actual31,prior,publisher,prepared,ref(Path(__file__))]:
  if r is not None:add(r)
 collect(producer);collect(load(p33));collect(load(p32));collect(rootreview)
 # Parent tests are separately public evidence. Keep direct accepted custody,
 # never recursively import their Native390MB capture or whole historical ZIP.
 for k in ['actual_snapshot','source_snapshot','author_Source','launcher_Source']:
  if isinstance(parent.get(k),dict) and 'path' in parent[k]:add(parent[k])
 value['finite_archive_inputs']=[v for p,v in sorted(files.items())];value['finite_archive_input_count']=len(files);value['finite_archive_input_bytes']=sum(v['bytes'] for v in files.values())
 value['pending_Root_application_join_ref']=None if rootref else '.runtime/porting/SRC-06/Root-component-node-report-application-33/receipt.json (accepted hash required after Root independently executes)'
 print(json.dumps(put(O/('publication-template.json' if rootref else 'publication-parent-bound-pending-application.json'),value)))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--draft-only',action='store_true');ap.add_argument('--parent-bound',action='store_true');ap.add_argument('--producer');ap.add_argument('--producer-sha');ap.add_argument('--Root-join-review');ap.add_argument('--Root-join-review-sha');main(ap.parse_args())

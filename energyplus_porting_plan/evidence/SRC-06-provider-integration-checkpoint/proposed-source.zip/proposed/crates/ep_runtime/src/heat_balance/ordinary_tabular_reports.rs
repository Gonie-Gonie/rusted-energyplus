//! Sole selected OutputReportTabular constructor flags. Input getters are not
//! bypassed: the genuine UpdateTabularReports232 first missing child is explicit.
use crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError as Error;
use crate::heat_balance::source_output_registration::TimeStepKind;
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SourceTabularReports {
    pub(crate) display_tabular_beps: bool,
    pub(crate) display_leed_summary: bool,
    pub(crate) display_tabular_comp_costs: bool,
    pub(crate) display_tabular_veri_sum: bool,
    pub(crate) display_component_sizing: bool,
    pub(crate) display_surface_shadowing: bool,
    pub(crate) display_demand_end_use: bool,
    pub(crate) display_adaptive_comfort: bool,
    pub(crate) display_source_energy_end_use_summary: bool,
    pub(crate) display_zone_component_load_summary: bool,
    pub(crate) display_air_loop_component_load_summary: bool,
    pub(crate) display_facility_component_load_summary: bool,
    pub(crate) display_life_cycle_cost_report: bool,
    pub(crate) display_tariff_report: bool,
    pub(crate) display_economic_result_summary: bool,
    pub(crate) display_heat_emissions_summary: bool,
    pub(crate) display_eio_summary: bool,
    pub(crate) display_thermal_resilience_summary: bool,
    pub(crate) display_co2_resilience_summary: bool,
    pub(crate) display_visual_resilience_summary: bool,
    pub(crate) display_thermal_resilience_summary_explicitly: bool,
    pub(crate) display_co2_resilience_summary_explicitly: bool,
    pub(crate) display_visual_resilience_summary_explicitly: bool,
    pub(crate) update_tabular_reports_get_input: bool,
}
impl Default for SourceTabularReports {
    fn default() -> Self {
        Self {
            display_tabular_beps: false,
            display_leed_summary: false,
            display_tabular_comp_costs: false,
            display_tabular_veri_sum: false,
            display_component_sizing: false,
            display_surface_shadowing: false,
            display_demand_end_use: false,
            display_adaptive_comfort: false,
            display_source_energy_end_use_summary: false,
            display_zone_component_load_summary: false,
            display_air_loop_component_load_summary: false,
            display_facility_component_load_summary: false,
            display_life_cycle_cost_report: false,
            display_tariff_report: false,
            display_economic_result_summary: false,
            display_heat_emissions_summary: false,
            display_eio_summary: false,
            display_thermal_resilience_summary: false,
            display_co2_resilience_summary: false,
            display_visual_resilience_summary: false,
            display_thermal_resilience_summary_explicitly: false,
            display_co2_resilience_summary_explicitly: false,
            display_visual_resilience_summary_explicitly: false,
            update_tabular_reports_get_input: true,
        }
    }
}
impl SourceTabularReports {
    /// This partial prefix deliberately cannot return success, clear GetInput,
    /// enable AllSummary flags or claim the selected TAB owner is ready.
    pub(crate) fn update_source_tabular_reports(
        &mut self,
        time_step: TimeStepKind,
    ) -> Result<(), Error> {
        match time_step {
            TimeStepKind::Zone | TimeStepKind::System => {}
        }
        if self.update_tabular_reports_get_input {
            return Err(Error::Unavailable(
                "actual UpdateTabularReports232 GetInputTabularMonthly; before annual/timebins/style/summary getters and GetInput clear",
            ));
        }
        Err(Error::Unavailable(
            "actual UpdateTabularReports278-296 time/date and gather children",
        ))
    }
}

//! Typed Air output identities, never a cached numeric snapshot.
use super::{OrdinaryRadiationError, SourceRealOutputOwners, SourceRealOutputTarget};
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum SourceAirOutputField {
    AirTemperature,
    AirHumidityRatio,
    AirRelativeHumidity,
    MeanRadiantTemperature,
    SensibleHeatingEnergy,
    SensibleCoolingEnergy,
    SensibleHeatingRate,
    SensibleCoolingRate,
    PredictedSensibleRate,
    PredictedHeatingSetpointRate,
    PredictedCoolingSetpointRate,
    SystemPredictedSensibleRate,
    SystemPredictedHeatingSetpointRate,
    SystemPredictedCoolingSetpointRate,
    PredictedMoistureRate,
    PredictedHumidifyingSetpointRate,
    PredictedDehumidifyingSetpointRate,
    SystemPredictedMoistureRate,
    SystemPredictedHumidifyingSetpointRate,
    SystemPredictedDehumidifyingSetpointRate,
    ThermostatAirTemperature,
    ThermostatHeatingSetpoint,
    ThermostatCoolingSetpoint,
    AdaptiveComfortCoolingSetpoint,
    LoadCorrectionFactor,
    // DataHeatBalance205–300 and HeatBalanceAirManager297–382 live report fields.
    MeanAirTemp,
    WetbulbGlobeTemp,
    OperativeTemp,
    MeanAirDewPointTemp,
    MeanAirHumRat,
    SumIntGains,
    SumHADTsurfs,
    SumMCpDTzones,
    SumMCpDtInfil,
    SumMCpDTsystem,
    SumNonAirSystem,
    CzdTdt,
    ImBalance,
    SumEnthalpyM,
    SumEnthalpyH,
    ExfilTotalLoss,
    ExfilSensiLoss,
    ExfilLatentLoss,
    ExhTotalLoss,
    ExhSensiLoss,
    ExhLatentLoss,
    ZoneTotalExfiltrationHeatLoss,
    ZoneTotalExhaustHeatLoss,
    ZoneHeatIndex,
    ZoneHumidex,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum SourceComfortOutputField {
    ZoneSimpleSummer,
    ZoneSimpleWinter,
    ZoneSimpleEither,
    FacilitySimpleSummer,
    FacilitySimpleWinter,
    FacilitySimpleEither,
    ZoneNotMetHeating,
    ZoneNotMetHeatingOccupied,
    ZoneNotMetCooling,
    ZoneNotMetCoolingOccupied,
    FacilityNotMetHeating,
    FacilityNotMetCooling,
    FacilityNotMetHeatingOccupied,
    FacilityNotMetCoolingOccupied,
}
/// Reporting borrows all four actual owner groups on each read.
pub(crate) struct SourceAllOutputOwners<'a> {
    pub(crate) surface: &'a dyn SourceRealOutputOwners,
    pub(crate) solar: &'a dyn SourceRealOutputOwners,
    pub(crate) air: &'a dyn SourceRealOutputOwners,
    pub(crate) comfort: &'a dyn SourceRealOutputOwners,
    pub(crate) hvac: &'a dyn SourceRealOutputOwners,
}
impl SourceRealOutputOwners for SourceAllOutputOwners<'_> {
    fn real_output(&self, target: SourceRealOutputTarget) -> Result<&f64, OrdinaryRadiationError> {
        match target {
            SourceRealOutputTarget::SurfaceHeatBalance { .. } => self.surface.real_output(target),
            SourceRealOutputTarget::Solar { .. } => self.solar.real_output(target),
            SourceRealOutputTarget::Air { .. } => self.air.real_output(target),
            SourceRealOutputTarget::Comfort { .. } => self.comfort.real_output(target),
            SourceRealOutputTarget::Hvac { .. } => self.hvac.real_output(target),
        }
    }
}

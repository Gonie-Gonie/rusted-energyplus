"""Prepare isolated CheckNodeConnections35 Sources; no canonical/Cargo changes."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'source-check-node-connections-draft-Outer-35'
HEAD='8de84bf3ecf4e3353fe8ba1b1de22213873c5539'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def jwrite(p,v):return save(p,(json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))
def main():
 assert not (O/'draft.json').exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
 parent=D/'source-controlled-zone-ventilation-held-Audit-34/complete-final-compiler-Source-plan.json'
 assert ref(parent)['sha256']=='7f7e7674808a970b1e9ad0beda6546a81831614708ead3d80fe9abc6500251b2'
 review=D/'Root-source-controlled-zone-ventilation-actual-review-34/review.json';actual=json.loads(review.read_bytes())
 assert actual['accepted'] is True and not actual.get('findings',[])
 assert ref(review)['sha256']=='ec2e7f307040ecfc083c4822146ec9a4b3f69ad44db23ff137051c4514f1c844'
 pp=json.loads(parent.read_bytes());entries=pp['entries'];assert len(entries)==4503
 # Authenticate actual complete parent files and frozen inputs, not all-Git
 # equality (the historical unselected comment CR bridge remains unchanged).
 for row in entries:
  b=checked(row['source']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['final_sha256'] and len(b)==row['final_bytes']
  assert (R/row['path']).read_bytes()==b,row['path']
 p='crates/ep_runtime/src/heat_balance/startup_integrity/nodes.rs';before=(R/p).read_bytes()
 assert before==subprocess.check_output(['git','show',f'{HEAD}:{p}'],cwd=R)
 old=b'''    /// Actual zero connection loops leave caller ErrorsFound latched unchanged.
    pub(crate) fn check_source_node_connections(
        &mut self,
        _errors_found: &mut bool,
    ) -> Result<(), Error> {
        let error_counter = 0;
        for _connection in 1..=self.number_node_connections {
            return Err(Error::Unavailable(
                "actual CheckNodeConnections919 NodeConnections.ConnectionType first record access",
            ));
        }
        // Native check10 array allocations are guarded by actual count>0.
        // All remaining count-governed checks also have zero iterations here.
        self.number_node_connection_errors += error_counter;
        Ok(())
    }
'''
 assert before.count(old)==1 and before.count(b'mod registration;\n')==1
 after=before.replace(b'mod registration;\n',b'mod registration;\nmod check_connections;\n',1).replace(old,b'',1)
 assert after.replace(b'mod check_connections;\n',b'',1).replace(b'impl SourceBranchNodeConnections {\n',b'impl SourceBranchNodeConnections {\n'+old,1)==before
 new='crates/ep_runtime/src/heat_balance/startup_integrity/nodes/check_connections.rs'
 assert not (R/new).exists()
 proposals={p:(before,after),new:(b'',(O/'proposed'/new).read_bytes())}
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'))
 applynode=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply')
 ns={'re':re};exec(compile(ast.Module(body=[applynode],type_ignores=[]),'<frozen literal apply>','exec'),ns)
 files=[]
 for i,(name,(oldb,newb)) in enumerate(proposals.items(),1):
  oldname=name if oldb else '/dev/null'
  fd=''.join(difflib.unified_diff(oldb.decode().splitlines(True),newb.decode().splitlines(True),fromfile=oldname,tofile=name)).encode()
  iv=''.join(difflib.unified_diff(newb.decode().splitlines(True),oldb.decode().splitlines(True),fromfile=name,tofile=oldname)).encode()
  assert ns['apply'](oldb,fd)==newb and ns['apply'](newb,iv)==oldb
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=newb,capture_output=True);assert q.returncode==0,q.stderr
  files.append(dict(canonical_path=name,before=save(O/'before'/name,oldb),proposed=save(O/'proposed'/name,newb),literal_inverse=save(O/'literal-inverse'/name,oldb),forward_diff=save(O/'diffs'/f'{i:02}.forward.diff',fd),inverse_diff=save(O/'diffs'/f'{i:02}.inverse.diff',iv),Source_only_parse=dict(exit_code=q.returncode,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))))
 final=copy.deepcopy(entries);by={x['canonical_path']:x for x in files}
 for row in final:
  if row['path'] in by:
   r=by[row['path']]['proposed'];row.update(final_sha256=r['sha256'],final_bytes=r['bytes'],source=r,origin='CheckNodeConnections35 existing sole-owner module hook/stub removal')
 r=by[new]['proposed'];final.append(dict(path=new,final_sha256=r['sha256'],final_bytes=r['bytes'],source=r,origin='CheckNodeConnections35 full valid-path child'))
 final.sort(key=lambda r:r['path']);assert len({r['path'] for r in final})==4504
 for row in final:
  if row['path'] not in by:assert row==next(x for x in entries if x['path']==row['path'])
 pr=jwrite(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-complete-Source35-proposed-compiler-input-plan.v1',base_HEAD=HEAD,accepted_actual34=ref(review),parent_plan=ref(parent),inputs=len(final),Rust_sources=sum(r['path'].endswith('.rs') for r in final),selected_existing=1,selected_new=1,entries=final))
 # Capture the exact final whole-crates census through a logical overlay.
 pattern=re.compile(rb'check_source_node_connections\(|checked_connection\(|is_loop_object\(|mod check_connections;')
 census=[]
 for path in sorted((R/'crates').rglob('*.rs')):
  if 'fixtures' in path.parts:continue
  name=path.relative_to(R).as_posix();b=proposals[name][1] if name in proposals else path.read_bytes()
  for line,t in enumerate(b.splitlines(),1):
   if pattern.search(t):census.append(dict(path=name,line=line,text=t.decode('utf-8')))
 for line,t in enumerate(proposals[new][1].splitlines(),1):
  if pattern.search(t):census.append(dict(path=new,line=line,text=t.decode('utf-8')))
 cr=jwrite(O/'whole-crates-final-API-census.json',dict(whole_crates=True,fixture_bodies_excluded=True,logical_overlay=[x['proposed'] for x in files],rows=census))
 plan=D/'check-node-connections-readonly-plan-Outer-35/plan.json';pj=json.loads(plan.read_bytes())
 enum=R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/DataLoopNode.hh'
 pin='6f2e40d10250a105b49966baa24d843711e61048'
 assert enum.read_bytes()==subprocess.check_output(['git','-C',str(R/'.reference/energyplus-src/26.1.0'),'show',f'{pin}:src/EnergyPlus/DataLoopNode.hh'])
 lines=enum.read_text(encoding='utf-8').splitlines(keepends=True)
 er=save(O/'Native-ConnectionObjectType146-437.txt',''.join(lines[145:437]).encode())
 result=dict(schema='src06-CheckNodeConnections-valid-path-draft35.v1',status='FROZEN_SOURCE_DRAFT_FOR_INDEPENDENT_PEER_NOT_FINAL_HELD_NOT_APPLIED',base_HEAD=HEAD,accepted_actual34=ref(review),actual_observed_B=actual['actual_B'],parent_manifest=ref(D/'source-controlled-zone-ventilation-held-Audit-34/manifest.json'),parent_complete_compiler_plan=ref(parent),complete_proposed_compiler_Source_plan=pr,files=files,Source_files=2,old=1,new=1,literal_applications=4,Source_only_parses=2,new_test_bodies=0,Native_readonly_plan=ref(plan),Native_wholes=pj['Native_wholes']+[dict(**ref(enum),pinned_Git=pin,whole_equals_pinned_Git=True)],Native_literal_extents=pj['Native_literal_extents']+[dict(**er,Native_path='src/EnergyPlus/DataLoopNode.hh',start=146,end=437,strict_whole_line_extent=True)],whole_crates_API_census=cr,unchanged_parent_inputs=len(entries)-1,contract=dict(owner='SAME SourceBranchNodeConnections, actual count/capacity/rows. No physical/OP/schedule/cache owner or new persistent state.',scope='All twelve valid-path passes in Native865-1474 exact order; original same method/caller signature. Existing represented object-type domain retained, exact loop bypass enum ordinals2/109/193 compared without wildcard expansion.',diagnostics='Each invalid predicate stops at its actual first severe request before unported diagnostic/counter/latch writes. No claimed diagnostic equivalence; successful suffix adds actual derived local0 to same persistent error count, leaves caller latch unchanged.',check10='Whole allocated registry MaxFluidStream; real local arrays/fills; exact case-sensitive consecutive grouping and sentinel; count1 first-row skip; one-based actual stream access accepts Num5 if allocated; group first-parent skip and subsequent individual parent skips; all stream flags before actual severe boundary; four actual local deallocations before final zone check.',math='No floating-point/property work or formulas. No copied registry/synthetic node/tree/counts.',validation_policy='Root alone executes actual B then A24 as appropriate; no new/helper/mirror tests or habitual unrelated rerun. No runtime/full startup/B620 claim from Source parse.'),author_Source=ref(Path(__file__)),canonical_Source_Cargo_Native_test_mutations=False)
 out=O/'draft.json';jwrite(out,result);print(json.dumps(ref(out)));print(json.dumps(pr))
if __name__=='__main__':main()

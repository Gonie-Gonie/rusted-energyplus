from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={'B': ('canonical-source-controlled-zone-ventilation-B-NOLIMIT-24H-command-Root-34/receipt.json', 'e9cfe5dbb297529bfbf817bc9ba6cb8bb45316f8594b9e868ef18ee68206af2d'), 'A24': ('canonical-source-controlled-zone-ventilation-A-24H-command-Root-34/receipt.json', '2d0b31c380349f84c70ce78946a42d0ebc02b18caddf317e27d860df75cd647e')}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-startup-connection-validation-report-'+case+'-command-Root-35'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-startup-connection-validation-report-'+case+'-Root-35/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

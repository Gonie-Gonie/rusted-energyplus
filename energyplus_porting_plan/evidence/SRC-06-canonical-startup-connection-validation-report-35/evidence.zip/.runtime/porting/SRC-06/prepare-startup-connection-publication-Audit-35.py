from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OLD=D/'publish-controlled-zone-ventilation-checkpoint-Audit-34.py';NEW=D/'publish-startup-connection-validation-report-checkpoint-Audit-35.py'
O=D/'startup-connection-validation-report-publication-prepared-Audit-35'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
mp=D/'source-startup-connection-validation-report-held-Audit-35/manifest.json';m=json.loads(mp.read_bytes());peer=json.loads(auth(m['independent_full_semantic_peer']).read_bytes());assert peer['accepted'] and not peer['findings']
assert not NEW.exists() and not O.exists();before=OLD.read_text(encoding='utf8');s=before
s=s.replace('engine34','engine35').replace('controlled-zone-ventilation','startup-connection-validation-report').replace('Audit-34','Audit-35').replace('ACTUAL34','ACTUAL35')
s=s.replace('startup-connection-validation-report-34','startup-connection-validation-report-35')
s=s.replace("assert len(producer['files'])==producer['existing_Source_files']==5 and producer['new_Source_files']==0","assert len(producer['files'])==5 and producer['existing_Source_files']==4 and producer['new_Source_files']==1")
s=s.replace("(4503,4490)","(4504,4491)").replace('same4503_archived_inputs_exact_final_plan','same4504_archived_inputs_exact_final_plan').replace('len(observed)==4503','len(observed)==4504')
s=s.replace('equal33','equal34').replace('accepted33_full5352_proof','accepted34_full5352_proof').replace('accepted33_proof','accepted34_proof')
s=s.replace('Accepted33 A24 proof transfer','Accepted34 A24 proof transfer').replace('Root-34/output','Root-35/output')
s=s.replace('src06-canonical34-finite','src06-canonical35-finite')
s=s.replace('Five existing production Sources','Four existing and one new production Sources').replace('The parent33 A24 proof is separately attributed; no cohort or new Native rerun by34.','The parent34 A24 proof is separately attributed; no cohort or new Native rerun by35.')
s=s.replace("status='Genuine Source controlled-zone ventilation live output registration; actual B result recorded'","status='Genuine Source startup connection validation and reporting; actual B result recorded'")
s=s.replace('[Source34 controlled-zone ventilation]','[Source35 startup connection validation/report]')
s=s.replace('canonical_controlled_zone_ventilation_34','canonical_startup_connection_validation_report_35').replace('actual_test_bodies_executed_by34','actual_test_bodies_executed_by35')
assert 'len(observed)==4503' not in s and "'new_Source_files']==0" not in s and 'equal33' not in s
ast.parse(s);NEW.write_bytes(s.encode());O.mkdir()
for name,a,b in [('publisher-forward.diff',before,s),('publisher-inverse.diff',s,before)]:
 (O/name).write_bytes(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='accepted34-publisher' if name.startswith('publisher-forward') else 'combined35-publisher',tofile='combined35-publisher' if name.startswith('publisher-forward') else 'accepted34-publisher')).encode())
finite={}
def add(row):p=auth(row);finite[ref(p)['path']]=ref(p)
for row in [ref(mp),m['complete_final_compiler_Source_plan'],m['independent_full_semantic_peer'],m['accepted_Check35_leaf_peer'],m['original_draft'],m['original_Check35_draft'],m['original_Reports36_preparation_draft'],m['read_only_reporting_map'],m['author_Source'],
 m['accepted34_actual_review'],m['full4503_parent_readback'],m['whole4491_Rust_API_census'],ref(Path(__file__)),ref(OLD),ref(O/'publisher-forward.diff'),ref(O/'publisher-inverse.diff')]:add(row)
for row in m['files']:
 for k in ('before','proposed','literal_inverse','forward_diff','inverse_diff'):
  if row.get(k):add(row[k])
 for k in ('stdout','stderr'):add(row['Source_only_parse'][k])
for row in m['Native_authorities']:
 add(row['whole'])
 for e in row['extents']:add(e['source'])
for row in m['concrete_same_owner_contexts']:add(row['whole'])
for key in ('original_Check35_draft','original_Reports36_preparation_draft'):
 old=json.loads(auth(m[key]).read_bytes());add(old['author_Source'])
combined=json.loads(auth(m['original_draft']).read_bytes());add(combined['author_Source'])
prior=json.loads((R/'energyplus_porting_plan/plan.json').read_bytes());task=next(x for x in prior['tasks'] if x['id']=='SRC-06');previous=task['canonical_controlled_zone_ventilation_34'];add(previous)
t={'schema':'src06-startup-connection-validation-report-publication-template.v1','status':'WAITING_FOR_ROOT_ACTUAL35_AND_FULL_READ',
 'base_HEAD':m['base_HEAD'],'publisher_Source':ref(NEW),'producer':ref(mp),'complete_plan':m['complete_final_compiler_Source_plan'],
 'independent_peer':m['independent_full_semantic_peer'],'accepted_parent_review':m['accepted34_actual_review'],'accepted_parent_plan':m['prior_complete_compiler_Source_plan'],
 'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-startup-connection-validation-report-actual-review-35/review.json','previous_engine_checkpoint':previous,'finite_archive_inputs':list(finite.values()),
 'summary_template':{'A':'14/54','B':'14/64','gate_changes':False,'policy_changes':False,'selected_existing_production_Sources':4,'new_production_Source_files':1,'selected_production_Sources':5,
  'same_original_Check2_and_report3_wholes':True,'actual_registry_and_physical_NodeID_Config_List_borrows':True,'positive_ParentNodeList_constructor_remains_explicit_boundary':True,
  'new_test_bodies':0,'actual_test_bodies_executed':0,
  'scope':'One cohesive startup unit joins genuine valid-path CheckNodeConnections traversal and controlled/nonparent/nonconnected reporting. Actual registry flags/counts, Config/List fields and physical NodeID determine operations, not case constants. Scientific code and existing cohort unchanged.',
  'qualification':'Actual B frontier recorded rather than inferred. Severe diagnostics and positive unrepresented parents/other children remain honest boundaries. A24 original5352 proof transferred from accepted34; no fullB/finite15/all12 or internal Native numerical equivalence claim.'},
 'doc_appends':{
 'cards/SRC-06.md':'시작 단계의 노드 연결 검사와 연결 보고를 하나의 변경 단위로 연결했다. 실제 연결 기록과 Config·장비 목록·물리 NodeID를 사용하며, 미구현 진단과 양수 부모 목록은 명시적 경계로 남긴다. B 실행 결과: `{{actual_B_result}}`. A24의 기존 5,352개 보고값 증거를 이어받고 새 테스트나 계산식 변경은 없다.',
 'CHECKLIST.md':'노드 연결 검사와 제어 구역·장비 목록·비부모 노드 연결 보고를 통합했다. 별도 빌드와 체크포인트를 반복하지 않고 실제 B/A24 한 쌍으로 확인한다. 게이트 수는 그대로다.',
 'STATE_CONTRACTS.md':'같은 BranchNodeConnections 기록과 Config·EquipmentList·물리 NodeID를 빌려 읽는다. 실제 부모 플래그를 센 뒤 할당 범위를 결정하고, NodeID[0]의 저장된 Undefined 값과 Native의 우선순위 출력 순서를 보존한다. 보고용 복사 상태는 추가하지 않는다.'}}
for text in t['doc_appends'].values():assert '\ufffd' not in text and '?' not in text
q=O/'publication-template.json';q.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'publisher':ref(NEW),'template':ref(q)}))

from pathlib import Path
import ast,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-positive-connection-reports-draft-Audit-36'
assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(name,b):p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def replace(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
files=[]
def edit(name,mutate):
 before=(R/name).read_bytes();s=before.decode('utf8');new=mutate(s).encode();assert new!=before
 forward=''.join(difflib.unified_diff(s.splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name)).encode()
 inverse=''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),s.splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name)).encode()
 p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R);assert p.returncode==0,p.stderr
 i=len(files)+1;files.append({'canonical_path':name,'before':save('before/'+name,before),'proposed':save('proposed/'+name,new),'literal_inverse':save('literal-inverse/'+name,before),
  'forward_diff':save(f'diffs/{i:02}-forward.diff',forward),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',inverse),'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',p.stdout),'stderr':save(f'parse/{i:02}.stderr',p.stderr)}})
def equipment(s):
 extra='''    /// Actual names and physical node ordinals consumed by startup reports.
    pub(crate) fn equipment_list_name(&self) -> &str { &self.row.equipment_list_name }
    pub(crate) fn control_list_name(&self) -> &str { &self.row.control_list_name }
    pub(crate) fn zone_node_number(&self) -> &usize { &self.row.zone_node }
    pub(crate) fn exhaust_node_number(&self, ordinal: usize) -> Option<&usize> {
        self.row.exhaust_node_numbers.as_ref()?.get(ordinal.checked_sub(1)?)
    }
    pub(crate) fn heating_distribution_inlet_node_number(&self, ordinal: usize) -> Option<&usize> {
        Some(&self.row.air_distribution_units_heat.as_ref()?.get(ordinal.checked_sub(1)?)?.inlet_node)
    }
    pub(crate) fn cooling_distribution_inlet_node_number(&self, ordinal: usize) -> Option<&usize> {
        Some(&self.row.air_distribution_units_cool.as_ref()?.get(ordinal.checked_sub(1)?)?.inlet_node)
    }
'''
 s=replace(s,"impl SourceZoneEquipmentConfigRef<'_> {\n","impl SourceZoneEquipmentConfigRef<'_> {\n"+extra)
 new='''/// A short borrow of the same actual EquipmentList row, not a report projection.
pub(crate) struct SourceZoneEquipmentListRef<'a> { row: &'a EquipmentList }
impl SourceZoneEquipmentListRef<'_> {
    pub(crate) fn name(&self) -> &str { &self.row.name }
    pub(crate) fn number_equipment_types(&self) -> &usize { &self.row.number_of_equipment_types }
    pub(crate) fn equipment_type_name(&self, ordinal: usize) -> Option<&str> {
        self.row.equipment_type_names.as_ref()?.get(ordinal.checked_sub(1)?).map(String::as_str)
    }
    pub(crate) fn equipment_name(&self, ordinal: usize) -> Option<&str> {
        self.row.equipment_names.as_ref()?.get(ordinal.checked_sub(1)?).map(String::as_str)
    }
    pub(crate) fn cooling_priority(&self, ordinal: usize) -> Option<&i32> {
        self.row.cooling_priorities.as_ref()?.get(ordinal.checked_sub(1)?)
    }
    pub(crate) fn heating_priority(&self, ordinal: usize) -> Option<&i32> {
        self.row.heating_priorities.as_ref()?.get(ordinal.checked_sub(1)?)
    }
}

'''
 s=replace(s,'/// Temporary reads of the same physical Node fields used by air correction.\n',new+'/// Temporary reads of the same physical Node fields used by air correction.\n')
 new='''    /// Native NodeID has physical lower bound0. Index0 is read from actual
    /// allocator storage (Undefined), never synthesized for missing owners.
    pub(crate) fn source_node_id(&self, number: usize) -> Result<&str, super::selected_heat_balance_input::HeatBalanceInputError> {
        i32::try_from(number).map_err(|_| super::selected_heat_balance_input::HeatBalanceInputError::Unavailable("actual NodeID signed ordinal"))?;
        self.nodes.node_ids.as_ref().and_then(|rows| rows.get(number)).map(String::as_str)
            .ok_or(super::selected_heat_balance_input::HeatBalanceInputError::Unavailable("actual allocated physical NodeID"))
    }
    /// Native2737 uses the actual parallel controlled-zone Count, without an
    /// EquipListIndex remap or name search.
    pub(crate) fn source_zone_equipment_list(&self, ordinal: i32) -> Result<SourceZoneEquipmentListRef<'_>, super::selected_heat_balance_input::HeatBalanceInputError> {
        let index=ordinal.checked_sub(1).and_then(|n|usize::try_from(n).ok())
            .ok_or(super::selected_heat_balance_input::HeatBalanceInputError::Unavailable("actual ZoneEquipList report ordinal"))?;
        let row=self.equipment_lists.as_ref().and_then(|rows|rows.get(index))
            .ok_or(super::selected_heat_balance_input::HeatBalanceInputError::Unavailable("actual same ZoneEquipList report allocation"))?;
        Ok(SourceZoneEquipmentListRef { row })
    }
'''
 return replace(s,'    pub(crate) fn source_zone_equipment_config(\n',new+'    pub(crate) fn source_zone_equipment_config(\n')
edit('crates/ep_runtime/src/heat_balance/ordinary_equipment.rs',equipment)
def loop_reports(s):
 a='''            return Err(Error::Unavailable(
                "actual ReportLoopConnections2684 controlled ZoneEquipConfig.ZoneName",
            ));'''
 b='''            let config = o.equipment.source_zone_equipment_config(number)?;
            writeln!(bnd, " Controlled Zone,{},{},{},{},{},{},{}",
                config.zone_name(), config.equipment_list_name(), config.control_list_name(),
                o.equipment.source_node_id(*config.zone_node_number())?,
                config.number_inlet_nodes(), config.number_exhaust_nodes(), config.number_return_nodes())?;
            for ordinal in 1..=*config.number_inlet_nodes() {
                // Native reads heat-node name first, and only this exact name
                // is replaced. Cooling NodeID0 remains the real Undefined.
                let heat_node = *config.heating_distribution_inlet_node_number(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2692 AirDistUnitHeat.InNode"))?;
                let heat_name = o.equipment.source_node_id(heat_node)?;
                let chr_name = if heat_name == "Undefined" { "N/A" } else { heat_name };
                let inlet = *config.inlet_node_number(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2700 InletNode"))?;
                let cool = *config.cooling_distribution_inlet_node_number(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2701 AirDistUnitCool.InNode"))?;
                writeln!(bnd, "   Controlled Zone Inlet,{},{},{},{},{}", ordinal,
                    config.zone_name(), o.equipment.source_node_id(inlet)?,
                    o.equipment.source_node_id(cool)?, chr_name)?;
            }
            for ordinal in 1..=*config.number_exhaust_nodes() {
                let node = *config.exhaust_node_number(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2709 ExhaustNode"))?;
                writeln!(bnd, "   Controlled Zone Exhaust,{},{},{}", ordinal,
                    config.zone_name(), o.equipment.source_node_id(node)?)?;
            }
            for ordinal in 1..=*config.number_return_nodes() {
                let node = *config.return_node_number(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2716 ReturnNode"))?;
                writeln!(bnd, "   Controlled Zone Return,{},{},{}", ordinal,
                    config.zone_name(), o.equipment.source_node_id(node)?)?;
            }'''
 s=replace(s,a,b)
 a='''            return Err(Error::Unavailable(
                "actual ReportLoopConnections2737 ZoneEquipList.Name",
            ));'''
 b='''            let list = o.equipment.source_zone_equipment_list(number)?;
            let config = o.equipment.source_zone_equipment_config(number)?;
            writeln!(bnd, " Zone Equipment List,{},{},{},{}", number,
                list.name(), config.zone_name(), list.number_equipment_types())?;
            for ordinal in 1..=*list.number_equipment_types() {
                let equipment_type = list.equipment_type_name(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2745 EquipTypeName"))?;
                let name = list.equipment_name(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2746 EquipName"))?;
                // Preserve actual Native argument order, although the existing
                // descriptive header names the opposite priority ordering.
                let cooling = list.cooling_priority(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2748 CoolingPriority"))?;
                let heating = list.heating_priority(ordinal)
                    .ok_or(Error::Unavailable("actual ReportLoopConnections2749 HeatingPriority"))?;
                writeln!(bnd, "   Zone Equipment Component,{},{},{},{},{},{}", ordinal,
                    equipment_type, name, config.zone_name(), cooling, heating)?;
            }'''
 return replace(s,a,b)
edit('crates/ep_runtime/src/heat_balance/startup_integrity/connection_reports.rs',loop_reports)
def node_reports(s):
 new='''
/// Literal Native DataLoopNode.hh112-127 names, including its exact spelling.
fn connection_type_name(kind: SourceNodeConnectionType) -> Result<&'static str, Error> {
    use SourceNodeConnectionType::*;
    match kind {
        Blank => Ok("blank"), Inlet => Ok("Inlet"), Outlet => Ok("Outlet"),
        Internal => Ok("Internal"), ZoneNode => Ok("ZoneNode"), Sensor => Ok("Sensor"),
        Actuator => Ok("Actuator"), OutsideAir => Ok("OutdoorAir"), ReliefAir => Ok("ReliefAir"),
        ZoneInlet => Ok("ZoneInlet"), ZoneReturn => Ok("ZoneReturn"), ZoneExhaust => Ok("ZoneExhaust"),
        SetPoint => Ok("Setpoint"), Electric => Ok("Electric"), OutsideAirReference => Ok("OutsideAirReference"),
        InducedAir => Ok("InducedAir"),
        Invalid | Num => Err(Error::Unavailable("actual ReportNodeConnections ConnectionTypeNames index domain")),
    }
}
'''
 s=replace(s,'use std::io::Write;\n','use std::io::Write;\n'+new)
 a='''        let number_non_parents = 0;
        for _connection in 1..=self.number_node_connections {
            return Err(Error::Unavailable(
                "actual ReportNodeConnections2088 NodeConnections.ObjectIsParent",
            ));
        }'''
 b='''        let mut number_non_parents: i32 = 0;
        for number in 1..=self.number_node_connections {
            let row = self.node_connections.as_ref()
                .and_then(|rows| extent(number).ok().and_then(|n| n.checked_sub(1)).and_then(|i| rows.get(i)))
                .ok_or(Error::Unavailable("actual ReportNodeConnections2088 live NodeConnections"))?;
            if row.object_is_parent { continue; }
            number_non_parents = number_non_parents.checked_add(1)
                .ok_or(Error::Unavailable("actual ReportNodeConnections2091 NumNonParents signed addition"))?;
        }'''
 s=replace(s,a,b)
 s=replace(s,'        // Both parent and non-parent record loops use the same actual zero count.\n','''        for number in 1..=self.number_node_connections {
            let row = self.node_connections.as_ref()
                .and_then(|rows| extent(number).ok().and_then(|n|n.checked_sub(1)).and_then(|i|rows.get(i)))
                .ok_or(Error::Unavailable("actual ReportNodeConnections2103 live NodeConnections"))?;
            if !row.object_is_parent { continue; }
            return Err(Error::Unavailable("actual ReportNodeConnections2106 positive parent NonConnectedNodes write"));
        }
''')
 needle='''        let mut number_non_connected: i32 = 0;'''
 new='''        for number in 1..=self.number_node_connections {
            let row = self.node_connections.as_ref()
                .and_then(|rows| extent(number).ok().and_then(|n|n.checked_sub(1)).and_then(|i|rows.get(i)))
                .ok_or(Error::Unavailable("actual ReportNodeConnections2169 live NodeConnections"))?;
            if row.object_is_parent { continue; }
            *self.non_connected_nodes.as_mut()
                .and_then(|rows|row.node_number.checked_sub(1).and_then(|i|rows.get_mut(i)))
                .ok_or(Error::Unavailable("actual ReportNodeConnections2172 NonConnectedNodes(NodeNumber)"))? = false;
            let object_type = row.object_type.source_name()?.to_ascii_uppercase();
            let connection_type = connection_type_name(row.connection_type)?;
            writeln!(bnd, " Non-Parent Node Connection,{},{},{},{},{}", row.node_name,
                object_type, row.object_name, connection_type, row.fluid_stream as i32)?;
        }
'''
 s=replace(s,needle,new+needle)
 a='''                return Err(Error::Unavailable(
                    "actual ReportNodeConnections2199 NodeID before NonConnected Node record",
                ));'''
 b='''                writeln!(bnd, " NonConnected Node,{},{}", number, equipment.source_node_id(number)?)?;'''
 return replace(s,a,b)
edit('crates/ep_runtime/src/heat_balance/startup_integrity/nodes/reporting.rs',node_reports)
# Original coherent Source bodies stay intact outside their exact literal edits.
for row in files:
 tree=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':__import__('re')};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
 before=(R/row['before']['path']).read_bytes();new=(R/row['proposed']['path']).read_bytes()
 assert ns['apply_literal'](before,(R/row['forward_diff']['path']).read_bytes())==new
 assert ns['apply_literal'](new,(R/row['inverse_diff']['path']).read_bytes())==before
plan=D/'positive-startup-connection-report-readonly-Audit-36/plan.json';assert ref(plan)['sha256']=='6816cd0605ea300350653e4286f13031c64ee1d971bb42c7287b9dcaa772c40a'
draft={'schema':'src06-positive-startup-connection-reports-Source-draft.v1','status':'Immutable Source-only semantic draft, unreached36/final35 parent and actual custody pending',
 'base_HEAD_at_authoring':subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True,text=True).stdout.strip(),
 'read_only_integration_map':ref(plan),'files':files,'existing_Source_files':3,'new_Source_files':0,'literal_applications':6,'Source_only_parses':3,
 'ownership':'Same actual Config/List/NodeOwner names and Branch NodeConnections/NonConnected/ParentList owners; only borrowed views, no scalar snapshot or production ready projection.',
 'preserved_scope':'All existing early outdoor/component/plant/condenser and positive ParentNodeList constructor boundaries remain genuine. No new Node registry shape or35 overlap. Parent record actual flags counted before deciding allocated shape.',
 'exact_output_details':['Native actual cooling priority then heating priority despite header order','Only exact heat NodeID Undefined maps N/A; cooling0 remains real NodeID[0] Undefined','Native UC object names, mixed-case connection type labels and actual stream underlying integer','Existing I/O stream produces physical text, no whole-file postprocessing'],
 'validation_policy':'Root alone runs B then A24 after formal peer and committed35. No new tests or scientific changes; existing cohort untouched. No current36 execution or fullB/Nativepaired report claim.',
 'new_test_bodies':0,'Cargo_main_tests_or_Native_execution':False,'author_Source':ref(Path(__file__))}
p=O/'draft.json';p.write_bytes((json.dumps(draft,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

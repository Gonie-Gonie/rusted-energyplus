from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
HEAD='8de84bf3ecf4e3353fe8ba1b1de22213873c5539';O=D/'source-startup-connection-validation-report-held-Audit-35'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
def load(name,sha):p=R/name;assert ref(p)['sha256']==sha;return p,json.loads(p.read_bytes())
def save(name,b):p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True).stdout
def contains(x,row):return isinstance(x,dict) and ((x.get('path'),x.get('sha256'))==(row['path'],row['sha256']) or any(contains(v,row) for v in x.values())) or isinstance(x,list) and any(contains(v,row) for v in x)
a=argparse.ArgumentParser();a.add_argument('--peer-path',required=True);a.add_argument('--peer-sha',required=True);args=a.parse_args()
assert not O.exists() and git(R,'rev-parse','HEAD').decode().strip()==git(R,'rev-parse','origin/main').decode().strip()==HEAD and not git(R,'status','--porcelain=v1').strip()
dp,draft=load('.runtime/porting/SRC-06/source-startup-connection-validation-report-draft-Audit-35/draft.json','ceb65bce1f146d94f749c66073f724eb3b6a8375e23d71277d61c83cce225601')
pp,peer=load(args.peer_path,args.peer_sha);assert peer['accepted'] and not peer['findings'] and contains(peer,ref(dp))
actual=json.loads(auth(draft['accepted34_actual_review']).read_bytes());assert actual['accepted'] and not actual['findings'];assert actual['B_frontier']=='GetHeatBalanceInput: actual CheckNodeConnections919 NodeConnections.ConnectionType first record access'
prior=json.loads(auth(draft['prior_complete_compiler_Source_plan']).read_bytes());entries={x['path']:copy.deepcopy(x) for x in prior['entries']};assert len(entries)==4503
b=json.loads(auth(actual['actual_B']).read_bytes());a24=json.loads(auth(actual['actual_A24']).read_bytes());assert b['exit_code']==6 and a24['exit_code']==0 and b['source_snapshot']==a24['source_snapshot'] and ref(auth(b['source_snapshot']))==draft['actual_parent_snapshot']
snapshot=json.loads(auth(draft['actual_parent_snapshot']).read_bytes());archives={x['historical_path']:x for x in snapshot['files']};assert set(entries)==set(archives)
readback=[]
for name,row in entries.items():
 raw=auth(archives[name]['archive']).read_bytes();assert raw==auth(row['source']).read_bytes()==(R/name).read_bytes();assert len(raw)==row['final_bytes'] and hashlib.sha256(raw).hexdigest()==row['final_sha256']
 readback.append({'path':name,'actual_archive':archives[name]['archive'],'sha256':row['final_sha256'],'bytes':len(raw),'archive_live_plan_exact':True})
O.mkdir();tree=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[]
for i,row in enumerate(draft['files'],1):
 name=row['canonical_path'];before=b'' if row['before_absent'] else auth(row['before']).read_bytes();new=auth(row['proposed']).read_bytes()
 if row['before_absent']:assert name not in entries and not (R/name).exists() and not git(R,'ls-tree',HEAD,'--',name)
 else:assert before==(R/name).read_bytes()==auth(archives[name]['archive']).read_bytes()==git(R,'show',HEAD+':'+name)
 assert ns['apply_literal'](before,auth(row['forward_diff']).read_bytes())==new and ns['apply_literal'](new,auth(row['inverse_diff']).read_bytes())==before
 assert new==auth(row['literal_origin_whole']).read_bytes()
 p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R);assert p.returncode==0,p.stderr
 whole=save('proposed/'+name,new)
 files.append({'canonical_path':name,'before_absent':row['before_absent'],'before':save('before/'+name,before) if before else None,'actual_parent_archive':row['actual_parent_archive'],
  'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}-forward.diff',auth(row['forward_diff']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',auth(row['inverse_diff']).read_bytes()),
  'original_author_family':row['origin_family'],'literal_origin_whole':row['literal_origin_whole'],'combined_reviewed_whole':row['proposed'],'before_whole_Git_exact_or_absent_at_base':True,
  'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',p.stdout),'stderr':save(f'parse/{i:02}.stderr',p.stderr)}})
 entries[name]={'path':name,'final_sha256':whole['sha256'],'final_bytes':whole['bytes'],'source':whole,'origin':'whole exact accepted original '+row['origin_family']+' proposal; final combined35 join only'}
assert len(files)==5 and sum(x['before_absent'] for x in files)==1 and len(entries)==4504 and sum(x.endswith('.rs') for x in entries)==4491
for row in draft['Native_authorities']:
 raw=auth(row['whole']).read_bytes();assert raw==git(N,'show',PIN+':'+row['Native_path'])==(N/row['Native_path']).read_bytes();lines=raw.splitlines(keepends=True)
 for e in row['extents']:assert b''.join(lines[e['first']-1:e['last']])==auth(e['source']).read_bytes()
for c in draft['concrete_same_owner_contexts']:
 assert auth(c['whole']).read_bytes()==(R/c['canonical_path']).read_bytes()
for row in draft['preserved_safe_cohort_Sources']:
 assert entries[row['path']]==next(x for x in prior['entries'] if x['path']==row['path'])
equipment='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';old=(R/equipment).read_bytes();new=auth(next(x for x in files if x['canonical_path']==equipment)['proposed']).read_bytes();token=b'    pub(crate) fn restore_native_cohort_node(';assert old[old.index(token):]==new[new.index(token):]
plan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-startup-connection-validation-report-plan.v1','base_HEAD':HEAD,'actual34_parent_review':draft['accepted34_actual_review'],'actual34_parent_snapshot':draft['actual_parent_snapshot'],'prior_plan':draft['prior_complete_compiler_Source_plan'],'inputs':4504,'Rust_sources':4491,'selected_existing':4,'selected_new':1,'entries':[entries[x] for x in sorted(entries)]})
manifest={'schema':'src06-held-startup-connection-validation-report.v1','status':'HELD coherent startup35 on clean committed actual34; no35 or36 execution/completion claim',
 'base_HEAD':HEAD,'accepted34_actual_review':draft['accepted34_actual_review'],'parent_producer':actual['producer'],'actual_parent_receipts':{'B':actual['actual_B'],'A24':actual['actual_A24']},'actual_parent_snapshot':draft['actual_parent_snapshot'],'prior_complete_compiler_Source_plan':draft['prior_complete_compiler_Source_plan'],'complete_final_compiler_Source_plan':plan,
 'compiler_inputs':4504,'Rust_sources':4491,'original_draft':ref(dp),'independent_full_semantic_peer':ref(pp),'accepted_Check35_leaf_peer':draft['accepted_Check35_leaf_peer'],
 'original_Check35_draft':draft['original_Check35_draft'],'original_Reports36_preparation_draft':draft['original_Reports36_preparation_draft'],'read_only_reporting_map':draft['read_only_reporting_map'],
 'files':files,'existing_Source_files':4,'new_Source_files':1,'selected_Source_files':5,'literal_applications':10,'Source_only_parses':5,'all5_original_proposals_whole_unchanged':True,
 'full4503_parent_readback':dump('actual34-parent-full-readback.json',readback),'whole4491_Rust_API_census':draft['whole4491_Rust_API_census'],
 'Native_commit':PIN,'Native_authorities':draft['Native_authorities'],'Native_whole_files':draft['Native_whole_files'],'Native_strict_extents':draft['Native_strict_extents'],'concrete_same_owner_contexts':draft['concrete_same_owner_contexts'],
 'preserved_safe_cohort_Sources':draft['preserved_safe_cohort_Sources'],'equipment_test_only_loader_suffix_unchanged':True,'operation_order':draft['operation_order'],'scope':draft['scope'],'combination_reason':draft['combination_reason'],
 'validation_policy':draft['validation_policy'],'new_test_bodies':0,'actual_test_bodies_executed':0,'Cargo_main_tests_or_Native_mutations':False,'author_Source':ref(Path(__file__))}
p=O/'manifest.json';p.write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'manifest':ref(p),'plan':plan}))

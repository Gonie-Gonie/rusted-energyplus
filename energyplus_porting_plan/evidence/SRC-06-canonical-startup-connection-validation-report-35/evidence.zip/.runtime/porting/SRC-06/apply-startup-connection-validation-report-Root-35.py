from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-startup-connection-validation-report-application-35';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-startup-connection-validation-report-held-Audit-35/manifest.json');assert mr['sha256']=='59acc57202c4cd0771d9330f0ae759b33ff2d9b126f8a4b0700e1cc70971e144';m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];assert pr['sha256']=='2b34c577869d48ff7eab536151b52a6c3025eecdfbdd719e0f4a0faf22dde8ec';peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peerfiles={v['canonical_path']:v for v in peer['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='8de84bf3ecf4e3353fe8ba1b1de22213873c5539' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4503 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(f['literal_origin_whole'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==5 and len(new)==1 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==7 and extent_count==17
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted34_actual_review','parent_producer','prior_complete_compiler_Source_plan','full4503_parent_readback','whole4491_Rust_API_census','original_draft']:checked(m[k])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4504 and sum(n.endswith('.rs') for n in rows)==4491
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
for v in m['preserved_safe_cohort_Sources']:assert (R/v['path']).read_bytes()==checked(v['whole'])
for k in ['original_Check35_draft','original_Reports36_preparation_draft','accepted_Check35_leaf_peer','read_only_reporting_map']:checked(m[k])
equipment=selected['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'];assert checked(equipment['before']).rsplit(b'#[cfg(test)]',1)[-1]==checked(equipment['proposed']).rsplit(b'#[cfg(test)]',1)[-1]
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Full combined five Sources: accepted independent Check2 leaf plus full Report3 semantics and exact five-file composition. Root independently authenticates committed34 parent4503 and complete4504/4491 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4503,final_inputs=4504,final_Rust_sources=4491,selected_Rust=5,new_Rust=1,literal_applications=10,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read the two entire Check proposals and all three reporting/getter forward diffs, full Native865-1474 twelve checks, SimulationManager2066-2204/2653-2775, actual registry/default/capacity and Config/List/NodeID owner contexts. Fullallocated stream maximum and consecutive grouping/counts preserve native normal predicates; first diagnostic requests remain honest boundaries with caller latch untouched. Report reads exact Config and sameCount List, heating Undefined maps N/A only, cooling Undefined retained, cooling then heating priorities match Native actual order. Nonparent count derives real flags, actual NonConnected writes precede declarations and deallocates at suffix; positive parent constructor honest boundary. No new physical state/cache, formulas, tests, tolerance or gate changes. Safe-main cohort and equipment loader suffix retained. Exact original2+3 proposal wholes combined in one coherent startup unit; actual B/A35 pending.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

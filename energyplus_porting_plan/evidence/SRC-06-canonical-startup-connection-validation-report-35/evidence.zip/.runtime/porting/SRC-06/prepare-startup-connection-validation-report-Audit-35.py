from pathlib import Path
import ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048';HEAD='8de84bf3ecf4e3353fe8ba1b1de22213873c5539';O=D/'source-startup-connection-validation-report-draft-Audit-35'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
def load(name,sha):p=R/name;assert ref(p)['sha256']==sha;return p,json.loads(p.read_bytes())
def save(name,b):p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True).stdout
assert not O.exists() and git(R,'rev-parse','HEAD').decode().strip()==git(R,'rev-parse','origin/main').decode().strip()==HEAD and not git(R,'status','--porcelain=v1').strip()
O.mkdir()
cp,check=load('.runtime/porting/SRC-06/source-check-node-connections-draft-Outer-35/draft.json','9915e6de64a4be0fd57864989e89103ebd51cc96208196a448fce1ac6ba005dc')
rp,report=load('.runtime/porting/SRC-06/source-positive-connection-reports-draft-Audit-36/draft.json','748558821b3b23922490d566a4b64ca7fa452ac200f2060adf6b0961d89eaf7f')
lp,leaf=load('.runtime/porting/SRC-06/Peer-check-node-connections-Source-review-35/review.json','202152087d5c5dcb6272153bf19d87c1c1f7005e58ef926f6675944fea85c0b3');assert leaf['accepted'] and not leaf['findings']
ap,actual=load('.runtime/porting/SRC-06/Root-source-controlled-zone-ventilation-actual-review-34/review.json','ec2e7f307040ecfc083c4822146ec9a4b3f69ad44db23ff137051c4514f1c844');assert actual['accepted'] and not actual['findings']
assert actual['B_frontier']=='GetHeatBalanceInput: actual CheckNodeConnections919 NodeConnections.ConnectionType first record access'
prior_path=auth(actual['complete_compiler_plan']);prior=json.loads(prior_path.read_bytes());assert len(prior['entries'])==4503 and sum(x['path'].endswith('.rs') for x in prior['entries'])==4490
entries={x['path']:copy.deepcopy(x) for x in prior['entries']};b=json.loads(auth(actual['actual_B']).read_bytes());a=json.loads(auth(actual['actual_A24']).read_bytes());assert b['exit_code']==6 and a['exit_code']==0 and a['source_snapshot']==b['source_snapshot'];sp=auth(b['source_snapshot']);snapshot=json.loads(sp.read_bytes());archives={x['historical_path']:x for x in snapshot['files']};assert set(entries)==set(archives)
raws={};readback=[]
for name,row in entries.items():
 raw=auth(archives[name]['archive']).read_bytes();assert raw==auth(row['source']).read_bytes()==(R/name).read_bytes();assert len(raw)==row['final_bytes'] and hashlib.sha256(raw).hexdigest()==row['final_sha256'];raws[name]=raw
 readback.append({'path':name,'actual_archive':archives[name]['archive'],'sha256':row['final_sha256'],'bytes':len(raw),'archive_live_plan_exact':True})
tree=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];logical={}
for label,parent in [('Check35',check),('Reports36_preparation',report)]:
 for row in parent['files']:
  name=row['canonical_path'];before=auth(row['before']).read_bytes();new=auth(row['proposed']).read_bytes();absent=name not in entries
  assert name not in logical
  if absent:assert not before and not (R/name).exists() and git(R,'ls-tree',HEAD,'--',name)==b''
  else:assert before==raws[name]==git(R,'show',HEAD+':'+name)
  assert ns['apply_literal'](before,auth(row['forward_diff']).read_bytes())==new and ns['apply_literal'](new,auth(row['inverse_diff']).read_bytes())==before
  p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R);assert p.returncode==0,p.stderr
  i=len(files)+1;whole=save('proposed/'+name,new)
  files.append({'canonical_path':name,'before_absent':absent,'before':save('before/'+name,before) if not absent else None,'original_before':row['before'],
   'actual_parent_archive':archives[name]['archive'] if not absent else None,'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),
   'forward_diff':save(f'diffs/{i:02}-forward.diff',auth(row['forward_diff']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',auth(row['inverse_diff']).read_bytes()),
   'origin_family':label,'literal_origin_whole':row['proposed'],'before_whole_Git_exact_or_absent_at_base':True,
   'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',p.stdout),'stderr':save(f'parse/{i:02}.stderr',p.stderr)}})
  entries[name]={'path':name,'final_sha256':whole['sha256'],'final_bytes':whole['bytes'],'source':whole,'origin':'whole exact original '+label+' proposal; no Source rewrite during composition'};logical[name]=new
assert len(files)==5 and sum(x['before_absent'] for x in files)==1 and len(entries)==4504 and sum(x.endswith('.rs') for x in entries)==4491
needles=['check_source_node_connections','check_connections','report_source_node_connections','report_source_loop_connections','SourceZoneEquipmentListRef','source_zone_equipment_list','source_node_id(','heating_distribution_inlet_node_number','cooling_distribution_inlet_node_number','connection_type_name(','register_source_node_connection','object_is_parent','parent_node_list']
api=[]
for name,row in sorted(entries.items()):
 if not name.endswith('.rs'):continue
 raw=logical[name] if name in logical else raws[name];text=raw.decode('utf8');hits=[{'line':i,'terms':[n for n in needles if n in line]} for i,line in enumerate(text.splitlines(),1) if any(n in line for n in needles)]
 if hits:api.append({'path':name,'ordered_hits':hits,'final_sha256':row['final_sha256']})
planp=auth(report['read_only_integration_map']);mapping=json.loads(planp.read_bytes());native={}
for row in mapping['Native_authorities']:
 name=row['Native_path'];raw=auth(row['whole']).read_bytes();assert raw==git(N,'show',PIN+':'+name)==(N/name).read_bytes();lines=raw.splitlines(keepends=True)
 ext=[]
 for x in row['extents']:assert b''.join(lines[x['first']-1:x['last']])==auth(x['source']).read_bytes();ext.append(x)
 native[name]={'Native_path':name,'whole':row['whole'],'extents':ext,'pinned_Git_exact':True}
for row in check['Native_wholes']:
 raw=auth(row).read_bytes();name=Path(row['path']).relative_to('.reference/energyplus-src/26.1.0').as_posix();assert raw==git(N,'show',PIN+':'+name)==(N/name).read_bytes()
 if name in native:assert raw==auth(native[name]['whole']).read_bytes()
 else:native[name]={'Native_path':name,'whole':save('Native-whole/'+Path(name).name,raw),'extents':[],'pinned_Git_exact':True}
for x in check['Native_literal_extents']:
 row=native[x['Native_path']];raw=auth(row['whole']).read_bytes();assert b''.join(raw.splitlines(keepends=True)[x['start']-1:x['end']])==auth(x).read_bytes()
 e={'first':x['start'],'last':x['end'],'source':{k:x[k] for k in ('path','sha256','bytes')}}
 if e not in row['extents']:row['extents'].append(e)
assert len(native)==7
contexts=[]
for x in mapping['Source_contexts']:
 name=x['canonical_path'];assert auth(x['whole']).read_bytes()==raws[name]
 contexts.append({'canonical_path':name,'whole':{**archives[name]['archive'],'bytes':len(raws[name])},'actual34_archive_and_live_exact':True})
native_refs=[native[x] for x in sorted(native)];extent_count=sum(len(x['extents']) for x in native_refs)
compiler_plan=dump('complete-proposed-compiler-Source-plan.json',{'schema':'src06-complete-startup-connection-validation-report-plan.v1','base_HEAD':HEAD,'actual34_parent_review':ref(ap),'actual34_parent_snapshot':ref(sp),'prior_plan':ref(prior_path),'inputs':4504,'Rust_sources':4491,'selected_existing':4,'selected_new':1,'entries':[entries[x] for x in sorted(entries)]})
preserved=[]
for name in ['crates/ep_runtime/Cargo.toml','crates/ep_runtime/src/lib.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/native_cohort.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/fixtures/native_prediction_b.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/surface.rs']:
 assert entries[name]==next(x for x in prior['entries'] if x['path']==name);preserved.append({'path':name,'whole':entries[name]['source']})
equipment='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';token=b'    pub(crate) fn restore_native_cohort_node(';assert raws[equipment][raws[equipment].index(token):]==logical[equipment][logical[equipment].index(token):]
manifest={'schema':'src06-combined-startup-connection-validation-report-Source-draft.v1','status':'Immutable coherent5Source draft; original2+3 whole bytes retained, final full peer and held seal pending; no production35/36 execution claim',
 'base_HEAD':HEAD,'accepted34_actual_review':ref(ap),'actual_observed_B':actual['actual_B'],'actual_parent_snapshot':ref(sp),'prior_complete_compiler_Source_plan':ref(prior_path),
 'complete_proposed_compiler_Source_plan':compiler_plan,'compiler_inputs':4504,'Rust_sources':4491,'files':files,'existing_Source_files':4,'new_Source_files':1,'selected_Source_files':5,'literal_applications':10,'Source_only_parses':5,
 'original_Check35_draft':ref(cp),'original_Reports36_preparation_draft':ref(rp),'accepted_Check35_leaf_peer':ref(lp),'read_only_reporting_map':ref(planp),
 'Native_commit':PIN,'Native_authorities':native_refs,'Native_whole_files':len(native_refs),'Native_strict_extents':extent_count,'concrete_same_owner_contexts':contexts,
 'full4503_parent_readback':dump('actual34-parent-full-readback.json',readback),'whole4491_Rust_API_census':dump('API-census.json',{'Rust_sources_examined':4491,'all_crates_runtime_tests_included':True,'needles':needles,'hits':api}),
 'preserved_safe_cohort_Sources':preserved,'equipment_test_only_loader_suffix_unchanged':True,
 'operation_order':'Existing Native startup315 checks real registry and error latch, then unchanged integrity children, then real guards328 call loop connections329, airloop330, node331. No caller reorder; no forced simulation flags or report omission.',
 'scope':'All12 genuine valid CheckNodeConnections passes and zero-local-error suffix; invalid first diagnostics typed boundaries. Complete controlled Config/List and nonparent/NonConnected reporting on same retained owners; positive ParentNodeList remains real typed constructor boundary. Native actualcool/heating priority order and physicalNodeID0 Undefined semantics preserved.',
 'combination_reason':'One cohesive startup validation/reporting production unit avoids a redundant CLI build, QA and checkpoint. Original authors/proposals/leaf acceptance retain attribution; no invented35/36 runtime completion or extra commit.',
 'validation_policy':'Root alone runs production B then A24 after independent full combined peer. No new tests/scientific formulas or habitual unrelated suites/cohort/Native reruns.',
 'new_test_bodies':0,'actual_test_bodies_executed':0,'Cargo_main_tests_or_Native_execution':False,'author_Source':ref(Path(__file__))}
p=O/'draft.json';p.write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'draft':ref(p),'plan':compiler_plan,'Native_wholes':len(native_refs),'Native_extents':extent_count}))

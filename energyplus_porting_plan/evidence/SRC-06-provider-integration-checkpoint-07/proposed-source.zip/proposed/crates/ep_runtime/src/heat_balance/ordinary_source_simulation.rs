//! Genuine simulation caller orchestration, requiring same retained Source children.
pub(crate) mod primary;
pub(crate) mod setup;
mod setup_host;

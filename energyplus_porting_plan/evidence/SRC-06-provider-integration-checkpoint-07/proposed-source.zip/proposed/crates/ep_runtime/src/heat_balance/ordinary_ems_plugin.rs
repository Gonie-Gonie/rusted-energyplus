//! Actual EMS quick-return and Plugin trend children used by ManageHeatBalance.
//! Constructor-empty plugin trends are read from the genuine retained module.
use super::selected_heat_balance_globals::SelectedHeatBalanceGlobals;
use super::selected_heat_balance_input::HeatBalanceInputError as Error;
use super::selected_simulation_startup::SelectedRuntimeLanguage;
use std::convert::Infallible;

/// Six actual EMSManager.hh calling points used by HeatBalanceManager and WeatherManager.
#[repr(i32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum SourceHeatBalanceEmsCallingPoint {
    BeginNewEnvironmentAfterWarmup = 3,
    EndZoneTimestepBeforeZoneReporting = 10,
    EndZoneTimestepAfterZoneReporting = 11,
    BeginZoneTimestepBeforeInitHeatBalance = 17,
    BeginZoneTimestepAfterInitHeatBalance = 18,
    BeginZoneTimestepBeforeSetCurrentWeather = 19,
}
/// Native263 writes anyProgramRan before the real AnyEMS quick-return predicate.
/// None represents the caller's unwritten local; it never supplies a probe value.
pub(crate) fn manage_source_heat_balance_ems(
    globals: &SelectedHeatBalanceGlobals,
    _calling_point: SourceHeatBalanceEmsCallingPoint,
    any_program_ran: &mut Option<bool>,
) -> Result<(), Error> {
    *any_program_ran = Some(false);
    if !globals.any_energy_management_system_in_model {
        return Ok(());
    }
    // None of the six actual caller constants is BeginNewEnvironment2, so
    // the first positive child is genuinely InitEMS274, before plugins/programs.
    Err(Error::Unavailable(
        "actual positive ManageHeatBalance EMS InitEMS274",
    ))
}
impl SelectedRuntimeLanguage {
    pub(crate) fn update_source_ems_trend_variables(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
    ) -> Result<(), Error> {
        if !globals.any_energy_management_system_in_model {
            return Ok(());
        }
        if self.number_of_erl_trend_variables == 0 {
            return Ok(());
        }
        if self.number_of_erl_trend_variables >= 1 {
            return Err(Error::Unavailable("actual EMS TrendVariable first row1468"));
        }
        // Native negative count has an empty signed 1..count loop as well.
        Ok(())
    }
}
/// Actual PluginManagerData237 std::vector ctor-empty; not maxIndex=-1 inference.
/// Positive PluginTrendVariable construction requires native arguments not admitted here.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct SourcePluginData {
    trends: Vec<Infallible>,
}
impl SourcePluginData {
    pub(crate) fn update_source_plugin_values(&mut self) -> Result<(), Error> {
        // LINK_WITH_PYTHON body1461 first traverses this genuine vector; the
        // no-Python body is empty. Both actual admitted empty-vector paths agree.
        if !self.trends.is_empty() {
            return Err(Error::Unavailable(
                "actual Plugin trend getGlobalVariableValue1462",
            ));
        }
        Ok(())
    }
}

"""One coherent independent Source peer; stdin rustfmt only, no Cargo/main."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/porting/SRC-06'
OUT = BASE / 'Audit-controlled-equipment-coherent-Source-review-01'
NATIVE = '6f2e40d10250a105b49966baa24d843711e61048'
PARENT = 'b68a0060d750eac9c074adb0f8de5635f6e8039c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(data), 'bytes': len(data)}


def checked(row):
    raw = (ROOT / row['path']).read_bytes()
    assert sha(raw) == row['sha256'], row
    if 'bytes' in row:
        assert len(raw) == row['bytes'], row
    return raw


def git(repo, revision, path):
    return subprocess.run(['git', '-C', str(repo), 'show', revision + ':' + path], capture_output=True, check=True).stdout


def structure(text, name):
    match = re.search(r'struct ' + name + r'\s*\{(.*?)\n\}', text, re.S)
    assert match, name
    return re.findall(r'^\s*(?:pub(?:\([^)]*\))?\s+)?([a-z_]+):', match[1], re.M)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--sha', required=True)
    args = parser.parse_args()
    path = ROOT / args.manifest
    assert sha(path.read_bytes()) == args.sha
    assert not OUT.exists()
    m = json.loads(path.read_text(encoding='utf-8'))
    assert m['base_HEAD'] == PARENT and m['Native_commit'] == NATIVE
    assert m['main_mutations'] == m['new_test_bodies'] == 0
    assert m['Cargo_Native_or_tests_executed'] is False and m['FP_or_tolerance_changes'] is False
    assert m['B_completion_claim'] is False
    applicator = (BASE / 'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8')
    function = next(n for n in ast.parse(applicator).body if isinstance(n, ast.FunctionDef) and n.name == 'apply')
    namespace = {'re': re}
    exec(compile(ast.Module(body=[function], type_ignores=[]), '<pure literal applicator>', 'exec'), namespace)
    apply = namespace['apply']
    snap = json.loads(checked(m['actual_parent_snapshot']))
    parent = {row['historical_path']: row for row in snap['files']}
    plan = json.loads(checked(m['complete_final_compiler_Source_plan']))
    final = {row['path']: row for row in plan['entries']}
    assert len(parent) == 4480 and len(final) == plan['inputs'] == 4486
    assert plan['Rust_sources'] == sum(p.endswith('.rs') for p in final) == 4473
    assert plan['parent_actual_snapshot']['sha256'] == m['actual_parent_snapshot']['sha256']
    rows = {row['canonical_path']: row for row in m['files']}
    assert len(rows) == 15 and m['existing_Source_files'] == 9 and m['new_Source_files'] == 6
    assert set(final) == set(parent) | {p for p, r in rows.items() if r['before_absent']}
    for p, row in final.items():
        if p in rows:
            expected = rows[p]['proposed']
            assert (row['final_sha256'], row['final_bytes']) == (expected['sha256'], expected['bytes'])
            assert checked(row['source']) == checked(expected)
        else:
            assert (row['final_sha256'], row['final_bytes']) == (parent[p]['archive']['sha256'], parent[p]['size_bytes'])
    bridges = {row['path']: row for row in m['precise_selected_parent_bridges']}
    assert set(bridges) == {p for p, r in rows.items() if not r['before_absent']}
    freeze = json.loads(checked(m['freeze']))
    for row in freeze['files']:
        raw = checked(row['parent'])
        old = parent[row['canonical_path']]
        assert raw == checked(old['archive']) == (ROOT / row['canonical_path']).read_bytes()
        assert row['actual14_plan_entry']['final_sha256'] == old['archive']['sha256']
    receipt = json.loads(checked(m['actual14_B_receipt']))
    assert receipt['exit_code'] == 6 and receipt['source_bytes_match_before_and_after'] is True
    assert receipt['source_snapshot']['sha256'] == m['actual_parent_snapshot']['sha256']
    assert b'actual GetZoneEquipmentData308 ZoneHVAC:EquipmentConnections getObjectItem' in checked(m['actual14_frontier'])
    native_wholes = {}
    for row in m['Native_wholes']:
        raw = checked(row['whole_source'])
        assert row['revision'] == NATIVE
        assert raw == git(ROOT / '.reference/energyplus-src/26.1.0', NATIVE, row['Native_path'])
        native_wholes[row['Native_path']] = raw
    for row in m['Native_literal_extents']:
        assert checked(row['whole_source']) == native_wholes[row['Native_path']]
        excerpt = b''.join(native_wholes[row['Native_path']].splitlines(keepends=True)[row['first_line'] - 1:row['last_line']])
        assert checked(row['literal_excerpt']) == excerpt
    helper = json.loads(checked(m['exact_Node_Branch_helper_join']))
    helper_peer_path = BASE / 'Audit-Node-getters-registration-Source-review-01/review.json'
    assert sha(helper_peer_path.read_bytes()) == 'd2bbb8653447d0281e87d664b728b34ff1da2a57f2f0afed783643cfcb909df5'
    helper_peer = json.loads(helper_peer_path.read_text(encoding='utf-8'))
    assert helper_peer['accepted'] is True
    for row in helper['files']:
        assert checked(row['proposed']) == checked(rows[row['canonical_path']]['proposed'])
    constructors = json.loads(checked(m['constructor_records']))
    integration = json.loads(checked(m['integration_contract']))
    checked(m['author_Source']); checked(m['sealer_Source'])
    # Independent field/order/default binding uses actual retained schema,
    # already authenticated from installed-schema/pinned IDD in RawB ingress.
    rawb = BASE / 'ordinary-source-B-raw-ingress-held-Audit-01/seven-whole-Native-schema-objects.json'
    schema = json.loads(rawb.read_text(encoding='utf-8'))
    connection_schema = schema['ZoneHVAC:EquipmentConnections']
    fields = connection_schema['legacy_idd']['fields']
    getter = checked(rows['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_equipment_getter.rs']['proposed']).decode('utf-8')
    field_pairs = re.findall(r'\("([a-z0-9_]+)", "([^"]+)"\)', getter)
    assert [p[0] for p in field_pairs] == fields
    assert [p[1] for p in field_pairs] == [connection_schema['legacy_idd']['field_info'][p]['field_name'] for p in fields]
    assert connection_schema['legacy_idd']['numerics']['fields'] == []
    properties = next(iter(connection_schema['patternProperties'].values()))['properties']
    assert all(properties[p]['type'] == 'string' and 'default' not in properties[p] and 'retaincase' not in properties[p] for p in fields)
    list_properties = next(iter(schema['ZoneHVAC:EquipmentList']['patternProperties'].values()))['properties']
    assert list_properties['load_distribution_scheme']['default'] == 'SequentialLoad'
    ext_props = list_properties['equipment']['items']['properties']
    assert all(ext_props[p]['type'] == 'integer' and 'default' not in ext_props[p] for p in ['zone_equipment_cooling_sequence', 'zone_equipment_heating_or_no_load_sequence'])
    OUT.mkdir()
    file_results, text = [], {}
    for index, row in enumerate(m['files'], 1):
        p = row['canonical_path']
        before, proposed = checked(row['before']), checked(row['proposed'])
        assert apply(before, checked(row['forward_diff'])) == proposed
        assert apply(proposed, checked(row['inverse_diff'])) == before == checked(row['literal_inverse'])
        if row['before_absent']:
            assert before == b'' and p not in parent and not (ROOT / p).exists()
        else:
            assert before == checked(parent[p]['archive']) == git(ROOT, PARENT, p) == (ROOT / p).read_bytes()
            assert bridges[p]['actual14_archive'] == parent[p]['archive']
        # Entire proposed bytes are parsed; rustfmt output is captured only.
        parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=proposed, capture_output=True)
        assert parsed.returncode == 0, parsed.stderr
        stdout, stderr = OUT / f'{index:02d}.parse.stdout', OUT / f'{index:02d}.parse.stderr'
        stdout.write_bytes(parsed.stdout); stderr.write_bytes(parsed.stderr)
        assert row['Source_only_parse']['exit_code'] == 0
        checked(row['Source_only_parse']['stdout']); checked(row['Source_only_parse']['stderr'])
        added = b''.join(line[1:] for line in checked(row['forward_diff']).splitlines(keepends=True) if line.startswith(b'+') and not line.startswith(b'+++'))
        assert not re.search(rb'\b(?:unwrap|expect)\s*\(', added)
        assert not re.search(rb'\b(?:panic|todo|unimplemented|unreachable)\s*!', added)
        assert b'#[test]' not in added
        file_results.append({'canonical_path': p, 'before': row['before'], 'proposed': row['proposed'], 'literal_forward_inverse_exact': True, 'fresh_parse_exit': 0, 'parse_stdout': ref(stdout), 'parse_stderr': ref(stderr)})
        text[p] = proposed.decode('utf-8')
    owner = text['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs']
    types = text['crates/ep_runtime/src/heat_balance/ordinary_equipment/source_equipment_types.rs']
    sizing = text['crates/ep_runtime/src/heat_balance/selected_sizing/terminal_unit.rs']
    for name, source in [('EquipmentConfig', owner), ('EquipmentList', owner), ('SourceAirIn', types), ('SourceEquipmentData', types), ('SourceSimulationOrder', types), ('SourceTerminalUnitSizingData', sizing)]:
        record = constructors['Source_records'][name]
        assert structure(source, name) == record['fields']
        assert len(record['fields']) == record['field_count']
    assert 'terminal_unit_sizing_index: 0' in types
    assert 'supply_air_path_outlet_node_index: None' in types
    assert re.search(r'terminal_unit_sizing_index:\s*usize', types)
    assert re.search(r'supply_air_path_outlet_node_index:\s*Option<i32>', types)
    # Exact whole preservation of the already-existing initialization body;
    # its existing SourceSome call alone gains a missing-Branch argument.
    init_path = 'crates/ep_runtime/src/heat_balance/initialization.rs'
    before_init = checked(rows[init_path]['before'])
    proposed_init = checked(rows[init_path]['proposed'])
    assert proposed_init.count(b'                None,\n') == before_init.count(b'                None,\n') + 1
    delta = checked(rows[init_path]['forward_diff'])
    assert [x for x in delta.splitlines() if x.startswith(b'+') and not x.startswith(b'+++')] == [b'+                None,']
    supplemental_extent = native_wholes['src/EnergyPlus/InputProcessing/InputProcessor.cc'].splitlines(keepends=True)[789:893]
    supplemental = OUT / 'Native-InputProcessor-setObjectItemValue-L790-893.txt'
    supplemental.write_bytes(b''.join(supplemental_extent))
    report = {
        'schema': 'src06-independent-coherent-controlled-equipment-Source-review.v1',
        'accepted': True, 'findings': [], 'author_manifest': ref(path),
        'base_HEAD': PARENT, 'actual14_B': m['actual14_B_receipt'],
        'actual14_parent_snapshot': m['actual_parent_snapshot'],
        'complete_final_compiler_Source_plan': m['complete_final_compiler_Source_plan'],
        'plan4486_inputs4473Rust_metadata_exact_parent4480_plus15_selected': True,
        'precise_raw_custody': 'nine selected existing parents are whole actual14 archive/current/b68 Git exact; six new parents empty and absent; fourteen frozen context owners match actual14 archive/current. Unchanged plan entries use exact actual14 raw metadata, without all4480 Git/raw rehash claim.',
        'whole_sources': 15, 'literal_applications': 30, 'fresh_parse_exits': [0] * 15,
        'files': file_results, 'native_commit': NATIVE,
        'Native14_whole_pinned_Git': m['Native_wholes'],
        'Native18_literal_extents': m['Native_literal_extents'],
        'supplemental_actual_value_writer_extent': ref(supplemental),
        'retained_schema8slots_and_exact_field_names_defaults': ref(rawb),
        'constructor_records': m['constructor_records'], 'integration_contract': m['integration_contract'],
        'exact_four_Source_helper_join': m['exact_Node_Branch_helper_join'],
        'accepted_helper_peer': ref(helper_peer_path),
        'resolved_prior_packet_findings': [
            'Source01 AirIn reversed the actual initialized TermUnitSizingIndex0 and omitted SupplyAirPathOutNodeIndex. Successor02 restores real terminalusize0 and actual omitted outletOptionNone, then native inlet writes and same-parent terminal reads; corrected all constructor claims.',
            'Source01 local EquipListAudit described ObjectType as an uninitialized enum although Native declares defaultempty std::string then assigns unscoped enum through char. Successor02 preserves actual empty-string/one-byte PurchasedAir12 assignment and string equality; no Native answer values or math change.'
        ],
        'reviewed_native_order_and_owners': [
            'Original counts and six definition/max queries, local arrays, zero Supply/Return domain allocations, real gains and Config/List/availability allocations, count diagnostics and real InitUnique precede the positive getter.',
            'Actual getter resets all existing local arrays then erases unused identity and writes the eight schema alpha slots/blanks/exact format-dependent field names. Consumed local values are represented; unconsumed NumAlphas/NumNums/IOStat are explicitly unrepresented, never fabricated8/0 counts.',
            'Same mutable Zone is looked up by actual uppercase name and marked controlled before the child. Actual Config control/name/uniqueness/ZoneNode and return schedule precede EquipmentList query/used erase/default load distribution and allocations.',
            'Real IdealLoads type/name validation precedes cooling then heating sequences/ranges, independent cooling/heating schedule pointers, available counts and enum12 assignment. Unitary factory branches are false for the actual enum; sequence duplicate/gap diagnostics stop before their first Native message.',
            'Actual inlet/exhaust/return/basis GetNodeNums calls share the existing Node and Branch owners. Native allocation order, zero and minus-one initializers, per-node unique checks, inlet terminal counter/index writes and return associations are retained.',
            'Actual same sizing manager NumAirTerminalUnits and full19-field terminal allocation follow the child, then controlled-zone indices. Local audit construction/population/ordered pair check precedes list-index mapping and EndUnique. Three exact family finds and genuine zero Supply/Return loops precede deallocation and fatal test.',
            'Native wrapper flags, timestep-day product, actual controlled Config maximum and full6-field PrioritySimOrder constructor allocation occur only after the child return. Post-return Rust validation reads real storage; it does not set readiness or substitute a second gains/node arena.',
            'Full44-field Config,18-field List,11-field AirIn,18-field EquipmentData,19-field terminal and6-field Priority defaults were checked directly against pinned Native. Actual AirIn omitted outlet primitive remains unrepresented; real terminal field starts0.',
            'Source first-input borrows the actual session HVAC ancillary Branch through context/setup and same mutable Zone/Schedule/Sizing owners. No duplicate registry/cache, typed NodeID substitution, Legacy fallback or default Branch is introduced. Existing initialization whole is recovered exactly by deleting only the added None argument in its preexisting SourceSome call.'
        ],
        'explicit_limits': [
            'Finite one-Zone/single Connections and List/IdealLoads valid-input closure only; multi-IDF order is not inferred. Existing sole NodeList scope and ASCII input-name comparisons remain qualified.',
            'Positive Space configuration, Supply/ReturnPath allocation, present SpaceHVAC warning/positive branches, component types outside IdealLoads and unported diagnostic domains return typed unavailability before the first unported Native operation.',
            'Later SetupNodeVarsForReporting/ResetNodeData/HVAC consumers are separate genuine obligations. Actual15 next frontier and full B completion are not claimed.',
            'No compiler, Native simulation or test ran in this peer. Root will use one nonzero meaningful existing runtime test plus productionCLI B/A24 and exact compiler snapshot/artifact evidence; a separate workspace-all-targets check is not required by this review.',
            'Prior Source01 remains immutable and superseded; acceptance applies only to the final author manifest bound above.'
        ],
        'main_mutations': 0, 'new_test_bodies': 0, 'Cargo_Native_tests_executed': False,
        'reviewer_Source': ref(Path(__file__)),
    }
    (OUT / 'review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(ref(OUT / 'review.json')))


if __name__ == '__main__':
    main()

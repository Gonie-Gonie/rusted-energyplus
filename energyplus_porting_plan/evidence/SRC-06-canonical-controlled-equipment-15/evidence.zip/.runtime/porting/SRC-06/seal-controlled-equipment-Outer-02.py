from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'source-controlled-equipment-draft-Outer-01';O=B/'source-controlled-equipment-held-Outer-02';N=R/'.reference/energyplus-src/26.1.0'
HEAD='b68a0060d750eac9c074adb0f8de5635f6e8039c';PIN='6f2e40d10250a105b49966baa24d843711e61048';assert not O.exists()
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(v):
 p=R/v['path'];x=ref(p);assert x['sha256']==v['sha256'] and x['bytes']==v.get('bytes',x['bytes']);return p
def load(p):return json.loads(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=R)
receipt_path=B/'canonical-source-Zone-Node-B-NOLIMIT-24H-command-Root-14/receipt.json';assert ref(receipt_path)['sha256']=='25304c5ef2b1aaad0e1ffb369f2c8c32c963055235c4c701c11bd7e482d24863'
receipt=load(receipt_path);assert receipt['exit_code']==6 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
snapshot=get(receipt['source_snapshot']);before={x['historical_path']:x for x in load(snapshot)['files']};assert len(before)==4480
diagnostics=B/'canonical-source-Zone-Node-B-NOLIMIT-24H-Root-14/output/diagnostics.json';assert 'actual GetZoneEquipmentData308 ZoneHVAC:EquipmentConnections getObjectItem' in diagnostics.read_text(encoding='utf8')
freeze=load(D/'freeze.json')
for row in freeze['files']:
 name=row['canonical_path'];z=get(row['parent']).read_bytes();assert z==get(before[name]['archive']).read_bytes()==(R/name).read_bytes()==subprocess.check_output(['git','show',HEAD+':'+name],cwd=R)
helper_path=B/'source-Node-getters-registration-helper-held-Peer-01/manifest.json';assert ref(helper_path)['sha256']=='c3b3d39b5d4cd2e925a06597c32fec68fc580d495d6ceef58ea747c3c43adc7b';helper=load(helper_path)
proposed={p.relative_to(D/'proposed').as_posix():p.read_bytes() for p in sorted((D/'proposed').rglob('*.rs'))};assert len(proposed)==15
for row in helper['files']:assert proposed[row['canonical_path']]==get(row['proposed']).read_bytes()
for name,new in proposed.items():
 assert b'#[test]' not in new
 assert b'ZONE ONE INLET' not in new and b'ZONE ONE EQUIPMENT' not in new and b'ZONE ONE IDEAL LOADS' not in new
 # Existing legacy files may contain preexisting test diagnostics; only newly
 # authored fragments are subject to the new-call census below.
 q=subprocess.run(['git','show',HEAD+':'+name],cwd=R,capture_output=True);old=q.stdout
 additions='\n'.join(x[1:] for x in difflib.unified_diff(old.decode().splitlines(),new.decode().splitlines()) if x.startswith('+') and not x.startswith('+++')).encode()
 assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unreachable|unimplemented)!',additions)
S=(B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8');F=next(x for x in ast.parse(S).body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');G={'re':re};exec(compile(ast.Module(body=[F],type_ignores=[]),'<whole-literal-applier>','exec'),G)
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==PIN
O.mkdir()
def put(n,z):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);return ref(p)
def doc(n,v):return put(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
files=[];bridges=[]
for i,(name,new) in enumerate(proposed.items(),1):
 q=subprocess.run(['git','show',HEAD+':'+name],cwd=R,capture_output=True);old=q.stdout;absent=q.returncode==128;assert absent or q.returncode==0
 if absent:assert not old and name not in before and not (R/name).exists()
 else:
  assert old==(R/name).read_bytes()==get(before[name]['archive']).read_bytes()
  bridges.append(dict(path=name,current_Git_revision=HEAD,actual14_archive=before[name]['archive'],whole_equal=True))
 row=dict(canonical_path=name,before_absent=absent,before=put('before/'+name,old),proposed=put('proposed/'+name,new),literal_inverse=put('literal-inverse/'+name,old))
 for key,a,b in [('forward_diff',old,new),('inverse_diff',new,old)]:
  diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='before/'+name,tofile='proposed/'+name,n=3)).encode();assert G['apply_literal'](a,diff)==b;row[key]=put(f'diffs/{i:02}-{key}.diff',diff)
 v=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R);assert v.returncode==0,(name,v.stderr)
 row['Source_only_parse']=dict(exit_code=0,stdout=put(f'parse/{i:02}.stdout',v.stdout),stderr=put(f'parse/{i:02}.stderr',v.stderr));files.append(row)
assert sum(x['before_absent'] for x in files)==6
native_names=['DataZoneEquipment.cc','DataZoneEquipment.hh','DataSizing.hh','ZoneEquipmentManager.cc','ZoneEquipmentManager.hh','NodeInputManager.cc','NodeInputManager.hh','DataLoopNode.hh','BranchNodeConnections.cc','DataBranchNodeConnections.hh','InputProcessing/InputProcessor.cc','GlobalNames.cc','GeneralRoutines.cc','UtilityRoutines.cc']
wholes=[]
for name in native_names:
 p=N/'src/EnergyPlus'/name;z=p.read_bytes();assert z==subprocess.check_output(['git','-C',str(N),'show',PIN+':src/EnergyPlus/'+name]);wholes.append(dict(Native_path='src/EnergyPlus/'+name,revision=PIN,whole_source=ref(p),Git_equal=True))
by_native={x['Native_path']:x for x in wholes};extents=[]
for name,a,b,purpose in [
 ('DataZoneEquipment.cc',167,812,'Whole GetZoneEquipmentData'),('DataZoneEquipment.cc',814,1260,'Whole processZoneEquipmentInput'),
 ('DataZoneEquipment.cc',101,163,'Equipment/LoadDist name tables'),('DataZoneEquipment.hh',108,190,'Equipment/LoadDist enums'),
 ('DataZoneEquipment.hh',282,452,'Whole AirIn/EquipConfiguration/EquipmentData/EquipList reached records'),
 ('DataSizing.hh',658,687,'TermUnitSizingData members/full constructor'),('DataSizing.hh',1329,1329,'Actual NumAirTerminalUnits ctor0'),('DataSizing.hh',1362,1368,'TermUnitSizing same-owner field'),
 ('ZoneEquipmentManager.cc',169,197,'Whole GetZoneEquipment wrapper'),('ZoneEquipmentManager.hh',72,80,'Whole SimulationOrder constructor'),
 ('InputProcessing/InputProcessor.cc',621,714,'Whole alpha/int field getters plus real field getter context'),
 ('InputProcessing/InputProcessor.cc',895,929,'Whole getJSONObjectItem lookup/used erase'),
 ('InputProcessing/InputProcessor.cc',932,1118,'Whole getObjectItem resets/unused/field value writes'),
 ('GlobalNames.cc',68,89,'Whole IntraObjUniquenessCheck'),('GeneralRoutines.cc',724,763,'Whole name ValidateComponent'),
 ('NodeInputManager.cc',80,186,'Whole GetNodeNums'),('NodeInputManager.cc',740,952,'GetOnlySingleNode/unique check methods'),
 ('BranchNodeConnections.cc',651,798,'Whole RegisterNodeConnection same-owner allocation/validation/order')]:
 name='src/EnergyPlus/'+name;whole=by_native[name]['whole_source'];z=b''.join(get(whole).read_bytes().splitlines(True)[a-1:b]);extents.append(dict(Native_path=name,first_line=a,last_line=b,purpose=purpose,whole_source=whole,literal_excerpt=put(f'Native/{name.replace("/","_")}.L{a}-{b}.txt',z)))
counts={};h='crates/ep_runtime/src/heat_balance/'
for n,typ,want in [('ordinary_equipment.rs','EquipmentConfig',44),('ordinary_equipment.rs','EquipmentList',18),('ordinary_equipment/source_equipment_types.rs','SourceAirIn',11),('ordinary_equipment/source_equipment_types.rs','SourceEquipmentData',18),('ordinary_equipment/source_equipment_types.rs','SourceSimulationOrder',6),('selected_sizing/terminal_unit.rs','SourceTerminalUnitSizingData',19)]:
 s=proposed[h+n].decode();body=s[s.index('struct '+typ+' {'):];body=body[:body.index('\n}')];fields=re.findall(r'^\s+(?:pub\([^)]*\) )?(\w+):',body,re.M);assert len(fields)==want;counts[typ]=dict(field_count=want,fields=fields)
constructors=doc('reached-constructor-records.json',dict(Source_records=counts,AirIn_constructor='Native explicitly initializes TermUnitSizingIndex0; Source retains usize0 and the actual inlet loop overwrites real counter values before parent read. Native omits SupplyAirPathOutNodeIndex, represented as None until a genuine later writer. Other9 fields preserve native ctor/unallocated states.',TermUnitSizing='Separate same-manager NumAirTerminalUnits ctor0/TermUnitSizing None, not NumAirTerminalSizing input count. Full19-field ctor preserves all 1.0/0.0/false/empty defaults; actual count writer/allocation/each CtrlZoneNum follows child return.',equipment_list='Full18-field same row. compPointer actual std::vector starts empty and resizesN+1/null; other arrays constructor-unallocated. Exact allocation/initializer loop retained before real JSON values.',priority='Native wrapper flags/timestep/max actual controlled config loop then real SimulationOrder allocation; no premature simulated order/IdealLoads type insertion.'))
legacy=h+'initialization.rs';old=(R/legacy).read_bytes();new=proposed[legacy];needle=b'                &mut *source.output_host,\n                None,\n';assert new.count(needle)==1;assert new.replace(needle,b'                &mut *source.output_host,\n')==old
contract=doc('integration-contract.json',dict(scope='Cohesive valid finite one-Zone/one-IdealLoads equipment input through genuine GetZoneEquipmentData and GetZoneEquipment wrapper return. Source only; actual compilation/execution not yet claimed.',actual14_frontier='Receipt25304c5e proves nominal controlled lookup and real NodeList/Assign/InitUnique returned before actual controlled getter308. No claim actual15 ran.',owners='Same SelectedZoneData isControlled before child/SystemZoneNodeNumber after; existing EquipmentConfig/List/Node/uniqueness/gains owners. Same existing ScheduleManager pointers, SelectedSizingManager NumAirTerminalUnits/TermUnitSizing, and session.hvac.ancillary.branch_node_connections borrowed through Source first-input/context/setup. No second branch/node/schedule arena or typed node conversion.',getter='Value-producing actual8 alpha slots with exact resets/blanks/field names/unused erase. Single input object has exact ordinal. Physical IDF NumAlphas/NumNums are unconsumed here and deliberately unrepresented; neither8nor0 is fabricated. Source-is-epJSON comes from same retained HB raw custody. No generic InputProcessor completion/order/default claim.',body='Actual config/list flags/name/duplicate check, ZoneNode/unique names, return schedule, real list query/used erase/JSON defaults/arrays/ValidateComponent/sequence checks/schedules/availability/type. Inlet/exhaust/return/basis Node APIs retain actual caller locals, arrays, integer indices, terminal counter and constructor write order.',parent='Same counts/maxima/local arrays/gain and config allocation/count diagnostics/InitUnique, actual Zone lookup/duplicate/write/child/ZoneNode handoff. Real terminal allocation/CtrlZoneNum, local equipment audit and duplicate loop, list-index association/EndUnique, actual3finds/zero path loops/local deallocation/fatal test. Native wrapper then flags/timestep/actual max equipment count/PrioritySimOrder allocation.',validation='Post-return Rust owner shape checks read real counts/arrays only; do not write readiness/flags or initialize diagnostic collections. Existing exhaustive empty-state validator is retained for legacy/A. Source controlled shape branch permits actual ended unique-count and checks same allocation/index associations.',legacy='Entire initialization.rs recovers by deleting the one added None argument inside its preexisting SourceSome path. Default None route gains no new call. Optional missing Branch is allowed only before a positive consumer; genuine Source first-input passes actual existing Branch. No fallback/default/reset branch owner.',bounds=['Space sizing/simulation, Supply/ReturnPath positives and present SpaceHVAC find warnings remain their earlier truthful boundaries.','Node/unique/list/error diagnostics stop at first unported message; no fabricated success/error flags.','Only finite IdealLoads component type is admitted at ValidateComponent operation; no unitary factories or general equipment completion.','Single Connections/List ordinal is explicit; no expanded generic IDF order recovery.','Later positive SetupNodeVarsForReporting/ResetNodeData/HVAC branches remain honest separately ported obligations.'],test_policy='No new test bodies or Cargo/test/Native execution by author. Root owns one focused meaningful existing runtime-test build plus actual CLI B/A24 regression; no duplicate mandatory alltargets or per-helper/broad-suite proliferation.',main_mutations=0,Native_answer_production_input=False,FP_or_tolerance_changes=False,full_B_completion_claim=False))
by={x['canonical_path']:x for x in files};entries=[]
for name,row in sorted(before.items()):
 final=by[name]['proposed'] if name in by else dict(path=row['archive']['path'],sha256=row['archive']['sha256'],bytes=row['size_bytes']);entries.append(dict(path=name,final_sha256=final['sha256'],final_bytes=final['bytes'],source=final,origin='held controlled-equipment proposal' if name in by else 'actual14 archived parent'))
for name,row in sorted(by.items()):
 if name not in before:
  final=row['proposed'];entries.append(dict(path=name,final_sha256=final['sha256'],final_bytes=final['bytes'],source=final,origin='new held Source'))
assert len(entries)==4486 and sum(x['path'].endswith('.rs') for x in entries)==4473
complete=doc('complete-final-compiler-Source-plan.json',dict(base_HEAD=HEAD,parent_actual_snapshot=ref(snapshot),inputs=4486,Rust_sources=4473,entries=sorted(entries,key=lambda x:x['path']),Root_full_rehash_required=True))
prior_path=B/'source-controlled-equipment-held-Outer-01/manifest.json';assert ref(prior_path)['sha256']=='f845e4f5a76fffcfdb58e66e639093c2b056e2c43d622ccffc0f140f7422a388'
prior=load(prior_path);corrections=[]
for row in files:
 name=row['canonical_path'];oldrow=next(x for x in prior['files'] if x['canonical_path']==name);a=get(oldrow['proposed']).read_bytes();b=get(row['proposed']).read_bytes()
 if a==b:continue
 assert name.endswith(('/source_equipment_types.rs','/source_controlled_equipment.rs','/source_input.rs'))
 change=dict(path=name,Source01=oldrow['proposed'],Source02=row['proposed'])
 for key,left,right in [('forward',a,b),('inverse',b,a)]:
  diff=''.join(difflib.unified_diff(left.decode().splitlines(True),right.decode().splitlines(True),fromfile='Source01/'+name,tofile='Source02/'+name,n=3)).encode();assert G['apply_literal'](left,diff)==right;change[key]=put('corrections/'+name.replace('/','_')+'-'+key+'.diff',diff)
 corrections.append(change)
assert len(corrections)==3
correction=doc('correction-proof.json',dict(supersedes=ref(prior_path),changes=corrections,additional_literal_applications=6,all_other12_proposals_whole_identical=True,findings=['AirIn constructor: TermUnitSizingIndex is initialized0, SupplyAirPathOutNodeIndex is the omitted primitive; corrected actual types/defaults/read/writers.','EquipListAudit.ObjectType is std::string initiallyempty, then native enum-to-char assignment; Source now stores the exact single-byte ASCII String rather than an equivalent finite integer comparison.'],audit_local='PurchasedAir native enum12 produces one char byte12. The same actual string/name/list-number local writes and duplicate order are preserved. No type-name substitution or numerical conversion.',validation_policy='Root latest focused existing runtime-test build plus actualCLI B/A24; no duplicate mandatory alltargets/newtests.'))
manifest=doc('manifest.json',dict(schema='src06-held-cohesive-finite-controlled-equipment-input.v1',status='HELD Source only; no compiler/test/actual15 claim',supersedes=ref(prior_path),correction_proof=correction,base_HEAD=HEAD,actual14_B_receipt=ref(receipt_path),actual14_frontier=ref(diagnostics),actual_parent_snapshot=ref(snapshot),precise_selected_parent_bridges=bridges,files=files,existing_Source_files=9,new_Source_files=6,literal_applications=30,Source_only_parses=15,complete_final_compiler_Source_plan=complete,constructor_records=constructors,integration_contract=contract,exact_Node_Branch_helper_join=ref(helper_path),Native_commit=PIN,Native_wholes=wholes,Native_literal_extents=extents,freeze=ref(D/'freeze.json'),new_test_bodies=0,main_mutations=0,Cargo_Native_or_tests_executed=False,FP_or_tolerance_changes=False,B_completion_claim=False,author_Source=ref(B/'author-controlled-equipment-Outer-02.py'),sealer_Source=ref(Path(__file__))))
print(json.dumps(manifest))

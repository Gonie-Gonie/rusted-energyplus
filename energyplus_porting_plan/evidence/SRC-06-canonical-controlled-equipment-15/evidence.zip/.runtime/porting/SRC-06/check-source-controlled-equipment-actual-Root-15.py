from pathlib import Path
import ast, copy, hashlib, json, re, subprocess, sys

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'Root-source-controlled-equipment-actual-review-15'
assert not O.exists()
parent = D / 'check-source-compact-actual-Root-13.py'
source = parent.read_bytes()
assert hashlib.sha256(source).hexdigest() == 'e74ca3d9d2a85102f0dca30ed978ed25d7f8bee8e1fd72459b7b7ba131c2dea4'
tree = ast.parse(source)
names = {'ref', 'checked', 'auth', 'same_path', 'core'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names], type_ignores=[]), '<authenticated13-helpers>', 'exec'))
ap, app = auth('Root-controlled-equipment-application-15/receipt.json', '1135682dd90244e0adecf7edffaf329259d2f09b6487ef019de1329b06731db6')
assert app['accepted'] and not app['findings']
producer = json.loads(checked(app['producer']))
peer = json.loads(checked(app['independent_peer']))
assert peer['accepted'] and not peer['findings']
fr, fix = auth('source-controlled-equipment-test-caller-fix-held-Root-15-02/manifest.json', '1232244c042f74cb09bafdfef09bcd0eee17be194bf3748098a765322e13fd2b')
fpr, fixpeer = auth('Audit-controlled-equipment-test-flag-fix-Source-review-15/review.json', '33c074aaf4bec7ea7dd084a4458f2a999b75d2727d306cf3d6c28d86dfbfd838')
assert fixpeer['accepted'] and not fixpeer['findings']
plan = json.loads(checked(fix['complete_final_compiler_Source_plan']))
rows = {v['path']: v for v in plan['entries']}
assert len(rows) == 4486 and sum(n.endswith('.rs') for n in rows) == 4473
commands = {}
for label, name, exit_code in [
    ('test', 'canonical-source-controlled-equipment-owner-test-Root-15-03/receipt.json', 0),
    ('B', 'canonical-source-controlled-equipment-B-NOLIMIT-24H-command-Root-15/receipt.json', 6),
    ('A24', 'canonical-source-controlled-equipment-A-24H-command-Root-15-02/receipt.json', 0),
]:
    p = D / name
    cr = ref(p)
    c = json.loads(checked(cr))
    assert c['exit_code'] == exit_code and c['launch_error'] is None and c['source_bytes_match_before_and_after']
    assert c['repository_before']['head'] == c['repository_after']['head'] == app['base_HEAD']
    checked(c['stdout']); checked(c['stderr'])
    commands[label] = (cr, c)
snap = commands['test'][1]['source_snapshot']
assert all(c['source_snapshot'] == snap for _, c in commands.values())
actual = {v['historical_path']: v for v in json.loads(checked(snap))['files']}
assert set(actual) == set(rows)
for n, v in actual.items():
    b = checked(v['archive'])
    assert len(b) == v['size_bytes'] == rows[n]['final_bytes'] and v['archive']['sha256'] == rows[n]['final_sha256']
selected = dict(app['selected'])
selected.update({f['canonical_path']: f for f in fix['files']})
assert len(selected) == 16
for n, f in selected.items():
    assert (R / n).read_bytes() == checked(f['proposed']) == checked(actual[n]['archive'])
test = commands['test'][1]
assert test['command'].count('heat_balance::ordinary_equipment::tests::actual_native_get_equipment_pair_and_input_owner_transitions') == 1 and '--exact' in test['command']
assert b'running 1 test' in checked(test['stdout']) and b'test result: ok. 1 passed; 0 failed; 0 ignored;' in checked(test['stdout'])
fixture = R / 'crates/ep_runtime/src/heat_balance/fixtures/ordinary_equipment_native_selected.json'
assert fixture.read_bytes() == subprocess.check_output(['git', 'show', app['base_HEAD'] + ':' + fixture.relative_to(R).as_posix()], cwd=R)
assert ref(fixture)['sha256'] == '8fc26d9728a3d186d858f03ce3a75468610f837fefdcfadd4ca294d6eb824a2c'
assert core(commands['B'][1], False) == core(commands['A24'][1], True)
A = D / 'canonical-source-controlled-equipment-A-24H-Root-15-02/output'
B = D / 'canonical-source-controlled-equipment-B-NOLIMIT-24H-Root-15/output'
old = D / 'canonical-source-Zone-Node-A-24H-Root-14/output'
bs = json.loads((B / 'run-summary.json').read_bytes())
bd = json.loads((B / 'diagnostics.json').read_bytes())
assert bs['exit_code'] == 6 and bs['rust_runtime'] is None
errors = [v for v in bd['diagnostics'] if v['severity'] == 'error']
frontier = sys.argv[1]
assert len(errors) == 1 and errors[0]['message'] == frontier
assert 'GetZoneEquipmentData308' not in frontier
assert (B / 'results').is_dir() and not any((B / 'results').iterdir())
ar, previous14 = auth('Root-source-Zone-Node-actual-review-14/review.json', '141d461e0070e3eb5c38fa0d5585f7dd4cb58c4141f91de637bc28dfefb131a8')
assert previous14['accepted'] and previous14['original_tolerance_RMSE_5352_proof_transferred']
pr, prior = auth('Peer-canonical-B-ingress-IO-A24-transfer-03/review.json', '6bfe7736ea81fc1123ebc4ee11c64e9de64d123f3e3a92e49636f13cd9dc4dca')
assert prior['accepted']
assert ref(D / 'check-canonical-B-ingress-IO-A24-transfer-Peer-03.py')['sha256'] == '0742d4694653c9f80e93e1ebe89ed80bf14696b148e39f8477f0c67c1cb50c74'
text = source.decode()
start = text.index('whole=[]\n')
end = text.index("O.mkdir();p=O/'table-clock-differences.json'")
block = text[start:end]
assert block.count('accepted12') == 4
exec(compile(block.replace('accepted12', 'accepted14'), '<unchanged13-A24-comparison>', 'exec'))
O.mkdir()
p = O / 'table-clock-differences.json'
p.write_text(json.dumps(table_changes, indent=2) + '\n', encoding='utf8', newline='\n')
ledger = ref(p)
artifacts = [ref(A / 'results/source-reported-results.json'), ref(A / 'run-summary.json'), ref(A / 'diagnostics.json'), ref(B / 'run-summary.json'), ref(B / 'diagnostics.json'), ref(fixture)] + [v['current'] for v in whole + csv + tables] + [ledger]
result = dict(schema='src06-controlled-equipment-actual-owner-test-and-A24-transfer.v1', accepted=True, findings=[],
    application=ap, producer=app['producer'], independent_peer=app['independent_peer'],
    existing_test_caller_correction=fr, existing_test_caller_correction_peer=fpr, original_failed_test=fix['failed_test'], second_failed_test=fix['second_failed_test'],
    complete_compiler_plan=fix['complete_final_compiler_Source_plan'],
    actual_owner_test=commands['test'][0], actual_B=commands['B'][0], actual_A24=commands['A24'][0],
    same4486_archived_inputs_exact_final_plan=True, selected16_final_sources_exact=True,
    first_B_core_fresh_false=True, A24_same_core_reused_fresh_true=True,
    actual_test_bodies_executed=1, new_test_bodies=0, existing_test_fixture_separately_Git_bound=ref(fixture),
    test_qualification='Existing Native uncontrolled getter pair7 plus owner transitions and allocation/counter independence. No positive controlled-equipment Native paired state comparison or all8 fixture cases claim; included JSON fixture separately Git/byte bound.',
    B_frontier=frontier, B_runtime_or_fallback_results=False,
    B_preceding_controlled_equipment_and_wrapper_returned=True,
    accepted14_full5352_proof=ar, whole_physical_streams_equal14=whole, whole_CSV_equal14=csv,
    whole_JSON_equal14_after_exactly_two_owned_path_field_bridges=True, full_runtime_equal14_after_two_owned_path_bridges=True,
    transferred_reported_series=58, transferred_JSON_CSV_scalar_roundtrips=5352,
    full_tables=tables, table_lines=line_count, table_clock_metadata_changes=len(table_changes), table_clock_ledger=ledger,
    unchanged_original_tolerance_policy=ref(policy), original_tolerance_RMSE_5352_proof_transferred=True,
    publication_artifacts=artifacts,
    limits='Genuine finite controlled equipment input, same shared owners and wrapper return. Existing unit-test execution is limited to its represented uncontrolled Native pair and owner transitions; no positive Native paired runtime-state equivalence, new72h/annual execution, fullB or card/gate completion.',
    main_mutations=0, policy_changes=0, gate_changes=0, comparison_helper_Source=ref(parent),
    comparison_block_only_metadata_key_spelling_changed=True, author_Source=ref(Path(__file__).resolve()))
p = O / 'review.json'
p.write_text(json.dumps(result, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(ref(p)))

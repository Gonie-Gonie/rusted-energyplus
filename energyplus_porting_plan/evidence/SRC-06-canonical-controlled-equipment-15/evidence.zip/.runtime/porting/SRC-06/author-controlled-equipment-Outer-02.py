from pathlib import Path
import hashlib,json
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'source-controlled-equipment-draft-Outer-01';H='crates/ep_runtime/src/heat_balance/'
def old(n):return (D/'parent'/n).read_text(encoding='utf8')
def put(n,s):
 p=D/'proposed'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf8'))
n=H+'ordinary_equipment.rs';s=old(n)
s=s.replace('mod source_input;','mod source_input;\nmod source_equipment_types;\nmod source_equipment_getter;\nmod source_controlled_equipment;\nmod source_node_connections;')
s=s.replace('use source_node_lists::SourceNodeList;','use source_node_lists::SourceNodeList;\nuse source_equipment_types::{SourceAirIn, SourceEquipmentData, SourceSimulationOrder};\nuse super::selected_schedule_manager::SourceScheduleIndex;\npub(crate) use source_input::SourceEquipmentInputOwners;')
fields=[('control_list_name','String','String::new()'),('return_flow_fraction_schedule','Option<SourceScheduleIndex>','None'),('number_return_flow_basis_nodes','usize','0'),('flow_error','bool','false')]
for k,t in [('inlet_node_numbers','usize'),('inlet_node_air_loop_numbers','i32'),('inlet_node_air_distribution_unit_numbers','i32'),('exhaust_node_numbers','usize'),('return_node_numbers','usize'),('return_node_air_loop_numbers','i32'),('return_node_return_path_numbers','i32'),('return_node_return_path_component_numbers','i32'),('return_node_inlet_numbers','i32'),('fixed_return_flow','bool'),('return_node_plenum_numbers','i32'),('return_flow_basis_node_numbers','usize'),('return_node_exhaust_node_numbers','i32'),('shared_exhaust_nodes','i32'),('return_node_space_mixer_indices','i32'),('air_distribution_units_heat','SourceAirIn'),('air_distribution_units_cool','SourceAirIn')]:fields.append((k,'Option<Vec<'+t+'>>','None'))
for k in ['zone_exhaust','zone_exhaust_balanced','plenum_mass_flow','excess_zone_exhaust','total_available_air_loop_outdoor_air','total_inlet_air_mass_flow_rate','total_exhaust_air_mass_flow_rate','air_loop_design_supply']:fields.append((k,'f64','0.0'))
for k,t,v in [('zone_has_air_loop_with_outdoor_air_system','bool','false'),('zone_air_distribution_index','i32','0'),('zone_design_specification_outdoor_air_index','i32','0')]:fields.append((k,t,v))
anchor='struct EquipmentConfig {\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+''.join(f'    {k}: {t},\n' for k,t,v in fields))
anchor='impl Default for EquipmentConfig {\n    fn default() -> Self {\n        Self {\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+''.join(f'            {k}: {v},\n' for k,t,v in fields))
listfields=[('load_distribution_scheme','i32'),('number_available_heating_equipment','i32'),('number_available_cooling_equipment','i32'),('equipment_type_names','Option<Vec<String>>'),('equipment_types','Option<Vec<i32>>'),('equipment_names','Option<Vec<String>>'),('equipment_indices','Option<Vec<i32>>'),('equipment_splitter_indices','Option<Vec<i32>>'),('component_pointers','Vec<Option<std::convert::Infallible>>'),('equipment_data','Option<Vec<SourceEquipmentData>>'),('cooling_priorities','Option<Vec<i32>>'),('heating_priorities','Option<Vec<i32>>'),('cooling_capacities','Option<Vec<i32>>'),('heating_capacities','Option<Vec<i32>>'),('sequential_cooling_fraction_schedules','Option<Vec<Option<SourceScheduleIndex>>>'),('sequential_heating_fraction_schedules','Option<Vec<Option<SourceScheduleIndex>>>')]
s=s.replace('struct EquipmentList {\n','struct EquipmentList {\n'+''.join(f'    {k}: {t},\n' for k,t in listfields))
s=s.replace('    node_references: Option<Vec<i32>>,','    node_references: Option<Vec<i32>>,\n    only_single_node_first_time: bool,\n    only_single_node_numbers: Option<Vec<usize>>,')
s=s.replace('            node_references: None,','            node_references: None,\n            only_single_node_first_time: true,\n            only_single_node_numbers: None,')
s=s.replace('    priority_simulation_order: Option<Vec<()>>,','    priority_simulation_order: Option<Vec<SourceSimulationOrder>>,')
needle='''        if maximum_equipment_types != 0 {
            return Err(Unavailable::InconsistentOwner);
        }
        self.priority_simulation_order = Some(Vec::new());'''
assert s.count(needle)==1;s=s.replace(needle,'''        self.priority_simulation_order = Some(vec![SourceSimulationOrder::default(); maximum_equipment_types]);''')
# The old exhaustive empty-state validator remains exact on the legacy/A path.
anchor='''    ) -> Result<(), Unavailable> {
        if self.zone_ids != zones
'''
assert s.count(anchor)==1;s=s.replace(anchor,'''    ) -> Result<(), Unavailable> {
        if let Some(gains) = source_gains {
            if self.zone_config.as_ref().is_some_and(|rows| rows.iter().any(|row| row.is_controlled)) {
                return self.validate_source_controlled_equipment_storage(zones, spaces, gains);
            }
        }
        if self.zone_ids != zones
''')
put(n,s)
n=H+'selected_sizing.rs';s=old(n)
s=s.replace('//! Input DoSizing switches and calculation globals are separate borrowed owners.','//! Input DoSizing switches and calculation globals are separate borrowed owners.\nmod terminal_unit;\npub(crate) use terminal_unit::SourceTerminalUnitSizingData;')
s=s.replace('pub(crate) struct SelectedSizingManager {','pub(crate) struct SelectedSizingManager {\n    pub(crate) number_of_air_terminal_units: usize,\n    pub(crate) terminal_unit_sizing: Option<Vec<SourceTerminalUnitSizingData>>,')
s=s.replace('impl Default for SelectedSizingManager {\n    fn default() -> Self {\n        Self {','impl Default for SelectedSizingManager {\n    fn default() -> Self {\n        Self {\n            number_of_air_terminal_units: 0,\n            terminal_unit_sizing: None,')
put(n,s)
n=H+'ordinary_equipment/source_input.rs';s=old(n)
anchor='fn definition(\n';i=s.index(anchor)
s=s[:i]+'''use super::source_equipment_getter::SourceEquipmentGetterLocals;
use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneData;
use crate::heat_balance::selected_schedule_manager::SelectedScheduleManager;
use crate::heat_balance::selected_sizing::{SelectedSizingManager, SourceTerminalUnitSizingData};
use crate::heat_balance::startup_integrity::SourceBranchNodeConnections;

pub(crate) struct SourceEquipmentInputOwners<'a> {
    pub(crate) zones: &'a mut [SelectedZoneData],
    pub(crate) schedules: &'a mut SelectedScheduleManager,
    pub(crate) sizing: &'a mut SelectedSizingManager,
    pub(crate) branch: Option<&'a mut SourceBranchNodeConnections>,
    pub(crate) source_is_epjson: bool,
}

'''+s[i:]
# Only these two methods take the new actual borrowed owner bundle.
needle='''        gains: &mut SelectedInternalHeatGains,
    ) -> Result<(), Unavailable> {'''
assert s.count(needle)==2
s=s.replace(needle,'''        gains: &mut SelectedInternalHeatGains,
        mut owners: SourceEquipmentInputOwners<'_>,
    ) -> Result<(), Unavailable> {''',1)
s=s.replace(needle,'''        gains: &mut SelectedInternalHeatGains,
        owners: &mut SourceEquipmentInputOwners<'_>,
    ) -> Result<(), Unavailable> {''',1)
s=s.replace('self.get_zone_equipment_data_source(input, space_sizing, space_simulation, globals, gains)?;','self.get_zone_equipment_data_source(input, space_sizing, space_simulation, globals, gains, &mut owners)?;')
s=s.replace('let _node_numbers = vec![0_i32;', 'let mut node_numbers = vec![0_usize;')
local='''        let alpha_args = vec![String::new(); max_alphas];
        let numeric_args = vec![0.0_f64; max_numbers];
        let alpha_names = vec![String::new(); max_alphas];
        let numeric_names = vec![String::new(); max_numbers];
        let alpha_blanks = vec![true; max_alphas];
        let numeric_blanks = vec![true; max_numbers];'''
assert s.count(local)==1;s=s.replace(local,'''        let mut locals = SourceEquipmentGetterLocals {
            alphas: vec![String::new(); max_alphas],
            numbers: vec![0.0_f64; max_numbers],
            alpha_names: vec![String::new(); max_alphas],
            numeric_names: vec![String::new(); max_numbers],
            alpha_blanks: vec![true; max_alphas],
            numeric_blanks: vec![true; max_numbers],
        };''')
start=s.index('        let _overall_equipment_count = 0_i32;');end=s.index('        let configs = self',start)
s=s[:start]+'''        let mut overall_equipment_count = 0_usize;
        let mut local_terminal_unit_sizing_counter = 0_usize;
        for _controlled_zone in 0..controlled_zones {
            locals.get_connections(input, owners.source_is_epjson)?;
            let zone = owners.zones.iter().position(|zone| zone.name == locals.alphas[0])
                .ok_or_else(|| Unavailable::Input("actual controlled Zone name-not-found severe diagnostic".into()))?;
            if owners.zones[zone].is_controlled {
                return Err(Unavailable::Input("actual duplicate controlled Zone severe diagnostic".into()));
            }
            owners.zones[zone].is_controlled = true;
            self.process_source_zone_equipment_input(zone, input,
                owners.branch.as_deref_mut().ok_or_else(|| Unavailable::Input("actual existing BranchNodeConnections owner required".into()))?,
                owners.schedules, &locals, &mut node_numbers,
                &mut local_terminal_unit_sizing_counter, &mut overall_equipment_count)?;
            owners.zones[zone].system_zone_node_number = i32::try_from(
                self.zone_config.as_ref().and_then(|rows| rows.get(zone)).ok_or(Unavailable::InconsistentOwner)?.zone_node
            ).map_err(|_| Unavailable::InconsistentOwner)?;
        }
        if controlled_spaces > 0 {
            return Err(Unavailable::Input("actual controlled-space ignored-input warning or positive getter".into()));
        }
        // Space sizing/simulation was bounded at its earlier actual allocation.
        if local_terminal_unit_sizing_counter > 0 {
            owners.sizing.number_of_air_terminal_units = local_terminal_unit_sizing_counter;
            owners.sizing.terminal_unit_sizing = Some(vec![SourceTerminalUnitSizingData::default(); local_terminal_unit_sizing_counter]);
            for (zone, config) in self.zone_config.as_ref().ok_or(Unavailable::InconsistentOwner)?.iter().enumerate() {
                for number in 0..config.inlet_nodes {
                    let terminal = config.air_distribution_units_cool.as_ref().and_then(|rows| rows.get(number))
                        .map(|row| row.terminal_unit_sizing_index).and_then(|n| n.checked_sub(1)).ok_or(Unavailable::InconsistentOwner)?;
                    owners.sizing.terminal_unit_sizing.as_mut().and_then(|rows| rows.get_mut(terminal))
                        .ok_or(Unavailable::InconsistentOwner)?.controlled_zone_number = i32::try_from(zone + 1).map_err(|_| Unavailable::InconsistentOwner)?;
                }
            }
        }
        if self.equipment_data_errors_found {
            return Err(Unavailable::Input("actual duplicate-items-not-checked warning diagnostic".into()));
        }
        if overall_equipment_count > 0 {
            // Native ObjectType is std::string (initially empty), assigned
            // the unscoped ZoneEquipType through operator=(char), not a type name.
            let mut audit = vec![(String::new(), String::new(), 0usize); overall_equipment_count];
            overall_equipment_count = 0;
            for zone in 0..controlled_zones {
                let list = self.equipment_lists.as_ref().and_then(|rows| rows.get(zone)).ok_or(Unavailable::InconsistentOwner)?;
                for number in 0..list.number_of_equipment_types {
                    let row = audit.get_mut(overall_equipment_count).ok_or(Unavailable::InconsistentOwner)?;
                    overall_equipment_count += 1;
                    let kind = *list.equipment_types.as_ref().and_then(|rows| rows.get(number)).ok_or(Unavailable::InconsistentOwner)?;
                    let character = u8::try_from(kind).ok().filter(u8::is_ascii).ok_or(Unavailable::InconsistentOwner)?;
                    row.0 = char::from(character).to_string();
                    row.1 = list.equipment_names.as_ref().and_then(|rows| rows.get(number)).ok_or(Unavailable::InconsistentOwner)?.clone();
                    row.2 = zone + 1;
                }
            }
            for first in 0..overall_equipment_count {
                for other in first + 1..overall_equipment_count {
                    if audit[first].0 != audit[other].0 || audit[first].1 != audit[other].1 { continue; }
                    return Err(Unavailable::Input("actual duplicate equipment-list item severe diagnostic".into()));
                }
            }
            drop(audit);
        }
'''+s[end:]
for oldname,newname in [('alpha_args','alphas'),('numeric_args','numbers'),('alpha_names','alpha_names'),('numeric_names','numeric_names'),('alpha_blanks','alpha_blanks'),('numeric_blanks','numeric_blanks')]:
 s=s.replace('drop('+oldname+');','drop(locals.'+newname+');')
put(n,s)
n=H+'ctf_initialization_context/setup_zone_geometry.rs';s=old(n)
s=s.replace('OrdinaryEquipment, OrdinaryEquipmentInput, OrdinaryEquipmentUnavailable,','OrdinaryEquipment, OrdinaryEquipmentInput, OrdinaryEquipmentUnavailable, SourceEquipmentInputOwners,')
needle='''        host: &mut dyn crate::heat_balance::source_output_registration::SourceOutputFileHost,
    ) -> Result<Vec<crate::geometry::InitializedZoneGeometry>, RuntimeError> {'''
assert s.count(needle)==1;s=s.replace(needle,'''        host: &mut dyn crate::heat_balance::source_output_registration::SourceOutputFileHost,
        branch: Option<&mut crate::heat_balance::startup_integrity::SourceBranchNodeConnections>,
    ) -> Result<Vec<crate::geometry::InitializedZoneGeometry>, RuntimeError> {''')
needle='''                &mut reports.selected_internal_heat_gains,
            )'''
assert s.count(needle)==1;s=s.replace(needle,'''                &mut reports.selected_internal_heat_gains,
                SourceEquipmentInputOwners {
                    zones: reports.selected_zone_input.as_mut()
                        .and_then(|state| state.zones.as_deref_mut())
                        .ok_or_else(|| hb_input_error(E::Unavailable("same actual mutable equipment Zone rows")))?,
                    schedules: reports.selected_schedule_manager.as_mut()
                        .ok_or_else(|| hb_input_error(E::Unavailable("same equipment ScheduleManager owner")))?,
                    sizing: &mut reports.selected_sizing_manager,
                    branch,
                    source_is_epjson: reports.heat_balance_input.as_ref()
                        .ok_or_else(|| hb_input_error(E::Unavailable("actual equipment input format custody")))?.source_is_epjson,
                },
            )''')
put(n,s)
n=H+'ctf_initialization_context/source_heat_balance_input.rs';s=old(n)
needle='''        radiation_input: OrdinaryRadiationInput,
    ) -> Result<(), RuntimeError> {''';assert s.count(needle)==1;s=s.replace(needle,'''        radiation_input: OrdinaryRadiationInput,
        branch: &mut crate::heat_balance::startup_integrity::SourceBranchNodeConnections,
    ) -> Result<(), RuntimeError> {''')
needle='''            output_host,
        )?;''';assert s.count(needle)==1;s=s.replace(needle,'''            output_host,
            Some(branch),
        )?;''')
put(n,s)
n=H+'ordinary_source_session/first_input.rs';s=old(n)
needle='''                self.equipment_input,
                self.radiation_input,
            )''';assert s.count(needle)==1;s=s.replace(needle,'''                self.equipment_input,
                self.radiation_input,
                &mut self.session.hvac.ancillary.branch_node_connections,
            )''')
put(n,s)
n=H+'initialization.rs';s=old(n)
needle='''            selected_world_zone_returns = actual.continue_selected_setup_zone_geometry(
                &model.typed,
                equipment_input,
                source.environment,
                source.minutes,
                &mut *source.output_host,
            )?;''';assert s.count(needle)==1;s=s.replace(needle,needle.replace('                &mut *source.output_host,\n','                &mut *source.output_host,\n                None,\n'))
put(n,s)
helper=B/'source-Node-getters-registration-helper-held-Peer-01/manifest.json'
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='c3b3d39b5d4cd2e925a06597c32fec68fc580d495d6ceef58ea747c3c43adc7b'
for row in json.loads(helper.read_bytes())['files']:
 name=row['canonical_path'];p=R/row['proposed']['path'];z=p.read_bytes();assert hashlib.sha256(z).hexdigest()==row['proposed']['sha256']
 q=D/'proposed'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z)
print('Prepared retained equipment/config/list/priority and sizing constructors only; main unchanged')

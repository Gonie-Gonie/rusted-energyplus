"""Root-only finite checkpoint15 publisher; focused existing test plus realCLI.

No workspace check is required here. Root owns full compiler snapshot proof;
the publisher reads complete plan metadata and the sixteen selected raw Sources.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import zipfile

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
READY = D / 'controlled-equipment-publication-prepared-Audit-15'
PUBLIC = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-controlled-equipment-15'
BACK = D / 'controlled-equipment-publication-readback-Audit-15'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path):
    path = path.resolve()
    return dict(path=path.relative_to(R).as_posix(), sha256=digest(path), bytes=path.stat().st_size)


def checked(row):
    path = (R / row['path']).resolve()
    path.relative_to(R)
    assert digest(path) == row['sha256']
    assert path.stat().st_size == row.get('bytes', row.get('size_bytes', path.stat().st_size))
    return path


def load(path):
    return json.loads(path.read_bytes())


def accepted(path):
    value = load(path)
    assert value.get('accepted') is True and not value.get('findings')
    return value


def contains(value, row):
    if isinstance(value, dict):
        return (value.get('path'), value.get('sha256')) == (row['path'], row['sha256']) or any(contains(v, row) for v in value.values())
    return isinstance(value, list) and any(contains(v, row) for v in value)


def main(args):
    assert args.publish and not PUBLIC.exists() and not BACK.exists()
    template_path = READY / 'publication-template.json'
    draft = load(template_path)
    assert draft['status'] == 'HELD_READY_FOR_ROOT_REVIEW'
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
    assert head == draft['base_HEAD'] == 'b68a0060d750eac9c074adb0f8de5635f6e8039c'
    producer = load(checked(draft['producer']))
    accepted(checked(draft['independent_peer']))
    caller_fix = load(checked(draft['caller_fix']))
    accepted(checked(draft['caller_fix_peer']))
    plan = load(checked(draft['complete_plan']))
    assert plan['inputs'] == 4486 and plan['Rust_sources'] == 4473
    selected = {row['canonical_path']: row for row in producer['files']}
    assert len(selected) == 15
    selected.update({row['canonical_path']: row for row in caller_fix['files']})
    assert len(selected) == 16 and sum(row['before_absent'] for row in selected.values()) == 6
    fixture = checked(draft['existing_test_JSON_fixture'])
    assert fixture.read_bytes() == subprocess.check_output(['git', 'show', head + ':' + draft['existing_test_JSON_fixture']['path']], cwd=R)
    validation_path = (R / args.validation_refs).resolve()
    validation_path.relative_to(R)
    v = load(validation_path)
    assert set(v) == {'Root_actual_review', 'test', 'B_CLI', 'A24_CLI', 'B_summary', 'B_diagnostics', 'A24_summary', 'A24_diagnostics'}
    review_path = checked(v['Root_actual_review'])
    actual = accepted(review_path)
    assert ref(review_path) == draft['actual_review']
    # These are the already-accepted aggregate predicates, not another checker.
    for key in draft['required_true_actual_predicates']:
        assert actual[key] is True, key
    assert actual['actual_test_bodies_executed'] == 1 and actual['new_test_bodies'] == 0
    assert actual['existing_test_fixture_separately_Git_bound'] == draft['existing_test_JSON_fixture']
    assert actual['B_runtime_or_fallback_results'] is False
    assert actual['transferred_reported_series'] == 58 and actual['transferred_JSON_CSV_scalar_roundtrips'] == 5352
    assert actual['policy_changes'] == actual['gate_changes'] == 0
    for row in [draft['producer'], draft['independent_peer'], draft['caller_fix'], draft['caller_fix_peer'], draft['complete_plan']] + [v[key] for key in ['test', 'B_CLI', 'A24_CLI']]:
        assert contains(actual, row), row['path']
    receipts = [load(checked(v[key])) for key in ['test', 'B_CLI', 'A24_CLI']]
    assert [run['exit_code'] for run in receipts] == [0, 6, 0]
    for run in receipts:
        assert run['launch_error'] is None and run['source_bytes_match_before_and_after'] is True
        assert Path(run['cwd']).resolve() == R
    assert all(run['source_snapshot'] == receipts[0]['source_snapshot'] for run in receipts)
    test_name = 'actual_native_get_equipment_pair_and_input_owner_transitions'
    assert 'test' in receipts[0]['command'] and any(test_name in arg for arg in receipts[0]['command'])
    assert 'test result: ok. 1 passed; 0 failed;' in checked(receipts[0]['stdout']).read_text(encoding='utf-8')
    for run, scope in zip(receipts[1:], ['B', 'A']):
        command = run['command']
        assert command[command.index('--porting-scope') + 1] == scope
        assert not {'--oracle-baseline', '--compare-oracle'} & set(command)
    bs, bd = load(checked(v['B_summary'])), load(checked(v['B_diagnostics']))
    asum, ad = load(checked(v['A24_summary'])), load(checked(v['A24_diagnostics']))
    errors = [row['message'] for row in bd['diagnostics'] if row['code'] == 'RuntimeConvergenceFailure']
    assert bs['exit_code'] == 6 and bs['rust_runtime'] is None
    assert errors == [draft['actual_B_frontier']]
    assert asum['exit_code'] == 0 and asum['rust_runtime'] is not None
    assert not any(row['code'] == 'RuntimeConvergenceFailure' for row in ad['diagnostics'])
    snapshot = load(checked(receipts[0]['source_snapshot']))
    observed = {row['historical_path']: row for row in snapshot['files']}
    index = {row['path']: row for row in plan['entries']}
    assert len(index) == len(observed) == 4486 and set(index) == set(observed)
    for name, row in index.items():
        assert (row['final_sha256'], row['final_bytes']) == (observed[name]['archive']['sha256'], observed[name]['size_bytes'])
    for name, row in selected.items():
        current = R / name
        assert current.read_bytes() == checked(row['proposed']).read_bytes() == checked(observed[name]['archive']).read_bytes()
        assert (digest(current), current.stat().st_size) == (index[name]['final_sha256'], index[name]['final_bytes'])
    base = R / 'energyplus_porting_plan'
    names = ['CHECKLIST.md', 'STATE_CONTRACTS.md', 'cards/SRC-06.md']
    docs = {name: (base / name).read_bytes() for name in names}
    plan_path = base / 'plan.json'
    before = plan_path.read_bytes()
    before_value = json.loads(before)
    for name, raw in docs.items():
        assert raw == subprocess.check_output(['git', 'show', head + ':energyplus_porting_plan/' + name], cwd=R)
        assert '\ufffd' not in raw.decode('utf-8', 'strict')
    assert before == subprocess.check_output(['git', 'show', head + ':energyplus_porting_plan/plan.json'], cwd=R)
    previous = load(checked(draft['previous_checkpoint']))
    assert (previous['A'], previous['B']) == ('14/54', '14/64')
    files = {}

    def add(path):
        path = path.resolve()
        row = ref(path)
        assert path.suffix.lower() != '.zip'
        assert row['path'] not in files or files[row['path']]['ref'] == row
        files[row['path']] = dict(path=path, ref=row)

    for row in draft['finite_archive_inputs']:
        add(checked(row))
    for path in [Path(__file__), template_path, validation_path, review_path]:
        add(path)
    for row in v.values():
        add(checked(row))
    for run in receipts:
        for key in ['stdout', 'stderr', 'source_snapshot']:
            add(checked(run[key]))
    for row in actual['publication_artifacts']:
        add(checked(row))
    for name in selected:
        add(R / name)
    PUBLIC.mkdir(parents=True)
    BACK.mkdir()
    (BACK / 'plan-before.json').write_bytes(before)
    for name, raw in docs.items():
        target = BACK / 'docs-before' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    archive = PUBLIC / 'evidence.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for name, item in sorted(files.items()):
            assert ref(item['path']) == item['ref']
            stream.write(item['path'], arcname=name)
    with zipfile.ZipFile(archive) as stream:
        assert stream.testzip() is None and set(stream.namelist()) == set(files)
        for name, item in files.items():
            assert hashlib.sha256(stream.read(name)).hexdigest() == item['ref']['sha256']
    inventory = PUBLIC / 'manifest.json'
    inventory.write_text(json.dumps(dict(schema='src06-canonical15-finite-evidence-archive.v1', archive=ref(archive), entries=[item['ref'] for name, item in sorted(files.items())], scope='Corrected controlled-equipment Source02 and existing test-caller compiler adapter, direct resolved-constructor/failed101 custody, accepted peers/final16Source plan and focused existing test/actual B+A24. Included JSON fixture is separately Git bound. No historical ZIP recursion, new Native dataset or annualJSON/CSV.', full_transitive_rebuild_archive_claim=False), indent=2) + '\n', encoding='utf-8', newline='\n')
    summary = dict(draft['summary_template'])
    summary.update(schema='src06-canonical-controlled-equipment.v1', status='Genuine controlled-equipment input; B remains incomplete at the exact actual frontier', canonical_existing_owner_test=v['test'], canonical_B_CLI=v['B_CLI'], canonical_A24_CLI=v['A24_CLI'], Root_actual_review=ref(review_path), actual_B_incomplete_boundary=errors[0], actual_B_completed=False, canonical_A24_completed_Source_run=True, accepted_A24_proof_transfer=draft['actual_A24_proof_transfer'], preceding_B_returns=draft['actual_preceding_B_returns'], validation_refs=ref(validation_path), archive=ref(archive), archive_manifest=ref(inventory), archive_entries=len(files), publisher_Source=ref(Path(__file__)))
    summary_path = PUBLIC / 'summary.json'
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    relative = 'evidence/SRC-06-canonical-controlled-equipment-15/summary.json'
    for name, raw in docs.items():
        target = base / name
        assert target.read_bytes() == raw
        link = '../' + relative if name.startswith('cards/') else relative
        append = '\n\n[Source 제어장비 입력 검증](' + link + '). ' + draft['doc_appends'][name] + '\n'
        assert '\ufffd' not in append
        target.write_bytes(raw + append.encode('utf-8'))
    after = json.loads(before)
    task = next(row for row in after['tasks'] if row['id'] == 'SRC-06')
    key = 'canonical_controlled_equipment_15'
    assert key not in task
    task[key] = dict(path=summary_path.relative_to(R).as_posix(), sha256=digest(summary_path), size_bytes=summary_path.stat().st_size)
    inverse = json.loads(json.dumps(after))
    del next(row for row in inverse['tasks'] if row['id'] == 'SRC-06')[key]
    assert inverse == before_value and plan_path.read_bytes() == before
    plan_path.write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    result = dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK', summary=ref(summary_path), archive=ref(archive), archive_manifest=ref(inventory), archive_entries=len(files), base_HEAD=head, publisher=ref(Path(__file__)), plan_before=ref(BACK / 'plan-before.json'), Git_mutated=False, Cargo_tests_Native_executed=False, gate_changes=False)
    readback = BACK / 'publication-readback.json'
    readback.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(ref(readback)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--validation-refs', required=True)
    parser.add_argument('--publish', action='store_true')
    main(parser.parse_args())

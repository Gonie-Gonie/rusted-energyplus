from pathlib import Path
import ast, hashlib, json, re, subprocess, sys

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'Root-controlled-equipment-application-15'
assert not O.exists()

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def checked(v):
    p = (R / v['path']).resolve()
    assert p.is_relative_to(R)
    b = p.read_bytes()
    assert hashlib.sha256(b).hexdigest() == v['sha256'] and len(b) == v.get('bytes', len(b)), v['path']
    return b

def auth(p, sha):
    p = (R / p).resolve()
    v = ref(p)
    assert v['sha256'] == sha
    return v, json.loads(checked(v))

mr, m = auth(sys.argv[1], sys.argv[2])
pr, peer = auth(sys.argv[3], sys.argv[4])
assert (peer.get('accepted') is True or peer.get('status') == 'accepted') and not peer['findings']
assert mr in [v for v in peer.values() if isinstance(v, dict)], 'Peer must bind the exact complete producer'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert head == m['base_HEAD'] == 'b68a0060d750eac9c074adb0f8de5635f6e8039c'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=R) == b''
assert m['new_test_bodies'] == 0 and not m['FP_or_tolerance_changes'] and not m['Cargo_Native_or_tests_executed']
parent = json.loads(checked(m['actual_parent_snapshot']))
parents = {v['historical_path']: v for v in parent['files']}
inventory = {p.relative_to(R).as_posix() for p in (R / 'crates').rglob('*.rs')} | {p.relative_to(R).as_posix() for p in (R / 'crates').rglob('Cargo.toml')} | {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml'}
assert len(inventory) == 4480 and set(parents) == inventory
for n, v in parents.items():
    assert (R / n).read_bytes() == checked(v['archive']) and (R / n).stat().st_size == v['size_bytes'], n
tree = ast.parse((D / 'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'))
exec(compile(ast.Module(body=[next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'apply')], type_ignores=[]), '<literal-apply>', 'exec'))
selected = {}
new = set()
newtests = 0
for f in m['files']:
    n = f['canonical_path']
    assert n not in selected
    before, after = checked(f['before']), checked(f['proposed'])
    assert checked(f['literal_inverse']) == before
    assert apply(before, checked(f['forward_diff'])) == after and apply(after, checked(f['inverse_diff'])) == before
    if f['before_absent']:
        assert not (R / n).exists() and before == b''
        new.add(n)
    else:
        assert before == (R / n).read_bytes() == subprocess.check_output(['git', 'show', head + ':' + n], cwd=R) == checked(parents[n]['archive'])
        assert (R / n).stat().st_nlink == 1
    assert f['Source_only_parse']['exit_code'] == 0
    checked(f['Source_only_parse']['stdout']); checked(f['Source_only_parse']['stderr'])
    newtests += after.count(b'#[test]') - before.count(b'#[test]')
    selected[n] = f
assert len(selected) == 15 and len(new) == 6 and newtests == 0
native = R / '.reference/energyplus-src/26.1.0'
revision = '6f2e40d10250a105b49966baa24d843711e61048'
for v in m['Native_wholes']:
    assert checked(v['whole_source']) == subprocess.check_output(['git', 'show', revision + ':' + v['Native_path']], cwd=native)
for v in m['Native_literal_extents']:
    assert b''.join(checked(v['whole_source']).splitlines(keepends=True)[v['first_line']-1:v['last_line']]) == checked(v['literal_excerpt'])
checked(m['constructor_records']); checked(m['integration_contract']); checked(m['actual14_B_receipt']); checked(m['actual14_frontier'])
plan = json.loads(checked(m['complete_final_compiler_Source_plan']))
rows = {v['path']: v for v in plan['entries']}
assert set(rows) == inventory | new and len(rows) == 4486 and sum(n.endswith('.rs') for n in rows) == 4473
for n, v in rows.items():
    b = checked(v['source'])
    assert len(b) == v['final_bytes'] and hashlib.sha256(b).hexdigest() == v['final_sha256']
    assert b == (checked(selected[n]['proposed']) if n in selected else (R / n).read_bytes()), n
O.mkdir()
# All mutation authorization and independent Source review precede this loop.
for n, f in selected.items():
    p = R / n
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(checked(f['proposed']))
for n, v in rows.items():
    assert (R / n).read_bytes() == checked(v['source']), n
receipt = dict(accepted=True, findings=[], base_HEAD=head, producer=mr, independent_peer=pr,
    complete_compiler_plan=m['complete_final_compiler_Source_plan'], selected=selected,
    original_parent_inputs=4480, final_inputs=4486, final_Rust_sources=4473,
    selected_Rust=15, new_Rust=6, literal_applications=30, new_test_bodies=0,
    all_parent_archive_live_equal=True, selected_existing_Git_whole_equal=True,
    all_final_plan_inputs_readback_exact=True, Cargo_Native_or_tests_executed=False,
    semantic_review='Root read controlled getter, whole finite process, constructors, parent and caller diffs. Same retained IP/Schedule/Zone/Node/Branch/Sizing state; actual getter defaults, explicit bounded ordinal, genuine wrapper return and read-only structural validator. Independent peer corrections required before mutation.',
    author_Source=ref(Path(__file__).resolve()))
p = O / 'receipt.json'
p.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(ref(p)))

"""Prepare ignored HELD publication materials after Root's accepted actuals."""
from pathlib import Path
import argparse
import ast
import hashlib
import json

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
READY = D / 'controlled-equipment-publication-prepared-Audit-15'


def ref(path):
    path = path.resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def main(args):
    assert not READY.exists()
    inputs = {}

    def add(path):
        row = ref(path)
        assert Path(path).suffix.lower() != '.zip'
        inputs[row['path']] = row
        return row

    def addref(row):
        observed = add(R / row['path'])
        assert observed['sha256'] == row['sha256']
        assert observed['bytes'] == row.get('bytes', row.get('size_bytes', observed['bytes']))
        return row

    producer_path = D / 'source-controlled-equipment-held-Outer-02/manifest.json'
    producer_ref = add(producer_path)
    assert producer_ref['sha256'] == '87bdcb7505fd0ed31329facc1f5c87359a496752089bd29083cb67086d9791c2'
    producer = json.loads(producer_path.read_bytes())
    peer_path = D / 'Audit-controlled-equipment-coherent-Source-review-01/review.json'
    peer_ref = add(peer_path)
    assert peer_ref['sha256'] == 'c265619551ea04086d1fe948220dd6afc88bd1adbac7922b9746f26f4983c97e'
    peer = json.loads(peer_path.read_bytes())
    assert peer['accepted'] is True and not peer['findings']
    addref(peer['reviewer_Source'])
    addref(peer['accepted_helper_peer'])
    addref(peer['supplemental_actual_value_writer_extent'])
    addref(producer['complete_final_compiler_Source_plan'])
    fix_path = D / 'source-controlled-equipment-test-caller-fix-held-Root-15-02/manifest.json'
    fix_ref = add(fix_path)
    assert fix_ref['sha256'] == '1232244c042f74cb09bafdfef09bcd0eee17be194bf3748098a765322e13fd2b'
    fix = json.loads(fix_path.read_bytes())
    fix_peer_path = D / 'Audit-controlled-equipment-test-flag-fix-Source-review-15/review.json'
    fix_peer_ref = add(fix_peer_path)
    assert fix_peer_ref['sha256'] == '33c074aaf4bec7ea7dd084a4458f2a999b75d2727d306cf3d6c28d86dfbfd838'
    fix_peer = json.loads(fix_peer_path.read_bytes())
    assert fix_peer['accepted'] is True and not fix_peer['findings']
    addref(fix_peer['reviewer_Source'])
    addref(fix_peer['superseded_incorrect_peer'])
    for key in ['complete_final_compiler_Source_plan', 'author_Source', 'failed_test', 'second_failed_test', 'supersedes']:
        addref(fix[key])
    for failed_key in ['failed_test', 'second_failed_test']:
        failed = json.loads((R / fix[failed_key]['path']).read_bytes())
        for key in ['stdout', 'stderr', 'source_snapshot']:
            addref(failed[key])
    for row in fix['files']:
        for key in ['before', 'proposed', 'forward_diff', 'inverse_diff', 'correction_forward', 'correction_inverse']:
            addref(row[key])
    superseded = json.loads((R / fix['supersedes']['path']).read_bytes())
    addref(superseded['files'][0]['proposed'])
    plan = json.loads((R / fix['complete_final_compiler_Source_plan']['path']).read_bytes())
    assert plan['inputs'] == 4486 and plan['Rust_sources'] == 4473
    for key in ['author_Source', 'sealer_Source', 'constructor_records', 'integration_contract', 'supersedes', 'correction_proof', 'exact_Node_Branch_helper_join']:
        addref(producer[key])
    for row in producer['files']:
        for key in ['before', 'proposed', 'forward_diff', 'inverse_diff']:
            addref(row[key])
    corrections = json.loads((R / producer['correction_proof']['path']).read_bytes())
    for row in corrections['changes']:
        for key in ['Source01', 'Source02', 'forward', 'inverse']:
            addref(row[key])
    for row in producer['Native_literal_extents']:
        addref(row['literal_excerpt'])
    application_path = D / 'Root-controlled-equipment-application-15/receipt.json'
    application_ref = add(application_path)
    assert application_ref['sha256'] == '1135682dd90244e0adecf7edffaf329259d2f09b6487ef019de1329b06731db6'
    application = json.loads(application_path.read_bytes())
    assert application['accepted'] is True and not application['findings']
    addref(application['author_Source'])
    fixture = add(R / 'crates/ep_runtime/src/heat_balance/fixtures/ordinary_equipment_native_selected.json')
    previous = add(R / 'energyplus_porting_plan/evidence/SRC-06-canonical-Zone-Node-14/summary.json')
    publisher_path = D / 'publish-controlled-equipment-checkpoint-Audit-15-template.py'
    ast.parse(publisher_path.read_text(encoding='utf-8'))
    publisher = add(publisher_path)
    author = add(Path(__file__))
    actual_path = D / 'Root-source-controlled-equipment-actual-review-15/review.json'
    actual_ref = add(actual_path)
    assert actual_ref['sha256'] == args.actual_sha
    actual = json.loads(actual_path.read_bytes())
    assert actual['accepted'] is True and not actual['findings']
    addref(actual['author_Source'])
    addref(actual['accepted14_full5352_proof'])
    addref(actual['unchanged_original_tolerance_policy'])
    addref(actual['comparison_helper_Source'])
    failed_a_path = D / 'canonical-source-controlled-equipment-A-24H-command-Root-15/receipt.json'
    failed_a_ref = add(failed_a_path)
    failed_a = json.loads(failed_a_path.read_bytes())
    assert failed_a['exit_code'] != 0 and failed_a['source_bytes_match_before_and_after'] is True
    for key in ['stdout', 'stderr', 'source_snapshot']:
        addref(failed_a[key])
    validation = dict(Root_actual_review=actual_ref, test=actual['actual_owner_test'], B_CLI=actual['actual_B'], A24_CLI=actual['actual_A24'])
    for label, run in [('B', 'canonical-source-controlled-equipment-B-NOLIMIT-24H-Root-15'), ('A24', 'canonical-source-controlled-equipment-A-24H-Root-15-02')]:
        for suffix, name in [('summary', 'run-summary.json'), ('diagnostics', 'diagnostics.json')]:
            row = ref(D / run / 'output' / name)
            assert row in actual['publication_artifacts']
            validation[label + '_' + suffix] = row
    required = ['same4486_archived_inputs_exact_final_plan', 'selected16_final_sources_exact', 'first_B_core_fresh_false', 'A24_same_core_reused_fresh_true', 'B_preceding_controlled_equipment_and_wrapper_returned', 'original_tolerance_RMSE_5352_proof_transferred', 'whole_JSON_equal14_after_exactly_two_owned_path_field_bridges', 'full_runtime_equal14_after_two_owned_path_bridges']
    assert all(actual[key] is True for key in required)
    transfer = dict(series=58, samples=5352, unchanged_policy=actual['unchanged_original_tolerance_policy'], accepted14_proof=actual['accepted14_full5352_proof'], physical_files_whole_equal14=len(actual['whole_physical_streams_equal14']), CSV_files_whole_equal14=len(actual['whole_CSV_equal14']), table_lines=actual['table_lines'], clock_only_line_changes_versus14=actual['table_clock_metadata_changes'], scope='Transfer from accepted14 reported output evidence; no new Native/72h/annual run or internal-state equivalence claim.')
    assert transfer['physical_files_whole_equal14'] == 7 and transfer['CSV_files_whole_equal14'] == 2 and transfer['table_lines'] == 19312
    READY.mkdir()
    validation_path = READY / 'validation-refs.json'
    validation_path.write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8', newline='\n')
    template = dict(
        schema='src06-held-canonical15-publication-template.v1', status='HELD_READY_FOR_ROOT_REVIEW',
        base_HEAD=producer['base_HEAD'], producer=producer_ref, independent_peer=peer_ref,
        caller_fix=fix_ref, caller_fix_peer=fix_peer_ref,
        complete_plan=fix['complete_final_compiler_Source_plan'], application=application_ref,
        existing_test_JSON_fixture=fixture, previous_checkpoint=previous, publisher_Source=publisher,
        actual_review=actual_ref, required_true_actual_predicates=required,
        actual_B_frontier=actual['B_frontier'], actual_A24_proof_transfer=transfer,
        actual_preceding_B_returns=dict(controlled_equipment_and_wrapper=actual['B_preceding_controlled_equipment_and_wrapper_returned']),
        retained_failed_A_weather_path_command=failed_a_ref,
        summary_template=dict(A='14/54', B='14/64', changed_Rust_sources=16, production_Rust_sources=15, adapted_existing_test_files=1, new_Rust_sources=6, new_test_functions=0, existing_test='actual_native_get_equipment_pair_and_input_owner_transitions', test_scope='One existing Native uncontrolled pair7 and real input/owner transitions; not positive controlled-equipment Native paired validation or all8 fixture cases.', existing_included_JSON_fixture=fixture, fixture_snapshot_scope='Existing recorder captures rs/Cargo only. Tracked included JSON is separately Git/current bound and directly archived; no recorder change.', producer=producer_ref, independent_peer=peer_ref, existing_test_caller_fix=fix_ref, caller_fix_peer=fix_peer_ref, retained_failed_tests=[fix['failed_test'], fix['second_failed_test']], superseded_caller_peer=fix_peer['superseded_incorrect_peer'], corrected_caller_scope=fix['semantic_scope'], retained_failed_A_weather_path_command=failed_a_ref, failed_A_scope='Manual weather-path typo, retained as unsuccessful CLI invocation rather than a Source runtime failure; successful corrected A suffix02 is authoritative.', complete_compiler_plan=fix['complete_final_compiler_Source_plan'], focused_validation_policy='One meaningful existing runtime test build and realCLI B/A24; no new tests or habitual duplicate workspace-all-targets check.', scope='Genuine retained single-Zone IdealLoads equipment input with same real mutable Zone/Schedule/Sizing/Node/Branch owners, exact field/value/constructor order and typed positive boundaries.', full_B_or_finite15_completion_claim=False, gate_changes=False),
        doc_appends={
            'CHECKLIST.md': '제어장비 입력을 연결하고 기존 소유권 테스트와 A-24H 회귀를 통과했습니다. B는 다음 실제 미포팅 경계에서 중단하며 A14/54·B14/64 게이트는 유지합니다.',
            'STATE_CONTRACTS.md': '제어장비 입력은 기존 Zone·Schedule·Sizing·Node·Branch 소유자를 직접 갱신합니다. AirIn의 실제 terminal index 초기값 0과 미초기화 outlet index를 구별하고, 생성자·배열 할당·호출 순서를 보존합니다.',
            'cards/SRC-06.md': '단일 Zone의 IdealLoads 장비 연결·목록·노드·terminal sizing 입력을 같은 실제 소유자에 연결했습니다. 기존 Native 비제어 입력 1쌍(pair7)·소유권 전이 테스트와 A-24H 회귀를 통과하고 보고값 5,352개의 기존 검증을 유지했습니다. B의 실제 미완료 경계는 `' + actual['B_frontier'] + '`입니다. 제어장비 내부 상태의 Native 대조와 후속 B 경로는 남아 있으며 게이트는 A14/54·B14/64를 유지합니다.'
        },
        targets=['energyplus_porting_plan/evidence/SRC-06-canonical-controlled-equipment-15/' + name for name in ['summary.json', 'manifest.json', 'evidence.zip']],
        append_existing_docs=['energyplus_porting_plan/CHECKLIST.md', 'energyplus_porting_plan/STATE_CONTRACTS.md', 'energyplus_porting_plan/cards/SRC-06.md'],
        plan_add_only='SRC-06.canonical_controlled_equipment_15',
        finite_archive_inputs=[row for name, row in sorted(inputs.items())],
        finite_archive_input_count=len(inputs), finite_archive_input_bytes=sum(row['bytes'] for row in inputs.values()),
        author_Source=author, publisher_executed=False, canonical_docs_mutations=False,
        Cargo_tests_Native_executed=False, gate_changes=False,
    )
    target = READY / 'publication-template.json'
    target.write_text(json.dumps(template, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(template=ref(target), publisher=publisher, validation=ref(validation_path), archive_input_count=len(inputs), archive_input_bytes=template['finite_archive_input_bytes'])))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--actual-sha', required=True)
    main(parser.parse_args())

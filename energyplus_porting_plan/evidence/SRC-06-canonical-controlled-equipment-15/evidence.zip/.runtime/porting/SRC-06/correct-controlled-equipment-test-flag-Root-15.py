from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-controlled-equipment-test-caller-fix-held-Root-15-02';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 b=(R/v['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
oldref=ref(D/'source-controlled-equipment-test-caller-fix-held-Root-15/manifest.json');assert oldref['sha256']=='e794a5da5d05acbbabb5b284260df5069d225f076cfa70818a5f762859a3c2ee';old=json.loads(checked(oldref));f=old['files'][0];n=f['canonical_path'];before=checked(f['before']);previous=checked(f['proposed']);assert(R/n).read_bytes()==previous
a=b'                source_is_epjson: owners.control.source_is_epjson,\n';b=b'                // Unused: this authored admitted-input fixture has zero controlled Connections.\n                source_is_epjson: false,\n';assert previous.count(a)==1;after=previous.replace(a,b,1)
second=ref(D/'canonical-source-controlled-equipment-owner-test-Root-15-02/receipt.json');assert second['sha256']=='14b14a45fe3ace9bdaee1d2f080c755d3bc789ffb5d4153255c98f43ecb6a2b6';failed=json.loads(checked(second));assert failed['exit_code']==101 and failed['source_bytes_match_before_and_after'];assert checked(failed['stderr']).count(b'error[E0609]')==1
O.mkdir();refs={}
for k,data in [('before',before),('proposed',after),('literal_inverse',before)]:
 p=O/k/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);refs[k]=ref(p)
for k,x,y in [('forward_diff',before,after),('inverse_diff',after,before),('correction_forward',previous,after),('correction_inverse',after,previous)]:
 p=O/(k+'.diff');p.write_bytes(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile='before/'+n,tofile='proposed/'+n)).encode());refs[k]=ref(p)
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
assert apply(before,checked(refs['forward_diff']))==after and apply(after,checked(refs['inverse_diff']))==before and apply(previous,checked(refs['correction_forward']))==after and apply(after,checked(refs['correction_inverse']))==previous
p=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True,cwd=R);assert p.returncode==0
q=O/'parse.stdout';q.write_bytes(p.stdout);stdout=ref(q);q=O/'parse.stderr';q.write_bytes(p.stderr);stderr=ref(q)
plan=json.loads(checked(old['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert checked(rows[n]['source'])==previous;rows[n].update(source=refs['proposed'],final_sha256=refs['proposed']['sha256'],final_bytes=len(after),origin='existing zero-equipment test caller; explicitly unconsumed authored format flag')
q=O/'complete-final-compiler-Source-plan.json';q.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8',newline='\n');planref=ref(q)
m=dict(old);m.update(supersedes=oldref,second_failed_test=second,files=[dict(canonical_path=n,before_absent=False,**refs,Source_only_parse=dict(exit_code=0,stdout=stdout,stderr=stderr))],complete_final_compiler_Source_plan=planref,semantic_scope='Only existing authored zero-equipment direct caller. Same fixture Zone rows and actual context sizing manager. Constructor-default local schedule/Branch None and authored format false are unconsumed because there are zero controlled Connections; this from_admitted_input fixture has no Raw format producer. No control-format ownership claim. Actual production passes its retained Raw format flag unchanged.',superseded_claim='Initial adapter incorrectly referenced source_is_epjson on SelectedHeatBalanceInputState. Compiler E0609 falsifies that ownership claim; original adapter/peer/failed02 retained. No production Source correction.',author_Source=ref(Path(__file__).resolve()))
q=O/'manifest.json';q.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(q)))

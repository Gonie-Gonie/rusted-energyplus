from pathlib import Path
import ast, hashlib, json, re, subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Audit-controlled-equipment-test-flag-fix-Source-review-15'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'];assert len(b)==v.get('bytes',len(b));return b
def main():
 assert not O.exists()
 mp=D/'source-controlled-equipment-test-caller-fix-held-Root-15-02/manifest.json';assert ref(mp)['sha256']=='1232244c042f74cb09bafdfef09bcd0eee17be194bf3748098a765322e13fd2b'
 m=json.loads(mp.read_bytes());previous=json.loads(checked(m['supersedes']));r=m['files'][0];old=previous['files'][0]
 first=json.loads(checked(m['failed_test']));second=json.loads(checked(m['second_failed_test']))
 assert first['exit_code']==second['exit_code']==101 and first['source_bytes_match_before_and_after'] and second['source_bytes_match_before_and_after']
 assert b'E0061' in checked(first['stderr']) and b'E0609' in checked(second['stderr'])
 initial={r['historical_path']:r for r in json.loads(checked(m['initial_snapshot']))['files']}
 after01={r['historical_path']:r for r in json.loads(checked(second['source_snapshot']))['files']}
 oldplan=json.loads(checked(previous['complete_final_compiler_Source_plan']));plan=json.loads(checked(m['complete_final_compiler_Source_plan']))
 oldrows={r['path']:r for r in oldplan['entries']};rows={r['path']:r for r in plan['entries']};p=r['canonical_path']
 assert len(rows)==len(oldrows)==len(initial)==len(after01)==4486 and plan['Rust_sources']==4473
 assert [k for k in rows if rows[k]!=oldrows[k]]==[p]
 for k in rows:
  assert (oldrows[k]['final_sha256'],oldrows[k]['final_bytes'])==(after01[k]['archive']['sha256'],after01[k]['size_bytes'])
 before,prior,final=checked(r['before']),checked(old['proposed']),checked(r['proposed'])
 assert before==checked(initial[p]['archive'])==subprocess.check_output(['git','show',m['base_HEAD']+':'+p],cwd=R)
 assert prior==checked(after01[p]['archive'])==(R/p).read_bytes()
 assert (rows[p]['final_sha256'],rows[p]['final_bytes'])==(r['proposed']['sha256'],len(final))
 source=(D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8');fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<pure-app>','exec'),ns)
 for a,b,fwd,inv in [(before,final,r['forward_diff'],r['inverse_diff']),(prior,final,r['correction_forward'],r['correction_inverse'])]:
  assert ns['apply'](a,checked(fwd))==b and ns['apply'](b,checked(inv))==a
 assert checked(r['literal_inverse'])==before
 correction=checked(r['correction_forward'])
 removed=[x for x in correction.splitlines()if x.startswith(b'-')and not x.startswith(b'---')]
 added=[x for x in correction.splitlines()if x.startswith(b'+')and not x.startswith(b'+++')]
 assert removed==[b'-                source_is_epjson: owners.control.source_is_epjson,']
 assert added==[b'+                // Unused: this authored admitted-input fixture has zero controlled Connections.',b'+                source_is_epjson: false,']
 control=R/'crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs';surface=R/'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/surface.rs'
 for path in [control,surface]:
  relative=path.relative_to(R).as_posix();assert path.read_bytes()==checked(initial[relative]['archive'])==subprocess.check_output(['git','show',m['base_HEAD']+':'+relative],cwd=R)
 control_struct=re.search(rb'struct SelectedHeatBalanceInputState\s*\{(.*?)\n\}',control.read_bytes(),re.S);assert control_struct and b'source_is_epjson' not in control_struct[1]
 assert b"control: &'a mut SelectedHeatBalanceInputState" in surface.read_bytes()
 assert b'SelectedInputProcessor::from_admitted_input(\n            definitions,\n            std::collections::BTreeMap::new(),\n        )' in before
 production=R/'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_input.rs';prod=production.read_bytes()
 assert prod.index(b'for _controlled_zone in 0..controlled_zones')<prod.index(b'locals.get_connections(input, owners.source_is_epjson)')
 assert before.count(b'#[test]')==final.count(b'#[test]') and b'assert' not in b'\n'.join(added)
 parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=final,capture_output=True);assert parsed.returncode==0,parsed.stderr
 for key in ['author_Source','application']:checked(m[key])
 O.mkdir();(O/'parse.stdout').write_bytes(parsed.stdout);(O/'parse.stderr').write_bytes(parsed.stderr)
 report=dict(schema='src06-independent-existing-test-unused-format-fix.v1',accepted=True,findings=[],producer=ref(mp),superseded_caller_fix=m['supersedes'],superseded_incorrect_peer=ref(D/'Audit-controlled-equipment-test-caller-fix-Source-review-15/review.json'),retained_failed_test_receipts=[m['failed_test'],m['second_failed_test']],final_compiler_plan=m['complete_final_compiler_Source_plan'],whole_test_source=r['proposed'],literal_applications=4,fresh_parse_exit=0,parse_stdout=ref(O/'parse.stdout'),parse_stderr=ref(O/'parse.stderr'),exact1row_plan_change_all4485_unchanged=True,actual_control_type_context=[ref(control),ref(surface)],actual_zero_domain_producer=ref(production),reviewed_semantics=['The prior peer9fe incorrectly accepted nonexistent control.source_is_epjson; failed02 E0609 invalidates that claim. That packet/peer and both101receipts are retained as superseded, not successful checks.','Source flag false appears only inside the existing authored admitted-input fixture whose actual InputProcessor is constructed from declared definitions and a new empty family BTreeMap. The sole production read is inside the zero-trip controlled-Connections loop, so this scalar, default local ScheduleManager and BranchNone are unconsumed; no Raw format producer or positive owner substitution is claimed.','Original whole test assertions/count recover exactly. Source02 changes only the bad field expression plus its explicit unused-domain comment; no production code, expectation, case or test body is added.'],limits=['Successful suffix03 test execution and final snapshot custody remain Root obligations.','No positive controlled-equipment Native paired validation or completeB claim.'],main_mutations=0,production_changes=0,new_test_bodies=0,Cargo_Native_tests_executed=False,reviewer_Source=ref(Path(__file__)))
 (O/'review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(O/'review.json')))
if __name__=='__main__':main()

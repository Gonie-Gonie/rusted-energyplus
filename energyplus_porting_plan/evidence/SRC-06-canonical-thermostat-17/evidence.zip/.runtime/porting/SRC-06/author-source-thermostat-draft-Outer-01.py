from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DRAFT = ROOT / '.runtime/porting/SRC-06/source-thermostat-draft-Outer-01'
BASE = 'crates/ep_runtime/src/heat_balance/'

def change(path, old, new):
    parent = DRAFT / 'parent' / path
    proposed = DRAFT / 'proposed' / path
    text = proposed.read_bytes().decode('utf8')
    assert text.count(old) == 1, (path, old[:100], text.count(old))
    proposed.write_bytes(text.replace(old, new).encode('utf8'))

def reset(path):
    (DRAFT / 'proposed' / path).write_bytes((DRAFT / 'parent' / path).read_bytes())

for path in (DRAFT / 'parent').rglob('*.rs'):
    reset(str(path.relative_to(DRAFT / 'parent')))

change('crates/ep_raw_model/src/idf_order.rs',
       '    // ScheduleManager uses getObjectItem\'s preserved IDF order within these\n',
       '    // GetZoneAirSetPoints consumes the actual thermostat numeric-field\n'
       '    // count. Preserve its staged name/order/max-fields on the same raw owner.\n'
       '    IdfOrderTarget {\n'
       '        object_type: "ZoneControl:Thermostat",\n'
       '        name_field_index: 0,\n'
       '    },\n'
       '    // ScheduleManager uses getObjectItem\'s preserved IDF order within these\n')
change('crates/ep_raw_model/src/idf_order.rs',
       '                        | "SizingPeriod:DesignDay"\n',
       '                        | "SizingPeriod:DesignDay"\n'
       '                        | "ZoneControl:Thermostat"\n')
change('crates/ep_raw_model/src/idf_order.rs',
       '                || object_type.eq_ignore_ascii_case("SizingPeriod:DesignDay"))\n',
       '                || object_type.eq_ignore_ascii_case("SizingPeriod:DesignDay")\n'
       '                || object_type.eq_ignore_ascii_case("ZoneControl:Thermostat"))\n')
change(BASE+'ordinary_air_heat_balance/predictor_corrector.rs',
       '    pub(crate) shortcut: &\'a mut SourceInputProcessorShortCut,\n',
       '    pub(crate) shortcut: &\'a mut SourceInputProcessorShortCut,\n'
       '    pub(crate) source_is_epjson: &\'a bool,\n'
       '    pub(crate) schedules: &\'a mut crate::heat_balance::selected_schedule_manager::SelectedScheduleManager,\n')
change(BASE+'ordinary_hvac_manager/owners.rs',
       "    pub(crate) schedules: &'a SelectedScheduleManager,\n",
       "    pub(crate) schedules: &'a mut SelectedScheduleManager,\n")
change(BASE+'ordinary_hvac_manager/owners.rs',
       '            shortcut: self.shortcut,\n',
       '            shortcut: self.shortcut,\n'
       '            source_is_epjson: self.source_is_epjson,\n'
       '            schedules: self.schedules,\n')
change(BASE+'ordinary_hvac_manager/owners.rs',
       "    pub(crate) shortcut: &'a mut SourceInputProcessorShortCut,\n",
       "    pub(crate) shortcut: &'a mut SourceInputProcessorShortCut,\n"
       "    pub(crate) source_is_epjson: &'a bool,\n")
change(BASE+'ordinary_surface_management/provider_host.rs',
       "    pub(crate) shortcut: &'a mut SourceInputProcessorShortCut,\n",
       "    pub(crate) shortcut: &'a mut SourceInputProcessorShortCut,\n"
       "    pub(crate) source_is_epjson: &'a bool,\n")
for path in ['ordinary_air_heat_balance/provider_host.rs', 'ordinary_heat_balance_initialization/report.rs']:
    indent = '                ' if path.startswith('ordinary_air') else '            '
    change(BASE+path, indent+'shortcut: o.shortcut,\n'+indent+'psychrometrics: o.psychrometrics,\n',
           indent+'shortcut: o.shortcut,\n'+indent+'source_is_epjson: o.source_is_epjson,\n'+indent+'psychrometrics: o.psychrometrics,\n')
change(BASE+'ordinary_source_session/body.rs',
       '            shortcut: &mut reports.input_processor_shortcut,\n',
       '            shortcut: &mut reports.input_processor_shortcut,\n'
       '            source_is_epjson: &reports.heat_balance_input.as_ref()\n'
       '                .ok_or(Error::Unavailable("same actual input format before thermostat getter"))?.source_is_epjson,\n')
change(BASE+'selected_heat_balance_input/zone/storage.rs',
       '    pub(crate) humidity_control_zone_index: i32,\n',
       '    /// Native DataHeatBalance.hh606 ctor0, written by actual thermostat getter419.\n'
       '    pub(crate) temperature_controlled_zone_index: i32,\n'
       '    pub(crate) humidity_control_zone_index: i32,\n')
change(BASE+'selected_heat_balance_input/zone/storage.rs',
       '            humidity_control_zone_index: 0,\n',
       '            temperature_controlled_zone_index: 0,\n'
       '            humidity_control_zone_index: 0,\n')
change(BASE+'ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs',
       '    pub(crate) thermostat_objects: Option<Vec<SourceTStatObject>>,\n',
       '    pub(crate) thermostat_objects: Option<Vec<SourceTStatObject>>,\n'
       '    pub(crate) temperature_controlled_zones: Option<Vec<SourceTemperatureControlledZone>>,\n')
change(BASE+'ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs',
       '            thermostat_objects: None,\n',
       '            thermostat_objects: None,\n            temperature_controlled_zones: None,\n')
types = r'''
/// Exact DataZoneControls.hh79-86 enum; both control modes construct Invalid.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[repr(i32)]
pub(crate) enum SourceTemperatureControlMode {
    #[default]
    Invalid = -1,
    None = 0,
    Constant = 1,
    Scheduled = 2,
    Num = 3,
}
/// Complete DataZoneControls.hh91-97 constructor, including null pointers.
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct SourceTemperatureSetpointType {
    pub(crate) name: String,
    pub(crate) is_used: bool,
    pub(crate) heat_schedule: Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>,
    pub(crate) cool_schedule: Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>,
}
/// Sole actual TempControlledZone row; complete DataZoneControls.hh99-154.
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct SourceTemperatureControlledZone {
    pub(crate) name: String,
    pub(crate) zone_name: String,
    pub(crate) actual_zone_number: i32,
    pub(crate) control_type_schedule: Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>,
    pub(crate) setpoints: [SourceTemperatureSetpointType; 5],
    pub(crate) manage_demand: bool,
    pub(crate) heating_reset_limit: f64,
    pub(crate) cooling_reset_limit: f64,
    pub(crate) ems_override_heating_on: bool,
    pub(crate) ems_override_heating_value: f64,
    pub(crate) ems_override_cooling_on: bool,
    pub(crate) ems_override_cooling_value: f64,
    pub(crate) operative_control: SourceTemperatureControlMode,
    pub(crate) fixed_radiative_fraction: f64,
    pub(crate) operative_radiative_fraction_schedule: Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>,
    pub(crate) adaptive_comfort_temperature_control: bool,
    pub(crate) adaptive_comfort_model_type_index: i32,
    pub(crate) zone_overcool_range: f64,
    pub(crate) overcool_control: SourceTemperatureControlMode,
    pub(crate) zone_overcool_constant_range: f64,
    pub(crate) overcool_range_schedule: Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>,
    pub(crate) zone_overcool_control_ratio: f64,
    pub(crate) dehumidifying_schedule: Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>,
    pub(crate) delta_temperature_cutout_setpoint: f64,
    pub(crate) thermostat_setpoint_hi: f64,
    pub(crate) thermostat_setpoint_lo: f64,
    pub(crate) cool_mode_last: bool,
    pub(crate) heat_mode_last: bool,
    pub(crate) cool_mode_last_save: bool,
    pub(crate) heat_mode_last_save: bool,
    pub(crate) cool_off: bool,
    pub(crate) heat_off: bool,
}
impl Default for SourceTemperatureControlledZone {
    fn default() -> Self {
        Self {
            name: String::new(), zone_name: String::new(), actual_zone_number: 0,
            control_type_schedule: None,
            setpoints: std::array::from_fn(|_| SourceTemperatureSetpointType::default()),
            manage_demand: false, heating_reset_limit: 0.0, cooling_reset_limit: 0.0,
            ems_override_heating_on: false, ems_override_heating_value: 0.0,
            ems_override_cooling_on: false, ems_override_cooling_value: 0.0,
            operative_control: SourceTemperatureControlMode::Invalid,
            fixed_radiative_fraction: 0.0, operative_radiative_fraction_schedule: None,
            adaptive_comfort_temperature_control: false, adaptive_comfort_model_type_index: 0,
            zone_overcool_range: 0.0, overcool_control: SourceTemperatureControlMode::Invalid,
            zone_overcool_constant_range: 0.0, overcool_range_schedule: None,
            zone_overcool_control_ratio: 0.0, dehumidifying_schedule: None,
            delta_temperature_cutout_setpoint: 0.0,
            thermostat_setpoint_hi: 0.0, thermostat_setpoint_lo: 0.0,
            cool_mode_last: false, heat_mode_last: false,
            cool_mode_last_save: false, heat_mode_last_save: false,
            cool_off: false, heat_off: false,
        }
    }
}
'''
change(BASE+'ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs',
       '/// Complete actual ZoneTempPredictorCorrector.hh74-79 row constructor.\n',
       types+'\n/// Complete actual ZoneTempPredictorCorrector.hh74-79 row constructor.\n')
path=BASE+'selected_schedule_manager/accessors.rs'
proposed=DRAFT/'proposed'/path
text=proposed.read_bytes().decode('utf8')
assert text.endswith('}\n')
text=text[:-2]+r'''
    /// Actual ScheduleBase::checkMinMaxVals for the caller's two inclusive bounds.
    pub(crate) fn source_check_min_max_inclusive(
        &mut self, index: SourceScheduleIndex, minimum: f64, maximum: f64,
    ) -> Result<bool, E> {
        let (actual_minimum, actual_maximum) = self.source_selected_min_max(index)?;
        let min_ok = f64::from(f32::EPSILON) >= minimum - actual_minimum;
        let max_ok = actual_maximum - maximum <= f64::from(f32::EPSILON);
        Ok(min_ok && max_ok)
    }
    /// Exact Constant::hasVal. Detailed traversal is an explicit separate bound.
    pub(crate) fn source_has_value(&self, index: SourceScheduleIndex, value: f64) -> Result<bool, E> {
        let row = self.schedules.get(index.0).ok_or(E::Unavailable("actual hasVal Schedule pointer"))?;
        match &row.data {
            SelectedScheduleData::Constant { .. } => Ok(value == row.current_value),
            SelectedScheduleData::Detailed(_) => Err(E::Unavailable("actual ScheduleDetailed::hasVal3433")),
        }
    }
}
'''
proposed.write_bytes(text.encode('utf8'))

path=BASE+'ordinary_air_heat_balance/predictor_corrector/lifecycle/input.rs'
change(path, '//! Actual GetZoneAirSetPoints zero-control body; reached positive branches explicit.\n',
       '//! Actual GetZoneAirSetPoints with genuine finite positive Thermostat input.\n')
change(path, 'use std::io::Write;\n', 'use std::io::Write;\nmod thermostat;\n')
change(path, '        owners.shortcut.current_module_object = "ZoneControl:Thermostat".into();\n',
       '        let errors_found = false; // Actual GetZoneAirSetPoints local ctor274.\n'
       '        // Actual getter-local arrays remain live through this function.\n'
       '        let mut thermostat_locals = thermostat::SourceThermostatInputLocals::default();\n'
       '        owners.shortcut.current_module_object = "ZoneControl:Thermostat".into();\n')
change(path, '        if self.controls.number_thermostat_statements > 0 {\n'
             '            return Err(Error::Unavailable("positive thermostat getObjectItem332"));\n'
             '        }\n',
       '        self.get_source_thermostat_objects(owners, &mut thermostat_locals)?;\n')
old='''                return Err(Error::Unavailable(match line {
                    525 => "actual positive singleHeat first getObjectItem529",
                    561 => "actual positive singleCool first getObjectItem565",
                    597 => "actual positive singleHeatCool first getObjectItem601",
                    _ => "actual positive dual first getObjectItem637",
                }));
'''
new='''                if kind == 4 {
                    self.get_source_dual_setpoint_schedules(owners)?;
                } else {
                    return Err(Error::Unavailable(match line {
                        525 => "actual positive singleHeat first getObjectItem529",
                        561 => "actual positive singleCool first getObjectItem565",
                        _ => "actual positive singleHeatCool first getObjectItem601",
                    }));
                }
'''
change(path, old, new)
change(path, '        owners.shortcut.current_module_object = "ZoneControl:Humidistat".into();\n',
       '        self.link_source_thermostat_schedules(owners, &mut thermostat_locals)?;\n'
       '        owners.shortcut.current_module_object = "ZoneControl:Humidistat".into();\n')
change(path, '        // Local ErrorsFound was false; zero-control path emits no final fatal.\n',
       '        // The valid finite path retains the actual false local constructor;\n'
       '        // unported diagnostic branches stop before their first message/write.\n'
       '        if errors_found {\n'
       '            return match owners.backend.show_fatal_error(\n'
       '                "Errors getting Zone Control input data.  Preceding condition(s) cause termination.",\n'
       '            ) {\n'
       '                Err(error) => Err(Error::Fatal(error)),\n'
       '                Ok(never) => match never {},\n'
       '            };\n'
       '        }\n')
print('Updated eleven isolated old Sources; two genuine getter children are authored separately.')

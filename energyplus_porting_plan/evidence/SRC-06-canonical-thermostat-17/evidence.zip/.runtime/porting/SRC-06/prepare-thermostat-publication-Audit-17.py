"""Prepare the held checkpoint17 packet only after Root accepts real actual17."""
from pathlib import Path
import argparse
import ast
import hashlib
import json

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
READY = D / 'thermostat-publication-prepared-Audit-17'


def ref(path):
    path = path.resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def main(args):
    assert not READY.exists()
    inputs = {}

    def add(path):
        row = ref(path)
        assert path.suffix.lower() != '.zip'
        inputs[row['path']] = row
        return row

    def addref(row):
        got = add(R / row['path'])
        assert got['sha256'] == row['sha256']
        assert got['bytes'] == row.get('bytes', row.get('size_bytes', got['bytes']))
        return got

    draft_path = D / 'thermostat-publication-draft-Audit-17/publication-template.draft.json'
    add(draft_path)
    draft = json.loads(draft_path.read_bytes())
    assert draft['status'] == 'UNSEALED_WAITING_ROOT_ACTUAL17_RECEIPTS_AND_REVIEW'
    for row in draft['finite_archive_inputs']:
        addref(row)
    producer_ref = addref(draft['producer'])
    assert producer_ref['sha256'] == 'f35a554765f35c58a565f0eab3a752917f25213559e482dddc24aa9d84d7191d'
    producer = json.loads((R / producer_ref['path']).read_bytes())
    peer_ref = addref(draft['independent_peer'])
    assert peer_ref['sha256'] == 'bf98703c583781a69a67a446f17250abffa1c5c49560619635bdd76996d029c7'
    peer = json.loads((R / peer_ref['path']).read_bytes())
    assert peer['accepted'] and not peer['findings']
    complete_plan = addref(producer['complete_final_compiler_Source_plan'])
    plan = json.loads((R / complete_plan['path']).read_bytes())
    assert plan['inputs'] == 4489 and plan['Rust_sources'] == 4476
    assert len(producer['files']) == 13 and producer['existing_Source_files'] == 11 and producer['new_Source_files'] == 2
    application_ref = add(D / 'Root-thermostat-application-17/receipt.json')
    assert application_ref['sha256'] == '21c0b7d58e33ff22b05096f148f98542a7e71873302c4b5f77ef680f5e12a154'
    application = json.loads((R / application_ref['path']).read_bytes())
    assert application['accepted'] and not application['findings']
    addref(application['author_Source'])
    publisher_path = D / 'publish-thermostat-checkpoint-Audit-17-template.py'
    ast.parse(publisher_path.read_text(encoding='utf-8'))
    publisher = add(publisher_path)
    author = add(Path(__file__))
    actual_path = D / 'Root-source-thermostat-actual-review-17/review.json'
    actual_ref = add(actual_path)
    assert actual_ref['sha256'] == args.actual_sha
    actual = json.loads(actual_path.read_bytes())
    assert actual['accepted'] and not actual['findings']
    for key in ['author_Source', 'accepted16_full5352_proof', 'unchanged_original_tolerance_policy', 'comparison_helper_Source']:
        addref(actual[key])
    validation = dict(Root_actual_review=actual_ref, test=actual['actual_owner_test'], B_CLI=actual['actual_B'], A24_CLI=actual['actual_A24'])
    for label, run in [('B', 'canonical-source-thermostat-B-NOLIMIT-24H-Root-17'), ('A24', 'canonical-source-thermostat-A-24H-Root-17')]:
        for suffix, name in [('summary', 'run-summary.json'), ('diagnostics', 'diagnostics.json')]:
            row = ref(D / run / 'output' / name)
            assert row in actual['publication_artifacts']
            validation[label + '_' + suffix] = row
    required = ['same4489_archived_inputs_exact_final_plan', 'selected13_final_sources_exact', 'first_B_core_fresh_false', 'A24_same_core_reused_fresh_true', 'original_tolerance_RMSE_5352_proof_transferred', 'whole_JSON_equal16_after_exactly_two_owned_path_field_bridges', 'full_runtime_equal16_after_two_owned_path_bridges']
    assert all(actual[key] is True for key in required)
    transfer = dict(series=58, samples=5352, unchanged_policy=actual['unchanged_original_tolerance_policy'], accepted16_proof=actual['accepted16_full5352_proof'], physical_files_whole_equal16=len(actual['whole_physical_streams_equal16']), CSV_files_whole_equal16=len(actual['whole_CSV_equal16']), table_lines=actual['table_lines'], clock_only_line_changes_versus16=actual['table_clock_metadata_changes'], scope='Transfer from accepted16 output evidence; no new Native/72h/annual execution, transitive replay or internal-state equivalence claim.')
    assert transfer['physical_files_whole_equal16'] == 7 and transfer['CSV_files_whole_equal16'] == 2 and transfer['table_lines'] == 19312
    fixture = addref(draft['existing_test_JSON_fixture'])
    docs = draft['doc_appends_pending_actual']
    docs = {'CHECKLIST.md': docs['CHECKLIST'], 'STATE_CONTRACTS.md': docs['STATE_CONTRACTS'], 'cards/SRC-06.md': docs['SRC06'].replace('{{actual_B_frontier}}', actual['B_frontier'])}
    assert all('\ufffd' not in text and '{{' not in text for text in docs.values())
    template = dict(schema='src06-held-canonical17-publication-template.v1', status='HELD_READY_FOR_ROOT_REVIEW', base_HEAD=producer['base_HEAD'], producer=producer_ref, independent_peer=peer_ref, complete_plan=complete_plan, application=application_ref, existing_test_JSON_fixture=fixture, previous_checkpoint=draft['previous_checkpoint'], publisher_Source=publisher, actual_review=actual_ref, required_true_actual_predicates=required, actual_B_frontier=actual['B_frontier'], actual_A24_proof_transfer=transfer, actual_scope_qualification=actual['B_Node_lifecycle_execution'],
        summary_template=dict(A='14/54', B='14/64', changed_Rust_sources=13, existing_Rust_sources=11, new_Rust_sources=2, new_test_functions=0, existing_test='actual_native_get_equipment_pair_and_input_owner_transitions', test_scope='One existing Native uncontrolled pair7 plus real input/owner transitions; not positive thermostat/Node Native paired state validation or all8 fixture cases.', existing_included_JSON_fixture=fixture, fixture_snapshot_scope='Existing rs/Cargo recorder omits this included JSON, which is separately Git/current bound and directly archived; no recorder change.', producer=producer_ref, independent_peer=peer_ref, complete_compiler_plan=complete_plan, focused_validation_policy='One meaningful existing runtime test build plus actualCLI B/A24; no new helper tests or habitual separate workspace-all-targets check.', scope='Genuine thermostat getter and retained declaration order, full TempControlledZone constructors, setpoint schedule links and actual same-owner callers. Environment/current-values/predefined positive boundaries remain explicit; execution and next boundary follow only the accepted Root aggregate.', full_B_or_finite15_completion_claim=False, gate_changes=False),
        doc_appends=docs, targets=draft['targets'], append_existing_docs=draft['append_existing_docs'], plan_add_only=draft['plan_add_only'], finite_archive_inputs=[row for name, row in sorted(inputs.items())], finite_archive_input_count=len(inputs), finite_archive_input_bytes=sum(row['bytes'] for row in inputs.values()), author_Source=author, publisher_executed=False, canonical_docs_mutations=False, Cargo_tests_Native_executed=False, gate_changes=False)
    READY.mkdir()
    validation_path = READY / 'validation-refs.json'
    validation_path.write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8', newline='\n')
    target = READY / 'publication-template.json'
    target.write_text(json.dumps(template, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(template=ref(target), publisher=publisher, validation=ref(validation_path), archive_inputs=len(inputs), archive_raw_bytes=template['finite_archive_input_bytes'])))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--actual-sha', required=True)
    main(parser.parse_args())

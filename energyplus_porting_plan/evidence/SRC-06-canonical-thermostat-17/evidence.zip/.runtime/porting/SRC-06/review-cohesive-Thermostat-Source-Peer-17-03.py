"""Independent held Thermostat Source peer. No main/Cargo/Native/tests execution."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'Peer-cohesive-Thermostat-input-Source-review-17-03'
parser = argparse.ArgumentParser()
parser.add_argument('--manifest-sha', required=True)
a = parser.parse_args()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
def check(row):
    path = R / row['path']; actual = ref(path)
    assert actual['sha256'] == row['sha256'] and actual['bytes'] == row.get('bytes', actual['bytes']), row
    return path
def load(row): return json.loads(check(row).read_bytes())
def put(name, data):
    path = O / name; assert not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
    return ref(path)
def doc(name, value): return put(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

mref = ref(D / 'source-thermostat-held-Outer-01/manifest.json')
assert mref['sha256'] == a.manifest_sha
m = load(mref)
assert m['Native_commit'] == PIN
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert head == m['base_HEAD']
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
root = load(m['actual16_review'])
assert root['accepted'] and not root['findings']
assert root['B_frontier'] == 'GetHeatBalanceInput: positive thermostat getObjectItem332'
assert not root['B_Node_lifecycle_execution']['setup_returned'] and not root['B_Node_lifecycle_execution']['reset_returned']
snap = load(m['actual16_snapshot'])
observed = {row['historical_path']: row for row in snap['files']}
assert len(observed) == len(snap['files']) == 4487
assert sum(p.endswith('.rs') for p in observed) == 4474
for key, expected in [('actual16_B', 6), ('actual16_A24', 0), ('actual16_test', 0)]:
    receipt = load(m[key])
    assert receipt['exit_code'] == expected and receipt['source_bytes_match_before_and_after']
    assert receipt['source_snapshot']['sha256'] == m['actual16_snapshot']['sha256']
assert len(m['files']) == 13 and m['literal_applications'] == 26
assert m['existing_Source_files'] == 11 and m['new_Source_files'] == 2
assert not O.exists(); O.mkdir()
node = next(row for row in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(row, ast.FunctionDef) and row.name == 'apply_literal')
namespace = {'re': re}
exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal-apply>', 'exec'), namespace)
texts, files = {}, []
for i, row in enumerate(m['files'], 1):
    p = row['canonical_path']; old, new = check(row['before']).read_bytes(), check(row['proposed']).read_bytes()
    texts[p] = new.decode()
    assert namespace['apply_literal'](old, check(row['forward_diff']).read_bytes()) == new
    assert namespace['apply_literal'](new, check(row['inverse_diff']).read_bytes()) == old == check(row['literal_inverse']).read_bytes()
    if row['before_absent']:
        assert old == b'' and p not in observed and not (R / p).exists()
        assert subprocess.run(['git', 'cat-file', '-e', head + ':' + p], cwd=R, capture_output=True).returncode != 0
    else:
        assert old == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes()
        assert old == subprocess.check_output(['git', 'show', head + ':' + p], cwd=R)
    assert row['Source_only_parse']['exit_code'] == 0 and not check(row['Source_only_parse']['stderr']).read_bytes()
    check(row['Source_only_parse']['stdout'])
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and not parsed.stderr
    files.append({'path': p, 'before_absent': row['before_absent'], 'before': row['before'], 'proposed': row['proposed'], 'both_literal_applications_and_whole_inverse': True,
        'Git_actual16_live_parent_equal': not row['before_absent'], 'independent_parse': {'exit_code': 0, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})

native = {}
for row in m['Native_wholes']:
    path = check(row); relative = path.relative_to(N).as_posix()
    data = path.read_bytes()
    assert data == subprocess.check_output(['git', 'show', PIN + ':' + relative], cwd=N)
    native[relative] = data
    put('Original-Git/' + relative, data)
extents = load(m['Native_literal_extents'])
for row in extents:
    data = b''.join(native[row['native_path']].splitlines(keepends=True)[row['first'] - 1:row['last']])
    assert data.decode() == row['literal'] and hashlib.sha256(data).hexdigest() == row['utf8_sha256']
assert len(native) == 12 and len(extents) == 26

controls = texts[P + 'ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs']
thermostat = texts[P + 'ordinary_air_heat_balance/predictor_corrector/lifecycle/input/thermostat.rs']
getter = texts[P + 'ordinary_air_heat_balance/predictor_corrector/lifecycle/input/thermostat/getter.rs']
input_body = texts[P + 'ordinary_air_heat_balance/predictor_corrector/lifecycle/input.rs']
access = texts[P + 'selected_schedule_manager/accessors.rs']
native_ctor = native['src/EnergyPlus/DataZoneControls.hh'].decode().split('struct ZoneTempControls', 1)[1].split('struct ZoneHumidityControls', 1)[0]
source_ctor = controls.split('struct SourceTemperatureControlledZone {', 1)[1].split('\n}', 1)[0]
source_default = controls.split('impl Default for SourceTemperatureControlledZone {', 1)[1].split('/// Complete actual ZoneTempPredictorCorrector.hh74', 1)[0]
mapping = [
    ('Name', 'name', 'std::string', 'String', 'String::new()', None),
    ('ZoneName', 'zone_name', 'std::string', 'String', 'String::new()', None),
    ('ActualZoneNum', 'actual_zone_number', 'int', 'i32', '0', '0'),
    ('setptTypeSched', 'control_type_schedule', 'Sched::Schedule *', 'Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>', 'None', 'nullptr'),
    ('setpts', 'setpoints', 'std::array', '[SourceTemperatureSetpointType; 5]', 'std::array::from_fn(|_| SourceTemperatureSetpointType::default())', None),
    ('ManageDemand', 'manage_demand', 'bool', 'bool', 'false', 'false'),
    ('HeatingResetLimit', 'heating_reset_limit', 'Real64', 'f64', '0.0', '0.0'),
    ('CoolingResetLimit', 'cooling_reset_limit', 'Real64', 'f64', '0.0', '0.0'),
    ('EMSOverrideHeatingSetPointOn', 'ems_override_heating_on', 'bool', 'bool', 'false', 'false'),
    ('EMSOverrideHeatingSetPointValue', 'ems_override_heating_value', 'Real64', 'f64', '0.0', '0.0'),
    ('EMSOverrideCoolingSetPointOn', 'ems_override_cooling_on', 'bool', 'bool', 'false', 'false'),
    ('EMSOverrideCoolingSetPointValue', 'ems_override_cooling_value', 'Real64', 'f64', '0.0', '0.0'),
    ('OpTempCtrl', 'operative_control', 'TempCtrl', 'SourceTemperatureControlMode', 'SourceTemperatureControlMode::Invalid', 'TempCtrl::Invalid'),
    ('FixedRadiativeFraction', 'fixed_radiative_fraction', 'Real64', 'f64', '0.0', '0.0'),
    ('opTempRadiativeFractionSched', 'operative_radiative_fraction_schedule', 'Sched::Schedule *', 'Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>', 'None', 'nullptr'),
    ('AdaptiveComfortTempControl', 'adaptive_comfort_temperature_control', 'bool', 'bool', 'false', 'false'),
    ('AdaptiveComfortModelTypeIndex', 'adaptive_comfort_model_type_index', 'int', 'i32', '0', '0'),
    ('ZoneOvercoolRange', 'zone_overcool_range', 'Real64', 'f64', '0.0', '0.0'),
    ('OvercoolCtrl', 'overcool_control', 'TempCtrl', 'SourceTemperatureControlMode', 'SourceTemperatureControlMode::Invalid', 'TempCtrl::Invalid'),
    ('ZoneOvercoolConstRange', 'zone_overcool_constant_range', 'Real64', 'f64', '0.0', '0.0'),
    ('zoneOvercoolRangeSched', 'overcool_range_schedule', 'Sched::Schedule *', 'Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>', 'None', 'nullptr'),
    ('ZoneOvercoolControlRatio', 'zone_overcool_control_ratio', 'Real64', 'f64', '0.0', '0.0'),
    ('dehumidifyingSched', 'dehumidifying_schedule', 'Sched::Schedule *', 'Option<crate::heat_balance::selected_schedule_manager::SourceScheduleIndex>', 'None', 'nullptr'),
    ('DeltaTCutSet', 'delta_temperature_cutout_setpoint', 'Real64', 'f64', '0.0', '0'),
    ('ZoneThermostatSetPointHi', 'thermostat_setpoint_hi', 'Real64', 'f64', '0.0', '0.0'),
    ('ZoneThermostatSetPointLo', 'thermostat_setpoint_lo', 'Real64', 'f64', '0.0', '0.0'),
    ('CoolModeLast', 'cool_mode_last', 'bool', 'bool', 'false', 'false'),
    ('HeatModeLast', 'heat_mode_last', 'bool', 'bool', 'false', 'false'),
    ('CoolModeLastSave', 'cool_mode_last_save', 'bool', 'bool', 'false', 'false'),
    ('HeatModeLastSave', 'heat_mode_last_save', 'bool', 'bool', 'false', 'false'),
    ('CoolOffFlag', 'cool_off', 'bool', 'bool', 'false', 'false'),
    ('HeatOffFlag', 'heat_off', 'bool', 'bool', 'false', 'false'),
]
actual_fields = re.findall(r'pub\(crate\) (\w+): ([^\n]+),', source_ctor)
assert len(actual_fields) == len(mapping) == 32
ctor_ledger = []
for (nn, sn, nt, st, sv, nv), (actual_name, actual_type) in zip(mapping, actual_fields, strict=True):
    assert actual_name == sn and actual_type == st
    assert re.search(r'\b' + re.escape(nn) + r'\b', native_ctor)
    assert re.search(r'\b' + re.escape(sn) + r'\s*:\s*' + re.escape(sv) + r'\s*,', source_default)
    if nv is not None:
        assert re.search(r'\b' + re.escape(nn) + r'\s*(?:\(\s*' + re.escape(nv) + r'\s*\)|=\s*' + re.escape(nv) + r'\s*;)', native_ctor)
    ctor_ledger.append({'Native_field': nn, 'Source_field': sn, 'Native_type': nt, 'Source_type': st, 'Native_default': nv or ('five member-default setpoints' if nn == 'setpts' else 'std::string empty'), 'Source_default': sv})
assert 'pub(crate) enum SourceTemperatureControlMode' in controls and 'Invalid = -1' in controls
assert '[SourceTemperatureSetpointType; 5]' in source_ctor
setpoint_body = controls.split('struct SourceTemperatureSetpointType {', 1)[1].split('\n}', 1)[0]
assert len(re.findall(r'pub\(crate\) \w+:', setpoint_body)) == 4
assert '#[derive(Clone, Debug, Default, PartialEq)]\npub(crate) struct SourceTemperatureSetpointType' in controls
ctor_ref = doc('independent-32-field-control-constructor.json', ctor_ledger)

# Actual new getters and Native call-order contracts; handwritten peer findings
# above concern procedure semantics, not only these structural assertions.
assert thermostat.count('getter::thermostat(') == 2
assert 'row.name == owners.shortcut.alpha_args[1]' in thermostat
assert 'row.zone_name == owners.shortcut.alpha_args[1]' in thermostat
assert 'zone.name == owners.shortcut.alpha_args[1]' in thermostat
assert thermostat.index('row.zone_name = owners.shortcut.alpha_args[1].clone();') < thermostat.index('row.actual_zone_number = match actual_zone') < thermostat.index('.temperature_controlled_zone_index = controlled_zone_number;') < thermostat.index('row.name = owners.shortcut.alpha_args[0].clone();') < thermostat.index('row.control_type_schedule = owners.schedules.get_source_schedule')
assert thermostat.index('alpha_field_blanks[6]') < thermostat.index('alpha_field_blanks[8]') < thermostat.index('alpha_field_blanks[10]') < thermostat.index('let setpoint_type_count =') < thermostat.index('if num_numbers > 0')
assert '(setpoint_type_count + sign * 0.5) as i32' in thermostat
assert '.find(|setpoint| setpoint.name == row.setpoints[kind].name)' in thermostat
assert '.or_else(|| rows.iter().find(|setpoint| setpoint.name.eq_ignore_ascii_case' in thermostat
assert 'if kind == 1 || kind == 3 || kind == 4' in thermostat and 'if kind == 2 || kind == 3 || kind == 4' in thermostat
assert 'let schedule_minimum = minimum as i32;' in thermostat and 'let schedule_maximum = maximum as i32;' in thermostat
assert 'if !setpoint.is_used {' in thermostat and 'source_has_value(schedule, kind as f64)?' in thermostat
assert thermostat.count('needed.must_have') == 2 and 'if locals.control_types.is_some() { locals.control_types = None; }' in thermostat
assert 'if maximum >= 12 { 1 } else { 0 }' in getter
assert 'maximum.min(11).max(1)' in getter
assert getter.index('shortcut.alpha_args.fill') < getter.index('input.mark_object_as_used') < getter.index('for (at, &(field, label))')
assert 'Some(V::Number(token)) => token.parse::<usize>()' in getter
assert "token.parse::<i64>().map(|value| value as f64)" in getter
assert 'family == DUAL && !source_is_epjson && names.len() != 1' in getter
assert 'source_selected_min_max(index)?' in access and 'f64::from(f32::EPSILON) >= minimum - actual_minimum' in access and 'actual_maximum - maximum <= f64::from(f32::EPSILON)' in access
assert 'SelectedScheduleData::Constant { .. } => Ok(value == row.current_value)' in access
assert 'SelectedScheduleData::Detailed(_) => Err' in access
assert 'positive thermostat ActualZoneNum3303' in input_body
idf = texts['crates/ep_raw_model/src/idf_order.rs']
assert 'object_type: "ZoneControl:Thermostat"' in idf
assert 'object_type.eq_ignore_ascii_case("ZoneControl:Thermostat")' in idf
assert 'requires a terminating semicolon for exact IDF field metadata' in idf
assert 'FieldName("idf_max_fields".to_string())' in idf
assert 'temperature_controlled_zone_index: 0' in texts[P + 'selected_heat_balance_input/zone/storage.rs']
planning = load(m['read_only_planning_authority'])
schema = load(planning['schema_authority'])
assert planning['selected_schema'] == {name: schema[name] for name in ['ZoneControl:Thermostat', 'ThermostatSetpoint:DualSetpoint']}
for family, array_name in [('ZoneControl:Thermostat', 'THERMOSTAT_ALPHAS'), ('ThermostatSetpoint:DualSetpoint', 'DUAL_ALPHAS')]:
    obj = schema[family]
    assert 'min_fields' not in obj and 'extension' not in obj['legacy_idd']
    assert 'retaincase' not in obj['name']
    block = getter.split('const ' + array_name + ':', 1)[1].split('];', 1)[0]
    pairs = re.findall(r'\("([^"]+)", "([^"]+)"\)', block)
    assert [key for key, _ in pairs] == obj['legacy_idd']['alphas']['fields']
    for key, label in pairs:
        assert obj['legacy_idd']['field_info'][key] == {'field_name': label, 'field_type': 'a'}
    props = next(iter(obj['patternProperties'].values()))['properties']
    assert all('retaincase' not in props.get(key, {}) for key, _ in pairs)
cutout = 'temperature_difference_between_cutout_and_setpoint'
thermostat_schema = schema['ZoneControl:Thermostat']
assert thermostat_schema['legacy_idd']['fields'][-1] == cutout and thermostat_schema['legacy_idd']['numerics']['fields'] == [cutout]
assert next(iter(thermostat_schema['patternProperties'].values()))['properties'][cutout]['default'] == 0.0

correction = load(m['preseal_search_correction'])
finding = correction['finding_and_fix']
old, new = check(correction['before']).read_bytes(), check(correction['after']).read_bytes()
assert hashlib.sha256(old).hexdigest() == finding['before_thermostat_sha256'] == '2c70c8d5ab16a91009d4dcdedd88768f4f228c7fe84bf83d315a4c8cb612073f'
assert hashlib.sha256(new).hexdigest() == finding['after_thermostat_sha256'] == '51a855a5bb150c5d4daa3fe5b0b41ba637ce65ca0b6e701ab7cb2ff146e9f0fa'
assert new.decode() == thermostat
assert namespace['apply_literal'](old, check(correction['forward']).read_bytes()) == new
assert namespace['apply_literal'](new, check(correction['inverse']).read_bytes()) == old
assert correction['before_status']['sha256'] == '90267f8db21fcdba41a4e58513a741d6538b7d804cd88dd5c83476c749ca4dc0'
check(correction['before_status'])
correction_ref = doc('preseal-semantic-finding-resolved.json', {'finding': finding, 'independent_finding': 'Three Native FindItemInList exact predicates and distinct FindItem exact-first/fallback now represented literally.', 'before': correction['before'], 'after': correction['after'], 'forward_and_inverse_applied': True, 'sealed_rejected_variant_created': False})

plan = load(m['complete_final_compiler_Source_plan'])
entries = {row['path']: row for row in plan['entries']}
selected = {row['canonical_path']: row for row in m['files']}
assert len(entries) == len(plan['entries']) == plan['inputs'] == 4489 and plan['Rust_sources'] == 4476
assert set(entries) == set(observed) | {p for p, row in selected.items() if row['before_absent']}
for p, row in entries.items():
    data = check(row['source']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['final_sha256'] and len(data) == row['final_bytes']
    if p in selected:
        assert data == check(selected[p]['proposed']).read_bytes()
    else:
        assert data == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes()
assert sum(p.endswith('.rs') for p in entries) == 4476
assert P + 'source_output_registration/report_diagnostics.rs' not in entries
api = load(m['whole_crates_API_inventory'])
assert api['actual_constructor_counts'] == {'SourceManageSurfaceOwners': 1, 'SourceHvacOwners': 2, 'SourceZoneAirOwners': 1}
for row in api['concrete_type_authorities']: check(row)
for p, row in selected.items():
    additions = ''.join(line[1:] for line in check(row['forward_diff']).read_text(encoding='utf-8').splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
    assert '#[test]' not in additions and '.runtime' not in additions and 'ZONE ONE' not in additions
contract = load(m['integration_contract'])
load(m['constructor_records'])
assert not m['new_test_bodies'] and not m['Cargo_Native_or_tests_executed'] and not m['main_mutations'] and not m['FP_tolerance_or_gate_changes']
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
review = {'schema': 'src06-independent-cohesive-Thermostat-Source-peer.v1', 'accepted': True, 'findings': [], 'reviewed_packet': mref,
    'base_HEAD': head, 'actual16_review': m['actual16_review'], 'actual16_snapshot': m['actual16_snapshot'],
    'files': files, 'independent_Native_Git_wholes': len(native), 'strict_Native_extents': len(extents), 'independent_constructor_ledger': ctor_ref,
    'preseal_semantic_correction': correction_ref, 'complete4489_plan_full_readback': m['complete_final_compiler_Source_plan'], 'Rust_sources': 4476,
    'selected_schema_authority': planning['schema_authority'], 'schema_scope': 'Two getter grammars/default/labels independently matched to the previously pinned whole seven-object Native schema authority; no new IDD parser execution is claimed.',
    'semantic_review': ['Complete32-field control constructor, complete4-field setpoint subrecords, Invalid-1 modes/null pointers/empty names/zero flags; real constructor-unallocated owner and actual positive allocations.',
        'Two real getter passes on retained IP/shared shortcut; prescan count/start/pointer, duplicate/Zone association and same TempControlledZoneIndex writer; exact Native name search predicates after preserved pre-seal correction.',
        'Real staged IDF declaration order/max-fields on same raw owner, explicit EOF metadata boundary; direct epJSON highest legacy field/min0. Actual Name count, physical12th numeric operand/default/blank/sign distinction and no fabricated NumNums.',
        'Exact blank7/9/11 rewrites before Native nint, ordered setpoint names/isUsed and cutout/NumOnOff logic. Four real setpoint families/count/allocation order; finite Dual pointers, actual link exact-first/fallback and relevant heat/cool assignments.',
        'Same mutable schedules and actual raw format bool borrowed through concrete four constructors; real GetSchedule used-state/minmax caches, FLT_EPSILON inclusive formula and Constant.hasVal(currentVal) distinct from live EMS override.',
        'Whole pinned TStatControlTypes census has only declaration/allocation/read/deallocation, so real MustHave/DidHave ctorfalse is preserved rather than inferred from samples. Map lifetime/order and local deallocation match.',
        'Existing suffix through GetZoneAirSetPoints return preserves zero unrepresented families, same capacitance assignments/EIO and fatal local constructor. Environment/current setpoint/predefined and positive Node execution remain separately unclaimed.'],
    'limits': ['This is Source-only acceptance. Root owns compilation, selected existing test, actual B/A24 and any result comparison.', 'No actual17/wholeB/Node lifecycle certification. Parent16 B stops at actual thermostat332 before positive Node setup/reset.', 'ZoneList expansion, positive single setpoint getters, multi-Dual IDF order, diagnostics/non-ASCII/unsupported numeric domains and Detailed.hasVal retain explicit operation boundaries.'],
    'reviewer_custody_proof_correction': {'failed_second_reviewer': ref(D / 'review-cohesive-Thermostat-Source-Peer-17-02.py'), 'reason': 'Final author correction provenance has a nested finding_and_fix wrapper and frozen before/after/diff refs. Final reviewer authenticates those exact authoritative refs; no Source finding/change.'}, 'reviewer_proof_correction': {'failed_reviewer': ref(D / 'review-cohesive-Thermostat-Source-Peer-17.py'), 'reason': 'Initial ordering assertion used row.name = as a prefix and matched the earlier row.name == predicate. Successor selects complete assignment statements only; no Source finding or Source change.'}, 'main_mutations': 0, 'Cargo_Native_or_tests_executed': False, 'new_test_bodies': 0, 'reviewer_Source': ref(Path(__file__))}
print(json.dumps(doc('review.json', review)))

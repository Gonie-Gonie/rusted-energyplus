from pathlib import Path
import ast,copy,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-source-compact-actual-review-13'
assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
def auth(name,sha):
 p=D/name;assert ref(p)['sha256']==sha;return ref(p),json.loads(p.read_bytes())
def same_path(value,p):assert Path(value).resolve()==p.resolve(),(value,str(p))
pr,prior=auth('Peer-canonical-B-ingress-IO-A24-transfer-03/review.json','6bfe7736ea81fc1123ebc4ee11c64e9de64d123f3e3a92e49636f13cd9dc4dca');assert prior['accepted'] and not prior['findings']
mr,m=auth('source-compact-schedules-held-Outer-01/manifest.json','43b11fd3ee2a2f71c9488d3dd4c4787b1b52e7139524272e1d4b93b36f03a755')
rr,producer=auth('Audit-Compact-coherent-producer-Source-review-01/review.json','cbc39c0577c13cca931a104f804c10f66b6fa457727ee4ef9ee2873e04a9ab4f');assert producer['status']=='accepted' and producer['packet']==mr
fr,fix=auth('source-compact-compile-fix-held-Root-13/manifest.json','a41d1b8183ab5c8875b34511ff8d844f718870fdd691b428c8caa40abf1c1f2d')
fpr,fixpeer=auth('Peer-Compact-narrow-compiler-fix-Source-review-01/review.json','0627b3a9813aa0a78f17cf2488ec0fde2c9e04311d99bf3670242f437a7cd287')
assert fixpeer['accepted'] and not fixpeer['findings']
plan=json.loads(checked(fix['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert len(rows)==4478 and sum(n.endswith('.rs') for n in rows)==4465
commands={}
for label,name,sha,exit_code in [
 ('check','canonical-source-compact-all-targets-Root-13-02/receipt.json','fc934dbdfe10a203796c14cfec61409ffa0ac2446848150d853d9d650108ca7b',0),
 ('test','canonical-source-compact-native-cohort-Root-13/receipt.json','a7fc46c979de81ed6179c940cd7921fcb95435817e1af2a5c46c31e446565cbc',0),
 ('B','canonical-source-compact-B-NOLIMIT-24H-command-Root-13/receipt.json','3144d1544002b39678eda01ff8e3df4612fcc9a1c24bbe011564455e3f7abc59',6),
 ('A24','canonical-source-compact-A-24H-command-Root-13/receipt.json','c16dcdf62c193e0b776a5a677f566aa4e349fcba5f9391db650b7167954090a8',0),
]:
 cr,c=auth(name,sha);assert c['exit_code']==exit_code and c['launch_error'] is None and c['source_bytes_match_before_and_after'];checked(c['stdout']);checked(c['stderr']);commands[label]=(cr,c)
snap=commands['check'][1]['source_snapshot'];assert all(c['source_snapshot']==snap for _,c in commands.values())
snapshot=json.loads(checked(snap));actual={v['historical_path']:v for v in snapshot['files']};assert set(actual)==set(rows)
for n,v in actual.items():
 b=checked(v['archive']);assert v['size_bytes']==len(b)==rows[n]['final_bytes'] and v['archive']['sha256']==rows[n]['final_sha256']
selected={f['canonical_path']:f for f in m['files']};selected.update({f['canonical_path']:f for f in fix['files']});assert len(selected)==17
for n,f in selected.items():assert (R/n).read_bytes()==checked(f['proposed'])==checked(actual[n]['archive'])
test=commands['test'][1];stdout=checked(test['stdout']);assert b'running 1 test' in stdout and b'test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout
assert test['command'].count('heat_balance::selected_schedule_manager::compact_native_tests::compact_primary_and_empty_hour_match_native_reported_timestep_bits')==1 and '--exact' in test['command']
def core(c,fresh):
 found={}
 for line in checked(c['stdout']).splitlines():
  try:o=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if not isinstance(o,dict) or o.get('reason')!='compiler-artifact':continue
  name=o['target']['name']
  if name not in ['ep_runtime','ep_run','eplus-rs']:continue
  assert name not in found and o['fresh'] is fresh
  crate='ep_cli' if name=='eplus-rs' else name
  same_path(o['manifest_path'],R/f'crates/{crate}/Cargo.toml')
  same_path(o['target']['src_path'],R/f'crates/{crate}/src/{"main" if name=="eplus-rs" else "lib"}.rs')
  q=copy.deepcopy(o);q.pop('fresh');found[name]=q
 assert len(found)==3
 return found
assert core(commands['B'][1],False)==core(commands['A24'][1],True)
A=D/'canonical-source-compact-A-24H-Root-13/output';B=D/'canonical-source-compact-B-NOLIMIT-24H-Root-13/output';old=D/'canonical-source-B-raw-IO-A-24H-Root-12/output'
bs=json.loads((B/'run-summary.json').read_bytes());bd=json.loads((B/'diagnostics.json').read_bytes());assert bs['exit_code']==6 and bs['rust_runtime'] is None
errors=[v for v in bd['diagnostics'] if v['severity']=='error'];assert len(errors)==1 and errors[0]['message']=='GetHeatBalanceInput: positive nominal controlled Zone lookup'
assert (B/'results').is_dir() and not any((B/'results').iterdir())
whole=[]
for ext in ['eso','mtr','eio','audit','shd','rdd','mdd']:
 p=A/f'eplusrs.{ext}';q=old/f'eplusrs.{ext}';assert p.read_bytes()==q.read_bytes();whole.append(dict(current=ref(p),accepted12=ref(q)))
nowbytes=(A/'results/source-reported-results.json').read_bytes();oldbytes=(old/'results/source-reported-results.json').read_bytes();now=json.loads(nowbytes);previous=json.loads(oldbytes);bridged=nowbytes
for stream in ['eso','mtr']:
 same_path(now[stream]['path'],A/f'eplusrs.{stream}');same_path(previous[stream]['path'],old/f'eplusrs.{stream}')
 a=json.dumps(now[stream]['path']).encode();b=json.dumps(previous[stream]['path']).encode();assert bridged.count(a)==1;bridged=bridged.replace(a,b,1)
assert bridged==oldbytes
csv=[]
for stream in ['eso','mtr']:
 p=A/f'results/source-{stream}.csv';q=old/f'results/source-{stream}.csv';assert p.read_bytes()==q.read_bytes();csv.append(dict(current=ref(p),accepted12=ref(q)))
s=json.loads((A/'run-summary.json').read_bytes());previous_summary=json.loads((old/'run-summary.json').read_bytes());assert s['exit_code']==0 and s['oracle'] is None and s['config']['compare_oracle'] is False and s['config']['oracle_baseline'] is False
runtime=copy.deepcopy(s['rust_runtime']);assert runtime['execution']=='actual Source ManageSimulation successful through620' and runtime['native_environment_hour_scope']==24
for current,prev in zip(runtime['reported_streams'],previous_summary['rust_runtime']['reported_streams'],strict=True):
 same_path(current['owned_path'],A/Path(prev['owned_path']).name);current['owned_path']=prev['owned_path']
assert runtime==previous_summary['rust_runtime']
metadata=json.loads(checked(prior['all_table_metadata_differences']));allowed={(v['format'],v['line']):v for v in metadata['actual_vs_canonical11_all_uncapped']}
t=ast.parse((D/'check-canonical-B-ingress-IO-A24-transfer-Peer-03.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='typed_metadata')],type_ignores=[]),'<existing-strict-metadata>','exec'))
table_changes=[];tables=[];line_count=0
for ext in ['csv','tab','txt','htm','xml']:
 p=A/f'eplustbl.{ext}';q=old/f'eplustbl.{ext}';x=p.read_bytes().splitlines(keepends=True);y=q.read_bytes().splitlines(keepends=True);assert len(x)==len(y);line_count+=len(x)
 for ordinal,(a,b) in enumerate(zip(x,y),1):
  if a==b:continue
  proof=allowed[(ext,ordinal)];assert proof['classification'] in ['actual wall clock','actual wall date'] and typed_metadata(a,b,proof['classification'],ext)
  table_changes.append(dict(format=ext,line=ordinal,classification=proof['classification'],current_raw_hex=a.hex(),accepted12_raw_hex=b.hex()))
 tables.append(dict(current=ref(p),accepted12=ref(q),lines=len(x)))
assert line_count==19312
policy=R/'energyplus_porting_plan/contracts/output-tolerances.json';assert ref(policy)['sha256']=='d3cd3e5956ce7e02dbcebe9e8c48799673b66c7b181d932f57514a949dcbf698'
O.mkdir();p=O/'table-clock-differences.json';p.write_text(json.dumps(table_changes,indent=2)+'\n',encoding='utf8',newline='\n');ledger=ref(p)
artifacts=[ref(A/'results/source-reported-results.json'),ref(A/'run-summary.json'),ref(A/'diagnostics.json'),ref(B/'run-summary.json'),ref(B/'diagnostics.json')]+[v['current'] for v in whole+csv+tables]+[ledger]
p=O/'review.json';result=dict(schema='src06-compact-actual-cohort-and-A24-transfer.v1',accepted=True,findings=[],producer=mr,producer_peer=rr,compiler_correction=fr,compiler_correction_peer=fpr,complete_compiler_plan=fix['complete_final_compiler_Source_plan'],actual_check=commands['check'][0],actual_native_cohort=commands['test'][0],actual_B=commands['B'][0],actual_A24=commands['A24'][0],same4478_archived_inputs_exact_final_plan=True,selected17_final_sources_exact=True,first_B_core_fresh_false=True,A24_same_core_reused_fresh_true=True,Native_paired_exact_scalar_checks=960,Native_paired_cohorts=2,actual_test_bodies_executed=1,B_frontier=errors[0]['message'],B_runtime_or_fallback_results=False,accepted12_full5352_proof=pr,whole_physical_streams_equal12=whole,whole_CSV_equal12=csv,whole_JSON_equal12_after_exactly_two_owned_path_field_bridges=True,full_runtime_equal12_after_two_owned_path_bridges=True,transferred_reported_series=58,transferred_JSON_CSV_scalar_roundtrips=5352,full_tables=tables,table_lines=line_count,table_clock_metadata_changes=len(table_changes),table_clock_ledger=ledger,unchanged_original_tolerance_policy=ref(policy),original_tolerance_RMSE_5352_proof_transferred=True,explicit_A_storage_correction='Same MissingDay0 owner now resized24 to96 zeros at Native1269; unchanged reported outputs do not certify old storage.',publication_artifacts=artifacts,limits='Narrow exact Native paired Compact unit test plus actual A24 regression. B genuinely passes prior nonconstant-schedule boundary and stops at positive nominal-controlled Zone lookup before equipment/Node execution. No new72h/annual execution, internal-state equivalence, fullB or gate/card completion.',main_mutations=0,new_test_bodies=0,policy_changes=0,gate_changes=0,author_Source=ref(Path(__file__).resolve()))
p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

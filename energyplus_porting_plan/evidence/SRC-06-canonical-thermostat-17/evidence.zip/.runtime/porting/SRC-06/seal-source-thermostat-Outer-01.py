"""Seal isolated Source17 only after Root supplies the clean committed16 HEAD."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, re, subprocess

R = Path(__file__).resolve().parents[3]
B = R / '.runtime/porting/SRC-06'
D = B / 'source-thermostat-draft-Outer-01'
O = B / 'source-thermostat-held-Outer-01'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
args = argparse.ArgumentParser()
args.add_argument('--committed16-head', required=True)
HEAD = args.parse_args().committed16_head

def ref(p):
    data = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def get(record):
    p = R / record['path']; actual = ref(p)
    assert actual['sha256'] == record['sha256']
    assert actual['bytes'] == record.get('bytes', actual['bytes'])
    return p

def load(p):
    return json.loads(p.read_bytes())

assert re.fullmatch('[0-9a-f]{40}', HEAD)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=R), 'Root16 must be committed clean'
assert not O.exists(), 'immutable output already exists'
review_path = B / 'Root-source-Node-lifecycle-actual-review-16/review.json'
assert ref(review_path)['sha256'] == '80a38621a8b95eaff7917308d473696ab7c448ac6bc7366a5f674f554cb497b9'
review = load(review_path)
assert review['accepted'] and not review['findings'] and review['B_frontier'] == 'GetHeatBalanceInput: positive thermostat getObjectItem332'
assert review['B_Node_lifecycle_execution']['setup_returned'] is False
assert review['B_Node_lifecycle_execution']['reset_returned'] is False
assert review['same4487_archived_inputs_exact_final_plan'] is True
snapshots = []
for key, expected in [('actual_owner_test', 0), ('actual_B', 6), ('actual_A24', 0)]:
    receipt = load(get(review[key]))
    assert receipt['exit_code'] == expected and receipt['launch_error'] is None
    assert receipt['source_bytes_match_before_and_after'] is True
    snapshots.append(get(receipt['source_snapshot']))
assert snapshots[0].read_bytes() == snapshots[1].read_bytes() == snapshots[2].read_bytes()
snapshot = snapshots[1]
before = {row['historical_path']: row for row in load(snapshot)['files']}
assert len(before) == 4487 and sum(name.endswith('.rs') for name in before) == 4474
parent_plan_path = get(review['complete_compiler_plan'])
parent_plan = {row['path']: row for row in load(parent_plan_path)['entries']}
assert set(parent_plan) == set(before)
for name, record in before.items():
    archived = get(record['archive']).read_bytes()
    assert len(archived) == record['size_bytes']
    assert parent_plan[name]['final_sha256'] == hashlib.sha256(archived).hexdigest()
    assert (R/name).read_bytes() == archived

proposed = {p.relative_to(D/'proposed').as_posix(): p.read_bytes() for p in sorted((D/'proposed').rglob('*.rs'))}
assert len(proposed) == 13 and len(load(D/'freeze.json')['sources']) == 11
status_by = {row['path']: row for row in load(D/'draft-status.json')['sources']}
assert set(status_by) == set(proposed)
for name, data in proposed.items():
    assert status_by[name]['sha256'] == hashlib.sha256(data).hexdigest()
    if (D/'parent'/name).exists():
        old = (D/'parent'/name).read_bytes()
        assert old == (R/name).read_bytes() == get(before[name]['archive']).read_bytes()
        assert old == subprocess.check_output(['git', 'show', HEAD+':'+name], cwd=R)
        assert old == subprocess.check_output(['git', 'show', load(D/'freeze.json')['observed_head']+':'+name], cwd=R)
    else:
        assert name not in before and not (R/name).exists()
        old = b''
    additions = '\n'.join(line[1:] for line in difflib.unified_diff(old.decode().splitlines(), data.decode().splitlines())
                          if line.startswith('+') and not line.startswith('+++')).encode()
    assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unreachable|unimplemented)!', additions)
    assert b'#[test]' not in additions and b'ZONE ONE' not in additions
    assert b'.runtime' not in additions

helper = (B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')
function = next(node for node in ast.parse(helper).body if isinstance(node, ast.FunctionDef) and node.name == 'apply_literal')
namespace = {'re': re}
exec(compile(ast.Module(body=[function], type_ignores=[]), '<independent-literal-applier>', 'exec'), namespace)
assert subprocess.check_output(['git', '-C', str(N), 'rev-parse', 'HEAD']).decode().strip() == PIN
O.mkdir()

def put(name, data):
    p = O/name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
    return ref(p)

def doc(name, value):
    return put(name, (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode('utf8'))

files = []; bridges = []
for number, (name, data) in enumerate(proposed.items(), 1):
    old = (D/'parent'/name).read_bytes() if (D/'parent'/name).exists() else b''
    absent = name not in before
    row = {'canonical_path': name, 'before_absent': absent,
           'before': put('before/'+name, old), 'proposed': put('proposed/'+name, data),
           'literal_inverse': put('literal-inverse/'+name, old)}
    for kind, left, right in [('forward_diff', old, data), ('inverse_diff', data, old)]:
        diff = ''.join(difflib.unified_diff(left.decode().splitlines(True), right.decode().splitlines(True),
                                          fromfile='before/'+name, tofile='proposed/'+name, n=3)).encode()
        assert namespace['apply_literal'](left, diff) == right
        row[kind] = put(f'diffs/{number:02}-{kind}.diff', diff)
    result = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'],
                            input=data, capture_output=True, cwd=R)
    assert result.returncode == 0, (name, result.stderr)
    row['Source_only_parse'] = {'exit_code': 0, 'stdout': put(f'parse/{number:02}.stdout', result.stdout),
                                'stderr': put(f'parse/{number:02}.stderr', result.stderr)}
    files.append(row)
    if not absent:
        bridges.append({'path': name, 'committed_Git': HEAD, 'frozen_Git': load(D/'freeze.json')['observed_head'],
                        'actual16_archive': before[name]['archive'], 'whole_equal': True})
assert sum(row['before_absent'] for row in files) == 2
correction_dir = D/'preseal-search-correction-01'
correction_before = (correction_dir/'before-thermostat.rs').read_bytes()
correction_after = (correction_dir/'after-thermostat.rs').read_bytes()
assert hashlib.sha256(correction_before).hexdigest() == '2c70c8d5ab16a91009d4dcdedd88768f4f228c7fe84bf83d315a4c8cb612073f'
assert proposed['crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/input/thermostat.rs'] == correction_after
for name, left, right in [('forward', correction_before, correction_after), ('inverse', correction_after, correction_before)]:
    assert namespace['apply_literal'](left, (correction_dir/(name+'.diff')).read_bytes()) == right
correction = doc('preseal-search-correction.json', {
    'kind': 'one unsealed draft semantic correction; no rejected or superseded sealed variant',
    'finding_and_fix': load(correction_dir/'correction.json'),
    'before': put('preseal-search-correction/before-thermostat.rs', correction_before),
    'after': put('preseal-search-correction/after-thermostat.rs', correction_after),
    'forward': put('preseal-search-correction/forward.diff', (correction_dir/'forward.diff').read_bytes()),
    'inverse': put('preseal-search-correction/inverse.diff', (correction_dir/'inverse.diff').read_bytes()),
    'before_status': put('preseal-search-correction/before-status.json', (correction_dir/'before-status.json').read_bytes()),
    'additional_literal_applications': 2,
})

plan_path = B/'source-thermostat-read-only-plan-Outer-01/plan.json'
assert ref(plan_path)['sha256'] == '02b397f3cc1f88ec705d38a69d3b4def2a3ae32a73228d15ef1834491b4f43d8'
planning = load(plan_path)
wholes = planning['native_wholes'].copy()
for path in ['src/EnergyPlus/InputProcessing/IdfParser.cc', 'third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh',
             'src/EnergyPlus/UtilityRoutines.hh', 'src/EnergyPlus/UtilityRoutines.cc']:
    p = N/path; data = p.read_bytes()
    assert data == subprocess.check_output(['git', '-C', str(N), 'show', PIN+':'+path])
    wholes.append({**ref(p), 'whole_equals_git': PIN})
for whole in wholes:
    p = get(whole)
    native_name = p.relative_to(N).as_posix()
    assert p.read_bytes() == subprocess.check_output(['git', '-C', str(N), 'show', PIN+':'+native_name])
extents_path = B/'source-thermostat-read-only-plan-Outer-01/native-extents.json'
extents = load(extents_path)
for native_name, first, last in [
    ('src/EnergyPlus/ZoneTempPredictorCorrector.cc', 150, 161),
    ('src/EnergyPlus/InputProcessing/IdfParser.cc', 308, 463),
    ('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh', 566, 591),
    ('src/EnergyPlus/UtilityRoutines.hh', 439, 475),
    ('src/EnergyPlus/UtilityRoutines.hh', 554, 575),
]:
    literal = b''.join((N/native_name).read_bytes().splitlines(True)[first-1:last])
    extents.append({'native_path': native_name, 'first': first, 'last': last,
                    'utf8_sha256': hashlib.sha256(literal).hexdigest(), 'literal': literal.decode()})
for extent in extents:
    data = b''.join((N/extent['native_path']).read_bytes().splitlines(True)[extent['first']-1:extent['last']])
    # The earlier read-only plan stored decoded splitlines retaining LF; all
    # selected Native wholes are exact UTF8/LF and independently Git-authenticated.
    assert data.decode() == extent['literal'] and hashlib.sha256(data).hexdigest() == extent['utf8_sha256']
native_extents = doc('Native-literal-extents.json', extents)

records = {}
controls = proposed['crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs'].decode()
for name, count in [('SourceTemperatureControlledZone', 32), ('SourceTemperatureSetpointType', 4)]:
    body = controls.split('struct '+name+' {', 1)[1].split('\n}', 1)[0]
    members = re.findall(r'^\s+pub\(crate\) (\w+):', body, re.M)
    assert len(members) == count
    records[name] = {'field_count': count, 'fields': members}
constructors = doc('constructor-and-input-custody.json', {
    'records': records,
    'TempControlledZone': 'All32 Native DataZoneControls.hh99-154 fields represented. Name/ZoneName empty, ActualZoneNum0, setpoint/control/opTemp/overcool/dehumidifying pointers null, actual5 setpt records. All explicit booleans false/numerics0; both TempCtrl modes Invalid-1, not None0. Actual vector is constructor-unallocated and allocated after real positive prescan count.',
    'TempControlledZoneIndex': 'Same SelectedZoneData field Native DataHeatBalance.hh606 ctor0; actual getter419 writes same controlled-zone index. Distinct from nominal control/system node/humidity fields.',
    'regular_local_arrays': 'NeededControlTypes MustHave/DidHave5false; actual positive allocation then deallocation806. Whole Native regular TStatControlTypes occurrence census has no field writers; comfort locals are separate. CTSchedMapToControlledZone actual int0 dimension remains alive until input function return.',
    'physical_counts': 'New Thermostat IDF target uses existing whole validated staged scanner/name/order reconciliation and adds only this family to actual max-fields transfer. Schema has no min_fields/extensibles. EOF without semicolon is explicitly unavailable before metadata application. Direct epJSON derives Native highest present legacy position/min0. Getter NumAlphas actual name increment/min(maxFields,11) and numeric count iff physical field12. Dual dead physical counts are deliberately unrepresented, never fabricated.',
    'numeric_conversion': 'Numeric JSON signed-integer branch converts through i64 before f64 (integer -0 becomes +0), floating branch parses as binary64. Unsupported unsigned outside signed Native conversion domain remains typed unavailable. No decimal rounding, injected temperatures or Native answers.',
    'format_owner': 'Existing reports.heat_balance_input Option<SelectedHeatBalanceInput>.source_is_epjson bool is borrowed by reference through existing Source views. SelectedHeatBalanceInputState has no such member; no new retained flag or alternate owner.',
    'schedule_owner': 'Existing body-selected mutable ScheduleManager reborrowed through same surface/HVAC/predictor views. Actual get_source_schedule isUsed propagation, same cache/min-max and exact FLT_EPSILON inclusive check. Constant hasVal compares actual currentVal; Detailed traversal remains explicit unported3433.',
})

by = {row['canonical_path']: row for row in files}
entries = []
census = []
constructor_counts = dict.fromkeys(['SourceManageSurfaceOwners', 'SourceHvacOwners', 'SourceZoneAirOwners'], 0)
symbols = re.compile(r'SourceManageSurfaceOwners|SourceZoneAirOwners|SourceHvacOwners|SourceZoneAirControls|SelectedZoneData\s*\{|IDF_ORDER_TARGETS')
for name, old in sorted(before.items()):
    record = by[name]['proposed'] if name in by else {**old['archive'], 'bytes': old['size_bytes']}
    entries.append({'path': name, 'final_sha256': record['sha256'], 'final_bytes': record['bytes'], 'source': record,
                    'origin': 'held Source17 Thermostat proposal' if name in by else 'exact actual16 archived parent'})
    if name.endswith('.rs'):
        data = proposed[name] if name in proposed else get(old['archive']).read_bytes()
        for line, text in enumerate(data.decode('utf8').splitlines(), 1):
            if symbols.search(text): census.append({'path': name, 'line': line, 'literal': text})
            for constructor in constructor_counts:
                constructor_counts[constructor] += len(re.findall(r'\b'+constructor+r'\s*\{', text))
for name, row in by.items():
    if name in before: continue
    record = row['proposed']; entries.append({'path': name, 'final_sha256': record['sha256'], 'final_bytes': record['bytes'],
                                             'source': record, 'origin': 'new held Source17 child'})
    for line, text in enumerate(proposed[name].decode().splitlines(), 1):
        if symbols.search(text): census.append({'path': name, 'line': line, 'literal': text})
        for constructor in constructor_counts:
            constructor_counts[constructor] += len(re.findall(r'\b'+constructor+r'\s*\{', text))
assert len(entries) == 4489 and sum(row['path'].endswith('.rs') for row in entries) == 4476
assert constructor_counts == {'SourceManageSurfaceOwners': 1, 'SourceHvacOwners': 2, 'SourceZoneAirOwners': 1}
complete = doc('complete-final-compiler-Source-plan.json', {'base_HEAD': HEAD, 'parent_actual_snapshot': ref(snapshot),
    'inputs': len(entries), 'Rust_sources': 4476, 'entries': sorted(entries, key=lambda row: row['path']),
    'Root_full_rehash_required': True})
api = doc('whole-crates-concrete-API-inventory.json', {'scope': 'All4489 logical final compiler inputs; all4476 Rust wholes scanned including runtime/tests. No heat_balance-only caller search.',
    'occurrences': census, 'actual_constructor_counts': constructor_counts,
    'existing_SelectedZoneData_test_literals': 'All5 actual test literals (ordinary_tests3, runtime/tests/ctf_ordinary_outputs2) use ..Default::default(); no adapter or test-body change needed.',
    'concrete_type_authorities': [before[name]['archive'] for name in [
        'crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs',
        'crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs',
        'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/input.rs',
        'crates/ep_runtime/src/heat_balance/selected_input_processor.rs',
        'crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs']]})
contract = doc('integration-contract.json', {
    'scope': 'Actual observed16 thermostat332 -> genuine valid finite one-zone DualSetpoint GetZoneAirSetPoints input function return. Source only; no actual17/wholeB/Node lifecycle claim.',
    'same_owners': 'Sole existing controller.controls TempControlledZone + flags.tempSetptScheds, same actual Zone rows/TempControlledZoneIndex, same IP raw/statistics/unused owner and shared shortcut arrays, same mutable ScheduleManager. No typed thermostat projection/cached schedule samples/copied values/extra permanent flags.',
    'sequence': 'Actual first prescan getter332/TStat name/Zone/start/count; real allocations379-381; second getter386/duplicate/Zone index/name/GetSchedule/checkMinMax; exact blank-driven NumAlphas rewrites/nint/setpts/physical NumNums/cutout. Actual four-family counts/allocations, Dual getter637, actual link and schedule validation/NeededControlTypes/deallocation806. Existing zero other controls/capacitance/EIO/staged suffix and final ErrorsFound2171 guard retained through genuine valid return.',
    'constructor_and_input_custody': constructors,
    'borrows': 'No16 path overlap. SourceHvacOwners schedules changes from immutable to mutable same-manager borrow; existing gains/report consumers reborrow it immutably. Existing raw input-format bool is referenced through actual four constructors. Whole-crates inventory includes runtime/tests and concrete member definitions.',
    'bounds': ['ZoneList thermostat expansion remains at actual first FindItem/rewrite operation.', 'SingleHeating/SingleCooling/SingleHeatCool positive getters remain after actual allocation at first unported getter.', 'Dual multi-object IDF order without overlay remains unavailable before first getter; single finite ordinal exact. Direct epJSON uses retained actual JSON order.', 'Invalid/error diagnostics stop before first unported call/write; local ErrorsFound retains genuine ctorfalse on the selected valid path.', 'Non-ASCII makeUPPER/unsupported alpha scalar and out-of-domain numeric conversions remain typed boundaries.', 'Detailed hasVal remains first unported actual traversal3433; finite control schedule is actual Constant from input.', 'Environment verification/current Dual values/EMS/comfort/predefined consumers preserve their existing separate positive stops. No relabeling as completed HVAC/endrun.', 'Node setup/reset remain unexecuted in parent16 and are not certified by this input Source packet.'],
    'A_None': 'Existing zero-control input path retains all scientific assignments/counts/streams; new real constructor members/defaults and borrowed operands are deliberate. Global raw IDF target addition changes only positive Thermostat order/max-field metadata/EOF boundary, not declarations/math/tolerance. No blanket whole-representation or Legacy JSON byte-equality claim.',
    'validation': 'Author performed13 Source-only stdin parses/26 literal applications, no Cargo/tests/Native/main. Root owns one meaningful existing runtime test and actualB/A24. No new tests, broad suite or duplicate alltargets requirement.',
    'no_approximation_or_policy_change': True, 'new_tests': 0, 'main_mutations': 0,
})
manifest = doc('manifest.json', {
    'schema': 'src06-held-cohesive-finite-Thermostat-input.v1', 'status': 'HELD Source only; compilation/actual17 pending',
    'base_HEAD': HEAD, 'actual16_review': ref(review_path), 'actual16_snapshot': ref(snapshot), 'actual16_complete_plan': ref(parent_plan_path),
    'actual16_B': review['actual_B'], 'actual16_A24': review['actual_A24'], 'actual16_test': review['actual_owner_test'],
    'precise_selected_parent_bridges': bridges, 'files': files, 'existing_Source_files': 11, 'new_Source_files': 2,
    'literal_applications': 26, 'Source_only_parses': 13, 'complete_final_compiler_Source_plan': complete,
    'constructor_records': constructors, 'whole_crates_API_inventory': api, 'integration_contract': contract,
    'Native_commit': PIN, 'Native_wholes': wholes, 'Native_literal_extents': native_extents,
    'read_only_planning_authority': ref(plan_path), 'finite12_IDF_inventory_and_schema': ref(plan_path),
    'draft_freeze': put('draft-freeze-at-seal.json', (D/'freeze.json').read_bytes()),
    'draft_status': put('draft-status-at-seal.json', (D/'draft-status.json').read_bytes()),
    'preseal_search_correction': correction,
    'author_Source': ref(B/'author-source-thermostat-draft-Outer-01.py'), 'sealer_Source': ref(Path(__file__)),
    'new_test_bodies': 0, 'Cargo_Native_or_tests_executed': False, 'main_mutations': 0,
    'FP_tolerance_or_gate_changes': False, 'full_B_or_positive_Node_execution_claim': False,
})
print(json.dumps(manifest))

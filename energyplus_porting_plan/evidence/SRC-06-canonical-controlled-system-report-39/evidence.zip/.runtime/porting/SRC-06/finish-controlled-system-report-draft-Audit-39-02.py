import difflib,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.runtime/porting/SRC-06'
OLD=BASE/'source-controlled-system-report-draft-Audit-39'
OUT=BASE/'source-controlled-system-report-draft-Audit-39-02'
assert not OUT.exists();OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def get(r):
 p=Path(r['path']);p=p if p.is_absolute() else ROOT/p;b=p.read_bytes();assert sha(b)==r['sha256'];return b
old_ref=ref(OLD/'draft.json');assert old_ref['sha256']=='5fb05520dc99acb0ef6c90e686acbf091478708117dd9aacefc6f8ff11044d65'
old=json.loads(get(old_ref))
def diff_apply(raw,diff):
 src=raw.decode().splitlines(keepends=True);out=[];pos=0;ls=diff.splitlines(keepends=True);i=2
 while i<len(ls):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ls[i]);assert m
  start=int(m[1])-(int(m[2] or '1')!=0);out.extend(src[pos:start]);pos=start;i+=1
  while i<len(ls) and not ls[i].startswith('@@ '):
   line=ls[i];i+=1
   if line[0] in ' -':assert src[pos]==line[1:];pos+=1
   if line[0] in ' +':out.append(line[1:])
 out.extend(src[pos:]);return ''.join(out).encode()
files=[];changed=[];unchanged=[]
for row in old['files']:
 name=row['canonical_path'];before=get(row['before']);previous=get(row['proposed']);new=previous
 if name.endswith('/ordinary_hvac_manager/remaining.rs'):
  s=previous.decode();needle='    ordinary_system_reports::{SourceSystemReportOwners, SourceSystemReports},'
  assert s.count(needle)==1;s=s.replace(needle,'    ordinary_system_reports::SourceSystemReports,',1)
  start=s.index("    fn system_owners<'a>(");end=s.index('    fn facility<',start)
  removed=s[start:end];assert 'SourceSystemReportOwners {' in removed
  s=s[:start]+s[end:];new=s.encode();changed.append(name)
  narrow=''.join(difflib.unified_diff(previous.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='draft01/'+name,tofile='draft02/'+name))
  narrow_inverse=''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),previous.decode().splitlines(keepends=True),fromfile='draft02/'+name,tofile='draft01/'+name))
  assert diff_apply(previous,narrow)==new and diff_apply(new,narrow_inverse)==previous
  correction={'original_proposal':row['proposed'],'final_proposal':put(OUT/'correction'/'remaining.rs',new),'forward':put(OUT/'correction'/'forward.diff',narrow.encode()),'inverse':put(OUT/'correction'/'inverse.diff',narrow_inverse.encode()),'literal_recovery_exact':True,'scope':'Remove obsolete uncalled SystemReportOwners constructor and its now-unused import after two report-local calls; no report/body/property changes.'}
 else:unchanged.append(name)
 fr=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name))
 inv=''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 assert diff_apply(before,fr)==new and diff_apply(new,inv)==before
 proposed=put(OUT/'proposed'/name,new)
 parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',proposed['path']],capture_output=True);assert parse.returncode==0,parse.stderr
 files.append({'canonical_path':name,'before_absent':False,'before':put(OUT/'before'/name,before),'proposed':proposed,'forward_diff':put(OUT/'diffs'/(name+'.forward.diff'),fr.encode()),'inverse_diff':put(OUT/'diffs'/(name+'.inverse.diff'),inv.encode()),'literal_forward_exact':True,'literal_inverse_exact':True,'Source_only_parse':put(OUT/'parse'/(name+'.json'),(json.dumps({'command':['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',proposed['path']],'exit_code':0,'stderr':parse.stderr.decode(),'formatted_stdout_sha256':sha(parse.stdout),'syntax_only_not_typecheck':True},indent=2)+'\n').encode())})
assert len(changed)==1 and len(unchanged)==5
correction['other_five_proposal_wholes_exact']=unchanged
correction_ref=put(OUT/'correction-proof.json',(json.dumps(correction,indent=2)+'\n').encode())
needles=['report_source_system_energy_use','report_source_ventilation_loads','source_purchased_air_out_air_mass_flow','source_purchased_air_zone_inlet_air_node','source_purchased_air_return_air_node','source_purchased_air_mixed_air_temperature','source_purchased_air_mixed_air_humidity_ratio','source_purchased_air_report_input','calculate_source_design_specification_outdoor_air','source_zone_equipment_list','SourceSystemReportOwners','system_owners']
ledger=[]
for path in sorted((ROOT/'crates').rglob('*.rs')):
 b=path.read_bytes();lines=b.decode('utf-8').splitlines();hits=[]
 for i,line in enumerate(lines,1):
  names=[n for n in needles if n in line]
  if names:hits.append({'line':i,'names':names,'text':line})
 ledger.append({'canonical_path':path.relative_to(ROOT).as_posix(),'sha256':sha(b),'bytes':len(b),'hits':hits})
census=put(OUT/'whole-crates-API-census.json',(json.dumps({'scope':'Every existing Rust file under crates, whole-byte hashes and ordered bounded API hits; observed current Root38 WIP, not Git-clean/full-compiler-plan proof.','needles':needles,'files':ledger},indent=2)+'\n').encode())
draft=dict(old);draft.update({'schema':'src06-controlled-system-report-draft39-02.v1','author_Source':ref(Path(__file__)),'original_draft':old_ref,'self_check_cleanup':correction_ref,'files':files,'whole_crates_API_census':census,'activation_status':'Isolated proposal only. Actual38 B02 has observed ReportSystemEnergyUse3155; final custody waits authenticated completed actual38/committed parent and independent full Source semantic peer.','Native_authorities':json.loads(get(old['read_only_plan']))['Native_authorities'],'concrete_same_owner_contexts':json.loads(get(old['read_only_plan']))['concrete_Source_contexts']})
p=OUT/'draft.json';p.write_text(json.dumps(draft,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

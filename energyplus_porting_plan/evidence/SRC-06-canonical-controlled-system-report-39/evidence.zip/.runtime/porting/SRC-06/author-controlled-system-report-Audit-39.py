import difflib,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.runtime/porting/SRC-06'
OUT=BASE/'source-controlled-system-report-draft-Audit-39'
assert not OUT.exists()
OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def replace(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
P='crates/ep_runtime/src/heat_balance/'
proposals={}
report=r'''//! Actual SystemReports controlled-zone report bodies on the sole live owners.
use super::*;
use crate::heat_balance::ordinary_air_heat_balance::{
    SourceAirHeatBalance,
    predictor_corrector::{SourceZoneAirDemand, SourceZoneAirReports},
};
use crate::heat_balance::selected_sizing::SelectedSizingManager;
use crate::psychrometrics::{energyplus_psy_h_fn_tdb_w, energyplus_psy_rho_air_fn_pb_tdb_w};
use crate::weather::day::WeatherEnvironmentState;

// ObjexxFCL double max338-355 retains its first operand on equality/NaN.
fn cpp_max(a: f64, b: f64) -> f64 { if a < b { b } else { a } }

impl SourceSystemReports {
    pub(crate) fn report_source_system_energy_use(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
        hvac: &SelectedHvacGlobals,
        equipment: &OrdinaryEquipment,
        demand: &SourceZoneAirDemand,
    ) -> Result<(), Error> {
        let _time_step_sys_sec = hvac.time_step_sys_seconds;
        if !self.air_loop_loads_report_enabled { return Ok(()); }
        if hvac.number_of_primary_air_systems > 0 {
            return Err(Error::Unavailable("actual ReportSystemEnergyUse3020 SysLoadRepVars live row before resets"));
        }
        // Actual primary reset3019 and component3067 loops have no rows here.
        for zone in 1..=globals.num_of_zones {
            let config = equipment.source_zone_equipment_config(zone)?;
            if !*config.is_controlled() { continue; }
            let mut zone_load = demand.zones.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportSystemEnergyUse3155 ZoneSysEnergyDemand row"))?
                .base.total_output_required;
            if *demand.deadband_or_setback.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportSystemEnergyUse3158 DeadBandOrSetback"))? {
                zone_load = 0.0;
            }
            // Native reads this local even though its controlled suffix does not use it.
            let _zone_load = zone_load;
            for inlet in 1..=*config.number_inlet_nodes() {
                let air_loop = *config.inlet_node_air_loop_number(inlet)
                    .ok_or(Error::Unavailable("actual ReportSystemEnergyUse3165 InletNodeAirLoopNum"))?;
                if air_loop == 0 { continue; }
                return Err(Error::Unavailable("actual ReportSystemEnergyUse3170 positive AirDistUnitCool/Heat reporting child"));
            }
        }
        // Actual final primary sum3279 is likewise empty.
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn report_source_ventilation_loads(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
        hvac: &SelectedHvacGlobals,
        equipment: &OrdinaryEquipment,
        zones: &mut SelectedZoneInputOwners,
        demand: &SourceZoneAirDemand,
        air_reports: &SourceZoneAirReports,
        air: &SourceAirHeatBalance,
        environment: &WeatherEnvironmentState,
        sizing: &SelectedSizingManager,
        predefined_summary: &mut SourceComfortPredefinedSummary,
    ) -> Result<(), Error> {
        // This is the report-local Native threshold, distinct from HVAC::SmallLoad.
        const SMALL_LOAD: f64 = 0.1;
        const SMALL_AIR_VOL_FLOW: f64 = 0.001;
        let time_step_sys = hvac.time_step_sys;
        let time_step_sys_sec = hvac.time_step_sys_seconds;
        if !self.vent_report_structure_created { return Ok(()); }
        if !self.vent_loads_report_enabled { return Ok(()); }
        for zone in 1..=globals.num_of_zones {
            // Native takes this real row reference before IsControlled.
            let row = self.zone_vent_rep_vars.as_mut().and_then(|v| v.get_mut(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ZoneVentRepVars3857 live row"))?;
            if !*equipment.source_zone_equipment_config(zone)?.is_controlled() { continue; }
            row.oa_mass_flow = 0.0;
            row.oa_mass = 0.0;
            row.oa_vol_flow_std_rho = 0.0;
            row.oa_vol_std_rho = 0.0;
            row.oa_vol_flow_crnt_rho = 0.0;
            row.oa_vol_crnt_rho = 0.0;
            row.mech_ach = 0.0;
            row.target_ventilation_flow_voz = 0.0;
            row.time_below_voz_dyn = 0.0;
            row.time_at_voz_dyn = 0.0;
            row.time_above_voz_dyn = 0.0;
            row.time_vent_unocc = 0.0;
            row.cooling_load_met_by_vent = 0.0;
            row.cooling_load_added_by_vent = 0.0;
            row.overcooling_by_vent = 0.0;
            row.heating_load_met_by_vent = 0.0;
            row.heating_load_added_by_vent = 0.0;
            row.overheating_by_vent = 0.0;
            row.no_load_heating_by_vent = 0.0;
            row.no_load_cooling_by_vent = 0.0;
        }
        self.any_zone_time_below_voz_dyn = 0.0;
        self.all_zones_time_at_voz_dyn = 0.0;
        self.any_zone_time_above_voz_dyn = 0.0;
        self.any_zone_time_vent_unocc = 0.0;
        self.any_zone_time_below_voz_dyn_occ = 0.0;
        self.all_zones_time_at_voz_dyn_occ = 0.0;
        self.any_zone_time_above_voz_dyn_occ = 0.0;
        if hvac.number_of_primary_air_systems > 0 {
            return Err(Error::Unavailable("actual ReportVentilationLoads3892 SysVentRepVars live row"));
        }
        for zone in 1..=globals.num_of_zones {
            let config = equipment.source_zone_equipment_config(zone)?;
            if !*config.is_controlled() { continue; }
            let mut z_air_sys_zone_vent_load = 0.0;
            let mut z_air_sys_out_air_flow = 0.0;
            let mut zfau_flow_rate = 0.0;
            let mut zfau_zone_vent_load = 0.0;
            let mut zfau_out_air_flow = 0.0;
            let mut zone_load = demand.zones.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads3923 ZoneSysEnergyDemand row"))?
                .base.total_output_required;
            let this_zone = zones.zones.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads3924 Zone row"))?;
            let zone_mult = this_zone.multiplier.checked_mul(this_zone.list_multiplier)
                .ok_or(Error::Unavailable("actual ReportVentilationLoads3925 Native integer multiplier product domain"))?;
            let zone_volume = this_zone.volume * f64::from(zone_mult);
            let predef = zones.zone_predefined.as_mut().and_then(|rows| rows.get_mut(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads3931 ZonePreDefRep"))?;
            let row = self.zone_vent_rep_vars.as_mut().and_then(|rows| rows.get_mut(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads3932 ZoneVentRepVars"))?;
            row.target_ventilation_flow_voz = sizing.calculate_source_design_specification_outdoor_air(
                *config.zone_design_specification_outdoor_air_index(), zone, true, true,
            )?;
            if *config.zone_air_distribution_index() > 0 {
                return Err(Error::Unavailable("actual ReportVentilationLoads3938 ZoneAirDistribution.calculateEz"));
            }
            if *demand.deadband_or_setback.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads3942 DeadBandOrSetback"))? {
                zone_load = 0.0;
            }
            let list_index = i32::try_from(*config.equipment_list_index())
                .map_err(|_| Error::Unavailable("actual ReportVentilationLoads3947 EquipListIndex Native integer domain"))?;
            let list = equipment.source_zone_equipment_list(list_index)?;
            for equipment_number in 1..=*list.number_equipment_types() {
                let equipment_index = *list.equipment_index(equipment_number)
                    .ok_or(Error::Unavailable("actual ReportVentilationLoads3949 EquipIndex"))?;
                let equipment_type = *list.equipment_type(equipment_number)
                    .ok_or(Error::Unavailable("actual ReportVentilationLoads3951 EquipType"))?;
                // Exact DataZoneEquipment::ZoneEquipType underlying values.
                match equipment_type {
                    12 => {
                        zfau_out_air_flow += equipment.source_purchased_air_out_air_mass_flow(equipment_index)?;
                        let zone_inlet_air_node = equipment.source_purchased_air_zone_inlet_air_node(equipment_index)?;
                        if zone_inlet_air_node > 0 {
                            zfau_flow_rate = cpp_max(*equipment.source_zone_air_node(zone_inlet_air_node)?.mass_flow_rate, 0.0);
                        }
                        let zfau_temp_mixed_air = equipment.source_purchased_air_mixed_air_temperature(equipment_index)?;
                        let zfau_hum_rat_mixed_air = equipment.source_purchased_air_mixed_air_humidity_ratio(equipment_index)?;
                        let return_air_node = equipment.source_purchased_air_return_air_node(equipment_index)?;
                        if zfau_flow_rate > 0.0 && return_air_node > 0 {
                            let zfau_enth_mixed_air = energyplus_psy_h_fn_tdb_w(zfau_temp_mixed_air, zfau_hum_rat_mixed_air);
                            let return_node = equipment.source_zone_air_node(return_air_node)?;
                            let zfau_enth_return_air = energyplus_psy_h_fn_tdb_w(*return_node.temperature, *return_node.humidity_ratio);
                            zfau_zone_vent_load += zfau_flow_rate * (zfau_enth_mixed_air - zfau_enth_return_air) * time_step_sys_sec;
                        } else {
                            zfau_zone_vent_load += 0.0;
                        }
                    }
                    1 => return Err(Error::Unavailable("actual ReportVentilationLoads3954 FanCoil OA getter")),
                    2 | 3 | 4 => return Err(Error::Unavailable("actual ReportVentilationLoads3981 PTUnit OA getter")),
                    5 => return Err(Error::Unavailable("actual ReportVentilationLoads4010 WindowAC OA getter")),
                    7 => return Err(Error::Unavailable("actual ReportVentilationLoads4037 UnitVentilator OA getter")),
                    8 => return Err(Error::Unavailable("actual ReportVentilationLoads4084 ERV OA getter")),
                    10 => return Err(Error::Unavailable("actual ReportVentilationLoads4113 OutdoorAirUnit OA getter")),
                    11 => return Err(Error::Unavailable("actual ReportVentilationLoads4139 VRF OA getter")),
                    // Native4153-4178 explicitly excludes OA for these real types.
                    6 | 9 | 13 | 15..=32 => {}
                    _ => return Err(Error::Unavailable("actual ReportVentilationLoads4181 unsupported EquipType fatal")),
                }
            }
            for inlet in 1..=*config.number_inlet_nodes() {
                let air_loop = *config.inlet_node_air_loop_number(inlet)
                    .ok_or(Error::Unavailable("actual ReportVentilationLoads4200 InletNodeAirLoopNum"))?;
                if air_loop != 0 {
                    return Err(Error::Unavailable("actual ReportVentilationLoads4203 positive AirDistUnitCool/Heat reporting child"));
                }
                // Real MixedAirNode/ReturnAirNode remain0 for this actual association;
                // Native4251-4253 sets both per-inlet values0 before accumulation.
                let air_sys_zone_vent_load = 0.0;
                let air_sys_out_air_flow = 0.0;
                z_air_sys_zone_vent_load += air_sys_zone_vent_load;
                z_air_sys_out_air_flow += air_sys_out_air_flow;
            }
            let out_air_flow = z_air_sys_out_air_flow + zfau_out_air_flow;
            row.oa_mass_flow = out_air_flow;
            row.oa_mass = row.oa_mass_flow * time_step_sys_sec;
            row.oa_vol_flow_std_rho = row.oa_mass_flow / environment.std_rho_air;
            row.oa_vol_std_rho = row.oa_vol_flow_std_rho * time_step_sys_sec;
            let zone_air_report = air_reports.zones.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads4295 ZnAirRpt"))?;
            let tot_mech_nat_vent_vol_std_rho = row.oa_vol_std_rho
                + (zone_air_report.ventil_volume_std_density + predef.afn_vent_vol_std_den) * f64::from(zone_mult);
            let target_voz = row.target_ventilation_flow_voz * time_step_sys_sec;
            if tot_mech_nat_vent_vol_std_rho < 0.99 * target_voz {
                row.time_below_voz_dyn = time_step_sys;
                self.any_zone_time_below_voz_dyn = time_step_sys;
            } else if tot_mech_nat_vent_vol_std_rho > 1.01 * target_voz {
                row.time_above_voz_dyn = time_step_sys;
                self.any_zone_time_above_voz_dyn = time_step_sys;
            } else if tot_mech_nat_vent_vol_std_rho > SMALL_AIR_VOL_FLOW {
                row.time_at_voz_dyn = time_step_sys;
                self.all_zones_time_at_voz_dyn = time_step_sys;
            }
            let zone_heat_balance = air.zones.as_ref().and_then(|rows| rows.get(at(zone).ok()?))
                .ok_or(Error::Unavailable("actual ReportVentilationLoads4313 zoneHeatBalance"))?;
            // This real property call occurs even when actual OA mass flow is0.
            let current_zone_air_density = energyplus_psy_rho_air_fn_pb_tdb_w(
                environment.current_weather.out_baro_press, zone_heat_balance.air.mat, zone_heat_balance.air.air_hum_rat_avg,
            );
            if current_zone_air_density < 0.0 {
                return Err(Error::Unavailable("actual PsyRhoAirFnPbTdbW negative-density diagnostic Psychrometrics.hh543"));
            }
            if current_zone_air_density > 0.0 {
                row.oa_vol_flow_crnt_rho = row.oa_mass_flow / current_zone_air_density;
            }
            row.oa_vol_crnt_rho = row.oa_vol_flow_crnt_rho * time_step_sys_sec;
            if zone_volume > 0.0 {
                row.mech_ach = (row.oa_vol_crnt_rho / time_step_sys) / zone_volume;
            }
            if predef.is_occupied {
                predef.tot_time_occ += time_step_sys;
                predef.mech_vent_vol_total_occ += row.oa_vol_crnt_rho;
                if row.oa_vol_crnt_rho / time_step_sys < predef.mech_vent_vol_min {
                    predef.mech_vent_vol_min = row.oa_vol_crnt_rho / time_step_sys;
                }
                predef.mech_vent_vol_total_occ_std_den += row.oa_vol_std_rho;
                predef.infil_vol_total_occ += zone_air_report.infil_volume_cur_density;
                if zone_air_report.infil_volume_cur_density < predef.infil_vol_min {
                    predef.infil_vol_min = zone_air_report.infil_volume_cur_density;
                }
                predef.infil_vol_total_occ_std_den += zone_air_report.infil_volume_std_density;
                predef.simp_vent_vol_total_occ += zone_air_report.ventil_volume_cur_density;
                if zone_air_report.ventil_volume_cur_density < predef.simp_vent_vol_min {
                    predef.simp_vent_vol_min = zone_air_report.ventil_volume_cur_density;
                }
                predef.simp_vent_vol_total_occ_std_den += zone_air_report.ventil_volume_std_density;
                self.any_zone_time_below_voz_dyn_occ = self.any_zone_time_below_voz_dyn;
                self.all_zones_time_at_voz_dyn_occ = self.all_zones_time_at_voz_dyn;
                self.any_zone_time_above_voz_dyn_occ = self.any_zone_time_above_voz_dyn;
                predef.voz_target_total_occ += target_voz;
                predef.voz_target_time_below_occ += row.time_below_voz_dyn;
                predef.voz_target_time_at_occ += row.time_at_voz_dyn;
                predef.voz_target_time_above_occ += row.time_above_voz_dyn;
            } else if tot_mech_nat_vent_vol_std_rho > SMALL_AIR_VOL_FLOW {
                row.time_vent_unocc = time_step_sys;
                self.any_zone_time_vent_unocc = time_step_sys;
                predef.tot_vent_time_non_zero_unocc += row.time_vent_unocc;
            }
            predef.mech_vent_vol_total_std_den += row.oa_vol_std_rho;
            predef.infil_vol_total_std_den += zone_air_report.infil_volume_std_density;
            predef.simp_vent_vol_total_std_den += zone_air_report.ventil_volume_std_density;
            predef.voz_target_total += target_voz;
            predef.voz_target_time_below += row.time_below_voz_dyn;
            predef.voz_target_time_at += row.time_at_voz_dyn;
            predef.voz_target_time_above += row.time_above_voz_dyn;
            let zone_vent_load: f64 = z_air_sys_zone_vent_load + zfau_zone_vent_load;
            if zone_vent_load.abs() < SMALL_LOAD { continue; }
            if zone_vent_load > SMALL_LOAD {
                if zone_load < -SMALL_LOAD {
                    row.cooling_load_added_by_vent += zone_vent_load.abs();
                } else if zone_load > SMALL_LOAD {
                    if zone_vent_load > zone_load {
                        row.heating_load_met_by_vent += zone_load.abs();
                        row.overheating_by_vent += zone_vent_load - zone_load;
                    } else {
                        row.heating_load_met_by_vent += zone_vent_load.abs();
                    }
                } else {
                    row.no_load_heating_by_vent += zone_vent_load.abs();
                }
            } else if zone_vent_load < -SMALL_LOAD {
                if zone_load < -SMALL_LOAD {
                    if zone_vent_load < zone_load {
                        row.cooling_load_met_by_vent += zone_load.abs();
                        row.overcooling_by_vent += (zone_vent_load - zone_load).abs();
                    } else {
                        row.cooling_load_met_by_vent += zone_vent_load.abs();
                    }
                } else if zone_load > SMALL_LOAD {
                    row.heating_load_added_by_vent += zone_vent_load.abs();
                } else {
                    row.no_load_cooling_by_vent += zone_vent_load.abs();
                }
            }
        }
        // Both primary SysVent loops3891/4418 have no rows here.
        predefined_summary.total_any_zone_below_voz_dyn_for_oa += self.any_zone_time_below_voz_dyn;
        predefined_summary.total_all_zones_at_voz_dyn_for_oa += self.all_zones_time_at_voz_dyn;
        predefined_summary.total_any_zone_above_voz_dyn_for_oa += self.any_zone_time_above_voz_dyn;
        predefined_summary.total_any_zone_vent_unocc_for_oa += self.any_zone_time_vent_unocc;
        predefined_summary.total_any_zone_below_voz_dyn_occ_for_oa += self.any_zone_time_below_voz_dyn_occ;
        predefined_summary.total_all_zones_at_voz_dyn_occ_for_oa += self.all_zones_time_at_voz_dyn_occ;
        predefined_summary.total_any_zone_above_voz_dyn_occ_for_oa += self.any_zone_time_above_voz_dyn_occ;
        Ok(())
    }
}
'''
proposals[P+'ordinary_system_reports/reporting.rs']=report
path=P+'ordinary_hvac_manager/remaining.rs'
s=(ROOT/path).read_text(encoding='utf-8')
s=replace(s,'''                .report_source_system_energy_use(&Self::system_owners(
                    o,
                    &manager.simulation.air_loop,
                )),''','''                .report_source_system_energy_use(o.globals, o.hvac, o.equipment, &o.controller.demand),''')
s=replace(s,'''                .report_source_ventilation_loads(&mut Self::system_owners(
                    o,
                    &manager.simulation.air_loop,
                )),''','''                .report_source_ventilation_loads(
                    o.globals, o.hvac, o.equipment, o.zones, &o.controller.demand,
                    &o.controller.reports, o.air, o.environment, o.sizing, o.comfort_summary,
                ),''')
proposals[path]=s
path=P+'ordinary_equipment.rs'
s=(ROOT/path).read_text(encoding='utf-8')
s=replace(s,"impl SourceZoneEquipmentConfigRef<'_> {",'''impl SourceZoneEquipmentConfigRef<'_> {
    /// Actual retained indices read by normal SystemReports controlled-zone bodies.
    pub(crate) fn equipment_list_index(&self) -> &usize { &self.row.equipment_list_index }
    pub(crate) fn zone_design_specification_outdoor_air_index(&self) -> &i32 { &self.row.zone_design_specification_outdoor_air_index }
    pub(crate) fn zone_air_distribution_index(&self) -> &i32 { &self.row.zone_air_distribution_index }
    pub(crate) fn inlet_node_air_loop_number(&self, ordinal: usize) -> Option<&i32> {
        self.row.inlet_node_air_loop_numbers.as_ref()?.get(ordinal.checked_sub(1)?)
    }''')
s=replace(s,"impl SourceZoneEquipmentListRef<'_> {",'''impl SourceZoneEquipmentListRef<'_> {
    pub(crate) fn equipment_type(&self, ordinal: usize) -> Option<&i32> {
        self.row.equipment_types.as_ref()?.get(ordinal.checked_sub(1)?)
    }
    pub(crate) fn equipment_index(&self, ordinal: usize) -> Option<&i32> {
        self.row.equipment_indices.as_ref()?.get(ordinal.checked_sub(1)?)
    }''')
proposals[path]=s
path=P+'ordinary_equipment/source_purchased_air.rs'
s=(ROOT/path).read_text(encoding='utf-8')
s=replace(s,'//! Genuine PurchasedAir entry/GetPurchasedAir through the actual Init callee.','//! Genuine PurchasedAir input, calculation/update/report and live report lookups.')
s += r'''
impl OrdinaryEquipment {
    /// Every Native report getter first tests the same real lazy-input latch.
    /// The true GetPurchasedAir child needs its actual input/output host context;
    /// normal reporting reads the existing same unit after real simulation input.
    fn source_purchased_air_report_input(&self) -> Result<(), Error> {
        if self.purchased_air.get_purchased_air_input {
            return Err(Error::Unavailable("actual PurchasedAir report getter GetPurchasedAir lazy-input child"));
        }
        Ok(())
    }
    pub(crate) fn source_purchased_air_out_air_mass_flow(&self, number: i32) -> Result<f64, Error> {
        self.source_purchased_air_report_input()?;
        Ok(self.purchased_unit(number)?.outdoor_air_mass_flow_rate)
    }
    pub(crate) fn source_purchased_air_zone_inlet_air_node(&self, number: i32) -> Result<i32, Error> {
        self.source_purchased_air_report_input()?;
        let mut node = 0;
        if number > 0 && number <= self.purchased_air.number_purchased_air {
            node = self.purchased_unit(number)?.zone_supply_air_node_num;
        }
        Ok(node)
    }
    pub(crate) fn source_purchased_air_return_air_node(&self, number: i32) -> Result<i32, Error> {
        self.source_purchased_air_report_input()?;
        let mut node = 0;
        if number > 0 && number <= self.purchased_air.number_purchased_air {
            node = self.purchased_unit(number)?.zone_recirc_air_node_num;
        }
        Ok(node)
    }
    pub(crate) fn source_purchased_air_mixed_air_temperature(&self, number: i32) -> Result<f64, Error> {
        self.source_purchased_air_report_input()?;
        Ok(self.purchased_unit(number)?.mixed_air_temp)
    }
    pub(crate) fn source_purchased_air_mixed_air_humidity_ratio(&self, number: i32) -> Result<f64, Error> {
        self.source_purchased_air_report_input()?;
        Ok(self.purchased_unit(number)?.mixed_air_hum_rat)
    }
}
'''
proposals[path]=s
path=P+'selected_sizing.rs'
s=(ROOT/path).read_text(encoding='utf-8')
s+=r'''
impl SelectedSizingManager {
    /// Actual DataSizing634-671 helper: a real zero DSOA pointer returns the
    /// local initial value before touching any OARequirements/zone operands.
    pub(crate) fn calculate_source_design_specification_outdoor_air(
        &self, dsoa_pointer: i32, _actual_zone: i32,
        _use_occupancy_schedule: bool, _use_minimum_oa_schedule: bool,
    ) -> Result<f64, super::selected_heat_balance_input::HeatBalanceInputError> {
        use super::selected_heat_balance_input::HeatBalanceInputError as E;
        let total_oa_flow_rate = 0.0;
        if dsoa_pointer == 0 { return Ok(total_oa_flow_rate); }
        let index = dsoa_pointer.checked_sub(1).and_then(|v| usize::try_from(v).ok())
            .ok_or(E::Unavailable("actual calcDesignSpecificationOutdoorAir650 OARequirements ordinal"))?;
        let requirement = self.oa_requirements.as_ref().and_then(|rows| rows.get(index))
            .ok_or(E::Unavailable("actual calcDesignSpecificationOutdoorAir650 OARequirements"))?;
        if requirement.number_of_dsoa == 0 {
            return Err(E::Unavailable("actual OARequirements.calcOAFlowRate655 positive DSOA child"));
        }
        Err(E::Unavailable("actual calcDesignSpecificationOutdoorAir659 positive DSOA SpaceList child"))
    }
}
'''
proposals[path]=s
path=P+'ordinary_equipment/source_purchased_air/owners.rs'
s=(ROOT/path).read_text(encoding='utf-8')
s=replace(s,'''//! UNSEALED genuine PurchasedAir retained constructor records only.
//! No GetPurchasedAir, registration, lifecycle readiness or integration is implemented.''','''//! Complete retained PurchasedAir constructor records used by genuine input,
//! calculation/update/report, live output bindings and report lookups.''')
proposals[path]=s

files=[]
for name,proposed in proposals.items():
 before=(ROOT/name).read_bytes();new=proposed.replace('\r\n','\n').encode('utf-8')
 # Source strings retain existing LF semantic text; preserve CRLF source files
 # only when their original bytes are uniformly CRLF.
 if b'\r\n' in before and before.count(b'\r\n')==before.count(b'\n'):
  new=new.replace(b'\n',b'\r\n')
 assert new!=before
 before_ref=put(OUT/'before'/name,before);proposal_ref=put(OUT/'proposed'/name,new)
 forward=''.join(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),new.decode('utf-8').splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name))
 inverse=''.join(difflib.unified_diff(new.decode('utf-8').splitlines(keepends=True),before.decode('utf-8').splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 forward_ref=put(OUT/'diffs'/(name+'.forward.diff'),forward.encode('utf-8'))
 inverse_ref=put(OUT/'diffs'/(name+'.inverse.diff'),inverse.encode('utf-8'))
 def apply(raw,diff):
  src=raw.decode('utf-8').splitlines(keepends=True);out=[];pos=0
  import re
  ls=diff.splitlines(keepends=True);i=2
  while i<len(ls):
   match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ls[i]);assert match,ls[i]
   start=int(match[1])-(int(match[2] or '1')!=0);out.extend(src[pos:start]);pos=start;i+=1
   while i<len(ls) and not ls[i].startswith('@@ '):
    line=ls[i];i+=1
    if line[0] in ' -':assert src[pos]==line[1:],(name,pos);pos+=1
    if line[0] in ' +':out.append(line[1:])
   
  out.extend(src[pos:]);return ''.join(out).encode('utf-8')
 assert apply(before,forward)==new
 assert apply(new,inverse)==before
 parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',proposal_ref['path']],capture_output=True)
 assert parse.returncode==0,(name,parse.stderr.decode())
 parse_ref=put(OUT/'parse'/(name+'.json'),(json.dumps({'command':['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',proposal_ref['path']],'exit_code':parse.returncode,'stderr':parse.stderr.decode(),'formatted_stdout_sha256':sha(parse.stdout),'syntax_only_not_typecheck':True},indent=2)+'\n').encode())
 files.append({'canonical_path':name,'before':before_ref,'proposed':proposal_ref,'forward_diff':forward_ref,'inverse_diff':inverse_ref,'literal_forward_exact':True,'literal_inverse_exact':True,'Source_only_parse':parse_ref})
plan_ref=ref(BASE/'prospective-controlled-system-report-readonly-Audit-39/plan.json')
assert plan_ref['sha256']=='4c30f7338513240f0ad2f17aa69ede0b156259257680bc2e471e9c0b6a63c9e2'
draft={'schema':'src06-controlled-system-report-draft39.v1','author_Source':ref(Path(__file__)),'read_only_plan':plan_ref,'files':files,'selected_existing_sources':len(files),'new_sources':0,'literal_applications':2*len(files),'fresh_syntax_parses':len(files),'Cargo_runs':0,'tests_executed':0,'Native_executions':0,'activation_status':'Isolated proposal only; final custody waits accepted actual38/committed parent and independent full semantic peer.','scope':'Whole normal controlled PurchasedAir ReportSystemEnergyUse and ReportVentilationLoads, including all20 live outputs/facility7 and existing22 ZonePredef writes; real inlet airloop0 predicates, real DSOA0 early helper, normal H/Rho and unchanged property diagnostic boundary.','qualifications':['true PurchasedAir GetInput latch is first-operation child boundary; no full lazy getter parity claim','positive primary/ADU/other equipment/DSOA/airdistribution children remain exact typed boundaries','NoOA does not imply thermalvent0; real retained mixed vs current return consumed','SmallLoad0.1 raw association, integer multiplier product and exact predef-before-cycle order preserved','No new tests or scientific Native equivalence claim until passive observer validation']}
p=OUT/'draft.json';p.write_text(json.dumps(draft,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

import argparse,ast,copy,hashlib,json,re,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
HEAD='19a2e63b5bc82ca3e8379d3c2a753bd420596901';PIN='6f2e40d10250a105b49966baa24d843711e61048'
O=D/'source-controlled-system-report-held-Audit-39'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'],x
 assert v['bytes']==x.get('bytes',v['bytes']);return p
def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True).stdout
def save(name,b):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def contains(x,row):
 return (isinstance(x,dict) and (((x.get('path'),x.get('sha256'))==(row['path'],row['sha256'])) or any(contains(v,row) for v in x.values()))) or isinstance(x,list) and any(contains(v,row) for v in x)
def load(name,prefix):
 p=R/name;assert ref(p)['sha256'].startswith(prefix);return p,json.loads(p.read_bytes())
a=argparse.ArgumentParser();a.add_argument('--peer-path',required=True);a.add_argument('--peer-sha',required=True);args=a.parse_args()
assert git(R,'rev-parse','HEAD').decode().strip()==git(R,'rev-parse','origin/main').decode().strip()==HEAD
assert not git(R,'status','--porcelain=v1').strip() and not O.exists()
dp,draft=load('.runtime/porting/SRC-06/source-controlled-system-report-draft-Audit-39-03/draft.json','840afffd96eaa1ab71533779fe77b63ace04e918b5ed5e839bb0c4446b4b34c2')
pp,peer=load(args.peer_path,args.peer_sha);assert peer['accepted'] and not peer['findings'] and contains(peer,ref(dp))
ap,actual=load('.runtime/porting/SRC-06/Root-source-energy-report-initialization-actual-review-38-02/review.json','89c5d592')
assert actual['accepted'] and not actual['findings'] and actual['same4508_archived_inputs_exact_final_plan']
assert actual['B_frontier']=='GetHeatBalanceInput: actual ReportSystemEnergyUse3155 ZoneSysEnergyDemand.TotalOutputRequired'
producer=auth(actual['producer']);assert ref(producer)['sha256']=='768f053e86b0ef874ca8f9d139a4cd9144c34d462bca60e33504d90b9c4f791f'
prior_path=auth(actual['complete_compiler_plan']);assert ref(prior_path)['sha256']=='92ec6ebe383467845eaa11fb8af461f65bf1cb5fa7b174af4ee327b76524d763'
prior=json.loads(prior_path.read_bytes());entries={x['path']:copy.deepcopy(x) for x in prior['entries']};assert len(entries)==4508
b=json.loads(auth(actual['actual_B']).read_bytes());a24=json.loads(auth(actual['actual_A24']).read_bytes())
assert b['exit_code']==6 and a24['exit_code']==0 and b['source_snapshot']==a24['source_snapshot']
assert all(x['source_bytes_match_before_and_after'] and x['launch_error'] is None for x in [b,a24])
sp=auth(b['source_snapshot']);snapshot=json.loads(sp.read_bytes());archives={x['historical_path']:x for x in snapshot['files']};assert set(entries)==set(archives)
readback=[];raws={}
for name,row in entries.items():
 raw=auth(archives[name]['archive']).read_bytes();assert raw==auth(row['source']).read_bytes()==(R/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['final_sha256'] and len(raw)==row['final_bytes']
 readback.append({'path':name,'actual_archive':archives[name]['archive'],'sha256':row['final_sha256'],'bytes':len(raw),'archive_live_plan_exact':True});raws[name]=raw
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];logical={}
for i,row in enumerate(draft['files'],1):
 name=row['canonical_path'];before=auth(row['before']).read_bytes();proposed=auth(row['proposed']).read_bytes()
 assert before==raws[name]==git(R,'show',HEAD+':'+name)
 assert ns['apply_literal'](before,auth(row['forward_diff']).read_bytes())==proposed
 assert ns['apply_literal'](proposed,auth(row['inverse_diff']).read_bytes())==before
 parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,capture_output=True,cwd=R);assert parsed.returncode==0,parsed.stderr
 whole=save('proposed/'+name,proposed)
 files.append({'canonical_path':name,'before_absent':False,'before':save('before/'+name,before),'actual_parent_archive':archives[name]['archive'],'proposed':whole,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}.forward.diff',auth(row['forward_diff']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}.inverse.diff',auth(row['inverse_diff']).read_bytes()),'literal_origin_whole':row['proposed'],'before_whole_Git_exact_at_base':True,'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',parsed.stdout),'stderr':save(f'parse/{i:02}.stderr',parsed.stderr)}})
 entries[name]={'path':name,'final_sha256':whole['sha256'],'final_bytes':whole['bytes'],'source':whole,'origin':'whole independent accepted immutable Source39 draft03; no semantic rewrite'};logical[name]=proposed
assert len(files)==6 and len(entries)==4508 and sum(x.endswith('.rs') for x in entries)==4495
needles=['report_source_system_energy_use','report_source_ventilation_loads','source_purchased_air_out_air_mass_flow','source_purchased_air_zone_inlet_air_node','source_purchased_air_return_air_node','source_purchased_air_mixed_air_temperature','source_purchased_air_mixed_air_humidity_ratio','source_purchased_air_report_input','calculate_source_design_specification_outdoor_air','SourceSystemReportOwners','system_owners','inlet_node_air_loop_number','equipment_list_index','equipment_index(','equipment_type(']
api=[]
for name,row in sorted(entries.items()):
 if not name.endswith('.rs'):continue
 raw=logical.get(name,raws[name]);hits=[{'line':i,'terms':[n for n in needles if n in line]} for i,line in enumerate(raw.decode('utf-8').splitlines(),1) if any(n in line for n in needles)]
 if hits:api.append({'path':name,'ordered_hits':hits,'final_sha256':row['final_sha256']})
preserved=[]
for name in ['crates/ep_runtime/Cargo.toml','crates/ep_runtime/src/lib.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/native_cohort.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/fixtures/native_prediction_b.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/surface.rs']:
 assert entries[name]==next(x for x in prior['entries'] if x['path']==name);preserved.append({'path':name,'whole':entries[name]['source']})
equipment='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';token=b'    pub(crate) fn restore_native_cohort_node('
assert raws[equipment].count(token)==logical[equipment].count(token)==1
assert raws[equipment][raws[equipment].index(token):]==logical[equipment][logical[equipment].index(token):]
native=[]
for x in draft['Native_authorities']:
 name=x['Native_path'];raw=auth(x['whole']).read_bytes();assert raw==git(N,'show',PIN+':'+name)==(N/name).read_bytes();lines=raw.splitlines(keepends=True)
 for e in x['extents']:assert b''.join(lines[e['first']-1:e['last']])==auth(e['source']).read_bytes()
 native.append({**x,'pinned_Git_exact':True})
assert len(native)==12 and sum(len(x['extents']) for x in native)==20
contexts=[]
for c in draft['concrete_same_owner_contexts']:
 name=c['canonical_path'];assert auth(c['whole']).read_bytes()==raws[name],name
 contexts.append({'canonical_path':name,'whole':{**archives[name]['archive'],'bytes':len(raws[name])},'actual38_archive_and_live_exact':True})
plan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-Source39-compiler-input-plan.v1','base_HEAD':HEAD,'actual38_parent_review':ref(ap),'actual38_parent_snapshot':ref(sp),'prior_plan':ref(prior_path),'inputs':4508,'Rust_sources':4495,'selected_existing':6,'selected_new':0,'entries':[entries[x] for x in sorted(entries)]})
manifest={'schema':'src06-held-controlled-system-report39.v1','status':'HELD Source39 full independent Source peer accepted; Root application/actual execution and scientific Native report cohort pending','base_HEAD':HEAD,'accepted38_actual_review':ref(ap),'parent_producer':actual['producer'],'actual_parent_receipts':{'B':actual['actual_B'],'A24':actual['actual_A24']},'actual_parent_snapshot':ref(sp),'prior_complete_compiler_Source_plan':ref(prior_path),'complete_final_compiler_Source_plan':plan,'compiler_inputs':4508,'Rust_sources':4495,'original_draft':ref(dp),'independent_full_semantic_peer':ref(pp),'files':files,'existing_Source_files':6,'new_Source_files':0,'selected_Source_files':6,'literal_applications':12,'Source_only_parses':6,'all6_proposals_whole_unchanged_from_reviewed_draft':True,'full4508_parent_readback':dump('actual38-parent-full-readback.json',readback),'whole4495_Rust_API_census':dump('API-census.json',{'Rust_sources_examined':4495,'all_crates_runtime_tests_included':True,'needles':needles,'hits':api}),'Native_commit':PIN,'Native_authorities':native,'concrete_same_owner_contexts':contexts,'integration_contract':{'scope':draft['scope'],'qualifications':draft['qualifications'],'read_only_map':draft['read_only_plan'],'historical_map_parent38_01_superseded':'Only map logical-parent metadata is historical. Final authoritative corrected38 producer/actual/plan/full archived-live custody are the explicit accepted38 fields above. No Source refresh.'},'preserved_safe_cohort_Sources':preserved,'equipment_test_only_loader_suffix_unchanged':True,'new_test_bodies':0,'actual_test_bodies_executed':0,'validation_policy':'Root alone actual B then A24. One separate passive report capture and later consolidated safe-main cohort may establish new scientific report equivalence; not claimed by Source peer/typecheck/normal integration. No unrelated cohort/alltargets/annual rerun.','Cargo_main_tests_or_Native_mutations':False,'author_Source':ref(Path(__file__))}
print(json.dumps({'manifest':dump('manifest.json',manifest),'plan':plan}))

from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-controlled-system-report-application-39';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-controlled-system-report-held-Audit-39/manifest.json');assert mr['sha256']==sys.argv[1];m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];assert pr['sha256']==sys.argv[2];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peermechanical=json.loads(checked(peer['mechanical_and_contextual_checks']));peerfiles={v['canonical_path']:v for v in peermechanical['files']};draft=json.loads(checked(m['original_draft']));draftfiles={v['canonical_path']:v for v in draft['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='19a2e63b5bc82ca3e8379d3c2a753bd420596901' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4508 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(draftfiles[n]['proposed'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==6 and len(new)==0 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==12 and extent_count==20
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted38_actual_review','parent_producer','prior_complete_compiler_Source_plan','whole4495_Rust_API_census','original_draft']:checked(m[k])
parent_readback=json.loads(checked(m['full4508_parent_readback']));assert len(parent_readback)==4508 and {v['path'] for v in parent_readback}==inventory
for v in parent_readback:assert v['archive_live_plan_exact'] and checked(v['actual_archive'])==(R/v['path']).read_bytes() and v['sha256']==v['actual_archive']['sha256'] and v['bytes']==(R/v['path']).stat().st_size
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4508 and sum(n.endswith('.rs') for n in rows)==4495
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
for v in m['preserved_safe_cohort_Sources']:assert (R/v['path']).read_bytes()==checked(v['whole'])
assert m['equipment_test_only_loader_suffix_unchanged']
equipment=selected['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'];assert checked(equipment['before']).rsplit(b'#[cfg(test)]',1)[-1]==checked(equipment['proposed']).rsplit(b'#[cfg(test)]',1)[-1]
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Full independent six Source39 semantics, genuine fields/visibility/borrows, twelve literal applications and exact proposal wholes; Root independently reads whole six diffs and03 enum correction, authenticates committed38 parent4508 and complete final4508/4495 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4508,final_inputs=4508,final_Rust_sources=4495,selected_Rust=6,new_Rust=0,literal_applications=12,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read all six existing forward diffs02 and exact03 switch/first-child correction, Native2978-3296/3829-4500 normal controlled closure, PurchasedAir3099-3234 five getters, DataSizing pointer0 helper and genuine ZoneEquip enum values, H/Rho definitions and actual call/owner contexts. Every controlled demand/deadband and actual inlet association read retained. Vent true pointer0 target before deadband; Config-selectedList/per-equipmenttype/index, five live PurchasedAir getters in Native order, real supply massflow and retained mixed versus currentrecirc H, no NoOA-zero shortcut. Full report20/facility7 reset and real predef state/minimum/totals writes before small0.1 cycle, integer multiplier product and exact currentRho/ACH/classification arithmetic preserved. CurrentRho executes evenOA0, negative diagnostic remains honest boundary. UnitarySystem33 is genuineNative emptycase, Hybrid14 and all other positive children stop at their actual first operation. Same actual report/zone/predef/equipment/controller/environment/sizing owners passed only at both actual report calls; obsolete local adapter removed, generic startup constructors unchanged. No duplicate physical state, computed answers, tests, tolerance or finitegate change. Lazy trueGetInput and positive primary/OA/other-equipment/diagnostic parity remain scoped; report scientific Native unit comparison is PENDING separate genuine captured entry/exit cohort. Actual B/A39 pending.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

import hashlib,json,re,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.runtime/porting/SRC-06'
OUT=BASE/'prospective-controlled-system-report-readonly-Audit-39'
assert not OUT.exists()
OUT.mkdir()
PIN='6f2e40d10250a105b49966baa24d843711e61048'
NATIVE=ROOT/'.reference/energyplus-src/26.1.0'
def sha(b): return hashlib.sha256(b).hexdigest()
def ref(p):
    b=p.read_bytes()
    return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def put(p,b):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def known(p,h):
    r=ref(p);assert r['sha256']==h,(p,r);return r
author=ref(Path(__file__))
ranges={
'src/EnergyPlus/SystemReports.cc':[(2978,3296),(3829,4500)],
'src/EnergyPlus/PurchasedAirManager.cc':[(3099,3170),(3188,3234)],
'src/EnergyPlus/DataSizing.cc':[(634,671)],
'src/EnergyPlus/DataSizing.hh':[(1223,1232)],
'src/EnergyPlus/Psychrometrics.hh':[(513,547),(648,666)],
'src/EnergyPlus/DataHVACGlobals.hh':[(87,95)],
'src/EnergyPlus/HVACManager.cc':[(433,472)],
'src/EnergyPlus/DataHeatBalance.hh':[(425,445),(571,580),(1494,1609)],
'src/EnergyPlus/DataZoneEquipment.hh':[(112,166),(305,382),(415,457)],
'src/EnergyPlus/DataZoneEnergyDemands.hh':[(65,80),(164,171)],
'src/EnergyPlus/ZoneTempPredictorCorrector.hh':[(102,132)],
'third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh':[(338,355)],
}
native=[]
for name,spans in ranges.items():
    raw=(NATIVE/name).read_bytes()
    pinned=subprocess.check_output(['git','-C',str(NATIVE),'show',PIN+':'+name])
    assert raw==pinned,name
    whole=put(OUT/'Native'/name,raw)
    lines=raw.splitlines(keepends=True)
    extents=[]
    for first,last in spans:
        assert len(lines)>=last
        extents.append({'first':first,'last':last,'source':put(OUT/'Native-extents'/f'{Path(name).name}.{first}-{last}.txt',b''.join(lines[first-1:last]))})
    native.append({'Native_path':name,'pinned_Git':PIN,'whole':whole,'extents':extents})
prefix='crates/ep_runtime/src/'
source_names=[
'heat_balance/ordinary_system_reports.rs','heat_balance/ordinary_system_reports/reporting.rs','heat_balance/ordinary_system_reports/state.rs',
'heat_balance/ordinary_hvac_manager/remaining.rs','heat_balance/ordinary_hvac_manager/owners.rs',
'heat_balance/ordinary_air_heat_balance.rs','heat_balance/ordinary_air_heat_balance/predictor_corrector.rs','heat_balance/ordinary_air_heat_balance/predictor_corrector/demand.rs',
'heat_balance/ordinary_equipment.rs','heat_balance/ordinary_equipment/source_equipment_types.rs','heat_balance/ordinary_equipment/source_controlled_equipment.rs',
'heat_balance/ordinary_equipment/source_purchased_air.rs','heat_balance/ordinary_equipment/source_purchased_air/owners.rs','heat_balance/ordinary_equipment/source_purchased_air/calculation.rs','heat_balance/ordinary_equipment/source_purchased_air/initialization.rs',
'heat_balance/selected_sizing.rs','heat_balance/selected_heat_balance_input/zone/storage.rs','psychrometrics.rs','weather_day/context.rs','heat_balance/ordinary_equipment/node_reporting.rs',
'heat_balance/ordinary_air_heat_balance/predictor_corrector/simple_air/mean_air_report.rs',
]
contexts=[]
for name in source_names:
    p=ROOT/(prefix+name)
    contexts.append({'canonical_path':prefix+name,'current_observed':ref(p),'whole':put(OUT/'Source-context'/(prefix+name),p.read_bytes())})
held38=known(BASE/'source-init-energy-reports-held-Outer-38/manifest.json','0c3649aeb6317c639a1a8be922ad030c2ff6b4c705c496659e9c2deb6cc3044b')
h38=json.loads(Path(held38['path']).read_text(encoding='utf-8'))
capture=known(BASE/'controlled-air-native-capture-Root-21/capture.json','6845958c28d6eef55ce89100a13f2001d43ae7ca2fb3e86b2c189d2820b4c47f')
eso_paths=[BASE/'native-installed-B-NOLIMIT-24H-Root-12/output/energyplusout.eso',Path('D:/CodexBuild/rusted-energyplus/SRC-06/controlled-air-native-capture-Root-21/B-NOLIMIT-24H/eplusout.eso')]
dictionaries=[]
for i,p in enumerate(eso_paths):
    b=p.read_bytes();mark=b'End of Data Dictionary';at=b.index(mark);end=b.index(b'\n',at)+1
    dictionary=b[:end];s=dictionary.decode('utf-8')
    assert 'Zone Mechanical Ventilation' not in s
    assert 'Mixed Air Temperature' not in s and 'Mixed Air Humidity Ratio' not in s
    dictionaries.append({'physical_ESO':ref(p),'complete_dictionary':put(OUT/f'Native-ESO-dictionary-{i+1}.txt',dictionary),'physical_dictionary_lines':len(dictionary.splitlines()),'report_scientific_oracle_present':False})
state=(ROOT/(prefix+'heat_balance/ordinary_system_reports/state.rs')).read_text(encoding='utf-8')
zone_fields=re.findall(r'pub\(crate\) (\w+): f64',state.split('struct SourceZoneVentReportVariables {',1)[1].split('}',1)[0]);assert len(zone_fields)==20
predef_fields=['tot_time_occ','mech_vent_vol_total_occ','mech_vent_vol_min','mech_vent_vol_total_occ_std_den','infil_vol_total_occ','infil_vol_min','infil_vol_total_occ_std_den','simp_vent_vol_total_occ','simp_vent_vol_min','simp_vent_vol_total_occ_std_den','voz_target_total_occ','voz_target_time_below_occ','voz_target_time_at_occ','voz_target_time_above_occ','tot_vent_time_non_zero_unocc','mech_vent_vol_total_std_den','infil_vol_total_std_den','simp_vent_vol_total_std_den','voz_target_total','voz_target_time_below','voz_target_time_at','voz_target_time_above']
storage=(ROOT/(prefix+'heat_balance/selected_heat_balance_input/zone/storage.rs')).read_text(encoding='utf-8')
for f in predef_fields: assert re.search(r'\b'+f+r'\b',storage),f
facility_fields=['any_zone_time_below_voz_dyn','all_zones_time_at_voz_dyn','any_zone_time_above_voz_dyn','any_zone_time_vent_unocc','any_zone_time_below_voz_dyn_occ','all_zones_time_at_voz_dyn_occ','any_zone_time_above_voz_dyn_occ']
plan={
'schema':'src06-prospective-controlled-system-report-readonly39.v1',
'author_Source':author,'read_only':True,'Source_proposals':0,'tests_executed':0,'Native_executions':0,
'Git_HEAD_at_observation':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
'current_worktree_qualification':'Root may have Source38 WIP applied. Context byte copies are observed current owners, not a clean37/full-plan claim. Final Source39 custody waits actual38 frontier and committed parent.',
'logical_parent38':held38,
'scope':'Both whole normal controlled ReportSystemEnergyUse and ReportVentilationLoads on actual PurchasedAir/zero-primary inlet associations, with genuine first-operation boundaries for positive other equipment/primary/DSOA/air-distribution children; no preamble-only checkpoint.',
'Native_authorities':native,'Native_whole_count':len(native),'Native_extent_count':sum(len(x['extents']) for x in native),'concrete_Source_contexts':contexts,
'caller_order':{'Native':'HVACManager433-472','operations':['!WarmupFlag','DoOutputReporting && !ZoneSizingCalc: CalcMoreNodeInfo, CalculatePollution, InitializeEnergyReports, ReportSystemEnergyUse','DoOutputReporting || sizing-comp-load: ReportAirHeatBalance (actual ZnAirRpt averaging)','DoOutputReporting: ReportVentilationLoads','UpdateDataAndReport(System)','UpdateTabularReports(System)'],'forbidden_proxies':['NoOA implies no thermal ventilation','zero primary count replaces actual inlet associations','absent family implies initialized owner','instantaneous Node temperature replaces actual MAT/airHumRatAvg']},
'energy_operation_ledger':[
{'lines':[3014,3065],'operation':'Read actual system seconds before report-enable guard; preserve primary reset first row boundary.'},
{'lines':[3149,3168],'operation':'For every actual Config row/control flag: read same demand.TotalOutputRequired, then same DeadBandOrSetback (not current deadband); then each actual NumInletNodes/InletNodeAirLoopNum. Only that actual ordinal0 skips positive ADU/primary child.'},
{'lines':[3170,3295],'operation':'Positive actual air-loop/ADU/component rows remain typed at first unrepresented access; zero-domain primary sums unchanged. Finite0 associations consume real inlet values, not primary-count inference.'}],
'ventilation_operation_ledger':[
{'lines':[3843,3901],'operation':'Actual local SmallLoad0.1; physical Node alias/time reads; two real flags; ZoneVent row lookup before controlled flag, exact20 resets; exact7 facility resets; primary row boundary.'},
{'lines':[3903,3949],'operation':'Real controlled Config; actual zero initialized local accumulators; demandTotal; checked Native integer Multiplier*ListMultiplier then Volume*product; mutable same ZonePreDef and report row; target designOA helper before deadband; Config-selected EquipListIndex, actual per-equipment types/indices.'},
{'lines':[4064,4081],'operation':'Five live getters in exact order: OAflow, supplyNode, mixedT, mixedW, recircNode. Positive supply node uses Objexx max(Mdot,0); positive flow+recirc uses H(retained mixed)-H(current physical recirc), multiplied flow then seconds. Else actual +=0.'},
{'lines':[4191,4283],'operation':'Every inlet actual AirLoopNum. Zero association leaves true per-inlet locals0; positive ADU/airloop before first missing row boundary. Sum genuine forced-air and system flows/thermal loads.'},
{'lines':[4285,4321],'operation':'Write real OA mass/flow and standard volumes; combine standard mechanical+natural volumes using same ZnAirRpt/AFN row and multiplier; target volume; .99/1.01 threshold and0.001 comparison; UNCONDITIONAL normal Rho(P,actualMAT,actualWavg), including OA0; current volumes then exact ACH grouping.'},
{'lines':[4323,4367],'operation':'Same occupied flag and accumulated predefined row writes, including minima and exact per-facility assignments; all writes precede small-load cycle. Preserve Native raw infiltration/ventilation min-volume comparisons.'},
{'lines':[4370,4416],'operation':'Combine real thermal ventilation load; abs<0.1 continues only this zone after prior writes; exact positive/negative demand classification and absolute-value grouping, without timestep/unit conversion.'},
{'lines':[4418,4500],'operation':'Real primary loop remains honest row boundary. Seven facility predefined totals accumulate from same live report state.'}],
'live_PurchasedAir_getters':{'Native_ranges':[[3099,3170],[3188,3234]],'call_order':['GetPurchasedAirOutAirMassFlow','GetPurchasedAirZoneInletAirNode','GetPurchasedAirMixedAirTemp','GetPurchasedAirMixedAirHumRat','GetPurchasedAirReturnAirNode'],'retained_unit_members':['outdoor_air_mass_flow_rate','zone_supply_air_node_num','mixed_air_temp','mixed_air_hum_rat','zone_recirc_air_node_num'],'each_getter_first_operation':'If real get_purchased_air_input flag true, actual GetPurchasedAir child precedes flagfalse; do not infer readiness from allocated units. A narrow finite getter may return typed Unavailable at that genuine child when true. If false, normal getter reads actual same manager/unit. Node getters preserve exact invalid unit ordinal0 return, direct real getters preserve real access failure.','important':'NoOA mechanical OA flow0 does not imply thermal ventilation load0: retained mixed state predates current corrector physical return state. Never replace either with reconstructed/predefined values.'},
'read_write_owners':{
'SourceSystemReports':{'read':['air_loop_loads_report_enabled','vent_report_structure_created','vent_loads_report_enabled'],'write_zone20':zone_fields,'write_facility7':facility_fields,'ownership':'same registered live SourceSystemReports rows; no new DTO/output owner'},
'controller.demand':{'read':['zones[zone].base.total_output_required','deadband_or_setback[zone]'],'not':'current_deadband_or_setback'},
'controller.reports':{'read':['zones[zone].infil_volume_cur_density','zones[zone].infil_volume_std_density','zones[zone].ventil_volume_cur_density','zones[zone].ventil_volume_std_density'],'timing':'real ReportAirHeatBalance earlier in same HVAC caller'},
'air.zones':{'read':['air.mat','air.air_hum_rat_avg']},
'equipment.Config':{'read':['is_controlled','number_inlet_nodes','inlet_node_air_loop_numbers','equipment_list_index','zone_design_specification_outdoor_air_index','zone_air_distribution_index']},
'equipment.List':{'read':['number_types','equipment_types','equipment_indices'],'association':'Config-selected List index for this report'},
'equipment.PurchasedAir':{'read':'same true input latch/count/retained unit five fields above'},
'equipment.Node':{'read':['actual supply mass_flow_rate','actual recirc temperature','actual recirc humidity_ratio'],'ownership':'same physical owner/current Node at report call'},
'zones.zones':{'read':['volume','multiplier','list_multiplier']},
'zones.zone_predefined':{'read':['is_occupied','afn_vent_vol_std_den','existing occupied/nonoccupied accumulators and minima'],'write':predef_fields,'constructor':'Existing actual zero fields and9.9e9 minima retained; no new duplicate row'},
'environment':{'read':['std_rho_air','current_weather.out_baro_press']},
'sizing':{'read':['actual DSOA ordinal and actual air-distribution ordinal'],'zero_DSOA':'Native helper returns literal local0 before any OARequirements read only when real pointer0; positive actual pointer firstOARequirements child remains boundary'},
'comfort_summary':{'write':['total_any_zone_below_voz_dyn_for_oa','total_all_zones_at_voz_dyn_for_oa','total_any_zone_above_voz_dyn_for_oa','total_any_zone_vent_unocc_for_oa','total_any_zone_below_voz_dyn_occ_for_oa','total_all_zones_at_voz_dyn_occ_for_oa','total_any_zone_above_voz_dyn_occ_for_oa']}},
'minimal_borrow_design':{'global_generic_owner':'Keep existing SourceSystemReportOwners and startup constructors unchanged. Narrow report-local direct parameters or short borrow view only at two remaining.rs arms.','energy':'globals,hvac,&equipment,&controller.demand','vent':'globals,hvac,&equipment,&mut zones,&controller.demand,&controller.reports,&air,&environment,&sizing,&mut comfort_summary','availability':'All true references already exist disjointly on SourceHvacOwners; do not copy controller/equipment/zone/report state.','likely_files':['ordinary_system_reports/reporting.rs','ordinary_hvac_manager/remaining.rs','ordinary_equipment.rs (borrowed actual Config/List accessors)','ordinary_equipment/source_purchased_air.rs (thin same-owner getters)','selected_sizing.rs (exact real-pointer0 design OA helper)'],'future_positive_children':'No hardcoded B names/counts/NoOA flags; unsupported positive OARequirements/air-distribution/primary/other equipment stays first real child operation.'},
'property_reuse':{'H':'Existing energyplus_psy_h_fn_tdb_w at actual two live states; exact humidity floor/native grouping.','Rho':'Existing energyplus_psy_rho_air_fn_pb_tdb_w at actualP/MAT/Wavg; no cache access required; normal numeric path then honest first-negative diagnostic boundary like current Node reporting.','max':'Native Objexx first-on-tie/NaN-first max helper, not f64::max substitution.','state_scope':'No new psychrometric cache owner required by normal H/Rho. No Native diagnostic/cache-hit/miss/recurrence equivalence claim.','constants':'Keep local report SmallLoad0.1 vs global HVAC SmallLoad1 distinct; HVAC SmallAirVolFlow0.001 only where Native uses it. No units correction, tolerance or scientific operation rearrangement.'},
'reference_coverage':{'Native_capture':capture,'existing_ESO_dictionaries':dictionaries,'existing_numeric_series':'Native retained ESO has actual IdealLoads/thermostat/Node series, including322 OAflow/323 supplyflow/324 supply standardvolume. No report20/facility4 or retainedMixedT/W numeric series; RDD declarations are not numeric answers.','raw_observer_gap':'Existing30445event/1168-entry full21 observer captures predictor/sums/corrector, not ReportVent call-entry retainedPurchasedAir mixed+currentNode/postaveragedMATW/ZonePredef accumulated entry. Do not reconstruct missing report operands or inject current-operation computed answers.','current_equivalence_claim':False},
'one_meaningful_validation_strategy':{'status':'Prospective only; no new engine/test run or Native report scientific PASS. Root separately authorizes observer implementation/run.','integration':'Future fullB Source/Native existing ESO exact identity/tuples+original tolerances and retained fullBND are integration evidence, not report formula cohort proof.','passive_extension':'ONE genuine entry/exit observer extension around both ReportSystemEnergyUse and ReportVentilationLoads in existing Native full-engine harness, no additional helper/Psy/getter calls, no math/FP changes. One later finiteB capture, if authorized.','entry_fields':['true parent time/flags/sequence IDs and primary count','all report20/facility7 pre-reset rows','Config-controlled/list/inlet ordinals and count metadata','demandTotal+deadband','Zone volume/multiplier/listmultiplier','actual DSOA/air-distribution pointer and valid consumed data','equipment type/index/true PurchasedAir latch/count/unit mixed/OA/nodeIDs','current physical supply/recirc Node fields','environment standardrho/baropress','actual postaverage MAT/Wavg','actual ZnAirRpt four volumes','full consumed ZonePredef occupied/AFN/minima/accumulator prestate','seven comfort_summary prestate'],'exit_fields':['all report20/facility7 fields','all modified ZonePredef accumulators/minima','all modified seven comfort_summary fields','optional true existing H/Rho local returns as expected OUTPUT only'],'replay':'Restore ONLY true captured function-entry operands on same real owners, call real two report functions; never seed computed current-operation ZoneVentLoad/H/Rho/target output. Reuse/consolidate ONE existing safe-main cohort target rather than per-helper tests. Exact bits only within genuine observed normal domain, qualify unobserved diagnostic/cache prestate.','efficiency':'No Native rerun for map or production routing, no duplicate full existing fixture/cohort replay, no new helper test bodies.'},
'not_claimed':['Source39 reached/executed','Native report-unit equivalence','positive primary/other equipment/OA children ported','NoOA implies thermalvent0','cold-zero state is Native oracle','unobserved accumulator/property state reconstructed'],
}
p=OUT/'plan.json';p.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(ref(p)))

from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'publish-energy-report-structure-checkpoint-Audit-37.py';NEW=D/'publish-controlled-system-report-checkpoint-Audit-39.py';O=D/'controlled-system-report-publication-prepared-Audit-39'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
mp=D/'source-controlled-system-report-held-Audit-39/manifest.json';m=json.loads(mp.read_bytes());assert ref(mp)['sha256']=='26d7fca84dec43a118807013cb08b43f8fb0526925cefed18ca66c1e1e713b56'
peer=json.loads(auth(m['independent_full_semantic_peer']).read_bytes());assert peer['accepted'] and not peer['findings']
dp=auth(m['original_draft']);draft=json.loads(dp.read_bytes());assert ref(dp)['sha256']=='840afffd96eaa1ab71533779fe77b63ace04e918b5ed5e839bb0c4446b4b34c2'
assert ref(OLD)['sha256']=='042079808d871c4da2b9a36c783bf0283906f13b89bd06b2d5170d36bd41ace6'
assert not NEW.exists() and not O.exists()
before=OLD.read_text(encoding='utf-8');s=before
for a,b in [
 ('engine37','engine39'),('final nine-file','final six-file'),('energy-report-structure','controlled-system-report'),('Audit-37','Audit-39'),('ACTUAL37','ACTUAL39'),('controlled-system-report-37','controlled-system-report-39'),
 ("len(producer['files'])==9 and producer['existing_Source_files']==6 and producer['new_Source_files']==3","len(producer['files'])==6 and producer['existing_Source_files']==6 and producer['new_Source_files']==0"),
 ('(4507,4494)','(4508,4495)'),('same4507_archived_inputs_exact_final_plan','same4508_archived_inputs_exact_final_plan'),('selected9_final_sources_exact','selected6_final_sources_exact'),('len(observed)==4507','len(observed)==4508'),
 ('equal35','equal38'),('accepted35_full5352_proof','accepted38_full5352_proof'),('accepted35_proof','accepted38_proof'),('Accepted35 A24 proof transfer','Accepted38 A24 proof transfer'),
 ('Root-37/output','Root-39/output'),('src06-canonical37-finite','src06-canonical39-finite'),('Six existing and three new production Sources','Six existing production Sources and no new Source files'),
 ('The parent35 A24 proof is separately attributed; no cohort or new Native rerun by37.','The parent38 A24 proof is separately attributed; no current report cohort or Native run by this production checkpoint. New report scientific equivalence remains pending independent passive observation/replay.'),
 ("status='Genuine Source energy report structure on actual connected equipment and metered-variable owners; actual B result recorded'","status='Genuine normal controlled-zone energy and ventilation reporting on actual same-state owners; actual B result recorded'"),
 ('[Source37 energy report structure]','[Source39 controlled system reports]'),('canonical_energy_report_structure_37','canonical_controlled_system_report_39'),('actual_test_bodies_executed_by37','actual_test_bodies_executed_by39'),
 ]:
 assert a in s,a;s=s.replace(a,b)
assert 'equal35' not in s and 'selected9' not in s and '4507' not in s and '4494' not in s
ast.parse(s);NEW.write_bytes(s.encode());O.mkdir()
for name,a,b in [('publisher-forward.diff',before,s),('publisher-inverse.diff',s,before)]:
 (O/name).write_bytes(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='accepted37-publisher' if name.startswith('publisher-forward') else 'Source39-publisher',tofile='Source39-publisher' if name.startswith('publisher-forward') else 'accepted37-publisher')).encode())
finite={}
def add(row):
 p=auth(row);v=ref(p);finite[v['path']]=v
for key in ['complete_final_compiler_Source_plan','independent_full_semantic_peer','original_draft','author_Source','accepted38_actual_review','whole4495_Rust_API_census','full4508_parent_readback']:
 add(m[key])
for row in [ref(mp),ref(Path(__file__)),ref(OLD),ref(O/'publisher-forward.diff'),ref(O/'publisher-inverse.diff'),draft['author_Source'],draft['branch_correction'],draft['original_draft'],draft['self_check_cleanup'],draft['read_only_plan']]:add(row)
old02=json.loads(auth(draft['original_draft']).read_bytes());add(old02['author_Source']);add(old02['original_draft'])
old01=json.loads(auth(old02['original_draft']).read_bytes());add(old01['author_Source'])
correction=json.loads(auth(draft['branch_correction']).read_bytes())
for k in ['original_proposal','forward','inverse']:add(correction[k])
cleanup=json.loads(auth(draft['self_check_cleanup']).read_bytes())
for k in ['original_proposal','final_proposal','forward','inverse']:add(cleanup[k])
for row in m['files']:
 for k in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(row[k])
 for k in ['stdout','stderr']:add(row['Source_only_parse'][k])
for row in m['Native_authorities']:
 add(row['whole'])
 for extent in row['extents']:add(extent['source'])
for row in m['concrete_same_owner_contexts']:add(row['whole'])
readonly=json.loads(auth(draft['read_only_plan']).read_bytes());add(readonly['author_Source'])
for row in readonly['reference_coverage']['existing_ESO_dictionaries']:add(row['complete_dictionary'])
prior=json.loads((R/'energyplus_porting_plan/plan.json').read_bytes());task=next(x for x in prior['tasks'] if x['id']=='SRC-06');previous=task['canonical_energy_report_initialization_38'];add(previous)
t={
'schema':'src06-controlled-system-report-publication-template39.v1','status':'WAITING_FOR_ROOT_ACTUAL39_AND_FULL_READ','base_HEAD':m['base_HEAD'],'publisher_Source':ref(NEW),'producer':ref(mp),'complete_plan':m['complete_final_compiler_Source_plan'],'independent_peer':m['independent_full_semantic_peer'],'accepted_parent_review':m['accepted38_actual_review'],'accepted_parent_plan':m['prior_complete_compiler_Source_plan'],'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-controlled-system-report-actual-review-39/review.json','previous_engine_checkpoint':previous,'finite_archive_inputs':list(finite.values()),
'summary_template':{'A':'14/54','B':'14/64','gate_changes':False,'policy_changes':False,'selected_existing_production_Sources':6,'new_production_Source_files':0,'selected_production_Sources':6,'new_test_bodies':0,'actual_test_bodies_executed':0,'Source39_scientific_report_unit_equivalence':'PENDING: a separate passive Native report observation and consolidated safe-main replay have not been executed by this production checkpoint.','scope':'Whole normal controlled PurchasedAir ReportSystemEnergyUse and ReportVentilationLoads use actual demand/deadband, Config-selected equipment list and inlet associations, retained mixed-air state/current physical return Node, averaged zone air, actual environment/sizing and same predefined/report rows. Existing live20 outputs and7 facility accumulators receive exact Native ordered formulas/writes.','qualification':'Zero OA flow does not imply zero thermal ventilation load or omit the density call. Native local0.1 threshold and integer multiplier product/accumulator order retained. Positive unrepresented primary/ADU/other equipment/DSOA/air-distribution and true lazy-input getter children remain typed boundaries. Actual B frontier and A24 strict5352 transfer recorded only after accepted Root39 execution. No internal report numerical Native PASS or whole-card completion claim.','Native_BND_full_body_comparison':'PENDING accepted Root39 actual observation; no inherited comparison asserted as current execution.'},
'doc_appends':{
'cards/SRC-06.md':'실제 수요·장비·물리 노드·구역 평균 상태를 빌려 정상 제어 구역의 에너지·환기 보고 계산과 누적 순서를 연결했다. 외기 유량이 0이어도 혼합 공기와 현재 환류 상태를 읽고 밀도를 계산한다. B 실행 결과: `{{actual_B_result}}`. A24는 기존 보고값 5,352개의 증거를 이어받으며, 새 보고 계산의 Native 수치 대조는 별도 관측·재생 검증 대기 상태다.',
'CHECKLIST.md':'정상 제어 구역 보고 경로를 기존 Rust 파일 6개로 연결하고 실제 B/A24 경로를 확인했다. 이번 단위의 추가 테스트는 없으며 게이트 수는 유지한다. 보고 계산의 Native 수치 검증은 아직 완료로 표시하지 않는다.',
'STATE_CONTRACTS.md':'보고 함수는 같은 수요·PurchasedAir·Node·평균 공기·ZonePreDefRep 소유자를 빌린다. 외기 유량 0의 습공기 물성 호출, 정수 배수 곱, 0.1 기준과 누적 순서를 보존하며, 실제 입력 플래그가 참인 장비 조회는 GetPurchasedAir 자식 경계에서 중단한다.'}}
for value in t['doc_appends'].values():assert '\ufffd' not in value and '?' not in value
p=O/'publication-template.json';p.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'publisher':ref(NEW),'template':ref(p)}))

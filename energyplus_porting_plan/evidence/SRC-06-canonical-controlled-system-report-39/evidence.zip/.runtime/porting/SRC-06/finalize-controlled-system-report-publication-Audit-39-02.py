from pathlib import Path
from types import SimpleNamespace
import argparse,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
old=D/'controlled-system-report-publication-prepared-Audit-39/publication-template.json'
O=D/'controlled-system-report-publication-READY-Audit-39-02'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
arg=argparse.ArgumentParser();arg.add_argument('--actual-sha',required=True);args=arg.parse_args()
assert not O.exists() and ref(old)['sha256']=='73614f6c75edcb85874a8e62459c07a177a444b3ca841cc128c63a038df8aad7'
ap=D/'Root-source-controlled-system-report-actual-review-39/review.json';assert ref(ap)['sha256']==args.actual_sha
a=json.loads(ap.read_bytes());assert a['accepted'] and not a['findings'] and a['same4508_archived_inputs_exact_final_plan'] and a['selected6_final_sources_exact']
assert a['actual_test_bodies_executed']==a['new_test_bodies']==0
observation=a['B_Node_lifecycle_observation'];assert observation['full_BND_body_bytes_equal'] and observation['compared_body_bytes']==8518 and observation['compared_body_lines']==106
assert len(observation['excluded_headers'])==2 and all(x.startswith('Program Version,') and x.endswith('\r') for x in observation['excluded_headers'])
checked(observation['Native_BND_finite_copy']);checked(observation['Native_capture'])
t=json.loads(old.read_bytes());before=old.read_text(encoding='utf-8');assert t['status']=='WAITING_FOR_ROOT_ACTUAL39_AND_FULL_READ'
t['status']='HELD_READY_FOR_ROOT_ACTUAL39_AND_FULL_READ';t['accepted_actual_review']=ref(ap)
t['summary_template']['Native_BND_full_body_comparison']=observation
t['summary_template']['Native_BND_qualification']='Entire8518-byte/106-line reported IO body exact after only each file\'s exact Program Version first line including its CR. No body normalization, new Native run by this production checkpoint or internal thermodynamic/report-state equivalence claim.'
t['doc_appends']['cards/SRC-06.md']+=' 보존된 Native BND 본문 8,518바이트·106줄과 일치하며, 이 비교는 보고 I/O 범위다.'
def add(row):
 p=checked(row);r=ref(p);existing=next((x for x in t['finite_archive_inputs'] if x['path']==r['path']),None)
 if existing:assert existing==r
 else:t['finite_archive_inputs'].append(r)
for row in [ref(old),ref(ap),ref(Path(__file__)),a['comparison_helper_Source'],ref(D/'review-meter-final-predefined-Root-01.py'),ref(D/'check-canonical-B-ingress-IO-A24-transfer-Peer-03.py'),a['unchanged_original_tolerance_policy'],observation['Native_capture'],observation['Native_BND_finite_copy']]:add(row)
assert a['comparison_helper_Source']['sha256']=='e74ca3d9d2a85102f0dca30ed978ed25d7f8bee8e1fd72459b7b7ba131c2dea4'
for text in t['doc_appends'].values():assert '\ufffd' not in text and '?' not in text
O.mkdir();q=O/'publication-template.json';q.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode());after=q.read_text(encoding='utf-8')
forward=O/'pending-to-READY-forward.diff';inverse=O/'pending-to-READY-inverse.diff'
forward.write_bytes(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='immutable-pending39',tofile='immutable-READY39-02')).encode())
inverse.write_bytes(''.join(difflib.unified_diff(after.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='immutable-READY39-02',tofile='immutable-pending39')).encode())
p=checked(t['publisher_Source']);assert ref(p)['sha256']=='969710d9e05cb140a56e99e4cda4e786cfb3ee64a1accdb285300acb919e2e43'
s=p.read_text(encoding='utf-8');anchor=" PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(oldplan)";assert s.count(anchor)==1
s=s.replace(anchor," print(json.dumps({'preflight':'PASS_BEFORE_ANY_MAIN_OR_PUBLICATION_WRITE','finite_entries':len(files)}));return\n"+anchor)
ns={'__name__':'private_READY_preflight','__file__':str(p)};exec(compile(s,str(p),'exec'),ns);ns['main'](SimpleNamespace(publish=True,template=str(q),actual_sha=ref(ap)['sha256']))
print(json.dumps({'publisher':ref(p),'READY_template':ref(q),'forward_diff':ref(forward),'inverse_diff':ref(inverse)}))

"""Independent bounded Source readback; no compiler or main mutation."""
from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-ordinary-meter-final-predefined-Source-review-01';assert not OUT.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 p=ROOT/r['path'];b=p.read_bytes();assert ref(p)['sha256']==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def apply(a,d):
 lines=a.splitlines(keepends=True);patch=d.splitlines(keepends=True);out=[];at=0;i=2
 assert patch[0].startswith(b'--- ') and patch[1].startswith(b'+++ ')
 while i<len(patch):
  h=re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch[i]);assert h
  start=int(h[1])-(int(h[2] or b'1')!=0);assert start>=at;out.extend(lines[at:start]);at=start;i+=1;old=new=0
  while i<len(patch) and not patch[i].startswith(b'@@ '):
   row=patch[i];kind=row[:1];assert kind in [b' ',b'+',b'-']
   if kind in [b' ',b'-']:assert at<len(lines) and lines[at]==row[1:];at+=1;old+=1
   if kind in [b' ',b'+']:out.append(row[1:]);new+=1
   i+=1
  assert old==int(h[2] or b'1') and new==int(h[4] or b'1')
 out.extend(lines[at:]);return b''.join(out)
p=BASE/'ordinary-meter-final-predefined-held-Reviewer-01/manifest.json';m=json.loads(p.read_bytes());assert ref(p)['sha256']=='5a0b7b091f3fb7e14bc25aee3668415134f789b2f0de47dec3b7e8804b42cdf4'
apps=[]
for row in m['files']:
 a=read(row['before']);b=read(row['proposed']);c=read(row['parent_before']);assert a==c==read(row['literal_inverse'])==read(row['literal_parent_inverse']);assert a.count(b'#[test]')==b.count(b'#[test]') and b'\r\n' not in b
 for role,left,right in [('complete_forward_diff',a,b),('complete_inverse_diff',b,a),('parent_forward_diff',c,b),('parent_inverse_diff',b,c)]:assert apply(left,read(row[role]))==right;apps.append(dict(path=row['canonical_path'],role=role))
 if row['parent_source']:assert read(row['parent_source'])==a==read(row['current_before'])
 else:assert not (ROOT/row['canonical_path']).exists() and not (BASE/'ordinary-provider-assembly-Root-67/workspace'/row['canonical_path']).exists()
 parsed=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--emit','stdout'],input=b,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parsed.returncode==0 and parsed.stdout==b
main=m['files'][0];assert read(main['proposed']).replace(b'mod report_for_tabular;\n',b'',1)==read(main['before'])
pin='6f2e40d10250a105b49966baa24d843711e61048';native=ROOT/'.reference/energyplus-src/26.1.0';ranges=[]
for row in m['Original_authority']:
 b=read(row['source']);np=ROOT/row['source']['path'];assert subprocess.check_output(['git','show',pin+':'+np.relative_to(native).as_posix()],cwd=native)==b
 lines=b.splitlines(keepends=True);assert 1<=row['first_line']<=row['last_line']<=len(lines);assert b''.join(lines[row['first_line']-1:row['last_line']])==read(row['literal_excerpt']);ranges.append(row['literal_excerpt'])
for row in m['actual_parent_Source_checks']:assert read(row['actual67_frozen_archive'])==read(row['live_parent'])
s=read(m['files'][1]['proposed']).decode();original=(native/'src/EnergyPlus/OutputProcessor.cc').read_text(encoding='utf8')
for unit,native_unit in [('elec','Electricity'),('otherKG','OtherKG'),('otherJ','default')]:
 names=[f'pdchEM{unit}{tail}' for tail in ['annual','minvalue','minvaluetime','maxvalue','maxvaluetime']];assert [s.index('"'+n+'"') for n in names]==sorted(s.index('"'+n+'"') for n in names)
 arm=original[original.index('case RT_IPUnits::'+native_unit+':'):] if native_unit!='default' else original[original.index('            default: {',original.index('void ReportForTabularReports')):]
 arm=arm[:arm.index('} break;')];assert [arm.index(n) for n in names]==sorted(arm.index(n) for n in names)
assert s.count('period.value * 1.0E-9')==1 and s.count('period.minimum / *time_step_zone_seconds')==2 and s.count('period.maximum / *time_step_zone_seconds')==2
assert s.index('names[0]')<s.index('names[1]')<s.index('names[2]')<s.index('names[3]')<s.index('names[4]')
assert 'pub(crate) enum SourceMeterIpUnits' in (BASE/'ordinary-provider-assembly-Root-67/workspace/crates/ep_runtime/src/heat_balance/source_output_registration/meters.rs').read_text()
owner=read(m['same_owner_and_order']);OUT.mkdir()
v=dict(schema='src06-independent-meter-final-predefined-Source-review.v1',status='ACCEPTED_BOUNDED_SOURCE_ONLY',accepted=True,manifest=ref(p),literal_applications=apps,strict_pinned_Native_ranges=ranges,actual_parent_pairs_verified=len(m['actual_parent_Source_checks']),Source_only_parse=2,parent_body_recovery=True,manual_semantic_checks=['Same actual meter vector, final-year period and TimeStepZoneSec; no invented meter or period state.','Native Electricity/default OtherJ annual multiplication1.0E-9 and minimum/maximum division order preserved. OtherKG annual default2 and min/max precision3 preserved. Five table appends remain annual/min/min-date/max/max-date.','Date uses actual Native zero/Month/Day/Hour/Minute guards, truncating signed decode, minute60 adjustment and uppercase month format. All i32 decode intermediate arithmetic remains defined.','Only the three constructible admitted Source IP variants are matched. Unwritten None stops before any entry. Earlier positive unsupported resource/units stay unavailable.','Existing finite fixed-real formatting and typed PredefinedReport error transport retained; broader scientific/nonfinite formatting and exceptional allocation timing are not certified.'],owner_ledger=ref(ROOT/m['same_owner_and_order']['path']),new_test_bodies=0,Cargo_or_Native_executed=False,canonical_changed=False,numerical_or_gate_PASS=False,remaining=['Actual parent592 connection and compilation/execution still required; all subsequent endrun and numerical parity unfinished.'],author_Source=ref(Path(__file__).resolve()))
q=OUT/'review.json';q.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(q)))

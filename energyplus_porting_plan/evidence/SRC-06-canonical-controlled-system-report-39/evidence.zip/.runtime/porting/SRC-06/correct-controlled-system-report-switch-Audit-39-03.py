import ast,difflib,hashlib,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-controlled-system-report-draft-Audit-39-03'
assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];assert ref(p)['sha256']==x['sha256'];return p
def save(name,b):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def dump(name,x):return save(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
old_path=D/'source-controlled-system-report-draft-Audit-39-02/draft.json';assert ref(old_path)['sha256']=='80865bf0349de0fd5953dd66aef0e202a70a0e2ea3a240fe0f73460bbb02ffb7'
old=json.loads(old_path.read_bytes())
tree=ast.parse((D/'finish-controlled-system-report-draft-Audit-39-02.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='diff_apply');import re
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>', 'exec'),ns)
replacement=[
('actual ReportSystemEnergyUse3170 positive AirDistUnitCool/Heat reporting child','actual ReportSystemEnergyUse3173 AirDistUnitCool.InNode positive reporting child'),
('actual ReportVentilationLoads4203 positive AirDistUnitCool/Heat reporting child','actual ReportVentilationLoads4204 AirDistUnitCool.InNode positive reporting child'),
('actual ReportVentilationLoads3954 FanCoil OA getter','actual ReportVentilationLoads4021 FanCoil GetFanCoilOutAirNode child'),
('actual ReportVentilationLoads3981 PTUnit OA getter','actual ReportVentilationLoads4002 PTUnit compPointer.getMixerOANode child'),
('actual ReportVentilationLoads4010 WindowAC OA getter','actual ReportVentilationLoads3955 WindowAC GetWindowACOutAirNode child'),
('actual ReportVentilationLoads4037 UnitVentilator OA getter','actual ReportVentilationLoads4043 UnitVentilator GetUnitVentilatorOutAirNode child'),
('actual ReportVentilationLoads4084 ERV OA getter','actual ReportVentilationLoads4084 ERV GetStandAloneERVOutAirNode child'),
('actual ReportVentilationLoads4113 OutdoorAirUnit OA getter','actual ReportVentilationLoads4110 OutdoorAirUnit GetOutdoorAirUnitOutAirNode child'),
('actual ReportVentilationLoads4139 VRF OA getter','actual ReportVentilationLoads3977 VRF GetVRFTUOutAirNode child'),
('                    // Native4153-4178 explicitly excludes OA for these real types.','''                    14 => return Err(Error::Unavailable("actual ReportVentilationLoads4131 Hybrid GetHybridUnitaryACOutAirNode child")),
                    // Native4105-4107 has a separate actual empty UnitarySystem case.
                    33 => {}
                    // Native4153-4178 explicitly excludes OA for these real types.'''),
]
files=[];unchanged=[];proof=None
for i,row in enumerate(old['files'],1):
 name=row['canonical_path'];before=auth(row['before']).read_bytes();prev=auth(row['proposed']).read_bytes();new=prev
 assert before==(R/name).read_bytes()==subprocess.check_output(['git','show','19a2e63b5bc82ca3e8379d3c2a753bd420596901:'+name],cwd=R)
 if name.endswith('/ordinary_system_reports/reporting.rs'):
  s=prev.decode()
  for a,b in replacement:assert s.count(a)==1,a;s=s.replace(a,b,1)
  new=s.encode()
  assert prev[prev.index(b'                    12 => {'):prev.index(b'                    1 => return')]==new[new.index(b'                    12 => {'):new.index(b'                    1 => return')]
  f=''.join(difflib.unified_diff(prev.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='draft02/'+name,tofile='draft03/'+name));inv=''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),prev.decode().splitlines(keepends=True),fromfile='draft03/'+name,tofile='draft02/'+name))
  assert ns['diff_apply'](prev,f)==new and ns['diff_apply'](new,inv)==prev
  proof={'finding':'Root and Outer independently found missing Hybrid14 positive getter and actual Unitary33 empty case; positive diagnostic labels corrected to actual first Native operations.','original_draft':ref(old_path),'original_proposal':row['proposed'],'forward':save('correction/forward.diff',f.encode()),'inverse':save('correction/inverse.diff',inv.encode()),'literal_forward_inverse_exact':True,'PurchasedAir12_entire_arm_byte_identical':True,'normal_property_formulas_and_predefined_classification_suffix_byte_identical':True}
 else:unchanged.append(name)
 f=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='before/'+name,tofile='proposed/'+name));inv=''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='proposed/'+name,tofile='before/'+name))
 assert ns['diff_apply'](before,f)==new and ns['diff_apply'](new,inv)==before
 proposed=save('proposed/'+name,new);p=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',proposed['path']],capture_output=True);assert p.returncode==0,p.stderr
 files.append({'canonical_path':name,'before_absent':False,'before':save('before/'+name,before),'proposed':proposed,'forward_diff':save(f'diffs/{i:02}.forward.diff',f.encode()),'inverse_diff':save(f'diffs/{i:02}.inverse.diff',inv.encode()),'literal_forward_exact':True,'literal_inverse_exact':True,'before_whole_Git_exact_at_committed38':True,'Source_only_parse':dump(f'parse/{i:02}.json',{'exit_code':0,'stderr':p.stderr.decode(),'formatted_stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'syntax_only_not_typecheck':True})})
assert proof is not None and len(unchanged)==5
proof['other_five_proposal_wholes_unchanged_from02']=unchanged
actual_path=D/'Root-source-energy-report-initialization-actual-review-38-02/review.json';actual=json.loads(actual_path.read_bytes());assert ref(actual_path)['sha256'].startswith('89c5d592') and actual['accepted']
draft=dict(old);draft.update({'schema':'src06-controlled-system-report-draft39-03.v1','author_Source':ref(Path(__file__)),'original_draft':ref(old_path),'branch_correction':dump('branch-correction-proof.json',proof),'files':files,'base_HEAD':'19a2e63b5bc82ca3e8379d3c2a753bd420596901','accepted38_actual_review':ref(actual_path),'parent_producer':actual['producer'],'prior_complete_compiler_Source_plan':actual['complete_compiler_plan'],'historical_map_logical38_01_superseded':'The read-only map and previous draft references remain historical. Current authoritative actual38 corrected02 producer/plan are explicit here; selected six before files equal current committed38 Git/live. Full4508 archive/live readback is final sealer scope.','activation_status':'All six Sources frozen for independent full semantic review; actual38 observed ReportSystemEnergyUse3155 and committed38 parent authenticated; Source39 application/actual/scientific report cohort not yet executed.'})
p=O/'draft.json';p.write_text(json.dumps(draft,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

"""Prepare isolated checkpoint25 publication by literal accepted24 delta only."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'purchased-air-publication-prepared-Audit-25'
OLD=D/'publish-zone-equipment-orchestration-checkpoint-Peer-24.py'
NEW=D/'publish-purchased-air-checkpoint-Audit-25.py'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];got=ref(p);assert got['sha256']==r['sha256'] and got['bytes']==r.get('bytes',r.get('size_bytes',got['bytes'])),r;return p
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists() and not NEW.exists()
 parent_ref=ref(OLD);assert parent_ref['sha256']=='dd5afc9bb8fcf1e0ec05ba9f06fd41f4d802f0db86176ef35100947b2468b5a7'
 producer_ref=ref(D/'source-purchased-air-held-Audit-25/manifest.json')
 assert producer_ref['sha256']=='f6a1ed0cca7edde252943e0c6cec601ae10078ba7ce5922d97fe568312308b04'
 producer=json.loads(checked(producer_ref).read_bytes())
 old=OLD.read_text(encoding='utf-8');body=old
 replacements=[
  ('checkpoint24','checkpoint25'),
  ('zone-equipment-orchestration-publication-prepared-Peer-24','purchased-air-publication-prepared-Audit-25'),
  ('SRC-06-canonical-zone-equipment-orchestration-24','SRC-06-canonical-purchased-air-input-25'),
  ('zone-equipment-orchestration-publication-readback-Peer-24','purchased-air-publication-readback-Audit-25'),
  ('f1f40fc84f2a8bfa5f048600cf4880e7ccc53e68','e2711b73e32c48b861e8abcd47f19908bc172dab'),
  ("len(producer['files']) == 4 and producer['existing_Source_files'] == 3 and producer['new_Source_files'] == 1", "len(producer['files']) == 23 and producer['existing_Source_files'] == 17 and producer['new_Source_files'] == 6"),
  ('4492','4500'),('4479','4487'),
  ('Root-source-zone-equipment-orchestration-actual-review-24','Root-source-purchased-air-input-actual-review-25'),
  ('selected4_final_sources_exact','selected23_final_sources_exact'),
  ('canonical-source-zone-equipment-orchestration-B-NOLIMIT-24H-Root-24','canonical-source-purchased-air-input-B-NOLIMIT-24H-Root-25'),
  ('canonical-source-zone-equipment-orchestration-A-24H-Root-24','canonical-source-purchased-air-input-A-24H-Root-25'),
  ('canonical24-finite','canonical25-finite'),
  ('4 coherent zone equipment orchestration Sources','23 coherent PurchasedAir input/live-output Sources'),
  ('src06-canonical-zone-equipment-orchestration.v1','src06-canonical-purchased-air-input.v1'),
  ('Genuine Source zone equipment orchestration','Genuine Source PurchasedAir input/live-output'),
  ('positive zone equipment orchestration Native state equivalence','positive PurchasedAir numerical Native state equivalence'),
  ('canonical_zone_equipment_orchestration_24','canonical_purchased_air_input_25'),
  ('accepted23','accepted24'),('equal23','equal24'),
  ('[Source 구역 설비 시뮬레이션 진입 검증]','[Source IdealLoads 입력·보고 연결 검증]'),
 ]
 for before,after in replacements:
  assert before in body,before;body=body.replace(before,after)
 assert 'accepted23' not in body and 'equal23' not in body
 assert 'Root-source-zone-equipment-orchestration-actual-review-24' not in body
 ast.parse(body);assert '\ufffd' not in body
 NEW.write_text(body,encoding='utf-8',newline='\n');O.mkdir()
 files={}
 def add(row):
  path=checked(row);row=ref(path)
  assert path.suffix.lower()!='.zip'
  assert not any(x in row['path'] for x in ['controlled-air-native-capture','source-controlled-zone-numerical-draft','source-CalcMoreNodeInfo-draft'])
  assert row['path'] not in files or files[row['path']]==row
  files[row['path']]=row
 for row in [producer_ref,producer['complete_final_compiler_Source_plan'],producer['whole_crates_API_census'],producer['integration_contract'],
  producer['schema_custody'],producer['schema_integer_correction'],producer['same_Native_IDD_parser_installed_schema_bridge'],
  producer['independent_whole_Source_review'],producer['independent_full_output_Source_peer'],producer['accepted_input02'],producer['accepted_output02'],
  producer['accepted_constructor02'],producer['actual_parent_review'],producer['author_Source'],producer['sealer_Source'],ref(Path(__file__))]:add(row)
 for authority in producer['Native_authorities']:
  add(authority['whole'])
  for extent in authority['extents']:add(extent['source'])
 for row in producer['files']:
  for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(row[key])
  for key in ['stdout','stderr']:add(row['Source_only_parse'][key])
 previous=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-zone-equipment-orchestration-24/summary.json');add(previous)
 docs={
  'CHECKLIST.md':'IdealLoads 입력과 67개 보고 항목의 실시간 연결 결과를 정리했다. B의 실제 다음 경계와 A24 결과는 요약을 따른다.',
  'STATE_CONTRACTS.md':'PurchasedAir는 13개 모듈 필드와 134개 장비 필드를 보존하며, 실수 66개·정수 1개 보고값은 같은 장비 상태를 참조한다. Node·스케줄 연결에도 기존 실제 소유자를 사용한다.',
  'cards/SRC-06.md':'PurchasedAir 입력과 실제 장비의 보고 선언을 연결했다. B는 `{{actual_B_frontier}}`에서 중단되며, B 전체 완료는 후속 작업이다.',
 }
 assert len(set(docs.values()))==3
 for value in docs.values():assert '\ufffd' not in value and value.encode('utf-8').decode('utf-8')==value
 template=dict(schema='src06-held-canonical25-publication-template.v1',status='HELD_FOR_ROOT_REVIEW_ACTUAL_AND_PEER_HASHES_REQUIRED',
  base_HEAD=producer['base_HEAD'],producer=producer_ref,complete_plan=producer['complete_final_compiler_Source_plan'],previous_checkpoint=previous,
  publisher_Source=ref(NEW),publisher_parent_Source=parent_ref,
  expected_actual_review_path='.runtime/porting/SRC-06/Root-source-purchased-air-input-actual-review-25/review.json',
  pending_Root_custody=dict(actual_review_sha256='REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
   independent_final_join_peer='REQUIRED_AT_PUBLISH_VIA_PEER_PATH_AND_SHA_ARGUMENTS',
   application='.runtime/porting/SRC-06/Root-purchased-air-input-application-25/receipt.json',
   application_Source='.runtime/porting/SRC-06/apply-purchased-air-input-Root-25.py',
   actual_checker_Source='.runtime/porting/SRC-06/check-source-purchased-air-input-actual-Root-25.py',
   launcher_Source='.runtime/porting/SRC-06/launch-purchased-air-input-Root-25.py',
   B_CLI='.runtime/porting/SRC-06/canonical-source-purchased-air-input-B-NOLIMIT-24H-command-Root-25/receipt.json',
   A24_CLI='.runtime/porting/SRC-06/canonical-source-purchased-air-input-A-24H-command-Root-25/receipt.json'),
  Root_custody_at_publish='Accepted aggregate/application/launcher/checker/actual B/A receipts and direct artifacts byte-checked and archived by the unchanged24 publication algorithm; no placeholder authorizes publish.',
  summary_template=dict(A='14/54',B='14/64',changed_Rust_sources=23,existing_Rust_sources=17,new_Rust_sources=6,new_test_functions=0,actual_test_bodies_executed=0,
   focused_validation_policy='Two actual production CLI runs B then A24. No extra test-profile or routine alltargets rerun; existing one Native1168/77 predictor cohort preserved unchanged.',
   scope='Genuine PurchasedAir13module/134unit retained owners and shared raw input/Node/Schedule/config writes; all67 Native System declarations read66real+1integer live owner fields, with exactly2true fuel meters. Actual executed scope/frontier comes only from Root aggregate; Init/Calc/fullB remain unclaimed.',
   full_B_or_finite15_completion_claim=False,Native_harness_runtime_or_unit_equivalence_claim=False,gate_changes=False,policy_changes=False),
  doc_appends=docs,finite_archive_inputs=[r for _,r in sorted(files.items())],finite_archive_input_count=len(files),finite_archive_input_bytes=sum(r['bytes'] for r in files.values()),
  publisher_executed=False,canonical_docs_mutations=False,Cargo_tests_Native_executed=False,gate_changes=False)
 template_ref=save(O/'publication-template.json',template)
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'))
 fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re}
 exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal publisher delta>','exec'),ns)
 changes={}
 for name,a,b in [('forward',old.encode('utf-8'),body.encode('utf-8')),('inverse',body.encode('utf-8'),old.encode('utf-8'))]:
  diff=''.join(difflib.unified_diff(a.decode('utf-8').splitlines(keepends=True),b.decode('utf-8').splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode('utf-8')
  assert ns['apply'](a,diff)==b
  path=O/(name+'.diff');path.write_bytes(diff);changes[name]=ref(path)
 bridge=save(O/'publisher-parent-bridge.json',dict(parent=parent_ref,successor=ref(NEW),literal_applications=2,changes=changes,
  scope='Checkpoint/name/path/baseHEAD/4500-4487-selected23/accepted24-proof labels and UTF8 link title only. Entire accepted24 archive/docs/oneSRC06-key publication algorithm retained.',
  Source_semantic_changes=False,actuals_pending=True,publisher_executed=False,canonical_mutations=False))
 print(json.dumps(dict(template=template_ref,publisher=ref(NEW),parent_bridge=bridge)))
if __name__=='__main__':main()

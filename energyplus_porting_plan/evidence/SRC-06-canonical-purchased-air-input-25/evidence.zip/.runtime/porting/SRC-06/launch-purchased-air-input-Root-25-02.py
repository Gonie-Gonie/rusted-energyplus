from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-zone-equipment-orchestration-B-NOLIMIT-24H-command-Root-24/receipt.json','b35cc057d92439bb8fa4c6ec67084661c2b8ec4d8314813a10c707ac052eac9c'),
 'A24':('canonical-source-zone-equipment-orchestration-A-24H-command-Root-24/receipt.json','0cc0a6f9b0690d41b7c023f826ba7193a2c42552373a2c2dc82b2e394e115216'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-purchased-air-input-'+case+'-command-Root-25-02'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-purchased-air-input-'+case+'-Root-25-02/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-purchased-air-IDF-metadata-application-25';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-purchased-air-IDF-metadata-held-Peer-25/manifest.json');assert mr['sha256']=='0e83d9891451eca0f96e1871bd8ac541b3f3a7eb559ab4c277466f69cbecf547';m=json.loads(checked(mr));assert len(m['files'])==1
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['observed_HEAD']=='e2711b73e32c48b861e8abcd47f19908bc172dab'
previous=json.loads(checked(m['failed25_B_receipt']));assert previous['exit_code']==6 and previous['source_bytes_match_before_and_after'];parents={v['historical_path']:v for v in json.loads(checked(m['failed25_snapshot']))['files']};assert len(parents)==4500
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive'])
f=m['files'][0];n=f['canonical_path'];a=checked(f['before']);b=checked(f['proposed']);assert n=='crates/ep_raw_model/src/idf_order.rs' and a==(R/n).read_bytes()==checked(m['selected_actual_parent_archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R)
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(v for v in t.body if isinstance(v,ast.FunctionDef) and v.name=='apply')],type_ignores=[]),'<literal>','exec'))
assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and a.count(b'#[test]')==b.count(b'#[test]')
assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr'])
for v in m['Native_authorities']:
 whole=checked(v['whole']);assert whole==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(whole.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source'])
schema=json.loads(checked(m['installed_schema']))['properties']['ZoneHVAC:IdealLoadsAirSystem'];assert schema['min_fields']==27 and len(schema['legacy_idd']['fields'])==32 and schema['legacy_idd']['fields'][0]=='name'
idf=checked(m['actual_physical_B_input']);assert idf==checked(m['actual_failed_staged_IDF']);text=re.sub(rb'!.*',b'',idf);objects=[v.strip() for v in text.split(b';')];units=[v.split(b',')[1:] for v in objects if v.split(b',')[0].strip().lower()==b'zonehvac:idealloadsairsystem'];assert len(units)==1 and len(units[0])==32 and [v.strip().decode('utf8') for v in units[0]]==m['actual_physical_IdealLoads_objects'][0]['physical_fields']
O.mkdir();(R/n).write_bytes(b);assert (R/n).read_bytes()==b
for path,v in parents.items():assert (R/path).read_bytes()==(b if path==n else checked(v['archive']))
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,original25_B=m['failed25_B_receipt'],actual_parent_snapshot=m['failed25_snapshot'],selected={n:f},all4500_original_inputs_authenticated=True,all4499_other_inputs_unchanged=True,literal_applications=2,new_test_bodies=0,existing_test_extended=m['existing_test'],semantic_review='Root fullread existing recovery271–617/metadata table1129+, all3598-byte correction diff and pinned NativeIdfParser309–405/IDD IdealLoads min-fields27. Adds same actual family target/name0 + staged physical count transport with genuine semicolon max(count,27), preserves Native END as bounded explicit EOF rejection before any model publication. Independently counted actual staged B32 physical fields. Two-instance existing table checks actual order and27/32 plus two EOF transaction failures. No count inferred from nonblank/defaulted values or hardcoded NumNums; original23 Source proposals unchanged. Root one focused existing raw libtest and corrected actual B/A remain required.',Cargo_Native_or_tests_executed=False,author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

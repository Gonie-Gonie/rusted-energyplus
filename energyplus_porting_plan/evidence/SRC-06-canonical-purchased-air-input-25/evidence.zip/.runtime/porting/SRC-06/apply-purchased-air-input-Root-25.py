from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-purchased-air-input-application-25';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-purchased-air-held-Audit-25/manifest.json');assert mr['sha256']==sys.argv[1];m=json.loads(checked(mr))
pr=ref(R/sys.argv[2]);assert pr['sha256']==sys.argv[3];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['producer']==mr
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='e2711b73e32c48b861e8abcd47f19908bc172dab' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']}
inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4494 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
root=json.loads(checked(m['independent_whole_Source_review']));assert root['accepted'] and not root['findings'];rootfiles={v['canonical_path']:v for v in root['Source_wholes']}
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
 assert hashlib.sha256(b).hexdigest()==rootfiles[n]['sha256'] and len(b)==rootfiles[n]['bytes'] and b==checked(f['literal_origin_whole'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==23 and len(new)==6 and tests==0 and set(rootfiles)==set(selected)
native=R/'.reference/energyplus-src/26.1.0';rev=m['Native_commit'];assert rev=='6f2e40d10250a105b49966baa24d843711e61048';extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',rev+':'+v['Native_path']],cwd=native)
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==10 and extent_count==24
for k in ['actual_parent_review','actual_parent_focused_test','parent_complete_plan','accepted_input02','accepted_output02','accepted_constructor02','independent_full_output_Source_peer','schema_custody','schema_integer_correction','whole_crates_API_census','integration_contract']:checked(m[k])
for v in m['cohort3_whole_unchanged']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole']) and v['canonical_path'] not in selected
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4500 and sum(n.endswith('.rs') for n in rows)==4487
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'];assert b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,Root_Source_review=m['independent_whole_Source_review'],complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4494,final_inputs=4500,final_Rust_sources=4487,selected_Rust=23,new_Rust=6,literal_applications=46,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root fullinput/constructor/output draft acceptance carries through exact23Source literal composition; independent Coil output review and Outer finaljoin accepted. Same actual equipment/Node/shortcut/Schedule/EquipIndex owners, all67 ordered live declarations including66real and i32status, exact two HVAC district-fuel meters and Cooling tabular branch. No production Native operands/CP facade/fake response. Actual InitPurchasedAir remains real next callee boundary. No new tests or tolerance/gate changes. Actual B/A24 remains required.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

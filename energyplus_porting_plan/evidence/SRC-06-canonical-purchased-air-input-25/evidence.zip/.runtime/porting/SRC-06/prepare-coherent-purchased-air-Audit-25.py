"""Literal coherent Source25 assembly preparation; no main/Cargo/test execution."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'source-purchased-air-held-Audit-25';N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b))),r['path'];return b
def load(r):return json.loads(checked(r))
def write_json(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(path)
def main():
 assert not (O/'prepared.json').exists() and not (O/'manifest.json').exists()
 input_ref=ref(D/'source-purchased-air-input-draft-Peer-25-02/draft.json')
 output_ref=ref(D/'source-purchased-air-output-routing-draft-Audit-25-02/draft.json')
 assert input_ref['sha256']=='18f1f37e6c8ed1db5ae0c80f212524d2abf26247879e411095ac1b744cade49d'
 assert output_ref['sha256']=='bee67804b0b30483fe45153e83eb0b9e2868d673e1f7c2543413d58a186b5562'
 inp=load(input_ref);out=load(output_ref)
 root_peer_ref=ref(D/'Root-purchased-air-input-output-draft-review-25/review.json')
 root_peer=load(root_peer_ref);assert root_peer_ref['sha256']=='2e923a13f95c30b0af3d2558b50594927ff2a850c90d1279b3bc146ebb67f79b'
 assert root_peer['accepted'] and not root_peer['findings'] and root_peer['input_draft']==input_ref and root_peer['output_draft']==output_ref
 actual_ref=ref(D/'Root-source-controlled-prediction-cohort-actual-review-21/review.json');actual=load(actual_ref)
 assert actual['accepted'] and not actual['findings'] and actual['all4494_inputs_exact_final_plan_and_live']
 assert actual['actual_executed_test_bodies']==1
 run=load(actual['actual_focused_test']);assert run['exit_code']==0 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
 assert run['source_snapshot']['sha256']==actual['actual_snapshot']['sha256']
 snapshot={x['historical_path']:x for x in load(actual['actual_snapshot'])['files']}
 parent={x['path']:x for x in load(actual['complete_compiler_plan'])['entries']};assert len(snapshot)==len(parent)==4494
 assert sum(p.endswith('.rs') for p in parent)==4481
 # Rehash the sole actual focused-test snapshot/live parent once, not thousands
 # of individual historical Git processes. Final sealing checks 17 selected Git.
 for name,row in snapshot.items():
  raw=checked(row['archive']);assert len(raw)==row['size_bytes']
  assert raw==(R/name).read_bytes() and sha(raw)==parent[name]['final_sha256'] and len(raw)==parent[name]['final_bytes'],name
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'))
 fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re}
 exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal patch>','exec'),ns)
 rows=[];selected={};originals={}
 for group,packet in [('input02',inp),('output02',out)]:
  for row in packet['files']:
   name=row['canonical_path'];assert name not in selected and name.endswith('.rs')
   before=b'' if row.get('before') is None else checked(row['before']);after=checked(row['proposed'])
   if row['before_absent']:assert before==b'' and name not in parent and not (R/name).exists()
   else:assert before==checked(snapshot[name]['archive'])==(R/name).read_bytes()
   forward=checked(row['forward_diff']);inverse=checked(row['inverse_diff'])
   assert ns['apply'](before,forward)==after and ns['apply'](after,inverse)==before
   if row.get('literal_inverse'):assert checked(row['literal_inverse'])==before
   for folder,b in [('before',before),('proposed',after),('literal-inverse',before)]:
    p=O/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
   index=len(rows)+1;diffs=[]
   for suffix,b in [('forward',forward),('inverse',inverse)]:
    p=O/'diffs'/f'{index:02d}-{suffix}.diff';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);diffs.append(ref(p))
   parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert parse.returncode==0,(name,parse.stderr)
   p=O/'parse'/f'{index:02d}.stdout';e=O/'parse'/f'{index:02d}.stderr';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(parse.stdout);e.write_bytes(parse.stderr)
   added='\n'.join(x[1:] for x in forward.decode('utf-8').splitlines() if x.startswith('+') and not x.startswith('+++'))
   assert not re.search(r'\.(unwrap|expect)\s*\(|\b(panic|todo|unimplemented|unreachable)!|#\[(test|ignore)',added)
   rows.append(dict(canonical_path=name,before_absent=row['before_absent'],before=ref(O/'before'/name),
    actual_parent_archive=None if row['before_absent'] else snapshot[name]['archive'],proposed=ref(O/'proposed'/name),literal_inverse=ref(O/'literal-inverse'/name),
    forward_diff=diffs[0],inverse_diff=diffs[1],origin_group=group,literal_origin_whole=row['proposed'],
    Source_only_parse=dict(exit_code=0,stdout=ref(p),stderr=ref(e))))
   selected[name]=after;originals[name]=before
 assert len(selected)==23 and sum(x['before_absent'] for x in rows)==6
 assert {x['canonical_path']:(x['sha256'],x['bytes']) for x in root_peer['Source_wholes']}=={p:(sha(b),len(b)) for p,b in selected.items()}
 # Authoritative cold owner bytes remain exactly ctor02 and actual input02.
 ctor=load(out['constructor']);owner_name='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/owners.rs'
 assert selected[owner_name]==checked(ctor['proposed']) and len(ctor['unit_members'])==134 and len(ctor['module_members'])==13
 cohort=load(actual['producer']);cohort_refs=[]
 for item in cohort['files']:
  name=item['canonical_path'];assert name not in selected
  assert checked(item['proposed'])==checked(snapshot[name]['archive'])==(R/name).read_bytes();cohort_refs.append(dict(canonical_path=name,whole=snapshot[name]['archive']))
 # Closed compiler overlay: only the 23 literal proposals change/add rows.
 entries=[]
 for name in sorted(set(snapshot)|set(selected)):
  source=ref(O/'proposed'/name) if name in selected else dict(snapshot[name]['archive'],bytes=snapshot[name]['size_bytes'])
  entries.append(dict(path=name,final_sha256=source['sha256'],final_bytes=source['bytes'],source=source,
   origin='literal accepted input02/output02 proposal' if name in selected else 'whole exact actual focused cohort02 archived parent'))
 assert len(entries)==4500 and sum(x['path'].endswith('.rs') for x in entries)==4487
 plan_entries=write_json(O/'prepared-compiler-Source-entries.json',dict(inputs=4500,Rust_sources=4487,entries=entries))
 # Exact bounded Native closure; declaration bodies are shared, never replayed
 # against 389MB observations or copied prior publication archives.
 ranges={
  'src/EnergyPlus/PurchasedAirManager.cc':[(144,1058)],
  'src/EnergyPlus/PurchasedAirManager.hh':[(69,325),(390,405)],
  'src/EnergyPlus/OutputProcessor.cc':[(1037,1277),(1309,1477),(1501,1611),(2002,2125),(3003,3240)],
  'src/EnergyPlus/OutputProcessor.hh':[(118,132),(407,424),(818,834)],
  'src/EnergyPlus/DataGlobalConstants.hh':[(99,172),(223,237),(288,337)],
  'src/EnergyPlus/InputProcessing/InputProcessor.cc':[(621,687),(747,887),(932,1070),(1216,1260)],
  'third_party/ObjexxFCL/src/ObjexxFCL/Array1D.hh':[(473,483),(1421,1427)],
  'src/EnergyPlus/NodeInputManager.cc':[(740,949)],
  'src/EnergyPlus/DataLoopNode.hh':[(145,425)],
  'src/EnergyPlus/BranchNodeConnections.cc':[(346,354),(633,633)],
 }
 authorities=[]
 for name,extents in ranges.items():
  raw=(N/name).read_bytes();assert raw==subprocess.check_output(['git','show',PIN+':'+name],cwd=N)
  path=O/'Native'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
  lines=raw.splitlines(keepends=True);fragments=[]
  for first,last in extents:
   fragment=b''.join(lines[first-1:last]);p=O/'Native-extents'/f'{Path(name).name}.{first}-{last}.txt';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(fragment)
   fragments.append(dict(first=first,last=last,source=ref(p)))
  authorities.append(dict(Native_path=name,whole=ref(path),extents=fragments,pinned_Git_exact=True))
 schema=load(inp['schema_custody']);installed=json.loads(checked(schema['installed_schema']))
 assert schema['complete_Native_object']==installed['properties']['ZoneHVAC:IdealLoadsAirSystem']
 schema_ref=inp['schema_custody'];correction=load(inp['schema_integer_correction'])
 grammar_ref=ref(D/'ordinary-source-B-raw-ingress-held-Audit-01/schema-authority.json');grammar=load(grammar_ref)
 assert grammar_ref['sha256']=='a2c165fd813f7db29ecf2c9abe3da6ea1afbc9196bd723ea7be0dc966a9ceffe'
 assert grammar['Original_commit']==PIN and grammar['all_seven_whole_installed_objects_equal_pinned_producer']
 # Whole crate/API census over the actual4494 + literal23 overlay. Includes
 # test Sources and precise line text so no public caller or aggregate is lost.
 patterns=['SourcePurchasedAir','purchased_air','manage_source_zone_equipment','simulate_source_zone_equipment',
  'SourceAllIntegerOutputOwners','SourceRealOutputTarget','SourceIntegerOutputTarget','SourceMeterGroup',
  'SourceMeterResource','SourceMeterIpUnits','get_source_only_single_node','check_source_unique_node_names','init_unique_check_source']
 ledger=[]
 for row in entries:
  name=row['path']
  if not name.startswith('crates/') or not name.endswith('.rs'):continue
  raw=checked(row['source']);body=raw.decode('utf-8')
  wanted=[x for x in patterns if x in body]
  if not wanted:continue
  hits=[dict(line=i,text=line,patterns=[p for p in wanted if p in line]) for i,line in enumerate(body.splitlines(),1) if any(p in line for p in wanted)]
  ledger.append(dict(canonical_path=name,whole=row['source'],hits=hits))
 census=write_json(O/'whole-crates-API-census.json',dict(patterns=patterns,Rust_sources=4487,scope='all actual4494 archived crate Rust + all23 literal proposals; includes tests',files=ledger))
 contract=write_json(O/'integration-contract.json',dict(
  module_owner='OrdinaryEquipment.purchased_air: SourcePurchasedAirManager; sole13-member cold owner; units Option<Vec<SourceZonePurchasedAir>> with134 exact member defaults. No CP442 facade or ready proxy.',
  input='Whole finite SimPurchasedAir entry/GetInput: shared21alpha11numeric physical metadata/raw values; NumericFieldNames whole RHS assignment; same physical Node/Unique/Branch/Schedule/config owners; actual67 declarations before EMS/error/Init boundary.',
  output_API=out['API'],output_context='SourcePurchasedAirReportingOutputContext exact9 Node-context fields; same live registration, retained input, prescan, reports, request frequency, timestepminutes, host, dictionaryhost and EIO.',
  actual_management='SourceHvacProviderHost passes &mut self.output/eio to generic real manager, through same simulate method to actual type12; same mutable EquipmentList CompIndex reborrow at each native operation.',
  live_targets='SourceRealOutputTarget::PurchasedAir{field,index:i32} maps all66fields by ctor Native mapping on same equipment; PurchasedAirAvailabilityStatus binds same actual &i32. System output read borrows same equipment; partial views explicitly typed unavailable.',
  meters='Exactly2 actual SupplyAir total fuel energy declarations; eFuel2eResource finite supported mapping; actualHVAC1/heating0/cooling1; DistrictHeatingWater11 defaultJ IP and DistrictCooling10/Cooling3; existing meter/order/counters reused; true cooling tabular5 columns and conversion.',
  no_new_scientific_kernel=True,no_Native_answer_dependency=True,no_new_test_bodies=True,no_new_Cargo_or_public_API=True,
  honest_boundaries=['actual InitPurchasedAir201 remains next callee boundary, not observed until Root actual25.',
  'Positive unrepresented autosize/errors/OA/EMS/returnplenum/humidity/sizing/otherfuel/IDF-multiinstance branches retain typed actual-operation boundaries. No forcing count0 or flags to skip children.',
  'Source20/18 remain separate held unreached work; no full B completion or numerical trajectory claim.'],
  test_policy='No new tests or mandatory duplicate all-targets build. Root will build/run actual production B then A24; existing focused Native predictor cohort remains preserved exactly. Wider checks only for concrete integration reason.'))
 prepared=dict(status='UNSEALED coherent Source25 literal assembly; final committed cohort HEAD and independent output peer required before manifest',
  observed_HEAD_metadata_only=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
  actual_parent_review=actual_ref,actual_parent_snapshot=actual['actual_snapshot'],actual_parent_focused_test=actual['actual_focused_test'],parent_complete_plan=actual['complete_compiler_plan'],
  input_draft=input_ref,output_draft=output_ref,Root_independent_Source_review=root_peer_ref,constructor=out['constructor'],
  files=rows,existing_Source_files=17,new_Source_files=6,literal_applications=46,Source_only_parses=23,
  prepared_complete_compiler_entries=plan_entries,compiler_inputs=4500,Rust_sources=4487,cohort3_whole_unchanged=cohort_refs,
  Native_commit=PIN,Native_authorities=authorities,Native_wholes=len(authorities),Native_extents=sum(len(x['extents']) for x in authorities),
  schema_custody=schema_ref,schema_integer_correction=inp['schema_integer_correction'],same_Native_IDD_parser_installed_schema_bridge=grammar_ref,
  whole_crates_API_census=census,integration_contract=contract,
  authority_qualification='Bound whole pinned Native and exact extents + existing schema parser bridge; reuses accepted Source/fixture proofs without replaying Native389MB observations. All Source proposals literal originals; no new semantic assembly delta.',
  base_seal_pending=True,Cargo_main_or_Native_mutations_or_test_execution=False,author_Source=ref(Path(__file__)))
 print(json.dumps(write_json(O/'prepared.json',prepared)))
if __name__=='__main__':main()

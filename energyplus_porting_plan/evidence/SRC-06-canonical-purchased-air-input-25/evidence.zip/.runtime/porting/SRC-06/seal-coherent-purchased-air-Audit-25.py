"""Seal unchanged prepared Source25 against the genuine committed cohort parent."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-purchased-air-held-Audit-25'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b))),r['path'];return b
def load(r):return json.loads(checked(r))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 head=sys.argv[1];assert re.fullmatch('[0-9a-f]{40}',head)
 assert not (O/'manifest.json').exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
 assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=R,text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R)
 prepared_ref=ref(O/'prepared.json');assert prepared_ref['sha256']=='6c6010abc93b7b6b9fbb221165d0e3776de397f0f12b61407a86d7ff4932d547'
 p=load(prepared_ref);assert p['existing_Source_files']==17 and p['new_Source_files']==6
 root=load(p['Root_independent_Source_review']);assert root['accepted'] and not root['findings']
 peer_ref=ref(D/'Peer-purchased-air-output-routing-Source-review-25/review.json')
 assert peer_ref['sha256']=='1c88cf03a10cd904fd9cb627c4c3b96ae7b74707afb252e40afb64ab3ee7fd8d'
 peer=load(peer_ref);assert peer['status']=='ACCEPTED independent bounded full Source/Native output-routing review; no findings'
 assert peer['reviewed_output_draft']==p['output_draft']
 selected=[]
 for row in p['files']:
  before=checked(row['before']);after=checked(row['proposed']);assert before==checked(row['literal_inverse'])
  if row['before_absent']:
   assert before==b'' and not (R/row['canonical_path']).exists()
   assert subprocess.run(['git','cat-file','-e',head+':'+row['canonical_path']],cwd=R,capture_output=True).returncode!=0
  else:
   assert before==(R/row['canonical_path']).read_bytes()==checked(row['actual_parent_archive'])
   assert before==subprocess.check_output(['git','show',head+':'+row['canonical_path']],cwd=R)
  row=dict(row)
  if not row['before_absent']:row['before_whole_Git_exact_at_base']=True
  selected.append(row)
  assert row['Source_only_parse']['exit_code']==0
  checked(row['forward_diff']);checked(row['inverse_diff']);checked(row['Source_only_parse']['stdout']);checked(row['Source_only_parse']['stderr'])
 for row in p['cohort3_whole_unchanged']:
  raw=checked(row['whole']);assert raw==(R/row['canonical_path']).read_bytes()
  assert raw==subprocess.check_output(['git','show',head+':'+row['canonical_path']],cwd=R)
 # Parent snapshot/live hashes were completely verified during preparation;
 # clean committed state and selected17 exact Git make the metadata rebase
 # explicit. The complete immutable overlay itself is rehashed below.
 entries=load(p['prepared_complete_compiler_entries'])
 assert entries['inputs']==4500 and entries['Rust_sources']==4487 and len(entries['entries'])==4500
 for row in entries['entries']:
  raw=checked(row['source']);assert sha(raw)==row['final_sha256'] and len(raw)==row['final_bytes']
 for row in p['Native_authorities']:
  checked(row['whole'])
  for extent in row['extents']:checked(extent['source'])
 plan_ref=save(O/'complete-final-compiler-Source-plan.json',dict(schema='src06-complete-Source25-compiler-input-plan.v1',base_HEAD=head,
  parent_actual_snapshot=p['actual_parent_snapshot'],parent_actual_review=p['actual_parent_review'],inputs=4500,Rust_sources=4487,
  entries=entries['entries'],selected_sources23_literal=True,all_cohort3_sources_whole_unchanged=True,Root_full_rehash_required=True))
 manifest=dict(schema='src06-held-coherent-purchased-air-input-live-output.v1',status='HELD sealed Source25; Root production B/A execution pending',
  base_HEAD=head,base_HEAD_origin_main_clean=True,Native_commit=p['Native_commit'],
  actual_parent_review=p['actual_parent_review'],actual_parent_snapshot=p['actual_parent_snapshot'],actual_parent_focused_test=p['actual_parent_focused_test'],parent_complete_plan=p['parent_complete_plan'],
  accepted_input02=p['input_draft'],accepted_output02=p['output_draft'],accepted_constructor02=p['constructor'],
  independent_whole_Source_review=p['Root_independent_Source_review'],independent_full_output_Source_peer=peer_ref,
  prepared_literal_assembly=prepared_ref,files=selected,existing_Source_files=17,new_Source_files=6,literal_applications=46,Source_only_parses=23,
  complete_final_compiler_Source_plan=plan_ref,compiler_inputs=4500,Rust_sources=4487,cohort3_whole_unchanged=p['cohort3_whole_unchanged'],
  Native_authorities=p['Native_authorities'],Native_wholes=p['Native_wholes'],Native_extents=p['Native_extents'],
  schema_custody=p['schema_custody'],schema_integer_correction=p['schema_integer_correction'],same_Native_IDD_parser_installed_schema_bridge=p['same_Native_IDD_parser_installed_schema_bridge'],
  whole_crates_API_census=p['whole_crates_API_census'],integration_contract=p['integration_contract'],
  semantic_join='All23 proposed wholes exactly equal already reviewed input02/output02; no semantic/literal Source correction during assembly. Only final committed parent/plan/peer metadata attached.',
  Git_scope='17 selected old before Sources and3 preserved cohort Sources whole Git-exact at clean base. Complete4494 actual focused-test snapshot/archive/live was checked once during preparation; complete4500 immutable overlay rehashed at seal. No blanket all-input Git-blob equality claim (known unselected scheduled_output CR physical bridge remains inherited).',
  achieved_Source_scope='Genuine retained PurchasedAir13module/134unit constructor + actual shared raw GetInput and Node/Schedule/config writes + all67 actual declarations (66real/1integer), exact two fuel meters and live reporting route, through actual next InitPurchasedAir201 boundary.',
  actual25_execution_pending=True,new_test_bodies=0,Cargo_or_public_API_changes=False,
  validation_policy='Root production B then A24 on complete4500 compiler snapshot; no habitual separate all-targets/test suite or new Native run. Existing successful single1168/77 Native-cohort Source/fixture retained byte-exact.',
  qualifications=['Source-only held; no actual25 frontier/completion or full B numerical claim before Root receipts.',
  'Unrepresented positive operations remain typed boundaries at genuine consumption; no zero-count/ready/flag or CP442 facade substitutions.',
  'Source20/18 remain held; original gate counts and tolerance policy unchanged.'],
  main_Cargo_tests_or_Native_mutations=False,author_Source=p['author_Source'],sealer_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'manifest.json',manifest)));print(json.dumps(plan_ref))
if __name__=='__main__':main()

import ast
import difflib
import hashlib
import json
import re
import subprocess
from pathlib import Path

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
OUT=D/'source-purchased-air-IDF-metadata-held-Peer-25'
N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
BASE='e2711b73e32c48b861e8abcd47f19908bc172dab'
NAME='crates/ep_raw_model/src/idf_order.rs'
FAMILY='ZoneHVAC:IdealLoadsAirSystem'

def ref(p):
    p=Path(p);b=p.read_bytes()
    return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}

def auth(r):
    p=R/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
    if 'bytes' in r:assert len(b)==r['bytes']
    return p

def save(name,data):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data);return ref(p)

def git(repo,rev,name):
    return subprocess.run(['git','-C',str(repo),'show',rev+':'+name],capture_output=True,check=True).stdout

assert not OUT.exists()
receipt_path=D/'canonical-source-purchased-air-input-B-NOLIMIT-24H-command-Root-25/receipt.json'
receipt=json.loads(receipt_path.read_bytes());assert receipt['exit_code']==6 and receipt['source_bytes_match_before_and_after']
snapshot_path=auth(receipt['source_snapshot']);snapshot=json.loads(snapshot_path.read_bytes())
raw=next(x for x in snapshot['files'] if x['historical_path']==NAME)
before=auth(raw['archive']).read_bytes()
assert before==(R/NAME).read_bytes()==git(R,BASE,NAME)
assert len(snapshot['files'])==4500
text=before.decode()
anchor='''    // ScheduleManager uses getObjectItem's preserved IDF order within these
'''
assert text.count(anchor)==1
text=text.replace(anchor,'''    // PurchasedAir's real getter consumes IDF order and physical max-fields metadata.
    IdfOrderTarget {
        object_type: "ZoneHVAC:IdealLoadsAirSystem",
        name_field_index: 0,
    },
'''+anchor)
anchor='''                        | "ZoneControl:Thermostat"
'''
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'''                        | "ZoneHVAC:IdealLoadsAirSystem"
''')
anchor='''                        "RunPeriod" => idf_object.max_fields.max(7),
'''
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'''                        // Pinned IdealLoads IDD/schema min_fields is 27; only semicolon records reach this padding.
                        "ZoneHVAC:IdealLoadsAirSystem" => idf_object.max_fields.max(27),
''')
anchor='''                || object_type.eq_ignore_ascii_case("ZoneControl:Thermostat"))
'''
assert text.count(anchor)==1
text=text.replace(anchor,'''                || object_type.eq_ignore_ascii_case("ZoneControl:Thermostat")
                || object_type.eq_ignore_ascii_case("ZoneHVAC:IdealLoadsAirSystem"))
''')
anchor='''                Some([2, 4]),
            ),
        ] {
'''
assert text.count(anchor)==1
long_fields='A,Availability,Supply,,,50,13,0.0156,0.0077,NoLimit,,,NoLimit,,,,,None,0.7,None,,,None,NoEconomizer,None,0.7,0.65,,,DistrictHeatingWater,,DistrictCooling'
assert len(long_fields.split(','))==32
text=text.replace(anchor,'''                Some([2, 4]),
            ),
            (
                "ZoneHVAC:IdealLoadsAirSystem",
                "ZoneHVAC:IdealLoadsAirSystem,Z;ZoneHVAC:IdealLoadsAirSystem,'''+long_fields+''';",
                Some([27, 32]),
            ),
        ] {
''')
anchor='''            assert_eq!(eof_design_day, before_eof);
        }
        Ok(())
'''
assert text.count(anchor)==1
text=text.replace(anchor,'''            assert_eq!(eof_design_day, before_eof);
        }
        let mut eof_ideal_loads = parse_epjson_str(r#"{"ZoneHVAC:IdealLoadsAirSystem":{"A":{}}}"#)?;
        for idf in [
            "zonehvac:idealloadsairsystem,a",
            "ZoneHVAC:IdealLoadsAirSystem,A,",
        ] {
            let before_eof = eof_ideal_loads.clone();
            let error = apply_idf_declaration_order(&mut eof_ideal_loads, idf, IDF_ORDER_TARGETS)
                .err()
                .ok_or("unterminated IdealLoads must remain unavailable")?;
            assert!(error.to_string().contains("terminating semicolon"));
            assert_eq!(eof_ideal_loads, before_eof);
        }
        Ok(())
''')
after=text.encode()
assert text.count('#[test]')==before.decode().count('#[test]')

# Literal application proves one Source edit and its inverse; no canonical mutation.
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
fwd=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+NAME,tofile='b/'+NAME)).encode()
inverse=''.join(difflib.unified_diff(text.splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='a/'+NAME,tofile='b/'+NAME)).encode()
assert ns['apply_literal'](before,fwd)==after and ns['apply_literal'](after,inverse)==before
parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True,cwd=R)
assert parsed.returncode==0,parsed.stderr
file={'canonical_path':NAME,'before_absent':False,'before':save('before/'+NAME,before),'proposed':save('proposed/'+NAME,after),'literal_inverse':save('literal-inverse/'+NAME,before),'forward_diff':save('diffs/01-forward.diff',fwd),'inverse_diff':save('diffs/01-inverse.diff',inverse),'Source_only_parse':{'exit_code':0,'stdout':save('parse/stdout',parsed.stdout),'stderr':save('parse/stderr',parsed.stderr)}}

authorities=[]
for name,ranges in [('src/EnergyPlus/InputProcessing/IdfParser.cc',[(309,405)]),('idd/Energy+.idd.in',[(35807,36042)])]:
    b=git(N,PIN,name);assert b==(N/name).read_bytes()
    whole=save('Native/'+name,b);lines=b.splitlines(keepends=True)
    extents=[{'first':a,'last':z,'source':save('Native-extents/'+Path(name).name+f'.{a}-{z}.txt',b''.join(lines[a-1:z]))} for a,z in ranges]
    authorities.append({'Native_path':name,'whole':whole,'extents':extents,'pinned_Git_exact':True})
idd=auth(authorities[1]['extents'][0]['source']).read_text(encoding='utf-8')
assert re.search(r'\\min-fields\s+27\b',idd)
schema_path=R/'.runtime/energyplus/26.1.0/Energy+.schema.epJSON'
schema=json.loads(schema_path.read_bytes());obj=schema['properties'][FAMILY]
assert obj['min_fields']==27.0 and len(obj['legacy_idd']['fields'])==32
assert obj['legacy_idd']['fields'][0]=='name'
schema_ref=save('Native-schema/IdealLoads-object.json',(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode())

# Authenticate the actual failed input and derive its physical delimiters, not default values.
case_path=R/'energyplus_porting_plan/cases/B-NOLIMIT-24H/input.idf'
case=case_path.read_bytes();assert case==git(R,BASE,case_path.relative_to(R).as_posix())
out=D/'canonical-source-purchased-air-input-B-NOLIMIT-24H-Root-25/output'
assert case==(out/'input/original.idf').read_bytes()
without_comments='\n'.join(line.split('!',1)[0] for line in case.decode().splitlines())
objects=[x.strip() for x in without_comments.split(';') if x.strip()]
selected=[]
for ordinal,body in enumerate(objects,1):
    fields=[x.strip() for x in body.split(',')]
    if fields[0].lower()==FAMILY.lower():
        selected.append({'global_IDF_object_ordinal':ordinal,'name':fields[1],'physical_data_fields':len(fields)-1,'semicolon_terminated':True,'Native_padded_max_fields':max(len(fields)-1,27),'physical_fields':fields[1:]})
assert len(selected)==1 and selected[0]['physical_data_fields']==32
converted_path=out/'input/converted.epJSON';converted=json.loads(converted_path.read_bytes())
assert all('idf_max_fields' not in row for row in converted[FAMILY].values())
input_hashes=out/'input/input-hashes.json'
assert 'actual PurchasedAir consumed IDF max-fields metadata' in (out/'diagnostics.json').read_text(encoding='utf-8')
manifest={'status':'HELD Source-only correction; failed25 predecessor retained, no canonical application or test/Cargo execution',
 'observed_HEAD':BASE,'failed25_B_receipt':ref(receipt_path),'failed25_snapshot':ref(snapshot_path),'selected_actual_parent_archive':raw['archive'],
 'coherent25_unchanged_parent':ref(D/'source-purchased-air-held-Audit-25/manifest.json'),
 'files':[file],'existing_Source_files':1,'new_Source_files':0,'literal_applications':2,'Source_only_parses':1,
 'Native_commit':PIN,'Native_authorities':authorities,'installed_schema':ref(schema_path),'whole_IdealLoads_schema_object':schema_ref,
 'exact_schema_metadata':{'min_fields':27,'legacy_field_count':32,'name_field_index':0},
 'actual_physical_B_input':ref(case_path),'actual_failed_staged_IDF':ref(out/'input/original.idf'),'actual_converted_input':ref(converted_path),'actual_input_hashes':ref(input_hashes),'actual_physical_IdealLoads_objects':selected,
 'policy':'Transport actual staged IDF global/name order and physical delimiter count on the same RawModel. Native semicolon increments final field then max(count,schema min_fields27). Native END returns before that increment/padding; same bounded metadata EOF rejection fails before publishing ANY overlay. No count inferred from present values/defaults/11numeric count.',
 'existing_test':'unnamed_report_order_tests::twelve_unnamed_reports_keep_actual_idf_count_order_and_field_counts',
 'test_extension':'Same existing test/table only: short Z;→27, actual32-field shape A;→32 and order Z/A; two EOF forms case-insensitive/trailing-comma must fail with full model equality. Zero new test functions; no test execution claim.',
 'Source25_old23_proposals':'Untouched; Outer independently composes corrected24Source4500/4487 successor.',
 'main_Cargo_Native_or_tests_executed_or_modified':False,'author_Source':ref(Path(__file__))}
p=OUT/'manifest.json';p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

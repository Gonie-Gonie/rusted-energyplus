"""Narrow publication successor: actual IDF-metadata correction + one existing test."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'purchased-air-publication-prepared-Audit-25-02'
OLD=D/'publish-purchased-air-checkpoint-Audit-25.py';NEW=D/'publish-purchased-air-checkpoint-Audit-25-02.py'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];g=ref(p);assert g['sha256']==r['sha256'] and g['bytes']==r.get('bytes',r.get('size_bytes',g['bytes'])),r;return p
def load(r):return json.loads(checked(r).read_bytes())
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists() and not NEW.exists()
 parent_ref=ref(OLD);assert parent_ref['sha256']=='d6cb53bd35216942dcf3f843b14484989839065c77633c234e204f6a04ed7e38'
 prior_template_ref=ref(D/'purchased-air-publication-prepared-Audit-25/publication-template.json')
 assert prior_template_ref['sha256']=='5014acf9360d21b530ea1fb2605d3e9ae5cef259e7c3c41efb980e076c4275ea'
 template=copy.deepcopy(load(prior_template_ref))
 producer_ref=ref(D/'source-purchased-air-held-Outer-25-02/manifest.json');assert producer_ref['sha256']=='f2bc3fd2f9fafb9046cae94af13af58e4e0eaba03202900f1f5b516dac92f813'
 producer=load(producer_ref);original=load(producer['original_producer']);raw=load(producer['raw_correction'])
 old_by={r['canonical_path']:r for r in original['files']};new_by={r['canonical_path']:r for r in producer['files']}
 assert len(old_by)==23 and len(new_by)==24
 for name,row in old_by.items():assert row['proposed']==new_by[name]['proposed']
 raw_peer=load(producer['independent_raw_correction_peer']);assert raw_peer['accepted'] and not raw_peer['findings'] and raw_peer['reviewed_packet']==producer['raw_correction']
 test_ref=ref(D/'canonical-purchased-air-IDF-metadata-test-Root-25/receipt.json');assert test_ref['sha256']=='5dff6e6fc343fe1dcc5e56c4dce4063fc4c3c9a408bb2f8779796f13e2313829'
 test=load(test_ref);assert test['exit_code']==0 and test['launch_error'] is None and test['source_bytes_match_before_and_after']
 old=OLD.read_text(encoding='utf-8');body=old
 replacements=[
  ('Root-only checkpoint25 publisher: exactly two actual CLI receipts, no tests.', 'Root-only checkpoint25 publisher: one existing RawModel test plus two actual CLI receipts.'),
  ('purchased-air-publication-prepared-Audit-25\'', 'purchased-air-publication-prepared-Audit-25-02\''),
  ('purchased-air-publication-readback-Audit-25\'', 'purchased-air-publication-readback-Audit-25-02\''),
  ('Root-source-purchased-air-input-actual-review-25/review.json','Root-source-purchased-air-input-actual-review-25-02/review.json'),
  ('canonical-source-purchased-air-input-B-NOLIMIT-24H-Root-25\'', 'canonical-source-purchased-air-input-B-NOLIMIT-24H-Root-25-02\''),
  ('canonical-source-purchased-air-input-A-24H-Root-25\'', 'canonical-source-purchased-air-input-A-24H-Root-25-02\''),
  ("len(producer['files']) == 23 and producer['existing_Source_files'] == 17 and producer['new_Source_files'] == 6", "len(producer['files']) == 24 and producer['existing_Source_files'] == 18 and producer['new_Source_files'] == 6"),
  ('selected23_final_sources_exact','selected24_final_sources_exact'),
  ("    assert contains(peer,template['producer'])", """    # Two honest independent-review chains; neither peer is relabeled as
    # an independent full review of the composite24-source producer.
    assert ref(peer_path) == template['original23_independent_peer']
    assert contains(peer,producer['original_producer'])
    raw_peer_path = checked(producer['independent_raw_correction_peer'])
    raw_peer = accepted(raw_peer_path,producer['independent_raw_correction_peer']['sha256'])
    assert raw_peer['reviewed_packet'] == producer['raw_correction']"""),
  ("    for row in [template['producer'],ref(peer_path),template['complete_plan']]:", "    for row in [template['producer'],ref(peer_path),producer['independent_raw_correction_peer'],template['complete_plan']]:"),
  ("    for row in [template['producer'],ref(peer_path),producer['independent_raw_correction_peer'],template['complete_plan']]:\n        assert contains(actual,row),row['path']", "    for row in [template['producer'],producer['independent_raw_correction_peer'],template['complete_plan']]:\n        assert contains(actual,row),row['path']"),
  ("    assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0", "    assert actual['actual_test_bodies_executed'] == 1 and actual['new_test_bodies'] == 0\n    assert contains(actual,template['existing_raw_test'])"),
  ("    assert runs[0]['source_snapshot'] == runs[1]['source_snapshot']", """    assert runs[0]['source_snapshot'] == runs[1]['source_snapshot']
    raw_test = load(checked(template['existing_raw_test']))
    assert raw_test['exit_code'] == 0 and raw_test['launch_error'] is None
    assert raw_test['source_bytes_match_before_and_after'] is True
    assert raw_test['source_snapshot'] == runs[0]['source_snapshot']
    assert raw_test['command'] == ['cargo','test','--locked','-p','ep_raw_model','--lib',
        'idf_order::unnamed_report_order_tests::twelve_unnamed_reports_keep_actual_idf_count_order_and_field_counts',
        '--','--exact','--nocapture']
    assert '1 passed; 0 failed; 0 ignored;' in checked(raw_test['stdout']).read_text(encoding='utf8')"""),
  ('23 coherent PurchasedAir input/live-output Sources','24 coherent PurchasedAir input/live-output and raw-IDF metadata Sources'),
  ('No test/fixture execution claim, historical ZIP recursion','One existing RawModel test executed; no new test body, historical ZIP recursion'),
  ("producer=template['producer'],independent_peer=ref(peer_path),complete_compiler_plan=template['complete_plan'],", "producer=template['producer'],independent_review_chain={'original23':ref(peer_path),'raw_metadata1':producer['independent_raw_correction_peer']},complete_compiler_plan=template['complete_plan'],")
 ]
 for before,after in replacements:
  assert before in body,before;body=body.replace(before,after)
 # The shared publication engine and mixed-fresh semantics are untouched.
 assert 'first_B_core_fresh_false' not in body and 'fresh_false' not in body
 ast.parse(body);assert '\ufffd' not in body
 NEW.write_text(body,encoding='utf-8',newline='\n');O.mkdir()
 files={r['path']:r for r in template['finite_archive_inputs']}
 def add(row):
  p=checked(row);r=ref(p);assert p.suffix.lower()!='.zip'
  assert not any(s in r['path'] for s in ['controlled-air-native-capture','source-controlled-zone-numerical-draft','source-CalcMoreNodeInfo-draft'])
  assert r['path'] not in files or files[r['path']]==r;files[r['path']]=r
 for row in [producer_ref,producer['complete_final_compiler_Source_plan'],producer['raw_correction'],producer['independent_raw_correction_peer'],producer['author_Source'],
  raw['whole_IdealLoads_schema_object'],raw['actual_physical_B_input'],raw['actual_failed_staged_IDF'],raw['actual_converted_input'],raw['actual_input_hashes'],raw['author_Source'],
  producer['original_application'],producer['first_actual25_diagnostics'],test_ref,prior_template_ref,parent_ref,ref(Path(__file__))]:add(row)
 for row in raw['Native_authorities']:
  add(row['whole'])
  for extent in row['extents']:add(extent['source'])
 for row in raw['files']:
  for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(row[key])
  for key in ['stdout','stderr']:add(row['Source_only_parse'][key])
 for first in producer['first_actual25'].values():
  add(first['receipt']);run=load(first['receipt'])
  for key in ['stdout','stderr','source_snapshot']:add(run[key])
 for key in ['stdout','stderr','source_snapshot']:add(test[key])
 original_app=load(producer['original_application']);add(original_app['author_Source'])
 raw_apply_ref=ref(D/'Root-purchased-air-IDF-metadata-application-25/receipt.json');assert raw_apply_ref['sha256']=='3e1d7a6a74e2e4b94a57fe617fb3cfc00f58e1b1b08a454ab85824328b2b829e'
 raw_apply=load(raw_apply_ref);assert raw_apply['accepted'] and not raw_apply['findings'];add(raw_apply_ref);add(raw_apply['author_Source'])
 composite_ref=ref(D/'Root-purchased-air-input-final-application-25-02/receipt.json');assert composite_ref['sha256']=='aabaa7e594a137eee0ccff7e289750cc90444bb5587439764ad797a2b65be952'
 composite=load(composite_ref);assert composite['accepted'] and not composite['findings'];add(composite_ref);add(composite['author_Source'])
 template.update(schema='src06-held-canonical25-IDF-metadata-publication-template.v2',status='HELD_FOR_ROOT_ACTUAL25_02_AND_FULL_READ',
  producer=producer_ref,complete_plan=producer['complete_final_compiler_Source_plan'],publisher_Source=ref(NEW),publisher_parent_Source=parent_ref,
  superseded_unexecuted_template=prior_template_ref,original23_independent_peer=producer['accepted23_join_peer'],
  independent_raw_correction_peer=producer['independent_raw_correction_peer'],existing_raw_test=test_ref,
  expected_actual_review_path='.runtime/porting/SRC-06/Root-source-purchased-air-input-actual-review-25-02/review.json')
 pending=template['pending_Root_custody']
 for key in ['actual_checker_Source','launcher_Source','B_CLI','A24_CLI']:pending[key]=pending[key].replace('Root-25','Root-25-02')
 pending['application']=composite_ref['path'];pending['application_Source']=composite['author_Source']['path']
 pending['direct_original_application_and_script']=producer['original_application'];pending['direct_raw_application_and_script']=raw_apply_ref
 pending['independent_final_join_peer']='Original23 peer6f27 chain plus independent Raw1 correction peer758; no fake full24 peer.'
 summary=template['summary_template'];summary.update(changed_Rust_sources=24,existing_Rust_sources=18,new_Rust_sources=6,new_test_functions=0,
  actual_test_bodies_executed=1,extended_existing_test_functions=1,
  focused_validation_policy='One existing RawModel metadata test extended and passed; then corrected actual production B02/A24-02. No new test body, suite, alltargets or forced core rebuild. Actual per-core freshness is recorded, not inferred.',
  raw_IDF_metadata_correction='Preserve original physical field-count/order metadata through actual IDF conversion; Native minimum-fields27/semicolon and honest unsupported EOF policy. No case-specific NumNums or inferred nonblank counts.',
  scope=summary['scope']+' The sole additional RawModel Source restores actual original-IDF field metadata; prior23 Source wholes unchanged.')
 template['doc_appends']['STATE_CONTRACTS.md']+=' 원본 IDF의 물리 필드 수도 변환 뒤에 보존한다.'
 template['finite_archive_inputs']=[r for _,r in sorted(files.items())]
 template['finite_archive_input_count']=len(files);template['finite_archive_input_bytes']=sum(r['bytes'] for r in files.values())
 template_ref=save(O/'publication-template.json',template)
 fn=next(x for x in ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8')).body if isinstance(x,ast.FunctionDef) and x.name=='apply')
 ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal successor>','exec'),ns)
 diffs={}
 for name,a,b in [('forward',old.encode('utf-8'),body.encode('utf-8')),('inverse',body.encode('utf-8'),old.encode('utf-8'))]:
  delta=''.join(difflib.unified_diff(a.decode('utf-8').splitlines(keepends=True),b.decode('utf-8').splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode('utf-8')
  assert ns['apply'](a,delta)==b
  path=O/(name+'.diff');path.write_bytes(delta);diffs[name]=ref(path)
 bridge=save(O/'publisher-parent-bridge.json',dict(parent=parent_ref,successor=ref(NEW),literal_applications=2,changes=diffs,
  scope='Only24-source/18old metadata, suffix02 actual roots, truthful two-peer chain, existingRawtest1 proof/summary and original/raw/composite writer provenance. Archive/docs/oneSRC06-key engine and mixed-fresh acceptance unchanged.',
  publisher_executed=False,canonical_mutations=False,actual_B_A02_pending=True))
 print(json.dumps(dict(template=template_ref,publisher=ref(NEW),parent_bridge=bridge)))
if __name__=='__main__':main()

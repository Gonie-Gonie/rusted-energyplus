from pathlib import Path
import ast,copy,hashlib,json,re,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-source-purchased-air-input-actual-review-25-02';assert not O.exists()
parent=D/'check-source-compact-actual-Root-13.py';source=parent.read_bytes();assert hashlib.sha256(source).hexdigest()=='e74ca3d9d2a85102f0dca30ed978ed25d7f8bee8e1fd72459b7b7ba131c2dea4'
tree=ast.parse(source);names={'ref','checked','auth','same_path','core'};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'<authenticated13-helpers>','exec'))
ap,app=auth('Root-purchased-air-input-final-application-25-02/receipt.json',sys.argv[2]);assert app['accepted'] and not app['findings']
producer=json.loads(checked(app['producer']));peer=json.loads(checked(app['independent_peer']));assert peer['accepted'] and not peer['findings']
plan=json.loads(checked(app['complete_compiler_plan']));rows={v['path']:v for v in plan['entries']};assert len(rows)==4500 and sum(n.endswith('.rs') for n in rows)==4487
commands={}
for label,name,code in [('B','canonical-source-purchased-air-input-B-NOLIMIT-24H-command-Root-25-02/receipt.json',6),('A24','canonical-source-purchased-air-input-A-24H-command-Root-25-02/receipt.json',0)]:
 p=D/name;cr=ref(p);c=json.loads(checked(cr));assert c['exit_code']==code and c['launch_error'] is None and c['source_bytes_match_before_and_after'];assert c['repository_before']['head']==c['repository_after']['head']==app['base_HEAD'];checked(c['stdout']);checked(c['stderr']);commands[label]=(cr,c)
snap=commands['B'][1]['source_snapshot'];assert all(c['source_snapshot']==snap for _,c in commands.values());actual={v['historical_path']:v for v in json.loads(checked(snap))['files']};assert set(actual)==set(rows)
raw_test=json.loads(checked(app['raw_metadata_focused_test']));assert raw_test['exit_code']==0 and raw_test['source_bytes_match_before_and_after'] and raw_test['source_snapshot']==snap
for n,v in actual.items():
 b=checked(v['archive']);assert len(b)==v['size_bytes']==rows[n]['final_bytes'] and v['archive']['sha256']==rows[n]['final_sha256']
assert len(app['selected'])==24
for n,f in app['selected'].items():assert(R/n).read_bytes()==checked(f['proposed'])==checked(actual[n]['archive'])
def actual_core(c):
 found={};fresh={}
 for line in checked(c['stdout']).splitlines():
  try:v=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if not isinstance(v,dict) or v.get('reason')!='compiler-artifact' or v['target']['name'] not in ['ep_runtime','ep_run','eplus-rs']:continue
  name=v['target']['name'];assert name not in found;crate='ep_cli' if name=='eplus-rs' else name;same_path(v['manifest_path'],R/f'crates/{crate}/Cargo.toml');same_path(v['target']['src_path'],R/f'crates/{crate}/src/{"main" if name=="eplus-rs" else "lib"}.rs');q=copy.deepcopy(v);fresh[name]=q.pop('fresh');found[name]=q
 assert len(found)==3
 return found,fresh
B_core,B_fresh=actual_core(commands['B'][1]);A_core,A_fresh=actual_core(commands['A24'][1]);assert B_core==A_core and all(A_fresh.values())
# RawModel-only correction legitimately reuses the previously compiled runtime.
# Record actual mixed Cargo freshness; never force a rebuild for an all-false label.
original_ref,original_B=auth('canonical-source-purchased-air-input-B-NOLIMIT-24H-command-Root-25/receipt.json','e96ae640371df4c12d9f537cfdad2a79696031826e12d82dc76be9a1baf5e668');assert original_B['exit_code']==6 and original_B['source_bytes_match_before_and_after'];original_core=core(original_B,False);assert original_core['ep_runtime']==B_core['ep_runtime']
A=D/'canonical-source-purchased-air-input-A-24H-Root-25-02/output';B=D/'canonical-source-purchased-air-input-B-NOLIMIT-24H-Root-25-02/output';old=D/'canonical-source-zone-equipment-orchestration-A-24H-Root-24/output'
bs=json.loads((B/'run-summary.json').read_bytes());bd=json.loads((B/'diagnostics.json').read_bytes());assert bs['exit_code']==6 and bs['rust_runtime'] is None
frontier=sys.argv[1];assert frontier=='GetHeatBalanceInput: actual PurchasedAirManager InitPurchasedAir201';errors=[v for v in bd['diagnostics'] if v['severity']=='error'];assert len(errors)==1 and errors[0]['message']==frontier and(B/'results').is_dir() and not any((B/'results').iterdir())
bnd=B/'eplusrs.bnd';bnd_bytes=bnd.read_bytes();node_observation=dict(BND=ref(bnd),BND_bytes=len(bnd_bytes),BND_node_block_present=b'! #Nodes' in bnd_bytes,Native_paired_Node_state_or_IO_claim=False)
ar,previous24=auth('Root-source-zone-equipment-orchestration-actual-review-24/review.json','f79231cea404f6c733cc5039340e697af04551319ebad97c4bc5d92b836b971e');assert previous24['accepted'] and previous24['original_tolerance_RMSE_5352_proof_transferred']
pr,prior=auth('Peer-canonical-B-ingress-IO-A24-transfer-03/review.json','6bfe7736ea81fc1123ebc4ee11c64e9de64d123f3e3a92e49636f13cd9dc4dca');assert prior['accepted'];assert ref(D/'check-canonical-B-ingress-IO-A24-transfer-Peer-03.py')['sha256']=='0742d4694653c9f80e93e1ebe89ed80bf14696b148e39f8477f0c67c1cb50c74'
text=source.decode();start=text.index('whole=[]\n');end=text.index("O.mkdir();p=O/'table-clock-differences.json'");block=text[start:end];assert block.count('accepted12')==4;exec(compile(block.replace('accepted12','accepted24'),'<unchanged13-A24-comparison>','exec'))
O.mkdir();p=O/'table-clock-differences.json';p.write_text(json.dumps(table_changes,indent=2)+'\n',encoding='utf8',newline='\n');ledger=ref(p)
artifacts=[ref(A/'results/source-reported-results.json'),ref(A/'run-summary.json'),ref(A/'diagnostics.json'),ref(B/'run-summary.json'),ref(B/'diagnostics.json'),ref(bnd)]+[v['current'] for v in whole+csv+tables]+[ledger]
result=dict(schema='src06-purchased-air-input-actual-B-and-A24-transfer.v1',accepted=True,findings=[],application=ap,producer=app['producer'],independent_peer=app['independent_peer'],complete_compiler_plan=app['complete_compiler_plan'],actual_B=commands['B'][0],actual_A24=commands['A24'][0],same4500_archived_inputs_exact_final_plan=True,selected24_final_sources_exact=True,actual_B_core_freshness=B_fresh,actual_A24_core_freshness=A_fresh,A24_same_core_reused_fresh_true=True,actual_test_bodies_executed=1,new_test_bodies=0,extended_existing_test_bodies=1,raw_metadata_focused_test=app['raw_metadata_focused_test'],original23Source_compilation=original_ref,raw_metadata_correction=app['raw_metadata_correction'],validation_policy='Actual productionCLI B then A24. No unrelated equipment unit-test/profile or redundant all-targets build rerun. Reached integration and A regression are checked; positive internal Native unit equivalence remains separate.',B_frontier=frontier,B_runtime_or_fallback_results=False,B_Node_lifecycle_observation=node_observation,accepted24_full5352_proof=ar,whole_physical_streams_equal24=whole,whole_CSV_equal24=csv,whole_JSON_equal24_after_exactly_two_owned_path_field_bridges=True,full_runtime_equal24_after_two_owned_path_bridges=True,transferred_reported_series=58,transferred_JSON_CSV_scalar_roundtrips=5352,full_tables=tables,table_lines=line_count,table_clock_metadata_changes=len(table_changes),table_clock_ledger=ledger,unchanged_original_tolerance_policy=ref(policy),original_tolerance_RMSE_5352_proof_transferred=True,publication_artifacts=artifacts,limits='Actual retained PurchasedAir entry/GetInput/67 live output registrations reached before real Init callee; 24Source whole correspondence and final composition independently reviewed. Unchanged1168-entry predictor cohort passed at parent checkpoint. Init/Calc/Update/Report and new72h/annual/fullB/card completion remain unclaimed.',main_mutations=0,policy_changes=0,gate_changes=0,comparison_helper_Source=ref(parent),comparison_block_only_metadata_key_spelling_changed=True,launcher_Source=ref(D/'launch-purchased-air-input-Root-25-02.py'),author_Source=ref(Path(__file__).resolve()))
p=O/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

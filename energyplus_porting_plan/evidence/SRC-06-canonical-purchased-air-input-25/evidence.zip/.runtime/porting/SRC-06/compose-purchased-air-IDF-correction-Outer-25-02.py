"""Seal literal Source25+one reviewed RawModel correction; no canonical mutation."""
from pathlib import Path
import argparse, hashlib, json, subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'source-purchased-air-held-Outer-25-02'


def sha(b): return hashlib.sha256(b).hexdigest()


def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=sha(b), bytes=len(b))


def checked(r):
    b = (R / r['path']).read_bytes()
    assert sha(b) == r['sha256'] and len(b) == r.get('bytes', len(b)), r['path']
    return b


def load(r): return json.loads(checked(r))


def save(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_text(json.dumps(obj, ensure_ascii=True, indent=2)+'\n', encoding='utf-8', newline='\n')
    return ref(p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--patch', required=True)
    ap.add_argument('--peer', required=True)
    args = ap.parse_args()
    assert not O.exists()
    old_ref = ref(D / 'source-purchased-air-held-Audit-25/manifest.json')
    assert old_ref['sha256'] == 'f6a1ed0cca7edde252943e0c6cec601ae10078ba7ce5922d97fe568312308b04'
    old = load(old_ref)
    old_plan = load(old['complete_final_compiler_Source_plan'])
    patch_ref = ref(R / args.patch)
    patch = load(patch_ref)
    peer_ref = ref(R / args.peer)
    peer = load(peer_ref)
    assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet'] == patch_ref
    assert len(patch['files']) == 1
    raw = patch['files'][0]
    name = raw['canonical_path']
    assert name == 'crates/ep_raw_model/src/idf_order.rs' and not raw['before_absent']
    assert name not in {r['canonical_path'] for r in old['files']}
    application_ref = ref(D / 'Root-purchased-air-input-application-25/receipt.json')
    assert application_ref['sha256'] == 'd700ccaa38d7c8d2aeed863e29f798005c8517743b8289b0a921d5d83bb6cc94'
    application = load(application_ref)
    assert application['accepted'] and not application['findings']
    assert application['producer'] == old_ref and application['complete_compiler_plan'] == old['complete_final_compiler_Source_plan']
    actuals = {}
    for case, expected_sha, expected_exit in [
        ('B-NOLIMIT-24H', 'e96ae640371df4c12d9f537cfdad2a79696031826e12d82dc76be9a1baf5e668', 6),
        ('A-24H', 'aebd455705ff19a5252fab48f00a695972ad24d84a35d1fb10814fa4799e1f91', 0)]:
        rr = ref(D / f'canonical-source-purchased-air-input-{case}-command-Root-25/receipt.json')
        assert rr['sha256'] == expected_sha
        run = load(rr)
        assert run['exit_code'] == expected_exit and run['launch_error'] is None and run['source_bytes_match_before_and_after']
        actuals[case] = dict(receipt=rr, snapshot=run['source_snapshot'], exit_code=expected_exit)
    assert actuals['B-NOLIMIT-24H']['snapshot'] == actuals['A-24H']['snapshot']
    snapshot_ref = actuals['B-NOLIMIT-24H']['snapshot']
    snapshot = load(snapshot_ref)
    rows = {x['historical_path']: x for x in snapshot['files']}
    entries = {x['path']: x for x in old_plan['entries']}
    assert len(rows) == len(entries) == 4500 and set(rows) == set(entries)
    assert sum(p.endswith('.rs') for p in rows) == 4487
    assert checked(raw['before']) == checked(rows[name]['archive'])
    assert checked(raw['before']) == subprocess.check_output(['git','show',old['base_HEAD']+':'+name],cwd=R)
    selected = {r['canonical_path']: r for r in old['files']}
    assert len(selected) == 23
    for path, row in rows.items():
        b = checked(row['archive'])
        assert len(b) == row['size_bytes']
        assert sha(b) == entries[path]['final_sha256'] and len(b) == entries[path]['final_bytes']
        if path != name:
            assert b == (R / path).read_bytes(), path
        else:
            assert (R / path).read_bytes() in [checked(raw['before']), checked(raw['proposed'])]
    for path, row in selected.items():
        assert checked(row['proposed']) == checked(rows[path]['archive']) == (R / path).read_bytes()
    diag_ref = ref(D / 'canonical-source-purchased-air-input-B-NOLIMIT-24H-Root-25/output/diagnostics.json')
    diag = load(diag_ref)
    assert [r['message'] for r in diag['diagnostics'] if r['severity']=='error'] == ['GetHeatBalanceInput: actual PurchasedAir consumed IDF max-fields metadata']
    after = checked(raw['proposed'])
    entries[name] = dict(path=name, final_sha256=sha(after), final_bytes=len(after), source=raw['proposed'],
        origin='sole literal RawModel metadata correction after first actual25 B frontier')
    final = [entries[p] for p in sorted(entries)]
    assert len(final) == 4500 and sum(r['path'].endswith('.rs') for r in final) == 4487
    assert [p for p in entries if (entries[p]['final_sha256'],entries[p]['final_bytes']) !=
        (rows[p]['archive']['sha256'],rows[p]['size_bytes'])] == [name]
    plan_ref = save(O / 'complete-final-compiler-Source-plan.json', dict(
        schema='src06-complete-Source25-IDF-correction-compiler-input-plan.v2', base_HEAD=old['base_HEAD'],
        prior_plan=old['complete_final_compiler_Source_plan'], actual_first25_snapshot=snapshot_ref,
        inputs=4500, Rust_sources=4487, entries=final,
        sole_changed_existing_input=name, original23_sources_whole_unchanged=True,
        Root_full_readback_required=True))
    manifest = dict(
        schema='src06-held-coherent-purchased-air-IDF-metadata-correction.v2',
        status='HELD Source25 successor: original23 proposals unchanged plus independently reviewed one RawModel metadata correction; Root test/B/A02 pending',
        base_HEAD=old['base_HEAD'], base_scope='Original clean cohort commit; original23 are already Root-applied WIP. No new clean-worktree claim.',
        original_producer=old_ref, original_application=application_ref,
        first_actual25=actuals, first_actual25_diagnostics=diag_ref, actual_parent_snapshot=snapshot_ref,
        prior_complete_compiler_Source_plan=old['complete_final_compiler_Source_plan'],
        complete_final_compiler_Source_plan=plan_ref, compiler_inputs=4500, Rust_sources=4487,
        raw_correction=patch_ref, independent_raw_correction_peer=peer_ref,
        files=old['files']+[raw], existing_Source_files=18, new_Source_files=6,
        selected_Source_files=24, literal_applications=48,
        Source_only_parses=dict(original23_inherited=old_ref, raw1_fresh=peer_ref),
        original23_whole_unchanged=True, cohort3_whole_unchanged=old['cohort3_whole_unchanged'],
        accepted23_semantic_review=old['independent_whole_Source_review'], accepted15_output_peer=old['independent_full_output_Source_peer'],
        accepted23_join_peer=application['independent_peer'],
        Native_commit=old['Native_commit'], original_Native10_wholes24_extents=old_ref,
        new_Native_parser_schema_authority=patch_ref,
        validation_policy='Root applies only raw correction, runs one existing ep_raw_model libtest (same test body extended; no new testfn), then real B/A24-25-02 on this complete4500 plan. Original tolerance/gates unchanged.',
        actual_successor25_execution_pending=True, new_test_bodies=0, extended_existing_test_bodies=1,
        qualifications=['First actual25 B exit6 is preserved as genuine metadata-integration failure; A24 exit0 is prior-plan evidence only.',
            'No GetPurchasedAir completed/Init runtime reach or full-B/numerical completion claim before actual02 receipts.',
            'No duplicate old Source semantics, whole-crate census or389MB Native observation replay. Existing23 accepted authorities remain unchanged.'],
        Cargo_main_tests_or_Native_mutations=False, author_Source=ref(Path(__file__)))
    print(json.dumps(save(O / 'manifest.json', manifest)))
    print(json.dumps(plan_ref))


if __name__=='__main__': main()

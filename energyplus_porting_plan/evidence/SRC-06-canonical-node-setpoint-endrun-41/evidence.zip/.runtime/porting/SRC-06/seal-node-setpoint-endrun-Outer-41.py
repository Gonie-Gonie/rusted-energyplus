"""Seal two accepted41 Sources on actual committed39; no canonical application."""
from pathlib import Path
import argparse,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';I=D/'source-node-setpoint-endrun-draft-Outer-41';O=D/'source-node-setpoint-endrun-held-Outer-41'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=(R/r['path']).resolve();p.relative_to(R);v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',r.get('size_bytes',v['bytes']));return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def contains(v,r):
 if isinstance(v,dict):return(v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(a):
 assert not O.exists();dr=ref(I/'draft.json');assert dr['sha256']=='cdd6501bc0578665ba96e3b09a352bedc171245b4fefe28858563847e877d989';m=json.loads(checked(dr).read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='b2fe1a5b4fb3210e7ae75e6e6602554f7c201321'
 pr=dict(path=a.peer,sha256=a.peer_sha);peer=json.loads(checked(pr).read_bytes());pr=ref(checked(pr));assert peer['accepted'] and not peer.get('findings',[]) and contains(peer,dr)
 actual=json.loads(checked(m['accepted39_actual_review']).read_bytes());assert actual['accepted'] and not actual['findings'] and actual['complete_compiler_plan']==m['prior_complete_compiler_Source_plan']
 parent=json.loads(checked(m['prior_complete_compiler_Source_plan']).read_bytes());index={r['path']:r for r in parent['entries']};assert len(index)==4508 and parent['Rust_sources']==4495
 command=json.loads(checked(actual['actual_B']).read_bytes());snapshot=command['source_snapshot'];observed={r['historical_path']:r for r in json.loads(checked(snapshot).read_bytes())['files']};assert set(observed)==set(index)
 for path,row in index.items():
  b=checked(row['source']).read_bytes();ab=checked(observed[path]['archive']).read_bytes();assert b==ab==(R/path).read_bytes(),path;assert(len(b),hashlib.sha256(b).hexdigest())==(row['final_bytes'],row['final_sha256']);assert observed[path]['size_bytes']==len(b)
 files=[];selected={}
 for i,row in enumerate(m['files'],1):
  path=row['canonical_path'];before=checked(row['before']).read_bytes();after=checked(row['proposed']).read_bytes();assert not row['before_absent'];assert before==checked(index[path]['source']).read_bytes()==subprocess.check_output(['git','show',head+':'+path],cwd=R)
  f=dict(canonical_path=path,before_absent=False)
  for key,sub in [('before','before'),('proposed','proposed'),('literal_inverse','literal-inverse')]:f[key]=save(O/sub/path,checked(row[key]).read_bytes())
  for key,tag in [('forward_diff','forward'),('inverse_diff','inverse')]:f[key]=save(O/'diffs'/f'{i:02}.{tag}.diff',checked(row[key]).read_bytes())
  q=row['Source_only_parse'];assert q['exit_code']==0;checked(q['stdout']);checked(q['stderr']);f['Source_only_parse']=q;f['whole_accepted_draft_proposal_exact']=True;files.append(f);selected[path]=f['proposed']
 entries=copy.deepcopy(parent['entries'])
 for row in entries:
  if row['path'] in selected:r=selected[row['path']];row.update(source=r,final_sha256=r['sha256'],final_bytes=r['bytes'],origin='Source41 same-owner complete normal deferred setpoint endrun check')
 dp={r['path']:r for r in json.loads(checked(m['complete_proposed_compiler_Source_plan']).read_bytes())['entries']}
 for row in entries:
  assert(row['final_sha256'],row['final_bytes'])==(dp[row['path']]['final_sha256'],dp[row['path']]['final_bytes'])
  if row['path'] not in selected:assert row==index[row['path']]
 fp=write(O/'complete-final-compiler-Source-plan.json',dict(schema='src06-complete-Source41-final-compiler-input-plan.v1',base_HEAD=head,actual39_parent_review=m['accepted39_actual_review'],actual39_parent_snapshot=snapshot,prior_plan=m['prior_complete_compiler_Source_plan'],inputs=4508,Rust_sources=4495,selected_existing=2,selected_new=0,entries=entries))
 pat=re.compile(rb'check_source_setpoint_nodes_at_end\(|check_source_node_setpoint_managed_by_handle\(|node_setpoint_checks|needs_setpoint_checking|check_setpoint\b|number_ems_actuators_available');rows=[]
 for row in entries:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  for line,text in enumerate(checked(row['source']).read_bytes().splitlines(),1):
   if pat.search(text):rows.append(dict(path=row['path'],line=line,text=text.decode('utf8')))
 census=write(O/'whole-crates-final-API-census.json',dict(complete_plan=fp,whole_crates=True,Rust_sources=4495,fixture_bodies_excluded=True,rows=rows))
 for row in m['Native_authorities']:
  checked(row['whole'])
  for e in row['extents']:checked(e['source'])
 for c in m['concrete_same_owner_contexts']:assert checked(c['whole']).read_bytes()==(R/c['canonical_path']).read_bytes()
 result=dict(schema='src06-held-node-setpoint-endrun41.v1',status='HELD Root independent full Source peer accepted; actual Source41 engine pending',base_HEAD=head,accepted39_actual_review=m['accepted39_actual_review'],actual_parent_snapshot=snapshot,parent_producer=m['parent_producer'],prior_complete_compiler_Source_plan=m['prior_complete_compiler_Source_plan'],complete_final_compiler_Source_plan=fp,original_draft=dr,independent_full_semantic_peer=pr,read_only_connected_map=m['read_only_connected_map'],compiler_inputs=4508,Rust_sources=4495,files=files,existing_Source_files=2,new_Source_files=0,selected_Source_files=2,literal_applications=4,Source_only_parses=2,full4508_parent_readback=dict(kind='INLINE_VERIFIED_PARENT_READBACK_NOT_A_FILE_REFERENCE',inputs=4508,Rust_sources=4495,all_actual_snapshot_archive_plan_live_wholes_exact=True,selected2_committed39_Git_wholes_exact=True,all4506_unselected_parent_entries_whole_preserved=True,all_parent_cohort_test_main_Cargo_feature_and_equipment_suffix_inputs_whole_preserved=True),whole4495_Rust_API_census=census,Native_commit=m['Native_commit'],Native_authorities=m['Native_authorities'],concrete_same_owner_contexts=m['concrete_same_owner_contexts'],integration_contract=dict(scope=m['scope'],state='Same existing NodeSetpointCheck Option/rows and NodeID on NodeOwner; same SelectedRuntimeLanguage available count. No new arrays, records, shadows, flags, type cache or AnyEMS proxy.',order='Full ascending actual node count, actual needs flag, clear only true flag before9control loop, non-short-circuit |= for every requested bit, actual NodeID/local/control table/count before first positive available1501 or warning1510 child; final1608 fatal only after all represented traversals return.',positive_boundaries='Available-actuator record data is not represented; true positive first handleCount1501 remains typed. Zero actual count still reaches missing-handle warning1510, never a fabricated false result. Final ShowFatal1608 remains first diagnostic boundary. No generic EMS/API/diagnostic completion claimed.',caller='Only actual endrun590 switches Equipment to mutable and borrows same startup.runtime_language. Preceding unused-actuator589 and subsequent OutputProcessor592/TAB calls unchanged.',validation='No new test or numerical-equivalence claim; Root sole actual B/A CLI compile/execution. Full prior scientific cohort preserved and not rerun by author.'),new_test_bodies=0,actual_test_bodies_executed=0,author_Source=ref(Path(__file__)),canonical_Cargo_Native_engine_tests_or_publication_mutations=False)
 out=O/'manifest.json';write(out,result);print(json.dumps(ref(out)));print(json.dumps(fp))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--peer',required=True);p.add_argument('--peer-sha',required=True);main(p.parse_args())

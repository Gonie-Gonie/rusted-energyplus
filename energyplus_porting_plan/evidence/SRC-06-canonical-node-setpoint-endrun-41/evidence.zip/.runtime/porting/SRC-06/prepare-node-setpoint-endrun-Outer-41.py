"""Private prospective41 map and normal-path Source draft; no canonical mutation."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'source-node-setpoint-endrun-draft-Outer-41';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();p.relative_to(R);r=ref(p);assert r['sha256']==v['sha256'] and r['bytes']==v.get('bytes',v.get('size_bytes',r['bytes']));return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
assert not O.exists();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='b2fe1a5b4fb3210e7ae75e6e6602554f7c201321'
mp=D/'source-controlled-system-report-held-Audit-39/manifest.json';m=json.loads(mp.read_bytes());ar=D/'Root-source-controlled-system-report-actual-review-39/review.json';actual=json.loads(ar.read_bytes());assert actual['accepted'] and not actual['findings'] and actual['B_frontier']=='GetHeatBalanceInput: actual checkSetpointNodesAtEnd first NodeSetpointCheck1588'
parent=json.loads(checked(m['complete_final_compiler_Source_plan']).read_bytes());assert(parent['inputs'],parent['Rust_sources'])==(4508,4495)
authorities=[]
for path,extents in [('src/EnergyPlus/EMSManager.cc',[(114,122),(1481,1559),(1574,1612)]),('src/EnergyPlus/DataLoopNode.hh',[(524,544)]),('src/EnergyPlus/NodeInputManager.cc',[(651,738)]),('src/EnergyPlus/DataHVACGlobals.hh',[(69,82)]),('src/EnergyPlus/DataRuntimeLanguage.hh',[(296,317),(745,800)]),('src/EnergyPlus/SimulationManager.cc',[(579,596)])]:
 p=N/path;b=p.read_bytes();assert b==subprocess.check_output(['git','show',PIN+':'+path],cwd=N);rows=[]
 for first,last in extents:rows.append(dict(first=first,last=last,source=save(O/'Native'/f'{Path(path).name}.{first}-{last}.txt',b''.join(b.splitlines(keepends=True)[first-1:last]))))
 authorities.append(dict(Native_path=path,whole=ref(p),pinned_Git=PIN,extents=rows))
contexts=[]
for path in ['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_controlled_equipment.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_endrun.rs','crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs','crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs','crates/ep_runtime/src/heat_balance/ordinary_ems_plugin.rs','crates/ep_runtime/src/heat_balance/ordinary_ems_plugin/endrun.rs','crates/ep_runtime/src/heat_balance/error_backend.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs']:
 b=(R/path).read_bytes();assert b==subprocess.check_output(['git','show',head+':'+path],cwd=R);contexts.append(dict(canonical_path=path,whole=save(O/'contexts'/path,b),committed39_Git_exact=True))
rust_pat=re.compile(rb'node_setpoint_checks|needs_setpoint_checking|check_setpoint\b|check_source_setpoint_nodes_at_end\(');census=[]
for p in (R/'crates').rglob('*.rs'):
 if 'fixtures' in p.parts:continue
 for line,t in enumerate(p.read_bytes().splitlines(),1):
  if rust_pat.search(t):census.append(dict(path=p.relative_to(R).as_posix(),line=line,text=t.decode('utf8')))
assert not any('needs_setpoint_checking = true' in r['text'] for r in census)
cr=write(O/'current-whole-crates-node-setpoint-census.json',dict(whole_crates=True,fixture_bodies_excluded=True,rows=census,scope='Observed actual39 implementation writers/definitions/caller; no fake zero derived from census. Future routine must read each real sidecar row.'))
plan=write(O/'read-only-connected-plan.json',dict(schema='src06-prospective-node-setpoint-endrun41-map.v1',author_Source=ref(Path(__file__)),base_HEAD=head,accepted39_actual_review=ref(ar),logical_parent39_producer=ref(mp),prior_complete_compiler_Source_plan=m['complete_final_compiler_Source_plan'],Native_authorities=authorities,concrete_same_owner_contexts=contexts,current_Rust_census=cr,authority_correction='Function is EMSManager1574-1612, not NodeInputManager. NodeInputManager651-738 is the real sidecar allocation/growth producer.',cold_owner='Same NodeOwner.node_setpoint_checks Option remains None before any genuine node allocation. Native DataLoopNode525-529 explicitly initializes needs=false and all nine bits=false; existing Source deriveDefault exactly represents those defined constructor values, not unknown primitive memory or a new zero snapshot. Growth preserves prior rows and appends the same real constructor.',required_node='No separate RequiredNode vector exists in the inspected Native routine. A node requires deferred checking only when its actual retained needsSetpointChecking bool is true; then each actual nine-bit control request selects the real helper. Do not infer it from physical Node.TempSetPoint, AnyEMS, node connection role, global actuator count, or an empty shadow list.',order=['Native1585 local FatalErrorFlag=false, no retained once/readiness flag.','For every actual1..NumOfNodes, read existing NodeSetpointCheck1588 before bool predicate. Count0 keeps absent sidecar unallocated; missing positive row is typed at actual first access.','True needs flag is cleared1592 before any control helper; false rows do not read bits, NodeID, runtime counts or actuator rows.','Control slots0..8 exact positional order. Native |= is non-short-circuit: invoke helper for every requested bit even after previous miss. Retain checkSetPoint bits unchanged.','Helper1493 localfalse then actual NodeID string1495, component type1496, positional controlTypeNames1497, actual byHandle=true loop count1500. Positive unrepresented available row typed first handleCount1501, no fabricated EMS records/count. Zero actual available count reaches real missing-handle warning1510 before returningfalse.','If a helper were fully returned, OR its inverse into same needs flag1596, inspect same final flag1601, accumulate localFatal1602 across all nodes. Fatal1608 only after entire traversal; first diagnostic child remains honest if not implemented.','Actual SimulationManager589 unused-actuator check precedes590; OutputProcessor592 and TAB594/596 remain after this return.'],control_type_table='Preserve exact Native114-122 positional string table independently of CtrlVarType names: underlying enum Max/Min order and Minimum/Maximum text differ; no repair/remapping.',minimal_context='Only source_endrun.rs needs mutable same Equipment NodeOwner plus borrowed actual SelectedRuntimeLanguage count. Narrow endrun_prefix.rs caller uses source_zone_equipment.as_mut and selected_simulation_startup.runtime_language; no new owner, array, flags or generic simulation context.',diagnostic_scope='No positive EMS/API generic completion. Current RuntimeLanguage has real available count but no available-actuator record representation; first actual positive handleCount1501 remains typed. Missing-handle ShowWarning1510 and final ShowFatal1608 are genuine boundaries unless existing backend is explicitly threaded; never silently returnfalse while omitting warning.',validation='Constructor/input/control glue only: no new tests or numerical unit-equivalence claim. Root owns eventual coherent Source41 peer/app/CLI B+A24 after final parent selection. Existing scientific cohort/Native39 capture is separate.'))
path='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_endrun.rs';before=(R/path).read_bytes()
new=b'''//! Actual EMSManager1574-1612 deferred setpoint check on the sole retained nodes.
use super::OrdinaryEquipment;
use crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError as Error;
use crate::heat_balance::selected_simulation_startup::SelectedRuntimeLanguage;

// Literal EMSManager114-122 positional table. Do not derive names from the
// CtrlVarType enum's Max/Min spellings: Native uses this exact array order.
const CONTROL_TYPE_NAMES: [&str; 9] = [
    "Temperature Setpoint",
    "Temperature Minimum Setpoint",
    "Temperature Maximum Setpoint",
    "Humidity Ratio Setpoint",
    "Humidity Ratio Minimum Setpoint",
    "Humidity Ratio Maximum Setpoint",
    "Mass Flow Rate Setpoint",
    "Mass Flow Rate Minimum Available Setpoint",
    "Mass Flow Rate Maximum Available Setpoint",
];

fn check_source_node_setpoint_managed_by_handle(
    node_ids: &Option<Vec<String>>,
    node_number: usize,
    control_type: usize,
    runtime_language: &SelectedRuntimeLanguage,
) -> Result<bool, Error> {
    let _found_control = false;
    let _node_name = node_ids.as_ref().and_then(|rows| rows.get(node_number))
        .ok_or(Error::Unavailable("actual CheckIfNodeSetPointManaged1495 NodeID"))?.clone();
    let _component_type_name = "System Node Setpoint";
    let _control_type_name = *CONTROL_TYPE_NAMES.get(control_type)
        .ok_or(Error::Unavailable("actual CheckIfNodeSetPointManaged1497 controlTypeNames ordinal"))?;
    if runtime_language.number_ems_actuators_available > 0 {
        return Err(Error::Unavailable(
            "actual CheckIfNodeSetPointManaged1501 EMSActuatorAvailable.handleCount first record",
        ));
    }
    // Native byHandle=true emits this warning even when the real available
    // count is zero. Do not return its local false while dropping that effect.
    Err(Error::Unavailable("actual CheckIfNodeSetPointManaged1510 missing-handle ShowWarningError"))
}

impl OrdinaryEquipment {
    pub(crate) fn check_source_setpoint_nodes_at_end(
        &mut self,
        runtime_language: &SelectedRuntimeLanguage,
    ) -> Result<(), Error> {
        let mut fatal_error_flag = false;
        for node_number in 1..=self.nodes.number_of_nodes {
            let check = self.nodes.node_setpoint_checks.as_mut()
                .and_then(|rows| rows.get_mut(node_number - 1))
                .ok_or(Error::Unavailable("actual checkSetpointNodesAtEnd1588 NodeSetpointCheck"))?;
            if check.needs_setpoint_checking {
                check.needs_setpoint_checking = false;
                for control_type in 0..CONTROL_TYPE_NAMES.len() {
                    if check.check_setpoint[control_type] {
                        // Compound OR evaluates the helper for every selected
                        // control, including after a preceding failed match.
                        check.needs_setpoint_checking |= !check_source_node_setpoint_managed_by_handle(
                            &self.nodes.node_ids, node_number, control_type, runtime_language,
                        )?;
                    }
                }
                if check.needs_setpoint_checking { fatal_error_flag = true; }
            }
        }
        if fatal_error_flag {
            return Err(Error::Unavailable("actual checkSetpointNodesAtEnd1608 ShowFatalError"));
        }
        Ok(())
    }
}
'''
caller='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';cb=(R/caller).read_bytes()
old=b'''        required(
            reports.source_zone_equipment.as_ref(),
            "actual same Node owner before setpoint nodes590",
        )?
        .check_source_setpoint_nodes_at_end()
        .map_err(hb_input_error)?;'''
replacement=b'''        required(
            reports.source_zone_equipment.as_mut(),
            "actual same Node owner before setpoint nodes590",
        )?
        .check_source_setpoint_nodes_at_end(
            &required(
                reports.selected_simulation_startup.as_ref(),
                "actual same RuntimeLanguage before setpoint node helper590",
            )?
            .runtime_language,
        )
        .map_err(hb_input_error)?;'''
assert cb.count(old)==1;caller_new=cb.replace(old,replacement);files=[]
tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_bytes());ns={'re':re};exec(compile(ast.Module(body=[v for v in tree.body if isinstance(v,ast.FunctionDef) and v.name=='apply'],type_ignores=[]),'<literal-apply>','exec'),ns)
for i,(p,a,b) in enumerate([(path,before,new),(caller,cb,caller_new)],1):
 row=dict(canonical_path=p,before_absent=False,before=save(O/'before'/p,a),proposed=save(O/'proposed'/p,b),literal_inverse=save(O/'literal-inverse'/p,a))
 for key,x,y in [('forward_diff',a,b),('inverse_diff',b,a)]:
  row[key]=save(O/'diffs'/f'{i:02}.{key}.diff',''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile='before/'+p,tofile='after/'+p)).encode())
 assert ns['apply'](a,checked(row['forward_diff']).read_bytes())==b and ns['apply'](b,checked(row['inverse_diff']).read_bytes())==a
 result=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert result.returncode==0
 row['Source_only_parse']=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',result.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',result.stderr));files.append(row)
final=copy.deepcopy(parent)
for row in final['entries']:
 f=next((f for f in files if f['canonical_path']==row['path']),None)
 if f:r=f['proposed'];row.update(source=r,final_sha256=r['sha256'],final_bytes=r['bytes'],origin='Prospective41 same-owner deferred node setpoint endrun closure')
final.update(schema='src06-prospective-Source41-compiler-input-plan.v1',base_HEAD=head,accepted39_actual_review=ref(ar),prior_plan=m['complete_final_compiler_Source_plan']);fp=write(O/'complete-proposed-compiler-Source-plan.json',final)
out=O/'draft.json';write(out,dict(schema='src06-node-setpoint-endrun41-draft.v1',status='FROZEN normal complete loop and actual unrepresented child boundaries; independent peer/final parent seal pending',base_HEAD=head,author_Source=ref(Path(__file__)),accepted39_actual_review=ref(ar),parent_producer=ref(mp),prior_complete_compiler_Source_plan=m['complete_final_compiler_Source_plan'],complete_proposed_compiler_Source_plan=fp,read_only_connected_map=plan,files=files,selected_existing_sources=2,new_sources=0,literal_applications=4,Source_only_parses=2,Native_commit=PIN,Native_authorities=authorities,concrete_same_owner_contexts=contexts,new_test_bodies=0,actual_test_bodies_executed=0,scope='Full actual NumOfNodes/needs-bit traversal, actual fixed9 control iteration/non-short-circuit compoundOR, same physical NodeID/type/helper-count reads and genuine warning/available-record/finalfatal boundaries. No AnyEMS/zero-counter surrogate, no fake EMS record or RequiredNode array.',canonical_Cargo_Native_engine_tests_or_publication_mutations=False));print(json.dumps(ref(out)));print(json.dumps(fp));print(json.dumps(plan))

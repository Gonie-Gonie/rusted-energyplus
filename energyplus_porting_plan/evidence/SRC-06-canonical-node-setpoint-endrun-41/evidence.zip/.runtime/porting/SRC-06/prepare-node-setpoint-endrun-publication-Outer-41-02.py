"""Immutable metadata-only publisher successor; no canonical write/execution."""
from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def main():
 old=D/'publish-node-setpoint-endrun-checkpoint-Outer-41.py';assert ref(old)['sha256']=='846f0e115b268d4a01aa3e675fb065717fdfa9079b977814cfc38b30a7572a8b'
 out=D/'node-setpoint-endrun-publication-prepared-Outer-41-02';assert not out.exists()
 new=D/'publish-node-setpoint-endrun-checkpoint-Outer-41-02.py';assert not new.exists()
 a=old.read_text(encoding='utf8');b=a
 changes=[
  ("BACK=D/'node-setpoint-endrun-publication-readback-Outer-41'","BACK=D/'node-setpoint-endrun-publication-readback-Outer-41-02'"),
  ("out=D/f'canonical-source-node-setpoint-endrun-{case}-Root-41/output';sp=out/'run-summary.json';dp=out/'diagnostics.json'","suffix='41-02' if case=='A-24H' else '41'\n  out=D/f'canonical-source-node-setpoint-endrun-{case}-Root-{suffix}/output';sp=out/'run-summary.json';dp=out/'diagnostics.json'"),
  ('Two existing production Sources and no new Source files and exactly two actual B/A CLI receipts.','Two existing production Sources and no new Source files. Three actual CLI invocations: two accepted B/A24-02 receipts and one separately retained supplemental A24 receipt with the wrong Cargo target directory, excluded from accepted canonical-build reuse.'),
  ('actual_engine_CLI_receipts=2,actual_test_bodies_executed_by41=0','actual_engine_CLI_invocations=3,accepted_engine_CLI_receipts=2,supplemental_wrong_target_A24_CLI_receipts=1,actual_test_bodies_executed_by41=0')]
 for before,after in changes:
  assert b.count(before)==1,before;b=b.replace(before,after)
 ast.parse(b);new.write_bytes(b.encode('utf8'));out.mkdir()
 before=D/'node-setpoint-endrun-publication-prepared-Outer-41/publication-template.json'
 t=json.loads(before.read_bytes());t['publisher_Source']=ref(new)
 t['status']='WAITING_FOR_ROOT_ACTUAL41_02_AND_FULL_READ'
 t['expected_actual_review_path']='.runtime/porting/SRC-06/Root-source-node-setpoint-endrun-actual-review-41-02/review.json'
 prior=D/'canonical-source-node-setpoint-endrun-A-24H-command-Root-41/receipt.json';r=json.loads(prior.read_bytes())
 assert r['exit_code']==0 and r['launch_error'] is None and r['source_bytes_match_before_and_after']
 assert r['launch_environment_selected']['CARGO_TARGET_DIR'] is None
 supplemental=[ref(prior),ref(R/r['stdout']['path']),ref(R/r['stderr']['path']),ref(D/'launch-node-setpoint-endrun-Root-41.py')]
 t['finite_archive_inputs']+=supplemental
 t['finite_archive_inputs']+= [ref(D/'launch-node-setpoint-endrun-A24-Root-41-02.py'),ref(old),ref(before),ref(Path(__file__))]
 t['summary_template'].update(actual_engine_CLI_invocations=3,accepted_engine_CLI_receipts=2,
  supplemental_wrong_target_A24=dict(receipt=ref(prior),qualification='Historical actual A24 exit0/stable, but CARGO_TARGET_DIR was null and it compiled target/. It is excluded from the accepted canonical B-core reuse; accepted A24-02 uses the canonical Cargo target. This supplemental invocation is retained, not silently discarded.'))
 t['doc_appends']['CHECKLIST.md']+=' \ucd5c\ucd08 A24\uc758 \ube4c\ub4dc \uacbd\ub85c \uc624\ub958 \uae30\ub85d\uc740 \ubcf4\uc874\ud558\uace0, \uad50\uc815\ub41c A24-02\ub97c \uc2b9\uc778\ub41c \uacb0\uacfc\ub85c \uc0ac\uc6a9\ud55c\ub2e4.'
 tp=out/'publication-template.json';write(tp,t)
 for label,left,right in [('publisher',a,b),('template',before.read_text(encoding='utf8'),tp.read_text(encoding='utf8'))]:
  (out/(label+'-forward.diff')).write_text(''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='before',tofile='proposed')),encoding='utf8')
  (out/(label+'-inverse.diff')).write_text(''.join(difflib.unified_diff(right.splitlines(True),left.splitlines(True),fromfile='proposed',tofile='before')),encoding='utf8')
 write(out/'prepared.json',dict(status='PREPARED_NOT_EXECUTED_WAITING_ACCEPTED_ACTUAL',publisher=ref(new),template=ref(tp),parent_publisher=ref(old),parent_template=ref(before),supplemental_historical_inputs=supplemental,author_Source=ref(Path(__file__)),canonical_writes=0))
 print(json.dumps(dict(publisher=ref(new),template=ref(tp),prepared=ref(out/'prepared.json'))))
if __name__=='__main__':main()

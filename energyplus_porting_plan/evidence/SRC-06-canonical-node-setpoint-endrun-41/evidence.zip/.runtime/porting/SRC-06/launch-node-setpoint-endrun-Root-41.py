from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={'B': ('canonical-source-controlled-system-report-B-NOLIMIT-24H-command-Root-39/receipt.json', '6aa3ea06e7239d5db70ebf721cd22817252a095cf1312ced1789a4c31466e12e'), 'A24': ('canonical-source-controlled-system-report-A-24H-command-Root-39/receipt.json', 'dd9486493a325fc87a7051eb4efda0bf7e024168744642d63a145d806124d459')}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-node-setpoint-endrun-'+case+'-command-Root-41'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-node-setpoint-endrun-'+case+'-Root-41/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
p=D/'canonical-source-controlled-system-report-A-24H-command-Root-39/receipt.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='dd9486493a325fc87a7051eb4efda0bf7e024168744642d63a145d806124d459'
cmd=json.loads(p.read_bytes())['command']
target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
assert Path(os.environ['CARGO_TARGET_DIR']).resolve()==target and os.environ['CARGO_INCREMENTAL']=='0'
assert cmd[cmd.index('--porting-scope')+1]=='A'
cmd[cmd.index('--output-dir')+1]=(D/'canonical-source-node-setpoint-endrun-A-24H-Root-41-02/output').as_posix()
receipt=D/'canonical-source-node-setpoint-endrun-A-24H-command-Root-41-02'
assert not receipt.exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',receipt.relative_to(R).as_posix(),'--',*cmd],cwd=R))

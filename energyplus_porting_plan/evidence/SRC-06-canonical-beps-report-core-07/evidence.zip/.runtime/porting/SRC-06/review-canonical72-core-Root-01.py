from pathlib import Path
import ast,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06'
OUT=BASE/'Root-canonical72-report-core-review-01';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def inventory():
    p=set((ROOT/'crates').rglob('*.rs'))|set((ROOT/'crates').rglob('Cargo.toml'))
    for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']:
        if (ROOT/n).is_file():p.add(ROOT/n)
    return {x.relative_to(ROOT).as_posix() for x in p}
mp=BASE/'canonical-source72-report-core-prepared-Reviewer-01/manifest.json'
assert ref(mp)['sha256']=='81f90aabf8953289e2145f8613d99c8976306ca26c358db1bcba3382222e318d'
m=json.loads(mp.read_bytes());plan=json.loads(checked(m['complete_compiler_Source_plan']))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==m['base_HEAD']
assert len(plan['files'])==4440
expected_before={r['path'] for r in plan['files'] if not r['before_absent']}
assert inventory()==expected_before and len(expected_before)==4428
selected={e['canonical_path']:e for e in m['files']};assert len(selected)==17
assert not set(selected)&set(m['excluded_diagnostic_paths'])
actualroot=BASE/'ordinary-provider-assembly-Root-72/workspace'
exact=0
for r in plan['files']:
    p=ROOT/r['path'];assert p.resolve().is_relative_to(ROOT)
    if r['before_absent']:assert not p.exists()
    else:
        z=p.read_bytes();assert len(z)==r['before_bytes'] and hashlib.sha256(z).hexdigest()==r['before_sha256']
    z=checked(selected[r['path']]['proposed']) if r['path'] in selected else p.read_bytes()
    assert len(z)==r['planned_bytes'] and hashlib.sha256(z).hexdigest()==r['planned_sha256']
    actual=(actualroot/r['path']).read_bytes();assert hashlib.sha256(actual).hexdigest()==r['actual72_sha256']
    same=z==actual;assert same==r['planned_exact_actual72'];exact+=same
assert exact==4432
t=ast.parse((BASE/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'))
exec(compile(ast.Module(body=[next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply')],type_ignores=[]),'<literal-apply>','exec'))
for e in m['files']:
    a,b=checked(e['before']),checked(e['proposed'])
    assert checked(e['literal_inverse'])==a and b==checked(e['actual72'])
    assert apply(a,checked(e['complete_forward_diff']))==b
    assert apply(b,checked(e['complete_inverse_diff']))==a
    if not e['before_absent']:
        assert (ROOT/e['canonical_path']).stat().st_nlink==1,'Canonical writes must not change held hardlinks'
        assert a==subprocess.check_output(['git','show',m['base_HEAD']+':'+e['canonical_path']],cwd=ROOT)
    else:
        q=subprocess.run(['git','cat-file','-e',m['base_HEAD']+':'+e['canonical_path']],cwd=ROOT,capture_output=True);assert q.returncode!=0
for key in ['actual72_independent_mechanical_command_review','actual72_independent_all_five_physical_prefix_review']:
    p=json.loads(checked(m[key]));assert p.get('accepted') or str(p.get('decision','')).startswith('ACCEPTED')
script=checked(m['apply_script']);ast.parse(script.decode('utf-8'))
OUT.mkdir();result=dict(accepted=True,manifest=ref(mp),full_compiler_plan=m['complete_compiler_Source_plan'],
    exact_before_inventory=4428,complete_planned_inputs=4440,planned_inputs_exact_actual72=4432,
    selected_Rust=17,new_Rust=12,existing_Rust=5,literal_applications=34,
    all_existing_canonical_selected_paths_single_link=True,all_diagnostic_paths_excluded=True,
    scope='Exact Source72 report core plus complete unchanged compiler inputs. No held dispatch/diagnostic/snapshot promoted. Apply script whole-before/whole-after byte guards reviewed; Root adds exact path census and verifies single-link canonical writes.',
    applied=False,Cargo_Native_tests_executed=False,whole_numeric_or_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve()))
p=OUT/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

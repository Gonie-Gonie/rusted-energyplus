"""Close the finite union72 review using actual compiler artifacts and frontier."""
from pathlib import Path
from collections import Counter
import hashlib,json
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';W=D/'ordinary-provider-assembly-Root-72/workspace';O=D/'through-primary-diagnostic-A-24H-Root-72/output';OLD=D/'through-primary-diagnostic-A-24H-Root-71-02/output';OUT=D/'Reviewer-ordinary-provider-union72-Source-review-01'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 b=(base/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b)));return b
def receipt(name,expected,code):
 p=W/'.runtime/porting/SRC-06'/name/'receipt.json';assert ref(p)['sha256']==expected;r=json.loads(p.read_bytes())
 assert r['exit_code']==code and r['launch_error'] is None and r['source_bytes_match_before_and_after'] and r['repository_before']==r['repository_after']
 assert r['source_snapshot']['sha256']=='295734c0cf745d328125933eedf8d8cb0374889158d9ff1f326559d1a0137368'
 for k in ['stdout','stderr','source_snapshot']:read(r[k],W)
 return r,dict(receipt=ref(p),command=r['command'],actual_exit=code,stdout=ref(W/r['stdout']['path']),stderr=ref(W/r['stderr']['path']),actual_Source_snapshot=ref(W/r['source_snapshot']['path']),Source_unchanged=True,elapsed_seconds=r['elapsed_seconds'],target_cache=r['launch_environment_selected']['CARGO_TARGET_DIR'])
part=OUT/'source-part.json';assert ref(part)['sha256']=='0a6cfd21b4aeb362bed0e526bc1a6c326ae7fe66d31bc1cb9c8311fcd8b66adb';P=json.loads(part.read_bytes());assert not P['findings']
check,cr=receipt('provider-assembly-all-targets-command-72','3fe68208673afcdc4fb8a79331dafccf7a2a85b0460ec2ec791adaeb3c13f3d9',0)
cli,rr=receipt('provider-assembly-through-primary-A-24H-command-72','c516522acb6cb9bba807211f1b13b7a82a22a799f53685c9532acef62a88b38c',6)
snapshot=json.loads(read(cli['source_snapshot'],W));assert len(snapshot['files'])==4441 and sum(r['historical_path'].endswith('.rs') for r in snapshot['files'])==4428
for row in snapshot['files']:assert read(row['archive'],W)==(W/row['historical_path']).read_bytes() and row['size_bytes']==(W/row['historical_path']).stat().st_size
artifacts=[]
for line in read(cli['stdout'],W).decode('utf8').splitlines():
 try:x=json.loads(line)
 except ValueError:continue
 if x.get('reason')=='compiler-artifact' and x['target']['name'] in ['ep_runtime','ep_run','eplus-rs']:
  assert not x['fresh'] and Path(x['manifest_path']).is_relative_to(W) and Path(x['target']['src_path']).is_relative_to(W)
  artifacts.append({k:x[k] for k in ['package_id','manifest_path','target','fresh','filenames','executable']})
assert len(artifacts)==3 and {x['target']['name'] for x in artifacts}=={'ep_runtime','ep_run','eplus-rs'}
diagnostic=json.loads((O/'diagnostics.json').read_bytes());errors=[r for r in diagnostic['diagnostics'] if r['severity']=='error']
assert len(errors)==1 and errors[0]['blocking'] and errors[0]['message']=='selected heat-balance input unavailable: actual WriteTabularReports5231 WriteTableOfContents entry'
log=(O/'eplusrs.ctf.log').read_bytes();assert b'Beginning Primary Simulation' in log and b'Starting Simulation at 01/01/2013 for RUN PERIOD 1' in log
assert b'Environment:WarmupDays, 20' in (O/'eplusrs.eio').read_bytes()
same=[]
for n in ['eplusrs.eso','eplusrs.mtr','eplusrs.eio','logs/source-report-binary64.csv']:
 assert (O/n).read_bytes()==(OLD/n).read_bytes();same.append(ref(O/n))
tablep=O/'logs/source-predefined-table.json';table=json.loads(tablep.read_bytes());before=json.loads((OLD/'logs/source-predefined-table.json').read_bytes());T=table['table'];B=before['table'];R=table['registry']
assert table['schema']==before['schema']=='source-predefined-table-observation.v1'
registry_without_footnote=json.loads(json.dumps(R));footnote_index=R['named_indices']['pdstLeedEneCostSum']-1
old_footnote=before['registry']['allocated_subtables_in_original_order'][footnote_index]['footnote'];new_footnote=R['allocated_subtables_in_original_order'][footnote_index]['footnote']
assert old_footnote=='' and new_footnote=='Process energy cost based on ratio of process to total energy.'
registry_without_footnote['allocated_subtables_in_original_order'][footnote_index]['footnote']=old_footnote
assert registry_without_footnote==before['registry']
assert B['num_table_entry']==505 and T['num_table_entry']==726 and T['size_table_entry']==B['size_table_entry']==800
assert T['allocated_rows_in_original_order'][:505]==B['allocated_rows_in_original_order'][:505]
columns={r['source_index_one_based']:r for r in R['allocated_columns_in_original_order']};subs={r['source_index_one_based']:r for r in R['allocated_subtables_in_original_order']};reports={r['source_index_one_based']:r for r in R['allocated_reports_in_original_order']};added=T['allocated_rows_in_original_order'][505:726];report_counts=Counter()
for row in added:
 c=columns[row['index_column']];s=subs[c['subtable_index']];r=reports[s['report_index']];report_counts[r['name_with_spaces']]+=1
assert report_counts=={'LEED Summary':221}
late_old=T['allocated_rows_in_original_order'][480];late_new=added[0]
assert (late_old['index_column'],late_old['object_name'])==(late_new['index_column'],late_new['object_name']) and bytes.fromhex(late_old['char_entry_hex']).strip(b' ')==b'-'
csvbytes=(O/'eplustbl.csv').read_bytes();lines=csvbytes.splitlines();titles=[]
for i,line in enumerate(lines):
 if line.startswith(b',,') and line.strip(b','):
  title=next(x for x in reversed(lines[:i]) if x);titles.append(title.decode('ascii'))
assert len(titles)==len(set(titles))==13
assert titles[0]=='Site and Source Energy' and titles[-1]=='Comfort and Setpoint Not Met Summary'
assert b'REPORT:,Annual Building Utility Performance Summary' in csvbytes and b',Total Site Energy,0.28,1.20,' in lines and b',Total Building Area,232.26' in lines
physical=[ref(O/n) for n in ['eplustbl.csv','eplustbl.tab','eplustbl.txt','eplustbl.htm','eplustbl.xml']]
r=dict(schema='src06-independent-union72-source-actual-command-frontier-review.v1',accepted=True,status='ACCEPTED_MECHANICAL_SOURCE_UNION_AND_ACTUAL_BOUNDED_BEPSTABLE_TRAVERSAL',manifest=P['manifest'],Source_part=ref(part),findings=[],actual_alltargets_check=cr,actual_A=rr,actual_compiler_artifacts=artifacts,compiler_Source_snapshot_inputs=4441,Rust_sources=4428,actual_frontier=errors[0],Source_predefined_observation=dict(snapshot=ref(tablep),before_active=505,after_active=726,capacity=800,unchanged_prefix_entries=505,appended_entries=221,appended_report_counts=dict(report_counts),actual_registry_footnote_write=dict(named_index='pdstLeedEneCostSum',source_subtable_ordinal=footnote_index+1,before=old_footnote,after=new_footnote,Source='beps_report/leed.rs107-110',Native='OutputReportTabular.cc8748-8749'),all_other_registry_cells_unchanged=True,late_gross_area_placeholder=late_old,actual_BEPS_later_appended_gross_area=late_new,qualification='Observed Source append order only. Registry joins are exact; no Native final table equality is inferred.'),actual_Source_report_tables=dict(count=13,ordered_titles=titles,physical_files=physical,observed_total_site_energy_reported_bytes='0.28 GJ',observed_total_building_area_reported_bytes='232.26 m2',qualification='Actual Source output observations, not a Native reference assertion, completed report set, or full endrun.'),existing_outputs_whole_equal71_corrected=same,independent_leaf_peers=P['independent_leaf_peers'],scope='Mechanical exact composition using separately accepted BEPS04/caller peers, actual compilation/traversal and finite Source state observations only. Root separately owns Native13-table/all-five-physical-prefix comparison.',qualifications=['Actual exit6 is the next genuine5231 TOC child entry after all13 BEPS tables, not completed Source runtime/export/endrun success. Generic diagnostic error code does not establish thermal convergence failure.','Runtime/run/cli compiler JSON all show fresh:false and actual72 manifest/source paths. The shared Root55 target directory is reused; no fresh-entire-target or unspecified loaded FP dependency claim.','No existing tests were rerun72 and no new test bodies were added. Recorded prior71 four-test contract evidence is not relabeled as tests of new BEPS behavior.','All55 report sidecar and ESO/MTR/EIO bytes remain whole-equal corrected71; prior3536/5280 parsed ESO mismatch and six-series upstream differences remain unchanged and unassigned.','TOC leaf/caller are separately accepted future work and not included72. Canonical production pipeline and diagnostics remain unchanged; no numerical gate or full Native run PASS.'],reviewer_Source=ref(Path(__file__)),preserved_partial_reviewer01=dict(Source=ref(D/'review-union72-actual-Reviewer-01.py'),failure='Reviewer initially assumed registry wholly unchanged. Actual Native8748-8749 and Sourceleed107-110 add the genuine LEED process-cost footnote; assertion stopped before artifacts. Reviewer02 verifies that sole named cell mutation and exact whole registry recovery.'),canonical_mutated=False,Git_mutated=False,Cargo_tests_Native_executed_by_reviewer=False,numerical_PASS_or_gate_claim=False)
p=OUT/'review.json';assert not p.exists();p.write_bytes((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

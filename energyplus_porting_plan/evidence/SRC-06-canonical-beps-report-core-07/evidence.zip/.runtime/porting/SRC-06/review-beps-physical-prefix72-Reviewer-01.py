"""Independently compare every physical Source prefix line, with raw mismatches."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';P=D/'Root-actual-BEPS-five-format-comparison-72-02/comparison.json';OUT=D/'Reviewer-ordinary-provider-union72-Source-review-01'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['bytes'];return b
assert ref(P)['sha256']=='a193d763483c0fe403a53009dbb5ebe28247a681917ed71b76c204cf05920443'
C=json.loads(P.read_bytes());rows=[];exact=0;all_differences=[]
for r in C['physical_formats']:
 s=read(r['Source']).splitlines(keepends=True);n=read(r['Native']).splitlines(keepends=True);assert len(n)>len(s)
 diffs=[]
 for i,(a,b) in enumerate(zip(s,n),1):
  if a==b:exact+=1;continue
  declared=next(x for x in r['all_uncapped_producer_clock_differences'] if x['line']==i)
  assert a.hex()==declared['Source_raw_hex'] and b.hex()==declared['Native_raw_hex']
  if declared['reason']=='producer/version':
   assert b'rusted-energyplus 0.1.0' in a and b'EnergyPlus, Version 26.1.0-6f2e40d102, YMD=' in b
   aa=a.replace(b'rusted-energyplus 0.1.0',b'<PRODUCER_VERSION>')
   bb=re.sub(rb'EnergyPlus, Version 26\.1\.0-6f2e40d102, YMD=\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}',b'<PRODUCER_VERSION>',b)
  else:
   assert declared['reason']=='actual time';pat=rb'^([ ]*)([0-2][0-9]:[0-5][0-9]:[0-5][0-9])(.*\r\n)$';ma=re.fullmatch(pat,a);mb=re.fullmatch(pat,b);assert ma and mb
   aa=ma[1]+b'<ACTUAL_CLOCK>'+ma[3];bb=mb[1]+b'<ACTUAL_CLOCK>'+mb[3]
  assert aa==bb
  diffs.append(declared);all_differences.append(dict(format=r['format'],**declared))
 assert diffs==r['all_uncapped_producer_clock_differences'] and len(s)==r['Source_physical_lines'] and len(n)==r['Native_final_physical_lines'] and len(s)-len(diffs)==r['all_other_prefix_lines_exact']
 rows.append(dict(format=r['format'],Source=r['Source'],Native=r['Native'],Source_raw_lines=len(s),Native_raw_lines=len(n),exact_raw_prefix_pairs=len(s)-len(diffs),all_uncapped_metadata_differences=diffs))
assert exact==C['exact_raw_prefix_lines']==3007 and len(all_differences)==C['producer_version_clock_lines_separately_retained']==9
csvp=next(r for r in C['physical_formats'] if r['format']=='csv');lines=read(csvp['Source']).splitlines();headers=[i for i,l in enumerate(lines,1) if l.startswith(b',,') and l.strip(b',')]
assert headers==C['CSV_header_line_positions'] and len(headers)==C['complete_named_BEPS_tables']==13
for key in ['actual_Source_receipt','Native_receipt','Native_version_receipt','original_IDF','weather','predefined_snapshot','author_Source']:read(C[key])
r=dict(schema='src06-independent-BEPS72-all-five-raw-prefix-review.v1',accepted=True,decision='ACCEPTED_FINITE_ACTUAL_REPORTED_BYTE_PREFIX_COMPARISON',Root_comparison=ref(P),union72_mechanical_actual_review=ref(OUT/'review.json'),actual_Source=C['actual_Source_receipt'],Native_actual=C['Native_receipt'],Native_version=C['Native_version_receipt'],formats=rows,independently_recomputed_exact_raw_line_pairs=exact,all_uncapped_producer_clock_differences=all_differences,CSV_nonempty_headers=headers,findings=[],method='Every Source splitlines(keepends=True) physical byte line is compared directly to the same Native prefix ordinal. All nine actual differences are retained fullhex and verified to differ only in producer/version or actual HH:MM:SS operands. No report body, comma, Unicode, CRLF, rounding or tolerance normalization.',qualifications=['Finite observed A24 physical BEPS prefix only. Source stopped before5231 TOC and later reports/close/export; Native output is complete.','Matching all reported precision/body bytes does not prove Native internal binary64 equality or unexecuted branches. Existing ESO upstream differences are unchanged.','No Cargo/tests/Native execution, canonical change, numerical gate or completed Source runtime claim.'],reviewer_Source=ref(Path(__file__)))
p=OUT/'physical-prefix-comparison-supplement.json';assert not p.exists();p.write_bytes((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06'
OUT=BASE/'Root-actual-BEPS-five-format-comparison-72-02';assert not OUT.exists()
S=BASE/'through-primary-diagnostic-A-24H-Root-72/output';N=BASE/'native-installed-A-24H-Root-67/output'
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
receipt=BASE/'ordinary-provider-assembly-Root-72/workspace/.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-72/receipt.json'
r=json.loads(receipt.read_bytes());assert r['exit_code']==6 and r['source_bytes_match_before_and_after']
assert ref(receipt)['sha256']=='c516522acb6cb9bba807211f1b13b7a82a22a799f53685c9532acef62a88b38c'
assert any('actual WriteTabularReports5231 WriteTableOfContents entry' in x.get('message','') for x in json.loads((S/'diagnostics.json').read_bytes())['diagnostics'])
rows=[];exact=0;excluded=0
expected={'csv':{1:'producer/version'},'tab':{1:'producer/version'},'txt':{1:'producer/version'},
          'htm':{6:'actual time',13:'producer/version',18:'actual time',25:'actual time'},
          'xml':{6:'producer/version',12:'actual time'}}
for ext,allowed in expected.items():
    sp=S/('eplustbl.'+ext);np=N/('energyplustbl.'+ext)
    a=sp.read_bytes().splitlines(keepends=True);b=np.read_bytes().splitlines(keepends=True)
    assert len(a)<len(b)
    diffs=[]
    for i,x in enumerate(a,1):
        y=b[i-1]
        if i in allowed:
            assert x!=y
            if allowed[i]=='producer/version':
                assert b'rusted-energyplus 0.1.0' in x and b'EnergyPlus, Version 26.1.0-6f2e40d102' in y
            else:
                assert x.split(b':')[:1]!=[] and y.split(b':')[:1]!=[]
            diffs.append(dict(line=i,reason=allowed[i],Source_raw_hex=x.hex(),Native_raw_hex=y.hex()))
        else:
            assert x==y,(ext,i,x,y)
    assert len(diffs)==len(allowed)
    exact+=len(a)-len(diffs);excluded+=len(diffs)
    rows.append(dict(format=ext,Source=ref(sp),Native=ref(np),Source_physical_lines=len(a),
        Native_final_physical_lines=len(b),all_other_prefix_lines_exact=len(a)-len(diffs),
        all_uncapped_producer_clock_differences=diffs,Source_is_unclosed_report_prefix=True))
assert exact==3007 and excluded==9
csv=(S/'eplustbl.csv').read_bytes().splitlines();table_headers=[i for i,l in enumerate(csv,1) if l.startswith(b',,') and l[2:].strip(b',')]
assert len(table_headers)==13
assert b',Total Site Energy,0.28,1.20,' in csv and b',Total Source Energy,0.88,3.80,' in csv
assert b',Total Building Area,232.26' in csv
for name in ['eplusrs.eso','eplusrs.mtr','eplusrs.eio']:
    assert (S/name).read_bytes()==(BASE/'through-primary-diagnostic-A-24H-Root-71-02/output'/name).read_bytes()
table=json.loads((S/'logs/source-predefined-table.json').read_bytes())
OUT.mkdir();result=dict(schema='actual-BEPS-full-physical-prefix-vs-installed-Native.v1',
    actual_Source_receipt=ref(receipt),Native_receipt=ref(BASE/'native-installed-A-24H-command-Root-67/receipt.json'),
    Native_version_receipt=ref(BASE/'native-installed-version-Root-67/receipt.json'),
    original_IDF=ref(ROOT/'energyplus_porting_plan/cases/A-24H/input.idf'),
    weather=ref(ROOT/'.runtime/energyplus/26.1.0/WeatherData/USA_CO_Golden-NREL.724666_TMY3.epw'),
    actual_frontier='WriteTableOfContents5231 entry after successful fullBEPS5230',
    complete_named_BEPS_tables=13,CSV_header_line_positions=table_headers,physical_formats=rows,
    exact_raw_prefix_lines=exact,producer_version_clock_lines_separately_retained=excluded,
    observed_nonzero_reported_values='TotalSite0.28GJ/1.20MJm2; TotalSource0.88GJ/3.80MJm2; actualarea232.26m2. Observations only, never supplied to production.',
    predefined_snapshot=ref(S/'logs/source-predefined-table.json'),active_predefined_entries=table['table']['num_table_entry'],
    comparison_method='Direct raw line equality at every Source prefix line in allfive formats. Only nine explicit producer-version/actual-clock lines excluded and stored full raw; no body rounding/normalization/tolerance/fuzzy matching.',
    limits='Finite actual A24 report writer/unit/caller comparison. Native output is complete, Source stops before TOC and later report/close/export. Matching reported precision does not certify all internal binary64 values, unexecuted branches, whole numerical equality or card completion.',
    ESO_MTR_EIO_whole_equal_previous71=True,Source_run_completed=False,whole_Native_numeric_PASS=False,gate_changes=False,
    author_Source=ref(Path(__file__).resolve()))
p=OUT/'comparison.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)));print('exact raw lines',exact,'explicit metadata lines',excluded,'tables',13)

from pathlib import Path
import ast,json,hashlib,difflib,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();D=R/'.runtime/porting/SRC-06/ordinary-tabular-writers-draft-Audit-01';O=R/'.runtime/porting/SRC-06/ordinary-tabular-writers-held-Audit-01'
assert not O.exists()
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-pollution-Audit-01.py').read_text(encoding='utf8'))
ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<pure-custody>','exec'),ns)
ref=ns['ref'];row=ns['row']
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pure={'re':re}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<literal-diff>','exec'),pure);apply_diff=pure['apply_diff']
parents=json.loads((D/'parents.json').read_bytes());recoveries=[]
def auth(d):
 p=R/d['path'];assert ref(p)==d,d;return p
def remove(s,t):
 assert s.count(t)==1,(t,s.count(t));return s.replace(t,'',1)
for c,d in parents.items():
 old=auth(d).read_text(encoding='utf8');s=(D/'proposed'/c).read_text(encoding='utf8');back=s
 if c.endswith('/ordinary_tabular_reports.rs'):
  back=remove(back,'mod writers;\n');back=remove(back,'\npub(crate) use writers::{SourceTabularBody, SourceTabularWriterOwners};\n')
 elif c.endswith('/state.rs'):
  added='    // Native OutputReportTabular.hh1290-1294 default-constructed char strings.\n'+''.join('    pub(super) '+n+': Vec<u8>,\n' for n in ['active_sub_table_name','active_report_name_no_space','active_report_name','active_for_name','prev_report_name'])
  back=remove(back,added);back=remove(back,''.join('            '+n+': Vec::new(),\n' for n in ['active_sub_table_name','active_report_name_no_space','active_report_name','active_for_name','prev_report_name']))
 else:
  for new,oldpart in [('    pub(super) streams: [SourceTabularOutputStream; 5],','    streams: [SourceTabularOutputStream; 5],'),('pub(super) struct SourceTabularOutputStream {','struct SourceTabularOutputStream {'),('    pub(super) fill: u8,','    fill: u8,'),('    pub(super) fn bytes(&mut self, bytes: &[u8])','    fn bytes(&mut self, bytes: &[u8])'),('    pub(super) fn integer(&mut self, value: i32, width: usize)','    fn integer(&mut self, value: i32, width: usize)')]:assert back.count(new)==1;back=back.replace(new,oldpart,1)
  back=remove(back,'\n// Same accepted Native ConvertToEscaped kernel; sibling writers borrow bytes.\npub(super) fn escape(input: &[u8], xml: bool) -> Result<Vec<u8>, Error> {\n    escaped::convert_to_escaped(input, xml)\n}\n')
 assert back==old,c;recoveries.append({'canonical_path':c,'whole_parent':d,'exact_inverse':True})
O.mkdir()
for p in sorted((D/'proposed').rglob('*.rs')):
 c=p.relative_to(D/'proposed').as_posix();row(c,p.read_bytes(),auth(parents[c]) if c in parents else None)
assert len(ns['rows'])==6
applications=0
for v in ns['rows']:
 new=auth(v['proposed']).read_bytes();before=auth(v['before']).read_bytes();parent=auth(v['parent_before']).read_bytes()
 for a,k,b in [(before,'complete_forward_diff',new),(new,'complete_inverse_diff',before),(parent,'parent_forward_diff',new),(new,'parent_inverse_diff',parent)]:assert apply_diff(a,auth(v[k]).read_bytes())==b;applications+=1
git=[]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
for v in ns['rows']:
 c=v['canonical_path'];proc=subprocess.run(['git','show',head+':'+c],cwd=R,capture_output=True)
 if v['canonical_absent_observed']:assert proc.returncode!=0;git.append({'canonical_path':c,'commit':head,'absent':True})
 else:assert proc.returncode==0 and proc.stdout==auth(v['before']).read_bytes();git.append({'canonical_path':c,'commit':head,'sha256':hashlib.sha256(proc.stdout).hexdigest(),'bytes':len(proc.stdout)})
syntax=[]
for v in ns['rows']:
 p=auth(v['proposed']);proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=p.read_bytes(),capture_output=True)
 assert proc.returncode==0,(p,proc.stderr.decode('utf8'));syntax.append({'Source':v['proposed'],'rustfmt_stdin_parse_exit':0,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),'stderr':proc.stderr.decode('utf8')})
native=R/'.reference/energyplus-src/26.1.0';commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=native).decode().strip();assert commit=='6f2e40d10250a105b49966baa24d843711e61048'
original=[]
for name,a,b in [('src/EnergyPlus/OutputReportTabular.cc',17305,17816),('src/EnergyPlus/OutputReportTabular.cc',17818,17950),('src/EnergyPlus/OutputReportTabular.cc',17985,18102),('src/EnergyPlus/OutputReportTabular.cc',19252,19294),('src/EnergyPlus/OutputReportTabular.hh',190,200),('src/EnergyPlus/OutputReportTabular.hh',1110,1125),('src/EnergyPlus/OutputReportTabular.hh',1280,1300),('src/EnergyPlus/OutputProcessor.hh',168,181),('src/EnergyPlus/UtilityRoutines.hh',628,634),('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.cc',201,218),('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.cc',247,278),('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.cc',294,307),('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.hh',842,851),('third_party/ObjexxFCL/src/ObjexxFCL/string.functions.hh',585,613),('third_party/ObjexxFCL/src/ObjexxFCL/char.functions.hh',244,254),('third_party/ObjexxFCL/src/ObjexxFCL/Array2.hh',608,626)]:
 p=native/name;lines=p.read_bytes().splitlines(True);assert 1<=a<=b<=len(lines);q=O/'Original'/f'{Path(name).name}-{a}-{b}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(lines[a-1:b]));original.append({'source':ref(p),'first_line':a,'last_line':b,'literal_excerpt':ref(q)})
depnames=['ordinary-tabular-style-passes-held-Root-01/manifest.json','Fix-ordinary-tabular-style-passes-Source-review-03/review.json','ordinary-tabular-output-files-held-Audit-02/manifest.json','Reviewer-ordinary-tabular-output-files-Source-review-01/review.json','ordinary-weather-stat-held-Audit-01/manifest.json','Fix-ordinary-weather-stat-Source-review-01/review.json','Reviewer-ordinary-live-diagnostics-Source-review-03/review.json']
deps=[ref(R/'.runtime/porting/SRC-06'/n) for n in depnames]
actual=[ref(R/p) for p in ['crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/output_files/escaped.rs','crates/ep_runtime/src/heat_balance/error_backend/live_flags.rs','crates/ep_runtime/src/heat_balance/source_output_registration.rs','crates/ep_runtime/src/heat_balance/ordinary_utility_bills.rs']]
api={'methods':['SourceTabularReports::write_source_report_headers(report:&[u8],object:&[u8],store:SourceOutputStoreType)->Result<(),HeatBalanceInputError>','write_source_subtitle(subtitle:&[u8])->Result<(),HeatBalanceInputError>','write_source_text_line(line:&[u8],bold:bool)->Result<(),HeatBalanceInputError>','write_source_table(body:&SourceTabularBody,row_labels:&[Vec<u8>],column_labels:&[Vec<u8>],widths:&mut[i32],transpose_xml:bool,footnote:&[u8],owners:&mut SourceTabularWriterOwners)->Result<(),HeatBalanceInputError>'],
 'local_body':'SourceTabularBody::allocate(columns,rows) default-constructs actual empty string cells; at/set use one-based (column,row) ordinals. Internal last-dimension-fast address matches pinned Array2. This is a local table body, not a duplicate scientific owner.',
 'owner':'SourceTabularWriterOwners borrows the sole SourceCostEstimateMonetary, actual backend, and short live SourceDiagnosticFlags references. No held phase copy; only mismatch warnings call the genuine ordered live backend method.',
 'storage':'Five genuine Native std::string fields on the same TAB state are sole Vec<u8> storage: active_sub_table_name, active_report_name_no_space, active_report_name, active_for_name, prev_report_name. Constructor empty is exact standard string default. No UTF8 mirror or replacement decoder.',
 'files':'Uses the exact accepted five SourceTabularOutputStream members. Only sibling visibility and a direct forwarding escape method are added to output_files.rs; all prior kernel/body/constructor bytes recover exactly. No open, flush, close, reset or additional File is introduced.',
 'formats':'Comma/Tab/Fixed/HTML/XML actual branches complete, including widths mutated before each style, 50-row column-label cap, byte-sized right justification, currency substr order, XML blank detection/transposition, active-name state writes and exact footnote conditions.',
 'true_boundaries':['isize and string-length int conversions outside the Native defined i32 domain','Native array subscript/column label row beyond50','negative fixed width requests unrepresentable Native allocation','unallocated/out-of-range actual currency row at first marker','same accepted ConvertToEscaped stoul/subscript domains and physical IO exceptional continuation limits'],
 'scope':'Reusable writer Source only. No BEPS numeric kernel, report pass caller, actual output generation, Native output equality or scientific gate completion claimed.'}
(O/'API.json').write_bytes((json.dumps(api,indent=2)+'\n').encode())
(O/'checks.json').write_bytes((json.dumps({'whole_existing_parent_recoveries':recoveries,'literal_patch_applications':applications,'read_only_Git':git,'Native_commit':commit,'syntax_only':syntax,'new_test_bodies':0,'Cargo_Native_executed':False},indent=2)+'\n').encode())
manifest={'schema':'src06-genuine-physical-tabular-writers-held.v1','status':'HELD reusable five-format writer Source; independent peer and joined compilation/caller required','base_HEAD':head,'Original_commit':commit,'files':ns['rows'],'Original_authority':original,'dependencies':deps,'actual_API_dependencies':actual,'API':ref(O/'API.json'),'checks':ref(O/'checks.json'),'author_Source':ref(Path(__file__).resolve()),'canonical_mutations':0,'Git_mutations':0,'Cargo_Native_executed':False,'new_test_bodies':0,'numerical_gate_claim':False}
(O/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

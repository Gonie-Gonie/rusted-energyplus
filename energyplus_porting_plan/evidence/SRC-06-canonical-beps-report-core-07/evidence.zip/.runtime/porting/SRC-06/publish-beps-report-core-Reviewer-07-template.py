"""Root-only publisher template. Do not run before Root supplies closed check SHA."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-beps-report-core-07'
READY=D/'canonical-beps-publication-template-Reviewer-07'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r,base=ROOT):
 p=base/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b)));return p
def load(p):return json.loads(p.read_bytes())
def main(args):
 assert args.publish,'Only Root may explicitly --publish after canonical check readiness'
 assert not PUBLIC.exists()
 cp=ROOT/args.canonical_receipt;assert ref(cp)['sha256']==args.canonical_receipt_sha
 check=load(cp);assert check['exit_code']==0 and check['launch_error'] is None and check['source_bytes_match_before_and_after']
 assert 'check' in check['command'] and '--all-targets' in check['command'] and '--workspace' in check['command']
 prepared=D/'canonical-source72-report-core-prepared-Reviewer-01/manifest.json';assert ref(prepared)['sha256']=='81f90aabf8953289e2145f8613d99c8976306ca26c358db1bcba3382222e318d';M=load(prepared)
 head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip();assert head==M['base_HEAD']
 plan=load(checked(M['complete_compiler_Source_plan']));planned={r['path']:r for r in plan['files']}
 snapshot=load(checked(check['source_snapshot']));observed={r['historical_path']:r for r in snapshot['files']};assert set(observed)==set(planned) and len(observed)==4440 and sum(n.endswith('.rs') for n in observed)==4427
 for n,r in observed.items():
  b=(ROOT/n).read_bytes();assert b==checked(r['archive']).read_bytes() and len(b)==planned[n]['planned_bytes'] and hashlib.sha256(b).hexdigest()==planned[n]['planned_sha256']
 assert len(M['files'])==17 and sum(r['before_absent'] for r in M['files'])==12
 for r in M['files']:assert (ROOT/r['canonical_path']).read_bytes()==checked(r['proposed']).read_bytes()
 promotion=D/'Root-canonical72-report-core-review-01/review.json';assert ref(promotion)['sha256']=='83e3ed90ece2db3162d5debbcd84655a8fbd3ff66581f0e90a38bd2301e5b631' and load(promotion)['accepted']
 actual=D/'Reviewer-ordinary-provider-union72-Source-review-01/review.json';assert ref(actual)['sha256']=='bb6c4be2be6738ff92e1b81324e903cacd833730b743187394964588cff1f2e5'
 independent=D/'Reviewer-ordinary-provider-union72-Source-review-01/physical-prefix-comparison-supplement.json';assert ref(independent)['sha256']=='bb26c910d4b79d1a87d17948086aef9896cd820aa96677ff52599b3365c42b61'
 comparison=D/'Root-actual-BEPS-five-format-comparison-72-02/comparison.json';assert ref(comparison)['sha256']=='a193d763483c0fe403a53009dbb5ebe28247a681917ed71b76c204cf05920443';C=load(comparison)
 assert load(actual)['accepted'] and load(independent)['accepted'] and C['exact_raw_prefix_lines']==3007 and C['producer_version_clock_lines_separately_retained']==9
 beforeplan=ROOT/'energyplus_porting_plan/plan.json';oldplan=load(beforeplan)
 docnames=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md'];docbefore={n:(ROOT/'energyplus_porting_plan'/n).read_bytes() for n in docnames}
 for b in docbefore.values():assert '\ufffd' not in b.decode('utf8','strict')
 prior=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-weather-remaining-reports-06/summary.json';assert ref(prior)['sha256']=='48d740822a3ab681a90ac5861cb349c73c3f1fe66ec749fadd59ae50374cb705';priorv=load(prior)
 payload={}
 def add(p):
  p=p.resolve();key=p.relative_to(ROOT).as_posix();b=p.read_bytes();assert key not in payload or payload[key]==b;payload[key]=b;return ref(p)
 def addref(r,base=ROOT):return add(checked(r,base))
 def receipt(r,base=ROOT):
  p=checked(r,base);v=load(p);add(p)
  for k in ['stdout','stderr','source_snapshot']:addref(v[k],Path(v['cwd']))
  return v
 add(Path(__file__));add(prepared);add(promotion);addref(load(promotion)['reviewer_Source']);add(actual);add(independent);add(comparison);add(prior)
 for key in ['complete_compiler_Source_plan','apply_script','author_Source']:addref(M[key])
 for r in M['files']:
  for key in ['before','literal_inverse','proposed','complete_forward_diff','complete_inverse_diff']:addref(r[key])
  add(ROOT/r['canonical_path'])
 for r in M['packets']:
  addref(r);p=load(ROOT/r['path'])
  for a in p.get('Original_authority',[]):addref(a['literal_excerpt'])
  if 'author_Source' in p:addref(p['author_Source'])
 for r in M['independent_semantic_peers']:addref(r)
 for name in ['Source_part','reviewer_Source']:addref(load(actual)[name])
 addref(load(independent)['reviewer_Source']);addref(C['author_Source'])
 W=ROOT/load(checked(M['actual72']))['workspace'];A=load(actual)
 actual_commands={}
 for name,key in [('all_targets','actual_alltargets_check'),('actual_A','actual_A')]:
  r=A[key]['receipt'];v=receipt(r);assert v['exit_code']==(0 if name=='all_targets' else 6) and v['source_bytes_match_before_and_after'];actual_commands[name]=r
 receipt(ref(cp))
 for k in ['Native_receipt','Native_version_receipt']:receipt(C[k])
 for k in ['original_IDF','weather','predefined_snapshot']:addref(C[k])
 for r in C['physical_formats']:addref(r['Source']);addref(r['Native'])
 out=D/'through-primary-diagnostic-A-24H-Root-72/output'
 for n in ['diagnostics.json','run-summary.json','eplusrs.ctf.log','eplusrs.eio','eplusrs.eso','eplusrs.mtr']:add(out/n)
 # The earlier27 receipt is retained only as historical scoped evidence.
 addref(M['prior_canonical06_existing27_receipt'])
 raw_ind=D/'Reviewer-ordinary-provider-union71-Source-review-01/review.json';raw_root=D/'Root-Source71-raw-reporting-comparison-02/comparison.json'
 assert ref(raw_ind)['sha256']=='524662b5e312be7f51bd18b996628cf29fa607c6dd6457a7a1566a9dafa4c7a2' and ref(raw_root)['sha256']=='ea736f6187349b07dc1dc33cd0841e468eda2ff3ab03ac8004f085a451e35427'
 add(raw_ind);add(raw_root);addref(load(raw_root)['all_pairs']);addref(load(raw_ind)['actual55_sidecar_review'])
 # No full-offline simulation replay promise: this is the finite declared bundle.
 assert not(READY/'plan-before.json').exists();READY.mkdir(parents=True,exist_ok=True)
 (READY/'plan-before.json').write_bytes(beforeplan.read_bytes())
 for n,b in docbefore.items():
  p=READY/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 PUBLIC.mkdir(parents=True)
 z=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for key,b in sorted(payload.items()):
   info=zipfile.ZipInfo(key,date_time=(2026,10,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,b)
 with zipfile.ZipFile(z) as archive:
  assert archive.testzip() is None and len(archive.namelist())==len(payload)
  for key,b in payload.items():assert archive.read(key)==b
 s=PUBLIC/'summary.json'
 summary=dict(schema='src06-canonical-beps-report-core.v1',status='Canonical report core integrated; actual held Source72 writes13 BEPS tables then stops at true5231 TOC entry',Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,prepared_selective_promotion=ref(prepared),independent_promotion_review=ref(promotion),changed_Rust_files=17,new_Rust_files=12,existing_Rust_files=5,compiler_inputs=4440,Rust_sources=4427,literal_applications=34,canonical_inputs_exact_actual72=4432,canonical_check=ref(cp),actual_commands=actual_commands,independent_Source_and_actual_peer=ref(actual),finite_five_format_comparison=ref(comparison),independent_five_format_comparison=ref(independent),reported_BEPS_tables=13,exact_raw_prefix_lines=3007,all_explicit_version_clock_difference_lines=9,active_predefined_entries_before=505,active_predefined_entries_after=726,appended_LEED_entries=221,all_diagnostic_paths_excluded=M['excluded_diagnostic_paths'],canonical_pipeline_whole_unchanged=True,readonly_predefined_snapshot_excluded=True,raw_reporting_observation=dict(independent_all55=ref(raw_ind),Root_six_series=ref(raw_root),all576_pairs=load(raw_root)['all_pairs'],Source_final_format_roundtrips='5280/5280 exact',Native_Which_comparison='107 equal /469 unequal in six series; actual System average operands are distinct from after-report Which',qualification='Upstream cause unassigned. Actual raw observations, no supplied Native answers or tolerance change.'),prior_existing27_receipt=M['prior_canonical06_existing27_receipt'],prior_existing27_scope='Historical prior canonical06 existing27 PASS; not rerun or claimed as new-BEPS testing.',new_test_bodies=0,full_suite_rerun=False,completed_Source_run_or_export=False,whole_Native_numeric_PASS=False,pipeline_activation=False,gate_changes=False,A=priorv['A'],B=priorv['B'],retained_whole_old_comparison=priorv['retained_whole_old_comparison'],previous_checkpoint=ref(prior),numeric_observation='Source72 ESO/MTR/EIO/rawsidecar remain whole-equal corrected71. Existing3536/5280 unequal ESO parsed values and six-series upstream differences remain unassigned; matching BEPS reported precision is not Native internal binary64 equality.',remaining=['TOC5231 and later report/close/endrun/export sequence are outside this canonical17 checkpoint.','Canonical default dispatcher activation, whole numerical parity and remaining A/B domains.'],reconstruction='Exact17 Sources/before/proposals/inverses, complete4440-input hash plan, finite command/output observations and independent reviews. No new full offline simulation replay claim.',evidence_archive=ref(z),archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for k,b in sorted(payload.items())],author_Source=ref(Path(__file__)))
 assert summary['A']=='14/54' and summary['B']=='14/64'
 s.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 relative='evidence/SRC-06-canonical-beps-report-core-07/summary.json'
 paragraph='BEPS 보고 핵심 Rust 파일 17개(신규 12개·기존 5개)를 같은 실제 상태 소유자와 연결했습니다. 실제 격리 Source72 실행은 BEPS 표 13개를 작성한 뒤 목차 호출 5231의 미구현 경계에서 exit6으로 종료됩니다. 같은 입력의 Native 최종 보고서와 다섯 출력 형식의 앞부분을 비교해 원시 바이트 3,007줄이 같고, 버전·실제 시각 차이 9줄은 원문 그대로 별도 보존했습니다. LEED predefined 항목은 505개에서 726개로 늘었습니다. canonical all-targets 검사를 통과했으며 새 테스트나 전체 테스트 반복은 없습니다. 이전 27개 테스트 결과는 이전 checkpoint의 검증 범위로만 유지합니다. 진단 경로 9개·읽기 전용 snapshot·기본 pipeline은 이번 적용에서 제외했습니다. 기존 ESO 수치 차이와 A14/54·B14/64 및 전체 FAIL은 유지하며, 전체 실행·수치 동등성·카드 완료를 뜻하지 않습니다.'
 for n in docnames:
  p=ROOT/'energyplus_porting_plan'/n;assert p.read_bytes()==docbefore[n];link='../'+relative if n.startswith('cards/') else relative;extra='\n\n[BEPS 보고 핵심 단계 검증]('+link+'). '+paragraph+'\n';p.write_bytes(docbefore[n]+extra.encode('utf8'))
 after=json.loads(json.dumps(oldplan));task=next(t for t in after['tasks'] if t['id']=='SRC-06');key='canonical_beps_report_core_07';assert key not in task;task[key]=dict(path=s.relative_to(ROOT).as_posix(),sha256=ref(s)['sha256'],size_bytes=s.stat().st_size)
 checkplan=json.loads(json.dumps(after));del next(t for t in checkplan['tasks'] if t['id']=='SRC-06')[key];assert checkplan==oldplan
 assert beforeplan.read_bytes()==(READY/'plan-before.json').read_bytes();beforeplan.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 readback=dict(summary=ref(s),archive=ref(z),archive_entries=len(payload),canonical_check=ref(cp),base_HEAD=head,plan_before=ref(READY/'plan-before.json'),publisher=ref(Path(__file__)),Git_mutated=False,Cargo_tests_Native_executed=False)
 p=READY/'publication-readback.json';assert not p.exists();p.write_bytes((json.dumps(readback,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(readback))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--canonical-receipt',required=True);p.add_argument('--canonical-receipt-sha',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

from pathlib import Path
import json, hashlib, ast, difflib, re, subprocess, sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd(); O=R/'.runtime/porting/SRC-06/ordinary-beps-caller-held-Audit-01'
assert not O.exists()
P=R/'.runtime/porting/SRC-06/ordinary-provider-assembly-Root-71/workspace'
B=R/'.runtime/porting/SRC-06/ordinary-beps-report-held-Audit-04'
bm=json.loads((B/'manifest.json').read_bytes())
state='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/state.rs'
endrun='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs'
sp=R/next(v['proposed']['path'] for v in bm['files'] if v['canonical_path']==state)
oldstate=sp.read_text(encoding='utf8'); oldend=(P/endrun).read_text(encoding='utf8')
assert oldstate[oldstate.index('impl super::SourceTabularReports {'):] == (P/state).read_text(encoding='utf8')[(P/state).read_text(encoding='utf8').index('impl super::SourceTabularReports {'):]
state_old='''    ) -> Result<(), crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError> {
        if self.input_state.units_style_sqlite == 6 {'''
state_new='''    ) -> bool {
        if self.input_state.units_style_sqlite == 6 {'''
assert oldstate.count(state_old)==1
newstate=oldstate.replace(state_old,state_new,1)
tail_old='''            return Err(crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError::Unavailable(
                "actual WriteTabularReports5230 WriteBEPSTable entry",
            ));
        }
        Err(crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError::Unavailable(
            "actual WriteTabularReports5278 audit ensure_open entry",
        ))'''
tail_new='''            return true;
        }
        false'''
assert newstate.count(tail_old)==1;newstate=newstate.replace(tail_old,tail_new,1)
newend=oldend
edits=[]
def change(old,new):
 global newend
 assert newend.count(old)==1,(old,newend.count(old));newend=newend.replace(old,new,1);edits.append((old,new))
change('self.write_source_tabular_reports_prefix_on_session(session, reports, weather)', 'self.write_source_tabular_reports_prefix_on_session(session, reports, weather, backend)')
change('''        weather: &WeatherSession,
    ) -> Result<(), RuntimeError> {
        self.fill_source_weather''','''        weather: &WeatherSession,
        backend: &mut SourceErrorBackend<'_>,
    ) -> Result<(), RuntimeError> {
        self.fill_source_weather''')
old='''        session
            .tabular
            .continue_source_write_tabular_reports_after_predefined(
                &reports.source_results_framework,
                &reports.source_sqlite,
            )
            .map_err(hb_input_error)'''
new='''        if session
            .tabular
            .continue_source_write_tabular_reports_after_predefined(
                &reports.source_results_framework,
                &reports.source_sqlite,
            )
        {
            let globals = required(
                reports.selected_heat_balance_globals.as_ref(),
                "actual same Globals before BEPS5230",
            )?;
            let project = required(
                reports.selected_project_data.as_ref(),
                "actual same SysVars before BEPS5230 diagnostics",
            )?;
            session.tabular.write_source_beps_report(
                &mut crate::heat_balance::ordinary_tabular_reports::SourceBepsReportOwners {
                    registration: &reports.output_registration,
                    zones: required(
                        reports.selected_zone_input.as_ref(),
                        "actual same Zones before BEPS5230",
                    )?,
                    globals,
                    facility: required(
                        reports.facility_electric_service.as_ref(),
                        "actual same FacilityElectricService before BEPS5230",
                    )?,
                    water: &session.hvac.ancillary.water.data,
                    hvac: &required(
                        reports.selected_simulation_startup.as_ref(),
                        "actual same HVAC globals before BEPS5230",
                    )?.hvac_globals,
                    predefined_summary: &session.comfort_summary,
                    registry: &mut reports.registry,
                    table: &mut reports.table,
                    schedules: required(
                        reports.selected_schedule_manager.as_ref(),
                        "actual same schedules before BEPS5230",
                    )?,
                    results: &reports.source_results_framework,
                    sqlite: &reports.source_sqlite,
                    writer: crate::heat_balance::ordinary_tabular_reports::SourceTabularWriterOwners {
                        monetary: &reports.cost_estimate_monetary,
                        flags: SourceDiagnosticFlags {
                            kickoff: &globals.kickoff_simulation,
                            developer: &project.system.developer_flag,
                            warmup: &weather.state.global.warmup_flag,
                            doing_sizing: &globals.doing_sizing,
                        },
                        backend,
                    },
                },
            ).map_err(hb_input_error)?;
            return Err(unavailable("actual WriteTabularReports5231 WriteTableOfContents entry"));
        }
        Err(unavailable("actual WriteTabularReports5278 audit ensure_open entry"))'''
change(old,new)
assert newstate.replace(state_new,state_old,1).replace(tail_new,tail_old,1)==oldstate
rev=newend
for old,new in reversed(edits):assert rev.count(new)==1;rev=rev.replace(new,old,1)
assert rev==oldend
O.mkdir()
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<pure-custody>','exec'),ns);ref=ns['ref'];row=ns['row']
row(endrun,newend.encode(),P/endrun);row(state,newstate.encode(),sp)
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pure={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<diff>','exec'),pure);apply=pure['apply_diff']
count=0
for v in ns['rows']:
 for a,k,b in [(v['before'],'complete_forward_diff',v['proposed']),(v['proposed'],'complete_inverse_diff',v['before']),(v['parent_before'],'parent_forward_diff',v['proposed']),(v['proposed'],'parent_inverse_diff',v['parent_before'])]:
  assert apply((R/a['path']).read_bytes(),(R/v[k]['path']).read_bytes())==(R/b['path']).read_bytes();count+=1
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();git=[];parses=[]
for v in ns['rows']:
 c=v['canonical_path'];p=O/'Git-before'/c;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',head+':'+c],cwd=R))
 git.append({'canonical_path':c,'commit':head,'Git_before':ref(p),'current_before':v['before'],'actual_parent_proposed':v['parent_proposed'],'qualification':'Frozen71 endrun and BEPS02 state are authoritative overlay parents; current/Git canonical may differ without implying an unsealed mutation.'})
 proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=(R/v['proposed']['path']).read_bytes(),capture_output=True);assert proc.returncode==0,proc.stderr.decode();parses.append({'Source':v['proposed'],'exit':0,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest()})
N=R/'.reference/energyplus-src/26.1.0';original=[]
for name,a,b in [('OutputReportTabular.cc',5198,5295),('SimulationManager.cc',566,605)]:
 p=N/'src/EnergyPlus'/name;ls=p.read_bytes().splitlines(True);assert 1<=a<=b<=len(ls);q=O/'Original'/f'{name}-{a}-{b}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(ls[a-1:b]));original.append({'source':ref(p),'first_line':a,'last_line':b,'literal_excerpt':ref(q)})
api={'entry':'Existing source_simulation_endrun_prefix(_on_session) signatures unchanged. Private WriteTabularReports prefix now forwards same backend; style helper returns actual WriteTabularFiles branch bool after original units/style effects.','true_branch':'Actual5230 same SourceBepsReportOwners, all actual owner references and short live SourceDiagnosticFlags; then explicit5231 TOC boundary.','false_branch':'Actual5278 Audit ensure_open boundary unchanged.','body_dependency':'Corrected BEPS04 exact two-index successor independently accepted Fix c0e5f8. Caller only reborrows actual owners and preserves the same ABI/body; no self-acceptance of BEPS scientific semantics.','missing_owner_domain':'Existing required owner representation guards only; no manufactured owner or success default.','whole_parent_recoveries':2,'new_test_bodies':0}
(O/'API.json').write_bytes((json.dumps(api,indent=2)+'\n').encode())
deps=[ref(P.parent/'manifest.json'),ref(B/'manifest.json'),ref(R/'.runtime/porting/SRC-06/Fix-ordinary-beps-report-correction-Source-review-01/review.json'),ref(R/'.runtime/porting/SRC-06/ordinary-tabular-writers-held-Audit-01/manifest.json'),ref(R/'.runtime/porting/SRC-06/Fix-ordinary-tabular-writers-Source-review-02/review.json')]
actual=[]
for c in ['crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs','crates/ep_runtime/src/heat_balance/ordinary_source_session.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/water_manager.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/writers.rs']:
 actual.append(ref(P/c))
checks={'applications':count,'whole_parent_recoveries':2,'read_only_Git':git,'Source_parse_only':parses,'same71_method_equals_BEPS_state_method':True,'actual_API_refs':actual,'mutable_registry_table_and_backend_are_disjoint_actual_field_borrows':True,'canonical_edits':0,'Cargo_or_Native_executed':False}
(O/'checks.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode())
m={'schema':'src06-literal-beps5230-caller-held.v1','status':'HELD caller-only on independently accepted BEPS04; independent caller peer/compiler/runtime required','base_HEAD':head,'files':ns['rows'],'Original_authority':original,'dependencies':deps,'actual_API_dependencies':actual,'API':ref(O/'API.json'),'checks':ref(O/'checks.json'),'author_Source':ref(Path(__file__).resolve()),'BEPS02_semantic_acceptance_claimed':False,'whole_run_or_numerical_gate_claim':False,'new_test_bodies':0,'Cargo_Native_or_Git_mutations':False,'canonical_mutations':0}
(O/'manifest.json').write_bytes((json.dumps(m,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

from pathlib import Path
import ast,json,hashlib,difflib,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd(); P=R/'.runtime/porting/SRC-06/ordinary-beps-report-held-Audit-02';O=R/'.runtime/porting/SRC-06/ordinary-beps-report-held-Audit-04';assert not O.exists()
m=json.loads((P/'manifest.json').read_bytes())
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<pure-custody>','exec'),ns);ref=ns['ref'];row=ns['row']
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pure={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<literal-diff>','exec'),pure);apply=pure['apply_diff']
def auth(d):
 p=R/d['path'];assert ref(p)==d,d;return p
rejection=R/'.runtime/porting/SRC-06/Fix-ordinary-beps-report-Source-review-03/review.json'
assert ref(rejection)['sha256']=='c28209f055b5b0991ab8ae741ff038310fa30ff0b3fd7e70e9f1e4c0b82dd71d'
O.mkdir();changed=[];unchanged=[];direct=[]
for old in m['files']:
 c=old['canonical_path'];before=auth(old['proposed']).read_bytes();after=before
 if c.endswith('/beps_report/prepare.rs'):
  for ordinal in ['sub','space']:
   a=f'                            {ordinal} as usize,\n                            source,\n                            end_use,\n'.encode()
   b=f'                            {ordinal} as usize,\n                            end_use,\n                            source,\n'.encode()
   assert after.count(a)==1;after=after.replace(a,b,1)
  changed.append(c)
 else:unchanged.append(c)
 parent=auth(old['parent_proposed']) if old['parent_proposed'] else None
 row(c,after,parent)
 new=ns['rows'][-1];new['direct_parent_proposed']=old['proposed']
 for key,a,b in [('direct02_forward_diff',before,after),('direct02_inverse_diff',after,before)]:
  q=O/'direct02-diffs'/(str(len(ns['rows'])).zfill(2)+('.inverse.diff' if 'inverse' in key else '.diff'));q.parent.mkdir(exist_ok=True)
  text=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+c,tofile='b/'+c))
  q.write_bytes(text.encode());new[key]=ref(q);assert apply(a,q.read_bytes())==b
assert len(changed)==1 and len(unchanged)==12
applications=0
for v in ns['rows']:
 for a,k,b in [(v['before'],'complete_forward_diff',v['proposed']),(v['proposed'],'complete_inverse_diff',v['before']),(v['parent_before'],'parent_forward_diff',v['proposed']),(v['proposed'],'parent_inverse_diff',v['parent_before'])]:
  assert apply(auth(a).read_bytes(),auth(v[k]).read_bytes())==auth(b).read_bytes();applications+=1
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();git=[];syntax=[]
W=R/'.runtime/porting/SRC-06/ordinary-provider-assembly-Root-71/workspace'
for v in ns['rows']:
 c=v['canonical_path'];proc=subprocess.run(['git','show',head+':'+c],cwd=R,capture_output=True)
 if v['canonical_absent_observed']:assert proc.returncode!=0;git.append({'canonical_path':c,'commit':head,'absent':True})
 else:
  assert proc.returncode==0 and proc.stdout==auth(v['before']).read_bytes(),c
  assert (W/c).read_bytes()==auth(v['parent_before']).read_bytes(),c
  git.append({'canonical_path':c,'commit':head,'current_Git_bytes_equal':True,'original_owner_parent_whole_equals_Root71':True,'Source':v['before']})
 p=auth(v['proposed']);proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=p.read_bytes(),capture_output=True);assert proc.returncode==0,(p,proc.stderr.decode());syntax.append({'Source':v['proposed'],'parse_exit':0,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest()})
for v in m['Original_authority']:
 lines=auth(v['source']).read_bytes().splitlines(True);a=v['first_line'];b=v['last_line'];assert 1<=a<=b<=len(lines);assert b''.join(lines[a-1:b])==auth(v['literal_excerpt']).read_bytes()
additional=[]
for c in ['crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/beps_gather.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/beps_input.rs']:
 p=W/c
 if p.exists():additional.append(ref(p))
api=json.loads(auth(m['API']).read_bytes());api['correction04']='Only gather_end_use_sub_beps and gather_end_use_space_type_beps read pairs now use actual [sub/space,end_use,source]. Collapsed destination stays [sub/space,end_use,display_resource]. Same actual Source producer and Native7922-7937 establish both domains. No other Source body changed.'
(O/'API.json').write_bytes((json.dumps(api,indent=2)+'\n').encode())
checks={'changed_Source_paths':changed,'unchanged_whole_Source_paths':unchanged,'direct02_changed_sites':2,'four_original_owner_parent_recoveries_inherited':m['checks'],'literal_applications':applications,'direct02_applications':26,'read_only_current_Git':git,'Source_parse_only':syntax,'actual_gather_producer_refs':additional,'no_numeric_execution_or_finite_A_effect_claim':True}
(O/'checks.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode())
out=dict(m);out.update({'schema':'src06-full-finite-physical-BEPS-source-held.v2','status':'HELD narrow two-site 3D gather-order successor; independent correction peer/compiler/runtime required','base_HEAD':head,'files':ns['rows'],'dependencies':[ref(P/'manifest.json'),ref(rejection)]+m['dependencies'],'API':ref(O/'API.json'),'checks':ref(O/'checks.json'),'author_Source':ref(Path(__file__).resolve()),'direct_rejection':ref(rejection),'original_owner_parent_policy':'parent_proposed retains original owner parents for first-time BEPS integration; direct_parent_proposed and direct02 diffs authenticate the narrow correction, never replace absent original integration baselines.','BEPS02_preserved_immutable':True})
out['preserved_unsealed_author03_failure']=ref(R/'.runtime/porting/SRC-06/ordinary-beps-report-held-Audit-03/author-failure.json')
(O/'manifest.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

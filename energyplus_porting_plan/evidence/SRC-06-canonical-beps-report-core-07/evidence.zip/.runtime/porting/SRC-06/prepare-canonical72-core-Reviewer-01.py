"""Prepare exact17 reviewed report-core proposals; never applies canonical bytes."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';OUT=D/'canonical-source72-report-core-prepared-Reviewer-01'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 b=(base/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b)));return b
def load(p):return json.loads(p.read_bytes())
def paths(w):
 q=subprocess.run(['rg','--files','--hidden','--no-ignore','-g','*.rs','-g','Cargo.toml','crates'],cwd=w,capture_output=True,check=True);s={n.replace('\\','/') for n in q.stdout.decode().splitlines()};return s|{n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (w/n).is_file()}
def git(*args):return subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
head=git('rev-parse','HEAD').stdout.decode().strip();assert head=='2c844b2962fe273c5ef715dfe4b5ae7320d5c9b8' and git('status','--porcelain').stdout==b''
mp=D/'ordinary-provider-assembly-Root-72/manifest.json';assert ref(mp)['sha256']=='110b2303cd448b1554e85acefb85eaf4539627976c0a2fda77c3086d3cc80936';M=load(mp);W=ROOT/M['workspace']
writerp=D/'ordinary-tabular-writers-held-Audit-01/manifest.json';writer=load(writerp)
packets=[writer]+[json.loads(read(r)) for r in M['packets']];selected={r['canonical_path'] for p in packets for r in p['files']};assert len(selected)==17
dp=D/'ordinary-report-binary64-diagnostic-held-Reviewer-01/manifest.json';diagnostic=load(dp);excluded={r['canonical_path'] for r in diagnostic['files']};assert len(excluded)==9 and not selected&excluded
reviewp=D/'Reviewer-ordinary-provider-union72-Source-review-01/review.json';supp=D/'Reviewer-ordinary-provider-union72-Source-review-01/physical-prefix-comparison-supplement.json';assert load(reviewp)['accepted'] and load(supp)['accepted']
peers=[M['independent_reviews'][0],M['independent_reviews'][1],ref(D/'Fix-ordinary-tabular-writers-Source-review-02/review.json')]
for r in peers:
 p=json.loads(read(r));assert not p.get('findings',[]) and (p.get('accepted') is True or str(p.get('decision',p.get('verdict',''))).startswith('ACCEPTED'))
beforepaths=paths(ROOT);actual72=paths(W);new={n for n in selected if not(ROOT/n).exists()};assert len(new)==12 and len(selected-new)==5
planned=beforepaths|new;assert len(beforepaths)==4428 and len(planned)==4440 and sum(n.endswith('.rs') for n in planned)==4427
assert actual72-planned=={n for n in excluded if not(ROOT/n).exists()} and len(actual72-planned)==1
priorp=D/'canonical-source70-existing-arbitrary-run-tests-Root-06-8MiB/receipt.json';prior=load(priorp);beforeindex=json.loads(read(prior['source_snapshot']));old={r['historical_path']:r for r in beforeindex['files']};assert set(old)==beforepaths
for n,r in old.items():assert read(r['archive'])==(ROOT/n).read_bytes()
tree=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
proposal={n:(W/n).read_bytes() for n in selected};before={n:(ROOT/n).read_bytes() if (ROOT/n).exists() else b'' for n in selected};patches={};gits=[]
for n in sorted(selected):
 q=git('show',f'{head}:{n}');assert (q.returncode==128 and n in new) or (q.returncode==0 and q.stdout==before[n]);gits.append(dict(path=n,revision=head,exit_code=q.returncode))
 assert proposal[n].count(b'#[test]')==before[n].count(b'#[test]') and proposal[n]!=before[n]
 f=ns['diff'](before[n],proposal[n],n,'before','proposed');r=ns['diff'](proposal[n],before[n],n,'proposed','before');assert ns['apply_literal'](before[n],f)==proposal[n] and ns['apply_literal'](proposal[n],r)==before[n];patches[n]=(f,r)
plan=[];differences=[]
for n in sorted(planned):
 a=(ROOT/n).read_bytes() if (ROOT/n).exists() else None;z=proposal[n] if n in selected else a;assert z is not None
 exact=z==(W/n).read_bytes()
 if not exact:differences.append(n)
 plan.append(dict(path=n,before_absent=a is None,before_sha256=hashlib.sha256(a).hexdigest() if a is not None else None,before_bytes=len(a) if a is not None else None,planned_sha256=hashlib.sha256(z).hexdigest(),planned_bytes=len(z),actual72_sha256=hashlib.sha256((W/n).read_bytes()).hexdigest(),planned_exact_actual72=exact,selected_for_write=n in selected))
assert set(differences)=={n for n in excluded if (ROOT/n).exists()} and len(differences)==8
assert not OUT.exists();OUT.mkdir(parents=True)
def write(name,b):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(name,obj):return write(name,(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode())
rows=[]
for i,n in enumerate(sorted(selected),1):
 rows.append(dict(canonical_path=n,before_absent=n in new,before=write('before/'+n,before[n]),literal_inverse=write('literal-inverse/'+n,before[n]),proposed=write('proposed/'+n,proposal[n]),complete_forward_diff=write(f'diffs/{i:02}.diff',patches[n][0]),complete_inverse_diff=write(f'diffs/{i:02}.inverse.diff',patches[n][1]),actual72=ref(W/n),proposal_rule='Exact whole Source72 bytes; no normalization, copied diagnostic state or new body edits.'))
planref=meta('complete-compiler-Source-plan.json',dict(schema='selective-canonical72-compiler-input-plan.v1',base_HEAD=head,files=plan))
applyp=D/'apply-canonical72-report-core-prepared-Reviewer-01.py';assert not applyp.exists()
applycode='''"""Root-only explicit guarded application of the prepared report core."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3]
def read(r):
 b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['bytes'];return b
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');a=p.parse_args();assert a.apply,'Root must explicitly pass --apply'
MP=ROOT/'.runtime/porting/SRC-06/canonical-source72-report-core-prepared-Reviewer-01/manifest.json';M=json.loads(MP.read_bytes())
assert subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip()==M['base_HEAD']
plan=json.loads(read(M['complete_compiler_Source_plan']))
# Validate every original compiler operand and all17 proposals before first write.
for r in plan['files']:
 p=ROOT/r['path']
 if r['before_absent']:assert not p.exists()
 else:
  b=p.read_bytes();assert len(b)==r['before_bytes'] and hashlib.sha256(b).hexdigest()==r['before_sha256']
values=[]
for r in M['files']:
 b=read(r['proposed']);assert b==read(r['actual72']);values.append((ROOT/r['canonical_path'],b))
for p,b in values:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for r in plan['files']:
 b=(ROOT/r['path']).read_bytes();assert len(b)==r['planned_bytes'] and hashlib.sha256(b).hexdigest()==r['planned_sha256']
print(json.dumps(dict(applied_paths=len(values),compiler_inputs_verified=len(plan['files']),Git_mutated=False,Cargo_or_tests_executed=False)))
'''
applyp.write_text(applycode,encoding='utf8',newline='\n')
result=meta('manifest.json',dict(schema='selective-canonical72-report-core-prepared.v1',status='PREPARED_ONLY_ROOT_APPLICATION_AND_CANONICAL_ALLTARGETS_CHECK_PENDING',base_HEAD=head,actual72=ref(mp),actual72_independent_mechanical_command_review=ref(reviewp),actual72_independent_all_five_physical_prefix_review=ref(supp),packets=[ref(writerp)]+M['packets'],independent_semantic_peers=peers,prior_canonical06_existing27_receipt=ref(priorp),canonical_before_full_Source_snapshot=prior['source_snapshot'],files=rows,complete_compiler_Source_plan=planref,apply_script=ref(applyp),readonly_Git=gits,counts=dict(selected_paths=17,new_Rust=12,existing_Rust=5,literal_applications=34,canonical_before_inputs=4428,planned_inputs=4440,planned_Rust=4427,planned_inputs_exact_actual72=4432),excluded_diagnostic_paths=sorted(excluded),existing_diagnostic_paths_whole_canonical_unchanged=sorted(differences),absent_diagnostic_path=sorted(actual72-planned),canonical_pipeline_whole_unchanged=True,readonly_predefined_observer_not_promoted=True,new_test_bodies=0,normalizations=0,reviewer_applied_canonical=False,reviewer_executed_Cargo_tests_Native=False,Git_mutated=False,whole_Source_run_or_export_PASS=False,numerical_gate_claim=False,qualifications=['Exact17 core union only; all9 diagnostic paths including isolated pipeline dispatch/enable and readonly predefined persistence stay excluded. Canonical normal pipeline remains previous whole bytes.','Actual72 compiler/traversal,13 finite BEPS reported tables and independent3007 exact physical prefix lines/9 explicit metadata differences are bound. This is not a completed Source endrun or Native internal numeric gate.','Canonical all-targets check is still required after Root applies. No blanket27-test repeat requirement is introduced by this prepared artifact; previous existing-test evidence remains scoped to its actual commands.','All12 new files and5 existing proposals are byte-exact actual72. All4440 planned compiler inputs are checked; the sole held diagnostic new file is absent and eight diagnostic existing files retain canonical bytes.'],author_Source=ref(Path(__file__))))
print(json.dumps(result))

"""Seal finite pre-PurchasedAir orchestration on committed/actual23 only."""
from pathlib import Path
import ast, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
N=R/'.reference/energyplus-src/26.1.0'
P='crates/ep_runtime/src/heat_balance/'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
HEAD='f1f40fc84f2a8bfa5f048600cf4880e7ccc53e68'
O=D/'source-zone-equipment-orchestration-held-Peer-24'

def ref(p):
    b=p.read_bytes(); return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def check(row):
    p=R/row['path']; got=ref(p)
    assert got['sha256']==row['sha256'] and got['bytes']==row.get('bytes',got['bytes']),row
    return p
def load(row): return json.loads(check(row).read_bytes())
def put(name,data):
    p=O/name; assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return ref(p)
def doc(name,value): return put(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def git(p): return subprocess.check_output(['git','show',HEAD+':'+p],cwd=R)

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=R,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=R)
root_ref=ref(D/'Root-source-zone-equipment-initialization-actual-review-23/review.json')
assert root_ref['sha256']=='006c4919f095f7108979f2c026f967ccc1c10c2a95b1e030951555ff393b0625'
root=load(root_ref);assert root['accepted'] and not root['findings']
assert root['B_frontier']=='GetHeatBalanceInput: actual controlled Config.ZoneExh3665'
B_ref,A_ref=root['actual_B'],root['actual_A24'];B,A=load(B_ref),load(A_ref)
assert B['exit_code']==6 and A['exit_code']==0 and B['launch_error'] is None and A['launch_error'] is None
assert B['source_bytes_match_before_and_after'] and A['source_bytes_match_before_and_after']
assert B['source_snapshot']==A['source_snapshot']
snapshot_ref=B['source_snapshot'];snapshot=load(snapshot_ref)
observed={row['historical_path']:row for row in snapshot['files']}
assert len(observed)==len(snapshot['files'])==4491
assert sum(p.endswith('.rs') for p in observed)==4478
parent_ref=root['producer'];parent=load(parent_ref)
assert parent_ref['sha256']=='2885f377e5978641e8343f455776a45598a5f28b0950f93a28b94066071ef9e3'
parent_plan_ref=root['complete_compiler_plan'];parent_plan=load(parent_plan_ref)
parents={row['path']:row for row in parent_plan['entries']};assert set(parents)==set(observed)
for p,row in parents.items():
    b=check(row['source']).read_bytes()
    assert hashlib.sha256(b).hexdigest()==row['final_sha256'] and len(b)==row['final_bytes']
    assert b==check(observed[p]['archive']).read_bytes()==(R/p).read_bytes(),p
paths=set((R/'crates').rglob('*.rs'))|set((R/'crates').rglob('Cargo.toml'))
for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']:
    if (R/p).is_file():paths.add(R/p)
assert {p.relative_to(R).as_posix() for p in paths}==set(observed)
assert P+'source_output_registration/report_diagnostics.rs' not in observed
assert not (R/(P+'source_output_registration/report_diagnostics.rs')).exists()
draft_ref=ref(D/'source-zone-equipment-orchestration-draft-Peer-24/draft.json')
assert draft_ref['sha256']=='62f34fe6d5328bee5491afc858e100473c4ee0ae1b30924094d9b14430197ca5'
draft=load(draft_ref)
assert draft['parent']==parent_ref and draft['base_HEAD']==HEAD
assert len(draft['files'])==4 and draft['existing_Source_files']==3 and draft['new_Source_files']==1
assert not O.exists();O.mkdir()
node=next(x for x in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body
    if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<own-literal>','exec'),ns)
files=[];texts={}
for i,row in enumerate(draft['files'],1):
    p=row['canonical_path'];old,new=check(row['before']).read_bytes(),check(row['proposed']).read_bytes()
    if row['before_absent']:
        assert old==b'' and p not in observed and not (R/p).exists()
        assert subprocess.run(['git','cat-file','-e',HEAD+':'+p],cwd=R,capture_output=True).returncode!=0
    else:
        assert old==check(observed[p]['archive']).read_bytes()==(R/p).read_bytes()==git(p)
    f,inv=check(row['forward_diff']).read_bytes(),check(row['inverse_diff']).read_bytes()
    assert ns['apply_literal'](old,f)==new and ns['apply_literal'](new,inv)==old
    parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],
        input=new,capture_output=True,cwd=R)
    assert parsed.returncode==0 and not parsed.stderr
    added=''.join(line[1:] for line in f.decode().splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
    assert not re.search(r'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)!|#\[test\]|\.runtime[/\\]',added)
    texts[p]=new.decode()
    files.append({'canonical_path':p,'before_absent':row['before_absent'],'before':put('before/'+p,old),
        'proposed':put('proposed/'+p,new),'literal_inverse':put('literal-inverse/'+p,old),
        'forward_diff':put(f'diffs/{i:02d}-forward.diff',f),'inverse_diff':put(f'diffs/{i:02d}-inverse.diff',inv),
        'actual23_archive':observed[p]['archive'] if p in observed else None,
        'committed23_Git_and_actual23_and_live_before_whole_equal':not row['before_absent'],
        'Source_only_parse':{'exit_code':0,'stdout':put(f'parse/{i:02d}.stdout',parsed.stdout),'stderr':put(f'parse/{i:02d}.stderr',parsed.stderr)}})
selected={row['canonical_path']:row for row in files}
patterns=['SelectedSizingManager {','SelectedHvacGlobals {','SourceHvacOwners {','priority_simulation_order',
    'sequenced_output_required','sequenced_output_to_heating_sp','sequenced_output_to_cooling_sp','sequenced_output_to_humid_sp','sequenced_output_to_dehumid_sp',
    'turn_fans_off','unbalanced_exhaust_mass_flow','balanced_exhaust_mass_flow','plenum_induced_mass_flow','data_cool_coil_capacity',
    'simulate_source_zone_equipment(','current_deadband_or_setback','source_current_schedule_value(']
entries=[];hits=[]
for p in sorted(set(observed)|set(selected)):
    source=selected[p]['proposed'] if p in selected else observed[p]['archive'];b=check(source).read_bytes()
    entries.append({'path':p,'final_sha256':source['sha256'],'final_bytes':len(b),'source':{**source,'bytes':len(b)},
        'origin':'selected24 genuine pre-PurchasedAir orchestration' if p in selected else 'whole exact actual23 archived parent'})
    if p.endswith('.rs'):
        for number,line in enumerate(b.decode().splitlines(),1):
            found=[pattern for pattern in patterns if pattern in line]
            if found:hits.append({'path':p,'line':number,'literal':line,'patterns':found})
assert len(entries)==4492 and sum(row['path'].endswith('.rs') for row in entries)==4479
for name,path in [('SelectedSizingManager {','selected_sizing.rs'),('SelectedHvacGlobals {','selected_simulation_startup.rs')]:
    assert {row['path'] for row in hits if name in row['patterns']}=={P+path}
assert sum('SourceHvacOwners {' in row['patterns'] for row in hits)==2
plan_ref=doc('complete-final-compiler-Source-plan.json',{'base_HEAD':HEAD,'parent_actual_snapshot':snapshot_ref,
    'inputs':4492,'Rust_sources':4479,'entries':entries,'Root_full_rehash_required':True})
api_ref=doc('whole-crates-concrete-API-inventory.json',{'before_inputs':4491,'before_Rust':4478,'final_inputs':4492,'final_Rust':4479,
    'all4491_parent_and4492_final_wholes_rehashed':True,'includes_all_crates_runtime_and_tests':True,'occurrences':hits,
    'new_struct_literal_callers_or_test_adapters':0,'SourceHvacOwners_constructor_count':2,
    'new_owner_or_duplicated_Node_state':False,'same_existing_six_demand_arrays_and_live_schedule_owner':True})
contexts=[]
for name in ['ordinary_equipment.rs','ordinary_equipment/source_equipment_types.rs','ordinary_equipment/source_controlled_equipment.rs',
    'ordinary_air_heat_balance/predictor_corrector.rs','ordinary_air_heat_balance/predictor_corrector/demand.rs',
    'ordinary_air_heat_balance/predictor_corrector/subsystems.rs','ordinary_hvac_manager/owners.rs',
    'selected_schedule_manager/report.rs','selected_heat_balance_space_controls.rs','selected_heat_balance_input/zone/storage.rs',
    'ordinary_heat_balance_initialization/first_call.rs','source_initialization/run_prefix.rs']:
    p=P+name;b=check(observed[p]['archive']).read_bytes()
    assert p not in selected and b==git(p)==(R/p).read_bytes()
    contexts.append({'canonical_path':p,'whole':put('context/'+p,b),'actual23_archive':observed[p]['archive'],
        'committed23_Git_and_actual23_and_live_whole_equal':True})
authorities={
    'src/EnergyPlus/ZoneEquipmentManager.cc':[(3538,4193),(4195,4255),(4257,4388),(4390,4514),(4515,4715)],
    'src/EnergyPlus/ZoneEquipmentManager.hh':[(72,80),(270,280)],
    'src/EnergyPlus/DataZoneEquipment.hh':[(117,190),(400,448)],
    'src/EnergyPlus/DataZoneEquipment.cc':[(1807,1816)],
    'src/EnergyPlus/DataHVACGlobals.hh':[(507,532)],
    'src/EnergyPlus/DataSizing.hh':[(708,764),(1299,1307)],
    'src/EnergyPlus/DataZoneEnergyDemands.hh':[(70,144)],
    'src/EnergyPlus/EPVector.hh':[(54,108),(124,155)],
    'src/EnergyPlus/ScheduleManager.hh':[(243,270)],
    'src/EnergyPlus/PurchasedAirManager.cc':[(146,208)],
}
native=[];extents=[]
for p,ranges in authorities.items():
    b=subprocess.check_output(['git','show',PIN+':'+p],cwd=N)
    assert b==(N/p).read_bytes()
    native.append({'Native_path':p,'revision':PIN,'whole':put('Original-Git/'+p,b)})
    lines=b.splitlines(keepends=True)
    for first,last in ranges:
        assert first>0 and last>=first and last<=len(lines)
        extent=b''.join(lines[first-1:last])
        extents.append({'native_path':p,'first':first,'last':last,'utf8_sha256':hashlib.sha256(extent).hexdigest(),'literal':extent.decode()})
management=texts[P+'ordinary_equipment/management.rs']
old_management=check(next(row for row in files if row['canonical_path']==P+'ordinary_equipment/management.rs')['before']).read_bytes().decode()
assert management.split('    fn initialize_source_zone_equipment(',1)[1].split('    fn simulate_source_zone_equipment(',1)[0] == old_management.split('    fn initialize_source_zone_equipment(',1)[1].split('    fn simulate_source_zone_equipment(',1)[0]
assert management.split('    fn update_source_zone_equipment(',1)[1] == old_management.split('    fn update_source_zone_equipment(',1)[1]
tail='        o.sizing.current_zone_equipment_number = 0;\n'
assert management.split(tail,1)[1] == old_management.split(tail,1)[1]
helper=texts[P+'ordinary_equipment/management/output_required.rs']
assert 'order.swap(number, compared)' in helper and 'sort(' not in helper
assert helper.index('let heating = fraction(o, zone, equipment, true)?;') < helper.index('let cooling = fraction(o, zone, equipment, false)?;') < helper.index('let ratio = if e.base.total_output_required >= 0.0')
assert 'match equipment_type {' in management and 'actual PurchasedAirManager SimPurchasedAir3871' in management
contract_ref=doc('integration-contract.json',{
    'scope':'Actual23 reached controlled prelude through genuine SimPurchasedAir entry, not CP442 or post-callee response. Both A/None and positive B share original owners.',
    'controlled_order':['same AirHB NonAirSystemResponse0 thenSysDepZoneLoads0','same Config ZoneExh0,ZoneExhBalanced0,PlenumMassFlow0',
        'CurZoneEqNum actualControlledZoneNum','simulation&&!DoingSizing actualspaces: airtwozeros before Config IsControlled; Configthreezeros onlycontrolled',
        'InitSystemOutputRequired beforeactual ZoneEquipList(ControlledZoneNum) count','per-equipment fanon/offfalse,threeexhaust/plenumzeros',
        'actual PrioritySimOrder.EquipPtr','same three local outputs0','same DataCoolCoilCap0','actual FirstPass then18distinctsizingwrites',
        'actual priority equipType','ZoneEquipList(CurZoneEqNum) actual EquipIndex(EquipPtr)','actual type<=14 andpositiveCompNum availabilitycallee boundary',
        'actual optionalspace splitter predicate/firstcallee boundary','actual type12 SimPurchasedAir boundary withsame mutable equipment_indices cell'],
    'priority_order':['actual ZoneEquipList(ControlledZoneNum), notConfig.EquipListIndex','realallocated class rows; full6field prefix writes',
        'unusedupperrows: clearonlynames/type/pointer; retainbothpriorityfields','nestedstrict> swaps; RemainingOutputRequired<0 vs>=0; updatebothlocalpriorities'],
    'load_initialization':['12 actual remaining/unadjusted writes inNativeorder','trueResetSimOrder andspaceNum0 beforearrayoperations',
        'sameEPVector allocated Option flag; wholefills onactual uncontrolled/sizing orfirst Sequential/Uniform',
        'positive firstPLR FinalZoneSizing boundary; laterfirst3sensiblewrites thenactualductbranch then3moisturewrites thenactualductbranch',
        'sameCurDeadBandOrSetback=DeadBandOrSetback afterinitarrayoperations','actual doSpaceHeatBalance.current independentofsimulation flag'],
    'sequential_distribution':['actual IsControlled/ZoneSizing/firstiteration scheme guards','realPrioritySimOrder(1).EquipPtr',
        'bothliveSequentialHeatingFraction andCoolingFraction reads, inthatorder, beforeTotalOutputRequiredsign selection',
        'threeenergysequencedwrites','actualductsensibleboundary','threeenergyremainingwrites','threemoisturesequencedwrites',
        'actualductlatentboundary','threemoistureremainingwrites','zone thenactualspaces inretainedindexorder'],
    'allocation_authority':'No new array allocation. Reuses real class Array1D<SimulationOrder> with six actual ctor fields; six sequenced EPVector<Real64> allocations from corrected23 fill T{}. HeatingCapacity/CoolingCapacity are actual Array1D_int, unchanged. New4HVAC scalars andDataCoolCoilCap have explicit pinned Native ctor initializers.',
    'alias_and_lifetime':'Same mutable SourceHvacOwners borrows same real EquipmentConfig/EquipmentList/PrioritySimOrder, demand arrays, sizing, HVAC globals and ScheduleManager. Native const ZoneCompNum reads the real cell; the eventual PurchasedAir argument is the same mutable cell. No typed Node projection, shadow cache, replacement component-index cell or Native answer injection.',
    'limits':['Actual23 stops beforethisnewpath, so24isSource-onlyuntilRootCLI.',
        'SimPurchasedAir genuine GetInput/Init/Calc/Update/Report is unported, reachedcallee stays typed; no fabricatedzeroresponse or successful fullB claim.',
        'Positive cachedCompIndex must enter availabilitygetter on lateriterations; it is not forced0 or skippedbyready/countproxy.',
        'Positive unrepresented distribution/FinalZoneSizing/duct/space splitter/other equipment callees remain explicit; no postcallee/suffix writes moved beforethem.',
        'No new tests, tolerance/policy/gate changes, internalNativepairing, positiveNodeReporting/Reset execution, HELD18/20 activation.']})
assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=R)
manifest={'schema':'src06-held-cohesive-zone-equipment-orchestration.v1','status':'HELD Source only; compilation/actual24 pending','base_HEAD':HEAD,
    'actual23_review':root_ref,'actual23_snapshot':snapshot_ref,'actual23_B':B_ref,'actual23_A24':A_ref,'actual23_complete_plan':parent_plan_ref,
    'parent23_producer':parent_ref,'files':files,'existing_Source_files':3,'new_Source_files':1,'literal_applications':8,'Source_only_parses':4,
    'complete_final_compiler_Source_plan':plan_ref,'whole_crates_API_inventory':api_ref,'Native_commit':PIN,
    'Native_wholes':[{**ref(N/row['Native_path']),'whole_equals_git':True} for row in native],'frozen_Native_wholes':native,
    'Native_literal_extents':doc('Native-literal-extents.json',extents),'unchanged_contexts':contexts,'integration_contract':contract_ref,
    'unsealed_author_draft':draft_ref,'author_Source':draft['author_Source'],'sealer_Source':ref(Path(__file__)),
    'new_test_bodies':0,'Cargo_Native_or_tests_executed':False,'main_mutations':0,'FP_tolerance_or_gate_changes':False,
    'full_B_or_positive_Node_execution_claim':False}
print(json.dumps(doc('manifest.json',manifest)))

from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-zone-equipment-initialization-B-NOLIMIT-24H-command-Root-23/receipt.json','98b2b4aca3d078857596e688ef62e05491164cc4276b05bd17bc6b33beca3d6c'),
 'A24':('canonical-source-zone-equipment-initialization-A-24H-command-Root-23/receipt.json','6f1d4170c3540577585719b88dcac2e08f5cdc2f679f0f6d62add296ab16aec8'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-zone-equipment-orchestration-'+case+'-command-Root-24'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-zone-equipment-orchestration-'+case+'-Root-24/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

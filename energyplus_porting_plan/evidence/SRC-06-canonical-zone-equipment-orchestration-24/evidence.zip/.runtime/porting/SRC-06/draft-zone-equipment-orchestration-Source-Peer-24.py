"""Held coherent SimZoneEquipment pre-callee orchestration; no main/Cargo/tests."""
from pathlib import Path
import ast, difflib, hashlib, json, re, subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'source-zone-equipment-orchestration-draft-Peer-24'

def ref(p):
    b=p.read_bytes(); return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def check(row):
    p=R/row['path']; got=ref(p)
    assert got['sha256']==row['sha256'] and got['bytes']==row.get('bytes',got['bytes']), row
    return p
def put(name,data):
    p=O/name; assert not p.exists(); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data); return ref(p)
def doc(name,value): return put(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def swap(s,a,b):
    assert s.count(a)==1,a[:100]
    return s.replace(a,b)

assert not (O/'draft.json').exists()
parent_ref=ref(D/'source-zone-equipment-initialization-held-Peer-23-02/manifest.json')
assert parent_ref['sha256']=='2885f377e5978641e8343f455776a45598a5f28b0950f93a28b94066071ef9e3'
parent=json.loads(check(parent_ref).read_bytes())
plan=json.loads(check(parent['complete_final_compiler_Source_plan']).read_bytes())
entries={row['path']:row for row in plan['entries']}
paths=[P+x for x in ['ordinary_equipment/management.rs',
    'ordinary_equipment/management/output_required.rs','selected_simulation_startup.rs','selected_sizing.rs']]
before={p:check(entries[p]['source']).read_bytes() if p in entries else b'' for p in paths}
assert all(data==(R/p).read_bytes() for p,data in before.items() if p in entries)
assert sum(p not in entries for p in paths)==1
texts={p:data.decode() for p,data in before.items()}
p=paths[0]
texts[p]=swap(texts[p],'mod modules;\n','mod modules;\nmod output_required;\n')
texts[p]=swap(texts[p],'''            return Err(Error::Unavailable("actual controlled Config.ZoneExh3665"));
''','''            {
                let config = o.equipment.zone_config.as_mut()
                    .and_then(|rows| rows.get_mut(at(number).ok()?))
                    .ok_or(Error::Unavailable("actual controlled ZoneEquipConfig3664"))?;
                config.zone_exhaust = 0.0;
                config.zone_exhaust_balanced = 0.0;
                config.plenum_mass_flow = 0.0;
            }
            o.sizing.current_zone_equipment_number = number;
            if o.space_controls.simulation && !o.globals.doing_sizing {
                let count = o.zones.zones.as_ref().and_then(|rows| rows.get(at(number).ok()?))
                    .ok_or(Error::Unavailable("actual controlled Zone spaceIndexes3670"))?.space_indexes.len();
                for i in 0..count {
                    let space = o.zones.zones.as_ref().and_then(|rows| rows.get(at(number).ok()?))
                        .and_then(|zone| zone.space_indexes.get(i)).copied()
                        .ok_or(Error::Unavailable("actual controlled Space ordinal3670"))?;
                    let air = &mut o.air.spaces.as_mut().and_then(|rows| rows.get_mut(at(space).ok()?))
                        .ok_or(Error::Unavailable("actual controlled Space AirHB3671"))?.air;
                    air.non_air_system_response = 0.0;
                    air.sys_dep_zone_loads = 0.0;
                    let config = o.equipment.space_config.as_mut().and_then(|rows| rows.get_mut(at(space).ok()?))
                        .ok_or(Error::Unavailable("actual spaceEquipConfig3674"))?;
                    if !config.is_controlled { continue; }
                    config.zone_exhaust = 0.0;
                    config.zone_exhaust_balanced = 0.0;
                    config.plenum_mass_flow = 0.0;
                }
            }
            output_required::initialize(o, number, first_hvac_iteration)?;
            let count = o.equipment.equipment_lists.as_ref().and_then(|rows| rows.get(at(number).ok()?))
                .ok_or(Error::Unavailable("actual SimZoneEquipment ZoneEquipList3688"))?.number_of_equipment_types;
            for equipment_number in 1..=count {
                o.hvac.turn_fans_on = false;
                o.hvac.turn_fans_off = false;
                o.hvac.unbalanced_exhaust_mass_flow = 0.0;
                o.hvac.balanced_exhaust_mass_flow = 0.0;
                o.hvac.plenum_induced_mass_flow = 0.0;
                let equipment_pointer = o.equipment.priority_simulation_order.as_ref()
                    .and_then(|rows| rows.get(equipment_number - 1))
                    .ok_or(Error::Unavailable("actual PrioritySimOrder EquipPtr3697"))?.equipment_pointer;
                let _system_output_provided = 0.0;
                let _latent_output_provided = 0.0;
                let _non_air_system_output = 0.0;
                o.sizing.data_cool_coil_capacity = 0.0;
                if o.equipment.first_pass_zone_equipment_flag {
                    let sizing = o.sizing.zone_equipment_sizing.as_mut()
                        .and_then(|rows| rows.get_mut(at(number).ok()?))
                        .ok_or(Error::Unavailable("actual first-pass ZoneEqSizing3704"))?;
                    sizing.air__vol__flow = 0.0;
                    sizing.max_hw_vol__flow = 0.0;
                    sizing.max_cw_vol__flow = 0.0;
                    sizing.oa_vol__flow = 0.0;
                    sizing.des__cooling__load = 0.0;
                    sizing.des__heating__load = 0.0;
                    sizing.cooling__air__vol__flow = 0.0;
                    sizing.heating__air__vol__flow = 0.0;
                    sizing.system__air__vol__flow = 0.0;
                    sizing.air__flow = false;
                    sizing.cooling__air__flow = false;
                    sizing.heating__air__flow = false;
                    sizing.system__air__flow = false;
                    sizing.capacity = false;
                    sizing.cooling__capacity = false;
                    sizing.heating__capacity = false;
                    sizing.system__capacity = false;
                    sizing.design__size__from__parent = false;
                }
                let equipment_type = o.equipment.priority_simulation_order.as_ref()
                    .and_then(|rows| rows.get(equipment_number - 1))
                    .ok_or(Error::Unavailable("actual PrioritySimOrder equipType3725"))?.equipment_type;
                let list = o.equipment.equipment_lists.as_ref()
                    .and_then(|rows| rows.get(at(o.sizing.current_zone_equipment_number).ok()?))
                    .ok_or(Error::Unavailable("actual current ZoneEquipList3727"))?;
                let component_number = list.equipment_indices.as_ref()
                    .and_then(|rows| rows.get(at(equipment_pointer).ok()?)).copied()
                    .ok_or(Error::Unavailable("actual ZoneEquipList EquipIndex3729"))?;
                let mut valid_availability_component = false;
                if equipment_type <= 14 { valid_availability_component = true; }
                if component_number > 0 && valid_availability_component {
                    // Genuine positive cached CompIndex enters this call on later
                    // iterations; no perpetual first-call/zero-count shortcut.
                    return Err(Error::Unavailable("actual GetZoneEqAvailabilityManager3739"));
                }
                if o.space_controls.simulation && !o.globals.doing_sizing {
                    let splitter = list.equipment_splitter_indices.as_ref()
                        .and_then(|rows| rows.get(at(equipment_pointer).ok()?)).copied()
                        .ok_or(Error::Unavailable("actual zoneEquipSplitterIndex3751"))?;
                    if splitter > -1 {
                        return Err(Error::Unavailable("actual zoneEquipSplitter adjustLoads3753"));
                    }
                }
                match equipment_type {
                    12 => {
                        let _name = &o.equipment.priority_simulation_order.as_ref()
                            .and_then(|rows| rows.get(equipment_number - 1))
                            .ok_or(Error::Unavailable("actual PurchasedAir priority name3872"))?.equipment_name;
                        let _same_component_index = o.equipment.equipment_lists.as_mut()
                            .and_then(|rows| rows.get_mut(at(o.sizing.current_zone_equipment_number).ok()?))
                            .and_then(|list| list.equipment_indices.as_mut())
                            .and_then(|rows| rows.get_mut(at(equipment_pointer).ok()?))
                            .ok_or(Error::Unavailable("actual PurchasedAir same EquipIndex3877"))?;
                        return Err(Error::Unavailable("actual PurchasedAirManager SimPurchasedAir3871"));
                    }
                    // Current real input admits only PurchasedAir. Any later
                    // represented positive type must enter its actual callee,
                    // never produce a fabricated zero equipment response.
                    _ => return Err(Error::Unavailable("actual SimZoneEquipment positive equipment callee switch3747")),
                }
            }
''')
texts[paths[1]]=(O/'output_required.rs').read_text(encoding='utf8')
p=paths[2]
texts[p]=swap(texts[p],'    pub(crate) turn_fans_on: bool,\n','''    pub(crate) turn_fans_on: bool,
    /// Actual DataHVACGlobals.hh517-521 constructor scalars, same owner.
    pub(crate) turn_fans_off: bool,
    pub(crate) unbalanced_exhaust_mass_flow: f64,
    pub(crate) balanced_exhaust_mass_flow: f64,
    pub(crate) plenum_induced_mass_flow: f64,
''')
texts[p]=swap(texts[p],'            turn_fans_on: false,\n','''            turn_fans_on: false,
            turn_fans_off: false,
            unbalanced_exhaust_mass_flow: 0.0,
            balanced_exhaust_mass_flow: 0.0,
            plenum_induced_mass_flow: 0.0,
''')
p=paths[3]
texts[p]=swap(texts[p],'    pub(crate) current_terminal_unit_sizing_number: i32,\n','''    pub(crate) current_terminal_unit_sizing_number: i32,
    /// Actual DataSizing.hh1304 constructor, reset by SimZoneEquipment3701.
    pub(crate) data_cool_coil_capacity: f64,
''')
texts[p]=swap(texts[p],'            current_terminal_unit_sizing_number: 0,\n','''            current_terminal_unit_sizing_number: 0,
            data_cool_coil_capacity: 0.0,
''')
node=next(x for x in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body
    if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<own-literal>','exec'),ns)
files=[]
for number,p in enumerate(paths,1):
    proposed=texts[p].encode(); previous=before[p]
    b=put('before/'+p,previous); q=put('proposed/'+p,proposed)
    diffs={}
    for kind,a,z in [('forward',previous,proposed),('inverse',proposed,previous)]:
        delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),z.decode().splitlines(keepends=True),fromfile=p,tofile=p)).encode()
        assert ns['apply_literal'](a,delta)==z
        diffs[kind+'_diff']=put(f'diffs/{number:02d}-{kind}.diff',delta)
    parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],
        input=proposed,capture_output=True,cwd=R)
    stdout=put(f'parse/{number:02d}.stdout',parsed.stdout);stderr=put(f'parse/{number:02d}.stderr',parsed.stderr)
    assert parsed.returncode==0,(p,parsed.stderr.decode())
    files.append({'canonical_path':p,'before_absent':p not in entries,'before':b,'proposed':q,**diffs,
        'Source_only_parse':{'exit_code':parsed.returncode,'stdout':stdout,'stderr':stderr}})
result=doc('draft.json',{'status':'UNSEALED_SOURCE_DRAFT_WAITING_FINAL_PARENT_CUSTODY_PEER',
    'parent':parent_ref,'base_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),
    'files':files,'selected_Source_files':len(files),'existing_Source_files':3,'new_Source_files':1,
    'Source_only_parse_passes':len(files),'literal_applications':2*len(files),
    'scope':'Genuine SimZoneEquipment controlled prelude/order/init/sequential distribution and first-pass sizing through actual SimPurchasedAir entry. No CP442 facade or fake equipment response; later availability, optional space/duct/nonsequential and other subsystem callees preserve explicit boundaries.',
    'not_claimed':['successful actual24','positive PurchasedAir input/calc/update/report','post-callee output updates','positive Node reporting/reset execution','Native internal unit equivalence'],
    'Cargo_main_Git_tests_Native_mutated_or_executed':False,'author_Source':ref(Path(__file__))})
print(json.dumps(result))

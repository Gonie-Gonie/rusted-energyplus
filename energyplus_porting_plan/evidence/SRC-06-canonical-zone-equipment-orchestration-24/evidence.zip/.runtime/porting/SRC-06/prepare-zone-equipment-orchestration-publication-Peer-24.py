"""Prepare held publication24 metadata only; never execute the publisher."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, re

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
O=D/'zone-equipment-orchestration-publication-prepared-Peer-24'
OLD=D/'publish-zone-equipment-initialization-checkpoint-Peer-23.py'
NEW=D/'publish-zone-equipment-orchestration-checkpoint-Peer-24.py'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(row):
    p=R/row['path'];got=ref(p)
    assert got['sha256']==row['sha256'] and got['bytes']==row.get('bytes',row.get('size_bytes',got['bytes'])),row
    return p
def write(p,value):p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
args_parser=argparse.ArgumentParser()
args_parser.add_argument('--peer-path',required=True)
args_parser.add_argument('--peer-sha',required=True)
args_parser.add_argument('--application-sha',required=True)
args=args_parser.parse_args()
assert not O.exists() and not NEW.exists()
parent_ref=ref(OLD)
assert parent_ref['sha256']=='c897e4ee07c77633797d73b16c2f2c28bcc8c820169e30e4cfee36378e98382e'
producer_ref=ref(D/'source-zone-equipment-orchestration-held-Peer-24/manifest.json')
assert producer_ref['sha256']=='3128a1953cb042a2c07cb5c42fdfd2a040cb176b606ba13c22144b77af99178d'
producer=json.loads(checked(producer_ref).read_bytes())
application_ref=ref(D/'Root-zone-equipment-orchestration-application-24/receipt.json')
assert application_ref['sha256']==args.application_sha
application=json.loads(checked(application_ref).read_bytes())
assert application['accepted'] and not application['findings'] and application['producer']==producer_ref
application_source_ref=ref(checked(application['author_Source']))
assert application_source_ref['path']=='.runtime/porting/SRC-06/apply-zone-equipment-orchestration-Root-24.py'
peer_ref=ref(R/args.peer_path)
assert peer_ref['sha256']==args.peer_sha
peer=json.loads(checked(peer_ref).read_bytes())
assert peer['accepted'] and not peer['findings']
old=OLD.read_bytes().decode();text=old
replacements=[
    ('checkpoint23','checkpoint24'),
    ('zone-equipment-initialization-publication-prepared-Peer-23','zone-equipment-orchestration-publication-prepared-Peer-24'),
    ('SRC-06-canonical-zone-equipment-initialization-23','SRC-06-canonical-zone-equipment-orchestration-24'),
    ('zone-equipment-initialization-publication-readback-Peer-23','zone-equipment-orchestration-publication-readback-Peer-24'),
    ('c5a6242d20a2c55e33948b5a11fb6ebae39dbe20','f1f40fc84f2a8bfa5f048600cf4880e7ccc53e68'),
    ("len(producer['files']) == 5 and producer['existing_Source_files'] == 4 and producer['new_Source_files'] == 1", "len(producer['files']) == 4 and producer['existing_Source_files'] == 3 and producer['new_Source_files'] == 1"),
    ('4491','4492'),('4478','4479'),
    ('Root-source-zone-equipment-initialization-actual-review-23','Root-source-zone-equipment-orchestration-actual-review-24'),
    ('selected5_final_sources_exact','selected4_final_sources_exact'),
    ('canonical-source-zone-equipment-initialization-B-NOLIMIT-24H-Root-23','canonical-source-zone-equipment-orchestration-B-NOLIMIT-24H-Root-24'),
    ('canonical-source-zone-equipment-initialization-A-24H-Root-23','canonical-source-zone-equipment-orchestration-A-24H-Root-24'),
    ('canonical23-finite','canonical24-finite'),
    ('5 coherent zone equipment initialization Sources','4 coherent zone equipment orchestration Sources'),
    ('src06-canonical-zone-equipment-initialization.v1','src06-canonical-zone-equipment-orchestration.v1'),
    ('Genuine Source zone equipment initialization','Genuine Source zone equipment orchestration'),
    ('positive zone equipment initialization Native state equivalence','positive zone equipment orchestration Native state equivalence'),
    ('canonical_zone_equipment_initialization_23','canonical_zone_equipment_orchestration_24'),
    ('accepted22','accepted23'),('equal22','equal23'),
    ('[Source 구역 설비 초기화 검증]','[Source 구역 설비 시뮬레이션 진입 검증]'),
]
for before,after in replacements:
    assert before in text,before
    text=text.replace(before,after)
assert 'equal22' not in text and 'accepted22' not in text
assert 'Root-source-zone-equipment-initialization-actual-review-23' not in text
assert 'canonical_zone_equipment_initialization_23' not in text
ast.parse(text);assert '\ufffd' not in text
NEW.write_bytes(text.encode())
inputs={}
def add(row):
    p=checked(row);got=ref(p)
    assert p.suffix.lower()!='.zip'
    assert not any(token in got['path'] for token in ['controlled-air-native','source-controlled-zone-numerical-draft','source-CalcMoreNodeInfo-draft','purchased-air-owner-input-readonly-plan'])
    assert got['path'] not in inputs or inputs[got['path']]==got
    inputs[got['path']]=got
add(producer_ref)
for key in ['complete_final_compiler_Source_plan','whole_crates_API_inventory','integration_contract','Native_literal_extents','author_Source','sealer_Source']:add(producer[key])
for row in producer['Native_wholes']:add(row)
for row in producer['unchanged_contexts']:add(row['whole'])
for row in producer['files']:
    for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(row[key])
    for key in ['stdout','stderr']:add(row['Source_only_parse'][key])
previous=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-zone-equipment-initialization-23/summary.json')
for row in [previous,peer_ref,application_ref,application_source_ref,ref(Path(__file__))]:add(row)
docs={
    'CHECKLIST.md':'설비 우선순위와 부하 배분을 실제 실행 경로에 연결했다. B의 다음 경계와 A24 회귀 검증은 요약 자료에 기록한다.',
    'STATE_CONTRACTS.md':'기존 설비 목록·수요 배열·스케줄 상태를 공유하고, 실제 분기 순서대로 우선순위와 최초 크기 산정 상태를 갱신한다.',
    'cards/SRC-06.md':'B의 실제 미완료 경계는 `{{actual_B_frontier}}`이다. IdealLoads 본체와 B 전체 완료를 주장하지 않는다.',
}
assert len(set(docs.values()))==3
for value in docs.values():
    assert '?' not in value and '\ufffd' not in value and value.encode().decode()==value
template={
    'schema':'src06-held-canonical24-publication-template.v1','status':'HELD_FOR_ROOT_REVIEW_ACTUAL_AND_PEER_HASHES_REQUIRED',
    'base_HEAD':producer['base_HEAD'],'producer':producer_ref,'complete_plan':producer['complete_final_compiler_Source_plan'],
    'previous_checkpoint':previous,'publisher_Source':ref(NEW),'publisher_parent_Source':parent_ref,
    'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-zone-equipment-orchestration-actual-review-24/review.json',
    'Root_application':application_ref,'Root_application_Source':application_source_ref,'accepted_independent_peer':peer_ref,
    'pending_Root_custody':{'actual_review_sha256':'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source':'REQUIRED_FROM_ACCEPTED_actual.author_Source',
        'launcher_Source':'.runtime/porting/SRC-06/launch-zone-equipment-orchestration-Root-24.py (authenticated from accepted actual.launcher_Source at publish)',
        'B_CLI':'.runtime/porting/SRC-06/canonical-source-zone-equipment-orchestration-B-NOLIMIT-24H-command-Root-24/receipt.json',
        'A24_CLI':'.runtime/porting/SRC-06/canonical-source-zone-equipment-orchestration-A-24H-command-Root-24/receipt.json'},
    'Root_custody_at_publish':'Accepted actual.application -> pinned application24 receipt and author_Source; actual.author_Source -> checker; actual.launcher_Source -> launcher. All four directly byte-checked and archived, following accepted23 algorithm.',
    'summary_template':{'A':'14/54','B':'14/64','changed_Rust_sources':4,'existing_Rust_sources':3,'new_Rust_sources':1,
        'new_test_functions':0,'actual_test_bodies_executed':0,
        'focused_validation_policy':'Two actual CLI runs B then A24. No unrelated test-profile rerun or habitual alltargets check.',
        'scope':'Genuine controlled SimZoneEquipment prefix, full first-pass18 sizing resets, six-field priority order and actual sequential demand initialization/distribution with both live schedule reads. Same retained owners; genuine PurchasedAir callee stays unsupported, with no CP442 facade or fabricated post-callee equipment response.',
        'full_B_or_finite15_completion_claim':False,'Native_harness_runtime_or_unit_equivalence_claim':False,'gate_changes':False,'policy_changes':False},
    'doc_appends':docs,'finite_archive_inputs':[row for _,row in sorted(inputs.items())],
    'finite_archive_input_count':len(inputs),'finite_archive_input_bytes':sum(row['bytes'] for row in inputs.values()),
    'publisher_executed':False,'canonical_docs_mutations':False,'Cargo_tests_Native_executed':False,'gate_changes':False,
}
O.mkdir();template_path=O/'publication-template.json';write(template_path,template)
node=next(x for x in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<own-literal>','exec'),ns)
diffs={}
for kind,a,b in [('forward',old.encode(),text.encode()),('inverse',text.encode(),old.encode())]:
    delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode()
    assert ns['apply_literal'](a,delta)==b
    p=O/(kind+'.diff');p.write_bytes(delta);diffs[kind]=ref(p)
bridge_path=O/'publisher-parent-bridge.json'
write(bridge_path,{'parent':parent_ref,'successor':ref(NEW),'literal_applications':2,'changes':diffs,
    'scope':'Checkpoint/path/four-source4492/proof23 labels, base commit and UTF8 link-title metadata only. Complete accepted23 archive/docs/SRC06-key algorithm unchanged.',
    'UTF8_Korean_appends_validated':True,'publisher_executed':False,'public_or_main_mutations':False})
print(json.dumps({'template':ref(template_path),'publisher':ref(NEW),'parent_bridge':ref(bridge_path)}))

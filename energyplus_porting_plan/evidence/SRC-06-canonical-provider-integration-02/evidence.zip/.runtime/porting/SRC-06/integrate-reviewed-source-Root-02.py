"""Promote the reviewed report/endrun-library union after bounded existing QA."""
from pathlib import Path
import hashlib,json,subprocess,re,zipfile
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06'
WORK=BASE/'ordinary-provider-assembly-Root-62/workspace'
OUT=BASE/'reviewed-source-promotion-Root-02'
PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-provider-integration-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 p=base/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b)));return b
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert not OUT.exists() and not PUBLIC.exists() and not git('status','--porcelain=v1','-z')
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip()=='41c68bef4d7bc00529b34a1f148507c72bbbcbce'
peer=BASE/'Audit-ordinary-provider-union62-Source-review-01/review.json';review=json.loads(peer.read_bytes());assert review['status'].startswith('ACCEPTED')
actual=[];snapshots=[];payload={}
def add(p):
 p=p.resolve();b=p.read_bytes();key=p.relative_to(ROOT).as_posix();assert key not in payload or payload[key]==b;payload[key]=b;return ref(p)
for folder in ['provider-assembly-typecheck-command-62','provider-assembly-existing-arbitrary-run-tests-62-8MiB']:
 p=WORK/'.runtime/porting/SRC-06'/folder/'receipt.json';r=json.loads(p.read_bytes());assert r['exit_code']==0 and r['source_bytes_match_before_and_after'];actual.append(add(p))
 for key in ['stdout','stderr','source_snapshot']:
  read(r[key],WORK);add(WORK/r[key]['path'])
 snapshots.append(json.loads(read(r['source_snapshot'],WORK)))
 if 'arbitrary-run' in folder:
  s=read(r['stdout'],WORK).decode('utf8');assert '"RUST_MIN_STACK": "8388608"' in s;assert 'test result: ok. 27 passed; 0 failed; 0 ignored;' in s
assert snapshots[0]==snapshots[1] and not snapshots[0]['bytes_normalized']
rows=snapshots[0]['files'];assert len(rows)==4412
changes=[];whole=[]
for row in rows:
 path=row['historical_path'];b=read(row['archive'],WORK);assert (WORK/path).read_bytes()==b
 p=ROOT/path;a=p.read_bytes()if p.exists()else b''
 whole.append(dict(path=path,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
 if a==b:continue
 assert path.endswith('.rs') and p.resolve().is_relative_to(ROOT/'crates') and b'\r\n'not in b and a.count(b'#[test]')==b.count(b'#[test]')
 tree=git('ls-tree',head,'--',path);assert bool(tree)==p.exists();blob=git('show',head+':'+path)if tree else b'';assert blob==a
 changes.append(dict(path=path,before_sha256=hashlib.sha256(a).hexdigest(),before_bytes=len(a),before_Git_exists=bool(tree),after_sha256=hashlib.sha256(b).hexdigest(),after_bytes=len(b)))
assert len(changes)==31 and sum(not r['before_Git_exists']for r in changes)==11
OUT.mkdir()
for row in changes:
 p=ROOT/row['path'];a=p.read_bytes()if p.exists()else b'';assert hashlib.sha256(a).hexdigest()==row['before_sha256'];old=OUT/'before'/row['path'];old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(a)
 p.parent.mkdir(parents=True,exist_ok=True);b=(WORK/row['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['after_sha256'];p.write_bytes(b)
for row in whole:assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256']
v=dict(schema='src06-reviewed-report-and-endrun-library-source-promotion.v1',status='Exact reviewed Source bytes applied; commit/push pending',base_HEAD=head,parent_assembly=ref(BASE/'ordinary-provider-assembly-Root-62/manifest.json'),union_peer=ref(peer),actual_commands=actual,counts=dict(compiler_inputs=4412,changed=31,new=11,existing=20,existing_tests_passed=27,failed=0,ignored=0),changes=changes,whole_current_compiler_inputs=whole,pipeline_activation=False,new_test_bodies=0,full_workspace_suite_rerun=False,Native_numeric_verified=False,gate_changes=False,A='14/54',B='14/64',author_Source=ref(Path(__file__).resolve()))
p=OUT/'promotion.json';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n');add(p);add(Path(__file__).resolve());add(BASE/'run-with-explicit-test-stack-Root-01.py')
for n in [61,62]:add(BASE/f'ordinary-provider-assembly-Root-{n}/manifest.json')
reviews=[]
for name in ['Audit-ordinary-provider-union62-Source-review-01','Audit-ordinary-provider-union61-Source-review-01','Fix-ordinary-outdoor-node-type-export-Source-review-01','Reviewer-ordinary-produce-dictionaries-Source-review-03','Fix-ordinary-connection-exporters-Source-review-02','Audit-ordinary-through-primary-Source-review-01','Audit-ordinary-prelude-report-wiring-Source-review-01','Fix-ordinary-endrun-small-leaves-Source-review-02','Audit-ordinary-compute-tariff-prefix-Source-review-01','Audit-ordinary-endrun-owner-prerequisites-Source-review-01']:
 reviews.append(add(BASE/name/'review.json'))
for name in ['Audit-ordinary-provider-union61-Source-review-01','Audit-ordinary-provider-union62-Source-review-01']:add(BASE/name/'source-part.json')
assembly=json.loads((BASE/'ordinary-provider-assembly-Root-61/manifest.json').read_bytes())
for r in assembly['packets']:read(r);add(ROOT/r['path'])
add(BASE/'ordinary-outdoor-node-type-export-held-Reviewer-02/manifest.json')
failure=BASE/'ordinary-provider-assembly-Root-61/workspace/.runtime/porting/SRC-06/provider-assembly-typecheck-command-61/receipt.json';r=json.loads(failure.read_bytes());assert r['exit_code']==101;add(failure)
for key in ['stdout','stderr','source_snapshot']:read(r[key],BASE/'ordinary-provider-assembly-Root-61/workspace');add(BASE/'ordinary-provider-assembly-Root-61/workspace'/r[key]['path'])
PUBLIC.mkdir();z=PUBLIC/'evidence.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
 for key,b in sorted(payload.items()):
  item=zipfile.ZipInfo(key,date_time=(2026,10,17,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(item,b)
with zipfile.ZipFile(z)as archive:
 assert archive.testzip()is None and set(archive.namelist())==set(payload)
 for key,b in payload.items():assert archive.read(key)==b
summary=dict(schema='src06-canonical-provider-source-integration.v2',status='Reviewed report and finite endrun-library Source integrated; actual full production activation and Native parity pending',Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,counts=v['counts'],promotion=ref(OUT/'promotion.json'),actual_commands=actual,independent_reviews=reviews,parent_public_checkpoint=ref(ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-provider-integration-01/summary.json'),evidence_archive=ref(z),archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))for k,b in sorted(payload.items())],scope=['Three genuine connection exporters and RDD/MDD dictionaries wired into the existing pre-primary host.','One continuation over the retained original simulation locals, weather/session and reporting owners from kickoff268 through primary564.','Finite Plant/EMS/LCC endrun leaves, real tariff2665-2703 prefix, and actual weather-day and TRACK_AIRLOOP state prerequisites.','Narrow crate-private type reexport corrects the actual61 E0603 without changing implementation bodies.'],remaining=['Canonical production dispatcher activation, full endrun566-620 and result export.','Remaining positive owner/physical-I/O failure domains and same-input/state Native A/B numeric comparison.'],validation_scope='Whole all-target compilation and existing27 arbitrary-run tests at original8MiB; no new tests. Prior60 full4985 tests/2ignored retained as historical parent, not rerun or claimed for62. Diagnostic pipeline and later endrun-prefix packets are not part of this canonical Source checkpoint.',reconstruction='31 changed LF Rust files are held by canonical Git Source; archive binds exact4412 compiled inputs and actual logs/independent peers. Historical local payloads remain their existing custody; no new complete offline replay claim.',pipeline_activation=False,new_test_bodies=0,whole_Native_numeric_PASS=False,gate_changes=False,A='14/54',B='14/64',retained_whole_old_comparison=dict(mismatches=235456,required_unavailable_or_unpaired=2754),author_Source=ref(Path(__file__).resolve()))
p=PUBLIC/'summary.json';p.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8',newline='\n')
relative='evidence/SRC-06-canonical-provider-integration-02/summary.json'
paragraph='연결 보고서 3종과 RDD/MDD를 실제 pre-primary host에 연결하고, 같은 날씨·세션·원래 지역 상태를 사용하는 kickoff부터 primary까지의 호출 함수를 적용했습니다. 종료 단계의 작은 함수, 실제 요금 계산 진입 순서와 상태 필드도 포함합니다. 전체 타깃 컴파일 및 기존 실행 테스트 27개가 원래 8MiB 스택에서 통과했습니다. 새 테스트를 추가하지 않았고 전체 테스트는 반복하지 않았습니다. 실제 기본 파이프라인 전환·전체 종료 처리·Native 수치 비교는 미완료이며 A14/54·B14/64와 기존 FAIL을 유지합니다. 별도 실험용 파이프라인과 이후 종료 prefix는 이 적용에 포함하지 않습니다.'
for name in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']:
 q=ROOT/'energyplus_porting_plan'/name;s=q.read_text(encoding='utf8');assert 'canonical-provider-integration-02'not in s;link='../'+relative if name.startswith('cards/')else relative;s+='\n\n[보고서 및 종료 함수 Source 적용](%s). %s\n'%(link,paragraph);q.write_text(s,encoding='utf8',newline='\n')
q=ROOT/'energyplus_porting_plan/plan.json';before=json.loads(q.read_bytes());after=json.loads(q.read_bytes());task=next(x for x in after['tasks']if x['id']=='SRC-06');key='canonical_provider_source_integration_02';assert key not in task;task[key]=dict(path=p.relative_to(ROOT).as_posix(),sha256=ref(p)['sha256'],size_bytes=p.stat().st_size);check=json.loads(json.dumps(after));del next(x for x in check['tasks']if x['id']=='SRC-06')[key];assert check==before;q.write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(ref(p)));print(json.dumps(ref(z)));print(json.dumps(v['counts']))

"""Private44 Root-only adapters, derived literally from accepted42 adapters."""
from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'thermostat-predefined-adapters-prepared-Outer-44'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def sub(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
def common(s):return s.replace('fill-remaining-controlled','thermostat-predefined').replace('fill_remaining_controlled','thermostat_predefined').replace('Root-42','Root-44').replace('Outer-42-02','Outer-44').replace('ACTUAL42','ACTUAL44')
def main():
 assert not O.exists();parents=[];outputs=[]
 actualp=D/'Root-source-fill-remaining-controlled-actual-review-42/review.json';actual=json.loads(actualp.read_bytes());assert ref(actualp)['sha256']=='55bbcea3db9ce3fc60cfe41f06f00ee4ab479f3ea0a1ed75ac888decb7a236a2'
 ap=D/'apply-fill-remaining-controlled-Outer-42-02.py';s=ap.read_bytes().decode();assert ref(ap)['sha256']=='15d4294770c0fff0496db5cc5c6efa0e71bbb67073f3e8ecd5eb8e2866df8a6f';parents.append(ref(ap));a=common(s)
 a=sub(a,"assert pr['sha256']=='556aa46d0de69d17fb0855535705612381b6bad93d6bc97656c9cb5e7f5049b4';",'')
 a=sub(a,"assert len(selected)==3 and len(new)==0", "assert len(selected)==5 and len(new)==1")
 a=sub(a,"assert len(m['Native_authorities'])==6 and extent_count==8","assert len(m['Native_authorities'])==9 and extent_count==12")
 a=sub(a,"for k in ['accepted40_actual_review','prior_complete_compiler_Source_plan','whole4497_Rust_API_census','original_draft','actual41_to40_Equipment_production_bridge']:checked(m[k])","for k in ['accepted42_actual_review','prior_complete_compiler_Source_plan','whole4498_Rust_API_census','original_draft','actual_Native_provider_move_authority']:checked(m[k])\nmove=json.loads(checked(m['actual_Native_provider_move_authority']));checked(move['actual_build']);checked(move['compiler'])\nfor header in move['headers']:\n b=checked(header['whole']);assert b==checked(header['retained_copy'])\n for extent in header['extents']:assert b''.join(b.splitlines(keepends=True)[extent['first_line']-1:extent['last_line']])==checked(extent['source'])")
 a=sub(a,"parent_readback['inputs']==4510","parent_readback['compiler_inputs']==4510")
 a=sub(a,"['kind','inputs','Rust_sources']","['kind','compiler_inputs','Rust_sources']")
 a=sub(a,"len(rows)==4510 and sum(n.endswith('.rs') for n in rows)==4497","len(rows)==4511 and sum(n.endswith('.rs') for n in rows)==4498")
 start=a.index("peer_scope='");end=a.index("',complete_compiler_plan=",start)
 a=a[:start]+"peer_scope='Outer authored the coherent five-Source thermostat implementation and this Root-only adapter. Root independently fully reviewed all Source/Native/control/schedule/calendar/provider/context semantics in the bound formal peer. This application authenticates exact committed42 archive/live/Git plus the accepted four-existing/one-new literal join; no independent authorship is attributed to Outer'"+a[end+1:]
 a=sub(a,'final_inputs=4510,final_Rust_sources=4497,selected_Rust=3,new_Rust=0,literal_applications=6','final_inputs=4511,final_Rust_sources=4498,selected_Rust=5,new_Rust=1,literal_applications=10')
 start=a.index("semantic_review='");end=a.index("',author_Source=",start)
 a=a[:start]+"semantic_review='Full thermostat6558-6766 and true Schedule3862-3935 methods on retained owners: actual unique Num, original row/name/enum order, cool-before-heat, provider-authenticated move and lexical join, actual Latitude/leap/startweekday/DST and full week/day identity counts. No hardcoded case values/month/count, new test, property/cache/FPU/tolerance/gate change or unobserved B completion/equivalence claim.'"+a[end+1:]
 outputs.append((ap,D/'apply-thermostat-predefined-Outer-44.py',a))
 lp=D/'launch-fill-remaining-controlled-Outer-42-02.py';s=lp.read_bytes().decode();parents.append(ref(lp));a=common(s)
 start=a.index('PARENTS=');end=a.index('def checked',start)
 v={case:(actual[key]['path'].removeprefix('.runtime/porting/SRC-06/'),actual[key]['sha256'])for case,key in [('B','actual_B'),('A24','actual_A24')]}
 a=a[:start]+'PARENTS='+repr(v)+'\n\n'+a[end:]
 a=sub(a,"(plan['inputs'],plan['Rust_sources'])==(4510,4497)","(plan['inputs'],plan['Rust_sources'])==(4511,4498)")
 a=a.replace('Root42 actualCLI','Root44 actualCLI');outputs.append((lp,D/'launch-thermostat-predefined-Outer-44.py',a))
 cp=D/'check-source-fill-remaining-controlled-actual-Outer-42-02.py';s=cp.read_bytes().decode();parents.append(ref(cp));a=common(s)
 a=a.replace('len(rows)==4510','len(rows)==4511').replace("sum(n.endswith('.rs') for n in rows)==4497","sum(n.endswith('.rs') for n in rows)==4498").replace("len(app['selected'])==3","len(app['selected'])==5")
 a=sub(a,"old=D/'canonical-source-node-setpoint-endrun-A-24H-Root-41-02/output'","old=D/'canonical-source-fill-remaining-controlled-A-24H-Root-42/output'")
 start=a.index('ar,previous41=');end=a.index("pr,prior=auth(",start)
 a=a[:start]+"ar,previous42=auth('Root-source-fill-remaining-controlled-actual-review-42/review.json','55bbcea3db9ce3fc60cfe41f06f00ee4ab479f3ea0a1ed75ac888decb7a236a2');assert previous42['accepted'] and previous42['original_tolerance_RMSE_5352_proof_transferred'];draft=json.loads(checked(producer['original_draft']));assert draft['accepted42_actual_review']==ar\n"+a[end:]
 a=a.replace("'accepted41'","'accepted42'").replace('same4510_archived','same4511_archived').replace('selected3_final','selected5_final').replace('accepted41_full5352','accepted42_full5352').replace('equal41','equal42')
 a=sub(a,",accepted40_cohort_parent_review=producer['accepted40_actual_review']",'')
 start=a.index("limits='");end=a.index("',actual_production_CLI_invocations=",start)
 a=a[:start]+"limits='Five production Sources (four existing, one new) implement genuine thermostat setpoint and schedule summaries plus common Constant/Detailed day-value/count methods. Actual B outcome is recorded only after execution; Source620 completion is distinct from Native numerical/physical equivalence. A42 original5352 whole proof transfer and retained Native21 BND IO are separately bounded. No new tests, cache/property/FPU/tolerance changes or finite15/card completion claim.'"+a[end+1:]
 outputs.append((cp,D/'check-source-thermostat-predefined-actual-Outer-44.py',a))
 pp=D/'publish-fill-remaining-controlled-checkpoint-Outer-42-02.py';s=pp.read_bytes().decode();parents.append(ref(pp));a=common(s)
 a=a.replace('engine42','engine44').replace('actualtwo-file','actualfive-file').replace('final two-file','final five-file')
 a=sub(a,"len(producer['files'])==3 and producer['existing_Source_files']==3 and producer['new_Source_files']==0","len(producer['files'])==5 and producer['existing_Source_files']==4 and producer['new_Source_files']==1")
 a=sub(a,"(plan['inputs'],plan['Rust_sources'])==(4510,4497)","(plan['inputs'],plan['Rust_sources'])==(4511,4498)")
 a=a.replace('same4510_archived','same4511_archived').replace('selected3_final','selected5_final').replace('equal41','equal42').replace('accepted41_full5352','accepted42_full5352')
 a=sub(a,'len(index)==len(observed)==4510','len(index)==len(observed)==4511')
 start=a.index("scope='Three existing production");end=a.index("'))\n summary=",start)
 a=a[:start]+"scope='Four existing and one new production Sources, exactly two actual B/A24 CLI invocations, launcher-enforced canonical target/incremental0. No new/unrelated test or Native engine. Accepted42 A24 original5352 whole evidence is transferred only by strict comparison; all prior scientific cohorts remain historical and unexecuted by44. Actual B Source620, when observed, is a Source execution fact and not a Native-equivalence certificate. No recursive ZIP, raw Native observation, exe/core, annual payload or broad math claim.'"+a[end+1:]
 a=a.replace('src06-canonical42-','src06-canonical44-').replace('Genuine controlled FillRemaining predefined entries on the same retained owners; actual B result recorded','Genuine thermostat setpoint/schedule predefined reports and true retained Schedule day-value/count methods; actual B result recorded')
 a=a.replace('accepted41_proof','accepted42_proof').replace('Accepted41 A24 proof transfer.','Accepted42 A24 proof transfer.')
 a=a.replace('[Source42 controlled predefined entries]','[Source44 thermostat predefined reports]').replace('actual_test_bodies_executed_by42','actual_test_bodies_executed_by44')
 outputs.append((pp,D/'publish-thermostat-predefined-checkpoint-Outer-44.py',a))
 rows=[]
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':__import__('re')};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal','exec'),ns)
 for i,(parent,p,source)in enumerate(outputs,1):
  assert not p.exists();ast.parse(source);b=source.encode();put(p,b);a=parent.read_bytes();fw=''.join(difflib.unified_diff(a.decode().splitlines(True),source.splitlines(True),fromfile=parent.name,tofile=p.name)).encode();iv=''.join(difflib.unified_diff(source.splitlines(True),a.decode().splitlines(True),fromfile=p.name,tofile=parent.name)).encode();assert ns['apply'](a,fw)==b and ns['apply'](b,iv)==a
  rows.append(dict(parent=ref(parent),proposed=ref(p),literal_forward=put(O/'diffs'/f'{i:02}.forward.diff',fw),literal_inverse=put(O/'diffs'/f'{i:02}.inverse.diff',iv),Python_AST_only=True))
 m=write(O/'manifest.json',dict(schema='src06-thermostat-predefined-Root-adapters-prepared44.v1',status='UNEXECUTED_PENDING_HELD_PRODUCER_ROOT_FULL_READ_AND_ACTUAL',author_Source=ref(Path(__file__)),accepted42_actual_review=ref(actualp),adapters=rows,canonical_Cargo_Native_engine_tests_or_publication_mutations=False))
 print(json.dumps(dict(manifest=m,helpers=[x['proposed']for x in rows])))
if __name__=='__main__':main()

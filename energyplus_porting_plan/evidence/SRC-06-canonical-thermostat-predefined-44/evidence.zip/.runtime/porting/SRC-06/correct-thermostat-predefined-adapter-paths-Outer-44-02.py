"""Preserve unexecuted44 adapter01; correct only namespace/custody transport."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'thermostat-predefined-adapters-prepared-Outer-44-02'
NOTE='Root and Outer concurrently executed authorized deterministic private seal preparation; both returned identical held6f176105/final90ffa0 bytes. No canonical mutation occurred during preparation. Root alone owns this canonical application and all Cargo/CLI/publication execution.'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def main():
 assert not O.exists();parent=D/'thermostat-predefined-adapters-prepared-Outer-44/manifest.json';m=json.loads(parent.read_bytes());assert ref(parent)['sha256']=='fd3621a937e579c98996e83f3f99f916f1b6dc1d5ca250cc9604e5d46dcb1af4'
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal','exec'),ns);rows=[]
 for i,row in enumerate(m['adapters'],1):
  q=R/row['proposed']['path'];before=q.read_bytes();assert ref(q)==row['proposed'];source=before.decode()
  source=source.replace('Root-thermostat-predefined-application-42','Root-thermostat-predefined-application-44').replace('Root-source-thermostat-predefined-actual-review-42','Root-source-thermostat-predefined-actual-review-44').replace('thermostat-predefined-publication-readback-Outer-42','thermostat-predefined-publication-readback-Outer-44').replace('SRC-06-canonical-thermostat-predefined-42','SRC-06-canonical-thermostat-predefined-44').replace('canonical_thermostat_predefined_42','canonical_thermostat_predefined_44').replace('Outer-44.py','Outer-44-02.py')
  if q.name.startswith('apply-'):
   source=source.replace('result=dict(accepted=True,','result=dict(private_preparation_custody='+repr(NOTE)+',accepted=True,',1)
  if q.name.startswith('publish-'):
   source=source.replace("dict(schema='src06-canonical44-finite-engine-evidence.v1',","dict(private_preparation_custody="+repr(NOTE)+",schema='src06-canonical44-finite-engine-evidence.v1',",1)
  ast.parse(source);after=source.encode();p=q.with_name(q.stem+'-02.py');assert not p.exists();put(p,after)
  fw=''.join(difflib.unified_diff(before.decode().splitlines(True),source.splitlines(True),fromfile=q.name,tofile=p.name)).encode();iv=''.join(difflib.unified_diff(source.splitlines(True),before.decode().splitlines(True),fromfile=p.name,tofile=q.name)).encode();assert ns['apply'](before,fw)==after and ns['apply'](after,iv)==before
  rows.append(dict(parent=row['proposed'],proposed=ref(p),literal_forward=put(O/'diffs'/f'{i:02}.forward.diff',fw),literal_inverse=put(O/'diffs'/f'{i:02}.inverse.diff',iv),Python_AST_only=True))
 out=write(O/'manifest.json',dict(schema='src06-thermostat-predefined-Root-adapters-prepared44-02.v1',status='UNEXECUTED_NAMESPACES_CORRECTED_BEFORE_DELIVERY',author_Source=ref(Path(__file__)),original_unexecuted_adapters=ref(parent),adapters=rows,private_preparation_custody=NOTE,canonical_Cargo_Native_engine_tests_or_publication_mutations=False));print(json.dumps(dict(manifest=out,helpers=[x['proposed']for x in rows])))
if __name__=='__main__':main()

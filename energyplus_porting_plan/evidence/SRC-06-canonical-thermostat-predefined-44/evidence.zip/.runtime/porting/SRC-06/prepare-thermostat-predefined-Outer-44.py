"""Private coherent thermostat reports and true Schedule getValAndCountOnDay."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
C='6f2e40d10250a105b49966baa24d843711e61048';H='eb411835539bed9a14f9e5eb2175d217e5fe36e2'
O=D/'source-thermostat-predefined-draft-Outer-44';A=D/'source-thermostat-predefined-author-Outer-44'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=R/row['path'];r=ref(p);assert r['sha256']==row['sha256'] and r['bytes']==row.get('bytes',r['bytes']);return p
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def replace(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
def main():
 assert not O.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
 ap=D/'Root-source-fill-remaining-controlled-actual-review-42/review.json'
 assert ref(ap)['sha256']=='55bbcea3db9ce3fc60cfe41f06f00ee4ab479f3ea0a1ed75ac888decb7a236a2'
 actual=json.loads(ap.read_bytes());assert actual['accepted']
 priorp=checked(actual['complete_compiler_plan']);prior=json.loads(priorp.read_bytes())
 assert(prior['compiler_inputs'],prior['Rust_sources'])==(4510,4497)
 bp=json.loads(checked(actual['actual_B']).read_bytes());snapshot=bp['source_snapshot'];sr=json.loads(checked(snapshot).read_bytes());arch={x['historical_path']:x for x in sr['files']}
 for row in prior['entries']:
  p=row['path'];a=checked(arch[p]['archive']).read_bytes();b=(R/p).read_bytes()
  assert a==b and (hashlib.sha256(b).hexdigest(),len(b))==(row['final_sha256'],row['final_bytes']),p
 f1='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/thermostat_predefined.rs'
 f2='crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs'
 f3='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/remaining.rs'
 f4='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs'
 f5='crates/ep_runtime/src/heat_balance/selected_schedule_manager/predefined.rs'
 before={p:(R/p).read_bytes()for p in(f1,f2,f3,f4)}
 for p,b in before.items():assert subprocess.check_output(['git','show',H+':'+p],cwd=R)==b,p
 assert not(R/f5).exists();proposed={p:b.decode('utf8')for p,b in before.items()}
 proposed[f1]=(A/'thermostat_predefined.rs').read_bytes().decode('utf8')
 proposed[f2]=replace(proposed[f2],'mod day_group;','mod day_group;\nmod predefined;')
 proposed[f3]=replace(proposed[f3],"    pub(crate) environment: &'a WeatherEnvironmentState,","    pub(crate) environment: &'a WeatherEnvironmentState,\n    pub(crate) weather: &'a crate::weather::day::WeatherOwnerState,")
 proposed[f3]=replace(proposed[f3],'''        o.controller.fill_source_predefined_table_on_thermostat_setpoints()?;
        o.controller.fill_source_predefined_table_on_thermostat_schedules()?;''','''        o.controller.fill_source_predefined_table_on_thermostat_setpoints(
            o.schedules, o.environment, o.weather, o.clock, o.registry, o.table,
        )?;
        o.controller.fill_source_predefined_table_on_thermostat_schedules(
            o.schedules, o.registry, o.table,
        )?;''')
 proposed[f4]=replace(proposed[f4],'                    environment: &weather.state.environment,\n                    clock: &weather.state.global,','                    environment: &weather.state.environment,\n                    weather: &weather.state.weather,\n                    clock: &weather.state.global,')
 proposed[f5]=(A/'schedule_predefined.rs').read_bytes().decode('utf8')
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal','exec'),ns)
 rows=[]
 for i,p in enumerate((f1,f2,f3,f4,f5),1):
  a=before.get(p,b'');b=proposed[p].encode('utf8');bf=put(O/'before'/p,a)if p in before else None;pp=put(O/'proposed'/p,b)
  fw=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile=p,tofile=p)).encode();iv=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile=p,tofile=p)).encode()
  assert ns['apply'](a,fw)==b and ns['apply'](b,iv)==a
  run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,cwd=R,capture_output=True);assert run.returncode==0,run.stderr
  rows.append(dict(canonical_path=p,before_absent=p not in before,before=bf,proposed=pp,literal_inverse=put(O/'literal-inverse'/p,a),forward_diff=put(O/'diffs'/f'{i:02}.forward.diff',fw),inverse_diff=put(O/'diffs'/f'{i:02}.inverse.diff',iv),Source_only_parse=dict(exit_code=run.returncode,stdout=put(O/'parse'/f'{i:02}.stdout',run.stdout),stderr=put(O/'parse'/f'{i:02}.stderr',run.stderr))))
 entries=copy.deepcopy(prior['entries'])
 for row in rows:
  p=row['canonical_path'];entry=next((x for x in entries if x['path']==p),None)
  if entry is None:entry=dict(path=p);entries.append(entry)
  entry.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'],origin='whole private coherent Source44 thermostat predefined proposal')
 entries.sort(key=lambda x:x['path']);assert len(entries)==4511 and sum(x['path'].endswith('.rs')for x in entries)==4498
 plan=dict(schema='src06-thermostat-predefined-proposed-compiler-Source-plan44.v1',base_HEAD=H,prior_complete_compiler_Source_plan=ref(priorp),accepted42_actual_review=ref(ap),actual42_parent_snapshot=snapshot,compiler_inputs=4511,inputs=4511,Rust_sources=4498,selected_existing=4,selected_new=1,unchanged_parent_entries=4506,entries=entries)
 planp=O/'complete-proposed-compiler-Source-plan.json';write(planp,plan)
 native=[]
 for p,extents in [('src/EnergyPlus/ZoneTempPredictorCorrector.cc',[(6558,6766)]),('src/EnergyPlus/ScheduleManager.cc',[(3862,3935)]),('src/EnergyPlus/ScheduleManager.hh',[(72,105),(198,282),(305,368)]),('src/EnergyPlus/General.cc',[(705,737),(889,903)]),('src/EnergyPlus/DataHVACGlobals.hh',[(112,127)]),('src/EnergyPlus/DataEnvironment.hh',[(166,215)]),('src/EnergyPlus/WeatherManager.hh',[(818,821)]),('src/EnergyPlus/OutputReportPredefined.cc',[(1766,1915)]),('src/EnergyPlus/OutputReportPredefined.hh',[(163,174)])]:
  b=(N/p).read_bytes();assert b==subprocess.check_output(['git','show',C+':'+p],cwd=N);lines=b.splitlines(True);out=[]
  for first,last in extents:out.append(dict(first_line=first,last_line=last,source=put(O/'Native'/p/f'{first}-{last}.txt',b''.join(lines[first-1:last]))))
  native.append(dict(Native_path=p,whole=ref(N/p),pinned_Git=C,Git_whole_exact=True,extents=out))
 # Concrete local provider implementing the observed Native move-from strings.
 compiler_root=R/'.runtime/reference-tools/winlibs-gcc13.2.0-ucrt-r3/mingw64'
 cpp=[]
 for leaf,extents in [('basic_string.h',[(660,685)]),('vector.tcc',[(113,126),(440,494)])]:
  p=compiler_root/'include/c++/13.2.0/bits'/leaf;b=p.read_bytes();lines=b.splitlines(True);out=[]
  for first,last in extents:out.append(dict(first_line=first,last_line=last,source=put(O/'Native-toolchain'/leaf/f'{first}-{last}.txt',b''.join(lines[first-1:last]))))
  cpp.append(dict(whole=ref(p),retained_copy=put(O/'Native-toolchain'/leaf/'whole',b),extents=out))
 build=D/'system-report-native-build-Root-39/native-build.json';buildj=json.loads(build.read_bytes());assert ref(build)['sha256']=='fbcc0a26ddc997adea2c29b8c48aaa4d690d06f816eea8bc8fe9bd87c01f534b'
 commands=[r['command']for r in buildj.get('compile_commands',[])if 'command'in r]if isinstance(buildj.get('compile_commands'),list)else[]
 # Store actual compiler-path occurrences from the already authenticated build
 # without claiming an old header hash was recorded where it was not.
 def strings(v):
  if isinstance(v,str):yield v
  elif isinstance(v,dict):
   for w in v.values():yield from strings(w)
  elif isinstance(v,list):
   for w in v:yield from strings(w)
 command=next(s for s in strings(buildj)if 'g++.exe' in s and '-std=c++20' in s)
 assert 'winlibs-gcc13.2.0-ucrt-r3' in command
 move=O/'Native-toolchain/move-authority.json';write(move,dict(actual_build=ref(build),actual_compile_command=command,compiler=ref(compiler_root/'bin/g++.exe'),headers=cpp,semantics='basic_string move constructor resets source data to local and _M_set_length(0); vector emplace constructs new element before relocating original rows on reallocation. The four implicit ControlTypeInfo string moves therefore leave original enum slots empty. Rust mem::take preserves this actual provider behavior.',qualification='Current frozen local Native13.2 UCRT provider headers are copied whole and hashed here. Actual accepted39 command selects this compiler/toolchain; no fabricated historical header-hash receipt or generic unspecified-state inference.'))
 terms=['fill_source_predefined_table_on_thermostat','source_value_and_count_on_day','SourceRemainingPredefinedOwners','SourceZoneSetpointSchedule','SourceTemperatureControlledZone','WeatherOwnerState','source_ordinal_day']
 hits=[]
 for q in sorted((R/'crates').rglob('*.rs')):
  if 'fixtures'in q.parts:continue
  p=q.relative_to(R).as_posix();s=proposed.get(p,q.read_text(encoding='utf8'));lines=[dict(line=n,literal=x)for n,x in enumerate(s.splitlines(),1)if any(t in x for t in terms)]
  if lines:hits.append(dict(path=p,whole_sha256=hashlib.sha256(s.encode()).hexdigest(),lines=lines))
 for p in (f5,):
  s=proposed[p];hits.append(dict(path=p,whole_sha256=hashlib.sha256(s.encode()).hexdigest(),lines=[dict(line=n,literal=x)for n,x in enumerate(s.splitlines(),1)if any(t in x for t in terms)]))
 census=O/'whole-crates-API-census.json';write(census,dict(terms=terms,fixture_payloads_excluded=True,files=hits))
 contexts=[]
 for p in ['crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs','crates/ep_runtime/src/heat_balance/selected_schedule_manager/accessors.rs','crates/ep_runtime/src/heat_balance/selected_schedule_manager/compact.rs','crates/ep_runtime/src/heat_balance/selected_schedule_manager/detailed.rs','crates/ep_runtime/src/heat_balance/ctf_reports.rs','crates/ep_runtime/src/heat_balance/predefined_tables_catalog.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs','crates/ep_runtime/src/weather_day/context.rs','crates/ep_runtime/src/weather_raw/source_typical/dates.rs','crates/ep_runtime/src/weather_raw/mod.rs']:
  contexts.append(dict(canonical_path=p,whole=ref(R/p)))
 manifest=dict(schema='src06-coherent-thermostat-predefined-private-draft44.v1',status='FROZEN_SOURCE_ONLY_PENDING_INDEPENDENT_FULL_PEER_AND_ROOT_INTEGRATION',base_HEAD=H,author_Source=ref(Path(__file__)),author_fragments=[ref(A/'thermostat_predefined.rs'),ref(A/'schedule_predefined.rs')],accepted42_actual_review=ref(ap),actual_parent_snapshot=snapshot,parent_producer=actual['producer'],prior_complete_compiler_Source_plan=ref(priorp),complete_proposed_compiler_Source_plan=ref(planp),full4510_parent_readback=dict(inline_proof=True,archive_live_and_plan_whole_equal=True,compiler_inputs=4510,Rust_sources=4497),files=rows,selected_existing_sources=4,new_sources=1,literal_applications=10,Source_only_parses=5,Native_commit=C,Native_authorities=native,actual_Native_provider_move_authority=ref(move),concrete_same_owner_contexts=contexts,whole_crates_API_census=ref(census),scope='Whole thermostat6558-6766 normal paths, four source control kinds, actual unique Num/name, summer/winter and both times, all five initial enum slots with actual move/sort/join, true selected Schedule Constant/Detailed3862-3935 day/count/month on same physical schedule/day/week identities and real environment/calendar/DST operands. No requested-output subset, hardcoded case values/counts or derived expected tables.',same_owners='One borrowed WeatherOwnerState is threaded from the existing WeatherSession; no new allocation/default/environment guard. Existing source_ordinal_day reused. Report is a short-lived borrowed context only; no state/cache/schedule copies. No property calls/cache mutations.',scope_A='Empty thermostat arrays and zero controlled zones perform the existing reserve/no-entry route; the actual weather owner already exists and is only immutably reborrowed.',honest_boundaries='Actual null/unrepresented pointers, invalid storage indices and undefined Native signed arithmetic remain typed errors at their consumed operation. This is not a generic new schedule-input producer or numerical equivalence claim.',new_test_bodies=0,actual_test_bodies_executed=0,canonical_Cargo_Native_engine_tests_or_publication_mutations=False)
 mp=O/'draft.json';write(mp,manifest);print(json.dumps(dict(draft=ref(mp),plan=ref(planp),sources=5,applications=10,parses=5)))
if __name__=='__main__':main()

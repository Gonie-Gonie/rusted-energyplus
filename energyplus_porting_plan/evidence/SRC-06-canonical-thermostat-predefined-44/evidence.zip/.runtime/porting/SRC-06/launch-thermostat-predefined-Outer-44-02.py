"""Root-only two-case CLI launcher; canonical target/incremental0 set internally."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PARENTS={'B': ('canonical-source-fill-remaining-controlled-B-NOLIMIT-24H-command-Root-42/receipt.json', '3b08e968db8866720e78d724765b19da02ca31013abb3bf8e8ea7c2962cf47b3'), 'A24': ('canonical-source-fill-remaining-controlled-A-24H-command-Root-42/receipt.json', 'e2af7a159104daef93b50afd6518df96e056ec6ba167e7aaa466aaff0730d189')}

def checked(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256']and len(b)==row.get('bytes',len(b));return p
def main(a):
 name,digest=a.application.rsplit('#',1);ap=checked(dict(path=name,sha256=digest));app=json.loads(ap.read_bytes());assert app['accepted']and not app['findings']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==app['base_HEAD']
 plan=json.loads(checked(app['complete_compiler_plan']).read_bytes());assert(plan['inputs'],plan['Rust_sources'])==(4511,4498)
 for row in plan['entries']:
  b=(R/row['path']).read_bytes();assert len(b)==row['final_bytes']and hashlib.sha256(b).hexdigest()==row['final_sha256'],row['path']
 old,digest=PARENTS[a.case];parent=checked(dict(path=(D/old).relative_to(R).as_posix(),sha256=digest));cmd=json.loads(parent.read_bytes())['command']
 case='B-NOLIMIT-24H'if a.case=='B'else'A-24H';scope='B'if a.case=='B'else'A'
 assert cmd[cmd.index('--porting-scope')+1]==scope and Path(cmd[cmd.index('--weather')+1]).is_file()
 assert (R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()in[Path(v).resolve()for v in cmd if v.casefold().endswith('.idf')]
 assert not{'test','--all-targets','--oracle-baseline','--compare-oracle'}&set(cmd)
 out=D/f'canonical-source-thermostat-predefined-{case}-Root-44/output';receipt=D/f'canonical-source-thermostat-predefined-{case}-command-Root-44'
 assert not receipt.exists()and not out.parent.exists();cmd[cmd.index('--output-dir')+1]=out.as_posix()
 # These values are supplied to the recorder/actual child even if the invoking
 # shell forgot them. Other compiler overrides must match the accepted baseline.
 env=dict(os.environ);target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve();assert target.is_dir()
 env['CARGO_TARGET_DIR']=str(target);env['CARGO_INCREMENTAL']='0'
 assert Path(env['CARGO_TARGET_DIR']).resolve()==target and env['CARGO_INCREMENTAL']=='0'
 for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'):
  assert env.get(key)is None,(key,'Unexpected compiler override; do not silently change build context')
 command=[sys.executable,'tools/porting/record_command.py','--output-dir',receipt.relative_to(R).as_posix(),'--',*cmd]
 print('Root44 actualCLI: canonical CARGO_TARGET_DIR fixed internally; CARGO_INCREMENTAL=0; fresh '+case,flush=True)
 return subprocess.call(command,cwd=R,env=env)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case',choices=['B','A24']);p.add_argument('--application',required=True);raise SystemExit(main(p.parse_args()))

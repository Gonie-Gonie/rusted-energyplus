from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-thermostat-predefined-application-42';assert not O.exists()
assert '--apply' in sys.argv, 'Root-only explicit --apply required'
manifest_arg=sys.argv[sys.argv.index('--manifest')+1];manifest_path,manifest_sha=manifest_arg.rsplit('#',1)
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref((R/manifest_path).resolve());assert mr['sha256']==manifest_sha;m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peerfiles={v['canonical_path']:v for v in peer['files']};draft=json.loads(checked(m['original_draft']));draftfiles={v['canonical_path']:v for v in draft['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD'] and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4510 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(draftfiles[n]['proposed'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==5 and len(new)==1 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first_line']-1:e['last_line']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==9 and extent_count==12
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted42_actual_review','prior_complete_compiler_Source_plan','whole4498_Rust_API_census','original_draft','actual_Native_provider_move_authority']:checked(m[k])
move=json.loads(checked(m['actual_Native_provider_move_authority']));checked(move['actual_build']);checked(move['compiler'])
for header in move['headers']:
 b=checked(header['whole']);assert b==checked(header['retained_copy'])
 for extent in header['extents']:assert b''.join(b.splitlines(keepends=True)[extent['first_line']-1:extent['last_line']])==checked(extent['source'])
parent_readback=m['full4510_parent_readback'];assert parent_readback['compiler_inputs']==4510 and parent_readback['Rust_sources']==4497 and all(v is True for k,v in parent_readback.items() if k not in ['kind','compiler_inputs','Rust_sources'])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4511 and sum(n.endswith('.rs') for n in rows)==4498
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Outer authored the coherent five-Source thermostat implementation and this Root-only adapter. Root independently fully reviewed all Source/Native/control/schedule/calendar/provider/context semantics in the bound formal peer. This application authenticates exact committed42 archive/live/Git plus the accepted four-existing/one-new literal join; no independent authorship is attributed to Outer',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4510,final_inputs=4511,final_Rust_sources=4498,selected_Rust=5,new_Rust=1,literal_applications=10,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Full thermostat6558-6766 and true Schedule3862-3935 methods on retained owners: actual unique Num, original row/name/enum order, cool-before-heat, provider-authenticated move and lexical join, actual Latitude/leap/startweekday/DST and full week/day identity counts. No hardcoded case values/month/count, new test, property/cache/FPU/tolerance/gate change or unobserved B completion/equivalence claim.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

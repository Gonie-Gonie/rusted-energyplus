from pathlib import Path
import ast, hashlib, json, re, subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'Root-thermostat-predefined-Source-review-44';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def check(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']),r['path'];return p
def read(r):return json.loads(check(r).read_bytes())
p=D/'source-thermostat-predefined-draft-Outer-44/draft.json';assert ref(p)['sha256']=='a7487c8823aa9cb205d6d26c859fe092fd5d35ff98c83598eb4ae75e5d9a62c4';m=json.loads(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==m['base_HEAD']=='eb411835539bed9a14f9e5eb2175d217e5fe36e2'
h=D/'review-meter-final-predefined-Root-01.py';assert ref(h)['sha256']=='e5aa0bb38df690b77f53b2ef63ec4083dca5a500b745881a2dd8d4b831515256'
t=ast.parse(h.read_bytes());exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='apply'],type_ignores=[]),'<authenticated-literal-helper>','exec'))
a=read(m['accepted42_actual_review']);assert a['accepted'] and not a['findings']
snapshot=read(m['actual_parent_snapshot']);actual={v['historical_path']:v for v in snapshot['files']}
parent=read(m['prior_complete_compiler_Source_plan']);plan=read(m['complete_proposed_compiler_Source_plan']);prior={v['path']:v for v in parent['entries']};final={v['path']:v for v in plan['entries']}
assert len(prior)==len(actual)==4510 and len(final)==4511 and sum(n.endswith('.rs') for n in final)==4498
selected={v['canonical_path']:v for v in m['files']};assert len(selected)==5
for n,row in prior.items():
 b=check(actual[n]['archive']).read_bytes();assert len(b)==row['final_bytes'] and hashlib.sha256(b).hexdigest()==row['final_sha256'] and (R/n).read_bytes()==b
 proposed=check(selected[n]['proposed']).read_bytes() if n in selected else b
 assert final[n]['final_sha256']==hashlib.sha256(proposed).hexdigest() and final[n]['final_bytes']==len(proposed)
assert set(final)-set(prior)=={v['canonical_path'] for v in m['files'] if v['before_absent']}
files=[]
for row in m['files']:
 n=row['canonical_path'];before=b'' if row['before_absent'] else check(row['before']).read_bytes();after=check(row['proposed']).read_bytes()
 if row['before_absent']:assert not (R/n).exists()
 else:assert before==subprocess.check_output(['git','show','HEAD:'+n],cwd=R)
 assert before==check(row['literal_inverse']).read_bytes()
 assert apply(before,check(row['forward_diff']).read_bytes())==after and apply(after,check(row['inverse_diff']).read_bytes())==before
 assert before.count(b'#[test]')==after.count(b'#[test]')
 parsed=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--config','skip_children=true','--emit','stdout',str(check(row['proposed']))],capture_output=True);assert parsed.returncode==0
 assert final[n]['final_sha256']==hashlib.sha256(after).hexdigest() and final[n]['final_bytes']==len(after)
 files.append(dict(canonical_path=n,before=row['before'],proposed=row['proposed'],literal_forward_inverse_exact=True,Source_only_syntax_exit=0))
native=[];extents=[]
for row in m['Native_authorities']:
 b=check(row['whole']).read_bytes();assert subprocess.check_output(['git','show',m['Native_commit']+':'+row['Native_path']],cwd=N)==b
 native.append(row['whole'])
 for e in row['extents']:
  assert b''.join(b.splitlines(keepends=True)[e['first_line']-1:e['last_line']])==check(e['source']).read_bytes();extents.append(e['source'])
for row in m['concrete_same_owner_contexts']:check(row['whole'])
move=read(m['actual_Native_provider_move_authority']);check(move['actual_build']);check(move['compiler'])
for header in move['headers']:
 b=check(header['whole']).read_bytes();assert b==check(header['retained_copy']).read_bytes()
 for e in header['extents']:assert b''.join(b.splitlines(keepends=True)[e['first_line']-1:e['last_line']])==check(e['source']).read_bytes()
assert b'_M_set_length(0);' in check(move['headers'][0]['retained_copy']).read_bytes().splitlines()[686-1]
census=read(m['whole_crates_API_census']);overlay={n:check(v['proposed']).read_bytes() for n,v in selected.items()}
fresh=[]
for n in sorted(set(prior)|set(selected)):
 if not n.startswith('crates/') or not n.endswith('.rs') or '/fixtures/' in n:continue
 b=overlay[n] if n in overlay else (R/n).read_bytes();s=b.decode('utf-8')
 hits=[dict(line=i,literal=line) for i,line in enumerate(s.splitlines(),1) if any(term in line for term in census['terms'])]
 if hits:fresh.append(dict(path=n,whole_sha256=hashlib.sha256(b).hexdigest(),lines=hits))
assert {v['path']:v for v in census['files']}=={v['path']:v for v in fresh}
O.mkdir();(O/'whole-crates-API-census.json').write_bytes((json.dumps(dict(terms=census['terms'],files=fresh),indent=2)+'\n').encode())
result=dict(schema='src06-independent-thermostat-predefined-Source-review.v1',accepted=True,findings=[],reviewed_draft=ref(p),authorship='Root independently reviewed Outer-authored five-Source change and complete Native helper branches; no author self-review.',files=files,Native_wholes=native,Native_extents=extents,actual_Native_provider_move_authority=m['actual_Native_provider_move_authority'],full4510_actual42_parent_and_proposed4511_plan_exact=True,selected4_Git_before_and_literal10_exact=True,new_source_absent=True,Source_only_parse_count=5,API_census=ref(O/'whole-crates-API-census.json'),checks=[
 'Whole ZTPC6558-6766: enum-kind traversal and unique schedule Num reservation/dedup, heat-before-cool Dual traversal, SingleHeatCool summer/winter labels, 11/23 call and entry order/default2/integer/month join retained.',
 'Whole Schedule3862-3935: actual Constant currentVal (not EMS getter), latitude branch and leap count; Detailed actual General ordinal/modulo, same DSTIndex and TimeStepsInHour, retained physical week/day identities then value equality annual short circuits. No case-value/calendar/result projection.',
 'Native schedule-summary five initial enum slots, actual controlled types, cool-before-heat pointer consumption, four-string move, lexicographic tuple sort and independent nonempty joins retained. Frozen actual GCC13.2 UCRT whole headers rehashed; basic_string line686 clears source, vector constructs appended row before relocation. Header receipts are current provider evidence, not invented historical hashes.',
 'Existing real weather owner immutably threaded through sole remaining/endrun caller. Full owner API census and all borrowed member types/error conversion checked. A empty arrays require no schedule lookup; no default owners or new cache/property arithmetic introduced.',
 'No new test body, dependency, production fixture injection, FP control or tolerance change. Source/Native static review is not numerical or completed-run equivalence; actual B/A and artifact comparison remain required.'
],Cargo_Native_engine_or_tests_executed=False,canonical_mutations=0,numerical_PASS_or_gate_change=False,reviewer_Source=ref(Path(__file__)))
q=O/'review.json';q.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(ref(q)))

"""Private44 finite engine publication template; never publishes or runs Cargo."""
from pathlib import Path
import argparse,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R);r=ref(p);assert r['sha256']==row['sha256']and r['bytes']==row.get('bytes',row.get('size_bytes',r['bytes']));return p
def arg(value):
 path,sha=value.rsplit('#',1);r=ref((R/path).resolve());assert r['sha256']==sha;return r
def main(a):
 mr=arg(a.manifest);m=json.loads(checked(mr).read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']
 assert len(m['files'])==5 and m['existing_Source_files']==4 and m['new_Source_files']==1
 plan=json.loads(checked(m['complete_final_compiler_Source_plan']).read_bytes());assert(plan['inputs'],plan['compiler_inputs'],plan['Rust_sources'])==(4511,4511,4498)
 out=D/('thermostat-predefined-publication-READY-Outer-44-02'if a.actual else'thermostat-predefined-publication-prepared-Outer-44-02');assert not out.exists();files={}
 def add(row):
  p=checked(row);r=ref(p);assert p.suffix.casefold()not in('.zip','.exe','.a','.dll')and r['bytes']<64*1024*1024
  if r['path']in files:assert files[r['path']]==r
  files[r['path']]=r
 def addp(p):add(ref(p))
 add(mr)
 for key in ('author_Source','original_draft','independent_full_semantic_peer','accepted42_actual_review','actual_parent_snapshot','prior_complete_compiler_Source_plan','complete_final_compiler_Source_plan','whole4498_Rust_API_census','actual_Native_provider_move_authority'):add(m[key])
 draft=json.loads(checked(m['original_draft']).read_bytes());add(draft['author_Source'])
 for row in draft['author_fragments']:add(row)
 add(draft['complete_proposed_compiler_Source_plan']);add(draft['whole_crates_API_census'])
 peer=json.loads(checked(m['independent_full_semantic_peer']).read_bytes());assert peer['accepted']and not peer['findings'];add(peer['reviewer_Source'])
 for row in peer['Native_extents']:add(row)
 for row in m['files']:
  for key in ('before','proposed','literal_inverse','forward_diff','inverse_diff','actual42_before_archive'):
   if row.get(key)is not None:add(row[key])
  for parse in ('Source_only_parse','final_fresh_Source_only_parse'):
   for key in ('stdout','stderr'):add(row[parse][key])
 for row in m['Native_authorities']:
  add(row['whole'])
  for extent in row['extents']:add(extent['source'])
 for row in m['concrete_same_owner_contexts']:add(row['whole'])
 move=json.loads(checked(m['actual_Native_provider_move_authority']).read_bytes());add(move['actual_build'])
 for header in move['headers']:
  add(header['whole']);add(header['retained_copy'])
  for extent in header['extents']:add(extent['source'])
 for folder in ('thermostat-predefined-adapters-prepared-Outer-44','thermostat-predefined-adapters-prepared-Outer-44-02'):
  mp=D/folder/'manifest.json';addp(mp);am=json.loads(mp.read_bytes());add(am['author_Source'])
  for row in am['adapters']:
   for key in ('parent','proposed','literal_forward','literal_inverse'):add(row[key])
 for p in [D/'apply-thermostat-predefined-Outer-44-02.py',D/'launch-thermostat-predefined-Outer-44-02.py',D/'check-source-thermostat-predefined-actual-Outer-44-02.py',D/'publish-thermostat-predefined-checkpoint-Outer-44-02.py',Path(__file__)]:addp(p)
 previous=R/'energyplus_porting_plan/evidence/SRC-06-canonical-fill-remaining-controlled-42/summary.json';pv=json.loads(previous.read_bytes());assert(pv['A'],pv['B'])==('14/54','14/64');addp(previous)
 t=dict(schema='src06-thermostat-predefined-publication-template44.v1',status='WAITING_FOR_ROOT_ACTUAL44_AND_FULL_READ',base_HEAD=head,publisher_Source=ref(D/'publish-thermostat-predefined-checkpoint-Outer-44-02.py'),producer=mr,complete_plan=m['complete_final_compiler_Source_plan'],independent_peer=m['independent_full_semantic_peer'],accepted_parent_review=m['accepted42_actual_review'],accepted_parent_plan=m['prior_complete_compiler_Source_plan'],expected_actual_review_path='.runtime/porting/SRC-06/Root-source-thermostat-predefined-actual-review-44/review.json',previous_engine_checkpoint=ref(previous),finite_archive_inputs=list(files.values()),
 summary_template=dict(A='14/54',B='14/64',gate_changes=False,policy_changes=False,selected_existing_production_Sources=4,new_production_Source_files=1,selected_production_Sources=5,new_test_bodies=0,actual_test_bodies_executed=0,actual_engine_CLI_invocations=2,accepted_engine_CLI_receipts=2,
  scope='Genuine complete thermostat setpoint/schedule predefined routines6558-6766 and common retained Schedule Constant/Detailed day-value/count/month3862-3935. Real Num identity, original kind/row order, five initial control-info slots, cool-before-heat and actual provider move/sort/join semantics; true Latitude/leap/startweekday/DST and full365/366 week/day pointer-identity counts.',
  qualification='Actual B result is pending until Root execution. Successful Source620, if observed, is a Source completion fact and does not alone establish Native numerical/physical equivalence. Accepted42 A24 original5352 evidence transfers only after strict complete reported files/CSV/JSON/runtime comparison. Earlier scientific cohorts remain preserved historical evidence, not rerun here. No hardcoded case values/month/daycounts, new test/property/cache/FPU/tolerance change or finite15/card gate claim.',
  Native_BND_qualification='Retained original Native21 physical BND body is compared after two exact engine ProgramVersion headers. This is reported IO only; no fresh Native engine or complete internal Node-state equivalence.'),
 doc_appends={
  'cards/SRC-06.md':'\uc628\ub3c4\uc870\uc808\uae30\uc758 \uc124\uc815\uac12\uacfc \uc2a4\ucf00\uc904 \uc694\uc57d\uc744 \uc2e4\uc81c Schedule \uc18c\uc720\uc790\uc5d0 \uc5f0\uacb0\ud588\ub2e4. \ub0a0\uc9dc\ubcc4 \uac12\u00b7\uc77c\uc218\u00b7\uc6d4\uc744 Native \uc21c\uc11c\ub300\ub85c \uad6c\ud55c\ub2e4. B \uc2e4\ud589 \uacb0\uacfc: `{{actual_B_result}}`. A24\uc758 \uae30\uc874 5,352\uac1c \ubcf4\uace0\uac12 \uc99d\uac70\ub294 \uc804\uccb4 \uacb0\uacfc \ube44\uad50 \ud6c4 \uc774\uc5b4\ubc1b\ub294\ub2e4.',
  'CHECKLIST.md':'\uae30\uc874 Rust \ud30c\uc77c 4\uac1c\uc640 \uc2e0\uaddc \uacf5\ud1b5 helper 1\uac1c\ub85c thermostat \ucd5c\uc885 \uc694\uc57d\uc744 \uc774\uc5c8\ub2e4. B/A24 CLI 2\ud68c\ub85c \ud655\uc778\ud558\uba70 \uc2e4\ud589 \ub3c4\uad6c\uac00 canonical \ube4c\ub4dc \uacbd\ub85c\uc640 incremental0\uc744 \uac15\uc81c\ud55c\ub2e4. \uc0c8 \ud14c\uc2a4\ud2b8\uc640 \uac8c\uc774\ud2b8 \ubcc0\uacbd\uc740 \uc5c6\ub2e4.',
  'STATE_CONTRACTS.md':'\uae30\uc874 WeatherSession\uc758 \uc704\ub3c4\u00b7\uc724\ub144\u00b7\uc2dc\uc791 \uc694\uc77c\u00b7DST\ub97c \uac19\uc740 Schedule \uc8fc\uac04\u00b7\uc77c\uac04 \uac1d\uccb4\uc640 \ud568\uaed8 \uc77d\ub294\ub2e4. \ub2e4\uc12f \uc81c\uc5b4 \uc815\ubcf4 \uc2ac\ub86f\uacfc GCC \ubb38\uc790\uc5f4 \uc774\ub3d9 \uc758\ubbf8, \uc815\ub82c\u00b7\uc5f0\uacb0 \uc21c\uc11c\ub97c \ubcf4\uc874\ud558\uba70 \uac12\uc774\ub098 \uc77c\uc218\ub97c \ubbf8\ub9ac \uc800\uc7a5\ud55c \ub300\uccb4 \uc18c\uc720\uc790\ub294 \uc5c6\ub2e4.'})
 if a.actual:
  ar=arg(a.actual);actual=json.loads(checked(ar).read_bytes());assert actual['accepted']and not actual['findings']and actual['producer']==mr and actual['complete_compiler_plan']==t['complete_plan']
  assert actual['same4511_archived_inputs_exact_final_plan']and actual['selected5_final_sources_exact']and actual['actual_test_bodies_executed']==actual['new_test_bodies']==0
  assert actual['accepted42_full5352_proof']==t['accepted_parent_review'];t['accepted_actual_review']=ar;t['status']='HELD_READY_FOR_ROOT_ACTUAL44_AND_FULL_READ'
 out.mkdir();p=out/'publication-template.json';p.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(dict(template=ref(p),publisher=t['publisher_Source'],fixed_archive_entries=len(files),canonical_mutations=0,published=False)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--actual');main(p.parse_args())

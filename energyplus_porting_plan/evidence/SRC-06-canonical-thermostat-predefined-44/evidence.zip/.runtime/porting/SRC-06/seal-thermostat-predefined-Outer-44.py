"""Private44 custody on actual committed42; no canonical/Cargo mutation."""
from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'source-thermostat-predefined-held-Outer-44';H='eb411835539bed9a14f9e5eb2175d217e5fe36e2'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=R/row['path'];r=ref(p);assert r['sha256']==row['sha256']and r['bytes']==row.get('bytes',r.get('size_bytes',r['bytes']));return p
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def contains(v,row):
 if isinstance(v,dict):return(v.get('path'),v.get('sha256'))==(row['path'],row['sha256'])or any(contains(x,row)for x in v.values())
 return isinstance(v,list)and any(contains(x,row)for x in v)
def main(a):
 assert not O.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R)
 dp=D/'source-thermostat-predefined-draft-Outer-44/draft.json';assert ref(dp)['sha256']=='a7487c8823aa9cb205d6d26c859fe092fd5d35ff98c83598eb4ae75e5d9a62c4';d=json.loads(dp.read_bytes())
 path,sha=a.peer.rsplit('#',1);peer=ref(R/path);assert peer['sha256']==sha;review=json.loads(checked(peer).read_bytes());assert review['accepted']and not review.get('findings',[])and contains(review,ref(dp))
 actualp=checked(d['accepted42_actual_review']);actual=json.loads(actualp.read_bytes());assert actual['accepted']and not actual.get('findings',[])
 priorp=checked(d['prior_complete_compiler_Source_plan']);prior=json.loads(priorp.read_bytes());assert(prior['compiler_inputs'],prior['Rust_sources'])==(4510,4497)
 snapshot=json.loads(checked(d['actual_parent_snapshot']).read_bytes());archives={x['historical_path']:x for x in snapshot['files']};assert len(archives)==4510
 for row in prior['entries']:
  p=row['path'];b=checked(archives[p]['archive']).read_bytes();assert b==(R/p).read_bytes()and(len(b),hashlib.sha256(b).hexdigest())==(row['final_bytes'],row['final_sha256']),p
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal','exec'),ns)
 files=[]
 for i,row in enumerate(d['files'],1):
  p=row['canonical_path'];before=b''if row['before_absent']else checked(row['before']).read_bytes();proposed=checked(row['proposed']).read_bytes()
  if row['before_absent']:assert not(R/p).exists()
  else:assert before==checked(archives[p]['archive']).read_bytes()==subprocess.check_output(['git','show',H+':'+p],cwd=R)
  assert ns['apply'](before,checked(row['forward_diff']).read_bytes())==proposed and ns['apply'](proposed,checked(row['inverse_diff']).read_bytes())==before
  assert checked(row['literal_inverse']).read_bytes()==before
  run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,cwd=R,capture_output=True);assert run.returncode==0
  item=copy.deepcopy(row);item['actual42_before_archive']=None if row['before_absent']else archives[p]['archive'];item['selected_Git_exact_or_new_absent']=True
  item['final_fresh_Source_only_parse']=dict(exit_code=0,stdout=put(O/'parse'/f'{i:02}.stdout',run.stdout),stderr=put(O/'parse'/f'{i:02}.stderr',run.stderr));files.append(item)
 proposed_plan=json.loads(checked(d['complete_proposed_compiler_Source_plan']).read_bytes());entries=copy.deepcopy(prior['entries'])
 for row in files:
  p=row['canonical_path'];entry=next((x for x in entries if x['path']==p),None)
  if entry is None:entry=dict(path=p);entries.append(entry)
  entry.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'],origin='whole accepted coherent Source44 thermostat predefined proposal')
 entries.sort(key=lambda x:x['path']);assert len(entries)==4511 and sum(x['path'].endswith('.rs')for x in entries)==4498
 assert[(x['path'],x['final_sha256'],x['final_bytes'])for x in entries]==[(x['path'],x['final_sha256'],x['final_bytes'])for x in proposed_plan['entries']]
 final=dict(schema='src06-thermostat-predefined-final-compiler-Source-plan44.v1',base_HEAD=H,accepted42_actual_review=d['accepted42_actual_review'],actual_parent_snapshot=d['actual_parent_snapshot'],prior_complete_compiler_Source_plan=ref(priorp),compiler_inputs=4511,inputs=4511,Rust_sources=4498,selected_existing=4,selected_new=1,unchanged_parent_entries=4506,entries=entries)
 fp=O/'complete-final-compiler-Source-plan.json';write(fp,final)
 for authority in d['Native_authorities']:
  p=checked(authority['whole']);b=p.read_bytes();assert b==subprocess.check_output(['git','show',d['Native_commit']+':'+authority['Native_path']],cwd=N);lines=b.splitlines(True)
  for x in authority['extents']:assert checked(x['source']).read_bytes()==b''.join(lines[x['first_line']-1:x['last_line']])
 move=json.loads(checked(d['actual_Native_provider_move_authority']).read_bytes());checked(move['actual_build']);checked(move['compiler'])
 for header in move['headers']:
  p=checked(header['whole']);assert checked(header['retained_copy']).read_bytes()==p.read_bytes();lines=p.read_bytes().splitlines(True)
  for x in header['extents']:assert checked(x['source']).read_bytes()==b''.join(lines[x['first_line']-1:x['last_line']])
 for c in d['concrete_same_owner_contexts']:assert checked(c['whole']).read_bytes()==checked(archives[c['canonical_path']]['archive']).read_bytes()
 old_census=json.loads(checked(d['whole_crates_API_census']).read_bytes());terms=old_census['terms'];hits=[]
 for entry in entries:
  p=entry['path']
  if not p.startswith('crates/')or not p.endswith('.rs')or '/fixtures/'in p:continue
  s=checked(entry['source']).read_text(encoding='utf8');lines=[dict(line=i,literal=x)for i,x in enumerate(s.splitlines(),1)if any(t in x for t in terms)]
  if lines:hits.append(dict(path=p,whole_sha256=entry['final_sha256'],lines=lines))
 cr=write(O/'whole4498-Rust-API-census.json',dict(compiler_Rust_sources=4498,fixture_payloads_excluded_only_for_API_text_search=True,terms=terms,files=hits))
 manifest=dict(schema='src06-thermostat-predefined-held44.v1',status='HELD_NOT_APPLIED',base_HEAD=H,author_Source=ref(Path(__file__)),original_draft=ref(dp),independent_full_semantic_peer=peer,accepted42_actual_review=d['accepted42_actual_review'],actual_parent_snapshot=d['actual_parent_snapshot'],parent_producer=d['parent_producer'],prior_complete_compiler_Source_plan=ref(priorp),complete_final_compiler_Source_plan=ref(fp),full4510_parent_readback=dict(inline=True,compiler_inputs=4510,Rust_sources=4497,all_actual42_archived_inputs_match_plan_and_live=True,selected4_before_wholes_exact_actual42_and_Git=True,new_child_canonical_absent=True,all4506_unselected_wholes_exact_actual42=True,all40_cohort_main_Cargo_and_fixture_changes_preserved=True),files=files,existing_Source_files=4,new_Source_files=1,selected_existing_sources=4,new_sources=1,literal_applications=10,Source_only_parses=5,whole4498_Rust_API_census=cr,Native_commit=d['Native_commit'],Native_authorities=d['Native_authorities'],actual_Native_provider_move_authority=d['actual_Native_provider_move_authority'],concrete_same_owner_contexts=d['concrete_same_owner_contexts'],scope=d['scope'],same_owners=d['same_owners'],scope_A=d['scope_A'],honest_boundaries=d['honest_boundaries'],new_test_bodies=0,actual_test_bodies_executed=0,canonical_Cargo_Native_engine_tests_or_publication_mutations=False)
 mp=O/'manifest.json';write(mp,manifest);print(json.dumps(dict(manifest=ref(mp),plan=ref(fp),compiler_inputs=4511,Rust_sources=4498,sources=5)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--peer',required=True);main(p.parse_args())

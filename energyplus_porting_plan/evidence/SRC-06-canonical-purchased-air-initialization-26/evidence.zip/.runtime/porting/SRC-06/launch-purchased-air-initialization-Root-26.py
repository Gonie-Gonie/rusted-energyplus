from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-purchased-air-input-B-NOLIMIT-24H-command-Root-25-02/receipt.json','f976f08c37a3491e14cd4777132af5204cb8e2f1ca1044244ce78b60d3126125'),
 'A24':('canonical-source-purchased-air-input-A-24H-command-Root-25-02/receipt.json','8376fdf0f9bd2240f76d136c44985f8b0997a339ddc50673c64041d1778a5484'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-purchased-air-initialization-'+case+'-command-Root-26'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-purchased-air-initialization-'+case+'-Root-26/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

import argparse
import ast
import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
OUT=D/'source-purchased-air-initialization-held-Peer-26'

def ref(p):
    p=Path(p);b=p.read_bytes()
    return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}

def auth(r):
    p=R/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'],r
    if 'bytes' in r:assert len(b)==r['bytes'],r
    return p

def read(path,sha):
    p=R/path;assert ref(p)['sha256']==sha;return p,json.loads(p.read_bytes())

def git(repo,*args):
    return subprocess.run(['git','-C',str(repo),*args],check=True,capture_output=True).stdout

def save(name,b):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)

def dump(name,obj):return save(name,(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode())

args=argparse.ArgumentParser();args.add_argument('--base-head',required=True);args=args.parse_args()
assert re.fullmatch('[0-9a-f]{40}',args.base_head)
assert git(R,'rev-parse','HEAD').decode().strip()==args.base_head
assert git(R,'rev-parse','origin/main').decode().strip()==args.base_head
assert not git(R,'status','--porcelain=v1','-uno').strip()
assert not OUT.exists()

draft_path,draft=read('.runtime/porting/SRC-06/source-purchased-air-initialization-draft-Peer-26-02/draft.json','5cd6069b83a4647eeb195ff8342b3b499dee82978050a4eba1870869a9e32f6e')
peer_path,peer=read('.runtime/porting/SRC-06/Outer-purchased-air-initialization-Source-review-26/review.json','f028388e504d58c2a8ce41e34da3b7f0e7132c24b9e6f7790ae0e73f20105357')
assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==ref(draft_path)
parent_path,parent=read('.runtime/porting/SRC-06/source-purchased-air-held-Outer-25-02/manifest.json','f2bc3fd2f9fafb9046cae94af13af58e4e0eaba03202900f1f5b516dac92f813')
actual_path,actual=read('.runtime/porting/SRC-06/Root-source-purchased-air-input-actual-review-25-02/review.json','1bc1b45027a2a3a675e6dc16c12ce1e6fc1fe16076e66357a20044b6555402ca')
assert actual['accepted'] and not actual['findings'] and actual['producer']==ref(parent_path)
assert actual['B_frontier']=='GetHeatBalanceInput: actual PurchasedAirManager InitPurchasedAir201'
parent_plan_path=auth(actual['complete_compiler_plan']);parent_plan=json.loads(parent_plan_path.read_bytes())
assert ref(parent_plan_path)['sha256']=='fc96be590fb15bfb05b73fd2dfe1e7b8a7c74a679600eb8d8f58945ac07a4a21'
assert parent_plan['inputs']==4500 and parent_plan['Rust_sources']==4487
receipts={}
for label,key,code in [('B-NOLIMIT-24H','actual_B',6),('A-24H','actual_A24',0)]:
    p=auth(actual[key]);receipt=json.loads(p.read_bytes())
    assert receipt['exit_code']==code and receipt['source_bytes_match_before_and_after']
    receipts[label]={'receipt':ref(p),'exit_code':code,'snapshot':receipt['source_snapshot']}
assert receipts['B-NOLIMIT-24H']['snapshot']==receipts['A-24H']['snapshot']
snapshot_path=auth(receipts['B-NOLIMIT-24H']['snapshot']);snapshot=json.loads(snapshot_path.read_bytes())
assert len(snapshot['files'])==4500
archives={x['historical_path']:x['archive'] for x in snapshot['files']}
entries={x['path']:copy.deepcopy(x) for x in parent_plan['entries']}
assert len(entries)==4500 and set(entries)==set(archives)
readback=[]
for name,entry in entries.items():
    b=auth(archives[name]).read_bytes()
    assert b==auth(entry['source']).read_bytes()==(R/name).read_bytes(),name
    assert hashlib.sha256(b).hexdigest()==entry['final_sha256'] and len(b)==entry['final_bytes'],name
    readback.append({'path':name,'actual_archive':archives[name],'actual_bytes':len(b),'actual_sha256':entry['final_sha256'],'whole_live_equal_actual_and_plan':True})

t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
files=[];logical={};peer_rows={x['canonical_path']:x for x in peer['files']}
for i,row in enumerate(draft['files'],1):
    name=row['canonical_path'];new=auth(row['proposed']).read_bytes()
    before=b'' if row['before_absent'] else auth(row['before']).read_bytes()
    if row['before_absent']:
        assert name not in entries and not (R/name).exists(),name
    else:
        assert before==auth(archives[name]).read_bytes()==(R/name).read_bytes()==git(R,'show',args.base_head+':'+name),name
    assert row['proposed']==peer_rows[name]['proposed']
    assert ns['apply_literal'](before,auth(row['forward_diff']).read_bytes())==new
    assert ns['apply_literal'](new,auth(row['inverse_diff']).read_bytes())==before
    assert auth(row['literal_inverse']).read_bytes()==before
    result=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True,cwd=R)
    assert result.returncode==0,(name,result.stderr)
    proposed=save('proposed/'+name,new)
    file={'canonical_path':name,'before_absent':row['before_absent'],'before':save('before/'+name,before) if before else None,'actual_parent_archive':archives.get(name),'proposed':proposed,'literal_inverse':save('literal-inverse/'+name,before),'forward_diff':save(f'diffs/{i:02}-forward.diff',auth(row['forward_diff']).read_bytes()),'inverse_diff':save(f'diffs/{i:02}-inverse.diff',auth(row['inverse_diff']).read_bytes()),'literal_origin_whole':row['proposed'],'before_whole_Git_exact_at_base':not row['before_absent'],'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',result.stdout),'stderr':save(f'parse/{i:02}.stderr',result.stderr)}}
    files.append(file);logical[name]=new.decode()
    entries[name]={'path':name,'final_sha256':proposed['sha256'],'final_bytes':proposed['bytes'],'source':proposed,'origin':'whole accepted Source26 draft02 proposal; no semantic rewrite'}
assert len(files)==4 and sum(x['before_absent'] for x in files)==1
assert len(entries)==4501 and sum(x.endswith('.rs') for x in entries)==4488
# Compiler metadata/pipeline and observer quarantine remain exact parent.
diag='crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs'
assert diag not in entries
pipeline=[x for x in entries if x.endswith('pipeline.json')]
for x in pipeline:assert entries[x]['final_sha256']==next(e['final_sha256'] for e in parent_plan['entries'] if e['path']==x)

api=[]
for name,entry in sorted(entries.items()):
    if not name.endswith('.rs'):continue
    text=logical.get(name)
    if text is None:text=auth(entry['source']).read_text(encoding='utf-8')
    needles=['simulate_source_purchased_air','SourcePurchasedAirInitOwners','SelectedSizingManager {','zone_cooling_only_fan','zone_heating_only_fan']
    found=[s for s in needles if s in text]
    if found:api.append({'path':name,'terms':found})
assert {x['path'] for x in api}=={x['canonical_path'] for x in files}

native=[]
for source in peer['Native_wholes']:
    name=source['Native_path'];b=auth(source['whole']).read_bytes()
    assert b==git(N,'show',PIN+':'+name)==(N/name).read_bytes()
    whole=save('Native/'+name,b);lines=b.splitlines(keepends=True);extents=[]
    ranges=[(e['first'],e['last']) for e in source['extents']]
    # AutoSize is a genuine Native constant, not an input-derived sentinel.
    if name=='src/EnergyPlus/DataSizing.hh':ranges.append((199,206))
    for a,z in ranges:
        value=b''.join(lines[a-1:z])
        old=next((e for e in source['extents'] if e['first']==a and e['last']==z),None)
        if old:assert value==auth(old['whole_line_bytes']).read_bytes()
        extents.append({'first':a,'last':z,'source':save('Native-extents/'+Path(name).name+f'.{a}-{z}.txt',value)})
    native.append({'Native_path':name,'whole':whole,'extents':extents,'pinned_Git_exact':True})
contexts=[]
for c in peer['concrete_same_owner_contexts']:
    name=c['canonical_path'];b=auth(c['whole']).read_bytes()
    assert b==auth(archives[name]).read_bytes()==(R/name).read_bytes()==git(R,'show',args.base_head+':'+name)
    contexts.append({'canonical_path':name,'whole':c['whole'],'actual_parent_archive':archives[name],'current_and_Git_exact':True})
# Actual getCurrentVal lives in report.rs; bind this concrete implementation as context too.
name='crates/ep_runtime/src/heat_balance/selected_schedule_manager/report.rs'
b=auth(archives[name]).read_bytes();assert b==(R/name).read_bytes()==git(R,'show',args.base_head+':'+name)
contexts.append({'canonical_path':name,'whole':{**archives[name],'bytes':len(b)},'actual_parent_archive':archives[name],'current_and_Git_exact':True})

plan=dump('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-Source26-compiler-input-plan.v1','base_HEAD':args.base_head,'actual25_parent_snapshot':ref(snapshot_path),'prior_plan':ref(parent_plan_path),'inputs':4501,'Rust_sources':4488,'entries':[entries[x] for x in sorted(entries)],'selected4_exact_draft02':True,'quarantined_diagnostic_child_absent':True,'Root_full_readback_required':True})
manifest={'schema':'src06-held-coherent-purchased-air-initialization.v1','status':'HELD Source26 on clean committed actual25-02; no Source26 runtime claim',
 'base_HEAD':args.base_head,'accepted25_actual_review':ref(actual_path),'parent_producer':ref(parent_path),'actual_parent_receipts':receipts,'actual_parent_snapshot':ref(snapshot_path),'prior_complete_compiler_Source_plan':ref(parent_plan_path),'complete_final_compiler_Source_plan':plan,'compiler_inputs':4501,'Rust_sources':4488,
 'original_draft02':ref(draft_path),'independent_full_semantic_peer':ref(peer_path),'files':files,'existing_Source_files':3,'new_Source_files':1,'selected_Source_files':4,'literal_applications':8,'Source_only_parses':4,'all4_proposals_whole_unchanged_from_reviewed_draft02':True,
 'full4500_parent_readback':dump('actual25-parent-full-readback.json',readback),'whole4488_Rust_API_census':dump('API-census.json',{'Rust_sources_examined':4488,'all_crates_runtime_tests_included':True,'hits':api,'sole_real_management_caller':True,'new_tests':0}),
 'Native_commit':PIN,'Native_authorities':native,'concrete_same_owner_contexts':contexts,
 'scope':'Real InitPurchasedAir plus ordinary SizePurchasedAir path through actual CalcPurchAirLoads203 entry. Same sole unit/module, Config/Node/list, live schedule/thermostat, sizing/clock/environment owners. No CP442 facade, fake readiness/count, scalar cache, substituted sized output or expected Native values.',
 'operation_order':peer['initialization_proof']+peer['sizing_proof'],
 'validation_policy':'Root owns actual production CLI B then appropriate A24 regression because two genuine sizing ctor flags changed. No new tests, repeated cohort, whole-suite or Cargo by author; positive diagnostic/plenum/scalable/Sizer first-operation bounds remain explicit.',
 'remaining_scope':'Calc/Update/Report unimplemented here; positive Init execution and fullB/numerical equivalence require future Root receipts. Parent25 BND is program-version only; no Node reporting claim.',
 'unsealed01_to02_order_correction':peer['unsealed_order_correction'],'new_test_bodies':0,'Cargo_main_tests_or_Native_mutations':False,'author_Source':ref(Path(__file__))}
p=OUT/'manifest.json';p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

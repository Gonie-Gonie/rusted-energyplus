"""Prepare one isolated checkpoint26 publisher; never execute it or mutate canonical docs."""
import ast
import copy
import difflib
import hashlib
import json
import re
from pathlib import Path

R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OUT=D/'purchased-air-initialization-publication-prepared-Peer-26'
OLD=D/'publish-zone-equipment-orchestration-checkpoint-Peer-24.py'
NEW=D/'publish-purchased-air-initialization-checkpoint-Peer-26.py'

def ref(p):
    p=Path(p);b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def check(r):
    p=R/r['path'];got=ref(p);assert got['sha256']==r['sha256'] and got['bytes']==r.get('bytes',r.get('size_bytes',got['bytes']));return p
def load(r):return json.loads(check(r).read_bytes())
def save(name,obj):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)

assert not OUT.exists() and not NEW.exists()
assert ref(OLD)['sha256']=='dd5afc9bb8fcf1e0ec05ba9f06fd41f4d802f0db86176ef35100947b2468b5a7'
producer_ref=ref(D/'source-purchased-air-initialization-held-Peer-26/manifest.json')
assert producer_ref['sha256']=='021f6a42a1bbed1b9d54f4bc5681ea02a71916f7603ecfec41d0ad787247e45e'
producer=load(producer_ref);peer_ref=producer['independent_full_semantic_peer'];peer=load(peer_ref)
assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==producer['original_draft02']
previous_ref=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-purchased-air-input-25/summary.json')
assert previous_ref['sha256'].startswith('28fa5554')
previous=load(previous_ref);assert previous['A']=='14/54' and previous['B']=='14/64'
parent_review_ref=producer['accepted25_actual_review'];parent_review=load(parent_review_ref)
assert parent_review['accepted'] and parent_review['actual_test_bodies_executed']==1
inherited_test=parent_review['raw_metadata_focused_test'];test=load(inherited_test)
assert test['exit_code']==0 and test['source_bytes_match_before_and_after']

old=OLD.read_text(encoding='utf-8');body=old
replacements=[
 ('checkpoint24 publisher','checkpoint26 publisher'),
 ('zone-equipment-orchestration-publication-prepared-Peer-24','purchased-air-initialization-publication-prepared-Peer-26'),
 ('SRC-06-canonical-zone-equipment-orchestration-24','SRC-06-canonical-purchased-air-initialization-26'),
 ('zone-equipment-orchestration-publication-readback-Peer-24','purchased-air-initialization-publication-readback-Peer-26'),
 ('f1f40fc84f2a8bfa5f048600cf4880e7ccc53e68','f8a5000d34f616b64dca7493fd8334ac2fc8f475'),
 ('(4492,4479)','(4501,4488)'),
 ("    assert contains(peer,template['producer'])", "    assert ref(peer_path) == template['accepted_independent_peer']\n    assert contains(peer,producer['original_draft02'])\n    assert producer['all4_proposals_whole_unchanged_from_reviewed_draft02'] is True"),
 ('Root-source-zone-equipment-orchestration-actual-review-24','Root-source-purchased-air-initialization-actual-review-26'),
 ('same4492_archived_inputs_exact_final_plan','same4501_archived_inputs_exact_final_plan'),
 ('whole_JSON_equal23_after_exactly_two_owned_path_field_bridges','whole_JSON_equal25_after_exactly_two_owned_path_field_bridges'),
 ('full_runtime_equal23_after_two_owned_path_bridges','full_runtime_equal25_after_two_owned_path_bridges'),
 ("    assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0", "    assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0\n    # The raw metadata test is inherited25 evidence; it is not a26 execution or same-snapshot claim.\n    inherited_test = load(checked(template['inherited25_raw_metadata_test']))\n    assert inherited_test['exit_code'] == 0 and inherited_test['source_bytes_match_before_and_after']\n    assert template['inherited25_raw_metadata_test'] == load(checked(template['accepted25_actual_review']))['raw_metadata_focused_test']"),
 ('== 4492 and set(index)==set(observed)','== 4501 and set(index)==set(observed)'),
 ('canonical-source-zone-equipment-orchestration-B-NOLIMIT-24H-Root-24','canonical-source-purchased-air-initialization-B-NOLIMIT-24H-Root-26'),
 ('canonical-source-zone-equipment-orchestration-A-24H-Root-24','canonical-source-purchased-air-initialization-A-24H-Root-26'),
 ('src06-canonical24-finite-evidence-archive.v1','src06-canonical26-finite-evidence-archive.v1'),
 ('4 coherent zone equipment orchestration Sources','4 coherent PurchasedAir initialization Sources'),
 ('src06-canonical-zone-equipment-orchestration.v1','src06-canonical-purchased-air-initialization.v1'),
 ('Genuine Source zone equipment orchestration; B incomplete at actual frontier','Genuine Source PurchasedAir initialization; B incomplete at actual frontier'),
 ('accepted23_full5352_proof','accepted25_full5352_proof'),
 ('accepted23_proof','accepted25_proof'),
 ('physical_files_whole_equal23','physical_files_whole_equal25'),
 ('whole_physical_streams_equal23','whole_physical_streams_equal25'),
 ('CSV_files_whole_equal23','CSV_files_whole_equal25'),
 ('whole_CSV_equal23','whole_CSV_equal25'),
 ('Proof transfer from accepted23','Proof transfer from accepted25'),
 ('canonical_zone_equipment_orchestration_24','canonical_purchased_air_initialization_26'),
 ('Source 구역 설비 시뮬레이션 진입 검증','Source IdealLoads 초기화 검증'),
 ('positive zone equipment orchestration Native state equivalence','positive PurchasedAir initialization Native state equivalence'),
 ('No test/fixture execution claim, historical ZIP recursion','No checkpoint26 test execution; inherited25 RawModel test named separately. No historical ZIP recursion'),
]
for before,after in replacements:
    assert before in body,before;body=body.replace(before,after)
# Preserve the existing archive/readback/docs engine; clarify inherited validation in public summary.
anchor="                   B_Node_lifecycle_observation=actual['B_Node_lifecycle_observation'],"
assert anchor in body
body=body.replace(anchor,anchor+"\n                   inherited25_raw_metadata_test=template['inherited25_raw_metadata_test'],\n                   inherited25_raw_test_is_not_checkpoint26_execution=True,")
ast.parse(body);assert '\ufffd' not in body
NEW.write_text(body,encoding='utf-8',newline='\n')
OUT.mkdir()

files={}
def add(r):
    p=check(r);value=ref(p);assert p.suffix.lower()!='.zip'
    assert not any(x in value['path'] for x in ['controlled-air-native-capture','source-controlled-zone-numerical-draft','source-CalcMoreNodeInfo-draft'])
    assert value['path'] not in files or files[value['path']]==value
    files[value['path']]=value

for r in [producer_ref,producer['complete_final_compiler_Source_plan'],producer['full4500_parent_readback'],producer['whole4488_Rust_API_census'],producer['original_draft02'],producer['author_Source'],peer_ref,peer['author_Source'],previous_ref,parent_review_ref,inherited_test,ref(OLD),ref(NEW),ref(Path(__file__))]:add(r)
for row in producer['files']:
    for k in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:
        if row[k]:add(row[k])
    for k in ['stdout','stderr']:add(row['Source_only_parse'][k])
for row in producer['Native_authorities']:
    add(row['whole'])
    for e in row['extents']:add(e['source'])
for c in producer['concrete_same_owner_contexts']:add(c['whole'])
for k in ['stdout','stderr','source_snapshot']:add(test[k])

template={
 'schema':'src06-held-canonical26-publication-template.v1','status':'HELD_FOR_ROOT_ACTUAL26_AND_FULL_READ',
 'base_HEAD':producer['base_HEAD'],'producer':producer_ref,'complete_plan':producer['complete_final_compiler_Source_plan'],
 'accepted_independent_peer':peer_ref,'accepted25_actual_review':parent_review_ref,'inherited25_raw_metadata_test':inherited_test,
 'previous_checkpoint':previous_ref,'publisher_Source':ref(NEW),'publisher_parent_Source':ref(OLD),
 'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-purchased-air-initialization-actual-review-26/review.json',
 'pending_Root_custody':{'application':'.runtime/porting/SRC-06/Root-purchased-air-initialization-application-26/receipt.json',
   'actual_review_sha256':'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
   'actual_checker_Source':'.runtime/porting/SRC-06/check-source-purchased-air-initialization-actual-Root-26.py',
   'launcher_Source':'.runtime/porting/SRC-06/launch-purchased-air-initialization-Root-26.py',
   'B_CLI':'.runtime/porting/SRC-06/canonical-source-purchased-air-initialization-B-NOLIMIT-24H-command-Root-26/receipt.json',
   'A24_CLI':'.runtime/porting/SRC-06/canonical-source-purchased-air-initialization-A-24H-command-Root-26/receipt.json'},
 'Root_custody_at_publish':'Actual aggregate/application with their author Sources, launcher, both CLI receipts/output artifacts are byte-authenticated and archived at publish. Independent draft semantic peer plus final whole-unchanged bridge is named honestly; no new full semantic review claim.',
 'summary_template':{'A':'14/54','B':'14/64','changed_Rust_sources':4,'existing_Rust_sources':3,'new_Rust_sources':1,
   'new_test_functions':0,'actual_test_bodies_executed':0,
   'focused_validation_policy':'Two actual CLI runs B then A24; inherited25 RawModel test is explicit prior-checkpoint evidence only. No metadata-test rerun, new test body, repeated cohort or alltargets.',
   'scope':'Genuine retained PurchasedAir Init and ordinary Size path: true per-unit allocations/flags, equipment-list/Config/Node links, live schedule/thermostat/environment reads, genuine NoLimit sizing guards and two real cold sizing fields. Positive unrepresented plenum/diagnostic/Sizer operations remain exact first-operation typed boundaries; Calc/Update/Report and fullB completion unclaimed.',
   'full_B_or_finite15_completion_claim':False,'Native_harness_runtime_or_unit_equivalence_claim':False,'gate_changes':False,'policy_changes':False},
 'doc_appends':{
   'CHECKLIST.md':'IdealLoads 초기화를 실제 장비·노드·일정·환경 소유자에 연결했다. 실행 도달 범위와 A24 회귀 결과는 연결 증거에 기록한다.',
   'STATE_CONTRACTS.md':'유닛별 초기화 배열과 환경·크기 결정 플래그를 같은 PurchasedAir 소유자에 보존한다. 실제 sizing 필드와 thermostat 값을 읽으며, 미구현 Sizer는 실제 호출 지점에서 중단한다.',
   'cards/SRC-06.md':'IdealLoads 초기화의 실행 결과를 기록했다. B의 실제 경계는 `{{actual_B_frontier}}`이며 Calc·Update·Report 및 B 전체 완료는 별도 작업이다.'},
 'finite_archive_inputs':[r for _,r in sorted(files.items())],'finite_archive_input_count':len(files),'finite_archive_input_bytes':sum(r['bytes'] for r in files.values()),
 'publisher_executed':False,'canonical_docs_mutations':False,'Cargo_tests_Native_executed':False,'gate_changes':False}
template_ref=save('publication-template.json',template)
t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal publisher delta>','exec'),ns)
diffs={}
for name,a,b in [('forward',old.encode(),body.encode()),('inverse',body.encode(),old.encode())]:
    delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=OLD.name,tofile=NEW.name)).encode()
    assert ns['apply_literal'](a,delta)==b
    p=OUT/(name+'.diff');p.write_bytes(delta);diffs[name]=ref(p)
bridge=save('publisher-parent-bridge.json',{'parent':ref(OLD),'successor':ref(NEW),'literal_applications':2,'changes':diffs,
 'scope':'Accepted24 two-CLI/zero-test publication engine, with26 paths/base/counts and actual25 proof transfer; explicit inherited25 RawModel test does not assert current snapshot/test execution. Same finite archive/three UTF8 appends/one SRC06 key/gates engine.',
 'publisher_executed':False,'canonical_mutations':False,'actual26_pending':True})
print(json.dumps({'publisher':ref(NEW),'template':template_ref,'parent_bridge':bridge}))

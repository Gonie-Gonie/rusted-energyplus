"""Independent Source26 draft02 Native semantic peer. No main/Cargo/Native run."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
O = D / 'Outer-purchased-air-initialization-Source-review-26'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), sha256=sha(b), bytes=len(b))


def checked(row):
    b = (R / row['path']).read_bytes()
    assert sha(b) == row['sha256'], row['path']
    assert len(b) == row.get('bytes', len(b)), row['path']
    return b


def load(row):
    return json.loads(checked(row))


def save(p, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(b)
    return ref(p)


def main():
    assert not O.exists()
    reviewed = ref(D / 'source-purchased-air-initialization-draft-Peer-26-02/draft.json')
    assert reviewed['sha256'] == '5cd6069b83a4647eeb195ff8342b3b499dee82978050a4eba1870869a9e32f6e'
    m = load(reviewed)
    parent = load(m['parent25'])
    parent_plan = load(parent['complete_final_compiler_Source_plan'])
    entries = {r['path']: r for r in parent_plan['entries']}
    assert len(entries) == 4500 and parent_plan['Rust_sources'] == 4487
    assert (len(m['files']), m['literal_applications'], m['Source_only_parses'], m['new_tests']) == (4, 8, 4, 0)
    assert not m['main_Cargo_or_Native_execution']
    t = ast.parse((D / 'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'))
    f = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply')
    ns = {'re': re}
    exec(compile(ast.Module(body=[f], type_ignores=[]), '<literal>', 'exec'), ns)
    apply = ns['apply']
    files = []
    proposed = {}
    for i, row in enumerate(m['files'], 1):
        path = row['canonical_path']
        before = b'' if row['before'] is None else checked(row['before'])
        after = checked(row['proposed'])
        assert checked(row['literal_inverse']) == before
        if row['before_absent']:
            assert path not in entries and not (R / path).exists() and before == b''
        else:
            assert before == checked(entries[path]['source']) == (R / path).read_bytes(), path
        assert apply(before, checked(row['forward_diff'])) == after
        assert apply(after, checked(row['inverse_diff'])) == before
        added = '\n'.join(x[1:] for x in checked(row['forward_diff']).decode('utf-8').splitlines() if x.startswith('+') and not x.startswith('+++'))
        assert not re.search(r'\.(unwrap|expect)\s*\(|\b(panic|todo|unimplemented|unreachable)!|#\[(test|ignore)', added)
        parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=after, capture_output=True)
        assert parse.returncode == 0, (path, parse.stderr)
        parsed = dict(exit_code=0,
            stdout=save(O / 'parse' / f'{i:02d}.stdout', parse.stdout),
            stderr=save(O / 'parse' / f'{i:02d}.stderr', parse.stderr))
        files.append(dict(canonical_path=path, before=row['before'], proposed=row['proposed'],
            two_literal_applications_exact=True, before_matches_accepted25_plan_and_live=True, fresh_Source_only_parse=parsed))
        proposed[path] = after
    assert sum(r['before_absent'] for r in m['files']) == 1
    init_path = 'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/initialization.rs'
    init = proposed[init_path].decode('utf-8')
    order = [
        'let mut cooling_air_vol_flow_des = 0.0;', 'let mut heating_air_vol_flow_des = 0.0;',
        'let row = self.purchased_unit(unit_number)?;', 'let mut max_heat_vol_flow_rate_des = 0.0;',
        'let mut max_heat_vol_flow_rate_user = 0.0;', 'let mut max_cool_vol_flow_rate_des = 0.0;',
        'let mut max_cool_vol_flow_rate_user = 0.0;', 'let mut max_heat_sens_cap_des = 0.0;',
        'let mut max_heat_sens_cap_user = 0.0;', 'let mut max_cool_tot_cap_des = 0.0;',
        'let mut max_cool_tot_cap_user = 0.0;', 'sizing.zone_heating_only_fan = false;',
        'sizing.zone_cooling_only_fan = false;', 'let comp_type = &row.c_object_name;', 'let comp_name = &row.name;']
    size = init[init.index('fn size_source_purchased_air'):]
    locations = [size.index(s) for s in order]
    assert locations == sorted(locations)

    # Full Native wholes are pinned; literal extents bound every reviewed method/constructor.
    ranges = {
        'src/EnergyPlus/PurchasedAirManager.cc': [(144,205), (1054,1396), (1697,1904)],
        'src/EnergyPlus/PurchasedAirManager.hh': [(390,405)],
        'src/EnergyPlus/DataZoneEquipment.cc': [(1553,1605)],
        'src/EnergyPlus/General.cc': [(981,1002)],
        'src/EnergyPlus/DataSizing.hh': [(1265,1305)],
        'src/EnergyPlus/DataHVACGlobals.hh': [(82,92)],
    }
    native = []
    for name, spans in ranges.items():
        b = (N / name).read_bytes()
        assert b == subprocess.check_output(['git', 'show', PIN + ':' + name], cwd=N)
        lines = b.splitlines(keepends=True)
        extents = []
        for first, last in spans:
            extents.append(dict(first=first, last=last, whole_line_bytes=save(O / 'Native-extents' / f'{Path(name).name}.{first}-{last}.txt', b''.join(lines[first-1:last]))))
        native.append(dict(Native_path=name, whole=save(O / 'Native' / name, b), pinned_Git_exact=True, extents=extents))

    # Independent all-crate caller/member census over accepted25+four proposal wholes.
    terms = ['simulate_source_purchased_air', 'SourcePurchasedAirInitOwners', 'SelectedSizingManager {', 'zone_cooling_only_fan', 'zone_heating_only_fan']
    census = []
    full_census = []
    source_count = 0
    for path in sorted(set(entries) | set(proposed)):
        if not path.startswith('crates/') or not path.endswith('.rs'):
            continue
        b = proposed[path] if path in proposed else checked(entries[path]['source'])
        source_count += 1
        body = b.decode('utf-8')
        found = [term for term in terms if term in body]
        if not found:
            continue
        census.append(dict(path=path, terms=found))
        full_census.append(dict(path=path, sha256=sha(b), bytes=len(b),
            occurrences=[dict(line=i, text=line) for i, line in enumerate(body.splitlines(), 1) if any(term in line for term in found)]))
    assert source_count == 4488 and census == m['API_census']
    assert len(census) == 4
    assert [r['path'] for r in full_census if any('simulate_source_purchased_air' in x['text'] for x in r['occurrences'])] == [
        'crates/ep_runtime/src/heat_balance/ordinary_equipment/management.rs',
        'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air.rs']

    # Authenticate concrete unchanged owner types and flags consumed by new borrows.
    contexts = [
        'crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs',
        'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/owners.rs',
        'crates/ep_runtime/src/heat_balance/selected_heat_balance_globals.rs',
        'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs',
        'crates/ep_runtime/src/weather_day/context.rs',
        'crates/ep_runtime/src/heat_balance/selected_schedule_manager/accessors.rs',
    ]
    context_refs = []
    for path in contexts:
        assert path in entries, path
        b = checked(entries[path]['source'])
        assert b == (R / path).read_bytes(), path
        context_refs.append(dict(canonical_path=path, whole=entries[path]['source']))
    # Preserve the historical unsealed01 ->02 ordering correction as literal bytes only.
    old = D / 'source-purchased-air-initialization-draft-Peer-26/proposed' / init_path
    correction = None
    if old.exists():
        b = old.read_bytes()
        delta = ''.join(difflib.unified_diff(b.decode('utf-8').splitlines(keepends=True), init.splitlines(keepends=True), fromfile='unsealed01/initialization.rs', tofile='draft02/initialization.rs')).encode('utf-8')
        assert apply(b, delta) == proposed[init_path]
        correction = dict(old=ref(old), corrected=next(r['proposed'] for r in m['files'] if r['canonical_path']==init_path),
            exact_diff=save(O / 'unsealed01-to02-initialization-order.diff', delta),
            meaning='Existing unit borrow moved before eight zero assignments and two same-sizing fan writes, exactly Native1373 before1375-1385. Earlier unsealed Source retained; no main apply claim.')
    result = dict(schema='src06-independent-Source26-initialization-draft-semantic-review.v1', accepted=True, findings=[],
        reviewed_draft=reviewed, parent25=m['parent25'],
        scope='Full four-Source draft02 semantic review on accepted25 Source parents; final25 actual/base/compiler join still pending.',
        files=files, literal_applications=8, fresh_Source_only_parses=4,
        Native_commit=PIN, Native_wholes=native, strict_Native_extents=sum(len(r['extents']) for r in native),
        concrete_same_owner_contexts=context_refs, independent_whole_crates_census=dict(Rust_sources=source_count, terms=terms, files=full_census),
        initialization_proof=[
            'Actual manager constructor owns one-time true/list-checked false/three None arrays. Three allocations precede true/true/false whole writes and one-time=false. No duplicated flags or Native primitive allocation-value claim.',
            'Same EquipmentInputsFilled -> checked=true -> actual all-unit loop -> plenum boundary1092 -> real CheckZoneEquipmentList1578..1597 with NumOfZones, optional CtrlZoneNum absent, exact case-insensitive type/name and wildcard semantics.',
            'Actual unit ordinal reference before per-unit flag read/write; same Config inlet/exhaust/return integer arrays and first-match FindNumberInList. Positive missing-inlet/exhaust/multi-return/OA diagnostics stop at genuine first unrepresented Native operations, before unimplemented fallback or warning writes.',
            'Real !SysSizingCalc && retained size flag dispatch; only successful Size return clears same size flag. Same BeginEnvrn/environment flag and StdRhoAir*volflow multiplication order; false/true rearming exact.',
            'Same live thermostat setptHi/Lo, actual schedule current values read in Native order even if availability off; exact comparisons. First severe/recurring diagnostic branches retain truthful typed boundaries.'],
        sizing_proof=[
            'Native1370-1387 order: two 0 locals, actual PurchAir reference, eight real0 locals, real same DataSizing heating=false then cooling=false and copied component name/type. Draft02 order correction independently verified.',
            'Actual CurZoneEqNum gate then genuine ZoneEqSizing row. Positive HVACSizingIndex stops at first DataZoneNumber1396 write; no forced-zero count or bypass.',
            'Ordinary hard-sized/no-zone-sizing/no-positive-sizer route genuinely traverses all four Size sections, actual FieldNames5/6/8 and suffixes, AutoSize=-99999 predicates, Native SmallLoad1.0/order; no surrogate Sizer.',
            'Every positive real Heating/Cooling Flow/Capacity Sizer, FinalZoneSizing read or report/diagnostic remains first-operation unavailable at exact Native branch; same fan fields written before boundaries at1718/1819/1850. No fabricated sized outputs.'],
        caller_proof='One real management caller and one definition across all4488 overlaid crate Sources including runtime/tests; temporary borrows are actual o.sizing/fan/globals/clock/environment, actual controlled ordinal and same mutable schedules. Only two real DataSizing bool ctor fields added. No clone/readiness/cache/alternate owner or public API.',
        unsealed_order_correction=correction,
        remaining_scope='Source entry continues genuine successful Init to actual CalcPurchAirLoads203 typed boundary. No Init/Calc runtime reach, numerical equivalence, final base or full-B completion claimed before Root actual receipts.',
        main_Cargo_tests_Native_or_publication_mutations=False, author_Source=ref(Path(__file__)))
    p = O / 'review.json'
    save(p, (json.dumps(result, ensure_ascii=True, indent=2)+'\n').encode('utf-8'))
    print(json.dumps(ref(p)))


if __name__ == '__main__':
    main()

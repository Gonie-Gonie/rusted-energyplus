"""Apply four reviewed coefficient ownership changes with exact base checks."""
from pathlib import Path
import difflib
import hashlib
import json

root=Path.cwd()
base=root/'.runtime/porting/SRC-06'
manifest_path=base/'ordinary-inside-convection-coefficient-borrow-prep-01/manifest.json'
def digest(data):return hashlib.sha256(data).hexdigest()
def checked(row):
    path=root/row['path'];data=path.read_bytes()
    assert digest(data)==row['sha256'] and len(data)==row['size_bytes'],row['path']
    return data
assert digest(manifest_path.read_bytes())=='dc8fc073e82be6b96dd5e23401195068dcfa20fa216197ebf6f93e87f1c596f6'
manifest=json.loads(manifest_path.read_bytes())
changes=[]
for row in manifest['files']:
    before=checked(row['actual_base'])
    assert checked(row['before_archive'])==before
    after=checked(row['proposed'])
    diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=row['canonical_path'],tofile=row['canonical_path'])).encode()
    assert diff==checked(row['direct_diff'])
    changes.append((row,after))
originals={}
for row in manifest['Original_ranges']:
    path=row['Original']['path']
    if path not in originals:originals[path]=checked(row['Original'])
    literal=b''.join(originals[path].splitlines(True)[row['first_line']-1:row['last_line']])
    assert literal==checked(row['literal_archive'])
out=base/'ordinary-inside-convection-borrow-application-01.json'
assert not out.exists()
for row,data in changes:(root/row['canonical_path']).write_bytes(data)
out.write_bytes((json.dumps({'schema':'src06-inside-convection-borrow-application.v1','preparation':{'path':manifest_path.relative_to(root).as_posix(),'sha256':digest(manifest_path.read_bytes())},'changed_paths':[row['canonical_path']for row,_ in changes],'Original_ranges_checked':3,'calculation_or_test_body_count_changed':False,'ordinary_dispatcher_activated':False,'gates_updated':False},indent=2)+'\n').encode())
print('Applied four Source-reviewed sole-coefficient ownership changes.')

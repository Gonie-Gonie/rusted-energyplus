"""Archive bounded ownership refactor and actual focused QA; keep gates unchanged."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess
import zipfile

root=Path.cwd()
base=root/'.runtime/porting/SRC-06'
out=root/'energyplus_porting_plan/evidence/SRC-06-ordinary-inside-convection-borrow'
assert not out.exists()
def write(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path):return json.loads(path.read_bytes())
artifacts={}
def add(path):
    row=ref(path)
    assert row['size_bytes']<=10*1024*1024
    artifacts[row['path']]=row
def checked(row):
    path=root/row['path'];actual=ref(path)
    assert actual['sha256']==row['sha256'],row['path']
    assert actual['size_bytes']==row.get('size_bytes',actual['size_bytes']),row['path']
    return path
def gather(value):
    if isinstance(value,dict):
        if 'path'in value and 'sha256'in value:add(checked(value))
        else:
            for item in value.values():gather(item)
    elif isinstance(value,list):
        for item in value:gather(item)
prep=base/'ordinary-inside-convection-coefficient-borrow-prep-01/manifest.json'
assert ref(prep)['sha256']=='dc8fc073e82be6b96dd5e23401195068dcfa20fa216197ebf6f93e87f1c596f6'
manifest=load(prep);add(prep);gather(manifest['README'])
review=base/'Header-ordinary-inside-convection-coefficient-borrow-review-01/review.json'
assert load(review)['accepted']is True
add(review);gather(load(review))
qa=[]
for name,argv in [
 ('fmt',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','fmt','--all','--','--check']),
 ('source-quality',['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1']),
 ('clippy',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','clippy','--workspace','--all-targets','--','-D','warnings']),
 ('tests',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','test','-p','ep_runtime','--lib','heat_balance::inside_convection_dispatcher::tests::']),
]:
    path=base/f'ordinary-inside-convection-borrow-{name}-01/receipt.json';data=load(path)
    assert data['command']==argv and data['exit_code']==0 and data['launch_error']is None
    assert data['source_bytes_match_before_and_after']is True
    qa.append(ref(path));add(path)
    for key in ['source_snapshot','stdout','stderr']:gather(data[key])
source=load(checked(qa[-1]))['source_snapshot']
assert all(load(checked(row))['source_snapshot']==source for row in qa)
stdout=checked(load(checked(qa[-1]))['stdout']).read_text(encoding='utf8')
assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)==[('8','0','0')]
changes=[]
diff_dir=base/'ordinary-inside-convection-borrow-final-diffs-01'
diff_dir.mkdir(exist_ok=False)
for row in manifest['files']:
    path=root/row['canonical_path'];add(path)
    for key in ['before_archive','proposed','direct_diff']:gather(row[key])
    before=subprocess.check_output(['git','show','HEAD:'+row['canonical_path']],cwd=root)
    assert before==checked(row['before_archive']).read_bytes()
    after=path.read_bytes()
    if path.name=='tests.rs':assert before.count(b'#[test]')==after.count(b'#[test]')==8
    diff=diff_dir/(path.name.replace('.rs','')+'-'+str(len(changes))+'.diff')
    diff.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='HEAD/'+row['canonical_path'],tofile=row['canonical_path'])).encode())
    add(diff);changes.append({'canonical':ref(path),'complete_final_diff':ref(diff)})
gather(manifest['Original_ranges'])
for name in ['ordinary-inside-convection-borrow-application-01.json','apply-inside-convection-borrow-Root-01.py']:add(base/name)
add(Path(__file__))
assert sum(row['size_bytes']for row in artifacts.values())<15*1024*1024
out.mkdir()
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as zipped:
    for name in sorted(artifacts):zipped.write(checked(artifacts[name]),name)
with zipfile.ZipFile(archive)as zipped:
    assert zipped.testzip()is None and set(zipped.namelist())==set(artifacts)
    for name in zipped.namelist():
        data=zipped.read(name)
        assert hashlib.sha256(data).hexdigest()==artifacts[name]['sha256'] and len(data)==artifacts[name]['size_bytes']
write(out/'manifest.json',{'schema':'src06-inside-convection-borrow-evidence.v1','Source_snapshot':source,'changes':changes,'artifacts':list(artifacts.values()),'archive':ref(archive),'archive_member_count':len(artifacts),'gates_updated':False})
summary={'schema':'src06-inside-convection-borrow-summary.v1','status':'Sole caller-owned HConv storage implemented; ordinary activation and full port incomplete','Source_snapshot':source,'QA':qa,'tests':{'selected_existing_bodies':8,'passed':8,'failed':0,'new_bodies':0,'new_binaries':0},'behavior':['Dispatcher retains only convection metadata; actual coefficient storage is borrowed','Runtime setter writes the sole SurfaceHeatBalanceState coefficient directly','Full coefficient count and ordered Surface IDs validated before setup/backend/Config/output writes','Selected example keeps its original scalar inputs and JSON schema with one external array'],'limitations':['No formula or cadence change; no new Native numerical comparison','Whole InitSurface/Setup and ordinary dispatcher activation still held','All SRC-06 gates and A14/54 B14/64 unchanged'],'validation_scope':'All-target workspace Clippy plus existing eight dispatcher tests; previous4a34c965 whole workspace4974/0/2 retained, not rerun for this bounded ownership refactor','independent_Source_review':ref(review),'manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False}
write(out/'summary.json',summary)
plan_path=root/'energyplus_porting_plan/plan.json'
plan=load(plan_path);task=next(row for row in plan['tasks']if row['id']=='SRC-06')
assert all(task[key]=='미확인'for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_inside_coefficient_borrow'not in task
task['actual_selected_ordinary_inside_coefficient_borrow']=ref(out/'summary.json')
write(plan_path,plan)
card=root/'energyplus_porting_plan/cards/SRC-06.md'
text=card.read_text(encoding='utf8')
text+='\n## 실내 대류 계수의 단일 저장소\n\nDispatcher는 convection metadata만 보존하고 실제 SurfHConvInt는 호출자의\n열수지 저장소를 대여해 직접 쓴다. Runtime은 SurfaceHeatBalanceState의 기존\n계수에 쓰며 중복 coefficient 또는 copy-back은 없다. 전체 계수 배열의 개수와\n순서별 Surface ID를 setup·backend·Config·계수 변경 전에 검증한다. 기존 선택\nexample은 입력 scalar와 JSON schema를 유지하며 하나의 외부 계수 배열을 쓴다.\n\n기존 8개 테스트를 유지하고, 연결 검사 표에 empty/stale/reordered/extra 계수\n거부와 실패 후 소유자 보존을 추가했다. 최종 Source `'+source['sha256']+'`에서\nfmt, source-quality, all-target workspace Clippy(-D warnings), 관련 8개 테스트가\n통과했다. 같은 작업에서 직전4a34c965의 전체4,974 passed/0 failed/ignored2\n검증을 보존하고, 이 네 파일의 저장소 정리를 위해 전체 테스트를 중복 실행하지\n않았다. 수식·cadence 변경이나 새 Native 수치 동등성은 주장하지 않는다.\n\n[계수 저장소 검증 요약](../evidence/SRC-06-ordinary-inside-convection-borrow/summary.json),\n[색인](../evidence/SRC-06-ordinary-inside-convection-borrow/manifest.json),\n[전체 검증 기록](../evidence/SRC-06-ordinary-inside-convection-borrow/evidence.zip)에\n실제 변경과 Original 구간, 독립 Source 검토 및 QA를 보존한다. 전체 InitSurface/\nSetup 호출 연결과 ordinary dispatcher 활성화는 계속 구현 중이다. SRC-06 네 gate와\nA14/54, B14/64는 유지한다.\n'
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'members':len(artifacts)},ensure_ascii=False))

"""Join accepted real endrun children on exact Source78, without activation."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'ordinary-complete-endrun-caller-held-Outer-01';assert not OUT.exists()
for n in ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')).body:
    if isinstance(n,ast.FunctionDef) and n.name in ('ref','apply_literal'):
        exec(compile(ast.Module([n],type_ignores=[]),'custody','exec'),globals())
P=D/'ordinary-provider-assembly-Root-78/manifest.json';assert ref(P)['sha256']=='28310f642f9dd51a2a535598e9b271b490c84514868405f3a021bc33f1a97cc1'
M=json.loads(P.read_bytes());W=ROOT/M['workspace'];N=ROOT/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def run(a,cwd=ROOT,required=True):
    p=subprocess.run(a,cwd=cwd,capture_output=True)
    if required:assert p.returncode==0,(a,p.stderr)
    return p
BASE=run(['git','rev-parse','HEAD']).stdout.decode().strip()
name='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';pb=(W/name).read_bytes();s=pb.decode('utf8');edits=[]
def replace(old,new):
    global s
    assert s.count(old)==1,old;s=s.replace(old,new,1);edits.append((old,new))
replace('//! Genuine ManageSimulation566-596 prefix; later tabular report children remain bounded.','//! Genuine ManageSimulation566-620 endrun caller on the same retained owners.')
replace('''    /// Continue on the original owners after Primary564, through the actual596 predefined prefix.
    /// Does not replay the primary Warmup=false writer, construct/reset a PSY
    /// scope or local owner, or close any file. Actual594 opens the same TAB files.''','''    /// Continue on the original owners after Primary564 through actual620.
    /// Does not replay the primary Warmup=false writer or construct/reset a PSY
    /// scope or simulation local. Actual594 opens and602 closes the same TAB files.''')
replace('''    /// Preserves each typed child cause and all preceding effects. Positive SQL
    /// sqliteBegin582 remains unavailable. Actual596 preserves each genuine child
    /// cause and stops at the next unported operation in Source order.''','''    /// Preserves each typed child cause and all preceding effects. Positive SQL
    /// sqliteBegin582 remains unavailable. Represented children execute through
    /// their real completion, including physical output closure606 and final620.''')
outer_old='''        self.write_source_tabular_reports_prefix_on_session(session, reports, weather, backend)
'''
outer_new='''        self.write_source_tabular_reports_prefix_on_session(session, reports, weather, backend)?;
        // The Native children below are outside WriteTabularReports and run
        // after its unconditional audit suffix, even if WriteTabularFiles=false.
        let session = required(session.as_mut(), "actual same session before tariff reports598")?;
        let globals = required(
            reports.selected_heat_balance_globals.as_ref(),
            "actual same Globals before tariff reports598",
        )?;
        let project = required(
            reports.selected_project_data.as_ref(),
            "actual same SysVars before outer endrun598",
        )?;
        reports.economic_tariff.write_source_tabular_tariff_reports(
            &mut session.tabular,
            globals,
            required(
                reports.selected_zone_input.as_ref(),
                "actual same Zones before tariff floor-area prerequisite598",
            )?,
            &mut *backend,
            &SourceDiagnosticFlags {
                kickoff: &globals.kickoff_simulation,
                developer: &project.system.developer_flag,
                warmup: &weather.state.global.warmup_flag,
                doing_sizing: &globals.doing_sizing,
            },
        ).map_err(hb_input_error)?;
        reports.source_life_cycle_cost.compute_source_life_cycle_cost_and_report(
            &mut *backend,
            &SourceDiagnosticFlags {
                kickoff: &globals.kickoff_simulation,
                developer: &project.system.developer_flag,
                warmup: &weather.state.global.warmup_flag,
                doing_sizing: &globals.doing_sizing,
            },
        ).map_err(hb_input_error)?;
        session.tabular.close_source_tabular_files().map_err(hb_input_error)?;
        session.hvac.dump_source_air_loop_statistics(&project.system).map_err(hb_input_error)?;
        self.close_source_output_files(
            &mut crate::heat_balance::source_initialization::SourceCloseOutputFilesOwners {
                registration: &reports.output_registration,
                tabular: &session.tabular,
                solar: required(
                    reports.ordinary_solar_radiation.as_ref(),
                    "actual same SolarShading before CloseOutputFiles606",
                )?,
                geometry: &reports.surface_geometry_input,
                system: &project.system,
                prescan: &reports.output_prescan,
                runtime_language: &required(
                    reports.selected_simulation_startup.as_ref(),
                    "actual same RuntimeLanguage before CloseOutputFiles606",
                )?.runtime_language,
                connections: &session.hvac.ancillary.branch_node_connections,
                heat_balance: &reports.heat_balance_input_state,
                standard_output_record_count: &reports.source_standard_output_record_count,
                standard_meter_record_count: &reports.source_standard_meter_record_count,
                shading_stream: &mut session.shading_stream,
                output_control: &reports.source_output_control,
            },
        ).map_err(hb_input_error)?;
        // Actual609 child first tests this same database pointer. Null has no
        // further reads/effects; positive first needs its real DB predicate.
        if reports.source_sqlite.present() {
            return Err(unavailable(
                "actual CreateSQLiteZoneExtendedOutput167 sqlite.writeOutputToSQLite predicate",
            ));
        }
        if reports.source_sqlite.present() {
            backend.display_source_string(
                "Writing final SQL reports",
                &SourceDiagnosticFlags {
                    kickoff: &globals.kickoff_simulation,
                    developer: &project.system.developer_flag,
                    warmup: &weather.state.global.warmup_flag,
                    doing_sizing: &globals.doing_sizing,
                },
            ).map_err(hb_input_error)?;
            return Err(unavailable(
                "actual final SQL sqliteCommit613 before initializeIndexes614",
            ));
        }
        // The actual SimulationManager179 ErrorsFound cell is retained by
        // this same WeatherSession across prelude, Setup and Primary. It is
        // distinct from HeatBalance's separate input ErrorsFound member.
        if weather.errors_found {
            return match backend.show_fatal_error(
                "Error condition occurred.  Previous Severe Errors cause termination.",
            ) {
                Ok(never) => match never {},
                Err(stop) => Err(hb_input_error(HeatBalanceInputError::Fatal(stop))),
            };
        }
        Ok(()) // Genuine ManageSimulation620, after all real preceding children.
'''
replace(outer_old,outer_new)
replace('''    /// Returns the actual typed prefix child failure, including the actual next tabular child boundary.''','''    /// Returns the actual typed child failure or genuine successful endrun620.''')
replace('''    // Actual WriteTabularReports5212-5227 on the same retained owners. The
    // existing outer on-session call already holds the single weather borrow.''','''    // Actual WriteTabularReports5212-5295 on the same retained owners. The
    // outer on-session call already holds the single real weather borrow.''')
period_old='''            if weather.state.global.do_weath_sim {
                return Err(unavailable("actual WriteTabularReports5270 WriteMonthlyTables entry"));
            }
        }
        Err(unavailable("actual WriteTabularReports5278 audit ensure_open entry"))
'''
period_new='''            if weather.state.global.do_weath_sim {
                session.tabular.write_source_monthly_tables().map_err(hb_input_error)?;
                session.tabular.write_source_time_bin_tables().map_err(hb_input_error)?;
                session.tabular.write_source_annual_tables().map_err(hb_input_error)?;
            }
        }
        session.tabular.write_source_tabular_audit(
            self,
            &reports.source_output_control,
            &reports.registry,
            &reports.table,
        ).map_err(hb_input_error)?;
        Ok(())
'''
replace(period_old,period_new)
a=s.encode();recovered=s
for old,new in reversed(edits):assert recovered.count(new)==1;recovered=recovered.replace(new,old,1)
assert recovered.encode()==pb
# The two code changes are exact tail extensions. All preceding runtime code
# retains its complete original bytes, including actual5230-5267 sequencing.
assert a.count(b'#[test]')==pb.count(b'#[test]')
OUT.mkdir()
def put(n,b):
    p=OUT/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(n,o):return put(n,(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode())
gp=run(['git','show',BASE+':'+name]);before=gp.stdout
row=dict(canonical_path=name,canonical_at_base_revision=put('before/'+name,before),canonical_base_revision=BASE,live_observation=ref(ROOT/name),live_observation_frozen=put('live-observation/'+name,(ROOT/name).read_bytes()),before=ref(OUT/'before'/name),literal_inverse=put('literal-inverse/'+name,before),parent_source=ref(W/name),parent_before=put('parent-before/'+name,pb),literal_parent_inverse=put('literal-parent-inverse/'+name,pb),proposed=put('proposed/'+name,a))
apps=[]
for x,y,k,l,r in [(before,a,'complete_forward_diff','GitBase','proposed'),(a,before,'complete_inverse_diff','proposed','GitBase'),(pb,a,'parent_forward_diff','Root78','proposed'),(a,pb,'parent_inverse_diff','proposed','Root78')]:
    patch=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=l+'/'+name,tofile=r+'/'+name)).encode();assert apply_literal(x,patch)==y
    row[k]=put('diffs/'+k+'.diff',patch);apps.append(dict(path=name,role=k,literal_application_passed=True))
put('Git/'+name,gp.stdout);put('Git/'+name+'.stderr',gp.stderr)
cmd=['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(OUT/'proposed'/name)];p=run(cmd);assert (OUT/'proposed'/name).read_bytes()==a
parse=doc('Source-only-parse.json',dict(command=cmd,exit_code=p.returncode,stdout=put('parse.stdout',p.stdout),stderr=put('parse.stderr',p.stderr),proposed_bytes_unchanged=True))
prereq_specs=[
('ordinary-outer-endrun-leaves-held-Outer-01/manifest.json','bd9814548458cd018c45dbdc46bc92ad6a83af385d675464a8f49a149137c6f1','Peer-ordinary-outer-endrun-leaves-Source-review-01/review.json','7648ec1d7f09082a8df39ec2ec397af3595f223beaaf4fca7a529941ec16eb14'),
('ordinary-tabular-audit-held-Outer-01/manifest.json','7fc5dc023047d0e4803b0b9b498479d97614a3d1d47a179a411a855ee8a46a41','Root-ordinary-tabular-audit-Source-review-01/review.json','2d5f5260c04a026a04b7441ddfb2e4df30cb009af6dfbe177a46f995401ed9d8'),
('ordinary-periodic-reports-held-Audit-03/manifest.json','347387','Peer-ordinary-periodic-reports-Source-review-02/review.json','cb91444fbf83eeb3f6be1c23d1e8615446429e73d9ea41ccb9a8799153888f87'),
('ordinary-close-output-files-held-Outer-01/manifest.json','da9b58e750cb8948b6fe8554a974afb491671df2522c27c5e8549333e81dec66','Peer-ordinary-close-output-files-Source-review-01/review.json','a20b331e982c4e8b41306f6f04d2dedfbb42ea55106da1721c9eb72815a0ca66')]
prereqs=[]
for mf,msha,rv,rsha in prereq_specs:
    mp=D/mf;rp=D/rv;assert ref(mp)['sha256'].startswith(msha) and ref(rp)['sha256']==rsha
    rm=json.loads(rp.read_bytes());assert rm.get('accepted') is True or str(rm.get('decision','')).startswith('ACCEPTED') or 'ACCEPTED' in str(rm.get('status',''))
    prereqs.append(dict(manifest=ref(mp),independent_review=ref(rp)))
adapter=D/'ordinary-output-text-mode-held-Outer-02/manifest.json';assert ref(adapter)['sha256']=='0dac8f21b299766251f20c2a74f61e94c1dfd2e411b8dd1ef30b7bd46cbed7ec'
ranges=[('SimulationManager.cc',175,181),('SimulationManager.cc',594,620),('OutputReportTabular.cc',5265,5296),('SQLiteProcedures.cc',166,174),('EconomicTariff.cc',4101,4116),('EconomicLifeCycleCost.cc',119,138),('HVACControllers.cc',1998,2024)]
originals=[];ng=[];seen=set()
for n,first,last in ranges:
    p=N/'src/EnergyPlus'/n;b=p.read_bytes();ls=b.splitlines(keepends=True);assert 1<=first<=last<=len(ls)
    if n not in seen:
        assert run(['git','show',PIN+':src/EnergyPlus/'+n],cwd=N).stdout==b;seen.add(n);ng.append(dict(source=ref(p),revision=PIN,actual_whole_stdout_equal=True))
    originals.append(dict(source=ref(p),first_line=first,last_line=last,literal_excerpt=put('Original/'+n.replace('/','__')+f'-{first}-{last}.txt',b''.join(ls[first-1:last])),strict_EOF=True))
reads=[ref(W/n) for n in ['crates/ep_runtime/src/heat_balance/ordinary_source_simulation/primary_host.rs','crates/ep_runtime/src/heat_balance/ordinary_source_simulation/prelude.rs','crates/ep_runtime/src/heat_balance/ordinary_source_simulation/setup_host.rs','crates/ep_runtime/src/heat_balance/source_initialization/output_reporting.rs','crates/ep_runtime/src/heat_balance/ordinary_life_cycle_cost/endrun.rs','crates/ep_runtime/src/heat_balance/ordinary_source_session.rs','crates/ep_runtime/src/heat_balance/error_backend.rs']]
proof=doc('same-owner-full-order-proof.json',dict(
whole_prior_prefix={'parent':ref(W/name),'literal_edit_inverse':True,'exact_literal_edits':edits,'semantic_body_changes':'only two prior terminal boundaries extended; all earlier operational statements recovered whole byte exact'},
actual_tabular_order=['same real DoWeathSim guard5269','Monthly5270 on same session.tabular','TimeBins5271 on same session.tabular','Annual5272 on same session.tabular','exit real WriteTabularFiles block5274','unconditional same File/TAB/registry/table audit5278-5294','return child5295'],
actual_outer_order=['await actual WriteTabularReports596 completion including unconditional audit','Tariff598 real conditioned-floor-area prerequisite before real numTariff count','same existing LCC600 with actual parameters_present and live diagnostic refs','CloseTAB602 same physical five ordinal streams','HVACstats604 live same TRACK_AIRLOOP flag, true bound at actual file open','CloseOutputFiles606 same13owners and real i64 OP record counter refs','CreateSQLiteZoneExtendedOutput609 same real nullable pointer, positive first DB.writeOutputToSQLite predicate bound','outerSQL611 same pointer; live Display612 before actual sqliteCommit613 typed bound; initializeIndexes614 not claimed if commit fails/unrepresented','same WeatherSession.errors_found617 and original fatal618 if true','genuine successful return620 if all children complete and final errorflagfalse'],
actual_close_owner_mapping={'registration':'reports.output_registration','tabular':'session.tabular','solar':'reports.ordinary_solar_radiation','geometry':'reports.surface_geometry_input','system':'reports.selected_project_data.system','prescan':'reports.output_prescan','runtime_language':'reports.selected_simulation_startup.runtime_language','connections':'session.hvac.ancillary.branch_node_connections','heat_balance':'reports.heat_balance_input_state','standard_output_record_count':'reports.source_standard_output_record_count i64 actual writer-owned cell','standard_meter_record_count':'reports.source_standard_meter_record_count i64 actual writer-owned cell','shading_stream':'session.shading_stream','output_control':'reports.source_output_control'},
final_errors_found={'owner':'weather.errors_found is actual SimulationManager179 caller local retained in same WeatherSession','prior_usage':'prelude and primary/setup hosts reborrow/read same actual cell; distinct from HeatBalance input ErrorsFound','fatal':'direct actual SourceErrorBackend.show_fatal_error exact string, genuine Infallible success type matched; typed fatal cause preserved via hb_input_error, no fabricated RuntimeError label'},
temporary_borrows={'reborrow':'after596 mutable reports call returns, shadow/reborrow existing actual globals/project/session references; no old reference retained across aliasing reports mutation','diagnostics':'fresh short SourceDiagnosticFlags struct stores references to same kickoff/developer/warmup/doing_sizing fields, backend mutably reborrowed per call','no_new_simulation_or_persistent_local':True,'no_ctor_default_reset_clone_or_numeric_mirror':True},
SQL_scope={'no_option_proxy':'never uses OutputControl.sqlite/results/database filename as nullable pointer substitute','positive_boundaries':'609 actual writeOutputToSQLite predicate is first positive unrepresented operation; outer611 truthful direct Display before sqliteCommit613 bound. No database truth result or index creation is synthesized','null':'represented constructor-null same pointer performs no reads of zones/schedules/surfaces/DB options and proceeds in actual order'},
completion_scope={'method_names':'existing prefix-named public APIs retained to avoid changing unrelated callers; their represented endrun now actually returns620','engine':'this leaf does not activate canonical Source runtime result/export conversion, relax any tolerance, construct expected answers or assert wholeengine/Owner/Numeric gates','not_arbitrary_prefix':'successful endrun620 is actual Native function return after all represented children; no replacement final unavailable marker is inserted here'}))
manifest=doc('manifest.json',dict(schema='src06-held-complete-endrun-caller.v1',status='HELD full represented ManageSimulation566-620 caller; independent peer/union compilation/actual full physical run still required',base_HEAD=BASE,parent=ref(P),files=[row],accepted_prerequisites=prereqs,optional_API_unchanged_text_adapter=ref(adapter),Original_commit=PIN,Original_authority=originals,actual_readonly_Native_Git=ng,actual_historical_base_Git=dict(revision=BASE,exit_code=gp.returncode,stdout=ref(OUT/'Git'/name),stderr=ref(OUT/'Git'/(name+'.stderr'))),read_only_existing_Source_APIs=reads,same_owner_full_order_proof=proof,Source_only_parse=parse,literal_diff_applications=apps,author_Source=ref(Path(__file__).resolve()),scope={'one_existing_Source_only':True,'whole_parent_recovered':True,'new_test_bodies':0,'new_simulation_locals':0,'new_persistent_owners':0,'replayed_input_getters':0,'canonical_Source_pipeline_activation':False,'actual_callers_complete_through620':True,'runtime_execution_or_gate_PASS_claim':False},canonical_changes=0,Git_mutations=0,Cargo_or_Native_executed=False))
print(json.dumps(manifest))

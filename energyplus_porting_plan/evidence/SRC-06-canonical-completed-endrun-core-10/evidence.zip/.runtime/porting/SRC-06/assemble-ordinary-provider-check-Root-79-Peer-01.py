"""Guarded Source79 full-endrun composition; do not execute before Root approval.
Retains the failed78 comparison. No canonical/Cargo/Native/test/Git mutation.
"""
from pathlib import Path
import argparse,ast,difflib,hashlib,json,os,re,shutil,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'.runtime/porting/SRC-06'
OUT=B/'ordinary-provider-assembly-Root-79';PARENT=B/'ordinary-provider-assembly-Root-78/workspace'
HEAD='1b318404eabf128ef5eca0a0e90fb2557cb7cd5b'
p=argparse.ArgumentParser();p.add_argument('--assemble-approved79',action='store_true')
for n in ['ihg-review','ihg-review-sha256','caller-review','caller-review-sha256']:p.add_argument('--'+n,required=True)
args=p.parse_args();assert args.assemble_approved79
for h in [args.ihg_review_sha256,args.caller_review_sha256]:assert re.fullmatch('[0-9a-f]{64}',h)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
tree=ast.parse((B/'assemble-ordinary-provider-check-Root-71-Fix-01.py').read_bytes())
for definition in [n for n in tree.body if isinstance(n,ast.FunctionDef)]:exec(compile(ast.Module(body=[definition],type_ignores=[]),'<pure-transport>','exec'))
mp=B/'ordinary-provider-assembly-Root-78/manifest.json';assert ref(mp)['sha256']=='28310f642f9dd51a2a535598e9b271b490c84514868405f3a021bc33f1a97cc1'
checkp=PARENT/'.runtime/porting/SRC-06/provider-assembly-all-targets-command-78/receipt.json'
clip=PARENT/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-78/receipt.json'
assert ref(checkp)['sha256']=='520b3e3caa7f7dac272c65b31e37d857d118d381b285323867d3a263881194ca'
assert ref(clip)['sha256']=='7a55f01e48ec65b641f23f7376149e3d29f7e77bd802d88d1f2eae183e413ebc'
check=json.loads(checkp.read_bytes());cli=json.loads(clip.read_bytes())
assert check['exit_code']==0 and cli['exit_code']==6 and check['source_bytes_match_before_and_after'] and cli['source_bytes_match_before_and_after']
assert check['source_snapshot']==cli['source_snapshot']
frontier=B/'through-primary-diagnostic-A-24H-Root-78/output/eplusrs.err';assert b'actual WriteTabularReports5270 WriteMonthlyTables entry' in frontier.read_bytes()
comparisonp=B/'Root-actual-tabular78-five-format-comparison-01/comparison.json'
assert ref(comparisonp)['sha256']=='4060a8af2e02dbe4b6d075be81d9ea4c07525d2ba3e920e71f18fba34ff27500'
snapshot=PARENT/cli['source_snapshot']['path'];assert ref(snapshot)['sha256']==cli['source_snapshot']['sha256']
si=json.loads(snapshot.read_bytes());assert not si['bytes_normalized'];expected={e['historical_path']:e for e in si['files']};assert len(expected)==len(si['files'])==4461
specs=[
 ('IHG','ordinary-ihg-lighting-total-producer-held-Peer-01','a03ec8574904f7d68df0da99ff8d710339f2a25e71d37415b32a275e064d272b',ROOT/args.ihg_review,args.ihg_review_sha256,2),
 ('Periodic','ordinary-periodic-reports-held-Audit-03','347387d2e13115beef23707ab3fcdcbe03e87d990ae09f27f6bc05750fcee385',B/'Peer-ordinary-periodic-reports-Source-review-02/review.json','cb91444fbf83eeb3f6be1c23d1e8615446429e73d9ea41ccb9a8799153888f87',2),
 ('Audit','ordinary-tabular-audit-held-Outer-01','7fc5dc023047d0e4803b0b9b498479d97614a3d1d47a179a411a855ee8a46a41',B/'Root-ordinary-tabular-audit-Source-review-01/review.json','2d5f5260c04a026a04b7441ddfb2e4df30cb009af6dfbe177a46f995401ed9d8',5),
 ('Outer','ordinary-outer-endrun-leaves-held-Outer-01','bd9814548458cd018c45dbdc46bc92ad6a83af385d675464a8f49a149137c6f1',B/'Peer-ordinary-outer-endrun-leaves-Source-review-01/review.json','7648ec1d7f09082a8df39ec2ec397af3595f223beaaf4fca7a529941ec16eb14',6),
 ('Close','ordinary-close-output-files-held-Outer-01','da9b58e750cb8948b6fe8554a974afb491671df2522c27c5e8549333e81dec66',B/'Peer-ordinary-close-output-files-Source-review-01/review.json','a20b331e982c4e8b41306f6f04d2dedfbb42ea55106da1721c9eb72815a0ca66',9),
 ('Text','ordinary-output-text-mode-held-Outer-02','0dac8f21b299766251f20c2a74f61e94c1dfd2e411b8dd1ef30b7bd46cbed7ec',B/'Audit-ordinary-output-text-mode-Source-review-01/review.json','4af268edda4f694da448307bd978d25024658b1476770cc26de45121546cc306',1),
 ('Caller','ordinary-complete-endrun-caller-held-Outer-01','6b699736e692e30e1353b69c5bd95f520a72e02e4c829bdd3a4c47e9b539b517',ROOT/args.caller_review,args.caller_review_sha256,1),
]
staged=[];packets=[];peers=[]
for role,name,h,peer,ph,count in specs:
 packet=B/name/'manifest.json';assert ref(packet)['sha256']==h and ref(peer)['sha256']==ph
 m=json.loads(packet.read_bytes());j=json.loads(peer.read_bytes())
 assert j.get('accepted',str(j.get('decision','')).startswith('ACCEPTED')) and not j.get('findings',[])
 assert j.get('manifest',j.get('preparation_manifest',j.get('reviewed_manifest')))==ref(packet),(role,peer)
 assert len(m['files'])==count
 staged.append((role,packet,peer,m));packets.append(ref(packet));peers.append(ref(peer))
assert not OUT.exists()
selected={};apps=[];composition=[];canonical_before={};joins=[]
tab='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports.rs'
filepath='crates/ep_runtime/src/heat_balance/source_initialization/files.rs'
post=b'\nmod post_summary;\npub(crate) use post_summary::SourceSurfaceShadowingReportOwners;\n'
pre=b'\nmod predefined_report;\npub(crate) use predefined_report::SourcePredefinedReportOwners;\n'
res=b'\nmod resilience_report;\npub(crate) use resilience_report::SourceResilienceTableOwners;\n'
period=b'\nmod periodic_reports;\n'
for role,packet,peer,m in staged:
 for row in m['files']:
  n=row['canonical_path'];c,a,z=read(row['before']),read(row['parent_before']),read(row['proposed'])
  assert read(row['literal_inverse'])==c and read(row['literal_parent_inverse'])==a
  assert a.count(b'#[test]')==z.count(b'#[test]')
  canonical_before.setdefault(n,None if not(ROOT/n).exists() else ref(ROOT/n))
  for fk,ik,base in [('complete_forward_diff','complete_inverse_diff',c),('parent_forward_diff','parent_inverse_diff',a)]:
   assert apply(base,read(row[fk]))==z and apply(z,read(row[ik]))==base
   apps.extend([dict(path=n,packet_role=role,role=k,pass_literal_application=True) for k in [fk,ik]])
  original=(PARENT/n).read_bytes() if n in expected else b''
  if n not in expected:assert not(PARENT/n).exists()
  current=selected[n]['after'] if n in selected else original
  application='Exact accepted whole proposal on byte-identical composed parent'
  joined=False
  if n==tab and role=='Periodic':
   assert current.count(post)==1 and current.replace(post,b'',1)==a and z==a+period
   merged=current+period;joined=True;application='Append only23byte periodic module suffix while preserving accepted84byte PostSummary suffix absent from the historical resilience parent'
  elif n==tab and role=='Audit':
   assert current==a+pre+res+period
   old=b'mod output_files;\n';new=old+b'mod audit;\n'
   assert a.count(old)==1 and z==a.replace(old,new,1) and current.count(old)==1
   merged=current.replace(old,new,1);joined=True;application='Exact one-line audit module insertion; retain whole Predefined/resilience/periodic suffixes'
  elif n==tab and role=='Outer':
   assert current.count(b'mod audit;\n')==1 and current.replace(b'mod audit;\n',b'',1)==a+pre+res+period
   old=b'mod output_files;\n';new=old+b'mod endrun_files;\n'
   assert a.count(old)==1 and z==a.replace(old,new,1) and current.count(old)==1
   merged=current.replace(old,new,1);joined=True;application='Exact one-line endrun_files module insertion; retain audit declaration and all three accepted later suffixes'
  elif n==filepath and role=='Text':
   assert a==(PARENT/n).read_bytes()
   proof=json.loads(read(m['mode_owner_and_writer_proof']))
   merged=current;reproduced=a
   for old,new in proof['whole_parent_recovery']['edits']:
    aa,bb=old.encode(),new.encode();assert merged.count(aa)==1 and reproduced.count(aa)==1
    merged=merged.replace(aa,bb,1);reproduced=reproduced.replace(aa,bb,1)
   assert reproduced==z
   recovered=merged
   for old,new in reversed(proof['whole_parent_recovery']['edits']):
    aa,bb=old.encode(),new.encode();assert recovered.count(bb)==1;recovered=recovered.replace(bb,aa,1)
   assert recovered==current
   joined=True;application='Only the two accepted Write methods transplanted literally onto exact Audit then Close606 composed file; entire prior module/export/observer/EIO prefix retained unchanged'
  else:assert current==a,(role,n,sha(current),sha(a));merged=z
  assert b'\r' not in merged
  if joined:joins.append(dict(path=n,packet_role=role,before=current,after=merged,explanation=application))
  stage=dict(path=n,packet_role=role,packet=ref(packet),peer=ref(peer),packet_parent_before=row['parent_before'],packet_proposed=row['proposed'],current_composed_before_sha256=sha(current),merged_sha256=sha(merged),application=application,normalization='none',conflicts=0,historical_current_alias_not_queried=True)
  if n not in selected:selected[n]=dict(before=original,after=merged,stages=[])
  else:selected[n]['after']=merged
  selected[n]['stages'].append(stage);composition.append(stage)
new_paths={n for n in selected if n not in expected}
assert len(composition)==26 and len(selected)==22 and len(new_paths)==7 and len(joins)==4
parse_rows=[]
for n,item in selected.items():
 parsed=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--config','skip_children=true','--emit','stdout'],input=item['after'],capture_output=True)
 assert parsed.returncode==0,(n,parsed.stderr.decode())
 parse_rows.append(dict(path=n,exit_code=0,scope='composed full Source stdin parse only; formatted output discarded'))
for n,e in expected.items():
 a=(PARENT/n).read_bytes();assert len(a)==e['size_bytes'] and sha(a)==e['archive']['sha256'] and (PARENT/e['archive']['path']).read_bytes()==a
OUT.mkdir();join_refs=[]
for j in joins:
 f=put('join-diffs/'+j['packet_role']+'.diff',delta(j['before'],j['after'],j['path']));iv=put('join-diffs/'+j['packet_role']+'.inverse.diff',delta(j['after'],j['before'],j['path']))
 assert apply(j['before'],f.read_bytes())==j['after'] and apply(j['after'],iv.read_bytes())==j['before']
 apps.extend([dict(path=j['path'],packet_role=j['packet_role'],role=k,pass_literal_application=True) for k in ['literal_join_forward','literal_join_inverse']])
 join_refs.append(dict(path=j['path'],packet_role=j['packet_role'],forward_diff=ref(f),inverse_diff=ref(iv),explanation=j['explanation']))
workspace=OUT/'workspace';workspace.mkdir()
for folder in ['crates','.cargo','tools','specs','energyplus_porting_plan','data','scripts','config','docs','.github']:shutil.copytree(PARENT/folder,workspace/folder,copy_function=os.link)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:
 if(PARENT/name).exists():shutil.copy2(PARENT/name,workspace/name)
shutil.copytree(PARENT/'.runtime/porting/source-objects',workspace/'.runtime/porting/source-objects',copy_function=os.link)
files=[];storage=[]
for i,(n,item) in enumerate(selected.items(),1):
 a,z=item['before'],item['after'];p=workspace/n;is_new=n in new_paths;assert p.resolve().is_relative_to(workspace.resolve())
 if is_new:assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True)
 else:
  assert p.read_bytes()==a and p.stat().st_ino==(PARENT/n).stat().st_ino and p.stat().st_nlink>=2
  oldid=p.stat().st_ino;p.unlink()
 p.write_bytes(z);assert p.stat().st_nlink==1
 assert not(PARENT/n).exists() if is_new else (PARENT/n).read_bytes()==a and p.stat().st_ino!=(PARENT/n).stat().st_ino
 storage.append(dict(path=n,new_fresh_file=True,links=1)) if is_new else storage.append(dict(path=n,parent_file_id=oldid,workspace79_file_id=p.stat().st_ino,detached_before_write=True,parent_bytes_retained=True))
 ba=put('before/'+n,a);iv=put('inverse/'+n,a);fd=put(f'diffs/{i:03}.diff',delta(a,z,n));rd=put(f'diffs/{i:03}.inverse.diff',delta(z,a,n))
 assert apply(a,fd.read_bytes())==z and apply(z,rd.read_bytes())==a
 apps.extend([dict(path=n,role=k,pass_literal_application=True) for k in ['assembled_forward','assembled_inverse']])
 files.append(dict(canonical_path=n,before=ref(ba),before_absent=is_new,proposed=ref(p),literal_inverse=ref(iv),forward_diff=ref(fd),inverse_diff=ref(rd),stages=item['stages']))
assert sourcepaths(PARENT)==set(expected) and sourcepaths(workspace)==set(expected)|new_paths
census=[];changed=[];shared=0
for n,e in expected.items():
 a,z=(PARENT/n).read_bytes(),(workspace/n).read_bytes()
 assert len(a)==e['size_bytes'] and sha(a)==e['archive']['sha256'] and (PARENT/e['archive']['path']).read_bytes()==a
 if n in selected:assert z==selected[n]['after'];changed.append(n)
 else:assert z==a
 assert a.count(b'#[test]')==z.count(b'#[test]')
 same=(PARENT/n).stat().st_ino==(workspace/n).stat().st_ino;shared+=same
 census.append(dict(path=n,parent78_sha256=sha(a),parent78_preserved_after_overlay=True,assembled79_sha256=sha(z),bytes79=len(z),same_underlying_file_id=same))
for n in sorted(new_paths):
 z=(workspace/n).read_bytes();assert z==selected[n]['after'] and b'#[test]' not in z
 census.append(dict(path=n,parent_absent=True,assembled79_sha256=sha(z),bytes79=len(z),new_fresh_file=True))
assert len(changed)==15 and len(census)==4468 and sum(n.endswith('.rs') for n in sourcepaths(workspace))==4455
assert shared==len(expected)-len(changed)-3 and len(apps)==156
pipeline='crates/ep_run/src/pipeline.rs';assert pipeline not in selected and (workspace/pipeline).read_bytes()==(PARENT/pipeline).read_bytes()
canonical_after={n:(None if not(ROOT/n).exists() else ref(ROOT/n)) for n in canonical_before};assert canonical_after==canonical_before
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD and subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
cp=jp('compiler-Source-input-census.json',dict(parent_recorded_snapshot=ref(snapshot),parent_count=4461,parent_Rust_count=4448,assembled_count=4468,assembled_Rust_count=4455,existing_changed=changed,new_paths=sorted(new_paths),all_other_existing_inputs_equal78=True,other_existing_count=4446,parent_all_archived_live_before_and_after_overlay=True,shared_unchanged_file_ids=shared,separate_unchanged_root_configs=['Cargo.toml','Cargo.lock','rust-toolchain.toml'],selected_storage=storage,files=census))
ap=jp('literal-applications.json',apps);co=jp('canonical-raw-observations.json',dict(current_HEAD=HEAD,selected_current_refs_before=canonical_before,selected_current_refs_after=canonical_after,all_selected_canonical_refs_unchanged=True))
parse_ref=jp('Source-only-parse.json',parse_rows)
out=jp('manifest.json',dict(schema='src06-isolated-full-endrun-and-genuine-IHG-producer-fix-union.v1',status='Frozen independently accepted leaves/callers over exact actual78; Root compiler and complete physical comparison pending',parent=ref(mp),parent_actual_check=ref(checkp),parent_actual_A_receipt=ref(clip),parent_actual_frontier_artifact=ref(frontier),parent_failed_full_physical_comparison=ref(comparisonp),parent_comparison_qualification='Full78physicalcomparison remains FAILED for missing genuine IHG1254-1261 total producer entries; this accepted-source union includes the reviewed producer fix but claims no observed repair until fresh execution.',workspace=workspace.relative_to(ROOT).as_posix(),packets=packets,independent_reviews=peers,composition=composition,explicit_literal_joins=join_refs,files=files,compiler_Source_census=ref(cp),literal_applications=ref(ap),canonical_observations=ref(co),author_Source=ref(Path(__file__)),copy_transport='All unchanged files hardlinked;15selected existing detached before write and7new fresh; all4461parent compiler inputs archived/live preserved before/after',parent_compiler_inputs_preserved=4461,assembled_compiler_inputs=4468,assembled_Rust_sources=4455,packet_stages=26,unique_changed_paths=22,existing_Source_changes=15,new_Source_files=7,literal_application_count=156,canonical_changed_by_assembler=False,Cargo_Native_or_tests_executed=False,Git_mutations=False,new_test_bodies=0,canonical_pipeline_activation=False,held_pipeline_exact_parent78=True,expected_reference_answers_compiled=False,numerical_PASS_or_gate_claimed=False,endrun_scope='Actual5270/5271/5272 then unconditional5278audit/SQLiteguard; outer598/600/602/604/606/609/611/617 through620 preserve real owners and final ErrorsFound. This assembly does not alter pipeline or activate a complete Source result exporter.',root_next_command_roots=dict(workspace=workspace.relative_to(ROOT).as_posix(),suggested_unique_actual_output_directory=(B/'through-primary-diagnostic-A-24H-Root-79/output').relative_to(ROOT).as_posix(),execution_by='Root only')))
print(json.dumps(ref(out)))

from pathlib import Path
from itertools import zip_longest
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-actual-completed-endrun79-comparison-01';assert not OUT.exists()
S=BASE/'through-primary-diagnostic-A-24H-Root-79/output';P=BASE/'through-primary-diagnostic-A-24H-Root-78/output';N=BASE/'native-installed-A-24H-Root-67/output';W=BASE/'ordinary-provider-assembly-Root-79/workspace'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(p.read_bytes())
check=W/'.runtime/porting/SRC-06/provider-assembly-all-targets-command-79/receipt.json';cli=W/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-79/receipt.json'
c=load(check);r=load(cli);assert c['exit_code']==0 and r['exit_code']==6 and c['source_bytes_match_before_and_after'] and r['source_bytes_match_before_and_after'] and c['source_snapshot']==r['source_snapshot']
frontier=b'actual Source after connected endrun prefix and completed result export';assert frontier in (S/'eplusrs.err').read_bytes()
assert '--oracle-baseline' not in r['command'] and '--compare-oracle' not in r['command']
compiler=[]
for line in (W/r['stdout']['path']).read_bytes().splitlines():
 try:row=json.loads(line)
 except (ValueError,UnicodeError):continue
 if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name') in ['ep_runtime','ep_run','eplus-rs']:
  assert row['fresh'] is False and str(W).replace('\\','/').lower() in row['target']['src_path'].replace('\\','/').lower();compiler.append(row)
assert len(compiler)==3
def classify(a,b,ext,i):
 if a is None or b is None:return 'UNCLASSIFIED'
 if (b'rusted-energyplus' in a or b'rusted-energyp' in a) and b'EnergyPlus' in b:return 'producer version/build'
 ca=re.fullmatch(rb'( *)\d{2}:\d{2}:\d{2}(</b></p>)?(\r?\n)?',a);cb=re.fullmatch(rb'( *)\d{2}:\d{2}:\d{2}(</b></p>)?(\r?\n)?',b)
 if ca is not None and cb is not None and ca.groups()==cb.groups():return 'actual wall clock'
 if (ext=='htm' and i==5) or (ext=='xml' and i==9):
  ca=re.fullmatch(rb'( *)\d{4}-\d{2}-\d{2}(\r?\n)?',a);cb=re.fullmatch(rb'( *)\d{4}-\d{2}-\d{2}(\r?\n)?',b)
  if ca is not None and cb is not None and ca.groups()==cb.groups():return 'actual wall date'
 if ext=='htm' and a.startswith((b'<p>Timestamp: <b>',b'<p>Simulation Timestamp: <b>')):
  ca=re.fullmatch(rb'(<p>(?:Simulation )?Timestamp: <b>)\d{4}-\d{2}-\d{2}(\r?\n)?',a);cb=re.fullmatch(rb'(<p>(?:Simulation )?Timestamp: <b>)\d{4}-\d{2}-\d{2}(\r?\n)?',b)
  if ca is not None and cb is not None and ca.groups()==cb.groups():return 'actual wall date'
 return 'UNCLASSIFIED'
formats=[];all_bad=[];total=exact=0
for ext in ['csv','tab','txt','htm','xml']:
 sp=S/f'eplustbl.{ext}';np=N/f'energyplustbl.{ext}';sl=sp.read_bytes().splitlines(keepends=True);nl=np.read_bytes().splitlines(keepends=True);bad=[]
 for i,(a,b) in enumerate(zip_longest(sl,nl),1):
  if a==b:continue
  bad.append(dict(format=ext,line=i,classification=classify(a,b,ext,i),Source_complete_raw_hex=None if a is None else a.hex(),Native_complete_raw_hex=None if b is None else b.hex()))
 count=max(len(sl),len(nl));formats.append(dict(format=ext,Source=ref(sp),Native=ref(np),Source_lines=len(sl),Native_lines=len(nl),exact_lines=count-len(bad),unequal_lines=len(bad),mismatches=bad));all_bad+=bad;total+=count;exact+=count-len(bad)
streams=[]
for source,native in [('eplusrs.eso','energyplusout.eso'),('eplusrs.mtr','energyplusout.mtr'),('eplusrs.eio','energyplusout.eio')]:
 sb=(S/source).read_bytes();pb=(P/source).read_bytes();nb=(N/native).read_bytes();translated=pb.replace(b'\n',b'\r\n');prefix_equal=sb.startswith(translated);suffix=sb[len(translated):] if prefix_equal else None
 bad=[];sl=sb.splitlines(keepends=True);nl=nb.splitlines(keepends=True)
 for i,(a,b) in enumerate(zip_longest(sl,nl),1):
  if a!=b:bad.append(dict(line=i,classification=classify(a,b,'stream',i),Source_complete_raw_hex=None if a is None else a.hex(),Native_complete_raw_hex=None if b is None else b.hex()))
 streams.append(dict(Source=ref(S/source),Source78=ref(P/source),Native=ref(N/native),Source78_complete_actual_stream_after_explicit_C_text_mode_translation_is_prefix=prefix_equal,actual_endrun_suffix_hex=None if suffix is None else suffix.hex(),Source_lines=len(sl),Native_lines=len(nl),Source_CRLF=sb.count(b'\r\n'),Source_bare_LF=sb.count(b'\n')-sb.count(b'\r\n'),Native_CRLF=nb.count(b'\r\n'),Native_bare_LF=nb.count(b'\n')-nb.count(b'\r\n'),all_uncapped_physical_mismatches=bad,qualification='Stream comparison retains actual binary64 reporting differences; explicit prior LF-to-CRLF projection verifies accepted adapter writes, not Native normalization. Physical values are not judged here using new tolerances.'))
raw_sidecar_same=(S/'logs/source-report-binary64.csv').read_bytes()==(P/'logs/source-report-binary64.csv').read_bytes()
snapshot=load(S/'logs/source-predefined-table.json');prior=load(P/'logs/source-predefined-table.json');sr=snapshot['table']['allocated_rows_in_original_order'];pr=prior['table']['allocated_rows_in_original_order'];delta=[]
for i,(a,b) in enumerate(zip_longest(sr,pr),1):
 if a!=b:delta.append(dict(ordinal=i,before=b,after=a))
named=re.findall(rb'<!-- FullName:(.*?)-->',(S/'eplustbl.htm').read_bytes())
OUT.mkdir();result=dict(accepted=not any(x['classification']=='UNCLASSIFIED' for x in all_bad),actual_Source_check=ref(check),actual_Source_CLI=ref(cli),Source79_manifest=ref(BASE/'ordinary-provider-assembly-Root-79/manifest.json'),Root_Source_preflight=ref(BASE/'Root-ordinary-provider-union79-preflight-01/review.json'),Native_actual_receipt=ref(BASE/'native-installed-A-24H-command-Root-67/receipt.json'),original_IDF=ref(ROOT/'energyplus_porting_plan/cases/A-24H/input.idf'),weather=ref(ROOT/'.runtime/energyplus/26.1.0/WeatherData/USA_CO_Golden-NREL.724666_TMY3.epw'),actual_first_error=frontier.decode(),actual_endrun620_completed=True,result_export_complete=False,compiler_artifact_rows=compiler,physical_formats=formats,full_physical_table_lines=total,exact_raw_table_lines=exact,unequal_raw_table_lines=len(all_bad),all_uncapped_raw_table_mismatches=all_bad,streams=streams,raw_binary64_sidecar_unchanged78=raw_sidecar_same,predefined_snapshot79=ref(S/'logs/source-predefined-table.json'),predefined_snapshot78=ref(P/'logs/source-predefined-table.json'),active_entries78=prior['table']['num_table_entry'],active_entries79=snapshot['table']['num_table_entry'],all_allocated_row_deltas=delta,HTML_named_table_comments=[x.decode('utf8') for x in named],findings=[x for x in all_bad if x['classification']=='UNCLASSIFIED'],method='Every raw physical Source line including CR/LF and complete table footer compared against same position in complete Native output, including all unmatched tail lines. No normalization, tolerance, decimal conversion or mismatch cap. Metadata differences retained verbatim as full raw hex. All raw ESO/MTR/EIO stream mismatches also retained. Source endrun is represented through620 but pipeline still stops honestly before result export.',whole_run_complete=False,numerical_gate_PASS=False,author_Source=ref(Path(__file__).resolve()))
p=OUT/'comparison.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)));print(json.dumps(dict(accepted=result['accepted'],lines=total,exact=exact,unequal=len(all_bad),active_entries79=result['active_entries79'],snapshot_deltas=len(delta),raw_binary64_same78=raw_sidecar_same,stream_prefixes=[x['Source78_complete_actual_stream_after_explicit_C_text_mode_translation_is_prefix'] for x in streams])))

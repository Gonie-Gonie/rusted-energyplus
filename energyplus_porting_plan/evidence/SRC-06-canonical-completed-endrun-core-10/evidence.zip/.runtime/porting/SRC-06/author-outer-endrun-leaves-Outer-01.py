"""Seal actual outer 598/602/604 leaves only; no caller, Cargo, or canonical edits."""
from pathlib import Path
import ast, difflib, hashlib, json, re, subprocess
ROOT=Path(__file__).resolve().parents[3]; D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'ordinary-outer-endrun-leaves-held-Outer-01'; assert not OUT.exists()
for n in ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')).body:
    if isinstance(n, ast.FunctionDef) and n.name in ('ref','apply_literal'):
        exec(compile(ast.Module([n],type_ignores=[]),'custody','exec'),globals())
P=D/'ordinary-provider-assembly-Root-77/manifest.json'
assert ref(P)['sha256']=='1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
W=ROOT/json.loads(P.read_bytes())['workspace']; N=ROOT/'.reference/energyplus-src/26.1.0'; PIN='6f2e40d10250a105b49966baa24d843711e61048'
def run(args,cwd=ROOT,required=True):
    p=subprocess.run(args,cwd=cwd,capture_output=True)
    if required: assert p.returncode==0,(args,p.stderr)
    return p
HEAD=run(['git','rev-parse','HEAD']).stdout.decode().strip()
assert HEAD.startswith('36b48e14')
names={
'crates/ep_runtime/src/heat_balance/ordinary_utility_bills/tabular_report.rs':r'''//! Actual WriteTabularTariffReports4082-4514 on the same economic/TAB owners.
use super::{Error, SourceEconomicTariff};
use crate::heat_balance::error_backend::{SourceDiagnosticFlags, SourceErrorBackend};
use crate::heat_balance::ordinary_tabular_reports::SourceTabularReports;
use crate::heat_balance::selected_heat_balance_globals::SelectedHeatBalanceGlobals;
use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneInputOwners;

impl SourceEconomicTariff {
    pub(crate) fn write_source_tabular_tariff_reports(
        &self,
        tabular: &mut SourceTabularReports,
        globals: &SelectedHeatBalanceGlobals,
        zones: &SelectedZoneInputOwners,
        backend: &mut SourceErrorBackend<'_>,
        flags: &SourceDiagnosticFlags<'_>,
    ) -> Result<(), Error> {
        // Native4089-4093 construct local empty arrays, not retained owners.
        // Its local perAreaUnitConv4099 is initialized before the area check.
        let _per_area_unit_conversion = 0.0_f64;
        // This check is BEFORE numTariff4108, even for the zero-tariff case.
        tabular.prepare_source_tariff_report_floor_area(globals, zones)?;
        if self.number_tariffs > 0 {
            if tabular.display_economic_result_summary {
                backend.display_source_string("Writing Tariff Reports", flags)?;
                return Err(Error::Unavailable(
                    "actual WriteTabularTariffReports showWarningsBasedOnTotal4111 child",
                ));
            }
            // Native's displayTariffReport4273 is inside the economic-summary
            // block. If that actual block is false, no tariff report is written.
        }
        Ok(())
    }
}
''',
'crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/endrun_files.rs':r'''//! Actual outer tariff floor-area prerequisite and CloseOutputTabularFile3157-3209.
use super::{Error, SourceTabularReports};
use crate::heat_balance::selected_heat_balance_globals::SelectedHeatBalanceGlobals;
use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneInputOwners;

impl SourceTabularReports {
    pub(crate) fn prepare_source_tariff_report_floor_area(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
        zones: &SelectedZoneInputOwners,
    ) -> Result<(), Error> {
        if self.input_state.building_conditioned_floor_area == 0.0 {
            // Reuse the ONE literal DetermineBuildingFloorArea body. The
            // actual caller may clear/recompute its same totals at this point.
            self.determine_source_building_floor_area_from_owners(globals, zones)?;
        }
        Ok(())
    }

    pub(crate) fn close_source_tabular_files(&mut self) -> Result<(), Error> {
        if self.input_state.write_tabular_files {
            for ordinal in 1..=self.input_state.number_of_styles {
                let at = usize::try_from(ordinal - 1)
                    .map_err(|_| Error::Unavailable("actual CloseTAB style ordinal3194"))?;
                let stream = self.output_streams.streams.get_mut(at).ok_or(
                    Error::Unavailable("actual CloseTAB TabularOutputFile pointer3195"),
                )?;
                let style = *self.input_state.table_styles.get(at).ok_or(
                    Error::Unavailable("actual CloseTAB TableStyle3196 read"),
                )?;
                if style == 3 {
                    stream.bytes(b"</body>\n")?;
                    stream.bytes(b"</html>\n")?;
                } else if style == 4 {
                    if !self.input_state.prev_report_name.is_empty() {
                        stream.bytes(b"</")?;
                        stream.bytes(&self.input_state.prev_report_name)?;
                        stream.bytes(b">\n")?;
                    }
                    stream.bytes(b"</EnergyPlusTabularReports>\n")?;
                }
                stream.close();
            }
        }
        Ok(())
    }
}
''',
}
links={
'crates/ep_runtime/src/heat_balance/ordinary_utility_bills.rs':('mod compute_tariff;\n','mod tabular_report;\n'),
'crates/ep_runtime/src/heat_balance/ordinary_tabular_reports.rs':('mod output_files;\n','mod endrun_files;\n'),
}
for name,(anchor,addition) in links.items():
    b=(W/name).read_bytes(); assert b.count(anchor.encode())==1 and addition.encode() not in b
    names[name]=b.replace(anchor.encode(),(anchor+addition).encode(),1).decode()
name='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/output_files.rs'; b=(W/name).read_bytes()
anchor=b'    pub(super) fn bytes(&mut self, bytes: &[u8]) -> Result<(), Error> {\n'; assert b.count(anchor)==1
close=b'''    // Native ofstream.close acts on this exact member after its final footer.
    // Dropping File closes the same OS handle; no reopen, sync, reset or flush
    // operation is inserted. Native's already-closed close sets failbit.
    pub(super) fn close(&mut self) {
        if self.file.take().is_none() {
            self.failed = true;
        }
    }
'''
names[name]=b.replace(anchor,close+anchor,1).decode()
name='crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/endrun.rs'; b=(W/name).read_bytes()
suffix=r'''
impl SourceHvacManager {
    /// Actual DumpAirLoopStatistics1998-2024. The live SysVars flag is the
    /// first predicate; a zero NumPrimaryAirSys is not a substitute guard.
    pub(crate) fn dump_source_air_loop_statistics(
        &self,
        system: &crate::heat_balance::selected_project_data::ProjectSystemVariables,
    ) -> Result<(), Error> {
        if !system.track_air_loop_env_flag {
            return Ok(());
        }
        Err(Error::Unavailable(
            "actual DumpAirLoopStatistics local StatisticsFilePath.open2015",
        ))
    }
}
'''
names[name]=b.decode()+suffix
OUT.mkdir()
def put(name,b):
    p=OUT/name; assert not p.exists(); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b); return ref(p)
def doc(name,o): return put(name,(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode())
for name,t in names.items(): put('proposed/'+name,t.encode())
new=[n for n in names if not (W/n).exists()]
fmt=run(['rustfmt','--edition','2024','--config','skip_children=true']+[str(OUT/'proposed'/n) for n in new])
formatting=doc('new-child-format.json',dict(exit_code=fmt.returncode,stdout=put('format.stdout',fmt.stdout),stderr=put('format.stderr',fmt.stderr),scope='Only two new HELD files; parent files remain literal byte proposals.'))
files=[]; apps=[]; git=[]; parse=[]; recoveries=[]
for i,name in enumerate(names,1):
    current=ROOT/name; exists=current.exists(); before=current.read_bytes() if exists else b''
    parent=W/name; pexists=parent.exists(); pb=parent.read_bytes() if pexists else b''; a=(OUT/'proposed'/name).read_bytes()
    row=dict(canonical_path=name,current_before=ref(current) if exists else None,current_absent_observed=not exists,before=put('before/'+name,before),literal_inverse=put('literal-inverse/'+name,before),parent_source=ref(parent) if pexists else None,parent_absent_observed=not pexists,parent_before=put('parent-before/'+name,pb),literal_parent_inverse=put('literal-parent-inverse/'+name,pb),proposed=ref(OUT/'proposed'/name))
    for x,y,k,l,r in [(before,a,'complete_forward_diff','canonical','proposed'),(a,before,'complete_inverse_diff','proposed','canonical'),(pb,a,'parent_forward_diff','Root77','proposed'),(a,pb,'parent_inverse_diff','proposed','Root77')]:
        patch=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=l+'/'+name,tofile=r+'/'+name)).encode(); assert apply_literal(x,patch)==y
        row[k]=put(f'diffs/{i:02}-{k}.diff',patch); apps.append(dict(path=name,role=k,literal_application_passed=True))
    p=run(['git','show',HEAD+':'+name],required=False); assert p.returncode==(0 if exists else 128) and p.stdout==before
    git.append(dict(path=name,revision=HEAD,exit_code=p.returncode,stdout=put('Git/'+name,p.stdout),stderr=put('Git/'+name+'.stderr',p.stderr),actual_absence=not exists))
    if name in links:
        anchor,addition=links[name]; assert a.replace(addition.encode(),b'',1)==pb
        recoveries.append(dict(path=name,sole_addition=addition,whole_parent_recovered=True))
    elif name.endswith('/output_files.rs'):
        assert a.replace(close,b'',1)==pb; recoveries.append(dict(path=name,sole_addition=close.decode(),whole_parent_recovered=True))
    elif name.endswith('/ordinary_hvac_manager/endrun.rs'):
        assert a.removesuffix(suffix.encode())==pb; recoveries.append(dict(path=name,sole_addition=suffix,whole_parent_recovered=True))
    assert a.count(b'#[test]')==pb.count(b'#[test]')
    cmd=['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(OUT/'proposed'/name)]
    cp=run(cmd); assert (OUT/'proposed'/name).read_bytes()==a
    parse.append(dict(path=name,command=cmd,exit_code=cp.returncode,stdout=put(f'parse/{i:02}.stdout',cp.stdout),stderr=put(f'parse/{i:02}.stderr',cp.stderr),proposed_bytes_unchanged=True)); files.append(row)
ranges=[('SimulationManager.cc',594,620),('EconomicTariff.cc',4082,4514),('OutputReportTabular.cc',3157,3209),('OutputReportTabular.cc',18104,18169),('OutputReportTabular.hh',1116,1124),('OutputReportTabular.hh',1460,1472),('HVACControllers.cc',1998,2024),('DataSystemVariables.hh',102,122)]
originals=[]; nativegit=[]; seen=set()
for name,first,last in ranges:
    p=N/'src/EnergyPlus'/name; b=p.read_bytes(); ls=b.splitlines(keepends=True); assert 1<=first<=last<=len(ls)
    if name not in seen:
        q=run(['git','show',PIN+':src/EnergyPlus/'+name],cwd=N); assert q.stdout==b; seen.add(name); nativegit.append(dict(source=ref(p),revision=PIN,actual_whole_stdout_equal=True))
    originals.append(dict(source=ref(p),first_line=first,last_line=last,literal_excerpt=put('Original/'+name.replace('/','__')+f'-{first}-{last}.txt',b''.join(ls[first-1:last])),strict_EOF=True))
read_names=['crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/beps_report.rs','crates/ep_runtime/src/heat_balance/ordinary_utility_bills/compute_tariff.rs','crates/ep_runtime/src/heat_balance/ordinary_life_cycle_cost/endrun.rs','crates/ep_runtime/src/heat_balance/selected_project_data.rs','crates/ep_runtime/src/heat_balance/selected_project_data/environment.rs']
reads=[ref(W/n) for n in read_names]
assert len(files)==6 and len(apps)==24 and len(recoveries)==4
proof=doc('same-owner-order-proof.json',dict(Tariff598={'owner':'same reports.economic_tariff and session.tabular; globals/zones same actual input owners','before_zero_count':'actual buildingConditionedFloorArea == 0 test4104 precedes numTariff4108; invokes one shared literal DetermineBuildingFloorArea body18104-18169, no replacement totals','positive_branch':'actual displayEconomicResultSummary guard4109; live Display4110 before typed first showWarningsBasedOnTotal4111 child; nested displayTariffReport4273 remains inside that block','no_inputs':'does not rerun a tariff getter or supply an absent-tariff result'},CloseTAB602={'owner':'same retained SourceTabularReports.output_streams five ordinal members; no SourceInitializationFiles stream/path copy','guard':'WriteTabularFiles only, not outputControl.tabular repeated','order':'for each actual ordinal pointer, read style; HTML two footer insertions or XML previous report closing element/root; then close same OS File member; no sync/reopen/reset/new footer owner','exception_scope':'exceptional OS close failures cannot be observed through Rust File::drop; successful physical close only is claimed'},HVAC604={'owner':'reads actual same ProjectSystemVariables.track_air_loop_env_flag set by processEnvironmentVariables TRACK_AIRLOOP','false_path':'actual1998 function returns2011 before any file open or controller count access','true_boundary':'real local StatisticsFilePath.open2015 before NumPrimaryAirSys2019; no zero-loop proxy'},whole_parent_recoveries=recoveries,new_numeric_owners=0,new_test_bodies=0,caller_not_changed=True))
manifest=doc('manifest.json',dict(schema='src06-held-outer-endrun-leaves.v1',status='HELD only; independent peer, actual caller, assembly and typecheck pending',base_HEAD=HEAD,parent=ref(P),files=files,Original_commit=PIN,Original_authority=originals,actual_readonly_Native_Git=nativegit,actual_current_Git=git,read_only_existing_Source_APIs=reads,same_owner_order_proof=proof,new_child_format=formatting,Source_only_parse=parse,literal_diff_applications=apps,author_Source=ref(Path(__file__).resolve()),API={'Tariff598':'SourceEconomicTariff::write_source_tabular_tariff_reports(&self,&mut SourceTabularReports,&SelectedHeatBalanceGlobals,&SelectedZoneInputOwners,&mut SourceErrorBackend,&SourceDiagnosticFlags)','CloseTAB602':'SourceTabularReports::close_source_tabular_files(&mut self)','HVAC604':'SourceHvacManager::dump_source_air_loop_statistics(&self,&ProjectSystemVariables)','LCC600':'existing accepted compute_source_life_cycle_cost_and_report reused unchanged'},scope={'new_files':2,'old_files_narrow_additions':4,'actual_calls':[598,602,604],'Root77_module_only_join_needed':True,'CloseOutputFiles606_not_implemented':True,'no_caller_or_dispatch_edit':True,'no_whole_run_or_gate_claim':True},canonical_changes=0,Git_mutations=0,Cargo_or_Native_executed=False,new_test_bodies=0))
print(json.dumps(manifest))

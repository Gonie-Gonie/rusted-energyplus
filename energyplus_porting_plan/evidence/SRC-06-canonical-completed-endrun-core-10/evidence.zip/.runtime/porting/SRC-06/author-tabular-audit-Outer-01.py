"""Seal genuine WriteTabularReports5278-5294 audit on existing actual owners."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3]; D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'ordinary-tabular-audit-held-Outer-01';assert not OUT.exists()
for n in ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')).body:
    if isinstance(n,ast.FunctionDef) and n.name in ('ref','apply_literal'):
        exec(compile(ast.Module([n],type_ignores=[]),'custody','exec'),globals())
P=D/'ordinary-provider-assembly-Root-77/manifest.json';assert ref(P)['sha256']=='1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
W=ROOT/json.loads(P.read_bytes())['workspace'];N=ROOT/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def run(a,cwd=ROOT,required=True):
    p=subprocess.run(a,cwd=cwd,capture_output=True)
    if required:assert p.returncode==0,(a,p.stderr)
    return p
HEAD=run(['git','rev-parse','HEAD']).stdout.decode().strip();assert HEAD.startswith('36b48e14')
names={
'crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/audit.rs':r'''//! Actual unconditional WriteTabularReports5278-5294 audit suffix.
use super::{Error, SourceTabularReports};
use crate::heat_balance::ctf_reports::PredefinedStringTable;
use crate::heat_balance::ordinary_output_control::SourceOutputControl;
use crate::heat_balance::predefined_tables::PredefinedRegistry;
use crate::heat_balance::source_initialization::SourceInitializationFiles;
use std::io::Write;

impl SourceTabularReports {
    /// This suffix is outside the WriteTabularFiles block; the actual caller
    /// must reach it even when that flag is false, after the weather reports.
    pub(crate) fn write_source_tabular_audit(
        &self,
        files: &mut SourceInitializationFiles,
        control: &SourceOutputControl,
        registry: &PredefinedRegistry,
        table: &PredefinedStringTable,
    ) -> Result<(), Error> {
        let audit = files.ensure_source_reporting_audit(control)?;
        // Read the sole retained cells in Native print order, no inferred
        // lengths, allocator capacities, defaults or cloned report snapshot.
        writeln!(audit, " MonthlyInputCount={:12}", self.input_state.monthly_input_count)?;
        writeln!(audit, " sizeMonthlyInput={:12}", self.input_state.size_monthly_input)?;
        writeln!(audit, " MonthlyFieldSetInputCount={:12}", self.input_state.monthly_field_set_input_count)?;
        writeln!(audit, " sizeMonthlyFieldSetInput={:12}", self.input_state.size_monthly_field_set_input)?;
        writeln!(audit, " MonthlyTablesCount={:12}", self.input_state.monthly_tables_count)?;
        writeln!(audit, " MonthlyColumnsCount={:12}", self.input_state.monthly_columns_count)?;
        writeln!(audit, " sizeReportName={:12}", registry.report_capacity)?;
        writeln!(audit, " numReportName={:12}", registry.report_count)?;
        writeln!(audit, " sizeSubTable={:12}", registry.subtable_capacity)?;
        writeln!(audit, " numSubTable={:12}", registry.subtable_count)?;
        writeln!(audit, " sizeColumnTag={:12}", registry.column_capacity)?;
        writeln!(audit, " numColumnTag={:12}", registry.column_count)?;
        writeln!(audit, " sizeTableEntry={:12}", table.size_table_entry)?;
        writeln!(audit, " numTableEntry={:12}", table.num_table_entry)?;
        writeln!(audit, " sizeCompSizeTableEntry={:12}", registry.component_sizing_capacity)?;
        writeln!(audit, " numCompSizeTableEntry={:12}", registry.component_sizing_count)?;
        Ok(())
    }

    pub(crate) fn source_max_unique_key_count(&self) -> &i32 {
        &self.input_state.max_unique_key_count
    }
    pub(crate) fn source_monthly_field_set_input_count(&self) -> &i32 {
        &self.input_state.monthly_field_set_input_count
    }
}
''',
'crates/ep_runtime/src/heat_balance/source_initialization/files/endrun_audit.rs':r'''//! Same IOFiles audit ensure_open for actual TAB5278 and CloseOutputFiles1797.
use super::SourceInitializationFiles;
use crate::heat_balance::ordinary_output_control::SourceOutputControl;
use crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError as Error;
use std::io::Write;

impl SourceInitializationFiles {
    pub(crate) fn ensure_source_reporting_audit(
        &mut self,
        control: &SourceOutputControl,
    ) -> Result<&mut dyn Write, Error> {
        // Native ensure_open first tests this same pointer and good state. An
        // already opened good stream is retained, irrespective of the option.
        if self.audit.file.is_none() || self.audit.failed {
            if !control.audit {
                return Err(Error::Unavailable(
                    "actual audit ensure_open disabled null-buffer stream allocation",
                ));
            }
            self.audit.ensure_open()?;
        }
        Ok(&mut self.audit)
    }
}
''',
}
edits={}
def replace(name,old,new):
    b=names.get(name,(W/name).read_text(encoding='utf8'));assert b.count(old)==1
    names[name]=b.replace(old,new,1);edits.setdefault(name,[]).append((old,new))
replace('crates/ep_runtime/src/heat_balance/ordinary_tabular_reports.rs','mod output_files;\n','mod output_files;\nmod audit;\n')
replace('crates/ep_runtime/src/heat_balance/source_initialization/files.rs','mod reporting;\n','mod reporting;\nmod endrun_audit;\n')
state='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/state.rs'
replace(state,'    pub(super) monthly_input_count: i32,\n','    pub(super) monthly_input_count: i32,\n    // Actual OutputReportTabular.hh1102-1104 constructor-zero members.\n    pub(super) size_monthly_input: i32,\n    pub(super) monthly_field_set_input_count: i32,\n    pub(super) size_monthly_field_set_input: i32,\n')
replace(state,'            monthly_input_count: 0,\n','            monthly_input_count: 0,\n            size_monthly_input: 0,\n            monthly_field_set_input_count: 0,\n            size_monthly_field_set_input: 0,\n')
OUT.mkdir()
def put(name,b):
    p=OUT/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(name,o):return put(name,(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode())
for n,t in names.items():put('proposed/'+n,t.encode())
new=[n for n in names if not (W/n).exists()]
fp=run(['rustfmt','--edition','2024','--config','skip_children=true']+[str(OUT/'proposed'/n) for n in new]);fmt=doc('new-child-format.json',dict(exit_code=fp.returncode,stdout=put('format.stdout',fp.stdout),stderr=put('format.stderr',fp.stderr)))
files=[];apps=[];git=[];parse=[];recoveries=[]
for i,n in enumerate(names,1):
    cp=ROOT/n;exists=cp.exists();before=cp.read_bytes() if exists else b'';pp=W/n;pexists=pp.exists();pb=pp.read_bytes() if pexists else b'';a=(OUT/'proposed'/n).read_bytes()
    row=dict(canonical_path=n,current_before=ref(cp) if exists else None,current_absent_observed=not exists,before=put('before/'+n,before),literal_inverse=put('literal-inverse/'+n,before),parent_source=ref(pp) if pexists else None,parent_absent_observed=not pexists,parent_before=put('parent-before/'+n,pb),literal_parent_inverse=put('literal-parent-inverse/'+n,pb),proposed=ref(OUT/'proposed'/n))
    for x,y,k,l,r in [(before,a,'complete_forward_diff','canonical','proposed'),(a,before,'complete_inverse_diff','proposed','canonical'),(pb,a,'parent_forward_diff','Root77','proposed'),(a,pb,'parent_inverse_diff','proposed','Root77')]:
        patch=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=l+'/'+n,tofile=r+'/'+n)).encode();assert apply_literal(x,patch)==y
        row[k]=put(f'diffs/{i:02}-{k}.diff',patch);apps.append(dict(path=n,role=k,literal_application_passed=True))
    p=run(['git','show',HEAD+':'+n],required=False);assert p.returncode==(0 if exists else 128) and p.stdout==before
    git.append(dict(path=n,revision=HEAD,exit_code=p.returncode,stdout=put('Git/'+n,p.stdout),stderr=put('Git/'+n+'.stderr',p.stderr),actual_absence=not exists))
    if n in edits:
        recovered=a.decode()
        for old,newtxt in reversed(edits[n]):assert recovered.count(newtxt)==1;recovered=recovered.replace(newtxt,old,1)
        assert recovered.encode()==pb;recoveries.append(dict(path=n,exact_literal_edits=edits[n],whole_parent_recovered=True))
    assert a.count(b'#[test]')==pb.count(b'#[test]')
    cmd=['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(OUT/'proposed'/n)];p=run(cmd);assert (OUT/'proposed'/n).read_bytes()==a
    parse.append(dict(path=n,command=cmd,exit_code=p.returncode,stdout=put(f'parse/{i:02}.stdout',p.stdout),stderr=put(f'parse/{i:02}.stderr',p.stderr),proposed_bytes_unchanged=True));files.append(row)
ranges=[('OutputReportTabular.cc',5276,5296),('OutputReportTabular.hh',1097,1110),('OutputReportTabular.cc',415,529),('OutputReportTabular.cc',340,405),('OutputReportTabular.cc',2135,2145),('IOFiles.cc',205,242),('IOFiles.hh',365,412)]
originals=[];ng=[];seen=set()
for n,first,last in ranges:
    p=N/'src/EnergyPlus'/n;b=p.read_bytes();ls=b.splitlines(keepends=True);assert 1<=first<=last<=len(ls)
    if n not in seen:
        assert run(['git','show',PIN+':src/EnergyPlus/'+n],cwd=N).stdout==b;seen.add(n);ng.append(dict(source=ref(p),revision=PIN,actual_whole_stdout_equal=True))
    originals.append(dict(source=ref(p),first_line=first,last_line=last,literal_excerpt=put('Original/'+n.replace('/','__')+f'-{first}-{last}.txt',b''.join(ls[first-1:last])),strict_EOF=True))
reads=[ref(W/n) for n in ['crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/getters.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/summary.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/monthly_initialization.rs','crates/ep_runtime/src/heat_balance/predefined_tables.rs','crates/ep_runtime/src/heat_balance/ctf_reports.rs','crates/ep_runtime/src/heat_balance/ordinary_output_control.rs']]
proof=doc('same-owner-count-writer-proof.json',dict(new_TAB_members={'actual':'sizeMonthlyInput,MonthlyFieldSetInputCount,sizeMonthlyFieldSetInput explicit ctor0 Native.hh1102-1104','sole_writers':'AddMonthlyReport445-459 and AddMonthlyFieldSetInput502-517; only reached after positive monthly getter379 or positive namedMonthly guard; both remain typed boundaries before writes','not_observed_defaults':'No Native output or input absence is assigned to these cells. Native constructors supply initial values; getters/initialization existing guards preserve them.'},existing_TAB_members={'reused':'monthly_input_count/monthly_tables_count/monthly_columns_count/max_unique_key_count; no mirrors or reset','writers':'real monthly getter writes input count, initialization allocates tables/columns and writes counts1500 key allocation; same existing state read live'},registry={'counts':'six existing same PredefinedRegistry capacity/count fields plus same component_sizing capacity/count from accepted77; two existing same PredefinedStringTable counters','no_projection':'no Vec.len/capacity, snapshots, replacement tables or copied predefined entries'},audit={'order':'same Files audit.ensure_open at actual5278 before16 print statements in exact5279-5294 order','output_control':'live same control.audit read only if pointer absent/bad, as Native ensure_open; unsupported disabled null-buffer construction is bounded at actual operation','exception_scope':'successful ordinary opens and real IO errors only; no full fatal/exceptional-stream equivalence claimed'},whole_parent_recoveries=recoveries,new_retained_numeric_cells=3,new_test_bodies=0,caller_not_changed=True))
assert len(files)==5 and len(apps)==20 and len(recoveries)==3
manifest=doc('manifest.json',dict(schema='src06-held-unconditional-tabular-audit.v1',status='HELD proposal only; independent peer/caller/assembly/typecheck pending',base_HEAD=HEAD,parent=ref(P),files=files,Original_commit=PIN,Original_authority=originals,actual_readonly_Native_Git=ng,actual_current_Git=git,read_only_existing_Source_APIs=reads,same_owner_count_writer_proof=proof,Source_only_parse=parse,new_child_format=fmt,literal_diff_applications=apps,author_Source=ref(Path(__file__).resolve()),API={'WriteTabularReports5278':'SourceTabularReports::write_source_tabular_audit(&self,&mut SourceInitializationFiles,&SourceOutputControl,&PredefinedRegistry,&PredefinedStringTable)','same_File_capability':'SourceInitializationFiles::ensure_source_reporting_audit(&mut self,&SourceOutputControl)->Result<&mut dyn Write,HeatBalanceInputError>','CloseOutputFiles_accessors':'source_max_unique_key_count/source_monthly_field_set_input_count return references to same actual TAB cells'},scope={'actual_call':'unconditional5278-5294 suffix after all report children, independent of WriteTabularFiles','new_files':2,'old_files_narrow_edits':3,'Root77_module_state_literal_join_needed':True,'Files_diagnostic_observers':'Root77 whole parent includes previously accepted observer bytes; proposal adds ONLY mod endrun_audit, so canonical promotion must extract literal addition and must not promote observers','no_dispatch_or_caller_edit':True,'no_whole_run_or_gate_claim':True},canonical_changes=0,Git_mutations=0,Cargo_or_Native_executed=False,new_test_bodies=0))
print(json.dumps(manifest))

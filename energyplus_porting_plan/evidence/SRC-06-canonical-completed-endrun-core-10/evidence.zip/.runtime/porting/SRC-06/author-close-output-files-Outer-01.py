"""Author actual CloseOutputFiles1764-1955 and same-owner constructor cells."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'ordinary-close-output-files-held-Outer-01';assert not OUT.exists()
for n in ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')).body:
    if isinstance(n,ast.FunctionDef) and n.name in ('ref','apply_literal'):
        exec(compile(ast.Module([n],type_ignores=[]),'custody','exec'),globals())
P=D/'ordinary-provider-assembly-Root-77/manifest.json';assert ref(P)['sha256']=='1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
M=json.loads(P.read_bytes());W=ROOT/M['workspace'];N=ROOT/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
AUD=D/'ordinary-tabular-audit-held-Outer-01/manifest.json';assert ref(AUD)['sha256']=='7fc5dc023047d0e4803b0b9b498479d97614a3d1d47a179a411a855ee8a46a41'
def run(a,cwd=ROOT,required=True):
    p=subprocess.run(a,cwd=cwd,capture_output=True)
    if required:assert p.returncode==0,(a,p.stderr)
    return p
HEAD=run(['git','rev-parse','36b48e14']).stdout.decode().strip();assert HEAD.startswith('36b48e14')
LIVE_HEAD=run(['git','rev-parse','HEAD']).stdout.decode().strip()
names={
'crates/ep_runtime/src/heat_balance/source_initialization/files/endrun.rs':r'''//! Actual CloseOutputFiles1764-1955 on the one retained physical file owner.
use super::{SourceInitializationFiles, SourceOutputStream};
use crate::heat_balance::ordinary_output_control::SourceOutputControl;
use crate::heat_balance::ordinary_tabular_reports::SourceTabularReports;
use crate::heat_balance::radiation::ordinary::OrdinarySolarRadiation;
use crate::heat_balance::radiation::ordinary::shading_report::SourceShadingStream;
use crate::heat_balance::selected_heat_balance_input::{HeatBalanceInputError as Error, SelectedHeatBalanceInputState};
use crate::heat_balance::selected_heat_balance_input::surface::SurfaceGeometryInputState;
use crate::heat_balance::selected_project_data::ProjectSystemVariables;
use crate::heat_balance::selected_simulation_startup::SelectedRuntimeLanguage;
use crate::heat_balance::source_output_prescan::SourceOutputPreScan;
use crate::heat_balance::source_output_registration::SourceOutputRegistration;
use crate::heat_balance::startup_integrity::SourceBranchNodeConnections;
use std::io::{self, Write};

/// Each member is borrowed from the same actual session/reports. Record counts
/// are the i64 cells incremented by the real OP writers, not parsed artifacts.
pub(crate) struct SourceCloseOutputFilesOwners<'a> {
    pub(crate) registration: &'a SourceOutputRegistration,
    pub(crate) tabular: &'a SourceTabularReports,
    pub(crate) solar: &'a OrdinarySolarRadiation,
    pub(crate) geometry: &'a SurfaceGeometryInputState,
    pub(crate) system: &'a ProjectSystemVariables,
    pub(crate) prescan: &'a SourceOutputPreScan,
    pub(crate) runtime_language: &'a SelectedRuntimeLanguage,
    pub(crate) connections: &'a SourceBranchNodeConnections,
    pub(crate) heat_balance: &'a SelectedHeatBalanceInputState,
    pub(crate) standard_output_record_count: &'a i64,
    pub(crate) standard_meter_record_count: &'a i64,
    pub(crate) shading_stream: &'a mut SourceShadingStream,
    pub(crate) output_control: &'a SourceOutputControl,
}

impl SourceOutputStream {
    fn close_source_output(&mut self) {
        // Actual InputOutputFile.close234-237 resets os, not its path.
        self.file = None;
    }
    fn delete_source_output(&mut self) -> io::Result<()> {
        // Actual del239-245 acts only when the os pointer exists, closes it
        // before removeFile, and leaves this same retained pathname in place.
        if self.file.take().is_some() {
            match std::fs::remove_file(&self.path) {
                Ok(()) => {}
                Err(e) if e.kind() == io::ErrorKind::NotFound => {}
                Err(e) => return Err(e),
            }
        }
        Ok(())
    }
}

impl SourceInitializationFiles {
    pub(crate) fn close_source_output_files(
        &mut self,
        o: &mut SourceCloseOutputFilesOwners<'_>,
    ) -> Result<(), Error> {
        let audit = self.ensure_source_reporting_audit(o.output_control)?;
        writeln!(audit, " NumOfRVariable={:12}", o.registration.num_real_variables_setup)?;
        writeln!(audit, " NumOfRVariable(Total)={:12}", o.registration.num_total_real_variables)?;
        writeln!(audit, " NumOfRVariable(Actual)={:12}", o.registration.num_real_variables)?;
        writeln!(audit, " NumOfRVariable(Summed)={:12}", o.registration.num_real_variables_sum)?;
        writeln!(audit, " NumOfRVariable(Meter)={:12}", o.registration.num_real_variables_meter)?;
        writeln!(audit, " NumOfIVariable={:12}", o.registration.num_integer_variables_setup)?;
        writeln!(audit, " NumOfIVariable(Total)={:12}", o.registration.num_total_integer_variables)?;
        writeln!(audit, " NumOfIVariable(Actual)={:12}", o.registration.num_integer_variables)?;
        writeln!(audit, " NumOfIVariable(Summed)={:12}", o.registration.num_integer_variables_sum)?;
        writeln!(audit, " NumEnergyMeters={:12}", o.registration.meters.meters.len())?;
        writeln!(audit, " maxUniqueKeyCount={:12}", o.tabular.source_max_unique_key_count())?;
        writeln!(audit, " maxNumberOfFigures={:12}", o.solar.solar_timestep.max_number_of_figures)?;
        writeln!(audit, " MAXHCArrayBounds={:12}", o.solar.solar_timestep.max_hc_array_bounds)?;
        writeln!(audit, " MaxVerticesPerSurface={:12}", o.geometry.coordinate.max_vertices_per_surface)?;
        if o.system.shadowing_clipping.sutherland_hodgman {
            if o.system.shadowing_clipping.slater_barsky {
                writeln!(audit, " ClippingAlgorithm=SlaterBarskyandSutherlandHodgman")?;
            } else {
                writeln!(audit, " ClippingAlgorithm=SutherlandHodgman")?;
            }
        } else {
            // Original1825 deliberately has no leading blank in this branch.
            writeln!(audit, "ClippingAlgorithm=ConvexWeilerAtherton")?;
        }
        writeln!(audit, " MonthlyFieldSetInputCount={:12}", o.tabular.source_monthly_field_set_input_count())?;
        writeln!(audit, " NumConsideredOutputVariables={:12}", o.prescan.num_considered_output_variables)?;
        writeln!(audit, " MaxConsideredOutputVariables={:12}", o.prescan.max_considered_output_variables)?;
        writeln!(audit, " numActuatorsUsed={:12}", o.runtime_language.number_of_actuators_used)?;
        writeln!(audit, " numEMSActuatorsAvailable={:12}", o.runtime_language.number_ems_actuators_available)?;
        writeln!(audit, " maxEMSActuatorsAvailable={:12}", o.runtime_language.max_ems_actuators_available)?;
        writeln!(audit, " numInternalVariablesUsed={:12}", o.runtime_language.number_internal_variables_used)?;
        writeln!(audit, " numEMSInternalVarsAvailable={:12}", o.runtime_language.number_ems_internal_variables_available)?;
        writeln!(audit, " maxEMSInternalVarsAvailable={:12}", o.runtime_language.max_ems_internal_variables_available)?;
        writeln!(audit, " NumOfNodeConnections={:12}", o.connections.source_number_node_connections())?;
        writeln!(audit, " MaxNumOfNodeConnections={:12}", o.connections.source_max_number_node_connections())?;
        // Native EP_Count_Calls conditional body is absent in the selected
        // ordinary build. No instrumentation counters are invented here.

        self.outputs[0].write_all(b"End of Data\n")?;
        if *o.standard_output_record_count > 0 {
            writeln!(self.outputs[0], " Number of Records Written={:12}", o.standard_output_record_count)?;
            self.outputs[0].close_source_output();
        } else {
            self.outputs[0].delete_source_output()?;
        }

        if o.heat_balance.any_cond_fd {
            self.outputs[1].write_all(b"! <ConductionFiniteDifference Numerical Parameters>, Starting Relaxation Factor, Final Relaxation Factor\n")?;
            return Err(Error::Unavailable(
                "actual CloseOutputFiles CondFDRelaxFactorInput/CondFDRelaxFactor1873 read",
            ));
        }
        self.outputs[1].write_all(b"! <Program Control Information:Threads/Parallel Sims>, Threading Supported,Maximum Number of Threads, Env Set Threads (OMP_NUM_THREADS), EP Env Set Threads (EP_OMP_NUM_THREADS), IDF Set Threads, Number of Threads Used (Interior Radiant Exchange), Number Nominal Surfaces, Number Parallel Sims\n")?;
        let t = &o.system.threading;
        if t.enabled {
            let env = if t.environment_set_threads == 0 { "Not Set".to_owned() } else { t.environment_set_threads.to_string() };
            let ep_env = if t.energyplus_environment_set_threads == 0 { "Not Set".to_owned() } else { t.energyplus_environment_set_threads.to_string() };
            let idf = if t.idf_set_threads == 0 { "Not Set".to_owned() } else { t.idf_set_threads.to_string() };
            if t.number_active_simulations_set {
                writeln!(self.outputs[1], "Program Control Information:Threads/Parallel Sims, Yes,{}, {}, {}, {}, {}, {}, {}", t.max_number_of_threads, env, ep_env, idf, t.number_interior_radiant_threads, t.nominal_total_surfaces, t.number_active_simulations)?;
            } else {
                writeln!(self.outputs[1], "Program Control Information:Threads/Parallel Sims, Yes,{}, {}, {}, {}, {}, {}, N/A", t.max_number_of_threads, env, ep_env, idf, t.number_interior_radiant_threads, t.nominal_total_surfaces)?;
            }
        } else if t.number_active_simulations_set {
            writeln!(self.outputs[1], "Program Control Information:Threads/Parallel Sims, No,{}, N/A, N/A, N/A, N/A, N/A, {}", t.max_number_of_threads, t.number_active_simulations)?;
        } else {
            writeln!(self.outputs[1], "Program Control Information:Threads/Parallel Sims, No,{}, N/A, N/A, N/A, N/A, N/A, N/A", t.max_number_of_threads)?;
        }
        self.outputs[1].write_all(b"End of Data\n")?;
        self.outputs[1].close_source_output();
        self.outputs[2].write_all(b"End of Data\n")?;
        writeln!(self.outputs[2], " Number of Records Written={:12}", o.standard_meter_record_count)?;
        if *o.standard_meter_record_count > 0 {
            self.outputs[2].close_source_output();
        } else {
            self.outputs[2].delete_source_output()?;
        }
        // This is the sole real SHD stream already used/reset by SolarShading;
        // InputOutputFile.close is the same unique_ptr reset234-237.
        o.shading_stream.reset();
        Ok(())
    }
}
''',
'crates/ep_runtime/src/heat_balance/selected_project_data/threading.rs':r'''//! Actual DataSystemVariables.hh140-151 subset on the same SysVars owner.
//! Nine explicit constructors; the pinned production tree has no other writers.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct SourceThreadingSystemVariables {
    pub(crate) environment_set_threads: i32,
    pub(crate) energyplus_environment_set_threads: i32,
    pub(crate) idf_set_threads: i32,
    pub(crate) number_active_simulations: i32,
    pub(crate) number_active_simulations_set: bool,
    pub(crate) max_number_of_threads: i32,
    pub(crate) number_interior_radiant_threads: i32,
    pub(crate) nominal_total_surfaces: i32,
    pub(crate) enabled: bool,
}
impl Default for SourceThreadingSystemVariables {
    fn default() -> Self {
        Self {
            environment_set_threads: 0,
            energyplus_environment_set_threads: 0,
            idf_set_threads: 0,
            number_active_simulations: 1,
            number_active_simulations_set: false,
            max_number_of_threads: 1,
            number_interior_radiant_threads: 1,
            nominal_total_surfaces: 0,
            enabled: false,
        }
    }
}
''',
}
edits={};parent_overrides={}
files_name='crates/ep_runtime/src/heat_balance/source_initialization/files.rs'
am=json.loads(AUD.read_bytes());ar=next(r for r in am['files'] if r['canonical_path']==files_name);parent_overrides[files_name]=ROOT/ar['proposed']['path']
def parent(n):return parent_overrides.get(n,W/n)
def replace(n,old,new):
    b=names.get(n,parent(n).read_text(encoding='utf8'));assert b.count(old)==1,(n,old)
    names[n]=b.replace(old,new,1);edits.setdefault(n,[]).append((old,new))
replace(files_name,'mod endrun_audit;\n','mod endrun_audit;\nmod endrun;\npub(crate) use endrun::SourceCloseOutputFilesOwners;\n')
replace('crates/ep_runtime/src/heat_balance/source_initialization.rs','mod files;\n','mod files;\npub(crate) use files::SourceCloseOutputFilesOwners;\n')
solar='crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep/state.rs'
replace(solar,'    pub(crate) max_hc_array_bounds: i32,\n','    pub(crate) max_hc_array_bounds: i32,\n    /// Actual SolarShading.hh432 ctor0; sole numerical writer is MULTOL4585.\n    pub(crate) max_number_of_figures: i32,\n')
replace(solar,'            max_hc_array_bounds: 0, max_hc_array_increment: 0,\n','            max_hc_array_bounds: 0, max_hc_array_increment: 0, max_number_of_figures: 0,\n')
runtime='crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs'
replace(runtime,'    pub(crate) number_of_actuators_used: usize,\n','    pub(crate) number_of_actuators_used: usize,\n    // Actual DataRuntimeLanguage.hh751-755 constructors; CheckIfAnyEMS does\n    // not reset these GetEMSInput/SetupEMSActuator/InternalVariable cells.\n    pub(crate) number_ems_actuators_available: i32,\n    pub(crate) max_ems_actuators_available: i32,\n    pub(crate) number_internal_variables_used: i32,\n    pub(crate) number_ems_internal_variables_available: i32,\n    pub(crate) max_ems_internal_variables_available: i32,\n')
branch='crates/ep_runtime/src/heat_balance/startup_integrity/nodes.rs'
replace(branch,'    number_node_connections: i32,\n','    number_node_connections: i32,\n    /// Actual DataBranchNodeConnections.hh119 constructor0, same module.\n    max_number_node_connections: i32,\n')
replace(branch,'            number_node_connections: 0,\n','            number_node_connections: 0,\n            max_number_node_connections: 0,\n')
replace('crates/ep_runtime/src/heat_balance/startup_integrity/nodes/reporting.rs','impl SourceBranchNodeConnections {\n','impl SourceBranchNodeConnections {\n    pub(crate) fn source_number_node_connections(&self) -> &i32 {\n        &self.number_node_connections\n    }\n    pub(crate) fn source_max_number_node_connections(&self) -> &i32 {\n        &self.max_number_node_connections\n    }\n')
project='crates/ep_runtime/src/heat_balance/selected_project_data.rs'
replace(project,'mod environment;\n','mod environment;\nmod threading;\n')
replace(project,'pub(crate) struct ProjectSystemVariables {\n','pub(crate) struct ProjectSystemVariables {\n    // Grouped actual threading members; not another SysVars instance.\n    pub(crate) threading: threading::SourceThreadingSystemVariables,\n')
OUT.mkdir()
def put(n,b):
    p=OUT/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(n,o):return put(n,(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode())
for n,t in names.items():put('proposed/'+n,t.encode())
new=[n for n in names if not parent(n).exists()]
fp=run(['rustfmt','--edition','2024','--config','skip_children=true']+[str(OUT/'proposed'/n) for n in new]);fmt=doc('new-child-format.json',dict(exit_code=fp.returncode,stdout=put('format.stdout',fp.stdout),stderr=put('format.stderr',fp.stderr)))
files=[];apps=[];git=[];parse=[];recoveries=[]
for i,n in enumerate(names,1):
    cp=ROOT/n;live_exists=cp.exists();live_bytes=cp.read_bytes() if live_exists else b''
    gp=run(['git','show',HEAD+':'+n],required=False);assert gp.returncode in (0,128)
    exists=gp.returncode==0;before=gp.stdout;assert exists or not before
    pp=parent(n);pexists=pp.exists();pb=pp.read_bytes() if pexists else b'';a=(OUT/'proposed'/n).read_bytes()
    frozen_before=put('before/'+n,before)
    row=dict(canonical_path=n,canonical_at_base_revision=frozen_before,canonical_base_revision=HEAD,canonical_absent_at_base=not exists,live_observation=ref(cp) if live_exists else None,live_absent_observed=not live_exists,live_observation_frozen=put('live-observation/'+n,live_bytes),live_differs_from_base=live_bytes!=before or live_exists!=exists,before=frozen_before,literal_inverse=put('literal-inverse/'+n,before),parent_source=ref(pp) if pexists else None,parent_absent_observed=not pexists,parent_before=put('parent-before/'+n,pb),literal_parent_inverse=put('literal-parent-inverse/'+n,pb),proposed=ref(OUT/'proposed'/n))
    for x,y,k,l,r in [(before,a,'complete_forward_diff','canonical','proposed'),(a,before,'complete_inverse_diff','proposed','canonical'),(pb,a,'parent_forward_diff','parent','proposed'),(a,pb,'parent_inverse_diff','proposed','parent')]:
        patch=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=l+'/'+n,tofile=r+'/'+n)).encode();assert apply_literal(x,patch)==y
        row[k]=put(f'diffs/{i:02}-{k}.diff',patch);apps.append(dict(path=n,role=k,literal_application_passed=True))
    p=gp;assert p.returncode==(0 if exists else 128) and p.stdout==before
    git.append(dict(path=n,revision=HEAD,exit_code=p.returncode,stdout=put('Git/'+n,p.stdout),stderr=put('Git/'+n+'.stderr',p.stderr),actual_absence=not exists))
    if n in edits:
        recovered=a.decode()
        for old,newtxt in reversed(edits[n]):assert recovered.count(newtxt)==1;recovered=recovered.replace(newtxt,old,1)
        assert recovered.encode()==pb;recoveries.append(dict(path=n,exact_literal_edits=edits[n],whole_parent_recovered=True))
    assert a.count(b'#[test]')==pb.count(b'#[test]')
    cmd=['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(OUT/'proposed'/n)];p=run(cmd);assert (OUT/'proposed'/n).read_bytes()==a
    parse.append(dict(path=n,command=cmd,exit_code=p.returncode,stdout=put(f'parse/{i:02}.stdout',p.stdout),stderr=put(f'parse/{i:02}.stderr',p.stderr),proposed_bytes_unchanged=True));files.append(row)
# Whole Native Git custody and exact finite extents, never silently truncate EOF.
ranges=[('SimulationManager.cc',1764,1955),('IOFiles.cc',232,246),('FileSystem.cc',324,332),('DataGlobals.hh',112,118),('SolarShading.hh',425,436),('SolarShading.cc',4562,4590),('SolarShading.cc',6265,6285),('SolarShading.cc',6470,6483),('SolarShading.cc',9225,9240),('SolarShading.cc',9325,9343),('DataRuntimeLanguage.hh',745,757),('EMSManager.cc',260,275),('EMSManager.cc',775,788),('EMSManager.cc',2037,2056),('EMSManager.cc',2090,2108),('EMSManager.cc',2143,2162),('EMSManager.cc',2197,2215),('EMSManager.cc',2246,2265),('DataBranchNodeConnections.hh',111,124),('BranchNodeConnections.cc',651,742),('DataSystemVariables.hh',138,153),('SQLiteProcedures.cc',166,172)]
originals=[];ng=[];seen=set()
for n,first,last in ranges:
    p=N/'src/EnergyPlus'/n;b=p.read_bytes();ls=b.splitlines(keepends=True);assert 1<=first<=last<=len(ls)
    if n not in seen:
        assert run(['git','show',PIN+':src/EnergyPlus/'+n],cwd=N).stdout==b;seen.add(n);ng.append(dict(source=ref(p),revision=PIN,actual_whole_stdout_equal=True))
    originals.append(dict(source=ref(p),first_line=first,last_line=last,literal_excerpt=put('Original/'+n.replace('/','__')+f'-{first}-{last}.txt',b''.join(ls[first-1:last])),strict_EOF=True))
# Retain every occurrence across the full pinned Native production tree for
# missing scalar write audits, including declaration/clear/read occurrences.
patterns={
'solar_max_number_of_figures':r'\bmaxNumberOfFigures\b',
'runtime_language_close_counters':r'\b(?:numEMSActuatorsAvailable|maxEMSActuatorsAvailable|NumInternalVariablesUsed|numEMSInternalVarsAvailable|maxEMSInternalVarsAvailable)\b',
'branch_max_connections':r'\bMaxNumOfNodeConnections\b',
'threading_members':r'\b(?:iEnvSetThreads|iepEnvSetThreads|iIDFSetThreads|inumActiveSims|lnumActiveSims|MaxNumberOfThreads|NumberIntRadThreads|iNominalTotSurfaces|Threading)\b',
}
census=[]
for label,pattern in patterns.items():
    rows=[];rx=re.compile(pattern)
    for p in sorted((N/'src/EnergyPlus').rglob('*')):
        if p.suffix not in ('.cc','.hh'):continue
        hits=[dict(line=i,text=t) for i,t in enumerate(p.read_text(encoding='utf8').splitlines(),1) if rx.search(t)]
        if hits:rows.append(dict(source=ref(p),occurrences=hits))
    census.append(dict(name=label,pattern=pattern,suffixes=['.cc','.hh'],scope='full pinned src/EnergyPlus production tree',results=doc('Native-occurrences/'+label+'.json',rows)))
reads_names=['crates/ep_runtime/src/heat_balance/ordinary_source_session/body.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs','crates/ep_runtime/src/heat_balance/source_output_registration/report_writers.rs','crates/ep_runtime/src/heat_balance/source_output_registration/update_data.rs','crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep/period.rs','crates/ep_runtime/src/heat_balance/ordinary_ems_plugin.rs','crates/ep_runtime/src/heat_balance/ordinary_exterior_energy_use/getter.rs','crates/ep_runtime/src/heat_balance/radiation/ordinary/shading_report.rs','crates/ep_runtime/src/heat_balance/source_output_registration.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/ancillary.rs','crates/ep_runtime/src/heat_balance/source_initialization/output_reporting.rs']
reads=[ref(W/n) for n in reads_names]
proof=doc('same-owner-write-and-close-proof.json',dict(
counts={'source':'same reports.source_standard_output_record_count/source_standard_meter_record_count i64 refs','actual_producer':'ordinary_source_session/body passes actual cells into OP updates; report_writers and update_data increment them, not weather count/ESO result reconstruction','OP9':'reads all nine existing SetupOutputVariable counters in actual order; meter vector size is the actual same SourceMeters.meters vector Native meters.size()'},
solar={'new':'one actual maxNumberOfFigures ctor0 on existing SourceSolarTimestepState belonging to same OrdinarySolarRadiation','sole_numerical_writer':'Native MULTOL4585; all4 call sites retained in strict Original extents','finite_path':'same Source Minimal determines each real combination before counts0; reached general/sub-surface routes are bounded at real polygon/subsurface child. Source source_shadow reads actual real counts and returns before positive polygon operations; no MULTOL runs or reset is invented','existing':'same max_hc_array_bounds actual allocation writer; same geometry.coordinate.max_vertices_per_surface actual vertex producer'},
EMS={'new':'5 actual RuntimeLanguage ctor0 counters, preserved on same SelectedRuntimeLanguage; CheckIfAnyEMS does not overwrite them','sole_writers':'GetEMSInput782 plus3 SetupEMSActuator overloads and2 SetupEMSInternalVariable overloads; full production occurrence census retained','finite_admission':'same check_if_any_ems rejects actual positive EMS/API/plugin/EDD producer before ordinary simulation; same ManageEMS actual AnyEMS false quick return precedes InitEMS; actual SourceExterior positive setup is typed unavailable','not_AnyEMS_inferred_results':'no counter derived from current flag or input absence in reporting; actual retained constructor cells read directly'},
Branch={'new':'one actual MaxNumOfNodeConnections ctor0 on EXISTING session.hvac.ancillary.branch_node_connections; no new DataBranch or LoopNode instance','existing':'number_node_connections reused unchanged via reference accessor','sole_writer':'RegisterNodeConnection722-728; Source positive node construction/record checks remain typed bounds, no registration writer present; complete max counter occurrence census retained'},
Threading={'new':'9 actual SysVars members grouped as a subset of SAME ProjectSystemVariables; literal Native.hh140-151 constructor values including1 threads/active simulation','writer_census':'full pinned Native production .cc/.hh census: only struct ctor/clear_state assignments, production CloseOutputFiles reads; no environment read or guessed OMP override added','all_branches':'Native enabled/activeSim tests, exact Not Set versus N/A spellings and all four thread report branches retained'},
physical_files={'identity':'same Files ESO/EIO/MTR handles and same session SHD stream; audit not closed by Native606','order':'audit26? actual lines then ESO marker and counter-positive close/zero delete; optionalCondFD header before first unavailable relaxation reads; threading header/data; EIO marker/close; MTR marker/count then close/delete; SHD reset','deleted_paths':'only exact same retained selected ESO/MTR pathname after original close-before-delete; absent file means no effect; real deletion OS failures propagate','normal_close':'drop closes real File handles without sync/flush/reopen; exceptional OS close failures unobservable through Rust File drop are explicitly unclaimed','no_extra_closes':'BND/debug/audit/dictionaries stay as Native function leaves them'},
SQL609={'not_implemented_here':'same actual nullable SourceSqliteState.database remains constructor-null; Root caller must preserve CreateSQLiteZoneExtendedOutput169 guard before outerSQL611 andErrorsFound617','no_success_route_activation':True},
parent_overrides={files_name:ref(parent(files_name))},whole_parent_recoveries=recoveries,new_actual_constructor_cells=16,new_test_bodies=0,caller_not_changed=True))
assert len(files)==9 and len(apps)==36 and len(recoveries)==7
manifest=doc('manifest.json',dict(schema='src06-held-close-output-files.v1',status='HELD complete ordinary CloseOutputFiles606 child; independent peer/caller/assembly/typecheck/physical verification pending',base_HEAD=HEAD,live_HEAD_observed=LIVE_HEAD,canonical_bridge='Canonical09 may be in progress after base36b; before/diffs authenticate exact historical Git36b bytes. Separate frozen live observations are retained and are NOT treated as baseline aliases. Parent Source proposals stay frozen Root77/audit01; future promotion must use narrow literal edits with explicit09 bridge.',parent=ref(P),tabular_audit_prerequisite=ref(AUD),files=files,Original_commit=PIN,Original_authority=originals,actual_readonly_Native_Git=ng,actual_historical_base_Git=git,Native_whole_tree_occurrence_census=census,read_only_existing_Source_APIs=reads,same_owner_write_and_close_proof=proof,Source_only_parse=parse,new_child_format=fmt,literal_diff_applications=apps,author_Source=ref(Path(__file__).resolve()),API={'CloseOutputFiles606':'SourceInitializationFiles::close_source_output_files(&mut self,&mut SourceCloseOutputFilesOwners)->Result<(),HeatBalanceInputError>','owner_exports':'source_initialization::SourceCloseOutputFilesOwners','actual_reference_members':13},scope={'new_files':2,'old_files_narrow_edits':7,'new_actual_constructor_cells':16,'same_TAB_audit_leaf_required':True,'Files_diagnostic_observers':'only module/type reexports added to full frozen audit-prerequisite File parent; canonical promotion must use exact narrow additions and exclude observer9','Native_feature_scope':'ordinary production without EP_Count_Calls instrumentation','positive_boundary':'AnyCondFD prints actual first header then stops at real missing relaxation-member reads; no relaxed values supplied','exception_scope':'successfully opened retained streams and successful close/delete; real write/open/delete IO failure retained, no whole C++ exceptional-state equivalence','no_dispatch_or_caller_edit':True,'no_whole_run_or_gate_claim':True},canonical_changes=0,Git_mutations=0,Cargo_or_Native_executed=False,new_test_bodies=0))
print(json.dumps(manifest))

from pathlib import Path
import hashlib,json,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'resilience-report-draft-Audit-01'
H='crates/ep_runtime/src/heat_balance/';main=H+'ordinary_tabular_reports.rs'
P=B/'ordinary-predefined-report-held-Audit-01/manifest.json'
assert hashlib.sha256(P.read_bytes()).hexdigest()=='02880decb5568a984e91f40929323c0103ab1571e8c74ffee56236809846f1f8'
M=json.loads(P.read_bytes());parent=R/next(x['proposed']['path'] for x in M['files'] if x['canonical_path']==main)
N=R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/OutputReportTabular.cc'
native=N.read_text(encoding='utf8')
source={}
source[main]=parent.read_text(encoding='utf8')+'\nmod resilience_report;\npub(crate) use resilience_report::SourceResilienceTableOwners;\n'
source[H+'ordinary_tabular_reports/resilience_report.rs']=r'''//! WriteThermal/CO2/VisualResilienceTables on the actual retained Zone bins.
//! These reporters neither gather nor initialize scientific state.
mod bins;
mod thermal;
mod values;
use super::{Error, SourceTabularBody, SourceTabularReports, SourceTabularWriterOwners};
use crate::heat_balance::ctf_initialization_context::internal_heat_gains_input::SelectedInternalHeatGains;
use crate::heat_balance::ctf_reports::PredefinedStringTable;
use crate::heat_balance::ordinary_output_control::SourceResultsFrameworkOptions;
use crate::heat_balance::predefined_tables::PredefinedRegistry;
use crate::heat_balance::selected_heat_balance_globals::SelectedHeatBalanceGlobals;
use crate::heat_balance::selected_heat_balance_input::zone::SelectedZoneInputOwners;
use crate::heat_balance::source_initialization::SourceSqliteState;
use crate::heat_balance::source_output_registration::SourceOutputStoreType;
use values::{Field, count, index, value, zone_name};

pub(crate) struct SourceResilienceTableOwners<'a, 'backend> {
    pub(crate) globals: &'a SelectedHeatBalanceGlobals,
    pub(crate) zones: &'a SelectedZoneInputOwners,
    pub(crate) gains: &'a SelectedInternalHeatGains,
    pub(crate) registry: &'a PredefinedRegistry,
    pub(crate) table: &'a mut PredefinedStringTable,
    pub(crate) results: &'a SourceResultsFrameworkOptions,
    pub(crate) sqlite: &'a SourceSqliteState,
    pub(crate) writer: SourceTabularWriterOwners<'a, 'backend>,
}

// Actual local column arrays/body. RowHead is independently allocated/reused
// by Native thermal/unmet/discomfort helpers and is passed by mutable reference.
struct Columns {
    headings: Vec<Vec<u8>>,
    widths: Vec<i32>,
    body: SourceTabularBody,
}
impl Columns {
    fn allocate(columns: usize, rows: usize) -> Result<Self, Error> {
        let widths = vec![10; columns];
        let headings = vec![Vec::new(); columns];
        let body = SourceTabularBody::allocate(columns, rows)?;
        Ok(Self {headings,widths,body})
    }
    fn headings(&mut self, headings: &[&str]) -> Result<(), Error> {
        if self.headings.len()!=headings.len(){return Err(Error::Unavailable("actual resilience heading array extent"));}
        for (target, text) in self.headings.iter_mut().zip(headings) { *target=text.as_bytes().to_vec(); }
        Ok(())
    }
}

impl SourceTabularReports {
    fn resilience_real(&self, pass:usize, value:f64)->Result<Vec<u8>,Error>{
        super::beps_report::source_report_real(self.input_state.tabular_report_passes[pass].format_reals,value,2)
    }
    fn resilience_subtitle(&mut self,pass:usize,title:&[u8])->Result<(),Error>{
        if self.input_state.tabular_report_passes[pass].produce_tabular {self.write_source_subtitle(title)?;}
        Ok(())
    }
    fn resilience_emit(&mut self,pass:usize,title:&[u8],rows:&[Vec<u8>],cols:&mut Columns,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        if self.input_state.tabular_report_passes[pass].produce_tabular {
            self.write_source_table(&cols.body,rows,&cols.headings,&mut cols.widths,false,b"",&mut o.writer)?;
        }
        if self.input_state.tabular_report_passes[pass].produce_sqlite && o.sqlite.present(){
            return Err(Error::Unavailable("actual resilience createSQLiteTabularDataRecords after physical table"));
        }
        if self.input_state.tabular_report_passes[pass].produce_json && o.results.time_series_and_tabular_enabled {
            return Err(Error::Unavailable("actual resilience TabularReportsCollection.addReportTable after SQLite"));
        }
        let _=title;
        Ok(())
    }
    // Native12884-12915. These are actual PreDef numeric writes, not physical
    // tables here; the later sole WritePredefinedTables consumes these entries.
    fn resilience_predefined(&mut self,columns:&[&str],field:Field,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        let mut ids=Vec::with_capacity(columns.len());
        for name in columns { ids.push(*o.registry.named_indices.get(*name).ok_or(Error::Unavailable("actual resilience predefined column owner"))?); }
        let mut max=vec![0.0;columns.len()];
        let mut min=vec![0.0;columns.len()];
        let mut sum=vec![0.0;columns.len()];
        for j in 0..columns.len(){min[j]=value(o.zones,1,field,j)? * 1.0;}
        for zone in 1..=o.globals.num_of_zones {
            let name=zone_name(o.zones,zone)?;
            for j in 0..columns.len(){
                let current=value(o.zones,zone,field,j)? * 1.0;
                if current>max[j]{max[j]=current;}
                if current<min[j]{min[j]=current;}
                sum[j]+=current;
                o.table.fixed_real_entry_2(ids[j],name,current)?;
            }
        }
        for j in 0..columns.len(){
            o.table.fixed_real_entry_2(ids[j],"Min",min[j])?;
            o.table.fixed_real_entry_2(ids[j],"Max",max[j])?;
            o.table.fixed_real_entry_2(ids[j],"Average",sum[j]/f64::from(o.globals.num_of_zones))?;
            o.table.fixed_real_entry_2(ids[j],"Sum",sum[j])?;
        }
        Ok(())
    }
    pub(crate) fn write_source_co2_resilience_tables(&mut self,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        if o.globals.num_of_zones<=0{return Ok(());}
        self.resilience_predefined(&["pdchCO2HourSafe","pdchCO2HourCaution","pdchCO2HourHazard"],Field::Co2,o)?;
        self.resilience_predefined(&["pdchCO2OccuHourSafe","pdchCO2OccuHourCaution","pdchCO2OccuHourHazard"],Field::Co2Occu,o)?;
        self.resilience_predefined(&["pdchCO2OccupiedHourSafe","pdchCO2OccupiedHourCaution","pdchCO2OccupiedHourHazard"],Field::Co2Occupied,o)?;
        Ok(())
    }
    pub(crate) fn write_source_visual_resilience_tables(&mut self,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        // The genuine per-Zone daylight array is allocated with Zone at Native
        // HeatBalanceManager1854, even when no Daylighting Controls are present.
        for zone in 1..=o.globals.num_of_zones {
            let daylight=o.zones.zone_daylight.as_ref().and_then(|rows|index(zone).ok().and_then(|i|rows.get(i)))
                .ok_or(Error::Unavailable("actual WriteVisualResilience13758 ZoneDaylight row"))?;
            if daylight.total_reference_points==0 && self.display_visual_resilience_summary_explicitly {
                o.writer.backend.show_warning_error(&format!("Writing Annual Visual Resilience Summary - Lighting Level Hours reports: Zone Average Daylighting Reference Point Illuminance output is required, but no Daylighting Controls are defined in Zone:{}",zone_name(o.zones,zone)?))?;
            }
        }
        if o.globals.num_of_zones<=0{return Ok(());}
        self.resilience_predefined(&["pdchIllumHourDark","pdchIllumHourDim","pdchIllumHourAdequate","pdchIllumHourBright"],Field::Lighting,o)?;
        self.resilience_predefined(&["pdchIllumOccuHourDark","pdchIllumOccuHourDim","pdchIllumOccuHourAdequate","pdchIllumOccuHourBright"],Field::LightingOccu,o)?;
        self.resilience_predefined(&["pdchIllumOccupiedHourDark","pdchIllumOccupiedHourDim","pdchIllumOccupiedHourAdequate","pdchIllumOccupiedHourBright"],Field::LightingOccupied,o)?;
        Ok(())
    }
}
'''
fields={
 'HeatIndex':'zone_heat_index_hour_bins','HeatIndexOccu':'zone_heat_index_occu_hour_bins','HeatIndexOccupied':'zone_heat_index_occupied_hour_bins',
 'Humidex':'zone_humidex_hour_bins','HumidexOccu':'zone_humidex_occu_hour_bins','HumidexOccupied':'zone_humidex_occupied_hour_bins',
 'LowSet':'zone_low_set_hours','HighSet':'zone_high_set_hours','ColdSafety':'zone_cold_hour_of_safety_bins','HeatSafety':'zone_heat_hour_of_safety_bins',
 'Unmet':'zone_unmet_degree_hour_bins','DiscomfortOccu':'zone_discomfort_wt_exceed_occu_hour_bins','DiscomfortOccupied':'zone_discomfort_wt_exceed_occupied_hour_bins',
 'Co2':'zone_co2_level_hour_bins','Co2Occu':'zone_co2_level_occu_hour_bins','Co2Occupied':'zone_co2_level_occupied_hour_bins',
 'Lighting':'zone_lighting_level_hour_bins','LightingOccu':'zone_lighting_level_occu_hour_bins','LightingOccupied':'zone_lighting_level_occupied_hour_bins'}
source[H+'ordinary_tabular_reports/resilience_report/values.rs']='''//! Checked access to actual existing Zone/Resilience cells; no fallback values.
use super::{Error,SelectedZoneInputOwners};
#[derive(Clone, Copy)]
pub(super) enum Field {'''+','.join(fields)+'''}
pub(super) fn count(n:i32)->Result<usize,Error>{usize::try_from(n).map_err(|_|Error::Unavailable("actual resilience array extent"))}
pub(super) fn index(n:i32)->Result<usize,Error>{count(n.checked_sub(1).ok_or(Error::Unavailable("actual resilience ordinal subtraction"))?)}
pub(super) fn zone_name(zones:&SelectedZoneInputOwners,n:i32)->Result<&str,Error>{
    zones.zones.as_ref().and_then(|v|index(n).ok().and_then(|i|v.get(i))).map(|v|v.name.as_str()).ok_or(Error::Unavailable("actual resilience Zone.Name owner"))
}
pub(super) fn value(zones:&SelectedZoneInputOwners,n:i32,field:Field,j:usize)->Result<f64,Error>{
    let row=zones.resilience.as_ref().and_then(|v|index(n).ok().and_then(|i|v.get(i))).ok_or(Error::Unavailable("actual retained ZoneResilience owner"))?;
    let values:&[f64]=match field {'''+''.join(f'Field::{k}=>&row.{v},' for k,v in fields.items())+'''};
    values.get(j).copied().ok_or(Error::Unavailable("actual resilience std::array.at bin ordinal"))
}
pub(super) fn date(value:f64)->Result<Vec<u8>,Error>{
    // Native13236/13104 converts double to the actual DateToString int argument.
    let integer=value.trunc();
    if !integer.is_finite() || integer<f64::from(i32::MIN) || integer>f64::from(i32::MAX){return Err(Error::Unavailable("actual resilience DateToString double-to-int defined domain"));}
    Ok(super::super::remaining::source_date_to_string(integer as i32)?.into_bytes())
}
'''
source[H+'ordinary_tabular_reports/resilience_report/bins.rs']=r'''//! Native12918-12982,13065-13135,13216-13295 local table helpers.
use super::{Columns,Error,Field,SourceResilienceTableOwners,SourceTabularReports,count,value,zone_name};
use super::values::date;
impl SourceTabularReports {
    pub(super) fn resilience_bins(&mut self,pass:usize,title:&[u8],field:Field,multiplier:f64,rows:&mut[Vec<u8>],cols:&mut Columns,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        self.resilience_subtitle(pass,title)?;
        let n=cols.headings.len();
        let mut max=vec![0.0;n];let mut min=vec![0.0;n];let mut sum=vec![0.0;n];
        for j in 0..n { min[j]=value(o.zones,1,field,j)?*multiplier; }
        for zone in 1..=o.globals.num_of_zones {
            let i=count(zone)?;
            rows[i-1]=zone_name(o.zones,zone)?.as_bytes().to_vec();
            for j in 0..n {
                let current=value(o.zones,zone,field,j)?*multiplier;
                if current>max[j]{max[j]=current;}
                if current<min[j]{min[j]=current;}
                sum[j]+=current;
                cols.body.set(j+1,i,self.resilience_real(pass,current)?)?;
            }
        }
        let zones=count(o.globals.num_of_zones)?;
        rows[zones]=b"Min".to_vec();rows[zones+1]=b"Max".to_vec();rows[zones+2]=b"Average".to_vec();rows[zones+3]=b"Sum".to_vec();
        for j in 0..n {
            cols.body.set(j+1,zones+1,self.resilience_real(pass,min[j])?)?;
            cols.body.set(j+1,zones+2,self.resilience_real(pass,max[j])?)?;
            cols.body.set(j+1,zones+3,self.resilience_real(pass,sum[j]/f64::from(o.globals.num_of_zones))?)?;
            cols.body.set(j+1,zones+4,self.resilience_real(pass,sum[j])?)?;
        }
        self.resilience_emit(pass,title,rows,cols,o)
    }
    pub(super) fn resilience_safety(&mut self,pass:usize,title:&[u8],field:Field,rows:&mut[Vec<u8>],cols:&mut Columns,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        self.resilience_subtitle(pass,title)?;
        let n=cols.headings.len();
        for zone in 1..=o.globals.num_of_zones {
            let i=count(zone)?;
            rows[i-1]=zone_name(o.zones,zone)?.as_bytes().to_vec();
            for j in 1..=n {cols.body.set(j,i,self.resilience_real(pass,value(o.zones,zone,field,j-1)?)?)?;}
            cols.body.set(2,i,date(value(o.zones,zone,field,1)?)?)?;
        }
        let mut max=vec![0.0;n];let mut min=vec![0.0;n];let mut sum=vec![0.0;n];
        for j in 0..n {min[j]=value(o.zones,1,field,j)?;}
        for zone in 1..=o.globals.num_of_zones {
            for j in 0..n {
                let current=value(o.zones,zone,field,j)?;
                if current>max[j]{max[j]=current;}
                if current<min[j]{min[j]=current;}
                sum[j]+=current;
            }
        }
        let zones=count(o.globals.num_of_zones)?;
        rows[zones]=b"Min".to_vec();rows[zones+1]=b"Max".to_vec();rows[zones+2]=b"Average".to_vec();rows[zones+3]=b"Sum".to_vec();
        for j in 0..n {
            cols.body.set(j+1,zones+1,self.resilience_real(pass,min[j])?)?;
            cols.body.set(j+1,zones+2,self.resilience_real(pass,max[j])?)?;
            cols.body.set(j+1,zones+3,self.resilience_real(pass,sum[j]/f64::from(o.globals.num_of_zones))?)?;
            cols.body.set(j+1,zones+4,self.resilience_real(pass,sum[j])?)?;
        }
        for i in 1..5 {cols.body.set(2,zones+i,b"-".to_vec())?;}
        self.resilience_emit(pass,title,rows,cols,o)
    }
    pub(super) fn resilience_set(&mut self,pass:usize,title:&[u8],field:Field,unit_multiplier:f64,rows:&mut[Vec<u8>],cols:&mut Columns,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        self.resilience_subtitle(pass,title)?;
        let n=cols.headings.len();
        let mut max=vec![0.0;n-1];let mut min=vec![0.0;n-1];let mut sum=vec![0.0;n-1];
        let mut multiplier=vec![unit_multiplier;n-1];multiplier[n-2]=1.0;
        for j in 0..n-1 {min[j]=value(o.zones,1,field,j)?*multiplier[j];}
        for zone in 1..=o.globals.num_of_zones {
            let i=count(zone)?;
            rows[i-1]=zone_name(o.zones,zone)?.as_bytes().to_vec();
            for j in 0..n-1 {
                let current=value(o.zones,zone,field,j)?*multiplier[j];
                if current>max[j]{max[j]=current;}
                if current<min[j]{min[j]=current;}
                sum[j]+=current;
                cols.body.set(j+1,i,self.resilience_real(pass,current)?)?;
            }
            cols.body.set(n,i,date(value(o.zones,zone,field,n-1)?)?)?;
        }
        let zones=count(o.globals.num_of_zones)?;
        rows[zones]=b"Min".to_vec();rows[zones+1]=b"Max".to_vec();rows[zones+2]=b"Average".to_vec();
        for j in 0..n-1 {
            cols.body.set(j+1,zones+1,self.resilience_real(pass,min[j])?)?;
            cols.body.set(j+1,zones+2,self.resilience_real(pass,max[j])?)?;
            cols.body.set(j+1,zones+3,self.resilience_real(pass,sum[j]/f64::from(o.globals.num_of_zones))?)?;
        }
        cols.body.set(n,zones+1,b"-".to_vec())?;cols.body.set(n,zones+2,b"-".to_vec())?;cols.body.set(n,zones+3,b"-".to_vec())?;
        self.resilience_emit(pass,title,rows,cols,o)
    }
}
'''
thermal=r'''//! Full Native13417-13656 annual thermal body; SI and same live format passes.
use super::*;
impl SourceTabularReports {
    pub(crate) fn write_source_thermal_resilience_tables(&mut self,o:&mut SourceResilienceTableOwners<'_, '_>)->Result<(),Error>{
        if o.globals.num_of_zones<=0{return Ok(());}
        for pass in 0..self.input_state.tabular_report_passes.len(){
            if matches!(self.input_state.tabular_report_passes[pass].units_style,4|5){
                return Err(Error::Unavailable("actual ThermalResilience13429 getSpecificUnitMultiplier Celsius-hour to Fahrenheit-hour first operation"));
            }
            let degree_hour_conversion=1.0;
            if self.input_state.tabular_report_passes[pass].produce_tabular {
                self.write_source_report_headers(b"Annual Thermal Resilience Summary",b"Entire Facility",SourceOutputStoreType::Average)?;
            }
            let zones=count(o.globals.num_of_zones)?;
            let row_count=count(o.globals.num_of_zones.checked_add(4).ok_or(Error::Unavailable("actual thermal row allocation signed extent"))?)?;
            let widths=vec![10;5];
            let mut rows=vec![Vec::new();row_count];
            let body=SourceTabularBody::allocate(5,row_count)?;
            let mut c=Columns{headings:vec![Vec::new();5],widths,body};
            c.headings(HEAT_INDEX)?;
            self.resilience_bins(pass,b"Heat Index Hours",Field::HeatIndex,1.0,&mut rows,&mut c,o)?;
            self.resilience_bins(pass,b"Heat Index OccupantHours",Field::HeatIndexOccu,1.0,&mut rows,&mut c,o)?;
            self.resilience_bins(pass,b"Heat Index OccupiedHours",Field::HeatIndexOccupied,1.0,&mut rows,&mut c,o)?;
            c.headings(HUMIDEX)?;
            self.resilience_bins(pass,b"Humidex Hours",Field::Humidex,1.0,&mut rows,&mut c,o)?;
            self.resilience_bins(pass,b"Humidex OccupantHours",Field::HumidexOccu,1.0,&mut rows,&mut c,o)?;
            self.resilience_bins(pass,b"Humidex OccupiedHours",Field::HumidexOccupied,1.0,&mut rows,&mut c,o)?;
            let mut has_pierce_set=true;
            if o.gains.totals[0]==0 {
                has_pierce_set=false;
                if self.display_thermal_resilience_summary_explicitly {
                    o.writer.backend.show_warning_error("Writing Annual Thermal Resilience Summary - SET Degree-Hours reports: Zone Thermal Comfort Pierce Model Standard Effective Temperature is required, but no People object is defined.")?;
                }
            }
            for people in 1..=o.gains.totals[0] {
                let person=o.gains.allocations.people.get(index(people)?).ok_or(Error::Unavailable("actual ThermalResilience13511 People.Pierce row"))?;
                if !person.pierce {
                    has_pierce_set=false;
                    if self.display_thermal_resilience_summary_explicitly {
                        o.writer.backend.show_warning_error(&format!("Writing Annual Thermal Resilience Summary - SET Degree-Hours reports: Zone Thermal Comfort Pierce Model Standard Effective Temperature is required, but no Pierce model is defined in {} object.",person.name))?;
                    }
                }
            }
            if has_pierce_set {
                // Native applies the same >30C column headings to both tables.
                c.headings(SET)?;
                let mut set_rows=vec![Vec::new();count(o.globals.num_of_zones.checked_add(3).ok_or(Error::Unavailable("actual SET row extent"))?)?];
                let mut set_c=Columns{headings:c.headings.clone(),widths:Vec::new(),body:SourceTabularBody::allocate(5,set_rows.len())?};
                // The very same columnWidth array carries WriteTable mutations
                // from prior thermal tables and both SET helpers into safety.
                std::mem::swap(&mut set_c.widths,&mut c.widths);
                self.resilience_set(pass,b"Heating SET Degree-Hours",Field::LowSet,degree_hour_conversion,&mut set_rows,&mut set_c,o)?;
                self.resilience_set(pass,b"Cooling SET Degree-Hours",Field::HighSet,degree_hour_conversion,&mut set_rows,&mut set_c,o)?;
                std::mem::swap(&mut set_c.widths,&mut c.widths);
            }
            c.headings(SAFETY)?;
            self.resilience_safety(pass,b"Hours of Safety for Cold Events",Field::ColdSafety,&mut rows,&mut c,o)?;
            self.resilience_safety(pass,b"Hours of Safety for Heat Events",Field::HeatSafety,&mut rows,&mut c,o)?;
            let mut unmet=Columns::allocate(6,row_count)?;
            unmet.headings(UNMET)?;
            self.resilience_bins(pass,b"Unmet Degree-Hours",Field::Unmet,degree_hour_conversion,&mut rows,&mut unmet,o)?;
            // Native13631-13635 reallocates these same three local arrays.
            c.headings=vec![Vec::new();4];
            c.widths=vec![10;4];
            c.body=SourceTabularBody::allocate(4,row_count)?;
            c.headings(DISCOMFORT)?;
            self.resilience_bins(pass,b"Discomfort-weighted Exceedance OccupantHours",Field::DiscomfortOccu,1.0,&mut rows,&mut c,o)?;
            self.resilience_bins(pass,b"Discomfort-weighted Exceedance OccupiedHours",Field::DiscomfortOccupied,1.0,&mut rows,&mut c,o)?;
        }
        Ok(())
    }
}
'''
def labels(lo,hi,var):
 lines=N.read_text(encoding='utf8').splitlines()[lo-1:hi]
 return re.findall(rf'{var}\(\d+\) = "([^"]*)";', '\n'.join(lines))
for name,lo,hi,var in [('HEAT_INDEX',13455,13460,'columnHeadStr'),('HUMIDEX',13478,13482,'columnHeadStr'),('SET',13530,13535,'columnHeadStr'),('SAFETY',13575,13579,'columnHeadStr'),('UNMET',13594,13599,'columnHeadUnmetDegHr'),('DISCOMFORT',13633,13636,'columnHeadStr')]:
 strings=labels(lo,hi,var);expected=6 if name=='UNMET' else 4 if name=='DISCOMFORT' else 5
 assert len(strings)==expected,(name,strings)
 thermal+=f'const {name}: &[&str] = &'+json.dumps(strings,ensure_ascii=False)+';\n'
source[H+'ordinary_tabular_reports/resilience_report/thermal.rs']=thermal
for name,txt in source.items():
 p=D/'proposed'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(txt.encode('utf8'))
 q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=p.read_bytes(),capture_output=True)
 assert q.returncode==0,(name,q.stderr.decode())
 # Formatting is applied only to these private unsealed drafts.
 if name!=main:p.write_bytes(q.stdout)
print(json.dumps({'draft':D.relative_to(R).as_posix(),'paths':list(source)},ensure_ascii=False))

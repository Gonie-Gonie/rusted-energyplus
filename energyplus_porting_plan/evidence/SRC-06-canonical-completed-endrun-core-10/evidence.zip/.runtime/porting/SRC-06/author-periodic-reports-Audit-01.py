from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();B=R/'.runtime/porting/SRC-06';D=B/'periodic-reports-draft-Audit-01';H='crates/ep_runtime/src/heat_balance/';main=H+'ordinary_tabular_reports.rs'
P=B/'ordinary-resilience-report-held-Audit-01/manifest.json';assert hashlib.sha256(P.read_bytes()).hexdigest()=='309742d37c2ee990ec2fb753665b5226929bd38cfc34631c184d81151f3a68f9'
M=json.loads(P.read_bytes());parent=R/next(x['proposed']['path'] for x in M['files'] if x['canonical_path']==main)
N=R/'.reference/energyplus-src/26.1.0/src/EnergyPlus/OutputReportTabular.cc';native=N.read_text(encoding='utf8');monthly=native[native.index('void WriteMonthlyTables('):native.index('void WriteTimeBinTables(')];bins=native[native.index('void WriteTimeBinTables('):native.index('void WriteBEPSTable(')]
def row_labels(body,count):
 a=re.findall(r'rowHead\((\d+)\) = "([^"]*)";',body)
 assert [int(n) for n,_ in a]==list(range(1,count+1)),a
 return [s for _,s in a]
month_labels=row_labels(monthly,16);bin_labels=row_labels(bins,39)
agg=re.findall(r'\{AggType::([A-Za-z]+), "([^"]*)"\}',monthly);assert len(agg)==13
expected=['SumOrAvg','Maximum','Minimum','ValueWhenMaxMin','HoursZero','HoursNonZero','HoursPositive','HoursNonPositive','HoursNegative','HoursNonNegative','SumOrAverageHoursShown','MaximumDuringHoursShown','MinimumDuringHoursShown'];assert [a for a,_ in agg]==expected
body=r'''//! Actual WriteMonthlyTables7056, TimeBin7500 and Annual::WriteAnnualTables643.
//! These genuine empty-domain bodies read retained counts/vectors, not raw IP.
use super::{Error,SourceTabularBody,SourceTabularReports};
use std::collections::HashMap;

impl SourceTabularReports {
    pub(crate) fn write_source_monthly_tables(&mut self)->Result<(),Error>{
        // Native7078 Array1D_string rowHead(16), before all passes/count guards.
        let mut row_head=vec![Vec::<u8>::new();16];
        const STORED_MAX_VAL:f64=f64::MAX;
        const STORED_MIN_VAL:f64=f64::MIN;
        for (row,label) in row_head.iter_mut().zip(MONTHLY_ROWS){*row=label.as_bytes().to_vec();}
        // Original7130 unordered_map<AggType,string>, including original case
        // and spaces. No map traversal order affects any report or state.
        let agg_string:HashMap<i32,Vec<u8>>=AGGREGATION.iter().enumerate()
            .map(|(number,(_name,text))|(number as i32,text.as_bytes().to_vec())).collect();
        let very_large=1.0E280;
        let very_small=-1.0E280;
        for current_style in &self.input_state.tabular_report_passes {
            // Native7148-7164 assignments occur even with MonthlyInputCount0.
            let (energy_units_string,energy_units_conversion_factor)=match current_style.units_style {
                0=>(b"J".to_vec(),1.0),
                1=>(b"kWh".to_vec(),1.0/3600000.0),
                2=>(b"MJ".to_vec(),1.0/1000000.0),
                3=>(b"GJ".to_vec(),1.0/1000000000.0),
                _=>(b"J".to_vec(),1.0),
            };
            for _input in 1..=self.input_state.monthly_input_count {
                // MonthlyInput is a distinct Native record array. Existing
                // MonthlyTables/Columns empty allocations are not that owner.
                return Err(Error::Unavailable("actual WriteMonthlyTables7169 MonthlyInput(iInput).showDigits first record read"));
            }
            drop((energy_units_string,energy_units_conversion_factor));
        }
        drop((row_head,agg_string,very_large,very_small,STORED_MAX_VAL,STORED_MIN_VAL));
        Ok(())
    }

    pub(crate) fn write_source_time_bin_tables(&mut self)->Result<(),Error>{
        // Actual7522-7527 string/stat allocations precede the style loop. The
        // numeric stat width is allocated/unwritten until a positive table body.
        let mut row_head=vec![Vec::<u8>::new();39];
        let column_head_stat=vec![Vec::<u8>::new();1];
        let column_width_stat:Vec<Option<i32>>=vec![None;1];
        let row_head_stat=vec![Vec::<u8>::new();6];
        let table_body_stat=SourceTabularBody::allocate(1,6)?;
        for _current_style in &self.input_state.tabular_report_passes {
            for (row,label) in row_head.iter_mut().zip(BIN_ROWS){*row=label.as_bytes().to_vec();}
            for input in 1..=self.input_state.output_table_binned_count {
                let index=input.checked_sub(1).and_then(|v|usize::try_from(v).ok())
                    .ok_or(Error::Unavailable("actual TimeBin7578 OutputTableBinned ordinal"))?;
                let actual=self.input_state.output_table_binned.as_ref().and_then(|v|v.get(index))
                    .ok_or(Error::Unavailable("actual TimeBin7578 OutputTableBinned(iInObj).resIndex row"))?;
                let _first_report=actual.result_index;
                return Err(Error::Unavailable("actual WriteTimeBinTables7579 varOrMeter / Constant::unitNames formatting first operation"));
            }
        }
        drop((row_head,column_head_stat,column_width_stat,row_head_stat,table_body_stat));
        Ok(())
    }

    pub(crate) fn write_source_annual_tables(&mut self)->Result<(),Error>{
        // Native643-655 has no preloop report-array allocation or flag guard.
        // Reborrow the existing single AnnualData.annualTables projection.
        for _current_style in &self.input_state.tabular_report_passes {
            for _annual_table in &mut self.input_state.annual_tables {
                return Err(Error::Unavailable("actual AnnualTable::writeTable677 setupAggString1059 local vector allocation first operation"));
            }
        }
        Ok(())
    }
}
'''
body+='const MONTHLY_ROWS:&[&str]=&'+json.dumps(month_labels,ensure_ascii=False)+';\n'
body+='const BIN_ROWS:&[&str]=&'+json.dumps(bin_labels,ensure_ascii=False)+';\n'
body+='const AGGREGATION:&[(&str,&str)]=&['+','.join('('+json.dumps(n)+','+json.dumps(v)+')' for n,v in agg)+'];\n'
sources={main:parent.read_bytes()+b'\nmod periodic_reports;\n',H+'ordinary_tabular_reports/periodic_reports.rs':body.encode()}
for n,z in sources.items():
 p=D/'proposed'/n;p.parent.mkdir(parents=True,exist_ok=True)
 q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=z,capture_output=True);assert q.returncode==0,(n,q.stderr.decode())
 p.write_bytes(z if n==main else q.stdout)
print(json.dumps({'draft':D.relative_to(R).as_posix(),'Sources':list(sources),'monthly_rows':len(month_labels),'bin_rows':len(bin_labels),'aggregation_keys':len(agg)}))

"""Narrow held producer correction for genuine IHG lighting-total entries.
Frozen actual78 and historical canonical09 remain untouched; no compiler/tests.
"""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
W=D/'ordinary-provider-assembly-Root-78/workspace';N=R/'.reference/energyplus-src/26.1.0'
OUT=D/'ordinary-ihg-lighting-total-producer-held-Peer-01'
HEAD='1b318404eabf128ef5eca0a0e90fb2557cb7cd5b';PIN='6f2e40d10250a105b49966baa24d843711e61048'
H='crates/ep_runtime/src/heat_balance/';MAIN=H+'ctf_initialization_context/internal_heat_gains_input.rs';GETTER=H+'ctf_initialization_context/internal_heat_gains_input/getter.rs'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 b=(R/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
assert not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==HEAD
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
mp=D/'ordinary-provider-assembly-Root-78/manifest.json';assert ref(mp)['sha256']=='28310f642f9dd51a2a535598e9b271b490c84514868405f3a021bc33f1a97cc1'
checkp=W/'.runtime/porting/SRC-06/provider-assembly-all-targets-command-78/receipt.json'
clip=W/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-78/receipt.json'
check=json.loads(checkp.read_bytes());cli=json.loads(clip.read_bytes())
assert check['exit_code']==0 and cli['exit_code']==6 and check['source_bytes_match_before_and_after'] and cli['source_bytes_match_before_and_after']
assert check['source_snapshot']==cli['source_snapshot']
snap=json.loads(read(dict(path=(W/cli['source_snapshot']['path']).relative_to(R).as_posix(),sha256=cli['source_snapshot']['sha256'])))
index={e['historical_path']:e for e in snap['files']};assert len(index)==4461
before={n:(W/n).read_bytes() for n in [MAIN,GETTER]}
for n,b in before.items():
 assert b==read(dict(path=(W/index[n]['archive']['path']).relative_to(R).as_posix(),sha256=index[n]['archive']['sha256']))
 assert b==(R/n).read_bytes()==subprocess.check_output(['git','show',HEAD+':'+n],cwd=R)
getter=before[GETTER]
def replace(b,a,z):
 assert b.count(a)==1,a[:100];return b.replace(a,z,1)
getter=replace(getter,b'    pub(super) eio: &\'a mut dyn Write,\n',b'''    pub(super) eio: &'a mut dyn Write,
    // The same actual DataOutRptPredefined registry and table-entry owner.
    pub(super) registry: &'a crate::heat_balance::predefined_tables::PredefinedRegistry,
    pub(super) table: &'a mut crate::heat_balance::ctf_reports::PredefinedStringTable,
''')
getter=replace(getter,b'''        for (kind, family) in FAMILIES[..9].iter().enumerate() {
            let objects = self.preprocess(family, kind, owners)?;
''',b'''        for (kind, family) in FAMILIES[..9].iter().enumerate() {
            // Native IHG924-925 initializes these procedure locals at the
            // Lights stage, before setupIHGZonesAndSpaces927. Other stages
            // do not construct them. Positive Lights still stop in their
            // existing actual getter before any total-entry write.
            let lighting_totals = if kind == 1 {
                Some((0.0_f64, 0.0_f64))
            } else {
                None
            };
            let objects = self.preprocess(family, kind, owners)?;
''')
getter=replace(getter,b'''                    owners,
                )?;
            }
        }
        self.totals[9]''',b'''                    owners,
                )?;
            }
            if let Some((sum_area, sum_power)) = lighting_totals {
                // Native1254-1261 is OUTSIDE the TotLights>0 block and
                // precedes ElectricEquipment1263, even for no Lights.
                let density_column = *owners.registry.named_indices.get("pdchInLtDens")
                    .ok_or_else(|| unavailable("actual IHG1254 lighting-density column"))?;
                if sum_area > 0.0 {
                    owners.table.fixed_real_entry_4(
                        density_column, "Interior Lighting Total", sum_power / sum_area,
                    )?;
                } else {
                    // Native DataPrecisionGlobals::constant_zero is +0.0.
                    owners.table.fixed_real_entry_4(
                        density_column, "Interior Lighting Total", 0.0,
                    )?;
                }
                let area_column = *owners.registry.named_indices.get("pdchInLtArea")
                    .ok_or_else(|| unavailable("actual IHG1260 lighting-area column"))?;
                owners.table.fixed_real_entry_2(
                    area_column, "Interior Lighting Total", sum_area,
                )?;
                let power_column = *owners.registry.named_indices.get("pdchInLtPower")
                    .ok_or_else(|| unavailable("actual IHG1261 lighting-power column"))?;
                owners.table.fixed_real_entry_2(
                    power_column, "Interior Lighting Total", sum_power,
                )?;
            }
        }
        self.totals[9]''')
main=replace(before[MAIN],b'                eio: self.eio,\n',b'''                eio: self.eio,
                registry: &reports.registry,
                table: &mut reports.table,
''')
proposed={MAIN:main,GETTER:getter}
tree=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<pure-literal>','exec'),ns)
parses=[]
for n,z in proposed.items():
 assert z.count(b'#[test]')==before[n].count(b'#[test]') and b'\r' not in z
 parsed=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--config','skip_children=true','--emit','stdout'],input=z,capture_output=True)
 assert parsed.returncode==0,parsed.stderr.decode();parses.append(dict(path=n,exit_code=0,scope='stdin parse only; output discarded'))
OUT.mkdir()
def write(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,o):return write(n,(json.dumps(o,indent=2)+'\n').encode())
files=[];apps=[]
for i,(n,z) in enumerate(proposed.items(),1):
 a=before[n]
 row=dict(canonical_path=n,canonical_before=ref(R/n),parent_source=ref(W/n),before=write('before/'+n,a),parent_before=write('parent-before/'+n,a),literal_inverse=write('literal-inverse/'+n,a),literal_parent_inverse=write('literal-parent-inverse/'+n,a),proposed=write('proposed/'+n,z),Git_authentication=dict(revision=HEAD,exit_code=0))
 for forward,inverse in [('complete_forward_diff','complete_inverse_diff'),('parent_forward_diff','parent_inverse_diff')]:
  f=ns['diff'](a,z,n,forward+'-before',forward+'-after');iv=ns['diff'](z,a,n,inverse+'-before',inverse+'-after')
  assert ns['apply_literal'](a,f)==z and ns['apply_literal'](z,iv)==a
  row[forward]=write(f'diffs/{i:02}-{forward}.diff',f);row[inverse]=write(f'diffs/{i:02}-{inverse}.diff',iv)
  apps.extend([dict(path=n,role=k,literal_application_passed=True) for k in [forward,inverse]])
 files.append(row)
originals=[];native_wholes={}
for file,lo,hi in [('InternalHeatGains.cc',231,3298),('InternalHeatGains.cc',3300,3429),
 ('InternalHeatGains.cc',919,1267),('OutputReportPredefined.cc',266,276),
 ('OutputReportPredefined.cc',1766,1835),('OutputReportPredefined.cc',1928,1973),
 ('OutputReportPredefined.hh',695,708),('DataHeatBalance.hh',1840,1855),('DataPrecisionGlobals.hh',52,58)]:
 p=N/'src/EnergyPlus'/file;b=p.read_bytes()
 if file not in native_wholes:assert subprocess.check_output(['git','show',PIN+':src/EnergyPlus/'+file],cwd=N)==b;native_wholes[file]=ref(p)
 excerpt=b''.join(b.splitlines(keepends=True)[lo-1:hi]);assert excerpt
 originals.append(dict(source=ref(p),first_line=lo,last_line=hi,literal_excerpt=write(f'Original/{file}-{lo}-{hi}.txt',excerpt)))
readonly=[]
for n in [H+'ctf_reports.rs',H+'ctf_reports_format.rs',H+'predefined_tables.rs',H+'predefined_tables_catalog.rs',H+'selected_heat_balance_input.rs',H+'ctf_initialization_context.rs',H+'ctf_initialization_context/internal_heat_gains_input/output.rs',H+'ctf_initialization_context/internal_heat_gains_input/nominal.rs']:
 p=W/n;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==index[n]['archive']['sha256'];readonly.append(dict(source=ref(p),immutable_copy=write('read-only-Source/'+n,b)))
comparisonp=D/'Root-actual-tabular78-five-format-comparison-01/comparison.json';assert ref(comparisonp)['sha256']=='4060a8af2e02dbe4b6d075be81d9ea4c07525d2ba3e920e71f18fba34ff27500'
proof=meta('same-owner-and-producer-order.json',dict(
 same_owner='Existing CtfInitializationReports.registry and table borrowed into existing short SourceGainInputOwners; sole construction in internal_heat_gains_input.rs253. No table/registry clone, replacement, reset or report-time synthesis.',
 actual_init='Native numLightsStatements923 constructor0, sumArea924 +0 and sumPower925 +0 precede real setup927. Current existing FAMILIES kind1 creates only the actual two sum locals at this stage before same preprocess call.',
 instance_count='Native TotLights DataHeatBalance.hh1848 ctor0; setup3300 epJSON find/numInputObjects/numGainInstances writes. Source existing totals[1], lights_objects and exact preprocess remain byte-unchanged.',
 admitted_zero='Real Lights object/map preprocessing and positive getter boundary select the actual entered path. The total block runs after the Light block regardless TotLights0, and before ElectricEquipment setup. No raw absence/report flag/DoWeathSim shortcut was added.',
 positive='Native1195/1196 accumulate spaceArea*mult and DesignLevel*mult inside the positive body. That existing positive Source getter is still unavailable before reading such records, so this packet does not fabricate positive sum values or claim positive Lights support.',
 order=['Density ifsumArea>0 uses sumPower/sumArea, else constant_zero; fixed precision4','Area sumArea default2','Power sumPower default2','Next ElectricEquipment setup1263'],
 predefined_effects='Existing real writer increments the same num_table_entry once per reached call, with normal allocation/growth; three append operations, no direct count assignment. Stored original_real_entry, significant_digits and original_entry_is_real follow the existing typed real writer; object_name/index_column use actual registered columns.',
 retained_getter_paths='All nine existing preprocessing calls and10totals fields, six getter-local argument arrays, diagnostics/fatal/output registration/EIO order remain intact; the two added borrowed references are the only new owner-carrier members.',
 comparison_role='Original full five-format78 comparison is retained as the failed factual trigger, never read by Source methods and never converted to expected-value operands.',
 new_retained_numeric_cells=0,new_test_bodies=0,Native_or_Cargo_executed=False))
checks=meta('checks.json',dict(Source_paths=2,new_Source_paths=0,literal_applications=len(apps),parse_only=parses,strict_Native_wholes=len(native_wholes),strict_Native_ranges=len(originals),new_test_bodies=0,canonical_changes=0,source78_changes=0,whole_run_or_numerical_gate_claim=False))
api=meta('API.json',dict(existing_entry='SelectedInternalHeatGains::get_input(&mut SourceGainInputOwners)',carrier_additions=['registry: &PredefinedRegistry','table: &mut PredefinedStringTable'],actual_constructor='CtfInitializationContext::manage_selected_internal_heat_gains_input existing owners construction',same_PreDef_methods=['fixed_real_entry_4','fixed_real_entry_2'],positive_Lights_unsupported=True))
assert len(files)==2 and len(apps)==8
print(json.dumps(meta('manifest.json',dict(schema='src06-held-genuine-IHG-lighting-total-producer-correction.v1',status='HELD producer correction; independent peer, composition, compiler and actual physical validation pending',base_HEAD=HEAD,parent=ref(mp),parent_actual_check=ref(checkp),parent_actual_CLI=ref(clip),parent_failed_physical_comparison=ref(comparisonp),Original_commit=PIN,files=files,Original_authority=originals,read_only_existing_Source_APIs=readonly,same_owner_and_producer_order=proof,checks=checks,API=api,author_Source=ref(Path(__file__)),qualifications=['The actual GetInternalHeatGains Lights total producer is restored at its original position; no WritePredefinedTables/report output patch is used.','The three unconditional total entries are generated from actual procedure-local sumArea/sumPower plus literal Native constant_zero. Positive Lights remains stopped before its unported sum producers.','The fixed-format real-entry helper and existing numeric error transport are reused unchanged. No Native output, comparison answer or injected report row drives a calculation.','Frozen Source78 including its rejected full physical comparison remains immutable; this packet needs Root independent review and subsequent composed actual execution before acceptance claims.'],canonical_changes=0,source78_changes=0,Git_mutations=0,Cargo_Native_or_tests_executed=False,new_test_bodies=0,numerical_or_gate_PASS=False))))

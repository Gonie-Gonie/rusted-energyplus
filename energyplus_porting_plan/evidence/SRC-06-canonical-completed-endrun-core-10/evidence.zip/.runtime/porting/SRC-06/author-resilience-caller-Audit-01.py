from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'ordinary-resilience-caller-held-Audit-01';assert not O.exists()
W=B/'ordinary-provider-assembly-Root-77/workspace';canonical='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';parent=W/canonical
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(d):
 p=R/d['path'];assert ref(p)==d;return p.read_bytes()
pm=B/'ordinary-provider-assembly-Root-77/manifest.json';M=json.loads(pm.read_bytes());assert M['workspace']==W.relative_to(R).as_posix()
body_leaf=B/'ordinary-resilience-report-held-Audit-01/manifest.json';assert ref(body_leaf)['sha256']=='309742d37c2ee990ec2fb753665b5226929bd38cfc34631c184d81151f3a68f9'
coil=B/'ordinary-coil-summary-finish-held-Reviewer-01/manifest.json';predefined=B/'ordinary-predefined-report-held-Audit-01/manifest.json'
assert ref(predefined)['sha256']=='02880decb5568a984e91f40929323c0103ab1571e8c74ffee56236809846f1f8'
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();old=(R/canonical).read_bytes();git_old=subprocess.check_output(['git','show',head+':'+canonical])
prepared09=B/'canonical-source77-post-summary-core-prepared-Peer-09/manifest.json';prepared09_m=json.loads(prepared09.read_bytes());bridge09=next(x for x in prepared09_m['files'] if x['canonical_path']==canonical)
assert old==get(bridge09['proposed'])==parent.read_bytes()
if git_old!=old:
 assert head==prepared09_m['base_HEAD'] and git_old==get(bridge09['before'])
git_equal=git_old==old
before=parent.read_bytes();s=before.decode()
needle='''            if session.tabular.display_thermal_resilience_summary && !globals.do_pure_load_calc {
                return Err(unavailable("actual WriteTabularReports5244 WriteThermalResilienceTables entry"));
            }
            return Err(unavailable("actual WriteTabularReports5246 CO2Resilience conditional entry"));
'''
assert s.count(needle)==1
insert=''
for kind,native in [('thermal',5244),('co2',5247),('visual',5250)]:
 insert+=f'''            if session.tabular.display_{kind}_resilience_summary && !globals.do_pure_load_calc {{
                session.tabular.write_source_{kind}_resilience_tables(
                    &mut crate::heat_balance::ordinary_tabular_reports::SourceResilienceTableOwners {{
                        globals,
                        zones: required(
                            reports.selected_zone_input.as_ref(),
                            "actual same Zone/Resilience/ZoneDaylight before {kind} resilience{native}",
                        )?,
                        gains: &reports.selected_internal_heat_gains,
                        registry: &reports.registry,
                        table: &mut reports.table,
                        results: &reports.source_results_framework,
                        sqlite: &reports.source_sqlite,
                        writer: crate::heat_balance::ordinary_tabular_reports::SourceTabularWriterOwners {{
                            monetary: &reports.cost_estimate_monetary,
                            flags: SourceDiagnosticFlags {{
                                kickoff: &globals.kickoff_simulation,
                                developer: &project.system.developer_flag,
                                warmup: &weather.state.global.warmup_flag,
                                doing_sizing: &globals.doing_sizing,
                            }},
                            backend: &mut *backend,
                        }},
                    }},
                ).map_err(hb_input_error)?;
            }}
'''
insert+='''            if weather.state.weather.tot_report_periods > 0 {
                return Err(unavailable("actual WriteTabularReports5253 WriteReportPeriodTimeConsumption12480 local array allocation entry"));
            }
            for _period in 1..=weather.state.weather.tot_thermal_report_periods {
                return Err(unavailable("actual WriteTabularReports5256 WriteThermalResilienceTablesRepPeriod12539 actual WriteTabularFiles and styles entry"));
            }
            for _period in 1..=weather.state.weather.tot_co2_report_periods {
                // Native13690 intentionally returns when WriteTabularFiles is
                // true. Preserve that original guard, including its TODO bug.
                if !*session.tabular.source_write_tabular_files_mut() {
                    return Err(unavailable("actual CO2ResilienceRepPeriod13692 tabularReportPasses first header operation"));
                }
            }
            for _period in 1..=weather.state.weather.tot_visual_report_periods {
                return Err(unavailable("actual WriteTabularReports5262 WriteVisualResilienceTablesRepPeriod13801 actual WriteTabularFiles and styles entry"));
            }
            required(
                reports.coil_selection_report.as_mut(),
                "actual same coilSelectionReportObj before finishCoilSummary5265",
            )?.finish_source_coil_summary_report_table().map_err(hb_input_error)?;
            session.tabular.write_source_predefined_tables(
                &mut crate::heat_balance::ordinary_tabular_reports::SourcePredefinedReportOwners {
                    registry: &reports.registry,
                    table: &mut reports.table,
                    results: &reports.source_results_framework,
                    sqlite: &reports.source_sqlite,
                    writer: crate::heat_balance::ordinary_tabular_reports::SourceTabularWriterOwners {
                        monetary: &reports.cost_estimate_monetary,
                        flags: SourceDiagnosticFlags {
                            kickoff: &globals.kickoff_simulation,
                            developer: &project.system.developer_flag,
                            warmup: &weather.state.global.warmup_flag,
                            doing_sizing: &globals.doing_sizing,
                        },
                        backend: &mut *backend,
                    },
                },
            ).map_err(hb_input_error)?;
            if weather.state.global.do_weath_sim {
                return Err(unavailable("actual WriteTabularReports5270 WriteMonthlyTables entry"));
            }
'''
s=s.replace(needle,insert,1);assert s.replace(insert,needle,1)==before.decode()
# Owner state follows existing same live WeatherSession layout, not a new copy.
assert 'pub weather: WeatherOwnerState,' in (W/'crates/ep_runtime/src/weather_day/state.rs').read_text(encoding='utf8')
new=s.encode();q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True);assert q.returncode==0,q.stderr.decode()
tree=ast.parse((B/'seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<custody>','exec'),ns)
tree=ast.parse((B/'seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));ps={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<literal-diff>','exec'),ps)
N=R/'.reference/energyplus-src/26.1.0';pin='6f2e40d10250a105b49966baa24d843711e61048';assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==pin
O.mkdir();ns['row'](canonical,new,parent);row=ns['rows'][0];apps=0
for a,k,b in [(row['before'],'complete_forward_diff',row['proposed']),(row['proposed'],'complete_inverse_diff',row['before']),(row['parent_before'],'parent_forward_diff',row['proposed']),(row['proposed'],'parent_inverse_diff',row['parent_before'])]:assert ps['apply_diff'](get(a),get(row[k]))==get(b);apps+=1
original=[]
for name,lo,hi in [('OutputReportTabular.cc',5239,5299),('OutputReportTabular.cc',12471,12553),('OutputReportTabular.cc',13686,13704),('OutputReportTabular.cc',13798,13817),('ReportCoilSelection.cc',126,131)]:
 p=N/'src/EnergyPlus'/name;z=p.read_bytes();assert subprocess.check_output(['git','-C',str(N),'show',pin+':src/EnergyPlus/'+name])==z
 x=O/'Original'/f'{name}-{lo}-{hi}.txt';x.parent.mkdir(exist_ok=True);x.write_bytes(b''.join(z.splitlines(True)[lo-1:hi]));original.append(dict(source=ref(p),first_line=lo,last_line=hi,literal_excerpt=ref(x)))
def write(name,value):
 p=O/name;p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
checks=write('checks.json',dict(current_Git_revision=head,current_Git_equal=git_equal,actual_working_before_is_prepared09_proposal=True,prepared09_bridge=ref(prepared09),prepared09_Git_before=bridge09['before'],prepared09_actual77_equal=bridge09['proposed'],actual77_parent=ref(parent),one_exact_tail_replacement=True,whole_old_parent_recovery=True,literal_applications=apps,parse_only_exit_code=0,typed_causes_preserved=True,actual_new_calls=['5244 Thermal only actual flag && !actual DoPureLoadCalc','5247 CO2 only actual flag && !actual DoPureLoadCalc','5250 Visual only actual flag && !actual DoPureLoadCalc','5253 TotReportPers positive boundary','5256 actual TotThermalReportPers loop positive boundary','5259 actual TotCO2ReportPers loop with original reversed WriteTabularFiles return guard','5262 actual TotVisualReportPers loop positive boundary','5265 actual same reports.coil_selection_report finish','5267 same actual TAB/registry/table/results/SQLite/writer Predefined','5270 actual DoWeathSim monthly boundary else original5278 audit boundary'],no_counts_or_flags_from_input_or_absence=True,no_flag_or_count_mutations=True,no_clones_or_resets=True,new_test_bodies=0))
m=dict(schema='src06-genuine-resilience-coil-predefined-caller-held.v1',status='HELD true current77 tail connection; resilience independent peer, Root caller peer and joined compiler/execution required',base_HEAD=head,Original_commit=pin,files=ns['rows'],Original_authority=original,dependencies=[ref(pm),ref(body_leaf),ref(coil),ref(predefined),ref(B/'Peer-ordinary-coil-summary-finish-Source-review-01/review.json'),ref(B/'Root-ordinary-predefined-report-Source-review-01/review.json')],checks=checks,author_Source=ref(Path(__file__).resolve()),qualifications=['No top-level success route: DoWeathSim true reaches actual WriteMonthlyTables5270 typed boundary; false continues existing5278 audit boundary.','Each actual report condition reads retained TAB display flag and Globals.DoPureLoadCalc before owner access. No inference from People, CO2 simulation, daylight count or AllSummary input.','Actual weather-owner totals preserve the four independent runtime predicates/loop bounds. No synthetic absent/empty fallback. Positive report-period bodies remain explicitly unsupported, not skipped or reported complete.','Original CO2 report-period guard returns when WriteTabularFiles is true (Native TODO notes reversed guard); Source preserves this behavior even though callers own the true branch.','Coil finish uses same once-constructed reports.coil_selection_report vector; no NumberOfCoilsReported absence guess or fresh report constructor.','Predefined receives actual preceding table mutations, same registry, real current flags/backend and existing sole physical output streams.','All code before the reached5243 condition and all original false5278 bytes recover exactly. No main/workspace/Cargo/Native execution or new test bodies.'],canonical_mutations=0,Cargo_Native_tests_executed=False,numerical_PASS_or_gate_claim=False)
print(json.dumps(write('manifest.json',m)))

"""Root-only guarded31-path canonical10 application; no Git/Cargo/tests."""
from pathlib import Path
import argparse,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3]
def read(r):
 b=(R/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');args=p.parse_args();assert args.apply
M=json.loads((R/'.runtime/porting/SRC-06/canonical-source79-endrun-core-prepared-Peer-10-With-Test-03/manifest.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==M['base_HEAD']
plan=json.loads(read(M['complete_compiler_Source_plan']))
for x in plan['files']:
 p=R/x['path']
 if x['before_absent']:assert not p.exists()
 else:
  b=p.read_bytes();assert len(b)==x['before_bytes'] and hashlib.sha256(b).hexdigest()==x['before_sha256']
packet=json.loads(read(M['existing_test_expectation_packet']));test=packet['file']['canonical_path'];values=[]
for x in M['files']:
 p=R/x['canonical_path'];b=read(x['proposed'])
 if not x['before_absent']:assert p.stat().st_nlink==1 and p.read_bytes()==read(x['before'])
 actual=read(x['actual79'])
 if x['planned_exact_actual79']:assert b==actual
 elif x['canonical_path']==test:
  before=read(x['before'])
  for fragment in packet['expectation_fragments']:
   old,new=read(fragment['before']),read(fragment['after']);assert before.count(old)==1;before=before.replace(old,new,1)
  assert b==before
 else:
  assert x['canonical_path']==M['existing_diagnostic_path_with_only_accepted_core_changes']
  projection=json.loads(read(M['files_rs_observer_projection']))
  for y in projection['removed_spans']:
   span=read(y['literal_span']);assert actual.count(span)==1;actual=actual.replace(span,b'',1)
  assert b==actual
 values.append((p,b))
assert len(values)==31
for p,b in values:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for x in plan['files']:
 b=(R/x['path']).read_bytes();assert len(b)==x['planned_bytes'] and hashlib.sha256(b).hexdigest()==x['planned_sha256']
print(json.dumps(dict(applied_paths=len(values),compiler_inputs_verified=len(plan['files']),Git_mutated=False,Cargo_or_tests_executed=False)))

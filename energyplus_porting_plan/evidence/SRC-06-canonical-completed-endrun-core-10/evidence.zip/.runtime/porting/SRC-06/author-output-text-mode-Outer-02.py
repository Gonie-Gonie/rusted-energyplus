"""Seal a same-stream Windows text-mode adapter; do not rewrite artifacts."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'ordinary-output-text-mode-held-Outer-02';assert not OUT.exists()
for n in ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')).body:
    if isinstance(n,ast.FunctionDef) and n.name in ('ref','apply_literal'):
        exec(compile(ast.Module([n],type_ignores=[]),'custody','exec'),globals())
P=D/'ordinary-provider-assembly-Root-77/manifest.json';assert ref(P)['sha256']=='1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
M=json.loads(P.read_bytes());W=ROOT/M['workspace'];N=ROOT/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def run(a,cwd=ROOT,required=True):
    p=subprocess.run(a,cwd=cwd,capture_output=True)
    if required:assert p.returncode==0,(a,p.stderr)
    return p
BASE=run(['git','rev-parse','36b48e14']).stdout.decode().strip();LIVE_HEAD=run(['git','rev-parse','HEAD']).stdout.decode().strip()
name='crates/ep_runtime/src/heat_balance/source_initialization/files.rs';pb=(W/name).read_bytes()
old_write=b'''    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        let result = self
            .file
            .as_mut()
            .ok_or_else(|| {
                io::Error::new(io::ErrorKind::NotConnected, "actual output is not open")
            })?
            .write(bytes);
        if result.is_err() || matches!(result,Ok(0) if !bytes.is_empty()) {
            self.failed = true;
        }
        result
    }
'''
new_write=b'''    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        // Native ostream.write consumes the requested logical byte sequence;
        // its Windows text-mode file buffer expands each LF at the same handle.
        self.write_all(bytes).map(|()| bytes.len())
    }
'''
anchor=b'''    fn write_all(&mut self, bytes: &[u8]) -> io::Result<()> {
        let result = self
'''
replacement=b'''    fn write_all(&mut self, bytes: &[u8]) -> io::Result<()> {
        // IOFiles.open uses in|out|trunc, without binary. Rust File uses the
        // binary OS handle, so perform the actual text-mode translation here,
        // at each reached write. Already supplied CR is retained: CRLF input
        // becomes CRCRLF, exactly as a Windows CRT text stream would write it.
        #[cfg(windows)]
        let translated;
        #[cfg(windows)]
        let bytes = if bytes.contains(&b'\\n') {
            let mut text = Vec::with_capacity(bytes.len());
            for &byte in bytes {
                if byte == b'\\n' {
                    text.push(b'\\r');
                }
                text.push(byte);
            }
            translated = text;
            translated.as_slice()
        } else {
            bytes
        };
        let result = self
'''
assert pb.count(old_write)==1 and pb.count(anchor)==1
proposed=pb.replace(old_write,new_write,1).replace(anchor,replacement,1)
assert proposed.replace(replacement,anchor,1).replace(new_write,old_write,1)==pb
OUT.mkdir()
def put(n,b):
    p=OUT/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(n,o):return put(n,(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode())
gp=run(['git','show',BASE+':'+name]);before=gp.stdout
files=[];apps=[]
row=dict(canonical_path=name,canonical_at_base_revision=put('before/'+name,before),canonical_base_revision=BASE,live_observation=ref(ROOT/name),live_observation_frozen=put('live-observation/'+name,(ROOT/name).read_bytes()),before=ref(OUT/'before'/name),literal_inverse=put('literal-inverse/'+name,before),parent_source=ref(W/name),parent_before=put('parent-before/'+name,pb),literal_parent_inverse=put('literal-parent-inverse/'+name,pb),proposed=put('proposed/'+name,proposed))
for x,y,k,l,r in [(before,proposed,'complete_forward_diff','Git36b','proposed'),(proposed,before,'complete_inverse_diff','proposed','Git36b'),(pb,proposed,'parent_forward_diff','Root77','proposed'),(proposed,pb,'parent_inverse_diff','proposed','Root77')]:
    diff=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=l+'/'+name,tofile=r+'/'+name)).encode();assert apply_literal(x,diff)==y
    row[k]=put('diffs/'+k+'.diff',diff);apps.append(dict(path=name,role=k,literal_application_passed=True))
files.append(row)
put('Git/'+name,gp.stdout);put('Git/'+name+'.stderr',gp.stderr)
cmd=['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(OUT/'proposed'/name)];p=run(cmd);assert (OUT/'proposed'/name).read_bytes()==proposed
parse=doc('Source-only-parse.json',dict(command=cmd,exit_code=p.returncode,stdout=put('parse.stdout',p.stdout),stderr=put('parse.stderr',p.stderr),proposed_bytes_unchanged=True))
# Verify the complete actual frozen compiler input census, then retain all
# relevant references / explicit CRLF producers over ALL 4441 Rust Sources.
C=ROOT/M['compiler_Source_census']['path'];assert ref(C)==M['compiler_Source_census'];c=json.loads(C.read_bytes());sources=[];verified=[]
for r in c['files']:
    p=W/r['path'];b=p.read_bytes();assert len(b)==r['bytes77'] and hashlib.sha256(b).hexdigest()==r['assembled77_sha256']
    verified.append(dict(path=r['path'],sha256=r['assembled77_sha256'],bytes=len(b)))
    if p.suffix=='.rs':sources.append((r['path'],b.decode('utf8')))
assert len(verified)==4454 and len(sources)==4441
whole_census=doc('verified-Root77-whole-compiler-census.json',dict(reference=ref(C),inputs=len(verified),Rust_sources=len(sources),files=verified))
queries={
'actual_stream_type':r'\bSourceOutputStream\b',
'actual_file_borrows':r'\b(?:ensure_output_open|eio_writer|eio_stream|bnd_stream|ensure_audit_open|ensure_debug_open|source_report_streams_and_eio|source_weather_streams_and_eio)\b',
'explicit_CRLF_translation_or_literal':r'\\r\\n|push\(b.\\r|replace\(.\\n',
'same_private_file_direct_access':r'\b(?:self\.)?(?:outputs|audit|debug)\b.*(?:file|write|open)|\b(?:stream|self)\.file\b',
}
ledgers=[];raw_results={}
for label,pattern in queries.items():
    rx=re.compile(pattern);rows=[]
    for n,text in sources:
        hits=[dict(line=i,text=t) for i,t in enumerate(text.splitlines(),1) if rx.search(t)]
        if hits:rows.append(dict(path=n,source=ref(W/n),occurrences=hits))
    raw_results[label]=rows;ledgers.append(dict(label=label,pattern=pattern,scope='all4441 frozen77 Rust Sources verified against actual compiler census',ledger=doc('Source-occurrences/'+label+'.json',rows)))
crlf_names={r['path'] for r in raw_results['explicit_CRLF_translation_or_literal']}
assert crlf_names=={
'crates/ep_compare/src/tests/window_material_blind_equivalent_layer.rs',
'crates/ep_run/src/outputs.rs',
'crates/ep_run/src/pipeline.rs',
'crates/ep_runtime/src/weather_raw/input_tests.rs',
'crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/output_files.rs',
'crates/ep_runtime/src/heat_balance/radiation/ordinary/shading_report.rs'}
type_names={r['path'] for r in raw_results['actual_stream_type']}
assert type_names=={name,'crates/ep_runtime/src/heat_balance/source_initialization/files/reporting.rs'}
ranges=[('IOFiles.cc',212,231),('IOFiles.cc',267,294),('IOFiles.hh',697,709),('IOFiles.hh',758,779),('SimulationManager.cc',1747,1762),('SimulationManager.cc',1797,1805),('SimulationManager.cc',1859,1866),('SimulationManager.cc',1939,1955)]
originals=[];ng=[];seen=set()
for n,first,last in ranges:
    p=N/'src/EnergyPlus'/n;b=p.read_bytes();ls=b.splitlines(keepends=True);assert 1<=first<=last<=len(ls)
    if n not in seen:
        assert run(['git','show',PIN+':src/EnergyPlus/'+n],cwd=N).stdout==b;seen.add(n);ng.append(dict(source=ref(p),revision=PIN,actual_whole_stdout_equal=True))
    originals.append(dict(source=ref(p),first_line=first,last_line=last,literal_excerpt=put('Original/'+n.replace('/','__')+f'-{first}-{last}.txt',b''.join(ls[first-1:last])),strict_EOF=True))
# Actual finite artifacts are observed and frozen, never transformed or used
# as production operands. Every byte remains in the earlier immutable folder.
observations=[]
for owner in ('native-installed-A-24H-Root-67','through-primary-diagnostic-A-24H-Root-77'):
    folder=D/owner/'output'
    prefix='energyplusout' if owner.startswith('native-') else 'eplusrs'
    for n in (prefix+'.audit',prefix+'.eio',prefix+'.eso',prefix+'.mtr',prefix+'.bnd'):
        p=folder/n
        if not p.exists():continue
        b=p.read_bytes();observations.append(dict(source=ref(p),physical_LF=b.count(b'\n'),physical_CRLF=b.count(b'\r\n'),physical_lone_LF=b.count(b'\n')-b.count(b'\r\n'),role='observation only, never expected answers or production input; file untouched'))
proof=doc('native-mode-owner-and-writer-census-proof.json',dict(
actual_mode={'constructor':'Native InputOutputFile.open277-294 owns std::fstream opened in|out|trunc or app, without std::ios::binary; all four primary outputs actual1747-1762 use this owner; audit/debug use same class','insertion':'Native print758 formats then writes to the same ostream; vprint697-709 uses os.write(buffer,size). Source fmt/real/DTOA bytes are already prepared before this actual stream boundary','selected_platform':'Windows native artifacts empirically have CRLF for every line; Linux/nonWindows branch preserves original bytes'},
stream_scope={'included':'only sole private SourceOutputStream, four outputs ESO/EIO/MTR/BND and same audit/debug','same_handle':'unchanged path/open/option/lifetime/failure fields; exact same File.write_all; no per-file reopen/buffer replacement/history mirror','separate_TAB':'five SourceTabularOutputStream File members already translate LF in bytes(); retain wholebyte unchanged and never send through SourceOutputStream','separate_SHD':'SourceShadingStream::Physical own File already translates text; not passed to this class','separate_dictionaries':'SourceDictionaryStream own PhysicalFile and MTD own host are separate; no change or parity claim for their text mode in this leaf'},
census={'full_compiler_inputs':4454,'all_Rust':4441,'SourceOutputStream_references':'exactly files.rs and files/reporting.rs; complete all-source ledger retained','explicit_CRLF_or_newline_transform_occurrences':'all six paths retained: weather_raw and ep_compare test literals, TAB bytes insertion, SHD text insertion, plus ep_run outputs.rs/pipeline.rs Markdown escaping replace newline with space. The two physical production CRLF translators own separate File types. Neither Markdown text nor test-input bytes flow through SourceOutputStream. No already-translated ordinary physical caller passes through SourceOutputStream','ordinary_borrows':'every ensure_output_open/eio_writer/eio_stream/bnd_stream/ensure_audit_open and runtime/weather report reborrow occurrence retained; private fields cannot be reached by unrelated module bodies'},
operation={'new':'at each actual Windows write_all call, insert CR immediately before EVERY LF in the supplied logical bytes; preserve pre-existing CR and all other bytes','no_postprocess':'no rewrite of whole files, existing output, old artifacts, line ending normalization, scientific arithmetic, stored values, dictionaries or snapshots','write_contract':'write delegates to this same full ostream insertion and returns logical input-byte count, not expanded physical count; real write_all IO cause and same failed flag retained. Partial/failure timing equivalence is not claimed','Windows_only':'cfg(windows) expansion; other platforms same input bytes; no added syscalls/flush/sync/clock/counter update'},
whole_parent_recovery={'edits':[[old_write.decode(),new_write.decode()],[anchor.decode(),replacement.decode()]],'inverse_recovers_entire_Root77':True},physical_observations=observations,canonical_bridge='Exact77 adapter section is wholeidentical to historical36b and canonical09 WIP; promotion must extract ONLY two shown edits, retaining09 EIO reader addition and excluding held observers/module leaves. Historical36b full-diffs are custody, not instructions to overwrite canonical09.'))
assert proposed.count(b'#[test]')==pb.count(b'#[test]')
manifest=doc('manifest.json',dict(schema='src06-held-same-output-stream-Windows-text-mode.v1',status='HELD only; independent peer plus actual compiled Native physical comparison required',author_history='01 stopped before seal because complete4441 Rust census correctly also found ep_compare test literal and two ep_run Markdown newline-to-space transforms beyond runtime subtree. Partial01 retained.02 keeps all6 paths with exact classification and corrects Source output prefix to actual eplusrs; no proposed Rust byte changed.',base_HEAD=BASE,live_HEAD_observed=LIVE_HEAD,parent=ref(P),files=files,Original_commit=PIN,Original_authority=originals,actual_readonly_Native_Git=ng,actual_historical_base_Git=dict(revision=BASE,exit_code=gp.returncode,stdout=ref(OUT/'Git'/name),stderr=ref(OUT/'Git'/(name+'.stderr'))),verified_compiler_Source_census=whole_census,complete_Source_reference_ledgers=ledgers,mode_owner_and_writer_proof=proof,Source_only_parse=parse,literal_diff_applications=apps,author_Source=ref(Path(__file__).resolve()),scope={'one_existing_Source_two_methods_only':True,'expected_reference_answers_compiled':False,'five_TAB_streams_unchanged':True,'SHD_and_dictionaries_unchanged':True,'legacy_LF_evidence_preserved':True,'no_run_or_gate_claim':True},canonical_changes=0,Git_mutations=0,Cargo_or_Native_executed=False,new_test_bodies=0,new_numeric_owners=0))
print(json.dumps(manifest))

"""Guarded Source78 assembly only: accepted Predefined, resilience, coil and caller.

Root must supply the committed clean canonical09 HEAD and accepted caller peer.
No canonical mutation, Cargo, Native, formatting, tests or Git mutation occurs.
"""
from pathlib import Path
import argparse,ast,difflib,hashlib,json,os,re,shutil,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'.runtime/porting/SRC-06'
OUT=B/'ordinary-provider-assembly-Root-78';PARENT=B/'ordinary-provider-assembly-Root-77/workspace'
parser=argparse.ArgumentParser();parser.add_argument('--assemble-after-canonical09',action='store_true');parser.add_argument('--canonical-head',required=True);parser.add_argument('--caller-review',required=True);parser.add_argument('--caller-review-sha256',required=True);args=parser.parse_args()
assert args.assemble_after_canonical09
assert re.fullmatch('[0-9a-f]{40}',args.canonical_head) and re.fullmatch('[0-9a-f]{64}',args.caller_review_sha256)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==args.canonical_head
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
assert args.canonical_head!='36b48e14e2c103ab8dd621cea4357cc37fcbc881','canonical09 must be committed first'
tree=ast.parse((B/'assemble-ordinary-provider-check-Root-71-Fix-01.py').read_bytes())
for definition in [n for n in tree.body if isinstance(n,ast.FunctionDef)]:exec(compile(ast.Module(body=[definition],type_ignores=[]),'<pure-transport>','exec'))
mp=B/'ordinary-provider-assembly-Root-77/manifest.json';assert ref(mp)['sha256']=='1b7d92299c314c33e895f0e90f3cf334d749e01ddad4e1ebdead55c6b5c1f346'
reviewp=B/'Root-ordinary-provider-union77-actual-review-01/review.json';assert ref(reviewp)['sha256']=='e4b7aa77f6f72e4039b98c17f601eb99314ad4cdc29a5145b0f699f4092b0975'
review=json.loads(reviewp.read_bytes());assert review['accepted'] and not review['findings'] and review['manifest']==ref(mp)
checkp=PARENT/'.runtime/porting/SRC-06/provider-assembly-all-targets-command-77/receipt.json'
clip=PARENT/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-77/receipt.json'
assert ref(checkp)['sha256']=='99182c34d4f0c3bdff14dc32c930dbd55fc67c6330b469723ef084a59ebd69a6'
assert ref(clip)['sha256']=='7c225bf398a637dbe6ee32887cd24c94682c084bbf4915d054f639c221b4ad69'
check=json.loads(checkp.read_bytes());cli=json.loads(clip.read_bytes())
assert check['exit_code']==0 and cli['exit_code']==6 and check['source_bytes_match_before_and_after'] and cli['source_bytes_match_before_and_after']
assert check['source_snapshot']==cli['source_snapshot']
frontier=B/'through-primary-diagnostic-A-24H-Root-77/output/eplusrs.err'
assert b'actual WriteTabularReports5244 WriteThermalResilienceTables entry' in frontier.read_bytes()
snapshot=PARENT/cli['source_snapshot']['path'];assert ref(snapshot)['sha256']==cli['source_snapshot']['sha256']
si=json.loads(snapshot.read_bytes());assert not si['bytes_normalized'];expected={r['historical_path']:r for r in si['files']}
assert len(expected)==len(si['files'])==4454
specs=[
 ('Predefined','ordinary-predefined-report-held-Audit-01','02880decb5568a984e91f40929323c0103ab1571e8c74ffee56236809846f1f8','Root-ordinary-predefined-report-Source-review-01','d0ee55829cdcd8d7ad5a6a7cd9558d9d6b3e71ad5ddd1d9bdca24cf332f53d84'),
 ('Resilience','ordinary-resilience-report-held-Audit-01','309742d37c2ee990ec2fb753665b5226929bd38cfc34631c184d81151f3a68f9','Peer-ordinary-resilience-report-Source-review-03','c19e7babc38fd8fb93deafac09459d351a8b621682093ab0266a537a180bdce3'),
 ('Coil','ordinary-coil-summary-finish-held-Reviewer-01','79a1decbf19765d7ba80a48a2c71eac36f2a3716cfa4e49028888ce006ff80a7','Peer-ordinary-coil-summary-finish-Source-review-01','3eba7ba0ba49b04de1615e6d7bbbd6651d684f9a8ed25d69bd70072e6cb51ae9'),
 ('Caller','ordinary-resilience-caller-held-Audit-01','44b679254a3d376b5830e056f0a872ea71829bafb0c6a2df1dce9afbf52d4e0e',None,args.caller_review_sha256),
]
staged=[];packets=[];peers=[]
for role,name,h,peername,ph in specs:
 p=B/name/'manifest.json';peer=ROOT/args.caller_review if role=='Caller' else B/peername/'review.json'
 assert ref(p)['sha256']==h and ref(peer)['sha256']==ph
 m=json.loads(p.read_bytes());j=json.loads(peer.read_bytes())
 assert j.get('accepted',str(j.get('decision','')).startswith('ACCEPTED')) and not j.get('findings',[])
 assert j.get('manifest',j.get('preparation_manifest',j.get('reviewed_manifest')))==ref(p)
 assert len(m['files'])=={'Predefined':3,'Resilience':5,'Coil':2,'Caller':1}[role]
 staged.append((role,p,peer,m));packets.append(ref(p));peers.append(ref(peer))
assert not OUT.exists()
selected={};apps=[];composition=[];canonical_before={};joins=[]
main='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports.rs'
post=b'\nmod post_summary;\npub(crate) use post_summary::SourceSurfaceShadowingReportOwners;\n'
nextpost=b'\nmod post_summary_next;\npub(crate) use post_summary_next::SourcePostSummaryReportOwners;\n'
pre=b'\nmod predefined_report;\npub(crate) use predefined_report::SourcePredefinedReportOwners;\n'
res=b'\nmod resilience_report;\npub(crate) use resilience_report::SourceResilienceTableOwners;\n'
for role,p,peer,m in staged:
 for row in m['files']:
  n=row['canonical_path'];c,a,z=read(row['before']),read(row['parent_before']),read(row['proposed'])
  assert c==read(row['literal_inverse']) and a==read(row['literal_parent_inverse'])
  assert a.count(b'#[test]')==z.count(b'#[test]')
  canonical_before.setdefault(n,None if not(ROOT/n).exists() else ref(ROOT/n))
  for fk,ik,base in [('complete_forward_diff','complete_inverse_diff',c),('parent_forward_diff','parent_inverse_diff',a)]:
   assert apply(base,read(row[fk]))==z and apply(z,read(row[ik]))==base
   apps.extend([dict(path=n,packet_role=role,role=k,pass_literal_application=True) for k in [fk,ik]])
  original=(PARENT/n).read_bytes() if n in expected else b''
  if n not in expected:assert not(PARENT/n).exists()
  current=selected[n]['after'] if n in selected else original
  application='Exact accepted whole proposal on byte-identical composed parent'
  if n==main:
   suffix=pre if role=='Predefined' else res
   assert role in ['Predefined','Resilience']
   assert current==c+post+nextpost+(pre if role=='Resilience' else b'')
   assert a==c+nextpost+(pre if role=='Resilience' else b'') and z==a+suffix
   merged=current+suffix
   joins.append(dict(path=n,role=role,before=current,after=merged))
   application='Literal module-only append preserving accepted84-byte PostSummary suffix absent from historical leaf parent; no body merge or normalization'
  else:assert a==current,(role,n,sha(a),sha(current));merged=z
  assert b'\r' not in merged
  stage=dict(path=n,packet_role=role,packet=ref(p),peer=ref(peer),packet_parent_before=row['parent_before'],packet_proposed=row['proposed'],current_composed_before_sha256=sha(current),merged_sha256=sha(merged),application=application,normalization='none',conflicts=0,historical_current_alias_not_queried=True)
  if n not in selected:selected[n]=dict(before=original,after=merged,stages=[])
  else:selected[n]['after']=merged
  selected[n]['stages'].append(stage);composition.append(stage)
new_paths={n for n in selected if n not in expected}
assert len(composition)==11 and len(selected)==10 and len(new_paths)==7 and len(joins)==2
for n,e in expected.items():
 a=(PARENT/n).read_bytes();assert len(a)==e['size_bytes'] and sha(a)==e['archive']['sha256'] and (PARENT/e['archive']['path']).read_bytes()==a
OUT.mkdir()
for j in joins:
 f=put('join-diffs/'+j['role']+'.diff',delta(j['before'],j['after'],j['path']))
 iv=put('join-diffs/'+j['role']+'.inverse.diff',delta(j['after'],j['before'],j['path']))
 assert apply(j['before'],f.read_bytes())==j['after'] and apply(j['after'],iv.read_bytes())==j['before']
 apps.extend([dict(path=j['path'],packet_role=j['role'],role=k,pass_literal_application=True) for k in ['module_join_forward','module_join_inverse']])
workspace=OUT/'workspace';workspace.mkdir()
for folder in ['crates','.cargo','tools','specs','energyplus_porting_plan','data','scripts','config','docs','.github']:shutil.copytree(PARENT/folder,workspace/folder,copy_function=os.link)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:
 if(PARENT/name).exists():shutil.copy2(PARENT/name,workspace/name)
shutil.copytree(PARENT/'.runtime/porting/source-objects',workspace/'.runtime/porting/source-objects',copy_function=os.link)
files=[];storage=[]
for i,(n,item) in enumerate(selected.items(),1):
 a,z=item['before'],item['after'];p=workspace/n;is_new=n in new_paths
 assert p.resolve().is_relative_to(workspace.resolve())
 if is_new:assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True)
 else:
  assert p.read_bytes()==a and p.stat().st_ino==(PARENT/n).stat().st_ino and p.stat().st_nlink>=2
  oldid=p.stat().st_ino;p.unlink()
 p.write_bytes(z);assert p.stat().st_nlink==1
 assert not(PARENT/n).exists() if is_new else (PARENT/n).read_bytes()==a and p.stat().st_ino!=(PARENT/n).stat().st_ino
 storage.append(dict(path=n,new_fresh_file=True,links=1)) if is_new else storage.append(dict(path=n,parent_file_id=oldid,workspace78_file_id=p.stat().st_ino,detached_before_write=True))
 ba=put('before/'+n,a);iv=put('inverse/'+n,a);fd=put(f'diffs/{i:03}.diff',delta(a,z,n));rd=put(f'diffs/{i:03}.inverse.diff',delta(z,a,n))
 assert apply(a,fd.read_bytes())==z and apply(z,rd.read_bytes())==a
 apps.extend([dict(path=n,role=k,pass_literal_application=True) for k in ['assembled_forward','assembled_inverse']])
 files.append(dict(canonical_path=n,before=ref(ba),before_absent=is_new,proposed=ref(p),literal_inverse=ref(iv),forward_diff=ref(fd),inverse_diff=ref(rd),stages=item['stages']))
assert sourcepaths(PARENT)==set(expected) and sourcepaths(workspace)==set(expected)|new_paths
census=[];changed=[];shared=0
for n,e in expected.items():
 a,z=(PARENT/n).read_bytes(),(workspace/n).read_bytes()
 assert len(a)==e['size_bytes'] and sha(a)==e['archive']['sha256'] and (PARENT/e['archive']['path']).read_bytes()==a
 if n in selected:assert z==selected[n]['after'];changed.append(n)
 else:assert z==a
 assert a.count(b'#[test]')==z.count(b'#[test]')
 same=(PARENT/n).stat().st_ino==(workspace/n).stat().st_ino;shared+=same
 census.append(dict(path=n,parent77_sha256=sha(a),parent77_preserved_after_overlay=True,assembled78_sha256=sha(z),bytes78=len(z),same_underlying_file_id=same))
for n in sorted(new_paths):
 z=(workspace/n).read_bytes();assert z==selected[n]['after'] and b'#[test]' not in z
 census.append(dict(path=n,parent_absent=True,assembled78_sha256=sha(z),bytes78=len(z),new_fresh_file=True))
assert len(changed)==3 and len(census)==4461 and sum(n.endswith('.rs') for n in sourcepaths(workspace))==4448
assert shared==len(expected)-len(changed)-3 and len(apps)==68
pipeline='crates/ep_run/src/pipeline.rs';assert pipeline not in selected and (workspace/pipeline).read_bytes()==(PARENT/pipeline).read_bytes()
canonical_after={n:(None if not(ROOT/n).exists() else ref(ROOT/n)) for n in canonical_before};assert canonical_after==canonical_before
cp=jp('compiler-Source-input-census.json',dict(parent_recorded_snapshot=ref(snapshot),parent_count=4454,parent_Rust_count=4441,assembled_count=4461,assembled_Rust_count=4448,existing_changed=changed,new_paths=sorted(new_paths),all_other_existing_inputs_equal77=True,other_existing_count=4451,parent_all_archived_live_before_and_after_overlay=True,shared_unchanged_file_ids=shared,separate_unchanged_root_configs=['Cargo.toml','Cargo.lock','rust-toolchain.toml'],selected_storage=storage,files=census))
ap=jp('literal-applications.json',apps);co=jp('canonical-raw-observations.json',dict(committed_canonical09_HEAD=args.canonical_head,selected_current_refs_before=canonical_before,selected_current_refs_after=canonical_after,all_selected_canonical_refs_unchanged=True))
out=jp('manifest.json',dict(schema='src06-isolated-resilience-coil-predefined-and-caller-union.v1',status='Frozen accepted Source78; Root compile/runtime pending',parent=ref(mp),parent_actual_review=ref(reviewp),parent_actual_check=ref(checkp),parent_actual_A_receipt=ref(clip),parent_actual_frontier_artifact=ref(frontier),workspace=workspace.relative_to(ROOT).as_posix(),packets=packets,independent_reviews=peers,composition=composition,files=files,compiler_Source_census=ref(cp),literal_applications=ref(ap),canonical_observations=ref(co),author_Source=ref(Path(__file__)),copy_transport='Hardlink unchanged files; three selected existing detach before writes, seven new fresh; all4454archived/live parent inputs preserved before/after',parent_compiler_inputs_preserved=4454,assembled_compiler_inputs=4461,assembled_Rust_sources=4448,unique_changed_paths=10,existing_Source_changes=3,new_Source_files=7,literal_application_count=68,canonical_changed_by_assembler=False,Cargo_Native_or_tests_executed=False,Git_mutations=False,new_test_bodies=0,canonical_pipeline_activation=False,held_pipeline_exact_parent77=True,expected_reference_answers_compiled=False,numerical_PASS_or_gate_claimed=False,endrun_boundary='Actual5244Thermal/5247CO2/5259Visual preserve true flags; real period loops then same5265Coil and5267Predefined; DoWeathSimtrue stopsMonthly5270 and false retains5278audit boundary',excluded_future_packets=['5278audit and outer598/602/604/606 leaves not included; no Source-result exporter or whole-run success activation'],root_next_command_roots=dict(workspace=workspace.relative_to(ROOT).as_posix(),suggested_unique_actual_output_directory=(B/'through-primary-diagnostic-A-24H-Root-78/output').relative_to(ROOT).as_posix(),execution_by='Root only')))
print(json.dumps(ref(out)))

from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path.cwd();B=R/'.runtime/porting/SRC-06'
MP=B/'dictionary-native-text-mode-held-Root-01/manifest.json'
O=B/'Outer-dictionary-native-text-mode-Source-review-01'
assert not O.exists()
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(x):
 p=R/x['path'];q=ref(p);assert q['sha256']==x['sha256'] and q['bytes']==x.get('bytes',q['bytes']);return p
assert ref(MP)['sha256']=='cc12ee6af5d90291394b3d616cc8a5bb989e1ee54e468cd0ee0e80dcd817723b'
M=json.loads(MP.read_bytes())
S=(B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')
T=ast.parse(S);F=next(n for n in T.body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal')
G={'re':re};exec(compile(ast.Module(body=[F],type_ignores=[]),'<independent-literal-applier>','exec'),G);apply=G['apply_literal']
apps=[];wholes=[];parents=[]
for row in M['files']:
 before=get(row['before']).read_bytes();after=get(row['proposed']).read_bytes();inverse=get(row['literal_inverse']).read_bytes()
 assert apply(before,get(row['forward_diff']).read_bytes())==after
 assert apply(after,get(row['inverse_diff']).read_bytes())==before==inverse
 assert subprocess.check_output(['git','show',M['base_HEAD']+':'+row['canonical_path']],cwd=R)==before
 apps.extend([row['forward_diff'],row['inverse_diff']]);wholes.extend([row['before'],row['proposed']]);parents.append(row['canonical_path'])
 assert row['Source_only_parse']['exit_code']==0
 for k in ['stdout','stderr']:get(row['Source_only_parse'][k])
old=get(M['files'][0]['before']).read_text(encoding='utf8');new=get(M['files'][0]['proposed']).read_text(encoding='utf8')
a=old[old.index('            for &byte in bytes {'):old.index('            translated = text;')].strip()
begin=new.index('        for &byte in bytes {');end=new.index('        return std::borrow::Cow::Owned(text);');c=new[begin:end].strip()
assert '\n'.join(x.strip() for x in a.splitlines())=='\n'.join(x.strip() for x in c.splitlines())
assert new.count('fn native_text_bytes(')==1 and new.count('let bytes = native_text_bytes(bytes);')==1
assert '#[cfg(windows)]\n    if bytes.contains(&b\'\\n\')' in new and 'std::borrow::Cow::Borrowed(bytes)' in new
old_d=get(M['files'][1]['before']).read_text(encoding='utf8');new_d=get(M['files'][1]['proposed']).read_text(encoding='utf8')
oldbranch='Some(SourceDictionaryBuffer::PhysicalFile(file)) => file.write_all(bytes),'
newbranch='Some(SourceDictionaryBuffer::PhysicalFile(file)) => {\n                file.write_all(super::native_text_bytes(bytes).as_ref())\n            }'
assert new_d.replace(newbranch,oldbranch)==old_d
N=R/'.reference/energyplus-src/26.1.0';pin=M['Native_commit']
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==pin
for row in M['Native_authority']:
 p=get(row['whole']);z=p.read_bytes();name=p.relative_to(N).as_posix()
 assert subprocess.check_output(['git','-C',str(N),'show',pin+':'+name])==z
 assert b''.join(z.splitlines(True)[row['start_line']-1:row['end_line']])==get(row['literal']).read_bytes()
observations=[]
for row in M['observed_prechange']:
 x=get(row['Source']).read_bytes();y=get(row['Native']).read_bytes()
 assert b'\r' not in x and y.count(b'\n')==y.count(b'\r\n')
 xx=x.replace(b'\n',b'\r\n').splitlines(keepends=True);yy=y.splitlines(keepends=True)
 assert xx[1:]==yy[1:] and len(xx)-1==row['nonheader_lines_exact_after_explicit_projection']
 observations.append(dict(case=row['case'],kind=row['kind'],unchanged_nonversion_body_rows=len(xx)-1,new_candidate_actual_claim=False))
O.mkdir();parses=[]
for i,row in enumerate(M['files'],1):
 p=get(row['proposed']);v=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(p)],capture_output=True);assert v.returncode==0
 st=O/f'parse-{i}.stdout';er=O/f'parse-{i}.stderr';st.write_bytes(v.stdout);er.write_bytes(v.stderr)
 parses.append(dict(exit_code=0,stdout=ref(st),stderr=ref(er)))
v=dict(schema='src06-dictionary-native-text-mode-bounded-independent-source-peer.v1',accepted=True,findings=[],manifest=ref(MP),source_wholes=wholes,literal_applications=4,independent_reapplied_diffs=apps,whole_Git_before_authentication=dict(revision=M['base_HEAD'],paths=parents),Native_commit=pin,Native_authority=M['Native_authority'],independent_Source_parses=parses,complete_transform_loop_identical_modulo_indent=True,dictionary_only_replacement_inverse_recovers_whole_parent=True,review=[
 'The existing reached SourceOutputStream translation loop is moved unchanged into one private pure Cow helper. Windows adds one CR before every LF, retaining existing CR; non-Windows/noLF returns borrowed bytes. Same physical write/error/failed flag order remains.',
 'Only active dictionary PhysicalFile write branch calls that helper. NativeNullBuffer bad states, already-failed PhysicalFile, failed physical open, absent stream, ensure/open/flush/close and flags remain whole unchanged by exact branch inverse. No reopen, reset or extra owner.',
 'Pinned Native fstream open lacks binary; formatted LF is written through actual ostream. The existing explicit-CRLF TAB class is not changed and no file postprocess/newline normalization is added.',
 'Before-fix dictionary body projection is observational only, not a production operand or fresh candidate output proof. Root must perform the planned shared build/actual run before a physical parity claim.'
 ],observed_existing_outputs=observations,new_test_bodies=0,main_mutations=0,Cargo_Native_or_tests_executed=False,actual_new_candidate_executed=False,gate_changes=False,author_Source=ref(Path(__file__)))
p=O/'review.json';p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

﻿from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'dictionary-native-text-mode-held-Root-01';assert not O.exists();O.mkdir()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
paths=['crates/ep_runtime/src/heat_balance/source_initialization/files.rs','crates/ep_runtime/src/heat_balance/source_initialization/files/dictionaries.rs'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='1435b44537a920ded21ae732bdc7c81051df0282' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
a=(R/paths[0]).read_bytes();start=a.index(b'        // IOFiles.open uses in|out|trunc, without binary.');end=a.index(b'        let result = self\n',start);old=a[start:end];assert b'for &byte in bytes' in old and old.count(b'text.push(b\'\\r\')')==1
helper=b'''/// Windows text-mode transformation shared by the actual physical streams.
/// Native IOFiles290 omits binary; every LF expands while prior CR is retained.
fn native_text_bytes(bytes: &[u8]) -> std::borrow::Cow<'_, [u8]> {
    #[cfg(windows)]
    if bytes.contains(&b'\\n') {
        let mut text = Vec::with_capacity(bytes.len());
        for &byte in bytes {
            if byte == b'\\n' {
                text.push(b'\\r');
            }
            text.push(byte);
        }
        return std::borrow::Cow::Owned(text);
    }
    std::borrow::Cow::Borrowed(bytes)
}

'''
b=a[:start]+b'        let bytes = native_text_bytes(bytes);\n'+a[end:];needle=b'            .write_all(bytes);';assert b.count(needle)==1;b=b.replace(needle,b'            .write_all(bytes.as_ref());',1);anchor=b'#[derive(Debug)]\nstruct SourceOutputStream';assert b.count(anchor)==1;b=b.replace(anchor,helper+anchor,1)
x=(R/paths[1]).read_bytes();old_dict=b'            Some(SourceDictionaryBuffer::PhysicalFile(file)) => file.write_all(bytes),';new_dict=b'''            Some(SourceDictionaryBuffer::PhysicalFile(file)) => {
                file.write_all(super::native_text_bytes(bytes).as_ref())
            }''';assert x.count(old_dict)==1;y=x.replace(old_dict,new_dict,1)
rows=[]
for i,(name,before,after) in enumerate(zip(paths,[a,x],[b,y]),1):
 assert before==subprocess.check_output(['git','show',head+':'+name],cwd=R)
 row=dict(canonical_path=name,before=put('before/'+name,before),proposed=put('proposed/'+name,after),literal_inverse=put('inverse/'+name,before))
 for label,src,dst in [('forward',before,after),('inverse',after,before)]:row[label+'_diff']=put(f'diffs/{i:02}-{label}.diff',''.join(difflib.unified_diff(src.decode().splitlines(True),dst.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name)).encode())
 q=subprocess.run(['C:/Users/GonieGonie/.cargo/bin/rustfmt.exe','--edition','2024','--config','skip_children=true','--emit','stdout',str(R/row['proposed']['path'])],capture_output=True);assert q.returncode==0,q.stderr
 row['Source_only_parse']=dict(exit_code=q.returncode,stdout=put(f'parse/{i:02}.stdout',q.stdout),stderr=put(f'parse/{i:02}.stderr',q.stderr));rows.append(row)
N=R/'.reference/energyplus-src/26.1.0';rev='6f2e40d10250a105b49966baa24d843711e61048';native=[]
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip()==rev
for name,lo,hi in [('IOFiles.cc',277,294),('IOFiles.hh',698,707),('OutputProcessor.cc',4729,4742)]:
 p=N/'src/EnergyPlus'/name;data=p.read_bytes();assert data==subprocess.check_output(['git','-C',str(N),'show',rev+':src/EnergyPlus/'+name]);native.append(dict(whole=ref(p),start_line=lo,end_line=hi,literal=put('Native/'+name+f'.L{lo}-{hi}.txt',b''.join(data.splitlines(keepends=True)[lo-1:hi]))))
observed=[]
for case in ['A-72H','A-ANNUAL']:
 for ext in ['rdd','mdd']:
  sp=D/f'canonical-source82-{case}-Root-11/output'/('eplusrs.'+ext);np=D/f'native-installed-{case}-Root-11/output'/('energyplusout.'+ext);sb,nb=sp.read_bytes(),np.read_bytes();sl,nl=sb.splitlines(keepends=True),nb.splitlines(keepends=True);assert all(l.endswith(b'\n') and not l.endswith(b'\r\n') for l in sl) and all(l.endswith(b'\r\n') for l in nl);assert [l[:-1]+b'\r\n' for l in sl[1:]]==nl[1:];observed.append(dict(case=case,kind=ext,Source=ref(sp),Native=ref(np),Source_ending='LF',Native_ending='CRLF',nonheader_lines_exact_after_explicit_projection=len(sl)-1,actual_new_candidate_run=False))
m=dict(schema='src06-held-shared-physical-native-text-write.v1',base_HEAD=head,files=rows,Native_commit=rev,Native_authority=native,observed_prechange=observed,change='Move the already accepted general-stream LF translation into one pure borrowed-or-owned helper, call it unchanged from general streams and at the actual dictionary PhysicalFile write. Other/null/failed/unopened alternatives, open/close ownership and error propagation remain exact.',qualifications=['Successful regular-file physical writes only; inherited general-adapter partial-write/OS-error timing equivalence is not newly claimed.','No postprocessing, table/RDD metadata normalization, report identity/counter/value changes, or actual new-candidate success claim.'],main_mutations=0,Cargo_Native_tests_executed=False,new_test_bodies=0,author_Source=ref(Path(__file__).resolve()))
p=O/'manifest.json';p.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

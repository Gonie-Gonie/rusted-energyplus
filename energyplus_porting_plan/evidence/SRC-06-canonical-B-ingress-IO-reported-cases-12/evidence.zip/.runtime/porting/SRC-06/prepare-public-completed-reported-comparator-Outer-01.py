from pathlib import Path
import ast,difflib,hashlib,json,subprocess
R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'public-completed-reported-comparator-held-Outer-01'
assert not O.exists()
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(x):
 p=R/x['path'];assert ref(p)['sha256']==x['sha256'];return p
mp=B/'completed-reported-stream-comparator-prepared-Outer-01/manifest.json'
assert ref(mp)['sha256']=='0bbdc88f08ddae130ae1b9d017c469999390be8ad855a52e0168eb95a3855026'
m=json.loads(mp.read_bytes());oldpath=get(m['script']);old=oldpath.read_bytes()
assert hashlib.sha256(old).hexdigest()=='db0b3915e3e1fcd9fa21cd8ebac0b19739ccf8f4b234decefb20b2a4866e37ae'
checkpoint='energyplus_porting_plan/evidence/SRC-06-canonical-completed-source-activation-11/summary.json'
cp=R/checkpoint;sha=ref(cp)['sha256'];assert sha=='49bc529e949c23e3ccf92880db6dccdef42decd183c3ed8a6fa30d32a7adba60'
assert subprocess.check_output(['git','show','1435b44537a920ded21ae732bdc7c81051df0282:'+checkpoint],cwd=R)==cp.read_bytes()
old_audit=get(m['preceding_accepted_operational_audit']);a=json.loads(old_audit.read_bytes());c=json.loads(cp.read_bytes())
assert a['policy_metadata_notes']==c['policy_metadata_notes'] and a['policy']==c['original_tolerance_policy']
substitutions=[
 ('ROOT = Path(__file__).resolve().parents[3]','ROOT = Path(__file__).resolve().parents[2]'),
 ('AUDIT_PATH = ".runtime/porting/SRC-06/completed-A24-tolerance-identity-audit-Audit-02/audit.json"',f'PUBLIC_CHECKPOINT_PATH = "{checkpoint}"'),
 ('AUDIT_SHA = "3cd42ca127c9eef3edff9d38a127dfa0d63cf8edcb4bc9ccab31079240e379a4"',f'PUBLIC_CHECKPOINT_SHA = "{sha}"'),
 ('audit = authenticated(ROOT / AUDIT_PATH, AUDIT_SHA)','checkpoint = authenticated(ROOT / PUBLIC_CHECKPOINT_PATH, PUBLIC_CHECKPOINT_SHA)'),
 ('"preceding_operational_contract": ref(ROOT / AUDIT_PATH)','"public_operational_checkpoint": ref(ROOT / PUBLIC_CHECKPOINT_PATH)'),
 ('"policy_metadata_notes": audit["policy_metadata_notes"]','"policy_metadata_notes": checkpoint["policy_metadata_notes"]')]
new=old.decode('utf8')
for before,after in substitutions:
 assert new.count(before)==1,before;new=new.replace(before,after)
new=new.encode();recovered=new.decode()
for before,after in reversed(substitutions):
 assert recovered.count(after)==1,after;recovered=recovered.replace(after,before)
assert recovered.encode()==old
assert 'AUDIT_PATH' not in new.decode() and 'AUDIT_SHA' not in new.decode()
before_ast=ast.parse(old);after_ast=ast.parse(new)
# All ordinary functions are literally whole equal except main's three metadata
# dependency references. Reverse the six listed spans to recover the full file.
old_funcs={n.name:ast.get_source_segment(old.decode(),n) for n in before_ast.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_funcs={n.name:ast.get_source_segment(new.decode(),n) for n in after_ast.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert old_funcs.keys()==new_funcs.keys()
assert all(old_funcs[n]==new_funcs[n] for n in old_funcs if n!='main')
main=new_funcs['main']
for before,after in reversed(substitutions[3:]):main=main.replace(after,before)
assert main==old_funcs['main']
canonical='tools/porting/check_completed_reported_streams.py';assert not (R/canonical).exists()
O.mkdir();p=O/'proposed'/canonical;p.parent.mkdir(parents=True);p.write_bytes(new)
parent=O/'parent.py';parent.write_bytes(old)
fd=O/'forward.diff';iv=O/'inverse.diff'
fd.write_bytes(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='parent/compare-completed-reported-streams-Outer-01.py',tofile='proposed/'+canonical,n=3)).encode())
iv.write_bytes(''.join(difflib.unified_diff(new.decode().splitlines(True),old.decode().splitlines(True),fromfile='proposed/'+canonical,tofile='parent/compare-completed-reported-streams-Outer-01.py',n=3)).encode())
man=dict(schema='src06-held-public-reusable-completed-reported-comparator.v1',base_HEAD='1435b44537a920ded21ae732bdc7c81051df0282',canonical_path=canonical,before=None,proposed=ref(p),immutable_parent=ref(parent),preceding_preparation=ref(mp),public_checkpoint=ref(cp),exact_substitutions=[dict(before=x,after=y) for x,y in substitutions],whole_inverse_recovers_parent=True,all_nonmain_functions_and_classes_whole_equal=True,main_whole_inverse_recovers_parent=True,syntax='Python ast.parse accepted, no comparator execution',forward_diff=ref(fd),inverse_diff=ref(iv),public_checkpoint_policy_metadata_notes_exact_private_predecessor=True,policy_hash_and_historical_authentication_unchanged=True,acceptance_algorithm_math_and_metrics_whole_unchanged=True,private_runtime_audit_dependency_removed=True,actual_root_resolution='Canonical tools/porting/check_completed_reported_streams.py uses parents[2], resolving the repository root; do not execute from held proposal layout.',limits='Root independently reviews the six bounded metadata/path substitutions and applies only this one new public tool. Root will execute public A72 once as control; the same whole scan/metrics algorithm authenticates the already completed annual comparison without another annual scan.',main_mutations=0,Cargo_Native_or_tests_executed=False,new_test_bodies=0,comparison_executed=False,author_Source=ref(Path(__file__)))
p=O/'manifest.json';p.write_bytes((json.dumps(man,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

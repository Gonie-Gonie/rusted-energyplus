"""Seal bounded real SourceB raw ingress; no main/Cargo/tests/engine changes."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'ordinary-source-B-raw-ingress-held-Audit-01';assert not O.exists()
P=D/'ordinary-source-B-raw-ingress-draft-Audit-04/draft.json';draft=json.loads(P.read_bytes());HEAD='1435b44537a920ded21ae732bdc7c81051df0282';assert draft['base_HEAD']==HEAD
N=R/'.reference/energyplus-src/26.1.0';PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 p=R/r['path'];assert ref(p)==r,r;return p.read_bytes()
def run(a,root=R):
 p=subprocess.run(a,cwd=root,capture_output=True);assert p.returncode==0,(a,p.stderr);return p.stdout
assert run(['git','rev-parse','HEAD']).decode().strip()==HEAD
assert run(['git','rev-parse','HEAD'],N).decode().strip()==PIN
receipt=D/'canonical-source82-B-NOLIMIT-24H-command-Root-11/receipt.json';assert ref(receipt)['sha256']=='ad50620376f596645de4d866166eaa2920a6bf0f5c9c7d860cd2702cb72cbd40'
actual=json.loads(receipt.read_bytes());assert actual['exit_code']==6 and actual['launch_error'] is None and actual['source_bytes_match_before_and_after']
output=D/'canonical-source82-B-NOLIMIT-24H-Root-11/output';diagnostics=json.loads((output/'diagnostics.json').read_bytes());summary=json.loads((output/'run-summary.json').read_bytes())
assert any(x['code']=='RuntimeConvergenceFailure' and x['message']=='ordinary equipment excludes positive family NodeList' for x in diagnostics['diagnostics'])
assert summary['rust_runtime'] is None and summary['exit_code']==6
# Primary schema producer, in memory only. No Native simulation or generated
# canonical file; installed selected objects must be whole-equal actual pinned
# IDD/parser/modifier output before they can authorize literal Rust grammar.
sys.path.insert(0,str(N/'idd/schema'));import idd_parser,modify_schema
data=idd_parser.Data();data.file=(N/'idd/Energy+.idd.in').read_text(encoding='utf8');idd_parser.parse_idd(data)
transforms=['change_schedule_compact','change_utility_cost','change_special_cased_enums','change_special_cased_name_fields','change_extensions_name','change_89_release_issues','add_explicit_extensible_bounds']
for symbol in transforms:getattr(modify_schema,symbol)(data.schema)
installed=json.loads(read(draft['field_schema']));families=['NodeList','Schedule:Compact','ThermostatSetpoint:DualSetpoint','ZoneControl:Thermostat','ZoneHVAC:EquipmentConnections','ZoneHVAC:EquipmentList','ZoneHVAC:IdealLoadsAirSystem']
for f in families:assert data.schema['properties'][f]==installed['properties'][f],f
subset={f:data.schema['properties'][f] for f in families}
U='crates/ep_run/src/';H='crates/ep_runtime/src/heat_balance/'
expected={U+'ordinary_equipment_input.rs',U+'ordinary_equipment_input/source_b.rs',U+'ordinary_input_processor.rs',U+'ordinary_input_processor/input_statistics.rs',H+'selected_input_processor/input_statistics.rs',H+'ordinary_equipment.rs',U+'pipeline.rs',U+'ordinary_input_processor/schema.rs',H+'selected_input_processor/input_statistics/schema.rs'}
by={x['canonical_path']:x for x in draft['files']};assert set(by)==expected and len(by)==9
before={};after={};gits=[]
for name,r in by.items():
 p=subprocess.run(['git','show',HEAD+':'+name],cwd=R,capture_output=True)
 absent=name.endswith('/ordinary_equipment_input/source_b.rs');assert p.returncode==(128 if absent else 0)
 old=p.stdout;assert ((R/name).read_bytes() if (R/name).exists() else b'')==old
 before[name]=old;after[name]=read(r['proposed']);gits.append(dict(path=name,revision=HEAD,exit_code=p.returncode,whole_before_SHA256=hashlib.sha256(old).hexdigest(),whole_before_bytes=len(old),actual_working_bytes_equal=True))
assert sum(not x for x in before.values())==1
assert not any(n in expected for n in [H+'source_initialization/files.rs',H+'source_initialization/files/dictionaries.rs',H+'selected_schedule_manager.rs',U+'ordinary_schedule_input.rs'])
# Exact no-ScopeB pipeline inverse, old input-statistics transfer payload and
# empty-equipment constructor are retained without a new positive-value cache.
pipeline=after[U+'pipeline.rs'].decode();oldpipe=before[U+'pipeline.rs'].decode()
pipeline=pipeline.replace('''Some(if scope == Some(crate::PortingScope::B) {
            crate::ordinary_input_processor::resolve_source_b(raw_model)?
        } else {
            crate::ordinary_input_processor::resolve(raw_model)?
        })''','Some(crate::ordinary_input_processor::resolve(raw_model)?)',1)
pipeline=pipeline.replace('''            let (equipment, radiation) = if scope == Some(crate::PortingScope::B) {
                crate::ordinary_equipment_input::resolve_with_radiation_source_b(raw_model, input.advanced_report_variables)?
            } else {
                crate::ordinary_equipment_input::resolve_with_radiation(raw_model, input.advanced_report_variables)?
            };''','''            let (equipment, radiation) = crate::ordinary_equipment_input::resolve_with_radiation(
                raw_model,
                input.advanced_report_variables,
            )?;''',1)
assert pipeline==oldpipe
raw=after[U+'ordinary_input_processor/input_statistics.rs'];old=before[U+'ordinary_input_processor/input_statistics.rs']
assert raw.startswith(old.replace(b'    SourceInputStatisticsInput {\n',b'    SourceInputStatisticsInput {\n        object_order: Default::default(),\n',1))
assert b'RawValue::Number(text) => SourceInputStatisticsValue::Number(text.clone())' in raw
assert b'raw.ordered_instances(&family.0)' in raw and b'full_value(raw)' in raw
original_ctor=before[H+'ordinary_equipment.rs'].split(b'    pub fn from_family_inventory',1)[1].split(b'\n}\n',1)[0]
assert original_ctor in after[H+'ordinary_equipment.rs']
for name in expected:assert after[name].count(b'#[test]')==before[name].count(b'#[test]')
# Current raw shape audit over the actual failed production input, not an oracle
# value. No values are defaulted, evaluated or supplied to a simulation here.
rawp=output/'input/converted.epJSON';rawjson=json.loads(rawp.read_bytes())
def valid(meta,value):
 if 'anyOf'in meta:return any(valid(x,value) for x in meta['anyOf'])
 kind=meta['type']
 if kind=='string':return isinstance(value,str) and ('enum'not in meta or any(value.casefold()==x.casefold() for x in meta['enum']))
 if kind in ['number','integer']:
  if isinstance(value,bool) or not isinstance(value,(int,float)):return False
  if kind=='integer' and int(value)!=value:return False
  return all((value>=v if k=='minimum' else value<=v if k=='maximum' else value>v if k=='exclusiveMinimum' else value<v) for k,v in meta.items() if k in ['minimum','maximum','exclusiveMinimum','exclusiveMaximum'])
 if kind=='array':
  return isinstance(value,list) and all(isinstance(item,dict) and all(k in item for k in meta['items'].get('required',[])) and all(k in meta['items']['properties'] and valid(meta['items']['properties'][k],v) for k,v in item.items()) for item in value)
 raise AssertionError(kind)
shape=[]
for family in families:
 p=next(iter(subset[family]['patternProperties'].values()))
 for name,fields in rawjson[family].items():
  assert all(k in fields for k in p.get('required',[]))
  assert all(k in p['properties'] and valid(p['properties'][k],v) for k,v in fields.items()),(family,name)
  shape.append(dict(family=family,object_name=name,complete_actual_fields=fields))
O.mkdir()
def put(n,b):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def doc(n,v):return put(n,(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
authority=[]
native_paths=['idd/Energy+.idd.in','idd/schema/idd_parser.py','idd/schema/modify_schema.py','idd/schema/generate_epJSON_schema.py','src/EnergyPlus/InputProcessing/InputProcessor.cc','src/EnergyPlus/ScheduleManager.cc','src/EnergyPlus/DataZoneEquipment.cc','src/EnergyPlus/NodeInputManager.cc']
for name in native_paths:
 b=run(['git','show',PIN+':'+name],N);assert b==(N/name).read_bytes()
 authority.append(dict(path=name,revision=PIN,whole_native=put('Original-Git/'+name,b),readonly_Git_command=['git','show',PIN+':'+name],whole_Git_equal=True))
auth=doc('schema-authority.json',dict(Original_commit=PIN,pinned_whole_sources=authority,primary_producer='idd_parser.Data/parse_idd; exact generate_epJSON_schema transform sequence, all in memory',transforms=transforms,installed_full_schema=draft['field_schema'],seven_whole_native_objects=put('seven-whole-Native-schema-objects.json',(json.dumps(subset,indent=2)+'\n').encode()),all_seven_whole_installed_objects_equal_pinned_producer=True,missing_definitions=['ThermostatSetpoint:DualSetpoint','ZoneControl:Thermostat','ZoneHVAC:IdealLoadsAirSystem'],no_Native_engine_or_Cargo=True))
ns={'re':re}
for node in ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8')).body:
 if isinstance(node,ast.FunctionDef) and node.name=='apply':exec(compile(ast.Module([node],type_ignores=[]),'<exact-complete-literal-application>','exec'),ns)
rows=[];apps=[];parses=[]
for i,name in enumerate(sorted(expected),1):
 b=before[name];a=after[name];row=dict(canonical_path=name,before_absent=not bool(b),before=put('before/'+name,b),proposed=put('proposed/'+name,a),literal_inverse=put('literal-inverse/'+name,b))
 for key,x,y in [('forward_diff',b,a),('inverse_diff',a,b)]:
  d=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name)).encode();row[key]=put(f'diffs/{i:02}-{key}.diff',d);assert ns['apply'](x,d)==y;apps.append(dict(path=name,role=key,whole_equal=True))
 q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],cwd=R,input=a,capture_output=True);assert q.returncode==0,(name,q.stderr)
 parses.append(dict(path=name,exit_code=0,stdout=put(f'parse/{i:02}.stdout',q.stdout),stderr=put(f'parse/{i:02}.stderr',q.stderr),proposed_unchanged=read(row['proposed'])==a))
 rows.append(row)
assert len(rows)==9 and len(apps)==18
rawscope=doc('actual-B-input-preservation.json',dict(actual_failed_receipt=ref(receipt),actual_failed_input=ref(rawp),actual_nodeList_frontier='ordinary equipment excludes positive family NodeList',all_seven_complete_raw_input_objects=shape,actual_counts=dict(NodeList=len(rawjson['NodeList']),controlled_zones=len(rawjson['ZoneHVAC:EquipmentConnections']),equipment_lists=len(rawjson['ZoneHVAC:EquipmentList']),Compact=len(rawjson['Schedule:Compact'])),retention='Numbers clone existing RawValue textual operands and booleans clone exact bits; strings/case/blank/null and nested extension fields/order remain exact. Names are obtained from validated RawModel::ordered_instances; no new default/current schedule or node values.',not_an_execution_of_proposed_Rust=True))
manifest=doc('manifest.json',dict(schema='src06-held-source-B-real-raw-ingress.v1',status='HELD source only; requires independent full Source peer and Root combined actual check/B frontier run',base_HEAD=HEAD,Original_commit=PIN,files=rows,existing_Source_files=8,new_Source_files=1,literal_applications=apps,Source_only_parses=parses,actual_Git_before=gits,schema_authority=auth,actual_B_frontier_and_raw_operands=rawscope,actual_B_prior_receipt=ref(receipt),actual_B_prior_diagnostics=ref(output/'diagnostics.json'),actual_B_prior_summary=ref(output/'run-summary.json'),draft_Source=ref(D/'prepare-source-B-raw-ingress-Audit-01.py'),author_Source=ref(Path(__file__).resolve()),explicit_SourceB_only_pipeline_calls=2,whole_pipeline_None_and_SomeA_inverse_recovered=True,old_A_None_statistics_transfer_equal_except_empty_order_metadata=True,existing_empty_equipment_constructor_whole_preserved=True,all_real_positive_family_counts_preserved=True,sole_IP_raw_owner_retained=True,missing_query_and_statistics_definitions_added=3,seven_fields_family_grammar='All seven whole schema objects are exact pinned Native producer outputs. Literal required fields/types/enums/bounds/extensible names are admitted; absent/default fields stay absent for the actual later getter. Actual B converted fields are shape-validated only, never sampled as answers.',raw_metadata='Exact SourceB Number(String)/Bool, recursive field/array values and validated effective original object-name order live in existing SourceInputStatisticsInput on SelectedInputProcessor; no second numerical or ready-state owner.',genuine_next_boundary='Existing SelectedScheduleManager::process_schedule_input reads real Compact count2 and maxargs, then typed nonconstant schedule input before later controlled equipment/NodeList getters. This is static expected frontier until Root actual new B run.',schedule_manager_and_schedule_input_projection_unchanged=True,dictionary_IO_paths_untouched=True,no_typed_NodeID_or_legacy_cache_factories=True,positive_getter_or_scientific_body_changes=False,reset_math_tolerance_changes=False,no_Native_engine_or_Cargo_or_tests_executed=True,new_test_bodies=0,canonical_mutations=0,full_B_or_gate_completion_claim=False,qualifications=['This packet carries real B input into the actual Source owner/getter sequence; it does not implement Compact, positive controlled equipment, NodeList allocation or PurchasedAir dispatch.','Schema grammar/count/default metadata is produced by pinned primary Native IDD/parser code, not Native output answers. SourceB still stops honestly at the next real unported child.','No schedule values, NodeIDs, zero positive counts, cached histories, native answer series, compatibility fallback or initialization-ready flags are fabricated.','A/None original admission and scalar projection remain the existing route; the entire pipeline becomes whole original1435 after replacing only the two SomeB call selections.','Root owns all Cargo, application, actual commands, publication and commits.']))
assert run(['git','rev-parse','HEAD']).decode().strip()==HEAD
for name,b in before.items():assert ((R/name).read_bytes() if (R/name).exists() else b'')==b
print(json.dumps(manifest))

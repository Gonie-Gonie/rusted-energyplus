"""Static independent comparator peer; no comparator or simulation execution."""
from pathlib import Path
import ast
import hashlib
import json
import math
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/Peer-completed-reported-stream-comparator-Source-review-01'

def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def authentic(path, sha, length=None):
    path = ROOT / path
    result = ref(path)
    assert result['sha256'] == sha, result
    assert length is None or result['bytes'] == length, result
    return path, result

def load(row):
    path, result = authentic(row['path'], row['sha256'], row.get('bytes'))
    return json.loads(path.read_bytes()), result

manifest_path, manifest_ref = authentic('.runtime/porting/SRC-06/completed-reported-stream-comparator-prepared-Outer-01/manifest.json', '0bbdc88f08ddae130ae1b9d017c469999390be8ad855a52e0168eb95a3855026', 5427)
manifest = json.loads(manifest_path.read_bytes())
script_path, script_ref = authentic(manifest['script']['path'], 'db0b3915e3e1fcd9fa21cd8ebac0b19739ccf8f4b234decefb20b2a4866e37ae', 23983)
source = script_path.read_text(encoding='utf8')
tree = ast.parse(source)
functions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
assert set(functions) == {'require', 'digest', 'ref', 'read', 'authenticated', 'project_ref', 'normalized_path', 'option', 'receipt', 'PhysicalLines', 'paired', 'available_variables', 'norm', 'binding', 'completed_stream', 'main'}
guards = [
    'r["exit_code"] == 0 and r["launch_error"] is None',
    'r["source_bytes_match_before_and_after"] is True',
    'option(command, "--porting-scope") == case["scope"]',
    'runtime["execution"] == "actual Source ManageSimulation successful through620"',
    'require(xe == ye,',
    'require(x == y,',
    'require(self.file.read(1) == b"",',
    'sorted(indices) == list(range(len(policy_rows)))',
    'require(sf[0] == nf[0],',
    'require(sl == nl, "native environment/timestamp raw tuple differs")',
    'd["last_stamp_index"] < stamp_index',
    'int(match[1]) == records == owner["reported_numeric_records"]',
    'd["samples"] == owner_row["samples"] == expected and expected > 0',
    'd["sum_squared_delta"] += delta * delta',
    'delta <= t["atol"] or delta <= t["rtol"] * scale',
    'math.sqrt(d["sum_squared_delta"] / d["samples"])',
    'd["rmse_delta"] <= d["policy"]["rmse_max"]',
    'failures.write(json.dumps(',
    'struct.pack(">d", x) != struct.pack(">d", y)',
    'require(not source_path.exists() and not native_path.exists(),',
    'owner["deleted_empty"] is True and owner["reported_numeric_records"] == 0',
]
assert all(guard in source for guard in guards)
assert 'source-reported-results.json' not in source
assert 'readline()' in source and 'for chunk in iter(lambda: f.read(1024 * 1024), b"")' in source
policy, policy_ref = load(manifest['policy'])
revision = '2fffe68fb9131c80efcd3232de3a81d5290045c6'
historical = subprocess.check_output(['git', 'show', revision + ':' + manifest['policy']['path']], cwd=ROOT)
assert historical == (ROOT / manifest['policy']['path']).read_bytes()
assert policy['schema_version'] == 'con01-output-tolerances.v2'
assert all(row['rtol'] == 0 for group in ('profiles', 'meter_profiles') for rows in policy[group].values() for row in rows)
audit, audit_ref = load(manifest['preceding_accepted_operational_audit'])
old_peer, old_peer_ref = load(manifest['independent_operational_peer'])
assert old_peer['accepted'] is True
assert manifest['explicit_policy_metadata_qualifications'] == audit['policy_metadata_notes']
receipts = []
for key in ('ready_actual_Source_A72_receipt', 'ready_Native_A72_receipt', 'ready_Native_annual_receipt'):
    item, item_ref = load(manifest[key])
    assert item['exit_code'] == 0 and item['launch_error'] is None and item['source_bytes_match_before_and_after'] is True
    receipts.append(item_ref)
annual_path, annual_ref = authentic('.runtime/porting/SRC-06/canonical-source82-A-ANNUAL-command-Root-11/receipt.json', '9ab4d0478339a53c4b5c8adf36155c74e5f94336fd0e2da651e1abee0781aabd')
annual = json.loads(annual_path.read_bytes())
assert annual['exit_code'] == 0 and annual['launch_error'] is None and annual['source_bytes_match_before_and_after'] is True
receipts.append(annual_ref)
report_path, report_ref = authentic('.runtime/porting/SRC-06/canonical-source82-A-72H-tolerance-Root-12/comparison.json', 'df345237096da07face1f70bf7657bd4602619fb131107ce499d17eab185fe27')
report = json.loads(report_path.read_bytes())
assert report['accepted'] is True and report['case'] == 'A-72H'
assert report['author_Source'] == script_ref and report['policy'] == policy_ref
assert report['policy_metadata_notes'] == audit['policy_metadata_notes']
assert report['Source_receipt'] == receipts[0] and report['Native_receipt'] == receipts[1]
metrics = [row for stream in report['streams'] for row in stream['series']]
assert len(metrics) == 58
assert [stream['records'] for stream in report['streams']] == [55 * 288, 3 * 72]
assert [len(stream['series']) for stream in report['streams']] == [55, 3]
for stream, rows in zip(report['streams'], (policy['profiles']['A'], policy['meter_profiles']['A'])):
    assert sorted(row['policy_index'] for row in stream['series']) == list(range(len(rows)))
    for row in stream['series']:
        assert row['policy'] == rows[row['policy_index']]
        assert row['samples'] == (288 if row['frequency'] == 'TimeStep' else 72)
        assert row['rmse_delta'] == math.sqrt(row['sum_squared_delta'] / row['samples'])
        assert row['rmse_limit_met'] == (row['rmse_delta'] <= row['policy']['rmse_max'])
        assert row['passed'] and row['tolerance_failures'] == 0
assert report['totals'] == {'series': 58, 'samples': 16056, 'raw_operand_unequal': 10651, 'parsed_binary64_unequal': 10651, 'tolerance_failures': 0, 'rmse_failures': 0, 'passed': True}
assert sum(row['samples'] for row in metrics) == report['totals']['samples']
assert sum(row['parsed_binary64_unequal'] for row in metrics) == 10651
assert sum(row['raw_operand_unequal'] for row in metrics) == 10651
empty_path, empty_ref = authentic(report['all_uncapped_tolerance_failures']['path'], report['all_uncapped_tolerance_failures']['sha256'], 0)
assert not OUT.exists()
OUT.mkdir()
review = {
    'schema': 'src06-independent-static-reported-stream-comparator-Source-peer.v1',
    'accepted': True,
    'findings': [],
    'prepared_manifest': manifest_ref,
    'complete_comparator_Source': script_ref,
    'review_method': 'Complete 23,983-byte independent Source read, Python AST syntax/guard inventory, authenticated original contracts and successful receipts, and bounded readback of existing Root A72 scalar comparison. Comparator was not imported or executed by this peer.',
    'receipt_and_scope_binding': 'Both authenticated command receipts require actual exit0, no launch error, stable producer bytes, exact contract input/weather arguments and explicit Source scope. Source summary requires successful actual through620, correct environment duration/settings, and genuine real stream owners. Incomplete B cannot pass.',
    'paired_identity_order_and_custody': 'All physical dictionary declarations/IDs/counts/key/name/unit/frequency and selected actual RDD types are paired exactly; every named policy row binds once. Raw environment and interval tuples, line endings, report-ID/operand ordering, unique monotonic intervals, per-series stamp progression, catalog order/StoreType, footer/real owner counters and EOF are checked. Only Program Version payload differs. Filesystem path normalization does not normalize physical data.',
    'original_numeric_policy': policy_ref,
    'historical_policy_revision': revision,
    'original_whole_policy_matches_historical_Git': True,
    'all_fixed_variable_and_meter_rtol_zero': True,
    'numeric_method': 'Finite parsed raw reported operands; original named atol OR rtol, independent raw-token/binary64 inequality counters, sequential binary64 sum(delta*delta) followed by sqrt(sum/count) and original rmse_max. No unit conversion, interpolation, reaggregation or resampling.',
    'explicit_policy_metadata_notes_preserved': audit['policy_metadata_notes'],
    'preceding_A24_operational_audit': audit_ref,
    'preceding_independent_A24_peer': old_peer_ref,
    'annual_memory_review': 'O(number of declarations/series plus one paired physical line and small run-summary/RDD/MDD). Only scalar metrics and latest clock are retained; uncapped failures stream as JSONL. Large own exported result JSON and per-sample histories are never loaded. Whole-file digest is chunked. No measured RSS/time/syscall claim.',
    'deleted_empty_MTR': 'Both absent physical streams require empty policy, real deleted-empty owner, zero records/series and empty catalog; one-sided absence or fabricated empty positive policy fails.',
    'authenticated_actual_receipts': receipts,
    'existing_Root_A72_report_bounded_readback': {'comparison': report_ref, 'totals': report['totals'], '55_Timestep_times288_and3_Hourly_times72': True, 'all58_policy_rows_and_scalar_RMSE_formula_rechecked': True, 'empty_uncapped_failure_ledger': empty_ref, 'raw_streams_not_rescanned': True},
    'limits': 'Static reusable-comparator acceptance and bounded existing A72 report consistency only. No independent comparator execution or annual numeric-result recomputation by this peer; no JSON/CSV roundtrip, ancillary-stream, internal-operation bit, whole15case or gate completion claim.',
    'author_Source': ref(Path(__file__)),
    'comparator_executed_by_peer': False,
    'Cargo_Native_or_tests_executed': False,
    'main_mutations': 0,
    'policy_changes': 0,
    'gate_changes': 0,
}
result = OUT / 'review.json'
result.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps(ref(result)))

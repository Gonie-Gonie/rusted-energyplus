from pathlib import Path
import ast,hashlib,json,re,subprocess,types
R=Path.cwd();B=R/'.runtime/porting/SRC-06';MP=B/'ordinary-source-B-raw-ingress-held-Audit-01/manifest.json'
O=B/'Outer-source-B-raw-ingress-Source-review-01';assert not O.exists()
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(v):
 p=R/v['path'];x=ref(p);assert x['sha256']==v['sha256'] and x['bytes']==v.get('bytes',x['bytes']);return p
assert ref(MP)['sha256']=='da19dc653e37e8a6c6249a129c98c84080b44e74b5d407e75b457dad731807c7'
M=json.loads(MP.read_bytes());rows={v['canonical_path']:v for v in M['files']};assert len(rows)==9
S=(B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8');F=next(n for n in ast.parse(S).body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal');G={'re':re};exec(compile(ast.Module(body=[F],type_ignores=[]),'<independent-complete-literal-applier>','exec'),G)
before={};after={};apps=[]
for name,row in rows.items():
 old=get(row['before']).read_bytes();new=get(row['proposed']).read_bytes()
 assert G['apply_literal'](old,get(row['forward_diff']).read_bytes())==new
 assert G['apply_literal'](new,get(row['inverse_diff']).read_bytes())==old==get(row['literal_inverse']).read_bytes()
 q=subprocess.run(['git','show',M['base_HEAD']+':'+name],cwd=R,capture_output=True)
 assert (q.returncode==128 and not old and row['before_absent']) or (q.returncode==0 and q.stdout==old and not row['before_absent'])
 assert old.count(b'#[test]')==new.count(b'#[test]')
 before[name]=old;after[name]=new;apps.extend([row['forward_diff'],row['inverse_diff']])
U='crates/ep_run/src/';H='crates/ep_runtime/src/heat_balance/'
pipeline=after[U+'pipeline.rs'].decode()
pipeline=pipeline.replace('''Some(if scope == Some(crate::PortingScope::B) {
            crate::ordinary_input_processor::resolve_source_b(raw_model)?
        } else {
            crate::ordinary_input_processor::resolve(raw_model)?
        })''','Some(crate::ordinary_input_processor::resolve(raw_model)?)')
pipeline=pipeline.replace('''            let (equipment, radiation) = if scope == Some(crate::PortingScope::B) {
                crate::ordinary_equipment_input::resolve_with_radiation_source_b(raw_model, input.advanced_report_variables)?
            } else {
                crate::ordinary_equipment_input::resolve_with_radiation(raw_model, input.advanced_report_variables)?
            };''','''            let (equipment, radiation) = crate::ordinary_equipment_input::resolve_with_radiation(
                raw_model,
                input.advanced_report_variables,
            )?;''')
assert pipeline.encode()==before[U+'pipeline.rs']
old_scalar=before[U+'ordinary_input_processor/input_statistics.rs']
new_scalar=after[U+'ordinary_input_processor/input_statistics.rs']
assert new_scalar.startswith(old_scalar.replace(b'    SourceInputStatisticsInput {\n',b'    SourceInputStatisticsInput {\n        object_order: Default::default(),\n',1))
old_ctor=before[H+'ordinary_equipment.rs'].split(b'    pub fn from_family_inventory',1)[1].split(b'\n}\n',1)[0]
assert old_ctor in after[H+'ordinary_equipment.rs']
# Authenticate all Native primary production inputs, then run only the schema
# parser/transform functions in memory. No Native binary or generated file.
A=json.loads(get(M['schema_authority']).read_bytes());N=R/'.reference/energyplus-src/26.1.0';PIN=A['Original_commit']
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==PIN
native={}
for row in A['pinned_whole_sources']:
 p=get(row['whole_native']);z=p.read_bytes();assert subprocess.check_output(['git','-C',str(N),'show',PIN+':'+row['path']])==z
 native[row['path']]=z
parser=types.ModuleType('independent_pinned_idd_parser');exec(compile(native['idd/schema/idd_parser.py'],'<pinned-parser>','exec'),parser.__dict__)
modifier=types.ModuleType('independent_pinned_schema_modifier');exec(compile(native['idd/schema/modify_schema.py'],'<pinned-modifier>','exec'),modifier.__dict__)
data=parser.Data();data.file=native['idd/Energy+.idd.in'].decode('utf8');parser.parse_idd(data)
generator=ast.parse(native['idd/schema/generate_epJSON_schema.py'])
fn=next(n for n in generator.body if isinstance(n,ast.FunctionDef) and n.name=='generate_epJSON_schema')
calls=[n.value.func.attr for n in fn.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='modify_schema']
assert calls==A['transforms'] and len(calls)==7
for name in calls:getattr(modifier,name)(data.schema)
installed=json.loads(get(A['installed_full_schema']).read_bytes());subset=json.loads(get(A['seven_whole_native_objects']).read_bytes())
assert len(subset)==7
for family,value in subset.items():assert data.schema['properties'][family]==installed['properties'][family]==value

def norm(s):
 tokens=''.join(re.findall(r'"(?:\\.|[^"\\])*"|\S',s))
 # rustfmt inserts optional final commas in enum arrays and function arguments.
 return re.sub(r',(?=[\]\)}])','',tokens)
def body(s,start):
 i=s.index('{',start);depth=1;j=i+1;quoted=False;escape=False
 while depth:
  c=s[j]
  if quoted:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quoted=False
  elif c=='"':quoted=True
  elif c=='{':depth+=1
  elif c=='}':depth-=1
  j+=1
 return s[i+1:j-1]
def top_items(s):
 out=[];depth=0;quote=False;escape=False;start=0
 for i,c in enumerate(s):
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quote=False
  elif c=='"':quote=True
  elif c in '([{':depth+=1
  elif c in ')]}':depth-=1
  elif c==',' and depth==0:out.append(s[start:i].strip());start=i+1
 if s[start:].strip():out.append(s[start:].strip())
 return out
grammar=after[U+'ordinary_equipment_input/source_b.rs'].decode()
armbody=body(grammar,grammar.index('match (family, name)'))
arms={}
headers=list(re.finditer(r'(?m)^ {8}\(\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,?\s*\)\s*=>\s*',armbody))
default=re.search(r'(?m)^ {8}_ => false,?\s*$',armbody);assert default
for i,match in enumerate(headers):
 end=headers[i+1].start() if i+1<len(headers) else default.start()
 expression=armbody[match.end():end].strip().rstrip(',').strip()
 if expression.startswith('{'):
  assert expression.endswith('}');expression=expression[1:-1].strip()
 identity=match[1],match[2];assert identity not in arms;arms[identity]=expression
def quoted(s):return json.dumps(s)
def expected_expression(meta,v='value'):
 if 'anyOf' in meta:return '('+' || '.join(expected_expression(row,v) for row in meta['anyOf'])+')'
 kind=meta['type']
 if kind=='string':
  if 'enum' in meta:return 'text_is('+v+', &['+', '.join(quoted(x) for x in meta['enum'])+'])'
  return 'matches!('+v+', RawValue::String(_))'
 if kind in ('number','integer'):
  checks=['n.fract() == 0.0'] if kind=='integer' else []
  for key,op in [('minimum','>='),('maximum','<='),('exclusiveMinimum','>'),('exclusiveMaximum','<')]:
   if key in meta:checks.append('n '+op+' '+repr(float(meta[key])))
  return 'number('+v+').is_some_and(|n| '+' && '.join(checks)+')' if checks else 'number('+v+').is_some()'
 if kind=='array':
  item=meta['items'];pieces=[]
  for name,field in item['properties'].items():pieces.append(quoted(name)+' => blank(value) || '+expected_expression(field)+', ')
  match='match name.0.as_str() { '+''.join(pieces)+'_ => false, }'
  req=''.join(' && fields.get(&FieldName('+quoted(name)+'.into())).is_some_and(|value| !blank(value))' for name in item.get('required',[]))
  return 'matches!('+v+', RawValue::Array(items) if items.iter().all(|item| matches!(item, RawValue::Object(fields) if fields.iter().all(|(name, value)| '+match+')'+req+')))'
 raise ValueError(kind)
expected={}
for family,definition in subset.items():
 obj=next(iter(definition['patternProperties'].values()))
 for name,field in obj['properties'].items():expected[family,name]='blank(value) || '+expected_expression(field)
assert arms.keys()==expected.keys()
for key in expected:assert norm(arms[key])==norm(expected[key]),key
reqbody=body(grammar,grammar.index('match family',grammar.index('fn required_fields')))
reqarms={}
for arm in top_items(reqbody):
 pat,expression=arm.split('=>',1)
 if pat.strip()=='_':continue
 reqarms[json.loads(pat)]=re.findall(r'"((?:\\.|[^"\\])*)"',expression)
for family,definition in subset.items():assert reqarms[family]==next(iter(definition['patternProperties'].values())).get('required',[])
# Independently reconstruct the query shape and seven existing/new statistics
# definitions from Native legacy fields/default/automatic metadata.
query=after[U+'ordinary_input_processor/schema.rs'].decode();stats=after[H+'selected_input_processor/input_statistics/schema.rs'].decode()
stats_rows=[]
for family,definition in subset.items():
 legacy=definition['legacy_idd'];obj=next(iter(definition['patternProperties'].values()));props=obj['properties']
 shape=(len(legacy['alphas']['fields']),len(legacy['numerics']['fields']),len(legacy['alphas'].get('extensions',[])),len(legacy['numerics'].get('extensions',[])),legacy.get('extension'))
 pat=r'\(\s*'+re.escape(quoted(family))+r'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(None|Some\("[^"]+"\))\s*,?\s*\)'
 m=re.search(pat,query);assert m,family
 observed=tuple(map(int,m.groups()[:4]))+(None if m[5]=='None' else json.loads(m[5][5:-1]),);assert observed==shape,(family,shape,observed)
 block=body(stats,stats.index(quoted(family)+' => SchemaDefinition'))
 assert ('has_name: true' in block)==('name' in definition)
 name_default=definition.get('name',{}).get('default',None)
 assert ('name_has_default: true' in block)==('default' in definition.get('name',{}))
 fieldrows=re.findall(r'SchemaField\s*\{\s*name:\s*("(?:\\.|[^"\\])*")\s*,\s*default:\s*(SchemaDefault::(?:Absent|NonString|String\("(?:\\.|[^"\\])*"\)))\s*,\s*automatic:\s*&\[([^\]]*)\]\s*,?\s*\}',block,re.S)
 expfields=[]
 def field_expect(name,meta):
  default=('SchemaDefault::Absent' if 'default' not in meta else 'SchemaDefault::String('+quoted(meta['default'])+')' if isinstance(meta['default'],str) else 'SchemaDefault::NonString')
  automatic=[]
  for variant in meta.get('anyOf',[]):
   for token in variant.get('enum',[]):
    if token in ('Autosize','Autocalculate'):automatic.append('SchemaAutomatic::'+token)
  return name,default,automatic
 for name in legacy['fields']:expfields.append(field_expect(name,definition['name'] if name=='name' and 'name' in definition else props[name]))
 extension=legacy.get('extension')
 if extension:
  extension_props=props[extension]['items']['properties']
  for name in legacy.get('extensibles',[]):expfields.append(field_expect(name,extension_props[name]))
 observed=[(json.loads(n),d,re.findall(r'SchemaAutomatic::\w+',a)) for n,d,a in fieldrows]
 assert observed==expfields,(family,observed,expfields)
 assert norm('extension: '+('Some('+quoted(extension)+')' if extension else 'None')) in norm(block)
 stats_rows.append(dict(family=family,query_shape=shape,statistics_field_rows=len(expfields),exact_default_and_automatic_order=True))
# New public methods only retain/borrow immutable raw values and real positive
# counts. Native initialization readiness and getter bodies are not modified.
rawscope=json.loads(get(M['actual_B_frontier_and_raw_operands']).read_bytes());prior=json.loads(get(M['actual_B_prior_receipt']).read_bytes())
assert prior['exit_code']==6 and prior['launch_error'] is None and prior['source_bytes_match_before_and_after']
diagnostics=json.loads(get(M['actual_B_prior_diagnostics']).read_bytes());assert any(x['message']=='ordinary equipment excludes positive family NodeList' for x in diagnostics['diagnostics'])
assert rawscope['actual_counts']==dict(NodeList=1,controlled_zones=1,equipment_lists=1,Compact=2)
for v in M['Source_only_parses']:
 assert v['exit_code']==0
 for k in ('stdout','stderr'):get(v[k])
newlines='\n'.join('\n'.join(line[1:] for line in get(row['forward_diff']).read_text(encoding='utf8').splitlines() if line.startswith('+') and not line.startswith('+++')) for row in rows.values())
assert not re.search(r'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unreachable|unimplemented)!',newlines)
O.mkdir();parses=[]
for i,(name,row) in enumerate(rows.items(),1):
 v=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after[name],capture_output=True,cwd=R);assert v.returncode==0
 stdout=O/f'parse-{i}.stdout';stderr=O/f'parse-{i}.stderr';stdout.write_bytes(v.stdout);stderr.write_bytes(v.stderr)
 parses.append(dict(path=name,exit_code=0,stdout=ref(stdout),stderr=ref(stderr)))
report=dict(schema='src06-independent-full-bounded-B-raw-ingress-Source-peer.v1',accepted=True,findings=[],manifest=ref(MP),whole_Source_count=9,literal_applications=18,whole_Git_before_revision=M['base_HEAD'],whole_Git_existing_before_count=8,Git_absent_new_file_count=1,independent_Source_parses=parses,Native_revision=PIN,pinned_Native_wholes=8,in_memory_primary_parser_and_seven_transforms=calls,seven_whole_Native_schema_objects_exact_installed_and_packet=True,whole_recursive_raw_field_grammar_predicates_compared=len(expected),required_fields_exact=True,query_and_statistics_metadata=stats_rows,whole_None_and_SomeA_pipeline_inverse_equal=True,whole_legacy_scalar_projection_equal_except_empty_order_metadata=True,old_equipment_constructor_whole_preserved=True,new_lint_banned_calls=0,actual_prior_B_receipt=ref(get(M['actual_B_prior_receipt'])),actual_positive_counts_preserved=rawscope['actual_counts'],review=[
 'Only explicit SomeB chooses new raw ingress in two pipeline sites. None/A select existing admission and scalar statistics projection; all remaining pipeline bytes are whole preserved. No support-class relabel, legacy retry, schedule cache or getter bypass.',
 'Seven positive families pass typed field grammar derived from independently executed pinned Native schema producer. Required/extensible field names, enums, inclusive/exclusive bounds and numeric/automatic alternatives match all recursive Source predicates. Blank optional fields remain raw for later actual getters rather than producing values.',
 'The full raw Number token/Bool/String/null/array/object projection is exact and recursive on the existing sole SelectedIP statistics/raw owner. Original effective object order comes RawModel::ordered_instances; retain validates complete unique exact identity sets before storing. New accessors borrow retained raw data only.',
 'Source family inventory records actual positive counts with duplicate/clock checks; no node allocation or initialized equipment state is produced. Original zero-only constructor remains whole unchanged. Native GetZoneEquipment/NodeList/Compact/thermostat implementations are untouched.',
 'Three missing query and statistics definitions join four existing ones. Every seven-family query shape and ordered default/automatic field definition was independently reconstructed from whole Native schema and matched, including explicit Native defaults without materializing them in raw input.',
 'Current real ProcessScheduleInput reads positive Compact count2 and maxargs then returns the existing typed nonconstant boundary before later equipment/NodeList getters. This Source peer predicts that frontier only; Root must confirm it with fresh combined actual run.',
 'No new test body, tolerance/math/ready-flag change or dictionary I/O edit. Root owns combined application, all-target build, actual A24/B and promotion.'
 ],main_mutations=0,Cargo_Native_or_tests_executed=False,new_test_bodies=0,proposed_B_actual_executed=False,full_B_or_gate_claim=False,author_Source=ref(Path(__file__)))
p=O/'review.json';p.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

"""Prepare succinct finite checkpoint12 publication; no canonical/doc writes."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-B-IO-publication-prepared-Audit-12';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];r=ref(p);assert r['sha256']==v['sha256'] and r['bytes']==v.get('bytes',r['bytes']);return p
def load(p):return json.loads(p.read_bytes())
def accepted(p):
 v=load(p);assert v.get('accepted') is True and not v.get('findings',[]);return v
inputs={}
def add(p):
 r=ref(p);assert r['path']not in inputs or inputs[r['path']]==r;inputs[r['path']]=r
def addref(r):add(checked(r))
HEAD='1435b44537a920ded21ae732bdc7c81051df0282';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==HEAD
planp=D/'Root-combined-source-B-IO-tool-preflight-12/complete-compiler-plan.json';assert ref(planp)['sha256']=='4c6cbcd44d2180f3ea86379c16ed4fe994f79a0ab22af01dced9e3363b8737b0';plan=load(planp)
preflight=D/'Root-combined-source-B-IO-tool-preflight-12/review.json';assert ref(preflight)['sha256']=='c602b6089021db0f2acbc2340cd7c27aba7bcdd3f9978845a2c3f706040c96d1';accepted(preflight)
application=D/'Root-combined-source-B-IO-tool-application-12/receipt.json';app=load(application);assert app['status']=='applied' and app['plan']==ref(planp)
assert (len(plan['entries']),plan['after_Rust'],len(plan['selected']))==(4473,4460,12)
publisher=D/'publish-source-B-IO-reported-checkpoint-Audit-12-template.py';ast.parse(publisher.read_text(encoding='utf8'))
previous=R/'energyplus_porting_plan/evidence/SRC-06-canonical-completed-source-activation-11/summary.json';old=load(previous);assert (old['A'],old['B'])==('14/54','14/64')
prior=[D/'canonical-source82-A-72H-tolerance-Root-12/comparison.json',D/'canonical-source82-A-ANNUAL-tolerance-Root-12/comparison.json']
for p,h,n in zip(prior,['df345237096da07face1f70bf7657bd4602619fb131107ce499d17eab185fe27','b6f7457fbd13057bd9a65d701d793ebc0b7d778ed283ddc26d28796ae3201ce0'],[16056,1953480]):
 assert ref(p)['sha256']==h;c=accepted(p);assert c['totals']['samples']==n and c['totals']['series']==58 and c['totals']['passed'] and c['totals']['tolerance_failures']==c['totals']['rmse_failures']==0
control=D/'public-comparer-A-72H-control-Root-12/comparison.json';assert ref(control)['sha256']=='b7db0caa956fb0d88cf28722cf96a06842d2122e0086d7c6531b5761f86f2304';accepted(control)
toolpacket=D/'public-completed-reported-comparator-held-Outer-01/manifest.json';tool=load(toolpacket);public=checked(tool['proposed']);private=checked(tool['immutable_parent']);a=public.read_text(encoding='utf8');b=private.read_text(encoding='utf8')
functions=lambda s:{n.name:ast.get_source_segment(s,n)for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name!='main'}
assert functions(a)==functions(b);inverse=a
for x in reversed(tool['exact_substitutions']):assert inverse.count(x['after'])==1;inverse=inverse.replace(x['after'],x['before'],1)
assert inverse==b
c1,c2=load(prior[0]),load(control)
for c in [c1,c2]:
 for k in ['author_Source','all_uncapped_tolerance_failures','preceding_operational_contract','public_operational_checkpoint']:c.pop(k,None)
assert c1==c2
for p in [Path(__file__),publisher,planp,preflight,application,previous,toolpacket,*prior,control]:add(p)
for r in app['accepted_peers']:
 addref(r);v=accepted(checked(r))
 if 'author_Source'in v:addref(v['author_Source'])
for r in plan['packets']:
 addref(r);v=load(checked(r))
 if 'author_Source'in v:addref(v['author_Source'])
 if 'schema_authority'in v:
  addref(v['schema_authority']);authority=load(checked(v['schema_authority']));addref(authority['seven_whole_native_objects'])
  for x in authority['pinned_whole_sources']:addref(x['whole_native'])
 if 'actual_B_frontier_and_raw_operands'in v:addref(v['actual_B_frontier_and_raw_operands'])
 if 'files'in v:
  for x in v['files']:
   for k in ['before','proposed','forward_diff','inverse_diff']:addref(x[k])
 else:
  for k in ['proposed','immutable_parent','forward_diff','inverse_diff']:addref(v[k])
for p in prior+[control]:
 c=load(p)
 for k in ['policy','case_scope','case_metadata','Source_receipt','Native_receipt','Source_summary','all_uncapped_tolerance_failures','author_Source']:addref(c[k])
 for x in c['type_authorities']:addref(x)
for n,x in plan['selected'].items():assert (R/n).read_bytes()==checked(x['proposed']).read_bytes()
transfer=D/'Peer-canonical-B-ingress-IO-A24-transfer-03/review.json';assert ref(transfer)['sha256']=='6bfe7736ea81fc1123ebc4ee11c64e9de64d123f3e3a92e49636f13cd9dc4dca';accepted(transfer)
root=D/'Root-source-B-raw-ingress-actual-frontier-12/review.json';assert ref(root)['sha256']=='f3cdd4c85f4a0557fb3e94690edb410e04b6800533d48df1b4118ea75b6817af';accepted(root)
O.mkdir()
def put(n,v):
 p=O/n;p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
algorithm=put('public-algorithm-propagation.json',dict(schema='src06-public-comparer-exact-algorithm-propagation.v1',private_Source=ref(private),public_Source=ref(public),public_manifest=ref(toolpacket),all_nonmain_functions_and_classes_whole_equal=True,all_six_public_metadata_path_substitutions_whole_inverse=True,A72_private=ref(prior[0]),A72_public_control=ref(control),whole_A72_report_equal_except_four_explicit_reference_fields=True,prior_annual=ref(prior[1]),annual_rerun=False,algorithm_or_numeric_policy_changes=False,scope='Exact algorithm/original policy propagates the already completed annual comparison; no new annual simulation, JSON load, scan or combined12 duration execution.'))
inputs[algorithm['path']]=algorithm
summary=dict(status='HELD publication template; actual combined proofs required at publication',base_HEAD=HEAD,Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',combined_plan=ref(planp),combined_preflight_review=ref(preflight),applied_custody=ref(application),accepted_Source_peers=app['accepted_peers'],changed_Rust_files=11,new_Rust_files=1,existing_Rust_files=10,new_public_tools=1,compiler_inputs=4473,Rust_sources=4460,literal_applications=24,
 raw_B='SomeB Native field grammar retains raw values, extension fields, original effective object order and positive counts on the same InputProcessor raw owner. Three missing query/default-statistics definitions use pinned IDD/parser metadata. No typed NodeID/cache/ready-state substitution.',
 dictionary_IO='RDD/MDD and general outputs share Native text expansion at each reached write. Windows LF becomes CRLF, existing CR remains; logical lengths and failure behavior preserved. No whole-file rewrite or numeric change.',
 public_comparer='tools/porting/check_completed_reported_streams.py streams physical ESO/MTR with exact identity/dictionary/StoreType/frequency/native tuple order/footer/counters and unchanged original named atol/rtol/per-series RMSE. Public promotion changes six metadata/path references only.',public_algorithm_propagation=algorithm,public_A72_control=ref(control),prior_A_case_comparison_refs=[ref(p)for p in prior],prior_A_case_compiled_scope='A72/annual ran canonical11 Source before combined12 rawB/IO changes. Current A24 transfer is separate; no new combined12 A72/annual duration execution is inferred.',prior_case_metrics=[dict(case=load(p)['case'],**load(p)['totals'])for p in prior],canonical_A24_completed_Source_run=None,canonical_A24_dictionary_write_and5352_proof_transfer=None,actual_B_incomplete_boundary=None,actual_B_completed=False,
 original_policy=old['original_tolerance_policy'],policy_metadata_notes=old['policy_metadata_notes'],numeric_scope='Physical reported decimal operands, original per-row tolerances and sequential per-series RMSE. Existing numerical differences remain. No unit conversion, relaxed policy, reconstructed history, internal binary64 identity or whole conformance claim.',previous_checkpoint=ref(previous),A='14/54',B='14/64',gate_changes=False,full15matrix_complete=False,new_test_bodies=0,full_suite_rerun=False,annual_numeric_comparison_rerun=False,annual_JSON_CSV_copied=False,
 remaining=['Genuine Source Compact detailed/day/week/year constructors/getters before constant insertion; then positive zone equipment/NodeList/PurchasedAir owners.','Remaining B cases/durations and all required card/unit/integration/production gates.','Strict optional Source oracle dispatch; no compatibility fallback or false comparison PASS.'],evidence_scope='Finite changed Source/custody, direct reviews/receipts, actual A24 transfer, prior A72/annual physical ESO/MTR on both sides with dictionaries/all metrics/zero-failure ledgers. No historical ZIP recursion or annual JSON/CSV.')
template=put('publication-template.json',dict(schema='src06-held-canonical12-publication-template.v1',status='HELD_NO_NEW_COMBINED_ACTUAL_CLAIMS',base_HEAD=HEAD,combined_plan=ref(planp),combined_preflight_review=ref(preflight),application=ref(application),previous_checkpoint=ref(previous),original_policy=old['original_tolerance_policy'],prior_A_case_comparisons=[ref(p)for p in prior],public_A72_control=ref(control),public_algorithm_propagation=algorithm,publisher_Source=ref(publisher),finite_archive_inputs=[r for n,r in sorted(inputs.items())],summary_template=summary,targets=['energyplus_porting_plan/evidence/SRC-06-canonical-B-ingress-IO-reported-cases-12/summary.json','energyplus_porting_plan/evidence/SRC-06-canonical-B-ingress-IO-reported-cases-12/manifest.json','energyplus_porting_plan/evidence/SRC-06-canonical-B-ingress-IO-reported-cases-12/evidence.zip'],append_existing_docs=['energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/cards/SRC-06.md'],plan_add_only='tasks[SRC-06].canonical_B_ingress_IO_reported_cases_12',finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(r['bytes']for r in inputs.values()),publisher_executed=False,canonical_docs_mutations=0,Cargo_tests_Native_or_numeric_comparison_executed=False,gate_changes=False,author_Source=ref(Path(__file__))))
validation=put('validation-refs.json',dict(combined_transfer_review=ref(transfer),Root_actual_frontier_review=ref(root)))
print(json.dumps(dict(template=template,validation=validation,publisher=ref(publisher))))

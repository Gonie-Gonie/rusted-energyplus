"""Root-only finite checkpoint12 publisher; requires real combined actual proofs.

No Cargo, tests, Native simulation, annual JSON/CSV load or comparison rerun.
No publication is attempted without --publish and exact supplied accepted refs.
"""
from pathlib import Path
import argparse,ast,hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
READY=D/'source-B-IO-publication-prepared-Audit-12'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-B-ingress-IO-reported-cases-12'
BACK=D/'source-B-IO-publication-readback-Audit-12'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(p):
 p=p.resolve();return dict(path=p.relative_to(R.resolve()).as_posix(),sha256=digest(p),bytes=p.stat().st_size)
def checked(v,base=R):
 p=(base/v['path']).resolve();p.relative_to(R.resolve());assert digest(p)==v['sha256'] and p.stat().st_size==v.get('bytes',v.get('size_bytes',p.stat().st_size)),v['path'];return p
def load(p):return json.loads(p.read_bytes())
def accepted(p):
 v=load(p);assert v.get('accepted') is True and not v.get('findings',[]),p;return v
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def paths():
 q=subprocess.run(['rg','--files','--hidden','--no-ignore','-g','*.rs','-g','Cargo.toml','crates'],cwd=R,capture_output=True,check=True)
 return {x.replace('\\','/') for x in q.stdout.decode().splitlines()}|{n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (R/n).is_file()}
def main(args):
 assert args.publish and not PUBLIC.exists() and not BACK.exists()
 dp=READY/'publication-template.json';draft=load(dp);assert draft['status']=='HELD_NO_NEW_COMBINED_ACTUAL_CLAIMS'
 planp=checked(draft['combined_plan']);assert digest(planp)=='4c6cbcd44d2180f3ea86379c16ed4fe994f79a0ab22af01dced9e3363b8737b0';plan=load(planp)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert head==draft['base_HEAD']==plan['base_HEAD']
 vp=(R/args.validation_refs).resolve();vp.relative_to(R.resolve());v=load(vp);assert set(v)=={'combined_transfer_review','Root_actual_frontier_review'}
 tp=checked(v['combined_transfer_review']);t=accepted(tp);rp=checked(v['Root_actual_frontier_review']);root=accepted(rp)
 assert t['combined_plan']==ref(planp) and t['accepted_combined_review']==draft['combined_preflight_review']
 assert t['all4473_compiled_archived_live_planned_inputs_exact'] is True and t['Rust_sources']==4460
 assert t['selected_canonical_Rust_files']==11 and t['all11_Rust_plus_one_public_tool_proposals_exact'] is True
 assert t['diagnostic_child_absent'] and t['legacy_results_and_diagnostic_artifacts_absent']
 assert (t['transferred_JSON_CSV_scalar_roundtrips'],t['transferred_reported_series'],t['table_lines'],t['exact_Native_table_lines'],t['Native_table_metadata_difference_lines'])==(5352,58,19312,19242,70)
 assert root['actual_B_receipt']==t['actual_first_B_CLI'] and root['check']==t['actual_check']
 assert root['diagnostics']==t['actual_first_B_diagnostics'] and root['summary']==t['actual_first_B_summary']
 assert root['positive_counts_not_substituted'] and root['real_Compact_objects']==2 and root['Source_or_Legacy_completed_results_absent']
 receipts=[load(checked(t[k])) for k in ['actual_check','actual_first_B_CLI','actual_A24_CLI']]
 assert [x['exit_code'] for x in receipts]==[0,6,0]
 for x in receipts:assert x['launch_error'] is None and x['source_bytes_match_before_and_after'] and Path(x['cwd']).resolve()==R.resolve()
 assert receipts[0]['source_snapshot']==receipts[1]['source_snapshot']==receipts[2]['source_snapshot']
 assert '--all-targets' in receipts[0]['command'] and '--workspace' in receipts[0]['command']
 for x,scope in zip(receipts[1:],['B','A']):
  c=x['command'];assert c[c.index('--porting-scope')+1]==scope and not {'--oracle-baseline','--compare-oracle'}&set(c)
 first_B=load(checked(t['actual_first_B_summary']));bd=load(checked(t['actual_first_B_diagnostics']))
 errors=[x['message'] for x in bd['diagnostics'] if x['code']=='RuntimeConvergenceFailure'];assert len(errors)==1 and 'nonconstant schedule input' in errors[0]
 assert root['current_actual_error']['message']==errors[0]
 assert first_B['exit_code']==6 and first_B['rust_runtime'] is None
 assert len(t['first_B_all_three_core_compiler_artifacts_fresh_false'])==len(t['A24_all_three_same_core_artifacts_reused_fresh_true'])==3
 assert all(x['fresh'] is False for x in t['first_B_all_three_core_compiler_artifacts_fresh_false'])
 assert all(x['fresh'] is True for x in t['A24_all_three_same_core_artifacts_reused_fresh_true'])
 idx={x['path']:x for x in plan['entries']};assert len(idx)==4473 and plan['after_Rust']==4460 and paths()==set(idx)
 snapshot=load(checked(receipts[0]['source_snapshot'],R));observed={x['historical_path']:x for x in snapshot['files']};assert set(observed)==set(idx)
 for n,x in idx.items():
  p=R/n;assert digest(p)==x['after_sha256'] and p.stat().st_size==x['after_bytes']
  assert digest(checked(observed[n]['archive']))==x['after_sha256']
 selected=plan['selected'];assert len(selected)==12 and sum(n.endswith('.rs')for n in selected)==11
 for n,x in selected.items():assert (R/n).read_bytes()==checked(x['proposed']).read_bytes()
 assert not(R/'crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs').exists()
 prior=load(checked(draft['previous_checkpoint']));assert (prior['A'],prior['B'])==('14/54','14/64')
 policy=draft['original_policy'];assert t['unchanged_original_tolerance_policy']==policy
 numeric=[]
 for r,count in zip(draft['prior_A_case_comparisons'],[16056,1953480]):
  c=accepted(checked(r));assert c['totals']['series']==58 and c['totals']['samples']==count
  assert c['totals']['passed'] and c['totals']['tolerance_failures']==c['totals']['rmse_failures']==0 and c['policy_changes']==0 and c['gate_changes']==0 and c['policy']==policy
  numeric.append(dict(case=c['case'],comparison=r,reported_series=58,reported_samples=count,metrics=c['totals'],Source_receipt=c['Source_receipt'],Native_receipt=c['Native_receipt'],scope='Prior compiled canonical11 Source snapshot only; no new duration run or transfer through changed combined12 B/IO path is inferred'))
 control=accepted(checked(draft['public_A72_control']));original=load(checked(draft['prior_A_case_comparisons'][0]))
 for c in [control,original]:
  for k in ['author_Source','all_uncapped_tolerance_failures','preceding_operational_contract','public_operational_checkpoint']:c.pop(k,None)
 assert control==original
 base=R/'energyplus_porting_plan';names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md'];docs={n:(base/n).read_bytes()for n in names};planfile=base/'plan.json';before=planfile.read_bytes();beforev=json.loads(before)
 for n,b in docs.items():assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R) and '\ufffd' not in b.decode('utf8','strict')
 assert before==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
 files={}
 def add(p):
  p=p.resolve();r=ref(p);n=r['path'];assert n not in files or files[n]['ref']==r;files[n]=dict(path=p,ref=r)
 def addref(r):add(checked(r))
 for r in draft['finite_archive_inputs']:addref(r)
 for p in [Path(__file__),dp,vp,tp,rp]:add(p)
 for k in ['actual_check','actual_first_B_CLI','actual_A24_CLI','actual_first_B_summary','actual_first_B_diagnostics','run_summary','diagnostics','reported_bundle','all_table_metadata_differences','author_Source']:addref(t[k])
 for x in receipts:
  for k in ['stdout','stderr','source_snapshot']:add(checked(x[k],Path(x['cwd'])))
 for x in t['physical_streams_whole_canonical11_equal']:addref(x['current'])
 for x in t['dictionaries']:
  for k in ['current','Native']:addref(x[k])
 for x in t['CSV_files_whole_canonical11_equal']:addref(x['current'])
 for x in t['full_tables']:addref(x['actual'])
 # Both real physical report streams, dictionaries, original policies and
 # complete per-series/zero-failure ledgers suffice for numeric recomputation.
 # Annual Source JSON/CSV and historical ZIP ancestry are never copied/loaded.
 for comparison in draft['prior_A_case_comparisons']+[draft['public_A72_control']]:
  c=load(checked(comparison));addref(comparison)
  for k in ['Source_receipt','Native_receipt','Source_summary','all_uncapped_tolerance_failures','case_metadata','case_scope','author_Source']:addref(c[k])
  for k in ['Source_receipt','Native_receipt']:
   x=load(checked(c[k]))
   for key in ['stdout','stderr','source_snapshot']:add(checked(x[key],Path(x['cwd'])))
  for x in c['type_authorities']:addref(x)
  for x in c['streams']:
   for key in ['Source','Native']:
    if x[key] is not None:addref(x[key])
 for n in selected:add(R/n)
 PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(before)
 for n,b in docs.items():p=BACK/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 zp=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for n,r in sorted(files.items()):assert ref(r['path'])==r['ref'];z.write(r['path'],arcname=n)
 with zipfile.ZipFile(zp)as z:
  assert z.testzip() is None and set(z.namelist())==set(files)
  for n,r in files.items():
   h=hashlib.sha256();total=0
   with z.open(n)as f:
    for b in iter(lambda:f.read(1048576),b''):h.update(b);total+=len(b)
   assert h.hexdigest()==r['ref']['sha256'] and total==r['ref']['bytes']
 inventory=PUBLIC/'manifest.json';inventory.write_bytes((json.dumps(dict(schema='src06-canonical12-finite-evidence-archive.v1',archive=ref(zp),entries=[x['ref']for n,x in sorted(files.items())],scope='Changed11 Rust and one public tool bodies/custody, direct reviews, actual combined check/B/A24 receipts and transfer, prior canonical11 A72/annual physical ESO/MTR on both sides with type dictionaries and complete numeric metrics. No annual JSON/CSV or recursive historical ZIP copies.',full_transitive_rebuild_archive_claim=False),indent=2)+'\n').encode())
 summary=dict(draft['summary_template']);summary.update(schema='src06-canonical-B-ingress-IO-reported-cases.v1',status='Actual SourceB advances through raw ingress to real Compact getter boundary; combined A24 result transfer and dictionary writes verified',canonical_check=t['actual_check'],canonical_A24_CLI=t['actual_A24_CLI'],canonical_first_B_CLI=t['actual_first_B_CLI'],canonical_A24_IO_transfer_review=ref(tp),Root_actual_frontier_review=ref(rp),actual_B_incomplete_boundary=errors[0],actual_B_completed=False,canonical_A24_completed_Source_run=True,canonical_A24_dictionary_write_and5352_proof_transfer=True,prior_A72_annual_reported_comparisons=numeric,validation_refs=ref(vp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),author_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json';sp.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 text=('B 입력의 실제 값·확장 필드·선언 순서·양수 개수를 같은 InputProcessor에 보존하고, 실제 초기화의 Schedule:Compact 미구현 경계까지 진행했습니다. B 실행은 exit6으로 명시적으로 중단하며 완료 처리하지 않습니다. '
 'RDD/MDD는 원래 출력 시점에 Native와 같은 Windows 줄바꿈을 사용합니다. 같은 새 코어의 A-24H는 종료·내보내기에 성공했고 5,352개 값의 기존 전체 증명과 일치합니다. '
 '이전 Source11의 A-72H 16,056개·연간 1,953,480개 보고값은 원래 허용오차·계열별 RMSE 실패가 모두 0입니다. 공개 스트림 비교 도구는 같은 알고리즘을 유지하며 A-72H 대조로 확인했습니다. 연간 비교는 반복하지 않았습니다. '
 '숫자 차이와 정책 메타데이터의 기존 한계를 보존하며, 내부 비트 동일성·B 및 전체 15사례·카드 게이트 완료를 주장하지 않습니다. A14/54·B14/64는 유지합니다.')
 rel='evidence/SRC-06-canonical-B-ingress-IO-reported-cases-12/summary.json'
 for n,b in docs.items():
  p=base/n;assert p.read_bytes()==b;link='../'+rel if n.startswith('cards/')else rel;p.write_bytes(b+('\n\n[Source B 입력·출력 형식·보고값 비교 검증]('+link+'). '+text+'\n').encode())
 after=json.loads(before);task=next(x for x in after['tasks']if x['id']=='SRC-06');key='canonical_B_ingress_IO_reported_cases_12';assert key not in task;task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=digest(sp),size_bytes=sp.stat().st_size)
 inverse=json.loads(json.dumps(after));del next(x for x in inverse['tasks']if x['id']=='SRC-06')[key];assert inverse==beforev and planfile.read_bytes()==before;planfile.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_INDEPENDENT_READBACK',summary=ref(sp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),Git_mutated=False,Cargo_tests_Native_executed=False,gate_changes=False)
 p=BACK/'publication-readback.json';p.write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--validation-refs',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

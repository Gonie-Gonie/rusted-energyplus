from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-purchased-air-calculation-B-NOLIMIT-24H-command-Root-27/receipt.json','041c8c70ba7437ef62e7dfad8dbe51ce4e79c641d52396084cf275e342064907'),
 'A24':('canonical-source-purchased-air-calculation-A-24H-command-Root-27/receipt.json','b824155c7ff3dcef82b9ed63bcaddfd5e16090656632a3a74778882dd3d6c8b5'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-zone-equipment-output-'+case+'-command-Root-28'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-zone-equipment-output-'+case+'-Root-28/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

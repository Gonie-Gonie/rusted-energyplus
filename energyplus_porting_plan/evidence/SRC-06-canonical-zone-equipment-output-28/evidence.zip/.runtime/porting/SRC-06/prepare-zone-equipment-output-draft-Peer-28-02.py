"""Isolated Source28 draft only. Root owns canonical application, Cargo and actuals."""
import ast,difflib,hashlib,json,re,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OUT=D/'source-zone-equipment-output-draft-Peer-28-02'
BASE='d8fc400e4371114a98ed55fa4306aff01509c1ed'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def auth(r):
 p=R/r['path'];g=ref(p);assert g['sha256']==r['sha256'] and g['bytes']==r.get('bytes',g['bytes']);return p
def save(name,b):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
PFX='crates/ep_runtime/src/heat_balance/'
MAN=PFX+'ordinary_equipment/management.rs';REQ=PFX+'ordinary_equipment/management/output_required.rs';AVAIL=PFX+'ordinary_equipment/management/availability.rs'
parent_path=D/'source-purchased-air-calculation-held-Audit-27/manifest.json';parent=json.loads(parent_path.read_bytes());parent_rows={r['canonical_path']:r for r in parent['files']}
assert parent['compiler_inputs']==4502 and parent['Rust_sources']==4489
before={}
for name in [MAN,REQ,AVAIL]:
 b=subprocess.run(['git','show',BASE+':'+name],cwd=R,capture_output=True,check=True).stdout
 assert b==(R/name).read_bytes(),name
 if name in parent_rows:assert b==auth(parent_rows[name]['proposed']).read_bytes()
 before[name]=b
proposed={}
s=before[MAN].decode()
assert s.count('let mut _first_call = true;')==1
s=s.replace('let mut _first_call = true;','let mut _first_call = true;\n        let mut error_flag = false;')
s=s.replace('        let _error_flag = false;\n','')
s=s.replace('                let _non_air_system_output = 0.0;','                let non_air_system_output = 0.0;')
anchor='''                let list = o.equipment.equipment_lists.as_ref()
                    .and_then(|rows| rows.get(at(o.sizing.current_zone_equipment_number).ok()?))'''
assert s.count(anchor)==1
s=s.replace(anchor,'''                let current_equipment_zone = o.sizing.current_zone_equipment_number;
                let list = o.equipment.equipment_lists.as_ref()
                    .and_then(|rows| rows.get(at(current_equipment_zone).ok()?))''')
anchor='''                        let current_equipment_zone = o.sizing.current_zone_equipment_number;
'''
assert s.count(anchor)==1;s=s.replace(anchor,'')
anchor='''                    // Genuine positive cached CompIndex enters this call on later
                    // iterations; no perpetual first-call/zero-count shortcut.
                    return Err(Error::Unavailable("actual GetZoneEqAvailabilityManager3739"));'''
assert s.count(anchor)==1
s=s.replace(anchor,'''                    self.ancillary.availability.get_source_zone_equipment_availability(
                        equipment_type, component_number, o.input, &mut error_flag,
                    )?;
                    let type_index = equipment_type.checked_sub(1).and_then(|v|usize::try_from(v).ok())
                        .ok_or(Error::Unavailable("actual ZoneComp availability type ordinal3730"))?;
                    let status = self.ancillary.availability.zone_components.as_ref().and_then(|rows|rows.get(type_index))
                        .and_then(|row|row.managers.as_ref()).and_then(|rows|rows.get(at(component_number).ok()?))
                        .ok_or(Error::Unavailable("actual same ZoneCompAvailMgrs status3730"))?.status;
                    if status == 2 {
                        o.hvac.turn_fans_on = true;
                        o.hvac.turn_fans_off = false;
                    } else if status == 1 {
                        o.hvac.turn_fans_on = false;
                        o.hvac.turn_fans_off = true;
                    }''')
anchor='''                        // These are the actual returned sensible/moisture cells.
                        // The next Native Config/output-distribution body remains explicit.
                        return Err(Error::Unavailable("actual PurchasedAir post-callee output response4084"));
'''
assert s.count(anchor)==1;s=s.replace(anchor,'')
anchor='''                    _ => return Err(Error::Unavailable("actual SimZoneEquipment positive equipment callee switch3747")),
                }
'''
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''                {
                    let config = o.equipment.zone_config.as_mut().and_then(|rows|rows.get_mut(at(number).ok()?))
                        .ok_or(Error::Unavailable("actual post-component ZoneEquipConfig4084"))?;
                    config.zone_exhaust += o.hvac.unbalanced_exhaust_mass_flow + o.hvac.balanced_exhaust_mass_flow;
                    config.zone_exhaust_balanced += o.hvac.balanced_exhaust_mass_flow;
                    config.plenum_mass_flow += o.hvac.plenum_induced_mass_flow;
                }
                let scheme = o.equipment.equipment_lists.as_ref().and_then(|rows|rows.get(at(current_equipment_zone).ok()?))
                    .ok_or(Error::Unavailable("actual post-component same ZoneEquipList4091"))?.load_distribution_scheme;
                if first_hvac_iteration && scheme != 0 {
                    let capacity = native_capacity_integer(system_output_provided)?;
                    let list = o.equipment.equipment_lists.as_mut().and_then(|rows|rows.get_mut(at(current_equipment_zone).ok()?))
                        .ok_or(Error::Unavailable("actual post-component same mutable ZoneEquipList4093"))?;
                    let rows = if system_output_provided > 0.0 { &mut list.heating_capacities }
                        else { &mut list.cooling_capacities };
                    *rows.as_mut().and_then(|rows|rows.get_mut(at(equipment_pointer).ok()?))
                        .ok_or(Error::Unavailable("actual ZoneEquipList integer Capacity4093"))? = capacity;
                }
                let use_splitter = if o.space_controls.simulation && !o.globals.doing_sizing {
                    let splitter = o.equipment.equipment_lists.as_ref().and_then(|rows|rows.get(at(current_equipment_zone).ok()?))
                        .and_then(|list|list.equipment_splitter_indices.as_ref()).and_then(|rows|rows.get(at(equipment_pointer).ok()?))
                        .ok_or(Error::Unavailable("actual post-component zoneEquipSplitterIndex4101"))?;
                    *splitter > -1
                } else { false };
                if use_splitter {
                    return Err(Error::Unavailable("actual zoneEquipSplitter distributeOutput4102"));
                } else {
                    o.air.zones.as_mut().and_then(|rows|rows.get_mut(at(number).ok()?))
                        .ok_or(Error::Unavailable("actual post-component same zoneHeatBalance4105"))?.air.non_air_system_response += non_air_system_output;
                }
                output_required::update(o, number, system_output_provided, latent_output_provided,
                    i32::try_from(equipment_number).map_err(|_|Error::Unavailable("actual EquipTypeNum integer domain4114"))?)?;
                o.sizing.current_terminal_unit_sizing_number = 0;
''')
s+='''
// Native capacities are Array1D_int. Preserve the defined finite C++ assignment
// domain; Rust's saturating float cast is not a replacement for out-of-range UB.
fn native_capacity_integer(value: f64) -> Result<i32, Error> {
    let truncated = value.trunc();
    if !truncated.is_finite() || truncated < f64::from(i32::MIN) || truncated > f64::from(i32::MAX) {
        return Err(Error::Unavailable("actual ZoneEquipList capacity integer assignment domain4093"));
    }
    Ok(truncated as i32)
}
'''
proposed[MAN]=s.encode()
s=before[REQ].decode()
s=s.replace('//! Native ZoneEquipmentManager4195-4510, real retained demand/order path.','//! Native ZoneEquipmentManager4195-4510/4717-4908, real retained demand/order path.')
anchor="fn fraction(o: &SourceHvacOwners<'_, '_>, zone: i32, equipment: i32, heating: bool) -> Result<f64, Error> {\n    let row = list(o.equipment, zone)?;"
assert s.count(anchor)==1
s=s.replace(anchor,"fn fraction(owner: &OrdinaryEquipment, schedules: &crate::heat_balance::selected_schedule_manager::SelectedScheduleManager, zone: i32, equipment: i32, heating: bool) -> Result<f64, Error> {\n    let row = list(owner, zone)?;")
assert s.count('    o.schedules.source_current_schedule_value(schedule)')==1
s=s.replace('    o.schedules.source_current_schedule_value(schedule)','    schedules.source_current_schedule_value(schedule)')
assert s.count('fraction(o, zone, equipment, ')==2
s=s.replace('fraction(o, zone, equipment, ','fraction(o.equipment, o.schedules, zone, equipment, ')
s+=(OUT/'update.append.rs').read_text(encoding='utf-8')
proposed[REQ]=s.encode()
s=before[AVAIL].decode()
anchor='''    pub(crate) get_input_flag: bool,
''';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''    /// Actual independent SystemAvailabilityManagerData.hh584/588 cold cells.
    pub(crate) get_lists_input: bool,
    pub(crate) number_manager_lists: i32,
''')
anchor='''            get_input_flag: true,
''';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''            get_lists_input: true,
            number_manager_lists: 0,
''')
s+=(OUT/'availability.append.rs').read_text(encoding='utf-8')
proposed[AVAIL]=s.encode()

t=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[]
for i,name in enumerate([MAN,REQ,AVAIL],1):
 b=before[name];p=proposed[name];diffs={}
 for kind,a,z in [('forward',b,p),('inverse',p,b)]:
  delta=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),z.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name)).encode()
  assert ns['apply_literal'](a,delta)==z
  diffs[kind+'_diff']=save(f'diffs/{i:02}-{kind}.diff',delta)
 result=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=p,capture_output=True,cwd=R);assert result.returncode==0,(name,result.stderr)
 assert p.count(b'#[test]')==b.count(b'#[test]')
 files.append({'canonical_path':name,'before_absent':False,'before':save('before/'+name,b),'proposed':save('proposed/'+name,p),'literal_inverse':save('literal-inverse/'+name,b),**diffs,'Source_only_parse':{'exit_code':0,'stdout':save(f'parse/{i:02}.stdout',result.stdout),'stderr':save(f'parse/{i:02}.stderr',result.stderr)}})
# Current whole crates caller inventory uses the three proposals plus all committed27 Sources.
plan=json.loads(auth(parent['complete_final_compiler_Source_plan']).read_bytes());assert plan['inputs']==4502 and plan['Rust_sources']==4489
hits=[];rust=0
for row in plan['entries']:
 name=row['path']
 if not name.endswith('.rs'):continue
 rust+=1;text=proposed[name].decode() if name in proposed else auth(row['source']).read_text(encoding='utf-8')
 needles=['SourceAvailability {','get_source_zone_equipment_availability','output_required::update(','fn update(o:','fn fraction(','fraction(o.']
 terms=[x for x in needles if x in text]
 if terms:hits.append({'path':name,'terms':terms})
assert rust==4489 and {x['path'] for x in hits}==set(proposed)
manifest={'schema':'src06-unsealed-zone-equipment-output-draft.v1','status':'UNSEALED isolated coherent Source28; three old Sources only, no main/Cargo/tests',
 'base_HEAD':BASE,'parent27':ref(parent_path),'parent27_plan':parent['complete_final_compiler_Source_plan'],
 'read_only_plan':ref(D/'zone-equipment-output-closure-readonly-plan-Peer-28/plan.json'),'files':files,
 'existing_Source_files':3,'new_Source_files':0,'literal_applications':6,'Source_only_parses':3,
 'API_census':{'Rust_sources':rust,'all_crates_runtime_tests':True,'hits':hits},
 'scope':'Whole post-callee4084-4116 plus whole updateSystemOutputRequired4717-4908 and same-owner zero-list availability lifecycle1448-1512. Existing mass/leaving methods and suffix remain byte-exact; positive unrepresented children retain typed boundaries.',
 'qualifications':['The read-only plan predates actual27 and labels28 predicted; Root actual27 subsequently observed genuine post-callee4084 and authorized this draft.',
 'Source27 final returned system/moisture cells retained; native capacity int conversion supports defined finite truncation domain only, no f64 retyping/saturation.',
 'Source availability actual positive manager lists remain first allocation/lookup boundaries; no fictitious list or per-component manager rows.',
 'No Source28 actual/current run or fullB/all12 completion claimed.'],
 'new_tests':0,'main_Cargo_or_Native_mutations_or_execution':False,'author_Source':ref(Path(__file__))}
p=OUT/'draft.json';assert not p.exists();p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(ref(p)))

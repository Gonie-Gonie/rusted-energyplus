import argparse
import ast
import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
OUT = D / 'source-zone-equipment-output-held-Peer-28-02'

def ref(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def auth(r):
    p = R / r['path']
    assert ref(p)['sha256'] == r['sha256'], r
    if 'bytes' in r:
        assert p.stat().st_size == r['bytes'], r
    return p

def load(path, sha):
    p = R / path
    assert ref(p)['sha256'] == sha
    return p, json.loads(p.read_bytes())

def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], check=True, capture_output=True).stdout

def save(name, b):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_bytes(b)
    return ref(p)

def dump(name, obj):
    return save(name, (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())

a = argparse.ArgumentParser()
a.add_argument('--base-head', required=True)
a = a.parse_args()
assert a.base_head == 'd8fc400e4371114a98ed55fa4306aff01509c1ed'
assert git(R, 'rev-parse', 'HEAD').decode().strip() == a.base_head
assert git(R, 'rev-parse', 'origin/main').decode().strip() == a.base_head
assert not git(R, 'status', '--porcelain=v1', '-uno').strip()
assert not OUT.exists()

dp, draft = load('.runtime/porting/SRC-06/source-zone-equipment-output-draft-Peer-28-02/draft.json', '55c5f752d9b30c564c8ec1c660fe9b211638c649812dbf42cfdc0972f68f688b')
pp, peer = load('.runtime/porting/SRC-06/Outer-zone-equipment-output-Source-review-28-02/review.json', '9e432e32ed560e4e798e92afc2e196c6758ea551dd599dc0f37d4467983a2f88')
assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet'] == ref(dp)
parent_path = auth(draft['parent27'])
parent = json.loads(parent_path.read_bytes())
ap, actual = load('.runtime/porting/SRC-06/Root-source-purchased-air-calculation-actual-review-27/review.json', 'ff63b47b136a03ef71025e46bb3d2eea8580d296fcd21bfc00e977563b4ae2b9')
assert actual['accepted'] and not actual['findings'] and actual['producer'] == ref(parent_path)
assert actual['B_frontier'] == 'GetHeatBalanceInput: actual PurchasedAir post-callee output response4084'
plan_path = auth(actual['complete_compiler_plan'])
assert ref(plan_path) == draft['parent27_plan']
plan = json.loads(plan_path.read_bytes())
assert plan['inputs'] == 4502 and plan['Rust_sources'] == 4489
receipts = {}
for label, key, code in [('B-NOLIMIT-24H', 'actual_B', 6), ('A-24H', 'actual_A24', 0)]:
    p = auth(actual[key])
    receipt = json.loads(p.read_bytes())
    assert receipt['exit_code'] == code and receipt['source_bytes_match_before_and_after']
    receipts[label] = {'receipt': ref(p), 'exit_code': code, 'snapshot': receipt['source_snapshot']}
assert receipts['B-NOLIMIT-24H']['snapshot'] == receipts['A-24H']['snapshot']
snapshot_path = auth(receipts['B-NOLIMIT-24H']['snapshot'])
snapshot = json.loads(snapshot_path.read_bytes())
assert len(snapshot['files']) == 4502
archives = {x['historical_path']: x['archive'] for x in snapshot['files']}
entries = {x['path']: copy.deepcopy(x) for x in plan['entries']}
assert len(entries) == 4502 and set(entries) == set(archives)
readback = []
for name, entry in entries.items():
    b = auth(archives[name]).read_bytes()
    assert b == auth(entry['source']).read_bytes() == (R / name).read_bytes(), name
    assert hashlib.sha256(b).hexdigest() == entry['final_sha256'] and len(b) == entry['final_bytes'], name
    readback.append({'path': name, 'actual_archive': archives[name], 'actual_sha256': entry['final_sha256'], 'actual_bytes': len(b), 'whole_live_equal_actual_and_plan': True})

t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
f = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[f], type_ignores=[]), '<literal>', 'exec'), ns)
files = []
logical = {}
peer_rows = {x['canonical_path']: x for x in peer['files']}
for i, row in enumerate(draft['files'], 1):
    name = row['canonical_path']
    assert not row['before_absent']
    before = auth(row['before']).read_bytes()
    new = auth(row['proposed']).read_bytes()
    assert before == auth(archives[name]).read_bytes() == (R / name).read_bytes() == git(R, 'show', a.base_head + ':' + name), name
    assert row['proposed'] == peer_rows[name]['proposed']
    assert ns['apply_literal'](before, auth(row['forward_diff']).read_bytes()) == new
    assert ns['apply_literal'](new, auth(row['inverse_diff']).read_bytes()) == before
    assert auth(row['literal_inverse']).read_bytes() == before
    parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parse.returncode == 0, (name, parse.stderr)
    proposed = save('proposed/' + name, new)
    files.append({'canonical_path': name, 'before_absent': False, 'before': save('before/' + name, before), 'actual_parent_archive': archives[name], 'proposed': proposed, 'literal_inverse': save('literal-inverse/' + name, before), 'forward_diff': save(f'diffs/{i:02}-forward.diff', auth(row['forward_diff']).read_bytes()), 'inverse_diff': save(f'diffs/{i:02}-inverse.diff', auth(row['inverse_diff']).read_bytes()), 'literal_origin_whole': row['proposed'], 'before_whole_Git_exact_at_base': True, 'Source_only_parse': {'exit_code': 0, 'stdout': save(f'parse/{i:02}.stdout', parse.stdout), 'stderr': save(f'parse/{i:02}.stderr', parse.stderr)}})
    logical[name] = new.decode()
    entries[name] = {'path': name, 'final_sha256': proposed['sha256'], 'final_bytes': proposed['bytes'], 'source': proposed, 'origin': 'Whole accepted Source28 draft02 proposal; no semantic rewrite'}
assert len(files) == 3 and len(entries) == 4502 and sum(x.endswith('.rs') for x in entries) == 4489
diag = 'crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs'
assert diag not in entries
for name in entries:
    if name.endswith('pipeline.json'):
        assert entries[name] == next(e for e in plan['entries'] if e['path'] == name)

terms = ['get_source_zone_equipment_availability', 'output_required::update(', 'SourceAvailability {', 'fn update(o:', 'fn fraction(', 'fraction(o.']
api = []
for name, entry in sorted(entries.items()):
    if not name.endswith('.rs'):
        continue
    text = logical.get(name)
    if text is None:
        text = auth(entry['source']).read_text(encoding='utf-8')
    found = [s for s in terms if s in text]
    if found:
        api.append({'path': name, 'terms': found})
assert {x['path']: set(x['terms']) for x in api} == {x['path']: set(x['terms']) for x in draft['API_census']['hits']}
assert {x['path'] for x in api} == {x['canonical_path'] for x in files}

native = []
for source in peer['Native_wholes']:
    name = source['Native_path']
    b = auth(source['whole']).read_bytes()
    assert b == git(N, 'show', PIN + ':' + name) == (N / name).read_bytes()
    lines = b.splitlines(keepends=True)
    extents = []
    for e in source['extents']:
        first, last = e['first'], e['last']
        value = b''.join(lines[first - 1:last])
        assert value == auth(e['source']).read_bytes()
        extents.append({'first': first, 'last': last, 'source': save('Native-extents/' + Path(name).name + f'.{first}-{last}.txt', value)})
    native.append({'Native_path': name, 'whole': save('Native/' + name, b), 'extents': extents, 'pinned_Git_exact': True})
assert len(native) == 5 and sum(len(x['extents']) for x in native) == 12
contexts = []
for c in peer['concrete_Source_contexts']:
    name = c['canonical_path']
    b = auth(c['whole']).read_bytes()
    assert b == auth(archives[name]).read_bytes() == (R / name).read_bytes() == git(R, 'show', a.base_head + ':' + name)
    contexts.append({'canonical_path': name, 'whole': c['whole'], 'actual_parent_archive': archives[name], 'current_and_Git_exact': True})
assert len(contexts) == 14
final_plan = dump('complete-final-compiler-Source-plan.json', {'schema': 'src06-complete-Source28-compiler-input-plan.v1', 'base_HEAD': a.base_head, 'actual27_parent_snapshot': ref(snapshot_path), 'prior_plan': ref(plan_path), 'inputs': 4502, 'Rust_sources': 4489, 'entries': [entries[x] for x in sorted(entries)], 'selected3_exact_draft02': True, 'quarantined_diagnostic_child_absent': True, 'Root_full_readback_required': True})
manifest = {'schema': 'src06-held-coherent-zone-equipment-output.v1', 'status': 'HELD Source28 on clean committed actual27; no Source28 runtime claim', 'base_HEAD': a.base_head, 'accepted27_actual_review': ref(ap), 'parent_producer': ref(parent_path), 'actual_parent_receipts': receipts, 'actual_parent_snapshot': ref(snapshot_path), 'prior_complete_compiler_Source_plan': ref(plan_path), 'complete_final_compiler_Source_plan': final_plan, 'compiler_inputs': 4502, 'Rust_sources': 4489, 'original_draft02': ref(dp), 'independent_full_semantic_peer': ref(pp), 'files': files, 'existing_Source_files': 3, 'new_Source_files': 0, 'selected_Source_files': 3, 'literal_applications': 6, 'Source_only_parses': 3, 'all3_proposals_whole_unchanged_from_reviewed_draft02': True, 'full4502_parent_readback': dump('actual27-parent-full-readback.json', readback), 'whole4489_Rust_API_census': dump('API-census.json', {'Rust_sources_examined': 4489, 'all_crates_runtime_tests_included': True, 'hits': api, 'new_tests': 0}), 'Native_commit': PIN, 'Native_authorities': native, 'concrete_same_owner_contexts': contexts, 'read_only_plan': draft['read_only_plan'], 'operation_order': {'postcaller': peer['postcaller_proof'], 'update': peer['update_proof'], 'availability': peer['availability_proof']}, 'scope': draft['scope'], 'draft01_to02_cleanup': peer['original01_to02'], 'remaining_scope': 'Existing controlled mass-balance/return/leaving and positive manager-list/Sizer/calculation callees retain honest boundaries. No fullB/all12, paired internal Native unit, positive Node reporting or new numerical equivalence claim.', 'validation_policy': 'Root owns actual production CLI B then A24 transfer. No new tests, repeated cohort, whole-suite, Cargo, Native or main changes by author.', 'new_test_bodies': 0, 'Cargo_main_tests_or_Native_mutations': False, 'author_Source': ref(Path(__file__))}
print(json.dumps(dump('manifest.json', manifest)))

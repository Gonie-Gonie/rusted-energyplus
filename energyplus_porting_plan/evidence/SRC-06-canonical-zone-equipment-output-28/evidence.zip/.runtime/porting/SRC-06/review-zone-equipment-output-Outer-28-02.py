"""Independent full Source28 update/availability semantic peer; no Cargo/main."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'Outer-zone-equipment-output-Source-review-28-02'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def load(r):return json.loads(checked(r))
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def main():
 assert not O.exists()
 pr=ref(D/'source-zone-equipment-output-draft-Peer-28-02/draft.json');m=load(pr)
 original_ref=ref(D/'source-zone-equipment-output-draft-Peer-28/draft.json');assert original_ref['sha256']=='655fe43cfbc83a7fd09ff0515a85bcf280929b0de74286195b1c2ff6a7995f13'
 original=load(original_ref)
 assert m['base_HEAD']=='d8fc400e4371114a98ed55fa4306aff01509c1ed'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==m['base_HEAD']
 parent=load(m['parent27']);plan=load(m['parent27_plan']);entries={r['path']:r for r in plan['entries']};assert len(entries)==4502
 assert m['parent27_plan']==parent['complete_final_compiler_Source_plan']
 assert len(m['files'])==3 and m['existing_Source_files']==3 and m['new_Source_files']==0 and m['new_tests']==0
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re}
 exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
 selected={};files=[]
 for i,r in enumerate(m['files'],1):
  path=r['canonical_path'];before=checked(r['before']);after=checked(r['proposed'])
  assert before==checked(r['literal_inverse'])==checked(entries[path]['source'])==(R/path).read_bytes()
  assert before==subprocess.check_output(['git','show',m['base_HEAD']+':'+path],cwd=R)
  assert ns['apply'](before,checked(r['forward_diff']))==after and ns['apply'](after,checked(r['inverse_diff']))==before
  added='\n'.join(x[1:] for x in checked(r['forward_diff']).decode('utf-8').splitlines() if x.startswith('+') and not x.startswith('+++'))
  assert not re.search(r'\.(unwrap|expect)\s*\(|\b(panic|todo|unimplemented|unreachable)!|#\[(test|ignore)',added)
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert parse.returncode==0
  files.append(dict(canonical_path=path,before=r['before'],proposed=r['proposed'],whole_before_Git_and_parent_exact=True,two_literal_applications_exact=True,
   fresh_Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',parse.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',parse.stderr))))
  selected[path]=after
 orig={r['canonical_path']:checked(r['proposed']) for r in original['files']}
 management='crates/ep_runtime/src/heat_balance/ordinary_equipment/management.rs'
 ob=orig[management].decode('utf-8');nb=selected[management].decode('utf-8')
 assert ob.count('        let _error_flag = false;\n')==1
 assert ob.replace('        let non_air_system_output = 0.0;\n','        let _non_air_system_output = 0.0;\n',1).replace('        let _error_flag = false;\n','',1)==nb
 for path in orig:
  if path!=management:assert orig[path]==selected[path]
 before=checked(m['files'][0]['before']);after=selected[management];marker=b'    fn calculate_source_zone_mass_balance('
 assert after[after.index(marker):].startswith(before[before.index(marker):])
 capacity=after[after.index(b'fn native_capacity_integer'):].decode('utf-8')
 assert 'let truncated = value.trunc();' in capacity
 assert '!truncated.is_finite() || truncated < f64::from(i32::MIN) || truncated > f64::from(i32::MAX)' in capacity
 assert 'Ok(truncated as i32)' in capacity
 readonly=load(m['read_only_plan']);native=readonly['Native_authorities']
 assert len(native)==5 and sum(len(r['extents']) for r in native)==12
 for r in native:
  raw=checked(r['whole']);assert raw==subprocess.check_output(['git','show',readonly['Native_commit']+':'+r['Native_path']],cwd=N)
  for e in r['extents']:assert checked(e['source'])==b''.join(raw.splitlines(keepends=True)[e['first']-1:e['last']])
 contexts=[]
 for r in readonly['Source_contexts']:
  raw=checked(r['whole']);assert raw==(R/r['canonical_path']).read_bytes()==checked(entries[r['canonical_path']]['source'])
  contexts.append(r)
 assert len(contexts)==14
 patterns=['SourceAvailability {','get_source_zone_equipment_availability','output_required::update(','fn update(o:','fn fraction(','fraction(o.']
 census=[];full=[];count=0
 for path,row in sorted(entries.items()):
  if not path.startswith('crates/') or not path.endswith('.rs'):continue
  raw=selected[path] if path in selected else checked(row['source']);count+=1
  text=raw.decode('utf-8');terms=[p for p in patterns if p in text]
  if terms:
   census.append(dict(path=path,terms=terms))
   full.append(dict(path=path,sha256=sha(raw),bytes=len(raw),hits=[dict(line=i,text=line) for i,line in enumerate(text.splitlines(),1) if any(p in line for p in terms)]))
 assert count==4489 and census==m['API_census']['hits'] and len(census)==3
 availability=next(v.decode('utf-8') for k,v in selected.items() if k.endswith('/availability.rs'))
 assert 'get_lists_input: true' in availability and 'number_manager_lists: 0' in availability
 result=dict(schema='src06-independent-Source28-zone-equipment-output-review.v1',accepted=True,findings=[],reviewed_packet=pr,
  original_draft=original_ref,original01_to02='Exactly two dead-local name/duplicate cleanups in management; both other proposed Sources whole-identical. No formulas/order/owner/API change.',
  scope='Full3 Source updateSystemOutputRequired4717-4908/post-component4084-4116 and same-owner no-list availability1448-1512 plus constructors/GetLists1219-1291.',
  files=files,literal_applications=6,fresh_Source_only_parses=3,Native_commit=readonly['Native_commit'],Native_wholes=native,
  Native_whole_count=5,strict_Native_extents=12,concrete_Source_contexts=contexts,
  full_crates_API_census=dict(Rust_sources=count,patterns=patterns,files=full),
  postcaller_proof=['Actual returned system/moisture cells remain live; exact Config ZoneExh += (Unbal+Balanced), ZoneExhBalanced and PlenumMassFlow updates precede capacity/distribution.',
   'FirstHVAC && nonSequential picks actual HeatingCapacity when sensible>0 else CoolingCapacity. Actual Native arrays are int. Truncate first, verify finite truncated i32 domain then cast; no f64 retyping, saturation, approximate clamp or implicit UB claim.',
   'Actual space/sizing/splitter predicate precedes unrepresented distributeOutput; else same zoneHB NonAirSystemResponse += actual reset component cell. Real update helper follows, then same CurTermUnitSizingNum=0; no arbitrary zero response.'],
  update_proof=['Native actual Zone.IsControlled chooses uncontrolled12 ordered subtract/copy writes, exact TempControlType0/1/2/3/4/default deadband semantics and optional priority+1/HeatingPriority+1/CoolingPriority+1 sequence writes with real equipment count.',
   'Controlled routine uses direct actual ZoneEquipList[ZoneNum]. Sequential subtracts all six unadjusted values; real nextPriority selects same PrioritySimOrder.EquipPtr. Exactly one actual heating OR cooling fraction schedule is evaluated according to TotalOutputRequired>=0, then six ratio*unadjusted writes and six ordered sequence writes.',
   'Sequential last-equipment/no-next branch copies all six unadjusted values and reevaluates exact +/-1W strict deadband tests; no tolerance/rounding changes.',
   'Uniform,UniformPLR,SequentialUniformPLR retain all sequenced and unadjusted values, copy only the next required total/heating/cooling values under the Native three separate conditions; no deadband reevaluation. Illegal scheme stops at actual fatal operation.',
   'Existing Init/Distribute function and initialize API preserved; only fraction helper borrow is narrowed to same Equipment/Schedules, preserving both old heating-before-cooling calls and original Total sign selection.'],
  availability_proof=['Same availability owner gains actual independent GetAvailListsInput ctortrue/NumAvailManagerLists ctor0 fields. No extra module, list cache or fabricated manager rows.',
   'GetLists first honors same original GetAvailMgrInputFlag and real getter then flagfalse; actual AssignmentList query writes real count. Positive count stops at genuine ListData.allocate; zero count returns, then caller clears independent GetListsInput only after success.',
   'Actual same type/component ordinal row and Input gate; Found local0 is Native initialization, positive list lookup is explicitly unrepresented. Missing-list first call Count0->1/Input remains true; second Count1->2/Input false; later Inputfalse performs no Count increment. Checked integer increment only excludes undefined overflow.',
   'NoAction/Start/Stop/manager-array writes of positive Found branch are not claimed. Real retained status is reread by management; only CycleOn2 and ForceOff1 write actual fan flags as Native3728-3735.'],
  downstream='Original full mass/leaving suffix bytes retained contiguously; one capacity conversion helper appended afterward. Existing initialize(o,zone,first) API remains available for Resilience29. No mass/leaving implementation or execution claim.',
  validation_pending='Final28 compiler-plan/base custody join and Root actual B/A remain required; no new tests or habitual alltargets. No full-B/numerical/all12 admitted-case completion claim.',
  main_Cargo_tests_Native_or_publication_mutations=False,author_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'review.json',(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))))
if __name__=='__main__':main()

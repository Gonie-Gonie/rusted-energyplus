from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-zone-equipment-output-application-28';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-zone-equipment-output-held-Peer-28-02/manifest.json');assert mr['sha256']=='c9ada9aed00f572069fd7d8848019bf3122ee588f189afabcfec6555624133ca';m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];assert pr['sha256']=='9e432e32ed560e4e798e92afc2e196c6758ea551dd599dc0f37d4467983a2f88';peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet']==m['original_draft02'];peerfiles={v['canonical_path']:v for v in peer['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='d8fc400e4371114a98ed55fa4306aff01509c1ed' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4502 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(f['literal_origin_whole'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==3 and len(new)==0 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==5 and extent_count==12
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==checked(v['actual_parent_archive'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted27_actual_review','parent_producer','prior_complete_compiler_Source_plan','full4502_parent_readback','whole4489_Rust_API_census','original_draft02','read_only_plan']:checked(m[k])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4502 and sum(n.endswith('.rs') for n in rows)==4489
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Full three existing Source corrected02 semantics and exact proposal wholes; Root independently authenticates committed27 parent and complete4502 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4502,final_inputs=4502,final_Rust_sources=4489,selected_Rust=3,new_Rust=0,literal_applications=6,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read all three Source diffs and Native post-callee4084-4116, full updateSystemOutputRequired4717-4908, GetZoneEqAvailability1448-1512, GetSysAvailManagerListInputs1219 prefix and independent constructor fields. Exact returned Sys/Moist cells feed three Config additions, actual integer Capacity defined truncated finite assignment, same NonAirSystemResponse and full genuine demand update. Six array/scalar updates and Native uncontrolled/Sequential/nonSequential distinctions, one live fraction chosen by Total sign, exact1W deadband predicates and priority indices preserved. Existing initialize distribution semantics retained by disjoint fraction helper signature. Same availability input/count/query and two-call no-list Input/Count lifecycle, no fabricated reset status. Corrected02 changes only dead local names; all numerical bytes reviewed. Positive manager/list, optional Space and downstream MassBalance/Leaving remain real boundaries. No new tests, DTO/cache, Native production answers, full12/fullB or internal paired equivalence claim. Actual B/A28 pending.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

"""Prepare, never execute, the minimal Source28 publication successor."""
import ast
import copy
import difflib
import hashlib
import json
import re
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
OLD = D / 'publish-purchased-air-calculation-checkpoint-Audit-27-02.py'
NEW = D / 'publish-zone-equipment-output-checkpoint-Peer-28.py'
OUT = D / 'zone-equipment-output-publication-prepared-Peer-28'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def checked(row):
    p = R / row['path']
    assert ref(p) == row
    return p

assert ref(OLD)['sha256'] == 'ba3b3181ce84dcd40ede4ce1ad363ac3b521c0c5c39e45614ade8240b579b87d'
assert not NEW.exists() and not OUT.exists()
source = OLD.read_text(encoding='utf-8')
body = source
def replace(before, after, count=1):
    global body
    assert body.count(before) == count, (before, body.count(before), count)
    body = body.replace(before, after)

replace('checkpoint27', 'checkpoint28', 3)
replace('purchased-air-calculation', 'zone-equipment-output', 8)
replace('Audit-27-02', 'Peer-28', 2)
replace('Root-27', 'Root-28', 2)
replace('SRC-06-canonical-zone-equipment-output-27', 'SRC-06-canonical-zone-equipment-output-28', 2)
replace("'815d809cf00a3f12dd8f71337f33af770d350dca'", "'d8fc400e4371114a98ed55fa4306aff01509c1ed'")
replace("producer['existing_Source_files'] == 2 and producer['new_Source_files'] == 1", "producer['existing_Source_files'] == 3 and producer['new_Source_files'] == 0")
replace('Root-source-zone-equipment-output-actual-review-27', 'Root-source-zone-equipment-output-actual-review-28')
for before, after in [
    ('whole_JSON_equal26_after_exactly_two_owned_path_field_bridges', 'whole_JSON_equal27_after_exactly_two_owned_path_field_bridges'),
    ('full_runtime_equal26_after_two_owned_path_bridges', 'full_runtime_equal27_after_two_owned_path_bridges'),
    ('accepted26_full5352_proof', 'accepted27_full5352_proof'),
    ('whole_physical_streams_equal26', 'whole_physical_streams_equal27'),
    ('whole_CSV_equal26', 'whole_CSV_equal27'),
    ('physical_files_whole_equal26', 'physical_files_whole_equal27'),
    ('CSV_files_whole_equal26', 'CSV_files_whole_equal27'),
    ('accepted26_proof', 'accepted27_proof'),
    ('Proof transfer from accepted26;', 'Proof transfer from accepted27;'),
]:
    replace(before, after)
start = body.index('    # The raw metadata test is inherited25 evidence;')
end = body.index("    assert actual['policy_changes']", start)
body = body[:start] + body[end:]
replace("    for key in ['original_application_receipt','original_application_author_Source']:\n        add(checked(application[key]))\n", '')
replace('src06-canonical27-finite-evidence-archive.v1', 'src06-canonical28-finite-evidence-archive.v1')
replace('3 coherent PurchasedAir Calc/Update/Report Sources, Native authority, accepted peer and actual B/A24. No checkpoint28 test execution; inherited25 RawModel test named separately. No historical ZIP recursion, annual JSON/CSV or transitive rebuild claim.', '3 coherent post-component output/demand/availability Sources, Native authority, accepted peer and actual B/A24. No checkpoint28 test execution. No historical ZIP recursion, annual JSON/CSV or transitive rebuild claim.')
replace("status='Genuine Source PurchasedAir Calc/Update/Report; B incomplete at actual frontier'", "status='Genuine Source zone-equipment output and demand update; B incomplete at actual frontier'")
replace("                   inherited25_raw_metadata_test=template['inherited25_raw_metadata_test'],\n                   inherited25_raw_test_is_not_checkpoint28_execution=True,\n", '')
replace('Source peer alone establishes neither positive PurchasedAir numerical Native state equivalence nor positive Node execution.', 'Source peer alone establishes neither internal numerical Native state equivalence nor positive Node execution.')
replace('Source IdealLoads 계산·갱신·보고 검증', 'Source 장비 출력·수요 갱신 검증')
replace("key='canonical_purchased_air_calculation_27'", "key='canonical_zone_equipment_output_28'")
ast.parse(body)
NEW.write_text(body, encoding='utf-8', newline='\n')
OUT.mkdir()

producer_path = D / 'source-zone-equipment-output-held-Peer-28-02/manifest.json'
assert ref(producer_path)['sha256'] == 'c9ada9aed00f572069fd7d8848019bf3122ee588f189afabcfec6555624133ca'
producer = json.loads(producer_path.read_bytes())
peer_path = checked(producer['independent_full_semantic_peer'])
peer = json.loads(peer_path.read_bytes())
assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet'] == producer['original_draft02']
previous = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-purchased-air-calculation-27/summary.json'
assert json.loads(previous.read_bytes())['A'] == '14/54'
finite = {}
def add(p):
    row = ref(p)
    assert p.suffix.lower() != '.zip'
    if row['path'] in finite:
        assert finite[row['path']] == row
    finite[row['path']] = row

for p in [producer_path, peer_path, checked(producer['complete_final_compiler_Source_plan']), checked(producer['full4502_parent_readback']), checked(producer['whole4489_Rust_API_census']), checked(producer['original_draft02']), checked(producer['author_Source']), checked(producer['accepted27_actual_review']), previous, OLD, NEW, Path(__file__)]:
    add(p)
add(checked(json.loads(checked(producer['original_draft02']).read_bytes())['author_Source']))
add(checked(peer['author_Source']))
for row in producer['files']:
    for key in ['before', 'proposed', 'literal_inverse', 'forward_diff', 'inverse_diff']:
        add(checked(row[key]))
    for key in ['stdout', 'stderr']:
        add(checked(row['Source_only_parse'][key]))
for row in producer['Native_authorities']:
    add(checked(row['whole']))
    for extent in row['extents']:
        add(checked(extent['source']))
for row in producer['concrete_same_owner_contexts']:
    add(checked(row['whole']))

template = {
    'schema': 'src06-held-canonical28-publication-template.v1',
    'status': 'HELD_FOR_ROOT_ACTUAL28_AND_FULL_READ',
    'base_HEAD': producer['base_HEAD'],
    'producer': ref(producer_path),
    'complete_plan': producer['complete_final_compiler_Source_plan'],
    'accepted_independent_peer': ref(peer_path),
    'accepted27_actual_review': producer['accepted27_actual_review'],
    'previous_checkpoint': ref(previous),
    'publisher_Source': ref(NEW),
    'publisher_parent_Source': ref(OLD),
    'expected_actual_review_path': '.runtime/porting/SRC-06/Root-source-zone-equipment-output-actual-review-28/review.json',
    'pending_Root_custody': {
        'application': '.runtime/porting/SRC-06/Root-zone-equipment-output-application-28/receipt.json',
        'actual_review_sha256': 'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source': '.runtime/porting/SRC-06/check-source-zone-equipment-output-actual-Root-28.py',
        'launcher_Source': '.runtime/porting/SRC-06/launch-zone-equipment-output-Root-28.py',
        'B_CLI': '.runtime/porting/SRC-06/canonical-source-zone-equipment-output-B-NOLIMIT-24H-command-Root-28/receipt.json',
        'A24_CLI': '.runtime/porting/SRC-06/canonical-source-zone-equipment-output-A-24H-command-Root-28/receipt.json',
    },
    'Root_custody_at_publish': 'Byte-authenticate actual aggregate/application, their author Sources, launcher and both actual CLI receipts/artifacts at publication. No assumed frontier or positive execution claim from static Source. No historical application relabelling or Source reapplication.',
    'summary_template': {
        'A': '14/54', 'B': '14/64', 'changed_Rust_sources': 3, 'existing_Rust_sources': 3, 'new_Rust_sources': 0,
        'new_test_functions': 0, 'actual_test_bodies_executed': 0,
        'focused_validation_policy': 'Actual production B then A24 only. No unrelated test/profile, repeated cohort, new test or alltargets.',
        'scope': 'Same retained Config, equipment-list, sensible/moisture demand, priority order and live schedules: actual post-component output response and whole updateSystemOutputRequired, plus same component availability zero-list input/count/status lifecycle. Defined integer-capacity conversions preserve actual Array1D_int. Existing mass/return/leaving and positive manager-list/Sizer operations retain truthful boundaries.',
        'full_B_or_finite15_completion_claim': False,
        'Native_harness_runtime_or_unit_equivalence_claim': False,
        'gate_changes': False, 'policy_changes': False,
    },
    'doc_appends': {
        'CHECKLIST.md': '장비 호출 뒤 실제 반환 출력으로 구역 유량과 남은 부하를 갱신하는 경로를 연결했습니다. 관측된 B 경계와 A24 회귀 결과는 연결된 증거에 기록합니다.',
        'STATE_CONTRACTS.md': '장비 목록·우선순위와 현열·수분 수요는 기존 소유자에서 갱신하며, 다음 장비의 실제 스케줄 값을 Native 순서로 읽습니다. 가용성 입력 래치와 호출 횟수도 같은 컴포넌트 행에 보존합니다.',
        'cards/SRC-06.md': '출력 후처리·수요 갱신·가용성 경로의 실행 결과를 기록합니다. B의 실제 경계는 `{{actual_B_frontier}}`이며, 전체 B 및 내부 Native 수치 동등성 완료를 주장하지 않습니다.',
    },
    'finite_archive_inputs': [row for _, row in sorted(finite.items())],
    'finite_archive_input_count': len(finite),
    'finite_archive_input_bytes': sum(row['bytes'] for row in finite.values()),
    'publisher_executed': False, 'canonical_docs_mutations': False, 'Cargo_tests_Native_executed': False, 'gate_changes': False,
}
template_path = OUT / 'publication-template.json'
template_path.write_text(json.dumps(template, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
diffs = {}
for name, before, after in [('forward', source.encode(), body.encode()), ('inverse', body.encode(), source.encode())]:
    delta = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=OLD.name, tofile=NEW.name)).encode()
    assert ns['apply_literal'](before, delta) == after
    p = OUT / (name + '.diff')
    p.write_bytes(delta)
    diffs[name] = ref(p)
proof = {'parent': ref(OLD), 'successor': ref(NEW), 'literal_applications': 2, 'diffs': diffs, 'template': ref(template_path), 'scope': 'Same accepted27 two-CLI/no-test guarded publication algorithm; exact28 Source/base/peer/path/count/scope, prior27 proof transfer, fresh direct application custody. Removes historical25 test and historical application label-correction handling. No execution.', 'publisher_executed': False, 'canonical_mutations': False}
bridge_path = OUT / 'publisher-parent-bridge.json'
bridge_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'publisher': ref(NEW), 'template': ref(template_path), 'bridge': ref(bridge_path)}))

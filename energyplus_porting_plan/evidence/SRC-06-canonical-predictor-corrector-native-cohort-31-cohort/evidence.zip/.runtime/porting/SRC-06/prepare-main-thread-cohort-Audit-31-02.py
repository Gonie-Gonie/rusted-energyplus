"""Safe stable custom-harness successor; ignored Source-only authoring, no runs."""
from pathlib import Path
import hashlib,json,re,difflib,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'source-controlled-zone-cohort-held-Audit-31';OUT=D/'source-controlled-zone-cohort-main-draft-Audit-31-02'
def need(x,m):
 if not x:raise ValueError(m)
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(row):
 p=R/row['path'];need(ref(p)['sha256']==row['sha256'],'changed '+str(p));return p
def save(name,b):
 p=OUT/name;p.parent.mkdir(exist_ok=True,parents=True);need(not p.exists(),'immutable '+str(p));p.write_bytes(b);return ref(p)
def dump(name,v):return save(name,(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
need(not OUT.exists(),'immutable output')
mp=OLD/'manifest.json';need(ref(mp)['sha256']=='4689a118282b54227342ac1d216008cf0c30246bc4e736dd7efe2aefefa86411','original accepted held')
m=json.loads(mp.read_bytes());original={row['canonical_path']:row for row in m['files']}
files=[];proposals={}
for name,row in original.items():
 before=auth(row['before']).read_bytes();new=auth(row['proposed']).read_bytes()
 if name.endswith('/native_cohort.rs'):
  oldnew=new;anchor=b'#[test]\nfn all_native_b_prediction_entries_match_source_rollback_and_sensible_bits() -> Result {'
  need(new.count(anchor)==1,'one previous worker attribute');new=new.replace(anchor,anchor.replace(b'#[test]\n',b''))
  bridge=b'''
// Dedicated stable Cargo harness=false entry; this is the same cohort body.
impl SourceZoneAirPredictorCorrector {
    pub(crate) fn run_native_controlled_air_cohort() -> Result {
        all_native_b_prediction_entries_match_source_rollback_and_sensible_bits()
    }
}
'''
  new+=bridge
  need(new[:-len(bridge)].replace(anchor.replace(b'#[test]\n',b''),anchor)==oldnew,'complete prior cohort body/assertions exact')
 proposals[name]=(before,new)
CARGO='crates/ep_runtime/Cargo.toml';LIB='crates/ep_runtime/src/lib.rs'
PRED='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs'
for name in (CARGO,LIB,PRED):
 before=subprocess.run(['git','-C',str(R),'show','e110c389b7333e1e0770bcc80f334fa6e68c1b2d:'+name],capture_output=True,check=True).stdout
 need(before==(R/name).read_bytes(),'unchanged three logical parents '+name)
 if name==CARGO:
  new=before+b'''
[features]
native-controlled-air-cohort = []

[[test]]
name = "native_controlled_air_cohort"
path = "src/lib.rs"
harness = false
required-features = ["native-controlled-air-cohort"]
'''
 elif name==PRED:
  a=b'#[cfg(test)]\nmod native_cohort;';b=b'#[cfg(all(test, feature = "native-controlled-air-cohort"))]\nmod native_cohort;'
  need(before.count(a)==1,'native private module hook');new=before.replace(a,b)
 else:
  new=before+b'''
// Explicit test target only: keep the Native single-process-main FP context.
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
fn main() -> std::result::Result<(), Box<dyn std::error::Error>> {
    println!("running 1 native controlled-air cohort on process main");
    crate::heat_balance::ordinary_air_heat_balance::predictor_corrector::SourceZoneAirPredictorCorrector::run_native_controlled_air_cohort()?;
    println!("cohort native_controlled_air_cohort ... ok");
    println!("cohort result: ok. 1 passed; 0 failed; predictor entries=1168; whole corrector entries=1168; positive inlet cases=810");
    Ok(())
}
'''
 proposals[name]=(before,new)
for at,(name,(before,new)) in enumerate(proposals.items(),1):
 f=save(f'diffs/{at:02}.forward.diff',''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name)).encode())
 i=save(f'diffs/{at:02}.inverse.diff',''.join(difflib.unified_diff(new.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='b/'+name,tofile='a/'+name)).encode())
 row={'canonical_path':name,'before':save('before/'+name,before),'proposed':save('proposed/'+name,new),'forward_diff':f,'inverse_diff':i}
 if name.endswith('.rs'):
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True)
  need(parse.returncode==0,'Source syntax '+name+': '+parse.stderr.decode())
  row['Source_only_parse']={'exit_code':0,'stdout':save(f'parse/{at:02}.stdout',parse.stdout),'stderr':save(f'parse/{at:02}.stderr',parse.stderr)}
 else:
  import tomllib
  parsed=tomllib.loads(new.decode());need(parsed['features']['native-controlled-air-cohort']==[],'empty feature')
  target=parsed['test'][-1];need(target=={'name':'native_controlled_air_cohort','path':'src/lib.rs','harness':False,'required-features':['native-controlled-air-cohort']},'explicit safe main target')
  row['TOML_parse_zero']=True
 files.append(row)
need(len(files)==7 and sum(f['canonical_path'].endswith('.rs') for f in files)==6,'seven files six Rust')
tool=Path('C:/Users/GonieGonie/.rustup/toolchains/1.96.0-x86_64-pc-windows-gnu/lib/rustlib/src/rust/library/test/src')
authority=[]
for name,ranges in [('lib.rs',[(174,228),(369,386),(627,656)]),('cli.rs',[(256,266),(385,400)])]:
 p=tool/name;b=p.read_bytes();lines=b.splitlines(keepends=True)
 for first,last in ranges:
  excerpt=b''.join(lines[first-1:last]);authority.append({'whole':{'path':p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)},'first_line':first,'last_line':last,
   'excerpt':save(f'Rust-authority/{name}.{first}-{last}.txt',excerpt)})
failed=[]
for name in ('canonical-source-predictor-corrector-cohort-Root-31-cohort','canonical-source-corrector-property-diagnostic-Root-31','corrector-test-serial-thread-diagnostic-Root-31'):
 p=D/name/'receipt.json';x=json.loads(p.read_bytes());need(x['exit_code']==101 and x['source_bytes_match_before_and_after'],'preserved failed worker receipt '+name);failed.append(ref(p))
draft={'schema':'src06-safe-main-thread-consolidated-cohort-draft.v1','status':'IMMUTABLE SOURCE-ONLY; final committed31 custody/peer/application/custom-harness execution pending',
 'base_HEAD':'e110c389b7333e1e0770bcc80f334fa6e68c1b2d','original_accepted_packet':ref(mp),'original_semantic_and_fixture_peer':m['independent_full_Source_and_fixture_peer'],
 'files':files,'existing_files':7,'new_files':0,'literal_diffs':14,'Rust_Source_only_parses':6,'TOML_parses':1,
 'original_four_proposal_qualification':'Node/surface test-only helpers and complete fixture unchanged; only #[test] removed from the same cohort body, which gains one associated test-only bridge.',
 'complete_original_cohort_body_name_assertions_fixture_unchanged':True,'new_test_bodies':0,'existing_cohort_body':1,
 'feature_contract':'Empty native-controlled-air-cohort; private leaf enabled only all(test,feature); no public production entry/API or dependency.',
 'command':['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort'],
 'stable_Rust_authority':authority,'primary_Cargo_source':'https://raw.githubusercontent.com/rust-lang/cargo/rust-1.96.0/src/cargo/core/compiler/mod.rs#L1282-L1296',
 'primary_Cargo_documentation':'https://doc.rust-lang.org/cargo/reference/cargo-targets.html#the-harness-field',
 'primary_attribute_expansion':'https://raw.githubusercontent.com/rust-lang/rust/1.96.0/compiler/rustc_builtin_macros/src/test.rs#L122-L125',
 'preserved_failed_worker_receipts':failed,'Root_diagnosis_context':'Same production rlib gave Native-exact Psat/RH on process main(x87=037f) and2ULP RH difference in worker(x87=027f), same MXCSR1f80. This proposal changes the runner context, not calculations/expected values.',
 'diagnosis_scope':'Root isolated diagnostics are context, not a successful current cohort execution; all prior failed bodies retained.',
 'no_FP_writes_unsafe_dependencies_math_tolerance_fixture_changes':True,'Cargo_main_tests_or_Native_mutations_by_author':False,'author_Source':ref(Path(__file__))}
print(json.dumps({'draft':dump('draft.json',draft),'files':7,'Rust_syntax_parses':6,'TOML_parse':True}))

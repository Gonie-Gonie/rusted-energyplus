"""Freeze the safe custom target over the exact known Root-applied worker packet."""
from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-controlled-zone-cohort-main-held-Audit-31-02'
HEAD='e110c389b7333e1e0770bcc80f334fa6e68c1b2d'
def need(x,m):
 if not x:raise ValueError(m)
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def auth(v):
 p=Path(v['path']);p=p if p.is_absolute() else R/p;b=p.read_bytes()
 need(hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b)),'custody '+str(p));return p
def load(path,sha):
 p=R/path;need(ref(p)['sha256']==sha,'JSON custody '+path);return p,json.loads(p.read_bytes())
def git(*args):return subprocess.run(['git','-C',str(R),*args],capture_output=True,check=True).stdout
def save(name,b):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);need(not p.exists(),'immutable '+str(p));p.write_bytes(b);return ref(p)
def dump(name,v):return save(name,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
a=argparse.ArgumentParser();a.add_argument('--peer',required=True);a.add_argument('--peer-sha',required=True);a.add_argument('--seal',action='store_true');a=a.parse_args()
need(a.seal and not O.exists(),'explicit fresh seal')
need(git('rev-parse','HEAD').decode().strip()==HEAD and git('rev-parse','origin/main').decode().strip()==HEAD,'committed31 Git identity')
dp,d=load('.runtime/porting/SRC-06/source-controlled-zone-cohort-main-draft-Audit-31-02/draft.json','ea566824034dfa771dcf0d085dc2ea1bf8e630b96666d8ba18d7a1dd9b03cb53')
pp,p=load(a.peer,a.peer_sha);need(p['accepted'] and not p['findings'] and p['reviewed_draft']==ref(dp),'accepted safe runner peer')
mp,m=load('.runtime/porting/SRC-06/source-controlled-zone-cohort-held-Audit-31/manifest.json','4689a118282b54227342ac1d216008cf0c30246bc4e736dd7efe2aefefa86411')
wp,w=load('.runtime/porting/SRC-06/Root-predictor-corrector-cohort-application-31-cohort/receipt.json','448d926486657f40ef99ed30afab201bfaa1e4d7acaa12dcddc0738d7790b4cd')
need(w['accepted'] and not w['findings'] and w['producer']==ref(mp),'known original Root application')
prior_path=auth(m['complete_final_compiler_Source_plan']);prior=json.loads(prior_path.read_bytes());need(ref(prior_path)['sha256']=='982f9138edc20f5104e7c3262eb6ef121cb5430c1162ee3b3c4911ace1fc33f1','prior WIP plan')
base_actual_path=auth(m['accepted31_production_actual_review']);base_actual=json.loads(base_actual_path.read_bytes());need(base_actual['accepted'] and not base_actual['findings'],'accepted31 science')
base_plan_path=auth(m['prior_complete_compiler_Source_plan']);base_plan=json.loads(base_plan_path.read_bytes());base_rows={v['path']:v for v in base_plan['entries']}
base_snapshot=json.loads(auth(m['actual_parent_snapshot']).read_bytes());base_archives={v['historical_path']:v['archive'] for v in base_snapshot['files']}
failed_path=auth(d['preserved_failed_worker_receipts'][0]);failed=json.loads(failed_path.read_bytes())
need(ref(failed_path)['sha256']=='662663a3ea61fa8b9bfe1f792daa856e6e885d41b010f61249656b10d17b5aa8' and failed['exit_code']==101 and failed['source_bytes_match_before_and_after'],'real executed worker failure')
snapshot_path=auth(failed['source_snapshot']);snapshot=json.loads(snapshot_path.read_bytes());archives={v['historical_path']:v for v in snapshot['files']}
rows={v['path']:copy.deepcopy(v) for v in prior['entries']};need(len(rows)==len(archives)==len(base_rows)==4503 and set(rows)==set(archives)==set(base_rows),'complete current/base input scope')
readback=[]
for name,v in rows.items():
 b=auth(v['source']).read_bytes();need(b==auth(archives[name]['archive']).read_bytes()==(R/name).read_bytes(),'exact prior WIP live/actual '+name)
 need(hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes']==archives[name]['size_bytes'],'prior plan metadata '+name)
 readback.append(dict(path=name,prior_WIP_source=v['source'],actual_failed_worker_archive=archives[name]['archive'],live_sha256=v['final_sha256'],bytes=len(b),whole_exact_prior_WIP_actual_live=True))
old={f['canonical_path']:f for f in m['files']};need(len(old)==4,'old4')
changed_vs_base={n for n,v in rows.items() if(v['final_sha256'],v['final_bytes'])!=(base_rows[n]['final_sha256'],base_rows[n]['final_bytes'])}
need(changed_vs_base==set(old),'ONLY known Root-applied4 differ from historical31')
tree=ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf8'));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal>','exec'),ns)
files=[];changed=[]
for at,f in enumerate(d['files'],1):
 name=f['canonical_path'];before=auth(f['before']).read_bytes();new=auth(f['proposed']).read_bytes();current=auth(rows[name]['source']).read_bytes()
 need(before==auth(base_archives[name]).read_bytes()==git('show',HEAD+':'+name),'seven historical31 before/Git '+name)
 need((hashlib.sha256(before).hexdigest(),len(before))==(base_rows[name]['final_sha256'],base_rows[name]['final_bytes']),'base metadata '+name)
 if name in old:need(current==auth(old[name]['proposed']).read_bytes(),'current known proposal '+name)
 else:need(current==before,'current unselected31 '+name)
 need(ns['apply_literal'](before,auth(f['forward_diff']).read_bytes())==new and ns['apply_literal'](new,auth(f['inverse_diff']).read_bytes())==before,'14 source literal applications '+name)
 prop=save('proposed/'+name,new);row=dict(canonical_path=name,before_absent=False,before=save('before/'+name,before),actual_historical31_archive=base_archives[name],before_whole_Git_exact_at_base=True,
   current_prior_WIP=rows[name]['source'],changed_from_current_WIP=current!=new,proposed=prop,reviewed_draft_whole=f['proposed'],literal_inverse=save('literal-inverse/'+name,before),
   forward_diff=save(f'diffs/{at:02}.forward.diff',auth(f['forward_diff']).read_bytes()),inverse_diff=save(f'diffs/{at:02}.inverse.diff',auth(f['inverse_diff']).read_bytes()))
 if name.endswith('.rs'):
  parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new,capture_output=True);need(parsed.returncode==0,'syntax '+name)
  row['Source_only_parse']=dict(exit_code=0,stdout=save(f'parse/{at:02}.stdout',parsed.stdout),stderr=save(f'parse/{at:02}.stderr',parsed.stderr))
 else:
  import tomllib
  cargo=tomllib.loads(new.decode());need(cargo['features']['native-controlled-air-cohort']==[],'empty feature');row['TOML_parse_zero']=True
 if current!=new:changed.append(name)
 files.append(row);rows[name]=dict(path=name,final_sha256=prop['sha256'],final_bytes=prop['bytes'],source=prop,origin='Whole accepted safe process-main cohort draft02')
expected={'crates/ep_runtime/Cargo.toml','crates/ep_runtime/src/lib.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/native_cohort.rs'}
need(set(changed)==expected and len(files)==7 and len(rows)==4503 and sum(n.endswith('.rs') for n in rows)==4490,'seven selected/four actual rewrites/unchanged input count')
diagnosis_path,diagnosis=load('.runtime/porting/SRC-06/corrector-thread-context-Root-31/diagnosis.json','eed505a53c484b8e5fbf7f3b0ac76d872ce9558cd2e6c57bcf2d4dfb7aa33508')
plan_ref=dump('complete-final-compiler-Source-plan.json',dict(schema='src06-safe-main-thread-cohort-complete-compiler-plan.v1',base_HEAD=HEAD,actual_current_WIP_snapshot=ref(snapshot_path),prior_current_WIP_plan=ref(prior_path),historical31_plan=ref(base_plan_path),inputs=4503,Rust_sources=4490,entries=[rows[n] for n in sorted(rows)],selected7_exact_reviewed_draft=True,actual_changed_current_files=changed,Root_full_readback_required=True))
manifest=dict(schema='src06-safe-main-thread-consolidated-cohort-held.v1',status='HELD: Root application and one dedicated process-main cohort execution pending',base_HEAD=HEAD,
  original_draft=ref(dp),independent_full_safe_runner_peer=ref(pp),original_worker_packet=ref(mp),original_semantic_and_fixture_peer=m['independent_full_Source_and_fixture_peer'],
  original_Root_application=ref(wp),current_prior_complete_compiler_Source_plan=ref(prior_path),historical31_complete_compiler_Source_plan=ref(base_plan_path),
  accepted31_production_actual_review=ref(base_actual_path),actual_current_WIP_snapshot=ref(snapshot_path),files=files,selected_existing_files=7,selected_Rust_files=6,selected_Cargo_manifests=1,new_files=0,
  actual_changed_current_files=changed,actual_rewrites=4,literal_applications=14,Source_only_parses=6,TOML_parses=1,complete_final_compiler_Source_plan=plan_ref,compiler_inputs=4503,Rust_sources=4490,
  full4503_current_WIP_readback=dump('current-WIP-full-readback.json',readback),ONLY_old4_applied_against_historical31=True,current_worktree_clean_claim=False,
  original_predictor_cases=1168,original_shortened_predictor_cases=77,whole_corrector_cases=1168,positive_inlet_cases=810,existing_cohort_bodies=1,new_test_bodies=0,normal_libtest_registration_delta=-1,
  complete_original_cohort_body_name_assertions_fixture_unchanged=True,command=d['command'],feature_contract=d['feature_contract'],stable_Rust_authority=d['stable_Rust_authority'],
  preserved_failed_worker_receipts=d['preserved_failed_worker_receipts'],Root_thread_context_diagnosis=ref(diagnosis_path),
  validation_policy='One dedicated stable harness=false process-main cohort. Preserve three failed/diagnostic worker invocations, no Native/B/A24/annual rerun. Source math/tolerances/fixtures untouched.',
  production_scope='Historical31 production numerical bodies unchanged after test/feature exclusion. Historical CLI did not use the updated test-only compiler snapshot.',
  no_FP_writes_unsafe_dependencies_math_tolerance_fixture_changes=True,main_Cargo_tests_or_Native_mutations_by_author=False,author_Source=ref(Path(__file__)))
print(json.dumps(dict(manifest=dump('manifest.json',manifest),plan=plan_ref,selected=7,actual_rewrites=4,inputs=4503,Rust_sources=4490)))

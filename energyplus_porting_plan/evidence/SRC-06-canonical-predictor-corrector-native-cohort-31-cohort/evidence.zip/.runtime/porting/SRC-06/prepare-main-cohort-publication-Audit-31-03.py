"""Prepare a route-aware WAITING publication; Root alone may publish after PASS."""
from pathlib import Path
import ast,hashlib,json,difflib
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'predictor-corrector-cohort-publication-prepared-Audit-31-cohort-03'
OLD=D/'publish-predictor-corrector-cohort-checkpoint-Audit-31-cohort-02.py';NEW=D/'publish-predictor-corrector-cohort-checkpoint-Audit-31-cohort-03.py'
def need(x,m):
 if not x:raise ValueError(m)
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def auth(row):
 p=R/row['path'];need(ref(p)['sha256']==row['sha256'],'ref '+str(p));return p
need(not O.exists() and not NEW.exists(),'immutable successor')
before=OLD.read_text(encoding='utf8');s=before
def replace(a,b):
 global s
 need(s.count(a)==1,'publisher anchor '+a[:80]);s=s.replace(a,b)
replace("predictor-corrector-cohort-publication-readback-Audit-31-cohort-02'","predictor-corrector-cohort-publication-readback-Audit-31-cohort-03'")
start=s.index("    assert producer['new_test_bodies']==0")
end=s.index("    for row in producer['files']",start)
s=s[:start]+'''    assert producer['new_test_bodies']==0 and producer['existing_cohort_bodies']==1
    assert producer['original_predictor_cases']==producer['whole_corrector_cases']==1168 and producer['positive_inlet_cases']==810
    assert producer['normal_libtest_registration_delta']==-1 and producer['no_FP_writes_unsafe_dependencies_math_tolerance_fixture_changes']
    assert producer['complete_original_cohort_body_name_assertions_fixture_unchanged']
    assert producer['selected_existing_files']==7 and producer['actual_rewrites']==4
'''+s[end:]
start=s.index("    command=unit['command'];")
end=s.index("    for row in (t['producer']",start)
s=s[:start]+'''    command=unit['command'];assert command==producer['command']
    output=checked(unit['stdout']).read_text(encoding='utf8')
    assert output.count('running 1 native controlled-air cohort on process main')==1
    assert output.count('cohort native_controlled_air_cohort ... ok')==1
    assert output.count('cohort result: ok. 1 passed; 0 failed; predictor entries=1168; whole corrector entries=1168; positive inlet cases=810')==1
'''+s[end:]
replace("    assert actual['actual_executed_test_bodies']==1 and actual['new_test_bodies']==0\n    assert producer['existing_test_bodies_extended']==1\n",'')
replace("    assert producer['accepted31_production_actual_review']==t['accepted31_review']","    assert producer['accepted31_production_actual_review']==t['accepted31_review']\n    assert len(producer['preserved_failed_worker_receipts'])==3\n    assert producer['Root_thread_context_diagnosis']==t['Root_thread_context_diagnosis']")
replace("    for row in t['finite_archive_inputs']:add(checked(row))",'''    for row in t['finite_archive_inputs']:add(checked(row))
    # Three real worker invocations failed; unlike compile-only failures they
    # each executed the cohort. Preserve them alongside the one successful run.
    diagnosis=accepted(t['Root_thread_context_diagnosis'])
    assert diagnosis['failed_or_diagnostic_focused_executions']==producer['preserved_failed_worker_receipts']
    add(checked(t['Root_thread_context_diagnosis']));add(checked(diagnosis['author_Source']))
    for row in diagnosis['helper_sources']:add(checked(row))
    diagnostic_command=load(checked(t['Root_thread_context_command']))
    assert diagnostic_command['exit_code']==0 and diagnostic_command['source_bytes_match_before_and_after']
    add(checked(t['Root_thread_context_command']))
    for key in ('stdout','stderr','source_snapshot'):add(checked(diagnostic_command[key]))
    add(checked(diagnostic_command['executed_launcher']['archive']))
    for row in producer['preserved_failed_worker_receipts']:
        run=load(checked(row));assert run['exit_code']==101 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
        add(checked(row))
        for key in ('stdout','stderr','source_snapshot'):add(checked(run[key]))
        add(checked(run['executed_launcher']['archive']))
        # Only the modified diagnostic test Source is needed from those snapshots.
        snapshot=load(checked(run['source_snapshot']))
        selected=next(v for v in snapshot['files'] if v['historical_path'].endswith('/prediction/native_cohort.rs'))
        add(checked(selected['archive']))''')
replace("status='One existing focused cohort test passed: all1168 predictor and1168 whole-corrector entries'","status='One dedicated safe process-main cohort passed: all1168 predictor and1168 whole-corrector entries'")
replace("        actual_unit_receipt=t['successful_unit_receipt'],Root_actual_unit_review=t['accepted_unit_review'],","        actual_unit_receipt=t['successful_unit_receipt'],Root_actual_unit_review=t['accepted_unit_review'],\n        Root_thread_context_diagnosis=t['Root_thread_context_diagnosis'],preserved_failed_worker_invocations=producer['preserved_failed_worker_receipts'],\n        successful_process_main_cohort_invocations=1,failed_or_diagnostic_worker_invocations=3,total_cohort_invocations=4,")
ast.parse(s);NEW.write_text(s,encoding='utf8',newline='');O.mkdir()
(O/'publisher-forward.diff').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='waiting-worker-publisher02',tofile='safe-main-publisher03')),encoding='utf8',newline='')
(O/'publisher-inverse.diff').write_text(''.join(difflib.unified_diff(s.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='safe-main-publisher03',tofile='waiting-worker-publisher02')),encoding='utf8',newline='')
mp=D/'source-controlled-zone-cohort-main-held-Audit-31-02/manifest.json';m=json.loads(mp.read_bytes());need(ref(mp)['sha256']=='6d45fb44ec142bb8ea3018223b92f063244dc1ceb9b0173742dbf245e2b10170','safe held')
finite={}
def add(row):
 p=auth(row);finite[ref(p)['path']]=ref(p)
for row in (ref(mp),m['complete_final_compiler_Source_plan'],m['independent_full_safe_runner_peer'],m['original_semantic_and_fixture_peer'],m['original_draft'],m['author_Source'],
 m['full4503_current_WIP_readback'],m['current_prior_complete_compiler_Source_plan'],m['historical31_complete_compiler_Source_plan'],
 m['original_worker_packet'],m['original_Root_application'],m['accepted31_production_actual_review'],
 ref(D/'prepare-main-thread-cohort-Audit-31-02.py'),ref(D/'prepare-corrector-cohort-Audit-31.py'),ref(D/'author-corrector-cohort-Audit-31.py'),ref(Path(__file__)),
 ref(D/'controlled-air-native-capture-Root-21/capture.json'),ref(D/'controlled-air-Native-reported-comparison-Root-21/comparison.json'),ref(OLD),ref(O/'publisher-forward.diff'),ref(O/'publisher-inverse.diff')):add(row)
for row in m['files']:
 for key in ('before','proposed','literal_inverse','forward_diff','inverse_diff'):add(row[key])
 if 'Source_only_parse' in row:
  for key in ('stdout','stderr'):add(row['Source_only_parse'][key])
for row in m['stable_Rust_authority']:add(row['excerpt'])
for name in ('manifest.json','controlled_air_observer.cc','controlled_air_observer.hh','air_fields.inc','fan_fields.inc','surface_fields.inc','demand_fields.inc'):
 add(ref(D/'controlled-air-native-held-Outer-21'/name))
base=R/'energyplus_porting_plan';oldplan=json.loads((base/'plan.json').read_bytes());task=next(t for t in oldplan['tasks'] if t['id']=='SRC-06');previous=task['canonical_controlled_zone_corrector_31'];add(previous)
diagnosis=auth(m['Root_thread_context_diagnosis']);command=D/'corrector-thread-context-command-Root-31/receipt.json'
need(ref(command)['sha256']=='a6fc9ddad060ffd077f076462688ae1af86c2b6f605637500bc45448b6b87027','diagnosis execution')
t={'schema':'src06-safe-main-cohort-publication-template.v1','status':'WAITING_FOR_ROOT_SAFE_PROCESS_MAIN_COHORT_AND_ACCEPTED_REVIEW','base_HEAD':m['base_HEAD'],
 'publisher_Source':ref(NEW),'producer':ref(mp),'complete_plan':m['complete_final_compiler_Source_plan'],'accepted31_review':m['accepted31_production_actual_review'],
 'actual_Native_capture':ref(D/'controlled-air-native-capture-Root-21/capture.json'),'actual_Native_reported_comparison':ref(D/'controlled-air-Native-reported-comparison-Root-21/comparison.json'),
 'previous_checkpoint':previous,'independent_peers':[m['independent_full_safe_runner_peer'],m['original_semantic_and_fixture_peer']],
 'Root_application':None,'successful_unit_receipt':None,'accepted_unit_review':None,'Root_thread_context_diagnosis':ref(diagnosis),'Root_thread_context_command':ref(command),
 'finite_archive_inputs':list(finite.values()),'finite_archive_scope':'Seven reviewed existing files, four actual rewrites, complete unchanged cohort fixture and safe runner, direct current custody, three preserved executed worker failures and one successful custom invocation. No previous ZIP/raw390MB/rlib/exe/Native or CLI replay.',
 'summary_template':{'A':'14/54','B':'14/64','gate_changes':False,'tolerance_policy_changes':False,'successful_process_main_cohort_invocations':1,'failed_or_diagnostic_worker_invocations':3,'total_cohort_invocations':4,
  'new_test_bodies':0,'existing_cohort_bodies':1,'normal_libtest_registration_delta':-1,'selected_files':7,'actual_current_rewrites':4,
  'original_predictor_cases':1168,'original_shortened_predictor_cases':77,'whole_corrector_cases':1168,'positive_inlet_cases':810,
  'scope':'All captured numeric/owner writes exact binary64; Native property cache hit/miss/recurrence and full engine/geometry-input execution remain unclaimed.',
  'runner':'Stable harness=false required-feature target executes the same body on process main without unsafe/FPU controls or science/fixture/tolerance/dependency changes.',
  'production_scope':'Historical31 production5352 proof inherited for unchanged science bodies; historical CLI did not execute this updated test snapshot.'},
 'doc_appends':{
  'cards/SRC-06.md':{'title':'예측·보정 Native 코호트 전용 실행','text':'기존 코호트 본문을 메인 스레드 전용 타깃으로 옮겨 예측·보정 각 1,168건과 양수 유입 810건을 비트 단위로 확인했다. 실행 명령은 `cargo test --locked -p ep_runtime --features native-controlled-air-cohort --test native_controlled_air_cohort`이다. 작업 스레드에서 발생한 실패·진단 3회를 보존했으며 계산식·기대값·허용오차는 바꾸지 않았다. 생산 경로 증거와 게이트 수는 체크포인트 31에서 이어받는다.'},
  'CHECKLIST.md':{'title':'SRC-06 통합 코호트 전용 타깃','text':'기존 본문 1개를 명시적 메인 스레드 테스트로 실행했다. 일반 단위 테스트에서는 큰 코호트를 제외하며, 실패·진단 3회와 성공 1회를 구분해 기록했다. 게이트 수는 그대로다.'},
  'STATE_CONTRACTS.md':{'title':'Native 코호트 실행 문맥','text':'안정 Rust의 전용 `harness=false` 타깃은 같은 실제 소유자·진입값·검증 본문을 프로세스 메인에서 실행한다. FPU 제어·생산 API·습공기 물성 계산·허용오차를 수정하지 않으며 Native의 캐시 적중·경고 이력이나 FPU 레지스터 일치는 주장하지 않는다.'}}}
q=O/'publication-template.json';q.write_text(json.dumps(t,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'publisher':ref(NEW),'template':ref(q),'status':t['status']}))

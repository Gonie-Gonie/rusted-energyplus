from pathlib import Path
import hashlib,json,re,struct,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-source-predictor-corrector-cohort-main-actual-review-31-02';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
def auth(path,sha):
 r=ref(D/path);assert r['sha256']==sha;return r,json.loads(checked(r))
mr,m=auth('source-controlled-zone-cohort-main-held-Audit-31-02/manifest.json','6d45fb44ec142bb8ea3018223b92f063244dc1ceb9b0173742dbf245e2b10170')
ar,a=auth('Root-predictor-corrector-cohort-main-application-31-02/receipt.json','dfde6d89dd4beb78a0812d8428a9d484c6b8ed33bfbe8f1b866e32680cb82a15')
rr,r=auth('canonical-source-predictor-corrector-cohort-main-Root-31-02/receipt.json',sys.argv[1])
assert a['accepted'] and not a['findings'] and a['producer']==mr and r['exit_code']==0 and r['launch_error'] is None and r['source_bytes_match_before_and_after']
assert r['command']==m['command']==['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort']
out=checked(r['stdout']).decode('utf8');err=checked(r['stderr']).decode('utf8');assert out.splitlines()==['running 1 native controlled-air cohort on process main','cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; predictor entries=1168; whole corrector entries=1168; positive inlet cases=810'] and 'error[' not in err
assert r['repository_before']==r['repository_after'] and r['repository_before']['head']==a['base_HEAD']==m['base_HEAD']=='e110c389b7333e1e0770bcc80f334fa6e68c1b2d'
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};actual={v['historical_path']:v for v in json.loads(checked(r['source_snapshot']))['files']};assert len(rows)==4503 and set(rows)==set(actual) and sum(n.endswith('.rs') for n in rows)==4490
for n,v in rows.items():
 b=checked(v['source']);assert b==checked(actual[n]['archive'])==(R/n).read_bytes() and hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes']==actual[n]['size_bytes'],n
assert len(m['files'])==7 and len(a['selected'])==7 and a['new_test_bodies']==0
for f in m['files']:assert(R/f['canonical_path']).read_bytes()==checked(f['proposed'])==checked(a['selected'][f['canonical_path']]['proposed'])
for f in m['files'][:2]:
 old=checked(f['before']);new=checked(f['proposed']);suffix=new[len(old):];assert new.startswith(old+b'\n') and suffix.count(b'#[cfg(test)]')==1
f=m['files'][3];fixture=json.loads(checked(f['proposed']).split(b'r###"',1)[1].rsplit(b'"###;',1)[0]);oldfixture=json.loads(checked(f['before']).split(b'r###"',1)[1].rsplit(b'"###;',1)[0]);assert {k:v for k,v in fixture.items() if not k.startswith('corrector_')}==oldfixture and len(fixture['cases'])==len(fixture['corrector_cases'])==1168
assert [v['invocation'] for v in fixture['corrector_cases']]==list(range(1,1169))
groups={};positive=0;tables=fixture['corrector_state_tables']
for case in fixture['corrector_cases']:
 entry={k:tables[k][v] for k,v in case['entry'].items()};clock=entry['clock'];key=(clock['WarmupFlag'],clock['KickOffSimulation'],case['arguments']['useZoneTimeStepHistory']);groups[key]=groups.get(key,0)+1
 positive+=any(struct.unpack('>d',bytes.fromhex(v['physical']['value']['MassFlowRate']))[0]>0.0 for v in entry['config']['InletNode']['values'])
assert positive==810 and sum(groups.values())==1168
pr=m['independent_full_safe_runner_peer'];peer=json.loads(checked(pr));assert a['independent_peer']==pr and peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft']
original=json.loads(checked(m['original_worker_packet']));original_peer=json.loads(checked(m['original_semantic_and_fixture_peer']));assert original_peer['accepted'] and not original_peer['findings'] and original_peer['reviewed_draft']==original['original_draft']
production=json.loads(checked(m['accepted31_production_actual_review']));assert production['accepted'] and not production['findings'] and production['original_tolerance_RMSE_5352_proof_transferred'] and production['B_frontier']=='GetHeatBalanceInput: positive component ZoneEquip inlet5488'
failures=[]
for row in m['preserved_failed_worker_receipts']:
 v=json.loads(checked(row));assert v['exit_code']==101 and v['source_bytes_match_before_and_after'];checked(v['stdout']);checked(v['stderr']);failures.append(row)
assert len(failures)==3
diagnosis=json.loads(checked(m['Root_thread_context_diagnosis']));assert diagnosis['accepted'] and not diagnosis['findings'] and diagnosis['failed_or_diagnostic_focused_executions']==failures
O.mkdir();result=dict(schema='src06-main-thread-consolidated-predictor-corrector-actual-cohort.v1',accepted=True,findings=[],producer=mr,application=ar,initial_worker_application=m['original_Root_application'],independent_safe_runner_peer=pr,independent_original_semantic_fixture_peer=m['original_semantic_and_fixture_peer'],complete_compiler_plan=m['complete_final_compiler_Source_plan'],actual_focused_test=rr,actual_snapshot=r['source_snapshot'],all4503_inputs_exact_final_plan_and_live=True,Rust_sources=4490,selected_existing_files=7,selected_Rust_files=6,selected_Cargo_manifests=1,new_test_bodies=0,existing_cohort_body_relocated=1,normal_libtest_registration_delta=-1,successful_main_cohort_executions=1,preserved_failed_or_diagnostic_worker_executions=failures,total_cohort_body_invocations=4,actual_test_stdout=r['stdout'],actual_test_stderr=r['stderr'],original_predictor_cases=1168,original_shortened_cases=77,whole_corrector_cases=1168,actual_positive_inlet_cases=positive,corrector_cohort_groups=[dict(warmup=k[0],kickoff=k[1],zone_history=k[2],count=v) for k,v in sorted(groups.items())],original_predictor_fixture_semantic_subtree_exact=True,cfg_test_owner_production_prefixes_exact=True,actual_Native_capture=original['actual_Native_capture'],Root_thread_context_diagnosis=m['Root_thread_context_diagnosis'],test_result='PASS: same existing cohort executes synchronously on process main. Original1168 predictor checks and all1168 whole correctAirTemp/Sums/humidity executions preserve every assertion and exact binary64 values/observed writes;810 positive inlets. Three earlier worker failures/diagnostics retained, no tolerance or expected-value change.',inherited_production_integration=m['accepted31_production_actual_review'],inherited_actual_B=production['actual_B'],inherited_actual_A24=production['actual_A24'],final_CLI_rebuilt_or_executed=False,production_science_body_changes=0,FP_controls_mutated=False,new_unsafe_or_dependencies=False,validation_policy='One dedicated stable harness=false Cargo target after diagnosing three prior worker invocations. Same feature gates remove large fixture from normal library tests. No broad suite, new Native engine, B/A24 or annual rerun for test-only code.',qualifications=['Same existing cohort body, fixture and numerical assertions; custom target main calls it directly without spawning, no forced FP controls.','Root main/worker diagnosis observes Rust thread x87 difference; Native register values were not captured and are not claimed. Actual full main cohort numerical equivalence is separately verified by success.','Complete captured function-entry consumed operands, not full engine or production geometry-input proof. Native property cache hit/miss/recurrence traces remain unobserved.','Historical31 production integration and5352 proof inherited after cfg(test)/feature exclusion; old CLI did not execute this updated compiler snapshot. A14/54 B14/64 unchanged.'],author_Source=ref(Path(__file__).resolve()))
p=O/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

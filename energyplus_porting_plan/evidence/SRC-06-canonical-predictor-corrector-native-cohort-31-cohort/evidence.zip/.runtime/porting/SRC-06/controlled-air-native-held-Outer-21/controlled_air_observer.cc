// Passive copies only: never call a getter, solver, psychrometric routine or cache.
#include "controlled_air_observer.hh"
#include <AirflowNetwork/Solver.hpp>
#include <EnergyPlus/Construction.hh>
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataHeatBalFanSys.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataHeatBalSurface.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataLoopNode.hh>
#include <EnergyPlus/DataRoomAirModel.hh>
#include <EnergyPlus/DataSurfaces.hh>
#include <EnergyPlus/DataZoneControls.hh>
#include <EnergyPlus/DataZoneEnergyDemands.hh>
#include <EnergyPlus/DataZoneEquipment.hh>
#include <EnergyPlus/DuctLoss.hh>
#include <EnergyPlus/HybridModel.hh>
#include <nlohmann/json.hpp>
#include <cstring>
#include <exception>
#include <limits>

#if !defined(__MINGW32__) || !defined(_WIN64) || __GNUC__ != 13 || __GNUC_MINOR__ != 2
#error "This isolated reference uses the retained GCC13.2 Windows core ABI"
#endif
#if defined(_GLIBCXX_DEBUG) || defined(__FAST_MATH__) || defined(NDEBUG)
#error "Preserve core assertions, container ABI and floating-point options"
#endif
#if !defined(EP_psych_errors) || defined(EP_psych_stats)
#error "Preserve actual core psychrometric definitions"
#endif

namespace ControlledAirObservation {
namespace {
using json = nlohmann::json;
thread_local Capture *active = nullptr;
thread_local Scope *current = nullptr;
char const *name(Method m) noexcept {
    switch (m) {
    case Method::Predict: return "predictSystemLoad";
    case Method::Update: return "updateTemperatures";
    case Method::PredictedLoad: return "calcPredictedSystemLoad";
    case Method::Sums: return "calcZoneOrSpaceSums";
    case Method::Temperature: return "correctAirTemp";
    case Method::Humidity: return "correctHumRat";
    default: return "invalid-observer-method";
    }
}
bool increment(std::uint64_t &counter) noexcept {
    if (counter == std::numeric_limits<std::uint64_t>::max()) {
        active->overflow = true; return false;
    }
    ++counter; return true;
}
json scalar(double value) {
    // Integer-only transport: neither JSON numeric formatting nor a floating
    // comparison is needed to preserve any binary64, including NaN payloads.
    std::uint64_t bits; std::memcpy(&bits, &value, sizeof(bits));
    char text[17]; char const *digits = "0123456789abcdef";
    for (unsigned i = 0; i < 16; ++i) text[i] = digits[(bits >> ((15 - i) * 4)) & 15];
    text[16] = '\0';
    return {{"value_bits", text}};
}
template<class A> bool contains(A const &a, int at) {
    if (!a.allocated()) return false;
    if constexpr (requires { a.contains(at); }) return a.contains(at);
    else return at >= 1 && at <= a.isize(); // actual EPVector 1-based operator()
}
template<class A> json shape(A const &a) {
    json out{{"allocated",a.allocated()},{"size",a.size()},
             {"owner_address",reinterpret_cast<std::uintptr_t>(&a)}};
    if constexpr (requires { a.l(); a.u(); }) {
        out["lower"] = a.allocated() ? json(a.l()) : json(nullptr);
        out["upper"] = a.allocated() ? json(a.u()) : json(nullptr);
    } else {
        out["index_domain"] = "EPVector one-based operator()";
    }
    return out;
}
template<class A> json real_slot(A const &a, int at) {
    auto out=shape(a); out["index"]=at;
    out["value"]=contains(a,at) ? scalar(a(at)) : json(nullptr); return out;
}
template<class A> json int_slot(A const &a, int at) {
    auto out=shape(a); out["index"]=at;
    out["value"]=contains(a,at) ? json(static_cast<std::int64_t>(a(at))) : json(nullptr); return out;
}
template<class A> json reals(A const &a) {
    json out=json::array(); for (auto const &v:a) out.push_back(scalar(v)); return out;
}
template<class A> json allocated_reals(A const &a) {
    auto out=shape(a);out["values"]=nullptr;
    if (a.allocated()) { out["values"]=json::array(); for(int i=1;i<=a.isize();++i) out["values"].push_back(scalar(a(i))); }
    return out;
}
json clock(EnergyPlus::EnergyPlusData const &s) {
    auto const &g=*s.dataGlobal; auto const &e=*s.dataEnvrn; auto const &h=*s.dataHVACGlobal;
    return {{"state_address",reinterpret_cast<std::uintptr_t>(&s)},
        {"environment_index",e.CurEnvirNum},{"environment_name",e.EnvironmentName},
        {"CalendarYear",g.CalendarYear},{"Month",e.Month},{"DayOfMonth",e.DayOfMonth},
        {"DayOfSim",g.DayOfSim},{"HourOfDay",g.HourOfDay},{"TimeStep",g.TimeStep},
        {"KindOfSim",static_cast<int>(g.KindOfSim)},{"CurrentTime",scalar(g.CurrentTime)},
        {"TimeStepZone",scalar(g.TimeStepZone)},{"TimeStepZoneSec",scalar(g.TimeStepZoneSec)},
        {"TimeStepSys",scalar(h.TimeStepSys)},{"TimeStepSysSec",scalar(h.TimeStepSysSec)},
        {"SysTimeElapsed",scalar(h.SysTimeElapsed)},{"FracTimeStepZone",scalar(h.FracTimeStepZone)},
        {"PreviousTimeStep",scalar(h.PreviousTimeStep)},{"NumOfSysTimeSteps",h.NumOfSysTimeSteps},
        {"NumOfSysTimeStepsLastZoneTimeStep",h.NumOfSysTimeStepsLastZoneTimeStep},
        {"FirstTimeStepSysFlag",h.FirstTimeStepSysFlag},{"ShortenTimeStepSys",h.ShortenTimeStepSys},
        {"UseZoneTimeStepHistory",h.UseZoneTimeStepHistory},{"WarmupFlag",g.WarmupFlag},
        {"DoingSizing",g.DoingSizing},{"KickOffSimulation",g.KickOffSimulation},
        {"BeginSimFlag",g.BeginSimFlag},{"BeginEnvrnFlag",g.BeginEnvrnFlag},
        {"BeginDayFlag",g.BeginDayFlag},{"BeginTimeStepFlag",g.BeginTimeStepFlag},
        {"OutBaroPress",scalar(e.OutBaroPress)},{"OutHumRat",scalar(e.OutHumRat)}};
}
json air_fields(Air const &a) {
    json out{{"owner_address",reinterpret_cast<std::uintptr_t>(&a)}};
    // Generated against every explicitly initialized Real64 member of the same
    // pinned Native record. No clone of a solver, history update or sum.
#include "air_fields.inc"
    return out;
}
json node(EnergyPlus::EnergyPlusData const &s,int at) {
    auto const &n=*s.dataLoopNodes; auto out=shape(n.Node);out["index"]=at;out["value"]=nullptr;
    if (contains(n.Node,at)) {
        auto const &v=n.Node(at);
        out["value"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},
            {"Temp",scalar(v.Temp)},{"MassFlowRate",scalar(v.MassFlowRate)},
            {"HumRat",scalar(v.HumRat)},{"Enthalpy",scalar(v.Enthalpy)},
            {"TempSetPoint",scalar(v.TempSetPoint)}};
    }
    out["NodeID"]=contains(n.NodeID,at) ? json(n.NodeID(at)) : json(nullptr);
    return out;
}
template<class A> json config(EnergyPlus::EnergyPlusData const &s,A const &a,int at) {
    auto out=shape(a);out["index"]=at;out["value"]=nullptr;
    if (!contains(a,at)) return out;
    auto const &v=a(at);json in=shape(v.InletNode);in["values"]=nullptr;
    if(v.InletNode.allocated()) {
        in["values"]=json::array();
        for(int i=v.InletNode.l();i<=v.InletNode.u();++i)
            in["values"].push_back({{"slot",i},{"NodeNum",v.InletNode(i)},{"physical",node(s,v.InletNode(i))}});
    }
    out["value"]={{"address",reinterpret_cast<std::uintptr_t>(&v)},{"ZoneName",v.ZoneName},
        {"IsControlled",v.IsControlled},{"ZoneNode",v.ZoneNode},{"NumInletNodes",v.NumInletNodes},{"InletNode",in}};
    return out;
}
json demand(EnergyPlus::EnergyPlusData const &s,int zone,int space) {
    auto const &d=*s.dataZoneEnergyDemand;
    json out{{"Setback",int_slot(d.Setback,zone)},{"DeadBandOrSetback",int_slot(d.DeadBandOrSetback,zone)},
             {"CurDeadBandOrSetback",int_slot(d.CurDeadBandOrSetback,zone)}};
    auto copy=[&](auto const &rows,int at) {
        auto value=shape(rows);value["index"]=at;value["value"]=nullptr;
        if(contains(rows,at)) {
            auto const &v=rows(at);json fields{{"address",reinterpret_cast<std::uintptr_t>(&v)},
                {"NumZoneEquipment",v.NumZoneEquipment},{"StageNum",v.StageNum}};
#include "demand_fields.inc"
            fields["SequencedOutputRequired"]=allocated_reals(v.SequencedOutputRequired);
            fields["SequencedOutputRequiredToHeatingSP"]=allocated_reals(v.SequencedOutputRequiredToHeatingSP);
            fields["SequencedOutputRequiredToCoolingSP"]=allocated_reals(v.SequencedOutputRequiredToCoolingSP);
            value["value"]=fields;
        }
        return value;
    };
    out["zone"]=copy(d.ZoneSysEnergyDemand,zone);
    if(space>0) out["space"]=copy(d.spaceSysEnergyDemand,space);
    return out;
}
json fan(EnergyPlus::EnergyPlusData const &s,int zone) {
    auto const &f=*s.dataHeatBalFanSys;
    json out{{"TempControlType",int_slot(f.TempControlType,zone)},
             {"TempControlTypeRpt",int_slot(f.TempControlTypeRpt,zone)}};
#include "fan_fields.inc"
    auto v=shape(f.zoneTstatSetpts);v["value"]=nullptr;
    if(contains(f.zoneTstatSetpts,zone)) {
        auto const &p=f.zoneTstatSetpts(zone);
        v["value"]={{"address",reinterpret_cast<std::uintptr_t>(&p)},
            {"setpt",scalar(p.setpt)},{"setptLo",scalar(p.setptLo)},{"setptHi",scalar(p.setptHi)}};
    }
    out["zoneTstatSetpts"]=v;return out;
}
json spaces(EnergyPlus::EnergyPlusData const &s,int zone) {
    auto const &h=*s.dataHeatBal;auto const &sur=*s.dataSurface;auto const &hs=*s.dataHeatBalSurf;
    json rows=json::array();
    for(int at:h.Zone(zone).spaceIndexes) {
        json row{{"index",at},{"space_owner",shape(h.space)},{"value",nullptr}};
        if(!contains(h.space,at)) {rows.push_back(row);continue;}
        auto const &v=h.space(at);
        json data{{"address",reinterpret_cast<std::uintptr_t>(&v)},{"Volume",scalar(v.Volume)},
            {"fracZoneVolume",scalar(v.fracZoneVolume)},{"SystemZoneNodeNumber",v.SystemZoneNodeNumber},
            {"HTSurfaceFirst",v.HTSurfaceFirst},{"HTSurfaceLast",v.HTSurfaceLast}};
        json surfaces=json::array();
        for(int i=v.HTSurfaceFirst;i<=v.HTSurfaceLast;++i) {
            json z{{"index",i},{"surface_owner",shape(sur.Surface)},{"value",nullptr}};
            if(contains(sur.Surface,i)) {
                auto const &a=sur.Surface(i);
                json f{{"address",reinterpret_cast<std::uintptr_t>(&a)},{"Area",scalar(a.Area)},
                       {"Class",static_cast<int>(a.Class)},{"Construction",a.Construction},
                       {"SurfTAirRef",int_slot(sur.SurfTAirRef,i)}};
#include "surface_fields.inc"
                z["value"]=f;
            }
            surfaces.push_back(z);
        }
        data["surfaces"]=surfaces;
        json gains=shape(h.spaceIntGainDevices);gains["value"]=nullptr;
        if(contains(h.spaceIntGainDevices,at)) {
            auto const &g=h.spaceIntGainDevices(at);json devices=shape(g.device);devices["values"]=nullptr;
            if(g.device.allocated()) {
                devices["values"]=json::array();
                for(int i=g.device.l();i<=g.device.u();++i) {
                    // Only actual active devices are read; spare allocated rows
                    // retain shape without dereferencing unconsumed pointers.
                    if(i>g.numberOfDevices) break;
                    auto const &d=g.device(i);
                    devices["values"].push_back({{"index",i},{"address",reinterpret_cast<std::uintptr_t>(&d)},
                        {"CompObjectName",d.CompObjectName},{"CompType",static_cast<int>(d.CompType)},
                        {"ConvectGainRate",scalar(d.ConvectGainRate)},
                        {"ReturnAirConvGainRate",scalar(d.ReturnAirConvGainRate)},
                        {"ReturnAirNodeNum",d.ReturnAirNodeNum},{"LatentGainRate",scalar(d.LatentGainRate)}});
                }
            }
            gains["value"]={{"numberOfDevices",g.numberOfDevices},{"maxNumberOfDevices",g.maxNumberOfDevices},{"device",devices}};
        }
        data["gains"]=gains;row["value"]=data;rows.push_back(row);
    }
    return rows;
}
json snapshot(Scope const &q) {
    auto const &s=q.state;auto const &z=s.dataHeatBal->Zone(q.zone);
    auto const &c=*s.dataZoneTempPredictorCorrector;
    json zone{{"address",reinterpret_cast<std::uintptr_t>(&z)},{"Name",z.Name},
        {"IsControlled",z.IsControlled},{"SystemZoneNodeNumber",z.SystemZoneNodeNumber},
        {"Multiplier",z.Multiplier},{"ListMultiplier",z.ListMultiplier},{"Volume",scalar(z.Volume)},
        {"ZoneVolCapMultpSens",scalar(z.ZoneVolCapMultpSens)},{"ZoneVolCapMultpMoist",scalar(z.ZoneVolCapMultpMoist)},
        {"spaceIndexes",z.spaceIndexes},{"leakageParallelPIUNums",z.leakageParallelPIUNums},
        {"NoHeatToReturnAir",z.NoHeatToReturnAir},{"IsReturnPlenum",z.IsReturnPlenum},{"IsSupplyPlenum",z.IsSupplyPlenum},
        {"OutDryBulbTemp",scalar(z.OutDryBulbTemp)},{"HasAdjustedReturnTempByITE",z.HasAdjustedReturnTempByITE},
        {"AdjustedReturnTempByITE",scalar(z.AdjustedReturnTempByITE)}};
    json flags{{"ZoneAirSolutionAlgo",static_cast<int>(s.dataHeatBal->ZoneAirSolutionAlgo)},
        {"doSpaceHeatBalance",s.dataHeatBal->doSpaceHeatBalance},{"DoLatentSizing",s.dataHeatBal->DoLatentSizing},
        {"NumStageCtrZone",c.NumStageCtrZone},{"StageZoneLogic",int_slot(s.dataZoneCtrls->StageZoneLogic,q.zone)},
        {"anyNonMixingRoomAirModel",s.dataRoomAir->anyNonMixingRoomAirModel},
        {"DuctLossSimu",s.dataDuctLoss->DuctLossSimu},{"FlagHybridModel",s.dataHybridModel->FlagHybridModel},
        {"FlagHybridModel_PC",s.dataHybridModel->FlagHybridModel_PC},
        {"multizone_always_simulated",s.afn->multizone_always_simulated},
        {"distribution_simulated",s.afn->distribution_simulated},
        {"AFN_control_type",static_cast<int>(s.afn->simulation_control.type)},
        {"AirflowNetworkFanActivated",s.afn->AirflowNetworkFanActivated}};
    if(contains(s.dataRoomAir->AirModel,q.zone)) {
        auto const &r=s.dataRoomAir->AirModel(q.zone);
        flags["roomAir"]={{"AirModel",static_cast<int>(r.AirModel)},{"SimAirModel",r.SimAirModel}};
    } else flags["roomAir"]=nullptr;
    json aliases{{"zoneHeatBalance",shape(c.zoneHeatBalance)},{"spaceHeatBalance",shape(c.spaceHeatBalance)}};
    aliases["is_zone_row"]=contains(c.zoneHeatBalance,q.zone) ? json(&q.air==&c.zoneHeatBalance(q.zone)) : json(nullptr);
    aliases["is_space_row"]=contains(c.spaceHeatBalance,q.space) ? json(&q.air==&c.spaceHeatBalance(q.space)) : json(nullptr);
    json out{{"air",air_fields(q.air)},{"aliases",aliases},{"zone",zone},{"flags",flags},
        {"fan",fan(s,q.zone)},{"demand",demand(s,q.zone,q.space)},
        {"zone_config",config(s,s.dataZoneEquip->ZoneEquipConfig,q.zone)},
        {"zone_system_node",node(s,z.SystemZoneNodeNumber)}};
    if(q.space>0) {
        out["space_config"]=config(s,s.dataZoneEquip->spaceEquipConfig,q.space);
        if(contains(s.dataHeatBal->space,q.space))
            out["space_system_node"]=node(s,s.dataHeatBal->space(q.space).SystemZoneNodeNumber);
    }
    // Geometry/gain inputs are needed for full sums provenance, not every
    // nested scalar checkpoint. Both complete sums entry/exit retain them.
    if(q.method==Method::Sums) out["spaces"]=spaces(s,q.zone);
    return out;
}
void record(Scope const &q,char const *phase,std::initializer_list<Real> rs,std::initializer_list<Integer> is) noexcept {
    if(!active || !q.selected || !increment(active->attempted)) return;
    try {
        json locals=json::object();for(auto const &r:rs) locals[r.name]=scalar(r.value);
        for(auto const &i:is) locals[i.name]=i.value;
        json event{{"event_ordinal",active->attempted},{"method",name(q.method)},
            {"invocation_ordinal",q.invocation},{"phase",phase},{"zoneNum",q.zone},{"spaceNum",q.space},
            {"parent_method",q.parent ? json(name(q.parent->method)) : json(nullptr)},
            {"parent_invocation_ordinal",q.parent ? json(q.parent->invocation) : json(nullptr)},
            {"clock",clock(q.state)},{"locals",locals},{"state",snapshot(q)}};
        auto bytes=event.dump();if(!active->first) active->stream<<',';active->stream<<bytes;
        if(!active->stream) {active->stream_failed=true;return;}
        active->first=false;increment(active->retained);
    } catch(...) {increment(active->failures);}
}
} // anonymous
Binding::Binding(Capture &c) noexcept : previous(active) { active=&c; }
Binding::~Binding() noexcept { active=previous; }
Scope::Scope(EnergyPlus::EnergyPlusData const &s,Air const &a,Method m,int z,int sp,
             std::initializer_list<Real> rs,std::initializer_list<Integer> is) noexcept
    : state(s),air(a),method(m),zone(z),space(sp),parent(current),exceptions(std::uncaught_exceptions()) {
    current=this;if(!active) return;
    auto at=static_cast<unsigned>(method);if(!increment(active->entered[at])) return;
    invocation=active->entered[at];
    selected=contains(s.dataHeatBal->Zone,z) && s.dataHeatBal->Zone(z).IsControlled &&
        s.dataHeatBal->ZoneAirSolutionAlgo==EnergyPlus::DataHeatBalance::SolutionAlgo::ThirdOrder;
    if(selected) {increment(active->selected[at]);record(*this,"entry",rs,is);}
}
Scope::~Scope() noexcept {
    if(active && selected) {
        bool const unwinding=std::uncaught_exceptions()>exceptions;
        increment(unwinding ? active->unwound[static_cast<unsigned>(method)] : active->normal[static_cast<unsigned>(method)]);
        record(*this,unwinding ? "unwind" : "normal_exit",{},{});
    }
    current=parent;
}
void Scope::point(char const *phase,std::initializer_list<Real> rs,std::initializer_list<Integer> is) const noexcept {
    record(*this,phase,rs,is);
}
bool finish(Capture &c,bool returned,int code,char const *exception) noexcept {
    try {
        json rows=json::array();
        for(unsigned i=0;i<static_cast<unsigned>(Method::Count);++i)
            rows.push_back({{"method",name(static_cast<Method>(i))},{"entered",c.entered[i]},
                {"selected",c.selected[i]},{"normal_exits",c.normal[i]},{"unwinds",c.unwound[i]}});
        json end{{"actual_engine_entry_returned",returned},{"actual_engine_exit_code",returned ? json(code):json(nullptr)},
            {"outer_caught_exception_class",exception ? json(exception):json(nullptr)},{"methods",rows},
            {"attempted_events",c.attempted},{"retained_events",c.retained},{"copy_failures",c.failures},
            {"counter_overflow",c.overflow},{"stream_failed",c.stream_failed},
            {"selection","all actual controlled-zone ThirdOrder calls to six bounded methods; no value/time sampling"},
            {"numeric_equivalence_or_PASS_claimed",false}};
        c.stream<<"],\"terminal_summary\":"<<end.dump()<<"}\n";c.stream.flush();
        return bool(c.stream)&&!c.stream_failed&&!c.overflow&&c.failures==0&&c.attempted==c.retained;
    } catch(...) {return false;}
}
} // namespace ControlledAirObservation

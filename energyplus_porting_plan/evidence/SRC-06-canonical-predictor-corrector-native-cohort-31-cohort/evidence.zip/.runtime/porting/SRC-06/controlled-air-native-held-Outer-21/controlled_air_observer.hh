#pragma once
#include <EnergyPlus/ZoneTempPredictorCorrector.hh>
#include <array>
#include <cstdint>
#include <initializer_list>
#include <ostream>

namespace ControlledAirObservation {
using Air = EnergyPlus::ZoneTempPredictorCorrector::ZoneSpaceHeatBalanceData;
enum class Method : unsigned { Predict, Update, PredictedLoad, Sums, Temperature, Humidity, Count };
struct Real { char const *name; double value; };
struct Integer { char const *name; std::int64_t value; };
struct Capture {
    explicit Capture(std::ostream &stream) noexcept : stream(stream) {}
    std::ostream &stream;
    std::array<std::uint64_t, static_cast<unsigned>(Method::Count)> entered{};
    std::array<std::uint64_t, static_cast<unsigned>(Method::Count)> selected{};
    std::array<std::uint64_t, static_cast<unsigned>(Method::Count)> normal{};
    std::array<std::uint64_t, static_cast<unsigned>(Method::Count)> unwound{};
    std::uint64_t attempted = 0, retained = 0, failures = 0;
    bool first = true, overflow = false, stream_failed = false;
};
class Binding {
public:
    explicit Binding(Capture &) noexcept;
    ~Binding() noexcept;
private:
    Capture *previous;
};
class Scope {
public:
    Scope(EnergyPlus::EnergyPlusData const &, Air const &, Method, int zone, int space,
          std::initializer_list<Real> = {}, std::initializer_list<Integer> = {}) noexcept;
    ~Scope() noexcept;
    Scope(Scope const &) = delete;
    Scope &operator=(Scope const &) = delete;
    void point(char const *, std::initializer_list<Real> = {}, std::initializer_list<Integer> = {}) const noexcept;
    EnergyPlus::EnergyPlusData const &state;
    Air const &air;
    Method method;
    int zone, space;
    std::uint64_t invocation = 0;
    Scope *parent = nullptr;
    bool selected = false;
private:
    int exceptions;
};
bool finish(Capture &, bool engine_returned, int engine_exit, char const *exception) noexcept;
} // namespace ControlledAirObservation

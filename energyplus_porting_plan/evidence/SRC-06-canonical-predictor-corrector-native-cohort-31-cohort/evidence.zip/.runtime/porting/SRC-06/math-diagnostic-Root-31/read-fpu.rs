﻿fn read_fpu(){let mut cw=0u16;let mut mx=0u32;unsafe{std::arch::asm!("fnstcw [{}]",in(reg)&mut cw,options(nostack,preserves_flags));std::arch::asm!("stmxcsr [{}]",in(reg)&mut mx,options(nostack,preserves_flags));}println!("thread={:?} x87={cw:04x} mxcsr={mx:08x}",std::thread::current().name());}
fn main(){read_fpu();std::thread::spawn(read_fpu).join().unwrap();}

from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-predictor-corrector-cohort-application-31-cohort';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-controlled-zone-cohort-held-Audit-31/manifest.json');assert mr['sha256']=='4689a118282b54227342ac1d216008cf0c30246bc4e736dd7efe2aefefa86411';m=json.loads(checked(mr));pr=m['independent_full_Source_and_fixture_peer'];assert pr['sha256']=='b406ffed3551b031541474a8cfc78ea3b6481a6e253afc811f79605d78651b8d';peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peerfiles={v['canonical_path']:v for v in peer['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='e110c389b7333e1e0770bcc80f334fa6e68c1b2d' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4503 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(f['reviewed_draft_whole'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==4 and len(new)==0 and tests==0 and set(selected)==set(peerfiles)
for k in ['accepted31_production_actual_review','production31_producer','prior_complete_compiler_Source_plan','full4503_actual_archive_live_plan_readback','original_draft','fixture_derivation','actual_Native_capture']:checked(m[k])
for f in m['files'][:2]:
 a=checked(f['before']);b=checked(f['proposed']);assert b.startswith(a+b'\n') and b[len(a):].count(b'#[cfg(test)]')==1 and b'impl ' in b[len(a):]
fix=m['files'][3];a=json.loads(checked(fix['before']).split(b'r###"',1)[1].rsplit(b'"###;',1)[0]);b=json.loads(checked(fix['proposed']).split(b'r###"',1)[1].rsplit(b'"###;',1)[0]);assert {k:v for k,v in b.items() if not k.startswith('corrector_')}==a and len(a['cases'])==len(b['corrector_cases'])==1168
assert checked(m['files'][2]['before']).count(b'#[test]')==checked(m['files'][2]['proposed']).count(b'#[test]')==1
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4503 and sum(n.endswith('.rs') for n in rows)==4490
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Full four existing test-only Sources and entire streamed Native fixture reviewed independently; Root independently authenticates committed31 parent, cfg(test) prefixes, original predictor subtree and complete4503 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4503,final_inputs=4503,final_Rust_sources=4490,selected_Rust=4,new_Rust=0,literal_applications=8,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read all three code diffs, original seed/check helpers, derivation and final independent streaming peer. Two cfg(test)-only loaders preserve complete production prefixes and restore captured function-entry operands on genuine physical Nodes and private opaque surface owners. One existing test retains every predictor assertion and all1168 cases/77 shortened; added1168 full correctAirTemp calls include real Sums and humidity with all67 captured Air scalars/six histories and Node/fan/demand writes plus real returned temperature change asserted exactbits. Geometry/gain values are true first-consumed upstream inputs; no child outputs or current-operation coefficients injected. All original fixture data semantic subtree exact. Native cache traces/recurrence and unconsumed members explicitly unobserved, no production getter/fullrun proof. Historical31 production proof inherited for unchanged production bytes, no CLI/Native rerun. Exactly one focused existing lib test remains required',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

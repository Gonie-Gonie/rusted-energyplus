"""Isolated test-only continuation; no canonical writes, engine, Cargo or tests."""
from pathlib import Path
import hashlib, json, re, shutil, struct, difflib, subprocess
from collections import Counter

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
P=D/'source-controlled-zone-cohort-draft-Audit-31'
LOGICAL=D/'source-controlled-zone-corrector-draft-Outer-31-03'
TEST='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/native_cohort.rs'
FIX=TEST.rsplit('/',1)[0]+'/fixtures/native_prediction_b.rs'
EQ='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'
SURF='crates/ep_runtime/src/heat_balance/selected_heat_balance_input/surface.rs'
def need(x,m):
    if not x: raise ValueError(m)
def ref(p):
    p=p.resolve()
    with p.open('rb') as h: sha=hashlib.file_digest(h,'sha256').hexdigest()
    return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':sha,'bytes':p.stat().st_size}
def unique(pairs):
    d={}
    for k,v in pairs:
        need(k not in d,'duplicate '+k); d[k]=v
    return d
def strip(x):
    if isinstance(x,dict):
        if 'value_bits' in x:
            need(set(x)=={'value_bits'} and re.fullmatch('[0-9a-f]{16}',x['value_bits']),'f64 transport')
            return x['value_bits']
        return {k:strip(v) for k,v in x.items() if k not in ('address','owner_address','state_address')}
    if isinstance(x,list): return [strip(v) for v in x]
    need(not isinstance(x,float),'JSON decimal float'); return x
def state(e):
    s=e['state']; f=s['fan']; n=s['zone_system_node']
    return strip({'air':s['air'],'zone':s['zone'],'clock':e['clock'],'flags':s['flags'],
      'node':n['value'],'node_ordinal':n['index'],'node_name':n['NodeID'],
      'fan':{'TempTstatAir':f['TempTstatAir']['value'],'LoadCorrectionFactor':f['LoadCorrectionFactor']['value'],
       'TempControlType':f['TempControlType']['value'],'setpoints':f['zoneTstatSetpts']['value'],
       **{k:f[k]['value'] for k in ('SumConvHTRadSys','SumConvPool','SumLatentHTRadSys','SumLatentPool')}},
      'demand':{'Setback':s['demand']['Setback']['value'],'DeadBandOrSetback':s['demand']['DeadBandOrSetback']['value'],
       'CurDeadBandOrSetback':s['demand']['CurDeadBandOrSetback']['value'],'sensible':s['demand']['zone']['value']},
      'config':s['zone_config']['value']})

need(not P.exists(),'immutable draft destination already exists')
P.mkdir()
capture=D/'controlled-air-native-capture-Root-21/capture.json'
need(ref(capture)['sha256']=='6845958c28d6eef55ce89100a13f2001d43ae7ca2fb3e86b2c189d2820b4c47f','capture custody')
cap=json.loads(capture.read_bytes()); need(cap['accepted'] and not cap['findings'],'accepted capture')
raw=Path(cap['full_retained_observation']['path'])
if not raw.is_absolute(): raw=R/raw
need(ref(raw)==cap['full_retained_observation'],'raw observation custody')
reader=R/'.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'
rb=reader.read_bytes()
need(ref(reader)['sha256']=='8e7f05196fe567c052352d4d0fe501eb02a0f8e5a623c20f7dcd3db669f6bab8','reader')
adapted=rb.replace(b"literal('],\"summary\":')",b"literal('],\"terminal_summary\":')")
need(hashlib.sha256(adapted).hexdigest()=='22d630e116d9dc2d5fdb7eb83db27b2452be7c14ce39c15107f636bfe7d784cf','reader sole terminal-key bridge')
ns={}; exec(compile(adapted,'<read-only-terminal-key-adapter>','exec'),ns)
rows=[]; active=None; events=0; positive=0; groups=Counter()
def visit(e):
    global active,events,positive
    events+=1; need(e['event_ordinal']==events,'event ordinal')
    m,p=e['method'],e['phase']
    if m=='correctAirTemp':
        if p=='entry':
            need(active is None and e['invocation_ordinal']==len(rows)+1,'corrector entry order')
            s=e['state']; flags=s['flags']; z=s['zone']
            need(e['zoneNum']==1 and e['spaceNum']==0 and s['aliases']['is_zone_row'] is True,'same actual zone Air')
            need(z['IsControlled'] and not z['IsReturnPlenum'] and not z['IsSupplyPlenum'] and not z['leakageParallelPIUNums'],'finite controlled branch')
            need(flags['ZoneAirSolutionAlgo']==0 and flags['roomAir']=={'AirModel':1,'SimAirModel':False},'ThirdOrder Mixing')
            need(not any(flags[k] for k in ('doSpaceHeatBalance','DoLatentSizing','anyNonMixingRoomAirModel','DuctLossSimu','FlagHybridModel','FlagHybridModel_PC','multizone_always_simulated','distribution_simulated','AFN_control_type','AirflowNetworkFanActivated')),'excluded positive subsystem')
            active={'invocation':e['invocation_ordinal'],'arguments':strip(e['locals']),'entry':state(e),
                    'native_Air_address':s['air']['owner_address'],'native_Node_address':s['zone_system_node']['value']['address']}
            positive+=any(int(i['physical']['value']['MassFlowRate']['value_bits'],16)&0x7fffffffffffffff for i in s['zone_config']['value']['InletNode']['values'])
            groups[(e['clock']['WarmupFlag'],e['clock']['KickOffSimulation'],e['locals']['useZoneTimeStepHistory'])]+=1
        elif p=='temperature_return_value':
            need(active is not None and e['invocation_ordinal']==active['invocation'],'return parent')
            active['return_value']=strip(e['locals'])
        elif p=='normal_exit':
            need(active is not None and e['invocation_ordinal']==active['invocation'],'corrector exit')
            active['exit']=state(e)
            need(all(k in active for k in ('sums_inputs','sums_exit','humidity_entry','humidity_exit','return_value')),'complete children')
            need(active['entry']['config']==active['exit']['config'],'inlets/config unchanged by corrector')
            rows.append(active); active=None
    if m in ('calcZoneOrSpaceSums','correctHumRat') and e['parent_method']=='correctAirTemp':
        need(active is not None and e['parent_invocation_ordinal']==active['invocation'],'true nested parent')
        need(e['state']['air']['owner_address']==active['native_Air_address'],'same nested Air')
        need(e['state']['zone_system_node']['value']['address']==active['native_Node_address'],'same nested Node')
        if m=='calcZoneOrSpaceSums':
            if p=='entry':
                need(e['locals']=={'CorrectorFlag':1} and 'sums_inputs' not in active,'single genuine corrector sums')
                need(state(e)['config']==active['entry']['config'],'same real inlets at first consumption')
                active['sums_inputs']=strip(e['state']['spaces'])
            elif p=='normal_exit': active['sums_exit']=state(e)
        elif p=='entry':
            need('humidity_entry' not in active,'single nested humidity')
            active['humidity_entry']=state(e)
        elif p=='normal_exit': active['humidity_exit']=state(e)
transport=ns['read'](raw,need,unique,visit)
need(active is None and len(rows)==1168 and events==30445 and positive==810,'complete actual cohort census')
need(transport['summary']==cap['observation_checks']['terminal_summary'],'terminal summary exact')
old_fixture=(R/FIX).read_bytes()
prefix=b'const NATIVE_PREDICTION_COHORT_JSON: &str = r###"'
payload=old_fixture.split(prefix,1)[1].rsplit(b'"###;',1)[0]
fixture=json.loads(payload,object_pairs_hook=unique)
original=json.loads(payload)
tables={}; by_value={}; packed=[]
for row in rows:
    out={k:v for k,v in row.items() if k not in ('entry','sums_inputs','sums_exit','humidity_entry','humidity_exit','exit')}
    for phase in ('entry','sums_inputs','sums_exit','humidity_entry','humidity_exit','exit'):
        key=json.dumps(row[phase],sort_keys=True,separators=(',',':'),ensure_ascii=False)
        t=tables.setdefault(phase,[]); idx=by_value.setdefault(phase,{})
        if key not in idx: idx[key]=len(t);t.append(row[phase])
        out[phase]=idx[key]
        need(t[out[phase]]==row[phase],'lossless interning')
    packed.append(out)
fixture['corrector_case_count']=1168; fixture['corrector_state_tables']=tables;fixture['corrector_cases']=packed
need({k:v for k,v in fixture.items() if not k.startswith('corrector_')}==original,'complete original predictor data preserved')
targets=[EQ,SURF,TEST,FIX]
for rel in targets:
    source=LOGICAL/'proposed'/rel if rel==EQ else R/rel
    dst=P/'before'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(source.read_bytes())
    prop=P/'proposed'/rel;prop.parent.mkdir(parents=True,exist_ok=True);prop.write_bytes(source.read_bytes())
(P/'proposed'/FIX).write_bytes(b'// Test-only exact actual Native predictor/corrector entry states; no production reads.\n'+prefix+json.dumps(fixture,separators=(',',':'),ensure_ascii=False).encode()+b'"###;\n')
note={'schema':'src06-consolidated-corrector-fixture-readonly-derivation.v1','status':'isolated unsealed test preparation; no test or engine executed',
 'author_Source':ref(Path(__file__)),'accepted_capture':ref(capture),'raw_observation':ref(raw),'reader':ref(reader),
 'adapted_reader_sha256':hashlib.sha256(adapted).hexdigest(),'logical31':ref(LOGICAL/'draft.json'),
 'original_predictor_fixture':ref(P/'before'/FIX),'all_original_predictor_data_exact':True,'existing_cases_preserved':len(original['cases']),
 'corrector_cases':1168,'actual_positive_inlet_cases':positive,'events_streamed':events,
 'groups':[{'warmup':k[0],'kickoff':k[1],'use_zone_history':k[2],'count':v} for k,v in sorted(groups.items())],
 'lossless_corrector_state_interning':{k:len(v) for k,v in tables.items()},'fixture':ref(P/'proposed'/FIX),
 'scope':'Real correctAirTemp entry to exit, including actual sums/humidity children; numerical outputs and captured owner writes only.',
 'unobserved':['Native normal-Cp function-local cache prestate','Native Psat cache hit/miss/tag-write trace and recurrence/error owner indices','Air hmThermalMassMultErrIndex','unconsumed physical Node members and gain pointer targets'],
 'no_cached_answers_or_current_operation_intermediates_seeded':True,
 'sums_input_boundary':'Observed at nested real Sums entry; finite Mixing prefix does not mutate geometry/gain inputs. Only first-consumed upstream geometry/gain values are restored, not child output sums.'}
(P/'derivation.json').write_text(json.dumps(note,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'draft_directory':str(P),'derivation':ref(P/'derivation.json'),'fixture':ref(P/'proposed'/FIX)}))

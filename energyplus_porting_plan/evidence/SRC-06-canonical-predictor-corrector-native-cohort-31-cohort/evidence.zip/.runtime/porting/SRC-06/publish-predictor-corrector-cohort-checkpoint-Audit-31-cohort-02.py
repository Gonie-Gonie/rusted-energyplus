"""Root-only compact test-cohort publication; no compiler, engine or tests.

Exactly one successful focused unit receipt is required. Production B/A results
are inherited from accepted31; this publisher claims no updated-snapshot CLI execution.
"""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-predictor-corrector-native-cohort-31-cohort'
BACK=D/'predictor-corrector-cohort-publication-readback-Audit-31-cohort-02'
def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':h,'bytes':p.stat().st_size}
def checked(row):
    p=(R/row['path']).resolve();got=ref(p)
    assert got['sha256']==row['sha256'] and got['bytes']==row.get('bytes',row.get('size_bytes',got['bytes'])),row['path']
    return p
def load(p):return json.loads(p.read_bytes())
def contains(value,row):
    if isinstance(value,dict):return (value.get('path'),value.get('sha256'))==(row['path'],row['sha256']) or any(contains(v,row) for v in value.values())
    return isinstance(value,list) and any(contains(v,row) for v in value)
def write(p,x):p.write_bytes((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def accepted(row):
    x=load(checked(row));assert x['accepted'] and not x['findings'];return x

def main(args):
    assert args.publish and not PUBLIC.exists() and not BACK.exists()
    template_path=args.template.resolve();assert ref(template_path)['sha256']==args.template_sha256
    t=load(template_path);assert t['status']=='READY_FOR_ROOT_REVIEW_AND_PUBLICATION'
    assert ref(Path(__file__))==t['publisher_Source']
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==t['base_HEAD']
    producer=load(checked(t['producer']));plan=load(checked(t['complete_plan']))
    assert len(plan['entries'])==4503 and sum(row['path'].endswith('.rs') for row in plan['entries'])==4490
    assert producer['new_test_bodies']==0 and producer['existing_test_bodies_extended']==1
    assert producer['original_predictor_cases']==producer['corrector_cases']==1168 and producer['positive_inlet_cases']==810
    assert producer['production_science_body_changes']==0 and producer['cfg_test_owner_prefix_bytes_exact']
    assert producer['complete_original_predictor_test_inverse_exact']
    for row in producer['files']:assert (R/row['canonical_path']).read_bytes()==checked(row['proposed']).read_bytes()
    actual=accepted(t['accepted_unit_review']);unit=load(checked(t['successful_unit_receipt']))
    assert unit['schema']=='recorded-porting-command.v1' and unit['exit_code']==0 and unit['launch_error'] is None
    assert unit['source_bytes_match_before_and_after'] and Path(unit['cwd']).resolve()==R
    command=unit['command'];name=producer['test_filter']
    full_name='heat_balance::ordinary_air_heat_balance::predictor_corrector::lifecycle::prediction::native_cohort::'+name
    assert command==['cargo','test','--locked','-p','ep_runtime','--lib',full_name,'--','--exact','--nocapture']
    output=checked(unit['stdout']).read_text(encoding='utf8')
    assert re.search(r'\brunning 1 test\b',output) and re.search(r'test result: ok\. 1 passed; 0 failed;',output)
    assert re.search(r'test [^\r\n ]*'+re.escape(name)+r' \.\.\. ok',output)
    for row in (t['producer'],t['complete_plan'],t['successful_unit_receipt'],t['Root_application']):
        assert contains(actual,row),row['path']
    snap=load(checked(unit['source_snapshot']));observed={row['historical_path']:row for row in snap['files']}
    assert len(observed)==4503
    for row in plan['entries']:
        saved=observed[row['path']]
        assert saved['archive']['sha256']==row['final_sha256'] and saved['size_bytes']==row['final_bytes']
    inherited=accepted(t['accepted31_review']);assert inherited['same4503_archived_inputs_exact_final_plan']
    assert inherited['actual_test_bodies_executed']==0
    inherited_runs=[load(checked(inherited[key])) for key in ('actual_B','actual_A24')]
    assert [run['exit_code'] for run in inherited_runs]==[6,0]
    assert all(run['launch_error'] is None and run['source_bytes_match_before_and_after'] for run in inherited_runs)
    assert inherited_runs[0]['source_snapshot']==inherited_runs[1]['source_snapshot']
    assert actual['actual_executed_test_bodies']==1 and actual['new_test_bodies']==0
    assert producer['existing_test_bodies_extended']==1
    assert producer['accepted31_production_actual_review']==t['accepted31_review']
    # Historical production31 executed its own snapshot. Its science bodies are
    # inherited byte-exact after cfg(test) exclusion, not reexecuted here.
    assert unit['source_snapshot']!=inherited_runs[0]['source_snapshot']
    base=R/'energyplus_porting_plan';names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']
    docs={name:(base/name).read_bytes() for name in names};old_plan=(base/'plan.json').read_bytes();old_json=json.loads(old_plan)
    for name,b in [*docs.items(),('plan.json',old_plan)]:
        assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+name],cwd=R)
        b.decode('utf8','strict')
    previous=load(checked(t['previous_checkpoint']));assert (previous['A'],previous['B'])==('14/54','14/64')
    capture=accepted(t['actual_Native_capture']);captured_output=Path(capture['output_directory']).resolve()
    files={}
    def add(p):
        p=p.resolve();row=ref(p)
        assert p.suffix.lower() not in ('.zip','.exe','.dll','.a','.obj','.map')
        assert row['bytes']<40*1024*1024 and not p.name.endswith('.observation.json')
        if p.is_relative_to(R):archive_path=p.relative_to(R).as_posix()
        else:
            assert p.parent==captured_output and p.name in ('eplusout.eso','eplusout.rdd','eplusout.mdd')
            archive_path='Native-capture-reported/'+p.name
        assert archive_path not in files or files[archive_path]['original']==row
        files[archive_path]={'original':row,'archive_path':archive_path,'physical':p}
    for row in t['finite_archive_inputs']:add(checked(row))
    for p in (Path(__file__),template_path,checked(t['accepted_unit_review']),checked(t['successful_unit_receipt'])):add(p)
    for key in ('stdout','stderr','source_snapshot'):add(checked(unit[key]))
    recorder=unit.get('executed_launcher',{}).get('archive')
    assert recorder is not None;add(checked(recorder))
    app=accepted(t['Root_application'])
    for row in (t['Root_application'],app['author_Source'],actual['author_Source']):add(checked(row))
    if 'launcher_Source' in actual:add(checked(actual['launcher_Source']))
    for row in t['independent_peers']:accepted(row);add(checked(row))
    PUBLIC.mkdir(parents=True);BACK.mkdir()
    (BACK/'plan-before.json').write_bytes(old_plan)
    for name,b in docs.items():p=BACK/'docs-before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    archive=PUBLIC/'evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,item in sorted(files.items()):assert ref(item['physical'])==item['original'];z.write(item['physical'],arcname=name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(files)
        for name,item in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['original']['sha256']
    inventory=PUBLIC/'manifest.json'
    write(inventory,{'schema':'src06-compact-predictor-corrector-cohort-archive.v1','archive':ref(archive),
        'entries':[{k:v for k,v in item.items() if k!='physical'} for _,item in sorted(files.items())],
        'scope':t['finite_archive_scope'],'large_binary_raw_or_recursive_archives_included':False})
    summary=dict(t['summary_template']);summary.update(schema='src06-canonical-predictor-corrector-Native-cohort.v1',
        status='One existing focused cohort test passed: all1168 predictor and1168 whole-corrector entries',
        producer=t['producer'],complete_compiler_plan=t['complete_plan'],independent_peers=t['independent_peers'],
        actual_unit_receipt=t['successful_unit_receipt'],Root_actual_unit_review=t['accepted_unit_review'],
        inherited_production31={'accepted_actual_review':t['accepted31_review'],'B_receipt':inherited['actual_B'],'A24_receipt':inherited['actual_A24'],
            'B_incomplete_boundary':inherited['B_frontier'],'new_final_CLI_build_or_execution':False,
            'scope':'Historical production31 B/A24 and5352 proof inherited for byte-exact production bodies. The updated test-only compiler snapshot was not used by those CLI executions.'},
        actual_Native_capture=t['actual_Native_capture'],actual_Native_reported_comparison=t['actual_Native_reported_comparison'],
        archive=ref(archive),archive_manifest=ref(inventory),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
    summary_path=PUBLIC/'summary.json';write(summary_path,summary)
    relative='evidence/'+PUBLIC.name+'/summary.json'
    for name,b in docs.items():
        link=('../' if name.startswith('cards/') else '')+relative
        spec=t['doc_appends'][name];paragraph='\n\n['+spec['title']+']('+link+'). '+spec['text']+'\n'
        assert '\ufffd' not in paragraph and '?' not in paragraph and '{{' not in paragraph and (base/name).read_bytes()==b
        (base/name).write_bytes(b+paragraph.encode('utf8'))
    updated=json.loads(old_plan);task=next(row for row in updated['tasks'] if row['id']=='SRC-06')
    key='canonical_predictor_corrector_native_cohort_31';assert key not in task
    task[key]={'path':summary_path.relative_to(R).as_posix(),'sha256':ref(summary_path)['sha256'],'size_bytes':summary_path.stat().st_size}
    inverse=json.loads(json.dumps(updated));del next(row for row in inverse['tasks'] if row['id']=='SRC-06')[key]
    assert inverse==old_json and (base/'plan.json').read_bytes()==old_plan;write(base/'plan.json',updated)
    result={'status':'PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK','summary':ref(summary_path),'archive':ref(archive),
        'archive_manifest':ref(inventory),'archive_entries':len(files),'base_HEAD':head,'publisher':ref(Path(__file__)),
        'plan_before':ref(BACK/'plan-before.json'),'exactly_one_new_SRC06_key':key,
        'Cargo_Native_or_tests_executed':False,'Git_mutated':False,'gates_or_tolerances_changed':False}
    path=BACK/'publication-readback.json';write(path,result);print(json.dumps(ref(path)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--template',type=Path,required=True);p.add_argument('--template-sha256',required=True)
    p.add_argument('--publish',action='store_true');main(p.parse_args())

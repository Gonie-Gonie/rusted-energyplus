from pathlib import Path
import ast,hashlib,json,re,subprocess,sys,tomllib
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-predictor-corrector-cohort-main-application-31-02';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-controlled-zone-cohort-main-held-Audit-31-02/manifest.json');assert mr['sha256']==sys.argv[1];m=json.loads(checked(mr));pr=m['independent_full_safe_runner_peer'];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft']
peerfiles={f['canonical_path']:f for f in peer['files']};assert len(peerfiles)==7
original=json.loads(checked(m['original_worker_packet']));oldapp=json.loads(checked(m['original_Root_application']));assert oldapp['accepted'] and not oldapp['findings'] and oldapp['producer']==m['original_worker_packet']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='e110c389b7333e1e0770bcc80f334fa6e68c1b2d'
assert set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())==set(oldapp['selected']) and not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R).strip()
oldplan=json.loads(checked(m['current_prior_complete_compiler_Source_plan']));oldrows={v['path']:v for v in oldplan['entries']};snapshot={v['historical_path']:v for v in json.loads(checked(m['actual_current_WIP_snapshot']))['files']};assert len(oldrows)==4503 and set(oldrows)==set(snapshot)
inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert set(oldrows)==inventory
for n,v in oldrows.items():assert (R/n).read_bytes()==checked(v['source'])==checked(snapshot[n]['archive']) and (R/n).stat().st_size==v['final_bytes']==snapshot[n]['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};rewrites=[];registration=0
for f in m['files']:
 n=f['canonical_path'];a=checked(f['before']);b=checked(f['proposed']);current=checked(f['current_prior_WIP']);assert n not in selected and current==(R/n).read_bytes()==checked(oldrows[n]['source']) and (R/n).stat().st_nlink==1
 assert a==subprocess.check_output(['git','show',head+':'+n],cwd=R) and checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and checked(f['reviewed_draft_whole'])==b
 assert b==checked(peerfiles[n]['proposed']) and a==checked(peerfiles[n]['before'])
 if n.endswith('.rs'):
  assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);registration+=b.count(b'#[test]')-a.count(b'#[test]')
 else:
  assert n=='crates/ep_runtime/Cargo.toml' and f['TOML_parse_zero'];cargo=tomllib.loads(b.decode());assert cargo['features']['native-controlled-air-cohort']==[] and dict(name='native_controlled_air_cohort',path='src/lib.rs',harness=False,**{'required-features':['native-controlled-air-cohort']}) in cargo['test']
 if current!=b:rewrites.append(n)
 selected[n]=f
assert len(selected)==7 and len(rewrites)==4 and set(rewrites)==set(m['actual_changed_current_files']) and registration==-1
for k in ['original_semantic_and_fixture_peer','historical31_complete_compiler_Source_plan','accepted31_production_actual_review','full4503_current_WIP_readback','Root_thread_context_diagnosis']:checked(m[k])
for r in m['preserved_failed_worker_receipts']:
 failed=json.loads(checked(r));assert failed['exit_code']==101 and failed['source_bytes_match_before_and_after']
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory and len(rows)==4503 and sum(n.endswith('.rs') for n in rows)==4490
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n in rewrites:(R/n).write_bytes(checked(selected[n]['proposed']))
for n,v in rows.items():assert(R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,original_semantic_and_fixture_peer=m['original_semantic_and_fixture_peer'],prior_application=m['original_Root_application'],complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,selected_existing_files=7,selected_Rust=6,selected_Cargo_manifests=1,new_files=0,actual_rewritten_files=rewrites,literal_applications=14,new_test_bodies=0,existing_cohort_body_relocated=1,normal_libtest_registration_delta=-1,all4503_prior_WIP_archive_live_equal=True,all7_historical31_Git_before_whole_equal=True,all4503_final_plan_live_equal=True,preserved_failed_worker_receipts=m['preserved_failed_worker_receipts'],Root_thread_context_diagnosis=m['Root_thread_context_diagnosis'],semantic_review='Root read original whole Native cohort, all seven revised Source/config diffs, installed libtest worker-spawn authority and real main/worker property diagnostics. Same existing cohort body and all asserts/data retained; remove only libtest registration and route it synchronously from dedicated harness=false process main through cfg(test) feature and private-leaf associated bridge. Normal library tests exclude this large fixture without explicit feature. No private module production visibility widening, new dependency, FP control write, math/tolerance or expected-data change. Exact historical31 before/Git plus ONLY known prior4 applied WIP permitted; full4503 current and final rehash. Three prior failed/diagnostic executions preserved; successful all1168 main cohort remains pending. Production31 evidence inherited, no updated CLI/Native execution claim.',Cargo_tests_or_Native_executed=False,author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

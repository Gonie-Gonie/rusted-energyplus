"""Private Source42 genuine controlled FillRemaining continuation; no main/Cargo."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'source-fill-remaining-controlled-draft-Outer-42';C='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(row):
 p=R/row['path'];r=ref(p);assert r['sha256']==row['sha256'] and r['bytes']==row.get('bytes',r['bytes']);return p
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def replace(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
def main():
 assert not O.exists()
 ap=D/'Root-source-node-setpoint-endrun-actual-review-41-02/review.json';actual=json.loads(ap.read_bytes())
 assert ref(ap)['sha256']=='574277c9e4ca17c9007371f482ef7c02b3b38656a96ea394f3a8e21022e4e001' and actual['accepted']
 priorp=checked(actual['complete_compiler_plan']);prior=json.loads(priorp.read_bytes());assert(prior['inputs'],prior['Rust_sources'])==(4508,4495)
 index={x['path']:x for x in prior['entries']};bp=json.loads(checked(actual['actual_B']).read_bytes());snapshot=bp['source_snapshot'];sr=json.loads(checked(snapshot).read_bytes());arch={x['historical_path']:x for x in sr['files']}
 f1='crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/remaining.rs'
 f2='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs'
 f3='crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs'
 before={}
 for p in (f1,f2,f3):
  b=(R/p).read_bytes();assert (hashlib.sha256(b).hexdigest(),len(b))==(index[p]['final_sha256'],index[p]['final_bytes'])
  assert b==checked(arch[p]['archive']).read_bytes();before[p]=b.decode('utf8')
 proposed=dict(before)
 proposed[f1]=replace(proposed[f1],"    pub(crate) hvac_manager: &'a crate::heat_balance::ordinary_hvac_manager::SourceHvacManager,","    pub(crate) hvac_manager: &'a crate::heat_balance::ordinary_hvac_manager::SourceHvacManager,\n    pub(crate) equipment: &'a crate::heat_balance::ordinary_equipment::OrdinaryEquipment,")
 totals=['total_occupants','total_average_occupants','total_area','total_voz_min','total_mech_vent_vol','total_nat_vent_vol','total_infil_vol','total_voz_dyn','total_mech_vent_rate_occ','total_nat_vent_rate_occ','total_infil_rate_occ','total_voz_dyn_occ']
 for x in totals:proposed[f1]=replace(proposed[f1],f'        let {x} = 0.0;',f'        let mut {x} = 0.0;')
 proposed[f1]=replace(proposed[f1],'            let _zone_multiplier =','            let zone_multiplier =')
 old='''                if zone.is_controlled {
                    let _air_loop_name = String::new();
                    return Err(Error::Unavailable(
                        "actual FillRemaining controlled ZoneEquipConfig.NumInletNodes6370",
                    ));
                }
'''
 fragment=D/'source-fill-remaining-controlled-author-Outer-42/controlled.rs.fragment'
 proposed[f1]=replace(proposed[f1],old,fragment.read_text(encoding='utf8'))
 proposed[f2]=replace(proposed[f2],'                    controller: &session.controller,\n                    predefined_summary: &session.comfort_summary,','                    equipment: required(reports.source_zone_equipment.as_ref(),\n                        "actual same ZoneEquipConfig before FillRemaining5213")?,\n                    controller: &session.controller,\n                    predefined_summary: &session.comfort_summary,')
 # This is the genuine Native ctor field; positive People remains before its real907 writer.
 proposed[f3]=replace(proposed[f3],'    pub(crate) is_nominal_controlled: bool,','    pub(crate) is_nominal_controlled: bool,\n    /// Native ZoneData.hh645 ctorfalse; sole true writer IHG907 follows positive People input.\n    pub(crate) is_nominal_occupied: bool,')
 proposed[f3]=replace(proposed[f3],'            is_nominal_controlled: false,','            is_nominal_controlled: false,\n            is_nominal_occupied: false,')
 # Byte-precise whole forward+inverse applications, including LF transport.
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'literal-applier','exec'),ns)
 rows=[]
 for i,p in enumerate((f1,f2,f3),1):
  a=before[p].encode();b=proposed[p].encode();bf=put(O/'before'/p,a);pp=put(O/'proposed'/p,b)
  fw=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile=p,tofile=p)).encode()
  iv=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile=p,tofile=p)).encode()
  assert ns['apply'](a,fw)==b and ns['apply'](b,iv)==a
  fr=put(O/'diffs'/f'{i:02}.forward.diff',fw);ir=put(O/'diffs'/f'{i:02}.inverse.diff',iv)
  run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,cwd=R,capture_output=True)
  stdout=put(O/'parse'/f'{i:02}.stdout',run.stdout);stderr=put(O/'parse'/f'{i:02}.stderr',run.stderr);assert run.returncode==0
  rows.append(dict(canonical_path=p,before_absent=False,before=bf,proposed=pp,literal_inverse=put(O/'literal-inverse'/p,a),forward_diff=fr,inverse_diff=ir,Source_only_parse=dict(exit_code=run.returncode,stdout=stdout,stderr=stderr)))
 plan=copy.deepcopy(prior);plan.update(schema='src06-fill-remaining-controlled-logical-proposed-Source-plan.v1',logical_parent=ref(priorp),accepted41_parent_review=ref(ap),selected_existing=3,selected_new=0)
 for row in rows:
  item=next(x for x in plan['entries']if x['path']==row['canonical_path']);item.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'],origin='whole private Source42 controlled FillRemaining proposal')
 planp=O/'complete-proposed-compiler-Source-plan.json';write(planp,plan)
 # Retain complete Native wholes + strict useful extents with real pinned Git recovery.
 native=[]
 for p,extents in [('src/EnergyPlus/OutputReportTabular.cc',[(6333,6537),(6539,6542)]),('src/EnergyPlus/DataHeatBalance.hh',[(630,650)]),('src/EnergyPlus/InternalHeatGains.cc',[(895,919)]),('src/EnergyPlus/OutputReportPredefined.cc',[(1766,1835),(1837,1915)]),('src/EnergyPlus/OutputReportPredefined.hh',[(231,254)])]:
  b=(N/p).read_bytes();g=subprocess.run(['git','show',C+':'+p],cwd=N,capture_output=True,check=True).stdout;assert b==g
  lines=b.splitlines(True);out=[]
  for first,last in extents:
   q=O/'Native'/p/(str(first)+'-'+str(last)+'.txt');rr=put(q,b''.join(lines[first-1:last]));out.append(dict(first_line=first,last_line=last,source=rr))
  native.append(dict(Native_path=p,whole=ref(N/p),pinned_Git=C,Git_whole_exact=True,extents=out))
 # Whole-crates caller/member lineage and positive People admission context.
 terms=['SourceRemainingPredefinedOwners','SelectedZoneData {','is_nominal_occupied','source_zone_equipment_config(','number_inlet_nodes(','inlet_node_air_loop_number(']
 hits=[]
 for q in sorted((R/'crates').rglob('*.rs')):
  if 'fixtures'in q.parts:continue
  p=q.relative_to(R).as_posix();s=proposed.get(p,q.read_text(encoding='utf8'))
  lines=[dict(line=n,literal=x)for n,x in enumerate(s.splitlines(),1)if any(t in x for t in terms)]
  if lines:hits.append(dict(path=p,whole_sha256=hashlib.sha256(s.encode()).hexdigest(),lines=lines))
 census=O/'whole-crates-API-census.json';write(census,dict(terms=terms,fixture_payloads_excluded=True,files=hits))
 contexts=[]
 for p in ['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/getter.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports.rs','crates/ep_runtime/src/heat_balance/ctf_reports/predefined_table.rs']:
  q=R/p
  if q.exists():contexts.append(dict(canonical_path=p,whole=ref(q)))
 manifest=dict(schema='src06-fill-remaining-controlled-private-draft42.v1',status='FROZEN_SOURCE_ONLY_LOGICAL41_PARENT_NOT_ACTIVATED_PENDING41_COMMIT_AND_INDEPENDENT_PEER',
  base_HEAD_at_preparation=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),author_Source=ref(Path(__file__)),fragment_Source=ref(fragment),accepted41_actual_review=ref(ap),actual41_parent_snapshot=snapshot,parent_producer=actual['producer'],prior_complete_compiler_Source_plan=ref(priorp),complete_proposed_compiler_Source_plan=ref(planp),
  files=rows,selected_existing_sources=3,new_sources=0,literal_applications=6,Source_only_parses=3,Native_commit=C,Native_authorities=native,concrete_same_owner_contexts=contexts,whole_crates_API_census=ref(census),
  scope='Actual FillRemaining6370-6534 whole controlled-zone predefined entry and accumulator path; same borrowed Config and retained Zone/ZonePreDefRep. All existing suffixes preserved; actual positive PrimaryAirSystems.Name6374 child boundary remains honest; no upstream guard or synthetic zero inlet count.',
  constructor_lineage='Native ZoneData.isNominalOccupied explicitfalse645; sole true writer InternalHeatGains907, reached only after positive People input. Source positive People getter already stops109-110 before this writer, so same-owner ctorfalse is actual admitted domain, not inferred from simulation outcome. No broad occupancy implementation claim.',
  unchanged_suffix='Primary-system6540 loop and all later genuine existing summaries/thermostat-report children remain byteexact.',new_test_bodies=0,actual_test_bodies_executed=0,canonical_Cargo_Native_engine_tests_or_publication_mutations=False)
 mp=O/'draft.json';write(mp,manifest);print(json.dumps(dict(draft=ref(mp),plan=ref(planp),files=3,parses=3,applications=6)))
if __name__=='__main__':main()

"""Metadata-only42 successor: same3 Source wholes; correct Native extents/census."""
from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0';C='6f2e40d10250a105b49966baa24d843711e61048'
O=D/'source-fill-remaining-controlled-draft-Outer-42-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def main():
 assert not O.exists();p=D/'source-fill-remaining-controlled-draft-Outer-42/draft.json';m=json.loads(p.read_bytes())
 assert ref(p)['sha256']=='c04acf03e4a81ebdd834e8c35c6c5a75b3b26b781e9135b1b11561e10207d665'
 m['original_draft']=ref(p);m['metadata_successor_Source']=ref(Path(__file__))
 # Strict corrected/default-precision and constexpr authority; originals retained in01.
 for authority in m['Native_authorities']:
  if authority['Native_path']=='src/EnergyPlus/OutputReportPredefined.hh':
   lines=(N/authority['Native_path']).read_bytes().splitlines(True)
   authority['extents']=[dict(first_line=163,last_line=174,source=put(O/'Native'/'OutputReportPredefined.hh163-174.txt',b''.join(lines[162:174])))]
 q=N/'src/EnergyPlus/DataGlobalConstants.hh';b=q.read_bytes();assert subprocess.run(['git','show',C+':src/EnergyPlus/DataGlobalConstants.hh'],cwd=N,check=True,capture_output=True).stdout==b
 lines=b.splitlines(True);literal=b''.join(lines[599:602]);assert b'rSecsInMinute = 60.0' in literal and b'rMinutesInHour = 60.0'in literal and b'rSecsInHour = rSecsInMinute * rMinutesInHour'in literal
 m['Native_authorities'].append(dict(Native_path='src/EnergyPlus/DataGlobalConstants.hh',whole=ref(q),pinned_Git=C,Git_whole_exact=True,extents=[dict(first_line=600,last_line=602,source=put(O/'Native'/'DataGlobalConstants.hh600-602.txt',literal))]))
 run=subprocess.run(['rg','--json','-n','--glob','*.cc','--glob','*.hh','isNominalOccupied','src/EnergyPlus'],cwd=N,capture_output=True,check=True)
 rows=[json.loads(x)for x in run.stdout.splitlines()];matches=[r['data']for r in rows if r['type']=='match'];assert len(matches)==5
 expected={('src/EnergyPlus/DataHeatBalance.hh',645),('src/EnergyPlus/InternalHeatGains.cc',907),('src/EnergyPlus/OutputReportTabular.cc',6383),('src/EnergyPlus/OutputReportTabular.cc',6502),('src/EnergyPlus/OutputReportTabular.cc',18456)}
 observed={(r['path']['text'].replace('\\','/'),r['line_number'])for r in matches};assert observed==expected
 census=put(O/'Native'/'whole-production-isNominalOccupied-census.jsonl',run.stdout)
 getter=R/'crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/getter.rs';text=getter.read_text(encoding='utf8');lines=getter.read_bytes().splitlines(True)
 assert 'pub(super) const FAMILIES: [&str; 10] = [\n    "People",'in text
 assert 'if family != "OtherEquipment"'in text and 'positive IHG expansion alpha-field getter'in text
 source_extents=[]
 for first,last in [(23,34),(97,111),(175,212)]:
  source_extents.append(dict(first_line=first,last_line=last,source=put(O/'Source'/(str(first)+'-'+str(last)+'.txt'),b''.join(lines[first-1:last]))))
 m['constructor_lineage']='Native ZoneData.hh645 explicitlyfalse; exhaustive allsrc/EnergyPlus *.cc/*.hh census has1ctor,1truewriter(IHG907),3consumers. SourceFAMILIES[0]=People; any positive rawPeople object reaches preprocess205-211 typedboundary before later109-110 guard and before actualNative907 writer. Same-owner ctorfalse is real admitted domain, no runtime-count/expected-case proxy.'
 m['finite_constructor_writer_proof']=dict(Native_whole_production_census=census,actual_occurrences=len(matches),matches=matches,Source_getter_whole=ref(getter),Source_getter_extents=source_extents,exact_constant='Native constexpr60.0*60.0 is exactly representable3600.0; consumed multiplication/division grouping unchanged.')
 m['metadata_corrections']=['Replace irrelevant OutputReportPredefined.hh231-254 extent with genuine163-174 overloadedEntry/defaultprecision.', 'Add pinned DataGlobalConstants.hh600-602 exact3600 authority.', 'Clarify first positivePeople boundary is preprocess211;109-110 is a later additionalguard. All3Source proposals, sixdiffs/parses and logical4508plan remain byte-identical01.']
 write(O/'draft.json',m);print(json.dumps(ref(O/'draft.json')))
if __name__=='__main__':main()

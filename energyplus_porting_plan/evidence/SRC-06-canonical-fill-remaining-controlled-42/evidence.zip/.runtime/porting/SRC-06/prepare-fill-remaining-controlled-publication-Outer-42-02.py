"""Private42 finite publication template; no publisher/Cargo/canonical execution."""
from pathlib import Path
import argparse,copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=(R/r['path']).resolve();assert p.is_relative_to(R);a=ref(p);assert a['sha256']==r['sha256']and a['bytes']==r.get('bytes',r.get('size_bytes',a['bytes']));return p
def argument(s):
 name,h=s.rsplit('#',1);p=(R/name).resolve();r=ref(p);assert r['sha256']==h;return r
def main(a):
 mr=argument(a.manifest);m=json.loads(checked(mr).read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']
 assert len(m['files'])==3 and m['existing_Source_files']==3 and m['new_Source_files']==0
 plan=json.loads(checked(m['complete_final_compiler_Source_plan']).read_bytes());assert(plan['inputs'],plan['Rust_sources'])==(4510,4497)
 out=D/('fill-remaining-controlled-publication-READY-Outer-42-02'if a.actual else'fill-remaining-controlled-publication-prepared-Outer-42-02');assert not out.exists()
 files={}
 def add(row):
  p=checked(row);r=ref(p);assert p.suffix.casefold()!='.zip'and r['bytes']<64*1024*1024
  if r['path']in files:assert files[r['path']]==r
  files[r['path']]=r
 def addp(p):add(ref(p))
 for key in ('original_draft','independent_full_semantic_peer','accepted40_actual_review','actual_parent_snapshot','prior_complete_compiler_Source_plan','complete_final_compiler_Source_plan','whole4497_Rust_API_census','actual41_to40_Equipment_production_bridge','author_Source','original_held_producer','original_held_compiler_plan','prior_sealer_Source'):add(m[key])
 add(mr)
 draft=json.loads(checked(m['original_draft']).read_bytes());add(draft['original_draft']);original=json.loads(checked(draft['original_draft']).read_bytes())
 for key in ('author_Source','fragment_Source','accepted41_actual_review'):add(original[key])
 add(draft['metadata_successor_Source']);add(draft['finite_constructor_writer_proof']['Native_whole_production_census']);add(draft['finite_constructor_writer_proof']['Source_getter_whole'])
 for row in draft['finite_constructor_writer_proof']['Source_getter_extents']:add(row['source'])
 for row in m['files']:
  for key in ('before','proposed','literal_inverse','forward_diff','inverse_diff','actual40_before_archive'):add(row[key])
  for parsekey in ('Source_only_parse','final_fresh_Source_only_parse'):
   for key in ('stdout','stderr'):add(row[parsekey][key])
 for native in m['Native_authorities']:
  add(native['whole'])
  for e in native['extents']:add(e['source'])
 for c in m['concrete_same_owner_contexts']:add(c['whole'])
 bridge=json.loads(checked(m['actual41_to40_Equipment_production_bridge']).read_bytes())
 for row in bridge['consumed_actual_API_extents']:add(row['whole_source'])
 for p in [D/'apply-fill-remaining-controlled-Outer-42-02.py',D/'launch-fill-remaining-controlled-Outer-42-02.py',D/'check-source-fill-remaining-controlled-actual-Outer-42-02.py',D/'publish-fill-remaining-controlled-checkpoint-Outer-42-02.py',D/'fill-remaining-controlled-adapters-prepared-Outer-42-02/manifest.json',Path(__file__)]:addp(p)
 previous=R/'energyplus_porting_plan/evidence/SRC-06-canonical-node-setpoint-endrun-41/summary.json';pv=json.loads(previous.read_bytes());assert(pv['A'],pv['B'])==('14/54','14/64');addp(previous)
 t=dict(schema='src06-fill-remaining-controlled-publication-template42.v1',status='WAITING_FOR_ROOT_ACTUAL42_AND_FULL_READ',base_HEAD=head,publisher_Source=ref(D/'publish-fill-remaining-controlled-checkpoint-Outer-42-02.py'),producer=mr,complete_plan=m['complete_final_compiler_Source_plan'],independent_peer=m['independent_full_semantic_peer'],accepted_parent_review=m['accepted40_actual_review'],accepted_parent_plan=m['prior_complete_compiler_Source_plan'],accepted41_engine_proof=draft['accepted41_actual_review'],expected_actual_review_path='.runtime/porting/SRC-06/Root-source-fill-remaining-controlled-actual-review-42/review.json',previous_engine_checkpoint=ref(previous),finite_archive_inputs=list(files.values()),
  summary_template=dict(A='14/54',B='14/64',gate_changes=False,policy_changes=False,selected_existing_production_Sources=3,new_production_Source_files=0,selected_production_Sources=3,new_test_bodies=0,actual_test_bodies_executed=0,actual_engine_CLI_invocations=2,accepted_engine_CLI_receipts=2,
   scope='Genuine FillRemaining6370-6534 controlled-zone predefined entry order, exact decimal precision/grouping and retained per-zone/facility accumulators; actual Config inlet loop, same Zone/ZonePreDefRep and sole Zone nominal-occupancy constructor field. No count proxy or fake zeros.',
   qualification='Prior accepted40 report scientific cohort/compiler custody is preserved and not rerun here. Its numerical evidence does not certify this new tabular arithmetic. A24 accepted41 original5352 proof transfers only after strict full reported-file/CSV/JSON/runtime comparison; no new Native engine,72H/annual or finitegate/card completion claim.',
   Native_BND_qualification='Only retained original Native21 BND physical reported IO body is compared after exact engine ProgramVersion headers; no fresh Native or internal physical Node-state equivalence claim.'),
  doc_appends={
   'cards/SRC-06.md':'\uc81c\uc5b4 \uc874\uc758 FillRemaining \ud45c \ud56d\ubaa9\uacfc \ub204\uacc4\ub97c \uac19\uc740 Config\u00b7Zone\u00b7ZonePreDefRep\uc5d0 \uc5f0\uacb0\ud588\ub2e4. \uc785\ub825\ub41c \ub178\ub4dc \uc21c\uc11c\uc640 \ub098\ub217\uc148 \ubb36\uc74c, \ucd9c\ub825 \uc790\ub9bf\uc218\ub97c \ubcf4\uc874\ud55c\ub2e4. B \uc2e4\ud589 \uacb0\uacfc: `{{actual_B_result}}`. A24\uc758 \uae30\uc874 5,352\uac1c \ubcf4\uace0\uac12 \uc99d\uac70\ub294 \uc804\uccb4 \uacb0\uacfc \ube44\uad50 \ud6c4 \uc774\uc5b4\ubc1b\ub294\ub2e4.',
   'CHECKLIST.md':'\uae30\uc874 Rust \ud30c\uc77c 3\uac1c\ub85c \uc81c\uc5b4 \uc874 \ucd5c\uc885 \ud45c \uae30\uc785\uc744 \uc5f0\uacb0\ud588\ub2e4. \uc2e4\uc81c B/A24 CLI 2\ud68c\ub9cc \uc0ac\uc6a9\ud558\uace0 \uc2e4\ud589 \ub3c4\uad6c\uac00 canonical \ube4c\ub4dc \uacbd\ub85c\uc640 incremental0\uc744 \uc9c1\uc811 \uc9c0\uc815\ud55c\ub2e4. \uc0c8 \ud14c\uc2a4\ud2b8\uc640 \uac8c\uc774\ud2b8 \ubcc0\uacbd\uc740 \uc5c6\ub2e4.',
   'STATE_CONTRACTS.md':'Zone.isNominalOccupied\ub294 Native \uc0dd\uc131\uc790\uc758 false\ub97c \uac19\uc740 \uc874 \uc18c\uc720\uc790\uc5d0 \ubcf4\uad00\ud55c\ub2e4. \uc720\uc77c\ud55c true \uc791\uc131 \uacbd\ub85c\uc778 \uc591\uc218 People \uc785\ub825\uc740 \uae30\uc874 \uc2e4\uc81c \uacbd\uacc4\ub97c \uc720\uc9c0\ud558\uba70 \uc2e4\ud589 \ud69f\uc218\ub098 \uc608\uc0c1 \uacb0\uacfc\ub85c \uc810\uc720 \ud50c\ub798\uadf8\ub97c \ub300\uccb4\ud558\uc9c0 \uc54a\ub294\ub2e4.'})
 if a.actual:
  ar=argument(a.actual);actual=json.loads(checked(ar).read_bytes());assert actual['accepted']and not actual['findings'];assert actual['producer']==mr and actual['complete_compiler_plan']==t['complete_plan']
  assert actual['same4510_archived_inputs_exact_final_plan']and actual['selected3_final_sources_exact']and actual['actual_test_bodies_executed']==0
  assert actual['accepted41_full5352_proof']==t['accepted41_engine_proof']and actual['accepted40_cohort_parent_review']==t['accepted_parent_review']
  t['accepted_actual_review']=ar;t['status']='HELD_READY_FOR_ROOT_ACTUAL42_AND_FULL_READ'
 out.mkdir();q=out/'publication-template.json';q.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
 print(json.dumps(dict(template=ref(q),publisher=t['publisher_Source'],fixed_archive_entries=len(files),canonical_mutations=0,published=False)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--actual');main(p.parse_args())

"""Metadata-only held42 successor; preserve all Source/evidence and old917b/eba4."""
from pathlib import Path
import copy,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-fill-remaining-controlled-held-Outer-42-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256']and v['bytes']==r.get('bytes',v['bytes']);return p
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'));return ref(p)
def main():
 assert not O.exists();oldm=D/'source-fill-remaining-controlled-held-Outer-42/manifest.json';m=json.loads(oldm.read_bytes());assert ref(oldm)['sha256']=='917b8efb8fe1184274f87dfee0fa64c1460f23e9ce18a720b8009b092d61eac9'
 oldp=checked(m['complete_final_compiler_Source_plan']);old=json.loads(oldp.read_bytes());assert ref(oldp)['sha256']=='eba4ac66f1a7e08ef05427aa6f9568a07b2c49c538bee3b834eb2016bd97da99'
 parentp=checked(m['prior_complete_compiler_Source_plan']);parent=json.loads(parentp.read_bytes());assert ref(parentp)['sha256']=='ddb9ed4a1357ea234499b13ba7924ed6bf6e0a71ad12b24d3f8517ebcaece426'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==m['base_HEAD']and not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R)
 snapshot=json.loads(checked(m['actual_parent_snapshot']).read_bytes());archives={x['historical_path']:x for x in snapshot['files']};pi={x['path']:x for x in parent['entries']};assert len(pi)==len(archives)==4510
 for p,row in pi.items():
  b=checked(archives[p]['archive']).read_bytes();assert b==(R/p).read_bytes()and len(b)==row['final_bytes']and hashlib.sha256(b).hexdigest()==row['final_sha256']
 selected={row['canonical_path']:row for row in m['files']};assert len(selected)==3
 for row in old['entries']:
  p=row['path'];b=checked(selected[p]['proposed']).read_bytes()if p in selected else(R/p).read_bytes();assert hashlib.sha256(b).hexdigest()==row['final_sha256']and len(b)==row['final_bytes']
 # Fresh42 stage metadata, exact old42 final entries; all historical40 stage
 # assertions are explicitly namespaced and remain bound to genuine ddb9.
 final=dict(schema='src06-fill-remaining-controlled-final-Source-plan42-02.v1',base_HEAD=m['base_HEAD'],actual40_parent_review=m['accepted40_actual_review'],actual40_parent_snapshot=m['actual_parent_snapshot'],prior_complete_compiler_Source_plan=ref(parentp),prior_plan=ref(parentp),inputs=4510,compiler_inputs=4510,Rust_sources=4497,selected_existing=3,selected_new=0,selected3_overlay_and_4507_preserved=True,Root_full_before_after_readback_required=True,actual40_parent_plan_metadata={k:copy.deepcopy(v)for k,v in parent.items()if k!='entries'},entries=copy.deepcopy(old['entries']))
 assert final['entries']==old['entries']and final['prior_complete_compiler_Source_plan']==m['prior_complete_compiler_Source_plan']
 assert 'exactly_one_row_changed'not in final and 'other4509_metadata_and_Source_refs_whole_equal'not in final
 fp=O/'complete-final-compiler-Source-plan.json';fr=write(fp,final)
 successor=copy.deepcopy(m);successor.update(schema='src06-fill-remaining-controlled-held42-02.v1',original_held_producer=ref(oldm),original_held_compiler_plan=ref(oldp),prior_sealer_Source=m['author_Source'],author_Source=ref(Path(__file__)),complete_final_compiler_Source_plan=fr,
  metadata_correction='Fresh42 stage fields:3selected/4507preserved, immediateparentddb9. All prior40 stage metadata is namespaced under actual40_parent_plan_metadata; all4510 final entries and3Sourcewholes unchanged. Original917b/eba4 retained.',fresh4510_parent_and_final_overlay_readback_after_metadata_correction=True)
 mp=O/'manifest.json';mr=write(mp,successor);print(json.dumps(dict(manifest=mr,plan=fr,all4510_entries_whole_equal_original42=True,canonical_mutations=0)))
if __name__=='__main__':main()

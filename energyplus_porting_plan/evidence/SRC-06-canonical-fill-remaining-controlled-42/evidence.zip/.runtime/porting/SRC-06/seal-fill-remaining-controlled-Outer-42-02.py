"""Private42 final custody; requires accepted committed40 parent and Root fullpeer."""
from pathlib import Path
import argparse,ast,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'source-fill-remaining-controlled-held-Outer-42'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];a=ref(p);assert a['sha256']==r['sha256'] and a['bytes']==r.get('bytes',r.get('size_bytes',a['bytes']));return p
def argument(s):
 p,h=s.rsplit('#',1);p=(R/p).resolve();r=ref(p);assert r['sha256']==h;return r
def contains(v,row):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(row['path'],row['sha256'])or any(contains(x,row)for x in v.values())
 return isinstance(v,list)and any(contains(x,row)for x in v)
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf8'));return ref(p)
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def block(s,marker):
 start=s.index(marker);opening=s.index('{',start);masked=re.sub(r'"(?:\\.|[^"\\])*"','""',s[opening:]);depth=0
 # Only these established small struct/impl/getter extents; line-end scanner is
 # used on original text to retain exact Source bytes, string contents skipped.
 in_string=False;escape=False
 for pos,c in enumerate(s[opening:],opening):
  if in_string:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':in_string=False
   continue
  if c=='"':in_string=True
  elif c=='{':depth+=1
  elif c=='}':
   depth-=1
   if depth==0:return s[start:pos+1]
 raise AssertionError(marker)
def main(a):
 assert not O.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a.base_head
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R)
 dp=D/'source-fill-remaining-controlled-draft-Outer-42-02/draft.json';d=json.loads(dp.read_bytes());assert ref(dp)['sha256']=='d69d8aabbb0405a4ed71a639f57cfaa54639dd66cbb4b00ba736167013d71481'
 ar,pr,sr,peer=map(argument,(a.parent_actual,a.parent_plan,a.parent_snapshot,a.peer))
 actual=json.loads(checked(ar).read_bytes());assert actual['accepted']and not actual.get('findings',[])
 for r in (pr,sr):assert contains(actual,r),r['path']
 review=json.loads(checked(peer).read_bytes());assert review['accepted']and not review.get('findings',[])
 assert contains(review,ref(dp)),'Full semantic Root peer must bind authoritative metadata02 draft'
 plan=json.loads(checked(pr).read_bytes());snapshot=json.loads(checked(sr).read_bytes());assert(plan['compiler_inputs'],plan['Rust_sources'])==(4510,4497)
 prior_index={x['path']:x for x in plan['entries']};archives={x['historical_path']:x for x in snapshot['files']};assert len(prior_index)==len(archives)==4510 and prior_index.keys()==archives.keys()
 for p,row in prior_index.items():
  archived=checked(archives[p]['archive']);b=archived.read_bytes();assert len(b)==row['final_bytes'] and hashlib.sha256(b).hexdigest()==row['final_sha256']
  assert(R/p).read_bytes()==b,p
 # Selected before custody is exact logical41 -> actual committed40, not a SHA waiver.
 files=[];parse_count=0;applications=0
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'applier','exec'),ns)
 for i,row in enumerate(d['files'],1):
  p=row['canonical_path'];before=checked(row['before']).read_bytes();proposed=checked(row['proposed']).read_bytes();assert before==checked(archives[p]['archive']).read_bytes()==(R/p).read_bytes()
  assert subprocess.check_output(['git','show',a.base_head+':'+p],cwd=R)==before
  assert ns['apply'](before,checked(row['forward_diff']).read_bytes())==proposed and ns['apply'](proposed,checked(row['inverse_diff']).read_bytes())==before;applications+=2
  run=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,cwd=R,capture_output=True);assert run.returncode==0;parse_count+=1
  item=copy.deepcopy(row);item['actual40_before_archive']=archives[p]['archive'];item['selected_Git_exact']=True
  item['final_fresh_Source_only_parse']=dict(exit_code=run.returncode,stdout=put(O/'parse'/f'{i:02}.stdout',run.stdout),stderr=put(O/'parse'/f'{i:02}.stderr',run.stderr));files.append(item)
 # OrdinaryEquipment production bridge is limited to real consumed APIs and
 # its complete prefix before the established first cfg(test) section.
 oldsr=json.loads(checked(d['actual41_parent_snapshot']).read_bytes());oldidx={x['historical_path']:x for x in oldsr['files']}
 equipment='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs';oldp=checked(oldidx[equipment]['archive']);newp=checked(archives[equipment]['archive']);old=oldp.read_text(encoding='utf8');new=newp.read_text(encoding='utf8')
 prefix=old.split('\n#[cfg(',1)[0];assert new.startswith(prefix)
 extents=[]
 for marker in ["pub(crate) struct SourceZoneEquipmentConfigRef<'a>","impl SourceZoneEquipmentConfigRef<'_>",'    pub(crate) fn source_zone_equipment_config(']:
  x=block(old,marker);assert block(new,marker)==x;extents.append(dict(marker=marker,whole_source=put(O/'contexts'/(str(len(extents)+1)+'.rs.txt'),x.encode())))
 bridge=dict(actual41_whole=ref(oldp),actual40_whole=ref(newp),production_prefix_bytes=len(prefix.encode()),production_prefix_sha256=hashlib.sha256(prefix.encode()).hexdigest(),production_prefix_exact=True,consumed_actual_API_extents=extents,qualification='Actual40 test-only continuation is retained whole; this bridge independently proves only unchanged complete production prefix and exact consumed borrowed Config APIs, not all-file equality.')
 bridge_ref=write(O/'contexts'/'ordinary-equipment-actual41-to40-bridge.json',bridge)
 final=copy.deepcopy(plan);final.update(schema='src06-fill-remaining-controlled-final-Source-plan42.v1',base_HEAD=a.base_head,actual40_parent_review=ar,actual40_parent_snapshot=sr,prior_plan=pr,selected_existing=3,selected_new=0,inputs=4510)
 for row in files:
  entry=next(x for x in final['entries']if x['path']==row['canonical_path']);entry.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'],origin='whole exact accepted Source42 controlled FillRemaining proposal')
 fp=O/'complete-final-compiler-Source-plan.json';write(fp,final)
 contexts=[]
 for c in d['concrete_same_owner_contexts']:
  p=c['canonical_path'];contexts.append(dict(canonical_path=p,whole=archives[p]['archive'],historical41_context=c['whole'],actual40_authority=True))
 for authority in d['Native_authorities']:
  p=checked(authority['whole']);assert subprocess.check_output(['git','show',d['Native_commit']+':'+authority['Native_path']],cwd=N)==p.read_bytes()
  for extent in authority['extents']:checked(extent['source'])
 census=json.loads(checked(d['whole_crates_API_census']).read_bytes());terms=census['terms'];hits=[]
 for entry in final['entries']:
  p=entry['path']
  if not p.startswith('crates/')or not p.endswith('.rs')or '/fixtures/'in p:continue
  source=checked(entry['source']).read_text(encoding='utf8');lines=[dict(line=i,literal=x)for i,x in enumerate(source.splitlines(),1)if any(t in x for t in terms)]
  if lines:hits.append(dict(path=p,whole_sha256=entry['final_sha256'],lines=lines))
 cr=write(O/'whole4497-Rust-API-census.json',dict(compiler_Rust_sources=4497,fixture_payloads_excluded_only_for_API_text_search=True,terms=terms,files=hits))
 manifest=dict(schema='src06-fill-remaining-controlled-held42.v1',status='HELD_NOT_APPLIED',base_HEAD=a.base_head,author_Source=ref(Path(__file__)),original_draft=ref(dp),independent_full_semantic_peer=peer,accepted40_actual_review=ar,actual_parent_snapshot=sr,parent_producer=actual.get('producer',actual.get('production')),prior_complete_compiler_Source_plan=pr,complete_final_compiler_Source_plan=ref(fp),
  full4510_parent_readback=dict(inline=True,inputs=4510,Rust_sources=4497,all_actual40_archived_inputs_match_plan_and_live=True,selected3_logical41_before_wholes_exact_actual40_and_Git=True,all4507_unselected_wholes_exact_actual40=True,all40_cohort_main_Cargo_and_fixture_changes_preserved=True),
  files=files,existing_Source_files=3,new_Source_files=0,selected_existing_sources=3,new_sources=0,literal_applications=applications,Source_only_parses=parse_count,whole4497_Rust_API_census=cr,Native_commit=d['Native_commit'],Native_authorities=d['Native_authorities'],finite_constructor_writer_proof=d['finite_constructor_writer_proof'],concrete_same_owner_contexts=contexts,actual41_to40_Equipment_production_bridge=bridge_ref,
  scope=d['scope'],constructor_lineage=d['constructor_lineage'],unchanged_suffix=d['unchanged_suffix'],new_test_bodies=0,actual_test_bodies_executed=0,canonical_Cargo_Native_engine_tests_or_publication_mutations=False)
 mp=O/'manifest.json';write(mp,manifest);print(json.dumps(dict(manifest=ref(mp),plan=ref(fp),inputs=4510,Rust_sources=4497,selected=3)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base-head',required=True);p.add_argument('--parent-actual',required=True);p.add_argument('--parent-plan',required=True);p.add_argument('--parent-snapshot',required=True);p.add_argument('--peer',required=True);main(p.parse_args())

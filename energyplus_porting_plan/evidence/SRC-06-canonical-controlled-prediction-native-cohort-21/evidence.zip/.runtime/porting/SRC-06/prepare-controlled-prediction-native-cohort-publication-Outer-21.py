"""Freeze compact publication inputs after the actual focused test; no publish."""
from pathlib import Path
import ast,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'controlled-prediction-native-cohort-publication-prepared-Outer-21'
def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':h,'bytes':p.stat().st_size}
def checked(row):
    p=(R/row['path']).resolve();assert ref(p)['sha256']==row['sha256'];return p
def read(row):return json.loads(checked(row).read_bytes())
def file(name):return ref(D/name)
assert not O.exists()
producer_ref=file('source-controlled-prediction-cohort-held-Outer-21-02/manifest.json')
assert producer_ref['sha256']=='3d19c6468d5669038e74518e89a70a3dfeb3d5674f185cf0725b9719f76b9e96'
producer=read(producer_ref)
actual_ref=file('Root-source-controlled-prediction-cohort-actual-review-21/review.json')
assert actual_ref['sha256']=='29148090bfc5f96840193c24f168ac4b7733b0f07acd76141c6ab8c8db655925'
actual=read(actual_ref);assert actual['accepted'] and not actual['findings']
assert actual['actual_executed_test_bodies']==1 and actual['case_count']==1168 and actual['shortened_cases']==77 and actual['kickoff_cases']==3
assert actual['final_CLI_rebuilt_or_executed'] is False
publisher=D/'publish-controlled-prediction-native-cohort-Outer-21.py';ast.parse(publisher.read_bytes())
inputs={}
def add(row):
    p=checked(row);r=ref(p)
    assert p.suffix.lower() not in ('.zip','.exe','.dll','.a','.obj','.map') and r['bytes']<20*1024*1024
    assert not p.name.endswith('.observation.json')
    assert r['path'] not in inputs or inputs[r['path']]==r
    inputs[r['path']]=r
def add_path(name):add(file(name))
peers=[actual['Source_peer'],actual['Native_fixture_peer'],producer['independent_draft_Source_peer'],
       file('Audit-controlled-prediction-cohort-final-join-review-21/review.json')]
peers=list({row['path']:row for row in peers}.values())
for row in peers:add(row)
for row in [producer_ref,producer['complete_final_compiler_Source_plan'],producer['rejected_first_packet'],producer['derivation'],
            producer['actual24_review'],producer['actual24_B'],producer['actual24_A24'],producer['rejected_first_unit_receipt']]:add(row)
failed=read(producer['rejected_first_unit_receipt'])
for key in ('stdout','stderr','source_snapshot'):add(failed[key])
for row in producer['files']:add(row['proposed'])
# Current full fixture is stored once. Redundant whole-fixture forward/inverse
# diffs and rejected duplicate fixture bodies are represented by their hashes
# and exact one-character correction Source, rather than copied again.
for name in ['derive-Source21-Native-cohort-Outer-21.py','correct-Source21-cohort-include-comment-Outer-21-02.py',
             'seal-Source21-Native-cohort-Outer-21.py','source-controlled-prediction-cohort-draft-Outer-21/draft.json',
             'source-controlled-prediction-cohort-held-Outer-21/test-name-only-correction.diff']:
    add_path(name)
capture_ref=actual['actual_Native_capture'];capture=read(capture_ref);add(capture_ref)
for key in ('stdout','stderr','Native_runtime_before','Native_runtime_after','actual_module_observation'):add(capture[key])
for row in capture['genuine_engine_inputs']:add(row)
for row in capture['output_inventory']:
    if Path(row['path']).name in ('eplusout.eso','eplusout.rdd','eplusout.mdd'):add(row)
build_ref=capture['actual_native_build'];build=read(build_ref);add(build_ref)
for key in ('actual_build','Native_before','Native_after','frozen_environment','launcher_Source','actual_preflight'):add(build[key])
build_receipt=read(build['actual_build'])
for key in ('stdout','stderr'):add(build_receipt[key])
harness_ref=build['accepted_harness'];harness=read(harness_ref);add(harness_ref);add(build['independent_Source_peer'])
for row in harness['payload']:add(row)
for row in harness['Native_wholes']:add(row)
for key in ('integration_contract','Native_literal_extents'):add(harness[key])
add(capture['launcher_Source'])
comparison_ref=actual['actual_Native_reported_comparison'];comparison=read(comparison_ref);add(comparison_ref)
for key in ('comparison_Source','preparation','original_policy','actual_installed_Native_receipt','all_unequal_physical_rows','all_original_policy_failures'):add(comparison[key])
comparison_plan=read(comparison['preparation'])
for row in comparison_plan['baseline_reported_files']:add(row)
for key in ('accepted_public_policy_binding_Source','installed_ESO_earlier_authenticated_reference'):add(comparison_plan[key])
original_note=capture['finite_defined_read_proof'];corrected_note=producer['corrected_EPVector_note']
add(original_note);add(corrected_note)
for row in read(corrected_note)['actual_type_and_allocation_authority']:add(row['source'])
previous=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-zone-equipment-orchestration-24/summary.json');add(previous)
add(ref(Path(__file__)))
docs={
 'CHECKLIST.md':{'title':'Source 예측 수치 코호트 검증','text':'Native 실제 호출 1,168개를 단일 테스트로 대조했습니다. 테스트 전용 변경의 운영 근거는 checkpoint 24의 B·A 실행 결과를 상속합니다.'},
 'STATE_CONTRACTS.md':{'title':'예측 상태와 Node 소유권 검증','text':'같은 실제 Node에서 이력 복원 결과를 먼저 확인한 뒤 세 계수 입력을 전달해 설정값과 수요를 비트 단위로 대조합니다. 전체 예측기·수정기와 캐시 검증은 별도 범위입니다.'},
 'cards/SRC-06.md':{'title':'단일 Native 코호트 테스트','text':'한 테스트에서 1,168개 호출과 시간 간격 축소 77회를 검증했습니다. 신규 CLI 실행을 주장하지 않으며 게이트는 A14/54·B14/64를 유지합니다.'}
}
assert len({row['text'] for row in docs.values()})==3
for row in docs.values():
    for value in row.values():assert '?' not in value and '\ufffd' not in value and value.encode('utf8').decode('utf8')==value
template={'schema':'src06-held-controlled-prediction-Native-cohort-publication.v1','status':'READY_FOR_ROOT_REVIEW_AND_PUBLICATION',
 'base_HEAD':producer['base_HEAD'],'producer':producer_ref,'complete_plan':producer['complete_final_compiler_Source_plan'],
 'accepted_unit_review':actual_ref,'successful_unit_receipt':actual['actual_focused_test'],
 'Root_application':actual['original_application'],'Root_comment_correction':actual['comment_only_correction'],
 'failed_first_unit_receipt':producer['rejected_first_unit_receipt'],'rejected_first_packet':producer['rejected_first_packet'],
 'accepted24_review':producer['actual24_review'],'previous_checkpoint':previous,'independent_peers':peers,
 'actual_Native_capture':capture_ref,'actual_Native_build':build_ref,'actual_Native_reported_comparison':comparison_ref,
 'original_defined_read_note':original_note,'corrected_defined_read_note':corrected_note,
 'publisher_Source':ref(publisher),'author_Source':ref(Path(__file__)),
 'summary_template':{'A':'14/54','B':'14/64','new_test_bodies':1,'actual_executed_test_bodies':1,
   'actual_Native_parent_invocations':1168,'selected_actual_phase_states':4672,'shortened_cases':77,'kickoff_cases':3,
   'fixture_bytes':6954950,'exact_binary64_checks':True,'cohort_groups':actual['cohort_groups'],
   'tested_methods':['update_source_temperatures','calculate_source_predicted_sensible'],
   'test_scope':'Two real private production methods at actual Native method-entry states, genuine raw-IP/getter-created physical Node, exact rollback outputs before only3 supplied parent coefficients. No full predictor/sums/cache20/corrector or Source trajectory equivalence.',
   'production_delta':'Only33-byte cfg(test) child hook plus2 test-only files; production bodies/APIs/math/owners unchanged.',
   'Native_reported_control':{'series':102,'samples':9792,'unequal_nonheader_rows':0,'actual_MTR_absent':True,
     'scope':'Two genuine Native executions; exact ESO/RDD/MDD except three Program Version clocks. This is not a Source completion receipt.'},
   'no_final_CLI_rebuild_or_execution':True,'full_B_complete':False,'full15matrix_complete':False,'gate_changes':False,'tolerance_changes':False},
 'doc_appends':docs,'finite_archive_inputs':[row for _,row in sorted(inputs.items())],
 'finite_archive_input_count':len(inputs),'finite_archive_input_bytes':sum(row['bytes'] for row in inputs.values()),
 'finite_archive_scope':'Current full test fixture stored once with three Sources, reviewed derivation/harness/Native authority, actual Native build/capture/report comparison, original/corrected defined-read notes, rejected first compile and exact correction, successful one-test receipt/checker, direct Root application Sources and inherited24 references. No390MB raw observation,1.3GB executable/static core/DLLs/map/object files, recursive prior ZIP, annual JSON/CSV or duplicate full-fixture diffs. Three small D-drive reported files have explicit Native-capture-reported archive aliases.',
 'publisher_executed':False,'main_or_public_docs_mutated':False,'Cargo_Native_or_tests_executed':False}
O.mkdir();path=O/'publication-template.json';path.write_bytes((json.dumps(template,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
print(json.dumps({'template':ref(path),'publisher':ref(publisher),'finite_inputs':len(inputs),'finite_input_bytes':template['finite_archive_input_bytes']}))

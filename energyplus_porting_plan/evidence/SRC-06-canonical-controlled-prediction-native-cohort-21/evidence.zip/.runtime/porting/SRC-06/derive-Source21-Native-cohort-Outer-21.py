"""Strict streaming test-fixture derivation only: no solver, engine or compiler."""
from pathlib import Path
import hashlib
import json
import re
from collections import Counter

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
P = D / 'source-controlled-prediction-cohort-draft-Outer-21'
REL = 'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction'


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(R).as_posix() if path.is_relative_to(R) else path.as_posix(),
            'sha256': digest, 'bytes': path.stat().st_size}


def checked(row):
    path = (R / row['path']).resolve()
    need(ref(path)['sha256'] == row['sha256'], 'Changed actual input: ' + row['path'])
    return path


def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'Duplicate JSON key')
        out[key] = value
    return out


AIR = ('MAT', 'airHumRat', 'T1', 'AirPowerCap', 'tempDepLoad', 'tempIndLoad', 'setPointLast',
       'XMAT', 'DSXMAT', 'WPrevZoneTS', 'DSWPrevZoneTS', 'ZTM', 'WPrevZoneTSTemp')
ZONE = ('Name', 'SystemZoneNodeNumber', 'IsControlled', 'Multiplier', 'ListMultiplier',
        'HasAdjustedReturnTempByITE', 'AdjustedReturnTempByITE')
CLOCK = ('BeginSimFlag', 'WarmupFlag', 'KickOffSimulation', 'ShortenTimeStepSys', 'UseZoneTimeStepHistory',
         'NumOfSysTimeSteps', 'NumOfSysTimeStepsLastZoneTimeStep', 'TimeStepSys')
FLAGS = ('ZoneAirSolutionAlgo', 'NumStageCtrZone', 'StageZoneLogic', 'anyNonMixingRoomAirModel')


def stripped(value):
    if isinstance(value, dict):
        if 'value_bits' in value:
            need(set(value) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', value['value_bits']), 'Bad f64 bits')
            return value['value_bits']
        return {key: stripped(child) for key, child in value.items() if key not in ('address', 'owner_address')}
    if isinstance(value, list):
        return [stripped(child) for child in value]
    need(not isinstance(value, float), 'Raw transport unexpectedly contains a decimal float')
    return value


def state(event):
    s = event['state']
    node = s['zone_system_node']
    need(node['value'] is not None and node['index'] == s['zone']['SystemZoneNodeNumber'], 'Missing same physical Node')
    f = s['fan']
    need(f['zoneTstatSetpts']['value'] is not None, 'Missing real setpoint row')
    return stripped({
        'air': {key: s['air'][key] for key in AIR},
        'zone': {key: s['zone'][key] for key in ZONE},
        'clock': {key: event['clock'][key] for key in CLOCK},
        'flags': {key: s['flags'][key] for key in FLAGS},
        'node': node['value'], 'node_ordinal': node['index'], 'node_name': node['NodeID'],
        'fan': {'TempTstatAir': f['TempTstatAir']['value'],
                'LoadCorrectionFactor': f['LoadCorrectionFactor']['value'],
                'TempControlType': f['TempControlType']['value'], 'setpoints': f['zoneTstatSetpts']['value']},
        'demand': {'Setback': s['demand']['Setback']['value'],
                   'DeadBandOrSetback': s['demand']['DeadBandOrSetback']['value'],
                   'CurDeadBandOrSetback': s['demand']['CurDeadBandOrSetback']['value'],
                   'sensible': s['demand']['zone']['value']}})


capture_path = D / 'controlled-air-native-capture-Root-21/capture.json'
need(ref(capture_path)['sha256'] == '6845958c28d6eef55ce89100a13f2001d43ae7ca2fb3e86b2c189d2820b4c47f', 'Wrong actual capture')
capture = json.loads(capture_path.read_bytes())
need(capture['accepted'] and not capture['findings'], 'Capture not accepted')
raw = checked(capture['full_retained_observation'])
comparison = D / 'controlled-air-Native-reported-comparison-Root-21/comparison.json'
need(ref(comparison)['sha256'] == '085799b03132dd5abb585068ef991c11c23f9bfb56d78c178b2daab4101bd910', 'Wrong actual physical comparison')
need(json.loads(comparison.read_bytes())['accepted'], 'Native physical comparison failed')
reader = R / '.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'
reader_bytes = reader.read_bytes()
need(ref(reader)['sha256'] == '8e7f05196fe567c052352d4d0fe501eb02a0f8e5a623c20f7dcd3db669f6bab8', 'Changed fixed streaming reader')
need(reader_bytes.count(b"literal('],\"summary\":')") == 1, 'Reader terminal delimiter changed')
adapted = reader_bytes.replace(b"literal('],\"summary\":')", b"literal('],\"terminal_summary\":')")
namespace = {}
exec(compile(adapted, '<fixed-stream-reader-terminal-key-only>', 'exec'), namespace)
rows, active, events, groups = [], None, 0, Counter()


def visit(event):
    global active, events
    events += 1
    need(event['event_ordinal'] == events, 'Missing/reordered event')
    method, phase = event['method'], event['phase']
    if method == 'predictSystemLoad':
        if phase == 'entry':
            need(active is None and event['spaceNum'] == 0 and event['zoneNum'] == 1, 'Wrong finite parent association')
            active = {'parent': event['invocation_ordinal'], 'zone': event['zoneNum'], 'space': event['spaceNum'],
                      'native_air_address': event['state']['air']['owner_address'],
                      'native_Node_address': event['state']['zone_system_node']['value']['address']}
        elif phase == 'normal_exit':
            need(active is not None and event['invocation_ordinal'] == active['parent'], 'Wrong parent close')
            need(all(key in active for key in ('update_entry', 'update_exit', 'sensible_entry', 'sensible_exit')), 'Incomplete case')
            rows.append(active)
            active = None
    if method not in ('updateTemperatures', 'calcPredictedSystemLoad') or phase not in ('entry', 'normal_exit'):
        return
    need(active is not None and event['parent_method'] == 'predictSystemLoad'
         and event['parent_invocation_ordinal'] == active['parent'], 'Child does not belong to actual predictor')
    need(event['state']['air']['owner_address'] == active['native_air_address']
         and event['state']['zone_system_node']['value']['address'] == active['native_Node_address'], 'Actual owner address changed')
    prefix = 'update' if method == 'updateTemperatures' else 'sensible'
    key = prefix + ('_entry' if phase == 'entry' else '_exit')
    need(key not in active, 'Duplicate actual child phase')
    if phase == 'entry':
        active[prefix + '_invocation'] = event['invocation_ordinal']
        active[prefix + '_arguments'] = stripped(event['locals'])
    else:
        need(active[prefix + '_invocation'] == event['invocation_ordinal'], 'Wrong actual child exit')
    active[key] = state(event)
    if prefix == 'update' and phase == 'entry':
        c = event['clock']
        groups[(c['WarmupFlag'], c['KickOffSimulation'], c['ShortenTimeStepSys'], c['UseZoneTimeStepHistory'])] += 1


transport = namespace['read'](raw, need, unique, visit)
need(active is None and len(rows) == 1168 and events == 30445, 'Actual complete cohort count differs')
need(transport['summary'] == capture['observation_checks']['terminal_summary'], 'Actual footer differs')
need([row['parent'] for row in rows] == list(range(1, 1169)), 'Actual parent invocations missing')
for row in rows:
    need(row['update_exit']['node'] == row['sensible_entry']['node'], 'Actual Node stage handoff differs')
    need(row['update_exit']['fan']['TempTstatAir'] == row['sensible_entry']['fan']['TempTstatAir'], 'Actual fan stage handoff differs')
    for key in ('MAT', 'airHumRat', 'XMAT', 'DSXMAT', 'WPrevZoneTS', 'DSWPrevZoneTS', 'ZTM', 'WPrevZoneTSTemp'):
        need(row['update_exit']['air'][key] == row['sensible_entry']['air'][key], 'Actual air stage handoff differs: ' + key)

raw_authority = D / 'ordinary-source-B-raw-ingress-held-Audit-01/actual-B-input-preservation.json'
raw_note = json.loads(raw_authority.read_bytes())
converted = checked(raw_note['actual_failed_input'])
original = json.loads(converted.read_bytes())
families = ('NodeList', 'ZoneHVAC:EquipmentConnections', 'ZoneHVAC:EquipmentList', 'ZoneHVAC:IdealLoadsAirSystem')
raw_families = {family: original[family] for family in families}
need(all(len(objects) == 1 for objects in raw_families.values()), 'Actual single-IDF-family restriction differs')
schema_path = R / '.runtime/energyplus/26.1.0/Energy+.schema.epJSON'
need(ref(schema_path)['sha256'] == '60b24d904e6fa553f773b38037a8a09730e6da1538647df552cd77db8d6704a9', 'Wrong installed Native schema')
schema = json.loads(schema_path.read_bytes())['properties']
definitions = []
for family in (*families, 'SpaceHVAC:EquipmentConnections', 'AirLoopHVAC:SupplyPath', 'AirLoopHVAC:ReturnPath'):
    legacy = schema[family]['legacy_idd']
    a, n = legacy['alphas'], legacy['numerics']
    definitions.append([family, len(a['fields']), len(n['fields']), len(a.get('extensions', [])),
                        len(n.get('extensions', [])), legacy.get('extension')])
tables, indices = {}, {}
packed_rows = []
for row in rows:
    packed = dict(row)
    for phase in ('update_entry', 'update_exit', 'sensible_entry', 'sensible_exit'):
        packed[phase] = {}
        for name, value in row[phase].items():
            # Lossless interning only: retain exact captured values once and use
            # array indices. No scalar, history, expected answer or null rebuilt.
            key = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
            table = tables.setdefault(name, [])
            by_value = indices.setdefault(name, {})
            if key not in by_value:
                by_value[key] = len(table)
                table.append(value)
            packed[phase][name] = by_value[key]
        need({name: tables[name][index] for name, index in packed[phase].items()} == row[phase],
             'Lossless state-field interning failed')
    packed_rows.append(packed)
fixture = {'schema': 'src06-Source21-complete-Native-method-entry-cohort.v1', 'case_count': len(rows),
    'definitions': definitions, 'raw': raw_families,
    'object_order': {family: list(objects) for family, objects in raw_families.items()},
    'state_tables': tables, 'cases': packed_rows}
target = P / 'proposed' / REL / 'fixtures/native_prediction_b.rs'
if target.exists():
    initial = P / 'unsealed-initial-noninterned-format'
    initial.mkdir(exist_ok=False)
    (initial / target.name).write_bytes(target.read_bytes())
    (initial / 'derivation.json').write_bytes((P / 'derivation.json').read_bytes())
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(('//! Test-only exact Native consumed states; production never reads this.\n'
    'const NATIVE_PREDICTION_COHORT_JSON: &str = r###"' + json.dumps(fixture, separators=(',', ':'), ensure_ascii=False) + '"###;\n').encode('utf8'))
provenance = {'schema': 'src06-Source21-Native-cohort-derivation.v1', 'author_Source': ref(Path(__file__)),
    'actual_capture': ref(capture_path), 'whole_raw_observation': ref(raw), 'actual_Native_reported_comparison': ref(comparison),
    'corrected_EPVector_note': ref(D / 'controlled-air-Native-reports-comparison-prepared-Outer-21/finite-B-defined-read-note-02.json'),
    'reader_original': ref(reader), 'reader_only_change': 'literal top-level summary delimiter becomes terminal_summary; return name remains summary',
    'adapted_reader_sha256': hashlib.sha256(adapted).hexdigest(), 'actual_original_B_raw_authority': ref(raw_authority),
    'actual_converted_B_input': ref(converted), 'actual_tracked_B_input': capture['genuine_engine_inputs'][0],
    'actual_schema': ref(schema_path), 'raw_family_counts': {key: len(value) for key, value in raw_families.items()},
    'events_visited': events, 'all_parent_invocations': [row['parent'] for row in rows],
    'cohort_groups': [{'warmup': k[0], 'kickoff': k[1], 'shorten': k[2], 'zone_history': k[3], 'count': v} for k, v in sorted(groups.items())],
    'fixture': ref(target), 'selected_actual_state_fields': {'air': AIR, 'zone': ZONE, 'clock': CLOCK, 'flags': FLAGS},
    'lossless_state_field_interning': {name: len(values) for name, values in tables.items()},
    'all_4672_phase_states_roundtrip_exact_after_interning': True,
    'no_sampling_or_solver_or_intermediate_reconstruction': True,
    'raw_file_mutated_or_Native_Cargo_tests_executed': False}
(P / 'derivation.json').write_bytes((json.dumps(provenance, indent=2) + '\n').encode('utf8'))
print(json.dumps({'fixture': ref(target), 'derivation': ref(P / 'derivation.json')}))

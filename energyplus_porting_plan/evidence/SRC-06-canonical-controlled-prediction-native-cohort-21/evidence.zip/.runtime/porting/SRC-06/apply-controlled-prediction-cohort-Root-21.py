from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-controlled-prediction-cohort-application-21'
assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-controlled-prediction-cohort-held-Outer-21/manifest.json');assert mr['sha256']=='8c830c24ffb9efb383a8690fafb0904ad10125bde2f8d1c1d5ed1de7930e0176';m=json.loads(checked(mr))
pr=ref(D/'Audit-controlled-prediction-cohort-final-join-review-21/review.json');assert pr['sha256']=='0fd7ef65bf01f472bdbbae52d65f53be52cce0b13d0c54c01819435efbd6c1c9';peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet']==mr
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='a141fe8f4f4f28144eaf918fb2010a19b2eea113' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual24_snapshot']))['files']}
inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4492 and set(parents)==inventory
for n,v in parents.items():assert(R/n).read_bytes()==checked(v['archive']) and(R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
 if f['before_absent']:assert not(R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and(R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==3 and len(new)==2 and tests==1
old=[f for f in m['files'] if not f['before_absent']][0];assert checked(old['proposed'])==checked(old['before'])+b'\n#[cfg(test)]\nmod native_cohort;\n'
for k in ['actual24_review','actual24_B','actual24_A24','parent24_complete_plan','independent_draft_Source_peer','independent_whole_fixture_peer','derivation','actual_capture','actual_Native_reported_comparison','corrected_EPVector_note','immutable_Source_draft','test_name_only_correction','author_Source','sealer_Source']:checked(m[k])
bridge=m['sole_known_unselected_Git_physical_byte_bridge'];assert len(bridge)==1
v=bridge[0];physical=checked(v['actual_archive_and_live']);blob=subprocess.check_output(['git','show',head+':'+v['path']],cwd=R);i=v['exact_extra_CR_byte_offset'];assert i==48574 and physical[i:i+1]==b'\r' and physical[:i]+physical[i+1:]==blob and hashlib.sha256(blob).hexdigest()==v['Git']['sha256'] and len(blob)==v['Git']['bytes']
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4494 and sum(n.endswith('.rs') for n in rows)==4481
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'];assert b==(checked(selected[n]['proposed']) if n in selected else(R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert(R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4492,final_inputs=4494,final_Rust_sources=4481,selected_Rust=3,new_Rust=2,literal_applications=6,new_test_bodies=1,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,known_unselected_Git_CR_bridge=bridge,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read the full25903-byte Rust test and full12654-byte exact streaming derivation, accepted independent whole Native fixture peer and whole Rust Source peer plus final one-byte name-only join. Actual rollback/history/physical Node is asserted before only3 real parent-derived coefficients are loaded. Actual sensible method then runs with complete consumed inputs and exact binary64 outputs, for all1168 actual parents/4672phase states. No production math/owner/API/visibility change; sole33-byte cfg(test) hook. No full predictor/sums/caches/corrector/full B claim. Exactly one focused lib test remains required; existing actual24 production integration is inherited without final CLI rebuild/execution claim.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

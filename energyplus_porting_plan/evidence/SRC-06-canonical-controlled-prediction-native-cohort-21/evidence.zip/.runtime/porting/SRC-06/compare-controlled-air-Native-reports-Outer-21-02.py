"""Read-only comparison of TWO genuine Native executions; never a Source receipt.

First retain every unequal physical row (including headers) without truncation.
Then require exact dictionaries, metadata, clock tuples, report IDs/order, footer
and EOF, applying the unchanged named policy only to actual decimal operands.
"""
from pathlib import Path
import argparse
import ast
import base64
import hashlib
import itertools
import json
import math
import re
import struct
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
PREP = D / 'controlled-air-Native-reports-comparison-prepared-Outer-21-02'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def ref(path):
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(R).as_posix() if path.is_relative_to(R) else path.as_posix(),
            'sha256': digest, 'bytes': path.stat().st_size}


def checked(row):
    path = (R / row['path']).resolve()
    actual = ref(path)
    require(actual['sha256'] == row['sha256'] and actual['bytes'] == row.get('bytes', actual['bytes']),
            'Changed whole file: ' + row['path'])
    return path


def read(path):
    return json.loads(path.read_bytes())


def normpath(path):
    return str(Path(path).resolve()).casefold().replace('\\', '/')


def option(command, flag):
    require(command.count(flag) == 1, 'Expected exactly one ' + flag)
    at = command.index(flag)
    require(at + 1 < len(command), 'Missing operand: ' + flag)
    return command[at + 1]


def body(raw):
    require(raw.endswith(b'\n'), 'Unterminated physical row')
    ending = b'\r\n' if raw.endswith(b'\r\n') else b'\n'
    content = raw[:-len(ending)]
    require(b'\r' not in content, 'Embedded CR in physical row')
    return content.decode('utf8'), ending


def version(raw):
    content, ending = body(raw)
    match = re.fullmatch(r'(Program Version,.*), YMD=(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2})(,?)', content)
    require(match is not None, 'Unsupported Program Version clock header')
    return match[1] + match[3], match[2], ending


def physical_pass(kind, baseline, captured, ledger):
    if not baseline.exists() or not captured.exists():
        require(not baseline.exists() and not captured.exists(), 'Only one ' + kind + ' is absent')
        return {'kind': kind, 'both_actually_absent': True, 'Source_counter_zero_inferred': False}
    unequal = body_unequal = endings_unequal = 0
    with baseline.open('rb') as left, captured.open('rb') as right:
        for number, (a, b) in enumerate(itertools.zip_longest(left, right), 1):
            if a != b:
                unequal += 1
                ledger.write(json.dumps({'file': kind, 'physical_line': number,
                    'installed_raw_bytes_base64': base64.b64encode(a).decode() if a is not None else None,
                    'captured_raw_bytes_base64': base64.b64encode(b).decode() if b is not None else None,
                    'entire_rows_retained': True}) + '\n')
                if number != 1:
                    body_unequal += 1
            if a is None or b is None:
                continue
            if number == 1:
                av, ac, ae = version(a)
                bv, bc, be = version(b)
                require(av == bv and ae == be, 'Only the Program Version YMD clock is an admitted header bridge')
                headers = {'installed': a.decode('utf8'), 'captured': b.decode('utf8'),
                           'exact_version_identity': av, 'installed_clock': ac, 'captured_clock': bc}
            if body(a)[1] != body(b)[1]:
                endings_unequal += 1
    return {'kind': kind, 'both_actually_absent': False, 'installed': ref(baseline), 'captured': ref(captured),
            'Program_Version_clock_bridge': headers, 'physical_rows': number,
            'whole_file_bytes_equal': unequal == 0, 'unequal_physical_rows_including_header': unequal,
            'unequal_rows_after_only_header': body_unequal, 'line_ending_unequal_rows': endings_unequal,
            'all_rows_equal_except_owned_Program_Version_clock': body_unequal == 0}


def numeric_scan(kind, baseline, captured, rows, expected_steps, failures, binding):
    if not baseline.exists() and not captured.exists():
        require(not rows, 'Absent streams have nonempty original named profile')
        return {'stream': kind, 'both_actually_absent': True, 'series': [], 'records': 0}
    require(baseline.is_file() and captured.is_file(), 'Only one physical stream is present')
    declarations, dictionary, ids = {}, [], set()
    line_number = records = stamps = environments = 0
    stamp_index = -1
    environment = stamp = previous_clock = None
    structure_sha = hashlib.sha256()
    with baseline.open('rb') as left, captured.open('rb') as right:
        def pair(exact=True):
            nonlocal line_number
            a, b = left.readline(), right.readline()
            line_number += 1
            require(a and b, 'Unexpected paired EOF at ' + str(line_number))
            av, ae = body(a)
            bv, be = body(b)
            require(ae == be, 'Physical line endings differ at ' + str(line_number))
            require(not exact or av == bv, 'Exact structural row differs at ' + str(line_number))
            return av, bv

        pair(False)  # The prior full pass admitted ONLY the YMD clock suffix.
        while True:
            line, _ = pair()
            if line == 'End of Data Dictionary':
                break
            fields = line.split(',', 2)
            require(len(fields) == 3, 'Invalid dictionary row')
            rid, count = int(fields[0]), int(fields[1])
            require(rid > 0 and rid not in ids, 'Invalid/duplicate dictionary ID')
            ids.add(rid)
            dictionary.append(line)
            if rid <= 6:
                continue
            pattern = (r'(\d+),(\d+),([^,]*),(.+) \[(.*)\] !(TimeStep|Hourly)' if kind == 'eso'
                       else r'(\d+),(\d+),(.+) \[(.*)\] !(TimeStep|Hourly)')
            match = re.fullmatch(pattern, line)
            require(match is not None and count == 1, 'Only declared scalar Timestep/Hourly reports admitted')
            row = {'report_id': rid, 'key': match[3] if kind == 'eso' else None,
                   'name': match[4] if kind == 'eso' else match[3],
                   'units': match[5] if kind == 'eso' else match[4],
                   'frequency': match[6] if kind == 'eso' else match[5], 'raw_dictionary': line}
            index, tolerance = binding(row, rows, kind)
            declarations[rid] = {**row, 'policy_index': index, 'policy': tolerance,
                'samples': 0, 'sum_squared_delta': 0.0, 'max_abs_delta': 0.0,
                'max_relative_delta': 0.0, 'max_abs_sample_index': 0, 'raw_operand_unequal': 0,
                'parsed_binary64_unequal': 0, 'tolerance_failures': 0, 'last_stamp_index': -1}
        require(set(range(1, 7)) <= ids, 'Missing actual Native clock dictionary')
        require(dictionary[0] == '1,5,Environment Title[],Latitude[deg],Longitude[deg],Time Zone[],Elevation[m]', 'Environment definition differs')
        require(dictionary[1] == '2,8,Day of Simulation[],Month[],Day of Month[],DST Indicator[1=yes 0=no],Hour[],StartMinute[],EndMinute[],DayType', 'Interval definition differs')
        require(sorted(d['policy_index'] for d in declarations.values()) == list(range(len(rows))), 'Original named profile not bound exactly once')
        identities = [(d['key'], d['name'], d['units'], d['frequency']) for d in declarations.values()]
        require(len(identities) == len(set(identities)), 'Duplicate physical report identity')
        while True:
            a, b = pair(False)
            if a == 'End of Data' or b == 'End of Data':
                require(a == b == 'End of Data', 'End of Data placement differs')
                break
            af, bf = a.split(','), b.split(',')
            require(af[0] == bf[0], 'Report ID/order differs')
            rid = int(af[0])
            require(rid in ids, 'Undeclared report ID')
            if rid <= 6:
                require(a == b, 'Raw Native environment/clock tuple differs')
                structure_sha.update((a + '\n').encode())
                if rid == 1:
                    require(len(af) == 6 and all(math.isfinite(float(x)) for x in af[2:]), 'Invalid environment tuple')
                    environments += 1
                    environment = tuple(af[1:])
                    stamp = previous_clock = None
                elif rid == 2:
                    require(environment is not None and len(af) == 9, 'Invalid interval tuple')
                    stamp = tuple(af[1:])
                    for token in stamp[:5]:
                        int(token)
                    require(all(math.isfinite(float(x)) for x in stamp[5:7]), 'Nonfinite clock')
                    clock = int(stamp[0]), int(stamp[4]), float(stamp[6])
                    require(previous_clock is None or previous_clock < clock, 'Duplicate/nonmonotonic interval tuple')
                    previous_clock = clock
                    stamps += 1
                    stamp_index += 1
                else:
                    require(False, 'Noninterval data clock outside finite B policy')
                continue
            require(stamp is not None and len(af) == len(bf) == 2, 'Missing clock/incorrect scalar operands')
            d = declarations[rid]
            require(d['last_stamp_index'] < stamp_index, 'Duplicate series sample for interval')
            require(d['frequency'] == 'TimeStep', 'Finite B profile unexpectedly includes non-Timestep data')
            x, y = float(af[1]), float(bf[1])
            require(math.isfinite(x) and math.isfinite(y), 'Nonfinite reported value')
            delta = abs(x - y)
            require(math.isfinite(delta), 'Nonfinite reported delta')
            scale = max(abs(x), abs(y))
            relative = 0.0 if scale == 0.0 else delta / scale
            if delta > d['max_abs_delta']:
                d['max_abs_delta'], d['max_abs_sample_index'] = delta, d['samples']
            d['max_relative_delta'] = max(d['max_relative_delta'], relative)
            # Same original sequential binary64 sum; no fsum, conversion or resampling.
            d['sum_squared_delta'] += delta * delta
            d['raw_operand_unequal'] += af[1] != bf[1]
            d['parsed_binary64_unequal'] += struct.pack('>d', x) != struct.pack('>d', y)
            t = d['policy']
            if not (delta <= t['atol'] or delta <= t['rtol'] * scale):
                d['tolerance_failures'] += 1
                failures.write(json.dumps({'stream': kind, 'report_id': rid, 'sample_index': d['samples'],
                    'physical_line': line_number, 'environment_ordinal': environments,
                    'actual_environment_tuple': environment, 'actual_timestamp_tuple': stamp,
                    'installed_raw': af[1], 'captured_raw': bf[1], 'delta': delta}) + '\n')
            d['samples'] += 1
            d['last_stamp_index'] = stamp_index
            records += 1
        footer, _ = pair()
        match = re.fullmatch(r' Number of Records Written=\s*(\d+)', footer)
        require(match is not None and int(match[1]) == records, 'Physical footer/numeric-row count differs')
        require(left.read(1) == right.read(1) == b'', 'Bytes after physical footer')
    reports = []
    for d in declarations.values():
        require(d['samples'] == expected_steps and d['samples'] > 0, 'Physical samples differ from complete finite duration')
        d['rmse_delta'] = math.sqrt(d['sum_squared_delta'] / d['samples'])
        require(math.isfinite(d['rmse_delta']), 'Nonfinite RMSE')
        d['rmse_limit_met'] = d['rmse_delta'] <= d['policy']['rmse_max']
        d['passed'] = d['tolerance_failures'] == 0 and d['rmse_limit_met']
        del d['last_stamp_index']
        reports.append(d)
    return {'stream': kind, 'both_actually_absent': False, 'records': records, 'series': reports,
            'exact_ordered_dictionary': dictionary, 'environments': environments, 'timestamp_rows': stamps,
            'exact_raw_environment_and_timestamp_rows_sha256': structure_sha.hexdigest()}


def main(args):
    require(args.compare_only, 'Explicit Root read-only comparison invocation required')
    prep = read(PREP / 'plan.json')
    require(checked(prep['helper_Source']) == Path(__file__).resolve(), 'Comparison Source changed')
    capture_path = checked(prep['actual_capture'])
    captured = read(capture_path)
    require(captured['schema'] == 'src06-controlled-air-Native-capture.v1' and captured['accepted']
            and not captured['findings'] and captured['exit_code'] == 0 and captured['launch_error'] is None
            and captured['Native_runtime_bytes_match_before_and_after']
            and captured['actual_three_GNU_DLL_binding_proved'], 'Requires genuine successful custom Native capture')
    installed_path = checked(prep['actual_installed_B12_receipt'])
    installed = read(installed_path)
    require(installed['schema'] == 'recorded-porting-command.v1' and installed['exit_code'] == 0
            and installed['launch_error'] is None and installed['source_bytes_match_before_and_after'],
            'Requires genuine successful installed Native receipt')
    for row in prep['fixed_inputs']:
        checked(row)
    input_file, idd, weather = [(R / row['path']).resolve() for row in prep['fixed_inputs']]
    ic, cc = installed['command'], captured['actual_original_Native_arguments']
    require(normpath(ic[-1]) == normpath(cc[-1]) == normpath(input_file), 'Different real B inputs')
    require(normpath(option(ic, '--weather')) == normpath(option(cc, '-w')) == normpath(weather), 'Different real weather paths')
    require(normpath(option(cc, '-i')) == normpath(idd), 'Capture actual IDD differs')
    require(option(ic, '--output-prefix') == 'energyplus' and '-p' not in cc and '--output-prefix' not in cc, 'Unproven output-prefix bridge')
    require(Path(ic[0]).name.casefold() == 'energyplus.exe', 'Installed producer is not actual Native CLI')
    require((Path(ic[0]).resolve().parent / 'Energy+.idd') == idd, 'Installed default IDD path differs')
    require(not (R / 'Energy+.ini').exists(), 'Current INI could override default IDD inference')
    require(subprocess.check_output(['git', 'show', installed['repository_before']['head'] + ':' + input_file.relative_to(R).as_posix()], cwd=R)
            == input_file.read_bytes(), 'B input differs from installed receipt historical Git')
    require(captured['genuine_engine_inputs'] == prep['fixed_inputs'], 'Actual capture input hash custody differs')
    for row in prep['baseline_reported_files']:
        checked(row)
    for row in captured['output_inventory']:
        if Path(row['path']).suffix in ('.eso', '.mtr', '.rdd', '.mdd'):
            checked(row)
    correction = read(checked(prep['corrected_defined_read_note']))
    require(correction['real_prior_finding_corrected'] and correction['actual_EPVector_allocation_zero_initializes'], 'Missing genuine allocation correction')
    policy_file = checked(prep['original_policy'])
    require(subprocess.check_output(['git', 'show', prep['original_policy_revision'] + ':' + prep['original_policy']['path']], cwd=R)
            == policy_file.read_bytes(), 'Original policy changed from historical version')
    policy = read(policy_file)
    require(policy['schema_version'] == 'con01-output-tolerances.v2', 'Policy schema differs')
    require(all(row['rtol'] == 0 for row in policy['profiles']['B']), 'Original finite rtol differs')
    source = checked(prep['accepted_public_policy_binding_Source']).read_bytes()
    tree = ast.parse(source)
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('norm', 'binding')]
    require([node.name for node in selected] == ['norm', 'binding'], 'Public pure policy binding functions differ')
    namespace = {'require': require}
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<authenticated-public-policy-binding>', 'exec'), namespace)
    baseline_dir = Path(option(ic, '--output-directory')).resolve()
    captured_dir = Path(captured['output_directory']).resolve()
    out = args.output.resolve()
    require(out.is_relative_to(D.resolve()) and out != D.resolve() and not out.exists(), 'Output must be a fresh ignored SRC-06 directory')
    out.mkdir()
    unequal = out / 'all-unequal-physical-rows.jsonl'
    failures = out / 'all-original-policy-failures.jsonl'
    facts, streams, findings = [], [], []
    with unequal.open('x', encoding='utf8', newline='\n') as ledger:
        for kind in ('eso', 'mtr', 'rdd', 'mdd'):
            try:
                facts.append(physical_pass(kind, baseline_dir / ('energyplusout.' + kind), captured_dir / ('eplusout.' + kind), ledger))
            except (OSError, ValueError) as error:
                findings.append(kind + ': ' + str(error))
    try:
        require(not findings, 'Physical file admission failed')
        require(all(row.get('both_actually_absent') or row['line_ending_unequal_rows'] == 0 for row in facts), 'Physical line endings differ')
        require(all(row.get('both_actually_absent') or row['all_rows_equal_except_owned_Program_Version_clock']
                    for row in facts if row['kind'] in ('rdd', 'mdd')), 'RDD/MDD metadata bodies differ')
        with failures.open('x', encoding='utf8', newline='\n') as fail:
            for kind, rows in (('eso', policy['profiles']['B']), ('mtr', policy['meter_profiles']['B'])):
                streams.append(numeric_scan(kind, baseline_dir / ('energyplusout.' + kind),
                    captured_dir / ('eplusout.' + kind), rows, prep['expected_physical_steps'], fail, namespace['binding']))
        require(all(row.get('both_actually_absent') or row['environments'] == 1 for row in streams), 'Unexpected physical environment count')
    except (OSError, ValueError, KeyError, OverflowError) as error:
        findings.append(type(error).__name__ + ': ' + str(error))
    if not failures.exists():
        failures.touch(exist_ok=False)
    series = [row for stream in streams for row in stream['series']]
    metrics = {'series': len(series), 'samples': sum(row['samples'] for row in series),
               'raw_operand_unequal': sum(row['raw_operand_unequal'] for row in series),
               'parsed_binary64_unequal': sum(row['parsed_binary64_unequal'] for row in series),
               'tolerance_failures': sum(row['tolerance_failures'] for row in series),
               'rmse_failures': sum(not row['rmse_limit_met'] for row in series)}
    passed = not findings and bool(series) and metrics['tolerance_failures'] == metrics['rmse_failures'] == 0
    result = {'schema': 'src06-two-genuine-Native-reported-stream-comparison.v1', 'accepted': passed,
        'findings': findings, 'metrics': metrics, 'physical_first_pass': facts, 'streams': streams,
        'actual_installed_Native_receipt': ref(installed_path), 'actual_observed_Native_capture': ref(capture_path),
        'corrected_defined_read_note': prep['corrected_defined_read_note'],
        'original_policy': prep['original_policy'], 'original_policy_revision': prep['original_policy_revision'],
        'policy_metadata_qualifications': prep['policy_metadata_qualifications'],
        'input_custody_qualification': prep['input_custody_qualification'],
        'all_unequal_physical_rows': ref(unequal), 'all_original_policy_failures': ref(failures),
        'prefix_bridge_only': {'installed': 'energyplusout', 'captured': 'eplusout'},
        'comparison_Source': ref(Path(__file__)), 'preparation': ref(PREP / 'plan.json'),
        'Source_or_internal_state_equivalence_or_complete_B_claimed': False,
        'engine_compiler_Cargo_tests_or_captured_outputs_modified': False}
    path = out / 'comparison.json'
    path.write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode('utf8'))
    print(json.dumps(ref(path)))
    return 0 if passed else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--compare-only', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    raise SystemExit(main(parser.parse_args()))

from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-source-controlled-prediction-cohort-actual-review-21';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
def auth(path,digest):
 v=ref(D/path);assert v['sha256']==digest;return v,json.loads(checked(v))
mr,m=auth('source-controlled-prediction-cohort-held-Outer-21-02/manifest.json','3d19c6468d5669038e74518e89a70a3dfeb3d5674f185cf0725b9719f76b9e96')
rr,r=auth('canonical-source-controlled-prediction-cohort-command-Root-21-02/receipt.json','0692d22dbbf63b83f44982327f74f8600b5c2884a3f0c9ac06cda2b8fb30d4f3')
ar,a=auth('Root-controlled-prediction-cohort-application-21/receipt.json','255367f6ad026f21eb2319749744cab51fa72ffcb69e2cffac78bd539e61d55b')
cr,c=auth('Root-controlled-prediction-cohort-comment-correction-21/receipt.json','f26e37c46fe4e1ec363a88d487bdc3e3d9b20f20cfd5d92684e2be9476701a07')
assert a['accepted'] and c['accepted'] and r['exit_code']==0 and r['launch_error'] is None and r['source_bytes_match_before_and_after']
name='heat_balance::ordinary_air_heat_balance::predictor_corrector::lifecycle::prediction::native_cohort::'+m['test_filter']
assert r['command']==['cargo','test','--locked','-p','ep_runtime','--lib',name,'--','--exact','--nocapture']
out=checked(r['stdout']).decode('utf8');err=checked(r['stderr']).decode('utf8');assert out.count('running 1 test')==1 and out.count('test '+name+' ... ok')==1 and re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out; finished in [0-9.]+s',out) and 'error[' not in err
assert r['repository_before']==r['repository_after'] and r['repository_before']['head']==m['base_HEAD']
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};snap=json.loads(checked(r['source_snapshot']));actual={v['historical_path']:v for v in snap['files']};assert len(rows)==4494 and set(rows)==set(actual) and sum(n.endswith('.rs') for n in rows)==4481
for n,v in rows.items():
 b=checked(v['source']);assert b==checked(actual[n]['archive'])==(R/n).read_bytes() and hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes']==actual[n]['size_bytes'],n
assert len(m['files'])==3
for f in m['files']:assert(R/f['canonical_path']).read_bytes()==checked(f['proposed'])
old=checked(c['before']);new=checked(c['after']);assert new==old[:2]+old[3:] and new==checked(m['correction']['proposed']) and old==checked(m['correction']['before'])
assert new.split(b'\n',1)[1]==old.split(b'\n',1)[1]
fixture=json.loads(new.decode('utf8').split('r###"',1)[1].rsplit('"###;',1)[0]);assert fixture['case_count']==len(fixture['cases'])==1168
cases=fixture['cases'];assert [v['parent'] for v in cases]==list(range(1,1169))
clocks=fixture['state_tables']['clock'];groups={};shortened=kickoff=0
for case in cases:
 clock=clocks[case['update_entry']['clock']];key=tuple(clock[n] for n in ['WarmupFlag','KickOffSimulation','ShortenTimeStepSys','UseZoneTimeStepHistory']);groups[key]=groups.get(key,0)+1;shortened+=bool(key[2]);kickoff+=bool(key[1])
assert shortened==77 and kickoff==3 and sum(groups.values())==1168
for k in ['independent_draft_Source_peer','independent_whole_fixture_peer','derivation','actual_capture','actual_Native_reported_comparison','corrected_EPVector_note']:checked(m[k])
source_peer=json.loads(checked(m['independent_draft_Source_peer']));fixture_peer=json.loads(checked(m['independent_whole_fixture_peer']));assert source_peer['accepted'] and fixture_peer['accepted'] and not source_peer['findings'] and not fixture_peer['findings']
previous=json.loads(checked(m['actual24_review']));assert previous['accepted'] and not previous['findings']
existing=[f for f in m['files'] if not f['before_absent']];assert len(existing)==1 and checked(existing[0]['proposed'])==checked(existing[0]['before'])+b'\n#[cfg(test)]\nmod native_cohort;\n'
O.mkdir();result=dict(schema='src06-controlled-prediction-cohort-actual-focused-test.v1',accepted=True,findings=[],producer=mr,original_application=ar,comment_only_correction=cr,complete_compiler_plan=m['complete_final_compiler_Source_plan'],actual_focused_test=rr,actual_snapshot=r['source_snapshot'],all4494_inputs_exact_final_plan_and_live=True,Rust_sources=4481,new_test_bodies=1,actual_executed_test_bodies=1,actual_test_stdout=r['stdout'],actual_test_stderr=r['stderr'],case_count=1168,selected_actual_Native_phase_states=4672,shortened_cases=77,kickoff_cases=3,cohort_groups=[dict(warmup=k[0],kickoff=k[1],shorten=k[2],zone_history=k[3],count=v) for k,v in sorted(groups.items())],Source_peer=m['independent_draft_Source_peer'],Native_fixture_peer=m['independent_whole_fixture_peer'],actual_Native_capture=m['actual_capture'],actual_Native_reported_comparison=m['actual_Native_reported_comparison'],same_fixture_data_after_comment_correction=True,test_result='PASS: real rollback/history/physical Node states checked before only3 parent coefficients; actual sensible method outputs exact binary64 for all1168 actual Native entries.',production_change='Only33-byte cfg(test) child hook; two new test-only files. No math/API/visibility/owner changes.',inherited_production_integration=m['actual24_review'],inherited_actual_B=m['actual24_B'],inherited_actual_A24=m['actual24_A24'],final_CLI_rebuilt_or_executed=False,validation_policy='One focused test selected; first compile failed E0753 before executing tests, diagnosed one comment byte corrected, same focused test then passed. No suite, extra Native engine, A24/B or annual reruns for test-only change.',qualifications=['Only two real private methods at actual Native method entry states; no full parent predictor/sums/psychrometric-cache/corrector or full B trajectory equivalence.','Existing actual24 integration remains the production evidence; no final test-checkpoint CLI rebuild/execution claim.','Historical A14/54 and B14/64 gates unchanged.'],author_Source=ref(Path(__file__).resolve()))
p=O/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

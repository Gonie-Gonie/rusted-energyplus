"""Root-only, one genuine B Native execution. No build, Cargo, tests or comparer.

The accepted five-TU build is a separate prerequisite. Windows module queries
read the actual child PID; they do not inject code or alter engine state.
Every complete observer event is checked incrementally and retained verbatim.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse
import csv
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re
import subprocess
import time

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
PREP = D / 'controlled-air-native-capture-prepared-Outer-21'
META = D / 'controlled-air-native-capture-Root-21'
UNIT = Path('D:/CodexBuild/rusted-energyplus/SRC-06/controlled-air-native-capture-Root-21')
BUILD_SHA = '9ff0df8f49b91b5318a8bdc410c951be21378ae81ad2252f6efc05af50f858e3'
METHODS = ('predictSystemLoad', 'updateTemperatures', 'calcPredictedSystemLoad',
           'calcZoneOrSpaceSums', 'correctAirTemp', 'correctHumRat')
POINTS = {
    'predict_coefficients_before_child': 'predictSystemLoad',
    'update_after_node_rollback_before_history': 'updateTemperatures',
    'predicted_load_before_node': 'calcPredictedSystemLoad',
    'predicted_load_before_report': 'calcPredictedSystemLoad',
    'temperature_after_solve_before_report': 'correctAirTemp',
    'temperature_return_value': 'correctAirTemp',
    'humidity_coefficients_before_solve': 'correctHumRat',
    'humidity_after_clamps_before_feedback': 'correctHumRat',
    'humidity_feedback_complete': 'correctHumRat',
    'sums_before_positive_inlets': 'calcZoneOrSpaceSums',
    'sums_controlled_inlet_before_accumulate': 'calcZoneOrSpaceSums',
    'temperature_before_SNLoad': 'correctAirTemp',
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def ref(path):
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(R).as_posix() if path.is_relative_to(R) else path.as_posix(),
            'sha256': digest, 'bytes': path.stat().st_size}


def checked(row):
    path = (R / row['path']).resolve()
    actual = ref(path)
    need(actual['sha256'] == row['sha256'], 'Whole SHA differs: ' + row['path'])
    need(actual['bytes'] == row.get('bytes', actual['bytes']), 'Whole size differs: ' + row['path'])
    return path


def load(path):
    return json.loads(path.read_bytes())


def write(name, value):
    path = META / name
    with path.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8'))
    return ref(path)


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def stream_observation(path, expected_arguments):
    """Fixed transport reader; at most one complete event is materialized."""
    counts = Counter()
    phases = Counter()
    cohorts = Counter()
    stack = []
    ordinal = 0
    bit_operands = 0
    max_depth = 0
    allocated_sequence_snapshots = 0

    def bits(value):
        nonlocal bit_operands
        if isinstance(value, dict):
            if 'value_bits' in value:
                need(set(value) == {'value_bits'} and isinstance(value['value_bits'], str)
                     and re.fullmatch('[0-9a-f]{16}', value['value_bits']) is not None,
                     'Raw binary64 transport shape differs')
                bit_operands += 1
            for child in value.values():
                bits(child)
        elif isinstance(value, list):
            for child in value:
                bits(child)
        else:
            need(not isinstance(value, float), 'Unexpected JSON float outside raw bit transport')

    def visit(event):
        nonlocal ordinal, max_depth, allocated_sequence_snapshots
        ordinal += 1
        need(event['event_ordinal'] == ordinal, 'Missing/reordered observer event')
        method, phase = event['method'], event['phase']
        invocation = event['invocation_ordinal']
        need(method in METHODS and type(invocation) is int and invocation > 0, 'Unknown method/invocation')
        need(type(event['zoneNum']) is int and event['zoneNum'] > 0
             and type(event['spaceNum']) is int and event['spaceNum'] >= 0, 'Invalid actual zone/space identity')
        identity = (method, invocation, event['zoneNum'], event['spaceNum'])
        address = event['state']['air']['owner_address']
        need(type(address) is int and address > 0, 'Missing actual air-owner address')
        if phase == 'entry':
            parent = stack[-1][0] if stack else None
            need(event['parent_method'] == (parent[0] if parent else None)
                 and event['parent_invocation_ordinal'] == (parent[1] if parent else None),
                 'Observed parent differs from actual nested scope')
            stack.append((identity, address))
            max_depth = max(max_depth, len(stack))
        else:
            need(stack and stack[-1] == (identity, address), 'Scope identity/address/order changed')
            parent = stack[-2][0] if len(stack) > 1 else None
            need(event['parent_method'] == (parent[0] if parent else None)
                 and event['parent_invocation_ordinal'] == (parent[1] if parent else None),
                 'Checkpoint/exit parent differs')
            if phase in ('normal_exit', 'unwind'):
                stack.pop()
            else:
                need(POINTS.get(phase) == method, 'Unexpected method checkpoint')
        counts[(method, phase)] += 1
        phases[phase] += 1
        clock = event['clock']
        for flag in ('WarmupFlag', 'KickOffSimulation', 'ShortenTimeStepSys', 'UseZoneTimeStepHistory'):
            need(type(clock[flag]) is bool, 'Actual clock flag is not bool')
        cohorts[(method, phase, clock['WarmupFlag'], clock['KickOffSimulation'],
                 clock['ShortenTimeStepSys'], clock['UseZoneTimeStepHistory'])] += 1
        aliases = event['state']['aliases']
        need(aliases['is_zone_row'] is True if event['spaceNum'] == 0 else aliases['is_space_row'] is True,
             'Observer is not reading the actual retained air row')
        demand = event['state']['demand']['zone']['value']
        if demand is not None and demand['SequencedOutputRequired']['allocated']:
            allocated_sequence_snapshots += 1
        bits(event)

    decoder = json.JSONDecoder(object_pairs_hook=unique,
        parse_constant=lambda value: need(False, 'Nonfinite JSON literal: ' + value))
    with path.open('r', encoding='utf8', newline='') as handle:
        buffer, eof = '', False

        def more():
            nonlocal buffer, eof
            block = handle.read(65536)
            if block:
                buffer += block
                need(len(buffer) <= 32 * 1024 * 1024, 'Individual JSON value exceeds 32MiB admission bound')
            else:
                eof = True

        def whitespace():
            nonlocal buffer
            while True:
                buffer = buffer.lstrip(' \t\r\n')
                if buffer or eof:
                    return
                more()

        def literal(text):
            nonlocal buffer
            whitespace()
            while len(buffer) < len(text) and not eof:
                more()
            need(buffer.startswith(text), 'Native observer delimiter/order differs: ' + text)
            buffer = buffer[len(text):]

        def value(expected):
            nonlocal buffer
            whitespace()
            while True:
                try:
                    result, end = decoder.raw_decode(buffer)
                except json.JSONDecodeError:
                    if eof:
                        raise
                    more()
                    continue
                need(type(result) is expected, 'Native observer member type differs')
                buffer = buffer[end:]
                return result

        literal('{"schema":')
        schema = value(str)
        need(schema == 'src06-controlled-air-native-observation.v1', 'Unknown observer schema')
        literal(',"actual_native_arguments":')
        arguments = value(list)
        need(arguments == expected_arguments, 'Engine did not receive the exact original Native arguments')
        literal(',"events":[')
        whitespace()
        if not buffer.startswith(']'):
            while True:
                visit(value(dict))
                whitespace()
                if buffer.startswith(']'):
                    break
                literal(',')
        literal('],"terminal_summary":')
        terminal = value(dict)
        literal('}')
        whitespace()
        need(eof and not buffer, 'Trailing Native observer bytes')
    need(not stack, 'Unclosed observer scopes')
    need(terminal['actual_engine_entry_returned'] is True and terminal['actual_engine_exit_code'] == 0
         and terminal['outer_caught_exception_class'] is None, 'Engine did not return normally with zero')
    need(terminal['attempted_events'] == terminal['retained_events'] == ordinal,
         'Attempted/retained/physical event counts differ')
    need(terminal['copy_failures'] == 0 and terminal['counter_overflow'] is False
         and terminal['stream_failed'] is False and terminal['numeric_equivalence_or_PASS_claimed'] is False,
         'Observer transport reports failure/overflow or an unintended PASS claim')
    need([row['method'] for row in terminal['methods']] == list(METHODS), 'Terminal method order differs')
    for row in terminal['methods']:
        method = row['method']
        need(type(row['entered']) is int and row['entered'] >= row['selected'] > 0, 'Missing selected-method coverage')
        need(row['selected'] == counts[(method, 'entry')]
             and row['normal_exits'] == counts[(method, 'normal_exit')]
             and row['unwinds'] == counts[(method, 'unwind')]
             and row['selected'] == row['normal_exits'] + row['unwinds'], 'Terminal/scope counts differ')
        need(row['unwinds'] == 0, 'Actual observed engine scope unwound')
    return {'schema': schema, 'actual_native_arguments': arguments, 'terminal_summary': terminal,
            'physical_events': ordinal, 'raw_binary64_operands': bit_operands,
            'maximum_observed_scope_depth': max_depth, 'phase_counts': dict(phases),
            'allocated_sensible_sequence_snapshots': allocated_sequence_snapshots,
            'bounded_clock_cohort_counts': [dict(zip(('method', 'phase', 'WarmupFlag', 'KickOffSimulation',
                'ShortenTimeStepSys', 'UseZoneTimeStepHistory'), key), count=count)
                for key, count in sorted(cohorts.items())],
            'all_events_visited_no_sampling': True, 'raw_file_modified': False,
            'numerical_Source_equivalence_or_full_B_completion_claimed': False}


def physical_records(path):
    """Physical Native ESO/MTR structure/counts only, no Source-counter proxy."""
    dictionary = {}
    per_id = Counter()
    controls = Counter()
    endings = Counter()
    stage = 'header'
    record_count = 0
    footer = None
    with path.open('r', encoding='utf8', newline='') as handle:
        for number, raw in enumerate(handle, 1):
            ending = 'CRLF' if raw.endswith('\r\n') else 'LF' if raw.endswith('\n') else 'NONE'
            endings[ending] += 1
            line = raw[:-2] if ending == 'CRLF' else raw[:-1] if ending == 'LF' else raw
            if stage == 'header':
                need(line.startswith('Program Version,'), 'Missing Native Program Version header')
                stage = 'dictionary'
            elif stage == 'dictionary':
                if line == 'End of Data Dictionary':
                    need(all(index in dictionary for index in range(1, 7)), 'Missing Native clock dictionary')
                    stage = 'data'
                else:
                    row = next(csv.reader([line], strict=True))
                    need(len(row) >= 3 and row[0].isdigit() and row[1].isdigit(), 'Malformed Native dictionary row')
                    index = int(row[0])
                    need(index not in dictionary, 'Duplicate Native dictionary ID')
                    dictionary[index] = int(row[1])
            elif stage == 'data':
                if line == 'End of Data':
                    stage = 'footer'
                else:
                    row = next(csv.reader([line], strict=True))
                    need(row and row[0].isdigit(), 'Malformed Native physical data row')
                    index = int(row[0])
                    need(index in dictionary and len(row) - 1 == dictionary[index], 'Native data ID/operand count differs')
                    if index > 6:
                        per_id[index] += 1
                        record_count += 1
                    else:
                        controls[index] += 1
            elif stage == 'footer':
                match = re.fullmatch(r' Number of Records Written=\s*(\d+)', line)
                need(match is not None, 'Malformed Native data footer')
                footer = int(match.group(1))
                need(footer == record_count, 'Native footer differs from actual numeric rows')
                stage = 'done'
            else:
                need(False, 'Trailing Native physical stream bytes')
    need(stage == 'done', 'Truncated Native physical stream')
    return {'file': ref(path), 'physical_lines': number, 'dictionary_rows': len(dictionary),
            'declared_data_series': sum(index > 6 for index in dictionary),
            'physical_numeric_records': record_count, 'physical_footer_records': footer,
            'per_report_ID_records': dict(sorted(per_id.items())),
            'physical_control_rows': dict(sorted(controls.items())), 'line_endings': dict(endings),
            'Source_counter_or_numerical_equality_claimed': False}


class ChildModules:
    """Read-only Windows PSAPI snapshots of the actual launched child process."""
    def __init__(self, pid, systemroot):
        need(os.name == 'nt' and ctypes.sizeof(ctypes.c_void_p) == 8, '64-bit Windows query provider required')
        self.kernel = ctypes.WinDLL(str(systemroot / 'System32/kernel32.dll'), use_last_error=True)
        self.psapi = ctypes.WinDLL(str(systemroot / 'System32/psapi.dll'), use_last_error=True)
        self.kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel.OpenProcess.restype = wintypes.HANDLE
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel.CloseHandle.restype = wintypes.BOOL
        self.psapi.EnumProcessModulesEx.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.HMODULE),
                                                   wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), wintypes.DWORD]
        self.psapi.EnumProcessModulesEx.restype = wintypes.BOOL
        self.psapi.GetModuleFileNameExW.argtypes = [wintypes.HANDLE, wintypes.HMODULE, wintypes.LPWSTR, wintypes.DWORD]
        self.psapi.GetModuleFileNameExW.restype = wintypes.DWORD
        self.handle = self.kernel.OpenProcess(0x0400 | 0x0010, False, pid)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())

    def snapshot(self):
        capacity = 256
        while True:
            modules = (wintypes.HMODULE * capacity)()
            needed = wintypes.DWORD()
            if not self.psapi.EnumProcessModulesEx(self.handle, modules, ctypes.sizeof(modules), ctypes.byref(needed), 3):
                raise ctypes.WinError(ctypes.get_last_error())
            if needed.value <= ctypes.sizeof(modules):
                break
            capacity = (needed.value + ctypes.sizeof(wintypes.HMODULE) - 1) // ctypes.sizeof(wintypes.HMODULE)
            need(capacity <= 65536, 'Actual child module list exceeds query bound')
        result = []
        for module in modules[:needed.value // ctypes.sizeof(wintypes.HMODULE)]:
            capacity = 1024
            while True:
                name = ctypes.create_unicode_buffer(capacity)
                length = self.psapi.GetModuleFileNameExW(self.handle, module, name, capacity)
                if not length:
                    raise ctypes.WinError(ctypes.get_last_error())
                if length < capacity:
                    break
                capacity *= 2
                need(capacity <= 65536, 'Actual module path exceeds query bound')
            result.append({'module_handle_address': int(module), 'actual_path': Path(name.value).as_posix()})
        return result

    def close(self):
        if self.handle:
            need(bool(self.kernel.CloseHandle(self.handle)), 'Actual process query handle did not close')
            self.handle = None


def head_metadata(environment):
    query = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=R, env=environment, capture_output=True, text=True)
    return {'head': query.stdout.strip() if query.returncode == 0 else None,
            'query_exit_code': query.returncode, 'acceptance_operand': False}


def main(args):
    need(args.capture_only and not META.exists() and not UNIT.exists(), 'Root flag and fresh capture paths required')
    preparation = load(PREP / 'manifest.json')
    need(checked(preparation['launcher_Source']) == Path(__file__).resolve(), 'Launcher differs from prepared Source')
    build_path = checked(preparation['actual_native_build'])
    need(ref(build_path)['sha256'] == BUILD_SHA, 'Only the reviewed actual Native build is admitted')
    build = load(build_path)
    need(build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after']
         and build['engine_or_Cargo_or_tests_executed'] is False, 'Actual Native build prerequisite failed')
    proof_path = checked(preparation['finite_defined_read_proof'])
    proof = load(proof_path)
    need(proof['finite_B_defined_read_argument_accepted_for_Root_review'] is True,
         'Allocated sequence defined-read proof is missing')
    helper = checked(build['helper_binary'])
    frozen_path = checked(build['frozen_environment'])
    frozen = load(frozen_path)
    need(frozen['accepted'], 'Frozen explicit environment is not accepted')
    environment = frozen['environment']
    need(all(isinstance(k, str) and isinstance(v, str) for k, v in environment.items()), 'Environment values differ')
    env = {key.casefold(): value for key, value in environment.items()}
    need(len(env) == len(environment), 'Case-colliding environment names')
    systemroot = Path(env['systemroot'])
    dlls = build['pinned_runtime_DLLs']
    need(len(dlls) == 3, 'Exactly three actual GNU runtime providers required')
    inputs = preparation['genuine_engine_inputs']
    input_path, idd, weather = [checked(row) for row in inputs]
    relative_input = input_path.relative_to(R).as_posix()
    tracked = subprocess.run(['git', 'ls-files', '--error-unmatch', '--', relative_input],
                             cwd=R, env=environment, capture_output=True)
    need(tracked.returncode == 0, 'Genuine case input is not tracked')
    head_before = head_metadata(environment)
    native_input = subprocess.run(['git', 'show', head_before['head'] + ':' + relative_input],
                                  cwd=R, env=environment, capture_output=True)
    need(native_input.returncode == 0 and native_input.stdout == input_path.read_bytes(), 'Tracked B input differs from current Git')
    query_providers = [ref(systemroot / 'System32/kernel32.dll'), ref(systemroot / 'System32/psapi.dll')]
    protected = [preparation['actual_native_build'], preparation['finite_defined_read_proof'],
                 preparation['launcher_Source'], ref(PREP / 'manifest.json'), build['helper_binary'],
                 build['frozen_environment'], *inputs, *dlls, *query_providers,
                 *proof['actual_pinned_Native_sources']]
    protected = list({row['path']: row for row in protected}.values())
    before = [ref(checked(row)) for row in protected]
    expected_dlls = {Path(row['path']).name.casefold(): checked(row) for row in dlls}
    need(set(expected_dlls) == {'libgcc_s_seh-1.dll', 'libstdc++-6.dll', 'libwinpthread-1.dll'}, 'GNU provider names differ')
    META.mkdir()
    UNIT.mkdir(parents=True)
    output = UNIT / 'B-NOLIMIT-24H'
    output.mkdir()
    raw = UNIT / 'B-NOLIMIT-24H.observation.json'
    native_arguments = [str(helper), '-i', str(idd), '-w', str(weather), '-d', str(output), str(input_path)]
    command = [str(helper), '--surface-observation-file', str(raw), '--', *native_arguments[1:]]
    before_ref = write('Native-runtime-before.json', before)
    start = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    process = None
    exit_code, launch_error = None, None
    module_query_errors = []
    module_query_error_count = 0
    module_query_attempts = 0
    modules = None
    module_observed_elapsed = None
    query = None
    with (META / 'stdout.log').open('xb') as stdout, (META / 'stderr.log').open('xb') as stderr:
        try:
            process = subprocess.Popen(command, cwd=R, env=environment, stdout=stdout, stderr=stderr)
        except OSError as error:
            launch_error = {'type': type(error).__name__, 'message': str(error)}
        if process is not None:
            while process.poll() is None and modules is None:
                module_query_attempts += 1
                try:
                    if query is None:
                        query = ChildModules(process.pid, systemroot)
                    snapshot = query.snapshot()
                    names = {Path(row['actual_path']).name.casefold() for row in snapshot}
                    if set(expected_dlls).issubset(names):
                        modules = snapshot
                        module_observed_elapsed = time.monotonic() - tick
                except (OSError, ValueError) as error:
                    module_query_error_count += 1
                    if len(module_query_errors) < 16:
                        module_query_errors.append({'type': type(error).__name__, 'message': str(error),
                                                    'elapsed_seconds': time.monotonic() - tick})
                if modules is None:
                    time.sleep(0.01)
            exit_code = process.wait()
    query_close_error = None
    if query is not None:
        try:
            query.close()
        except (OSError, ValueError) as error:
            query_close_error = {'type': type(error).__name__, 'message': str(error)}
    finish = datetime.now(timezone.utc).isoformat()
    elapsed = time.monotonic() - tick
    findings = []
    actual_binding = []
    if modules is None:
        findings.append('No complete live child module snapshot proved all three GNU runtime bindings')
    else:
        for name, expected_path in expected_dlls.items():
            matches = [row for row in modules if Path(row['actual_path']).name.casefold() == name]
            try:
                need(len(matches) == 1, 'Actual runtime module basename is missing or ambiguous: ' + name)
                actual_path = Path(matches[0]['actual_path']).resolve()
                need(actual_path == expected_path, 'Actual child DLL was loaded from a different provider: ' + name)
                actual_binding.append({'module': matches[0], 'actual_file': ref(actual_path),
                                       'expected_file': next(row for row in dlls if Path(row['path']).name.casefold() == name)})
            except (OSError, ValueError) as error:
                findings.append(str(error))
    if query_close_error is not None:
        findings.append('Read-only process query handle close failed')
    after, after_error = None, None
    try:
        after = [ref(checked(row)) for row in protected]
        need(after == before, 'Native runtime operands changed during actual capture')
    except (OSError, ValueError) as error:
        after_error = {'type': type(error).__name__, 'message': str(error)}
        findings.append('Native runtime custody differs after execution')
    after_ref = write('Native-runtime-after.json', {'custody': after, 'error': after_error})
    if exit_code != 0 or launch_error is not None:
        findings.append('Actual Native child did not exit zero')
    observation = None
    if raw.is_file():
        try:
            observation = stream_observation(raw, native_arguments)
        except (OSError, ValueError, KeyError, TypeError) as error:
            findings.append('Observer transport check: ' + type(error).__name__ + ': ' + str(error))
    else:
        findings.append('Actual Native observation file is absent')
    physical = {}
    for extension in ('eso', 'mtr'):
        path = output / ('eplusout.' + extension)
        if path.is_file():
            try:
                physical[extension] = physical_records(path)
            except (OSError, ValueError, csv.Error) as error:
                findings.append('Physical ' + extension + ' check: ' + type(error).__name__ + ': ' + str(error))
        else:
            physical[extension] = {'actually_absent': True, 'path': path.as_posix(),
                                   'Source_counter_or_numeric_zero_inferred': False}
            if extension == 'eso':
                findings.append('Actual Native ESO is absent')
    output_inventory = [ref(path) for path in sorted(output.rglob('*')) if path.is_file()]
    modules_ref = write('actual-child-modules.json', {'child_PID': process.pid if process else None,
        'actual_snapshot': modules, 'observed_elapsed_seconds': module_observed_elapsed,
        'query_attempts': module_query_attempts, 'transient_query_error_count': module_query_error_count,
        'first_at_most_16_transient_query_errors': module_query_errors, 'query_close_error': query_close_error,
        'three_actual_GNU_bindings': actual_binding, 'query_provider_files': query_providers,
        'all_three_loaded_from_expected_provider_proved': len(actual_binding) == 3,
        'API_authority': ['https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-enumprocessmodulesex',
                          'https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getmodulefilenameexw'],
        'process_modified_or_modules_closed': False})
    receipt = write('capture.json', {'schema': 'src06-controlled-air-Native-capture.v1',
        'accepted': not findings, 'findings': findings, 'actual_native_build': ref(build_path),
        'finite_defined_read_proof': ref(proof_path), 'launcher_Source': ref(Path(__file__)),
        'command': command, 'actual_original_Native_arguments': native_arguments, 'cwd': R.as_posix(),
        'child_PID': process.pid if process else None, 'exit_code': exit_code, 'launch_error': launch_error,
        'started_utc': start, 'finished_utc': finish, 'elapsed_seconds': elapsed,
        'stdout': ref(META / 'stdout.log'), 'stderr': ref(META / 'stderr.log'),
        'Native_runtime_before': before_ref, 'Native_runtime_after': after_ref,
        'Native_runtime_bytes_match_before_and_after': after == before and after_error is None,
        'actual_module_observation': modules_ref, 'actual_three_GNU_DLL_binding_proved': len(actual_binding) == 3,
        'genuine_engine_inputs': inputs, 'frozen_explicit_environment': build['frozen_environment'],
        'full_retained_observation': ref(raw) if raw.is_file() else None, 'observation_checks': observation,
        'output_directory': output.as_posix(), 'output_inventory': output_inventory,
        'physical_reported_stream_checks': physical,
        'Rust_HEAD_before_metadata_only': head_before, 'Rust_HEAD_after_metadata_only': head_metadata(environment),
        'Rust_source_or_compiler_or_test_claim': False, 'build_configure_or_Cargo_executed': False,
        'numerical_equivalence_or_internal_replay_or_Source_B_completion_claimed': False,
        'static_core_rehashed_during_capture': False,
        'static_core_proof_inherited_from_actual_accepted_build': build['core_after'],
        'standalone_reported_comparison_required': 'Root compares these genuine Native physical streams with installed Native B12; this is not a Source receipt.',
        'explicit_output_prefix_bridge': {'installed_B12': 'energyplusout', 'this_original_default_CLI': 'eplusout'}})
    print(json.dumps(receipt))
    return 0 if not findings else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--capture-only', action='store_true')
    raise SystemExit(main(parser.parse_args()))

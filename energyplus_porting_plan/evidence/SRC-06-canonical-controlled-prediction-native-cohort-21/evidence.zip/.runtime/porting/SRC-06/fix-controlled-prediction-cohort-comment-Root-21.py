from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-controlled-prediction-cohort-comment-correction-21';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'];return b
rp=D/'canonical-source-controlled-prediction-cohort-command-Root-21/receipt.json';rr=ref(rp);assert rr['sha256']=='9f65f53184e20d52c518fae804a53794b8761f455fb94d23c020ab333a29a7ce';receipt=json.loads(checked(rr));assert receipt['exit_code']==101 and receipt['source_bytes_match_before_and_after']
stderr=checked(receipt['stderr']);assert stderr.count(b'error[E0753]')==1 and b'due to 1 previous error' in stderr
snapshot=json.loads(checked(receipt['source_snapshot']));parents={v['historical_path']:v for v in snapshot['files']};assert len(parents)==4494
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive'])
n='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction/fixtures/native_prediction_b.rs';p=R/n;a=p.read_bytes();assert len(a)==6954951 and hashlib.sha256(a).hexdigest()=='392bf8efac4d919aa5101fe1661dfea826122990ce63f4344f1bc7c4675ab690' and a.startswith(b'//! Test-only')
b=a[:2]+a[3:];assert b.startswith(b'// Test-only') and b.split(b'\n',1)[1]==a.split(b'\n',1)[1]
O.mkdir();(O/'before.rs').write_bytes(a);(O/'after.rs').write_bytes(b);p.write_bytes(b);assert p.read_bytes()==b
for path,v in parents.items():assert (R/path).read_bytes()==(b if path==n else checked(v['archive']))
result=dict(accepted=True,findings=[],failed_actual_command=rr,failed_snapshot=receipt['source_snapshot'],before=ref(O/'before.rs'),after=ref(O/'after.rs'),canonical_path=n,exact_operation='Delete exactly ASCII ! byte at offset2 in first comment: //! -> //. Included constant JSON and every following byte unchanged.',data_test_and_production_bytes_unchanged=True,all4493_other_inputs_unchanged=True,reason='Actual rustc E0753 rejects inner doc comment in include! constant context. Pure comment correction; no numerical or fixture state change.',author_Source=ref(Path(__file__).resolve()))
out=O/'receipt.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(out)))

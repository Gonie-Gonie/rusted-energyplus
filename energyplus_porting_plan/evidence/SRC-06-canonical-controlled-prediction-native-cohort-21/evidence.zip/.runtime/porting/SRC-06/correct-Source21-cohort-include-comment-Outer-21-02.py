"""Immutable one-character include-context correction; no main edits or Cargo."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OLD=D/'source-controlled-prediction-cohort-held-Outer-21'
O=D/'source-controlled-prediction-cohort-held-Outer-21-02'
def ref(p):
    b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def check(row):
    p=R/row['path'];assert ref(p)['sha256']==row['sha256'];return p
def read(row):return json.loads(check(row).read_bytes())
def put(name,b):
    p=O/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(name,x):return put(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
assert not O.exists()
old_ref=ref(OLD/'manifest.json');assert old_ref['sha256']=='8c830c24ffb9efb383a8690fafb0904ad10125bde2f8d1c1d5ed1de7930e0176'
old=read(old_ref);old_plan=read(old['complete_final_compiler_Source_plan'])
failed_ref=ref(D/'canonical-source-controlled-prediction-cohort-command-Root-21/receipt.json')
assert failed_ref['sha256']=='9f65f53184e20d52c518fae804a53794b8761f455fb94d23c020ab333a29a7ce'
failed=read(failed_ref);assert failed['exit_code']==101 and failed['launch_error'] is None and failed['source_bytes_match_before_and_after']
stderr=check(failed['stderr']).read_text(encoding='utf8');assert 'error[E0753]' in stderr and 'native_prediction_b.rs' in stderr
app_ref=ref(D/'Root-controlled-prediction-cohort-application-21/receipt.json')
assert app_ref['sha256']=='255367f6ad026f21eb2319749744cab51fa72ffcb69e2cffac78bd539e61d55b'
app=read(app_ref);assert app['accepted'] and not app['findings'] and app['producer']==old_ref
observed={row['historical_path']:row for row in read(failed['source_snapshot'])['files']}
assert len(observed)==4494 and len(old_plan['entries'])==4494
for row in old_plan['entries']:
    assert row['final_sha256']==observed[row['path']]['archive']['sha256']
fixture=next(row for row in old['files'] if row['canonical_path'].endswith('/fixtures/native_prediction_b.rs'))
path=fixture['canonical_path'];before=check(fixture['proposed']).read_bytes()
assert before.startswith(b'//! Test-only') and before.count(b'\n')==2
after=before[:2]+before[3:]
assert len(after)==len(before)-1 and after.startswith(b'// Test-only')
assert after.split(b'\n',1)[1]==before.split(b'\n',1)[1]
for row in old['files']:
    actual=(R/row['canonical_path']).read_bytes()
    assert actual in (before,after) if row is fixture else actual==check(row['proposed']).read_bytes()
O.mkdir()
node=next(x for x in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<literal>','exec'),ns)
def diff(a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode()
forward,inverse=diff(before,after),diff(after,before)
assert ns['apply_literal'](before,forward)==after and ns['apply_literal'](after,inverse)==before
new_ref=put('proposed/'+path,after)
parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,cwd=R,capture_output=True)
assert parsed.returncode==0 and not parsed.stderr
parse={'exit_code':0,'stdout':put('parse/fixture.stdout',parsed.stdout),'stderr':put('parse/fixture.stderr',parsed.stderr)}
correction={'canonical_path':path,'before':fixture['proposed'],'proposed':new_ref,
    'forward_diff':put('correction-forward.diff',forward),'inverse_diff':put('correction-inverse.diff',inverse),
    'literal_applications':2,'Source_only_parse':parse,'deleted_byte_offset':2,'deleted_byte_ascii':33,
    'all_bytes_after_first_physical_line_unchanged':True,
    'unchanged_constant_and_JSON_data_suffix_sha256':hashlib.sha256(after.split(b'\n',1)[1]).hexdigest()}
new_file=dict(fixture);new_file.update(proposed=new_ref,literal_inverse=put('literal-inverse/'+path,b''),
    forward_diff=put('coherent-fixture-forward.diff',diff(b'',after)),inverse_diff=put('coherent-fixture-inverse.diff',diff(after,b'')),Source_only_parse=parse)
assert ns['apply_literal'](b'',check(new_file['forward_diff']).read_bytes())==after
assert ns['apply_literal'](after,check(new_file['inverse_diff']).read_bytes())==b''
files=[new_file if row is fixture else row for row in old['files']]
entries=[]
for row in old_plan['entries']:
    new=dict(row)
    if row['path']==path:new.update(final_sha256=new_ref['sha256'],final_bytes=len(after),source=new_ref,origin='test-only include comment context correction')
    entries.append(new)
plan=dict(old_plan);plan.update(entries=entries,prior_plan=old['complete_final_compiler_Source_plan'],
    sole_successor_change='Delete ! byte2 in fixture first-line comment; JSON/expected bits/test and production code unchanged.')
plan_ref=doc('complete-final-compiler-Source-plan.json',plan)
manifest=dict(old);manifest.update(schema='src06-held-Source21-complete-Native-cohort-correction.v2',
    status='HELD one-character include-context correction; focused test02 pending',files=files,
    complete_final_compiler_Source_plan=plan_ref,rejected_first_packet=old_ref,
    rejected_first_application=app_ref,rejected_first_unit_receipt=failed_ref,
    rejected_first_snapshot=failed['source_snapshot'],first_failure='Rust E0753 inner doc comment is invalid inside include!; no test body executed.',
    correction=correction,full_coherent_literal_applications=6,correction_literal_applications=2,Source_only_parses=1,
    fixture_derivation_unchanged_from_first_packet=True,
    derivation_to_final_fixture_bridge='Original derivation emits the preserved //! comment. Final fixture equals it except deletion of the single first-line !; all following constant/JSON bytes are identical. No rederivation or old-author mutation.',
    source_and_fixture_peers_inherited_scope='First full Source/fixture/final-join peers remain authoritative for unchanged bytes and all data; Root independently checks this pure one-byte comment correction before application. No second raw stream scan or duplicate semantic peer required.',
    author_Source=ref(Path(__file__)),sealer_Source=ref(Path(__file__)),Cargo_tests_Native_or_main_mutations=False)
result=doc('manifest.json',manifest)
print(json.dumps({'manifest':result,'plan':plan_ref,'corrected_fixture':new_ref}))

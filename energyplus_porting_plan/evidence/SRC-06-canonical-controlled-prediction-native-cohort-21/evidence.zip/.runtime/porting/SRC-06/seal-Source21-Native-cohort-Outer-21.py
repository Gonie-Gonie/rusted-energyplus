"""Final24-parent cohort seal only; never apply, compile, run or edit main."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import re
import subprocess

R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
S=D/'source-controlled-prediction-cohort-draft-Outer-21'
O=D/'source-controlled-prediction-cohort-held-Outer-21'

def ref(path):
    b=path.read_bytes();return {'path':path.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def check(row):
    p=R/row['path'];actual=ref(p);assert actual['sha256']==row['sha256'] and actual['bytes']==row.get('bytes',actual['bytes']),row;return p
def read(row):return json.loads(check(row).read_bytes())
def put(name,b):
    p=O/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(name,x):return put(name,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode('utf8'))

def main(args):
    assert re.fullmatch('[0-9a-f]{40}',args.base_head)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==args.base_head
    assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=R,text=True).strip()==args.base_head
    assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=R)
    assert not O.exists()
    draft_ref=ref(S/'draft.json');assert draft_ref['sha256']=='27c3cc522090eb6bac995026a2025db2a863b9eb75825280f16bffc78aa981cc'
    draft=read(draft_ref)
    actual_ref=ref(D/'Root-source-zone-equipment-orchestration-actual-review-24/review.json')
    assert actual_ref['sha256']==args.actual24_sha256
    actual=read(actual_ref);assert actual['accepted'] and not actual['findings'] and actual['same4492_archived_inputs_exact_final_plan']
    plan=read(actual['complete_compiler_plan']);entries={row['path']:row for row in plan['entries']};assert len(entries)==4492
    B=read(actual['actual_B']);A=read(actual['actual_A24'])
    assert B['exit_code']==6 and A['exit_code']==0 and B['source_snapshot']==A['source_snapshot']
    snapshot=read(B['source_snapshot']);archived={row['historical_path']:row for row in snapshot['files']}
    assert set(archived)==set(entries)
    # One persistent read-only Git provider for all whole blobs. This preserves
    # the exact check without launching 4492 separate Git processes.
    git_bridges=[]
    provider=subprocess.Popen(['git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
    assert provider.stdin is not None and provider.stdout is not None
    try:
        for path,row in entries.items():
            b=check(row['source']).read_bytes()
            assert (R/path).read_bytes()==check(archived[path]['archive']).read_bytes()==b
            assert hashlib.sha256(b).hexdigest()==row['final_sha256']
            provider.stdin.write((args.base_head+':'+path+'\n').encode('utf8'));provider.stdin.flush()
            header=provider.stdout.readline().split();assert len(header)==3 and header[1]==b'blob',path
            blob=provider.stdout.read(int(header[2]));assert provider.stdout.read(1)==b'\n'
            if blob!=b:
                assert path=='crates/ep_runtime/src/ideal_loads/binding/scheduled_output.rs',path
                assert hashlib.sha256(blob).hexdigest()=='7a48a7758b121a053c2048cb7cdaa3b01c8eb533189159017641215677ad2f85' and len(blob)==49459
                assert hashlib.sha256(b).hexdigest()=='8c554ec09415548122ea6feae459364c22710b8740ab61b0e75f62e44a4af148' and len(b)==49460
                literal=b'    pub calculation_heating_outdoor_air_maximum_flow_first_warning_call: PurchasedAirCalcHeatingOutdoorAirMaximumFlowFirstWarningCallSnapshot,\r\n'
                assert b.count(literal)==1 and b.replace(literal,literal.replace(b'\r\n',b'\n'))==blob
                git_bridges.append({'path':path,'actual_archive_and_live':ref(R/path),
                    'Git':{'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob)},
                    'exact_extra_CR_byte_offset':b.index(literal)+len(literal)-2,
                    'exact_physical_row_utf8':literal.decode('utf8'),
                    'scope':'Sole known unselected baseline physical CRLF byte; full actual24/live/compiler bytes preserved. This literal proof does not normalize the file or claim Git whole equality.'})
    finally:
        provider.stdin.close();provider.stdout.close();assert provider.wait()==0
    fixture_peer_ref=ref(D/'Peer-controlled-prediction-cohort-fixture-review-21/review.json')
    assert fixture_peer_ref['sha256']=='11a30f3b819b3e3a4363ebe3fc04865c70845ffc97b354cecad95ffba5930e9e'
    fixture_peer=read(fixture_peer_ref);assert fixture_peer['accepted'] and not fixture_peer['findings']
    source_peer_path=Path(args.source_peer).resolve();source_peer_ref=ref(source_peer_path);source_peer=read(source_peer_ref)
    assert source_peer['accepted'] and not source_peer['findings']
    derivation=read(draft['derivation']);check(derivation['fixture'])
    literal_node=next(node for node in ast.parse((D/'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(node,ast.FunctionDef) and node.name=='apply_literal')
    ns={'re':re};exec(compile(ast.Module(body=[literal_node],type_ignores=[]),'<literal-patch>','exec'),ns)
    O.mkdir();files=[];selected={};rename=None
    for i,row in enumerate(draft['files'],1):
        path=row['canonical_path'];before=check(row['before']).read_bytes() if row['before'] else b''
        proposed=check(row['proposed']).read_bytes()
        if row['before_absent']:assert path not in entries and not (R/path).exists()
        else:assert before==check(entries[path]['source']).read_bytes()==(R/path).read_bytes()
        if path.endswith('/native_cohort.rs'):
            old=proposed;needle=b'fn all_native_B_prediction_entries_match_source_rollback_and_sensible_bits()'
            assert proposed.count(needle)==1
            proposed=proposed.replace(needle,b'fn all_native_b_prediction_entries_match_source_rollback_and_sensible_bits()')
            diff=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='frozen-draft-test',tofile='final-lowercase-test')).encode()
            assert ns['apply_literal'](old,diff)==proposed
            rename=put('test-name-only-correction.diff',diff)
        forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode()
        inverse=''.join(difflib.unified_diff(proposed.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode()
        assert ns['apply_literal'](before,forward)==proposed and ns['apply_literal'](proposed,inverse)==before
        parsed=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,cwd=R,capture_output=True)
        assert parsed.returncode==0 and not parsed.stderr
        proposed_ref=put('proposed/'+path,proposed);selected[path]=proposed_ref
        files.append({'canonical_path':path,'before_absent':row['before_absent'],'before':put('before/'+path,before) if before else None,
            'proposed':proposed_ref,'literal_inverse':put('literal-inverse/'+path,before),
            'forward_diff':put(f'diffs/{i:02d}-forward.diff',forward),'inverse_diff':put(f'diffs/{i:02d}-inverse.diff',inverse),
            'Source_only_parse':{'exit_code':0,'stdout':put(f'parse/{i:02d}.stdout',parsed.stdout),'stderr':put(f'parse/{i:02d}.stderr',parsed.stderr)}})
    final=[]
    for path in sorted(set(entries)|set(selected)):
        source=selected.get(path) or entries[path]['source'];p=check(source)
        final.append({'path':path,'final_sha256':source['sha256'],'final_bytes':p.stat().st_size,'source':ref(p),
            'origin':'selected test-only cohort Source' if path in selected else 'whole exact accepted actual24 parent'})
    assert len(final)==4494 and sum(row['path'].endswith('.rs') for row in final)==4481
    final_plan=doc('complete-final-compiler-Source-plan.json',{'schema':'src06-complete-held-compiler-Source-plan.v1','base_HEAD':args.base_head,
        'actual24':actual_ref,'parent_plan':actual['complete_compiler_plan'],'entries':final,'compiler_inputs':4494,'Rust_sources':4481,
        'sole_known_unselected_Git_physical_byte_bridge':git_bridges})
    result=doc('manifest.json',{'schema':'src06-held-Source21-complete-Native-cohort.v1','status':'HELD final24-parent test Sources; actual focused test pending',
        'base_HEAD':args.base_head,'actual24_review':actual_ref,'actual24_snapshot':B['source_snapshot'],'actual24_B':actual['actual_B'],'actual24_A24':actual['actual_A24'],
        'parent24_complete_plan':actual['complete_compiler_plan'],'files':files,'new_Source_files':2,'existing_Source_files':1,
        'literal_applications':6,'Source_only_parses':3,'complete_final_compiler_Source_plan':final_plan,
        'immutable_Source_draft':draft_ref,'independent_draft_Source_peer':source_peer_ref,'independent_whole_fixture_peer':fixture_peer_ref,
        'test_name_only_correction':rename,'derivation':draft['derivation'],'actual_capture':draft['actual_capture'],
        'actual_Native_reported_comparison':draft['actual_Native_reported_comparison'],'corrected_EPVector_note':draft['corrected_EPVector_note'],
        'selected_parent_unchanged_across_draft_and_committed24_and_actual24':True,
        'sole_known_unselected_Git_physical_byte_bridge':git_bridges,
        'test_filter':'all_native_b_prediction_entries_match_source_rollback_and_sensible_bits','new_test_bodies':1,'cohort_cases':1168,
        'production_code_change':'Only cfg(test) child hook appended; math, visibility, owners, APIs and non-test execution unchanged.',
        'test_scope':'Two actual private update and sensible methods at real Native entry states; rollback/history/physical Node asserted before only3 later coefficients. No full parent predictor/sums/cache20/corrector or Source trajectory claim.',
        'validation_policy':'Root runs exactly one focused existing-library test build/filter after final peer; no habitual suite or new Native engine run. No additional A/B rerun required for cfg(test)-only Sources unless Root finds a concrete reason.',
        'author_Source':draft['author_Source'],'sealer_Source':ref(Path(__file__)),'Cargo_tests_Native_or_main_mutations':False})
    assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=R)
    print(json.dumps(result))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base-head',required=True);p.add_argument('--actual24-sha256',required=True)
    p.add_argument('--source-peer',required=True);main(p.parse_args())

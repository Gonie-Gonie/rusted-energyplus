"""Root-only five-object Native build; no configure, engine, Cargo or tests.

Custody is Native-specific. Concurrent Rust work and commits are permitted;
Rust HEADs are metadata only, never a compilation/snapshot acceptance premise.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,re,subprocess,time

R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PREP=D/'controlled-air-native-build-prepared-Outer-21'
META=D/'controlled-air-native-build-Root-21'
BUILD=R/'.runtime/ep261-gcc13-o0'
UNIT=Path('D:/CodexBuild/rusted-energyplus/SRC-06/controlled-air-native-build-Root-21')
TARGET='controlled_air_owner_helper'

def ref(p):
    p=p.resolve()
    with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),
            'sha256':digest,'bytes':p.stat().st_size}
def checked(row):
    p=(R/row['path']).resolve();actual=ref(p)
    assert actual['sha256']==row['sha256'],row['path']
    assert actual['bytes']==row.get('bytes',row.get('size_bytes',actual['bytes']))
    return p
def load(p):return json.loads(p.read_bytes())
def write(name,value):
    p=META/name
    with p.open('xb') as stream:stream.write((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
    return ref(p)
def norm(v):return str(v).replace('\\','/').casefold()
def rust_head_metadata(environment):
    # Metadata only: no worktree test, Rust source read or equality assertion.
    q=subprocess.run(['git','rev-parse','HEAD'],cwd=R,env=environment,capture_output=True,text=True)
    return {'head':q.stdout.strip() if q.returncode==0 else None,'query_exit_code':q.returncode,
            'query_stderr':q.stderr,'acceptance_operand':False}
def steps(text):return re.findall(r'^\[\d+/\d+\] (.+)$',text,re.M)

def main(args):
    assert args.build_only and not META.exists()
    preparation=load(PREP/'manifest.json');assert checked(preparation['launcher_Source'])==Path(__file__).resolve()
    preflight_path=checked(preparation['actual_preflight']);p=load(preflight_path)
    assert p['accepted'] and not p['findings'] and p['status']=='CONFIGURED_AND_DRY_RUN_ONLY_NOT_BUILT'
    assert len(p['added_five_TUs'])==5 and p['old_registry_rows']==790 and p['new_registry_rows']==795
    assert p['no_objects_binary_or_map_produced'] and p['build_or_engine_executed'] is False
    manifest_path=checked(p['accepted_harness']);m=load(manifest_path)
    peer=load(checked(p['independent_peer']));assert peer['accepted'] and not peer['findings']
    assert peer['reviewed_packet']==p['accepted_harness']
    before_config=load(checked(p['before']))
    frozen_path=checked(m['existing_build_environment']);frozen=load(frozen_path)
    assert frozen['accepted'] and frozen['provider_set_complete_for_this_build']
    environment=frozen['environment'];assert environment==before_config['environment']
    env={key.casefold():value for key,value in environment.items()};assert len(env)==len(environment)
    assert all(isinstance(k,str) and isinstance(v,str) for k,v in environment.items())
    compiler=checked(frozen['compiler']);assert norm(env['path'].split(';')[0])==norm(compiler.parent)
    providers=p['actual_providers'];assert len(providers)==73
    cmake=checked(next(row for row in providers if Path(row['path']).name=='cmake.exe'))
    dlls=p['pinned_runtime_DLLs'];assert len(dlls)==3
    assert {Path(row['path']).name for row in dlls}=={'libgcc_s_seh-1.dll','libstdc++-6.dll','libwinpthread-1.dll'}
    assert all(checked(row).parent==compiler.parent for row in dlls)
    assert UNIT.resolve()==Path('D:/CodexBuild/rusted-energyplus/SRC-06/controlled-air-native-build-Root-21').resolve()
    assert (UNIT/'bin').is_dir()
    executable=UNIT/'bin'/(TARGET+'.exe');link_map=UNIT/'bin'/(TARGET+'.map')
    implib=BUILD/'Products'/('lib'+TARGET+'.dll.a')
    rows=p['added_five_TUs'];outputs=[Path(row['output']) for row in rows]
    assert not executable.exists() and not link_map.exists() and not implib.exists()
    assert all(not x.exists() for x in outputs)
    for output in outputs:
        assert output.resolve().is_relative_to((BUILD/'CMakeFiles'/(TARGET+'.dir')).resolve())
    config_preparation=load(checked(preparation['configure_preparation']))
    protected=[preparation['actual_preflight'],preparation['launcher_Source'],preparation['author_Source'],ref(PREP/'manifest.json'),
               p['accepted_harness'],p['independent_peer'],m['integration_contract'],m['Native_literal_extents'],
               m['existing_build_environment'],*m['payload'],*m['Native_wholes'],*config_preparation['include_chain']]
    # Deduplicate exact paths. Historic mutable cache/registry references inside
    # the Source packet are not reinterpreted as current build operands.
    protected=list({row['path']:row for row in protected}.values())
    live_cache=BUILD/'CMakeCache.txt';live_commands=BUILD/'compile_commands.json'
    expected_cache=checked(p['immutable_after_cache']);expected_commands=checked(p['immutable_after_commands'])
    assert live_cache.read_bytes()==expected_cache.read_bytes()
    assert live_commands.read_bytes()==expected_commands.read_bytes()
    assert len(load(live_commands))==795
    # Preserve the finite archive operands already present in the accepted link
    # plan. This is not a recursive library search or a new build dependency.
    archive_paths=[]
    for token in re.findall(r'(?<!\S)([^\s"]+\.a)(?=\s|")',p['dry_run_five_compiles_one_link'][-1]):
        if token.startswith('-'):continue
        path=(BUILD/token.replace('\\','/')).resolve()
        assert path.is_relative_to(BUILD.resolve()) and path.is_file()
        if path not in archive_paths:archive_paths.append(path)
    assert BUILD/'Products/libenergypluslib.a' in archive_paths
    def custody():
        print('Native custody: stream-hash unchanged core, payloads, registry and providers.',flush=True)
        source_rows=[ref(checked(row)) for row in protected]
        provider_rows=[ref(checked(row)) for row in providers]
        archives=[ref(path) for path in archive_paths]
        core=next(row for row in archives if row['path']==p['core_after']['path'])
        assert core['sha256']=='32d873007f14c3f8e3c66c6280ebd508c7cb595cea28f4a20f47ac745113a694'
        assert core['bytes']==1832731010
        cache_ref=ref(live_cache);commands_ref=ref(live_commands)
        assert cache_ref['sha256']==p['immutable_after_cache']['sha256']
        assert commands_ref['sha256']==p['immutable_after_commands']['sha256']
        shadows=[UNIT/'bin',R,Path(env['systemroot'])/'System32',Path(env['systemroot'])/'System',Path(env['systemroot'])]
        assert not any((folder/Path(row['path']).name).exists() for folder in shadows for row in dlls)
        return {'Native_sources':source_rows,'actual_providers':provider_rows,'core':core,'explicit_link_archives':archives,
                'live_cache':cache_ref,'live_compile_registry':commands_ref,'pinned_runtime_DLLs':dlls,
                'earlier_DLL_search_shadows_absent':True,'full_explicit_environment':environment}
    before=custody();head_before=rust_head_metadata(environment)
    META.mkdir();before_ref=write('Native-before.json',before)
    command=[str(cmake),'--build',str(BUILD),'--target',TARGET,'--parallel','1','--verbose']
    start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();exit_code=None;launch_error=None
    with (META/'stdout.log').open('xb') as stdout,(META/'stderr.log').open('xb') as stderr:
        try:exit_code=subprocess.run(command,cwd=R,env=environment,stdout=stdout,stderr=stderr).returncode
        except OSError as error:launch_error={'type':type(error).__name__,'message':str(error)}
    elapsed=time.monotonic()-tick;finish=datetime.now(timezone.utc).isoformat()
    head_after=rust_head_metadata(environment)
    after=None;after_error=None
    try:after=custody();assert after==before
    except (AssertionError,OSError) as error:after_error={'type':type(error).__name__,'message':str(error)}
    after_ref=write('Native-after.json',{'custody':after,'error':after_error})
    receipt={'schema':'recorded-Native-build-command.v1','command':command,'cwd':R.as_posix(),
        'exit_code':exit_code,'launch_error':launch_error,'started_utc':start,'finished_utc':finish,'elapsed_seconds':elapsed,
        'stdout':ref(META/'stdout.log'),'stderr':ref(META/'stderr.log'),'Native_before':before_ref,'Native_after':after_ref,
        'Native_bytes_match_before_and_after':after==before and after_error is None,
        'Rust_HEAD_before_metadata_only':head_before,'Rust_HEAD_after_metadata_only':head_after,
        'Rust_source_snapshot_or_compiler_claim':False,'Rust_change_is_acceptance_gate':False,
        'actual_preflight':ref(preflight_path),'launcher_Source':ref(Path(__file__)),
        'configure_engine_Cargo_or_tests_executed':False}
    receipt_ref=write('receipt.json',receipt)
    if exit_code!=0 or launch_error is not None or after_error is not None:
        print(json.dumps({'receipt':receipt_ref,'accepted':False,'build_exit':exit_code,'Native_after_error':after_error}))
        return exit_code if isinstance(exit_code,int) and exit_code>0 else 1
    stdout=(META/'stdout.log').read_text(encoding='utf8');actual_steps=steps(stdout)
    assert len(actual_steps)==6,'Only five new compile/object operations and one new link are permitted'
    expected_steps=p['dry_run_five_compiles_one_link']
    assert sorted(norm(x) for x in actual_steps[:5])==sorted(norm(x) for x in expected_steps[:5])
    assert norm(actual_steps[-1])==norm(expected_steps[-1])
    assert all(output.is_file() for output in outputs)
    actual_objects={x.resolve() for x in (BUILD/'CMakeFiles'/(TARGET+'.dir')).rglob('*.obj')}
    assert actual_objects=={x.resolve() for x in outputs}
    assert executable.is_file() and link_map.is_file()
    with executable.open('rb') as stream:assert stream.read(2)==b'MZ'
    # Streaming map inspection retains only five finite LOAD witnesses and any
    # forbidden original-TU archive witnesses, rather than loading the map.
    witnesses={row['output']:[] for row in rows};old_tu=[];line_count=0
    original_pattern=re.compile(r'libenergypluslib\.a\([^)]*ZoneTempPredictorCorrector\.cc\.obj\)',re.I)
    with link_map.open(encoding='utf8') as stream:
        for line_count,line in enumerate(stream,1):
            if original_pattern.search(line):old_tu.append({'line':line_count,'literal':line.rstrip('\n')})
            if line.startswith('LOAD '):
                for row in rows:
                    relative=Path(row['output']).relative_to(BUILD)
                    if norm(relative) in norm(line):witnesses[row['output']].append({'line':line_count,'literal':line.rstrip('\n')})
    assert not old_tu,'The old libenergypluslib ZTPC TU must not be linked beside the full derived TU'
    assert all(len(value)==1 for value in witnesses.values())
    ztpc=next(row for row in rows if row['file'].endswith('/ZoneTempPredictorCorrector.controlled_air.cc'))
    assert len(witnesses[ztpc['output']])==1
    products=[{'compile_registration':row,'object':ref(Path(row['output'])),'map_LOAD':witnesses[row['output']]} for row in rows]
    result=write('native-build.json',{'schema':'src06-controlled-air-Native-built.v1','accepted':True,'findings':[],
        'status':'BUILT_FIVE_OBJECTS_CORE_PRESERVED_ENGINE_NOT_RUN','actual_preflight':ref(preflight_path),
        'accepted_harness':p['accepted_harness'],'independent_Source_peer':p['independent_peer'],'actual_build':receipt_ref,
        'Native_before':before_ref,'Native_after':after_ref,'Native_bytes_match_before_and_after':True,
        'objects_and_map_LOADs':products,'new_ZTPC_object_LOAD':witnesses[ztpc['output']],
        'old_core_ZTPC_archive_member_matches':old_tu,'map_lines_streamed':line_count,
        'actual_only_five_compile_operations_one_link':actual_steps,'helper_binary':ref(executable),'map_file':ref(link_map),
        'optional_import_library':ref(implib) if implib.is_file() else None,
        'core_before':before['core'],'core_after':after['core'],'actual_providers':before['actual_providers'],
        'explicit_link_archives_before':before['explicit_link_archives'],'explicit_link_archives_after':after['explicit_link_archives'],
        'pinned_runtime_DLLs':dlls,'frozen_environment':m['existing_build_environment'],
        'provider_closure_scope':'Exact73 build/runtime provider files, explicit environment and DLL search-shadow checks plus actual5object LOADs/new ZTPC/unchanged core. No engine process or actual Windows module-load observation yet.',
        'Rust_HEAD_before_metadata_only':head_before,'Rust_HEAD_after_metadata_only':head_after,
        'Rust_source_snapshot_or_compiler_claim':False,'unscanned_historical_object_whole_equality_claim':False,
        'engine_or_Cargo_or_tests_executed':False,'canonical_Rust_mutation_by_launcher':False,
        'launcher_Source':ref(Path(__file__)),'required_next':'Root reviews built artifacts/provider binding before separately authorizing genuine engine capture. This launcher never executes the helper.'})
    print(json.dumps(result));return 0

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--build-only',action='store_true')
    raise SystemExit(main(parser.parse_args()))

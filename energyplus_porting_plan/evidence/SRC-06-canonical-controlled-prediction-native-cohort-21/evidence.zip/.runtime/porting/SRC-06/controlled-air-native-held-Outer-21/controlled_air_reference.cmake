# One additive five-TU target. Include the current project chain first.
if(NOT DEFINED CONTROLLED_AIR_SOURCE_DIR OR NOT DEFINED CONTROLLED_AIR_OUTPUT_DIR)
  message(FATAL_ERROR "Controlled-air capture requires reviewed Source and a fresh D output directory")
endif()
if(CMAKE_SOURCE_DIR STREQUAL PROJECT_SOURCE_DIR)
  get_property(_controlled_air_scheduled GLOBAL PROPERTY CONTROLLED_AIR_SCHEDULED)
  if(NOT _controlled_air_scheduled)
    set_property(GLOBAL PROPERTY CONTROLLED_AIR_SCHEDULED TRUE)
    function(controlled_air_add_reference)
      if(NOT TARGET energypluslib)
        message(FATAL_ERROR "Controlled-air capture requires genuine unchanged energypluslib")
      endif()
      get_target_property(_controlled_air_defs energypluslib COMPILE_DEFINITIONS)
      get_directory_property(_controlled_air_dir_defs DIRECTORY "${CMAKE_SOURCE_DIR}/src/EnergyPlus" COMPILE_DEFINITIONS)
      list(APPEND _controlled_air_defs ${_controlled_air_dir_defs})
      list(FILTER _controlled_air_defs EXCLUDE REGEX "-NOTFOUND$")
      list(REMOVE_DUPLICATES _controlled_air_defs)
      add_executable(controlled_air_owner_helper
        "${CONTROLLED_AIR_SOURCE_DIR}/controlled_air_main.cpp"
        "${CONTROLLED_AIR_SOURCE_DIR}/ZoneTempPredictorCorrector.controlled_air.cc"
        "${CONTROLLED_AIR_SOURCE_DIR}/controlled_air_observer.cc"
        "${CMAKE_SOURCE_DIR}/src/EnergyPlus/api/EnergyPlusPgm.cc"
        "${CMAKE_SOURCE_DIR}/src/EnergyPlus/CommandLineInterface.cc")
      target_include_directories(controlled_air_owner_helper PRIVATE
        "$<TARGET_PROPERTY:energypluslib,INCLUDE_DIRECTORIES>" "${CONTROLLED_AIR_SOURCE_DIR}")
      target_compile_definitions(controlled_air_owner_helper PRIVATE ${_controlled_air_defs} ENERGYPLUS_STATIC_API)
      target_link_libraries(controlled_air_owner_helper PRIVATE energypluslib project_options project_fp_options project_warnings bcrypt)
      target_compile_features(controlled_air_owner_helper PRIVATE cxx_std_20)
      set_target_properties(controlled_air_owner_helper PROPERTIES
        RUNTIME_OUTPUT_DIRECTORY "${CONTROLLED_AIR_OUTPUT_DIR}")
      target_link_options(controlled_air_owner_helper PRIVATE
        "-Wl,-Map,${CONTROLLED_AIR_OUTPUT_DIR}/controlled_air_owner_helper.map")
    endfunction()
    cmake_language(DEFER CALL controlled_air_add_reference)
  endif()
endif()

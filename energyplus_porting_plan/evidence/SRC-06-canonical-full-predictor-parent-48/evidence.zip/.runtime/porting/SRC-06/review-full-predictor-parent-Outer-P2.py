"""Independent bounded Source/literal/projection review; never runs Cargo/Native."""
from pathlib import Path
import ast
import collections
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
P = D / 'source-full-predictor-parent-draft-Peer-P2-01'
O = D / 'Peer-full-predictor-parent-Source-review-Outer-P2-01'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
BASE = 'feda66208a8f3b3ae52aa38d7da56e8653c34b75'
N = R / '.reference/energyplus-src/26.1.0'
checked = {}

def need(v, label):
    if not v:
        raise AssertionError(label)

def ref(p):
    p = p.resolve()
    with p.open('rb') as f:
        h = hashlib.file_digest(f, 'sha256').hexdigest()
    return {'path': p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),
            'sha256': h, 'bytes': p.stat().st_size}

def verify(row):
    p = R / row['path']
    k = (row['path'], row['sha256'], row['bytes'])
    if k not in checked:
        need(ref(p) == row, 'Whole reference differs: ' + row['path'])
        checked[k] = True
    return p.read_bytes()

def unique(pairs):
    out = {}
    for k, v in pairs:
        need(k not in out, 'Duplicate JSON member ' + k)
        out[k] = v
    return out

def load(p):
    return json.loads(p.read_bytes(), object_pairs_hook=unique)

def scan_refs(v):
    if isinstance(v, dict):
        if set(v) == {'path', 'sha256', 'bytes'}:
            yield v
        else:
            for child in v.values():
                yield from scan_refs(child)
    elif isinstance(v, list):
        for child in v:
            yield from scan_refs(child)

def strip(v):
    if isinstance(v, dict):
        if 'value_bits' in v:
            need(set(v) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', v['value_bits']), 'Malformed raw f64')
            return v['value_bits']
        return {k: strip(x) for k, x in v.items() if k not in {'address', 'owner_address', 'state_address'}}
    if isinstance(v, list):
        return [strip(x) for x in v]
    need(not isinstance(v, float), 'Decimal float in retained projection')
    return v

def state(e):
    s = e['state']; f = s['fan']; n = s['zone_system_node']; d = s['demand']
    fan = {k: f[k]['value'] for k in ['TempTstatAir', 'LoadCorrectionFactor', 'TempControlType',
                                     'SumConvHTRadSys', 'SumConvPool', 'SumLatentHTRadSys', 'SumLatentPool']}
    fan['setpoints'] = f['zoneTstatSetpts']['value']
    demand = {k: d[k]['value'] for k in ['Setback', 'DeadBandOrSetback', 'CurDeadBandOrSetback']}
    demand['sensible'] = d['zone']['value']
    return strip(dict(air=s['air'], zone=s['zone'], clock=e['clock'], flags=s['flags'],
                      node=n['value'], node_ordinal=n['index'], node_name=n['NodeID'],
                      fan=fan, demand=demand, config=s['zone_config']['value'], actual_shapes={'aliases': s['aliases']}))

def canonical(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def count_bits(v):
    if isinstance(v, str):
        return int(re.fullmatch('[0-9a-f]{16}', v) is not None)
    if isinstance(v, dict):
        return sum(map(count_bits, v.values()))
    if isinstance(v, list):
        return sum(map(count_bits, v))
    return 0

need(not O.exists(), 'Immutable review output already exists')
manifest = load(P / 'draft.json')
need(ref(P / 'draft.json')['sha256'] == '5e8162c8cb3c3c68dd20321f5e0e7cccef3256c49169626e028e9b7602aedb72', 'Draft differs')
readset = load(R / manifest['readset']['path'])
proof = load(R / manifest['separate_unobserved_literal_proof']['path'])
allocation_path = D / 'full-predictor-parent-readset-Peer-P2-01/genuine-row-allocation-proof.json'
absence_path = D / 'full-predictor-parent-readset-Peer-P2-01/actual-IDF-zero-control-census.json'
allocation, absence = load(allocation_path), load(absence_path)
projection = load(R / manifest['projection']['path'])
for document in [manifest, readset, proof, allocation, absence, projection]:
    for row in scan_refs(document):
        # Current canonical references are bridged below; Root may independently
        # have applied End47 after this logical draft's feda parent.
        if not row['path'].startswith('crates/'):
            verify(row)

applier = ast.parse((D / 'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'))
fn = next(x for x in applier.body if isinstance(x, ast.FunctionDef) and x.name == 'apply')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal-byte-applier>', 'exec'), ns)
apply = ns['apply']
source_checks = []
for row in manifest['files']:
    before = verify(row['before']) if row['before'] else b''
    after = verify(row['proposed'])
    forward, inverse = verify(row['forward_diff']), verify(row['inverse_diff'])
    need(apply(before, forward) == after and apply(after, inverse) == before, 'Literal Source application ' + row['canonical_path'])
    if row['before']:
        git = subprocess.check_output(['git', 'show', BASE + ':' + row['canonical_path']], cwd=R)
        need(git == before, 'Selected logical parent Git differs')
        need((R / row['canonical_path']).read_bytes() == before, 'Selected current source changed; final join must wait')
    else:
        need(not (R / row['canonical_path']).exists(), 'New Source already present')
    cp = subprocess.run(['rustfmt', '--edition', '2024', '--emit', 'stdout', '--config', 'skip_children=true'],
                        input=after, capture_output=True, cwd=R)
    need(cp.returncode == 0, 'Fresh Source-only syntax parse ' + row['canonical_path'] + ': ' + cp.stderr.decode('utf-8', 'replace'))
    source_checks.append({'canonical_path': row['canonical_path'], 'before': row['before'], 'proposed': row['proposed'],
                          'literal_forward_and_inverse': True, 'fresh_syntax_only_exit_code': cp.returncode})

hub = manifest['files'][0]
old_hub, new_hub = verify(hub['before']), verify(hub['proposed'])
need(new_hub.startswith(old_hub), 'Old2336/471 helper body changed')
for row in manifest['old_whole_bodies_or_fixtures_carried']:
    verify(row)
    need(subprocess.check_output(['git', 'show', BASE + ':' + row['path']], cwd=R) == (R / row['path']).read_bytes(), 'Carried cohort differs from logical committed parent')
verify(manifest['Source_full_parent'])
need(subprocess.check_output(['git', 'show', BASE + ':' + manifest['Source_full_parent']['path']], cwd=R)
     == (R / manifest['Source_full_parent']['path']).read_bytes(), 'Production parent changed')
lib_before, lib_after = (verify(manifest['files'][3][k]) for k in ['before', 'proposed'])
need(lib_before.count(b'--sizer-only') == lib_after.count(b'--sizer-only') == 2, 'Existing59 branch plus usage string preserved')
# Existing59 source/fixture paths are collected from this concrete selector.
sizer_paths = sorted(p for p in (R / 'crates/ep_runtime/src/heat_balance/selected_sizing').rglob('*native*') if p.is_file())
sizer_refs = []
for p in sizer_paths:
    rel = p.relative_to(R).as_posix()
    need(subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=R) == p.read_bytes(), 'Existing59 scientific helper/fixture changed')
    sizer_refs.append(ref(p))

native_wholes = {}
extent_count = 0
allocation_extent_CRLF_transports = []
for doc in [proof, allocation]:
    for authority in doc['Native_authorities']:
        whole = authority['whole']
        data = verify(whole)
        rel = (R / whole['path']).relative_to(N).as_posix()
        need(subprocess.check_output(['git', 'show', PIN + ':' + rel], cwd=N) == data, 'Native Git whole ' + rel)
        native_wholes[rel] = whole
        lines = data.splitlines(keepends=True)
        for extent in authority['extents']:
            a, b = extent['first_line'], extent['last_line']
            extent_ref = extent.get('extent', extent.get('exact_UTF8_extent'))
            actual_extent = b''.join(lines[a - 1:b])
            retained_extent = verify(extent_ref)
            if 'exact_UTF8_extent' in extent:
                need(actual_extent == retained_extent, 'Native strict extent ' + rel)
            else:
                need(actual_extent.replace(b'\n', b'\r\n') == retained_extent, 'Native allocation extent exact LF-to-CRLF transport ' + rel)
                allocation_extent_CRLF_transports.append({'whole': whole, 'first_line': a, 'last_line': b,
                    'retained_extent': extent_ref, 'projection': 'Each original LF becomes CRLF; all text and line bounds exact, not claimed raw-byte identity.'})
            extent_count += 1

fixture_bytes = verify(manifest['files'][2]['proposed'])
fixture = json.loads(fixture_bytes.split(b'r###"', 1)[1].rsplit(b'"###;', 1)[0], object_pairs_hook=unique)
need(fixture['case_count'] == len(fixture['cases']) == 1168, 'All full-parent cases')
old_fixture = (R / manifest['old_whole_bodies_or_fixtures_carried'][1]['path']).read_bytes()
old_json = json.loads(old_fixture.split(b'r###"', 1)[1].rsplit(b'"###;', 1)[0], object_pairs_hook=unique)
need(all(fixture[k] == old_json[k] for k in ['definitions', 'raw', 'object_order']), 'Genuine raw/IP definition custody')
tables = fixture['state_tables']
for name, table in tables.items():
    need(len({canonical(x) for x in table}) == len(table), 'Unique intern table ' + name)
used = {name: set() for name in tables}
first_seen = {name: {} for name in tables}

def table_check(name, index, value):
    need(type(index) is int and 0 <= index < len(tables[name]), 'Intern index bounds')
    need(tables[name][index] == value, 'Full Native inverse ' + name)
    key = canonical(value)
    if key not in first_seen[name]:
        first_seen[name][key] = len(first_seen[name])
    need(index == first_seen[name][key], 'Exact first appearance order ' + name)
    used[name].add(index)

raw_path = R / readset['raw']['path']
verify(readset['raw'])
reader = verify(readset['reader'])
reader = reader.replace(b"literal('],\"summary\":')", b"literal('],\"terminal_summary\":')")
need(hashlib.sha256(reader).hexdigest() == readset['reader_single_terminal_key_adaptation_sha256'], 'One-key-only reader adaptation')
reader_ns = {}
exec(compile(reader, '<independent-bounded-stream-read>', 'exec'), reader_ns)
event_count = 0
parent_count = 0
active = None
phase_counts = collections.Counter()
captured_exit_bits = 0
shortened = 0
address_sets = collections.defaultdict(set)
actual_domains = collections.defaultdict(collections.Counter)

def visit(e):
    global event_count, parent_count, active, captured_exit_bits, shortened
    event_count += 1
    need(e['event_ordinal'] == event_count, 'All-event ordinal')
    phase_counts[e['method'] + ':' + e['phase']] += 1
    if e['method'] == 'predictSystemLoad':
        if e['phase'] == 'entry':
            need(active is None and e['invocation_ordinal'] == parent_count + 1, 'Full parent starts in actual invocation order')
            active = {'entry': state(e), 'arguments': strip(e['locals']), 'entry_event': e['event_ordinal'],
                      'invocation': e['invocation_ordinal'], 'native_Air_address': e['state']['air']['owner_address'],
                      'native_Node_address': e['state']['zone_system_node']['value']['address']}
            address_sets['Air'].add(active['native_Air_address'])
            address_sets['Node'].add(active['native_Node_address'])
            shortened += int(bool(e['locals']['shortenTimeStepSys']))
            for k, v in e['state']['flags'].items():
                actual_domains[k][canonical(v)] += 1
        elif e['phase'] == 'normal_exit':
            need(active is not None and active['invocation'] == e['invocation_ordinal'], 'Full parent exit association')
            active['exit'] = state(e); active['exit_event'] = e['event_ordinal']
            need('sums_inputs' in active, 'Actual nested Sums required')
            case = fixture['cases'][parent_count]
            for name in ['invocation', 'arguments', 'entry_event', 'exit_event', 'sums_entry_event', 'native_Air_address', 'native_Node_address']:
                need(case[name] == active[name], 'Actual parent args/address/event identity ' + name)
            for phase in ['entry', 'exit']:
                need(set(case[phase]) == set(active[phase]), 'Whole retained state field set')
                for k, v in active[phase].items():
                    table_check(k, case[phase][k], v)
            table_check('sums_inputs', case['sums_inputs'], active['sums_inputs'])
            captured_exit_bits += count_bits(active['exit'])
            parent_count += 1
            active = None
    elif e['method'] == 'calcZoneOrSpaceSums' and e['phase'] == 'entry' and e['parent_method'] == 'predictSystemLoad':
        need(active is not None and e['parent_invocation_ordinal'] == active['invocation'], 'Sums actual nesting')
        need('sums_inputs' not in active and e['locals'] == {'CorrectorFlag': 0}, 'Exactly one true predictor Sums')
        need(e['state']['air']['owner_address'] == active['native_Air_address'], 'Same nested Air')
        need(e['state']['zone_system_node']['value']['address'] == active['native_Node_address'], 'Same physical Node')
        active['sums_inputs'] = strip(e['state']['spaces'])
        active['sums_entry_event'] = e['event_ordinal']

transport = reader_ns['read'](raw_path, need, unique, visit)
need(active is None and event_count == 30445 and parent_count == 1168 and shortened == 77, 'Complete actual cohort and shortened coverage')
need(transport['summary'] == readset['terminal_summary'], 'Full terminal summary')
need(dict(phase_counts) == readset['phase_counts'], 'All observed phases retained')
need(all(len(s) == 1 for s in address_sets.values()), 'Actual Native stable owner identities')
need(all(used[k] == set(range(len(v))) for k, v in tables.items()), 'No unused or omitted intern state')
need(captured_exit_bits == projection['expected_exit_captured_f64_count'] == 169357, 'Captured raw-bit transport count; not Source execution count')
need(all(x['observed_in_capture'] is False for x in proof['proof']), 'Unobserved postconditions qualified')

O.mkdir(parents=True)
report = {
    'schema': 'src06-independent-full-predictor-parent-review.v1', 'status': 'ACCEPTED Source and projection; actual focused execution and final End47 join pending',
    'findings': [], 'reviewer_Source': ref(Path(__file__)), 'reviewed_draft': ref(P / 'draft.json'),
    'reviewer_authorship': 'Reviewer did not author P2 Rust/projection/readset. Independent full contextual Source/Native read plus independent bounded raw-to-fixture inverse. No reliance on author self-check for acceptance.',
    'four_Source_checks': source_checks, 'literal_applications': 8, 'fresh_Source_only_syntax_parses_zero': 4,
    'logical_parent': BASE, 'final_compiler_parent_join': 'WAIT actual End47/latest plan; no stale final compiler plan or application claim',
    'Native_pin': PIN, 'Native_git_wholes': list(native_wholes.values()), 'Native_strict_extent_checks': extent_count,
    'allocation_extent_CRLF_transports': allocation_extent_CRLF_transports,
    'raw': readset['raw'], 'capture': readset['capture'], 'projection': manifest['projection'],
    'independent_full_stream_inverse': {'events': event_count, 'parents': parent_count, 'entry_exit_states': 2336, 'first_consumed_Sums_inputs': 1168,
        'all_arguments_ids_event_order_addresses_exact': True, 'all_fields_nulls_shapes_integer_types_and_raw_bits_exact': True,
        'intern_table_unique_first_appearance_and_full_use': {k: len(v) for k, v in tables.items()},
        'shortened': shortened, 'stable_actual_Air_and_Node_addresses': {k: sorted(v) for k, v in address_sets.items()},
        'expected_exit_captured_f64_transport_count': captured_exit_bits, 'Source_assertion_or_execution_count_claimed': False},
    'full_parent_and_coefficient_separation': [
        'Real private SourceZoneSpaceHeatBalanceData::predict_source_system_load is called once per actual parent, including rollback/history, rho/Cp capacity, actual calculate_source_zone_sums(false), coefficient assembly, sensible demand, and normal no-humidistat moisture suffix.',
        'Three zero canaries AirPowerCap/tempDepLoad/tempIndLoad are output-only in every admitted normal ThirdOrder path. update_source_temperatures reads none; AirPowerCap is assigned before its use; sums does not read the three; tempDepLoad/tempIndLoad are assigned after real Sums/coefficient assembly before the child consumes them.',
        'Only true parent-entry Air/clock/Node/controller data and first-consumed external Surface/gain cells are inputs. No captured coefficient checkpoint or child-output restoration occurs inside the full parent.',
        'The graph uses genuine raw IP/get_zone_equipment_source Node/Config allocation, real Air/demand allocators, existing test-only Node restore, one persistent mutable physical Node/Air/controller/demand owner graph. Geometry/gain allocations are retained after first setup.',
        'Surface h/temperature and cached external gain cells are legitimate narrow full-predict-parent inputs. Full upstream surface/gain/schedule/thermostat-input producer equivalence is not claimed.'
    ],
    'unobserved_postconditions': {'literal_proof': manifest['separate_unobserved_literal_proof'], 'actual_IDF_absence': ref(absence_path), 'real_row_allocation': ref(allocation_path),
        'four_fields': 'ShortenTimeStepSysRoomAir false plus three positive-zero moisture outputs are code-derived; test-only true/17/-19/23 canaries are not Native observations or counted captured values.',
        'authority': 'Actual original IDF has no Humidistat/RoomAir object; genuine getter count0 retains Native Zone humidityControlZoneIndex ctor0; only positive writer854 is in empty getter loop. All actual parents are non-sizing/non-latent ThirdOrder and reach literal3212/3810-3812. Native moisture row allocation itself is code-derived, explicitly not captured.'},
    'unchanged_scientific_helpers': {'old_hub_prefix_whole': hub['before'], 'old_fixtures_and_report_helper': manifest['old_whole_bodies_or_fixtures_carried'][1:], 'existing59_paths': sizer_refs,
        'production_parent_whole': manifest['Source_full_parent'], 'existing_selectors': 'Old Air2336/report471/sizer59 branches unchanged after literal inverse of the added branch; no new feature/target/test body/dependency.'},
    'qualifications': ['1168 independent captured method calls, not uninterrupted full-engine recurrence; external entries are restored between calls only.',
        'Private Cp/psychrometric cache prestate, hit/miss and recurrence are unobserved. No state reset is added between calls; normal numeric results only are the future test scope.',
        'Four syntax-only parses do not typecheck contextual Rust. Root owns one actual focused existing harness-main invocation after final compiler join.',
        'No new Native or Source run, no production math/visibility/owner change, no tolerance change, no canonical edit, no whole-production gate promotion.'],
    'reviewer_preparation_history': 'Three reviewer preparations stopped before output: one-occurrence selector assumption (actual branch plus usage string), two distinct extent schema keys, and allocation proof CRLF transport instead of exact LF whole slice. Three scripts preserved; corrected reviewer proofs only, no P2 Source change. Seven allocation extents now explicitly qualified as LF-to-CRLF projections.',
    'authenticated_reference_count': len(checked), 'Cargo_or_Native_execution': False
}
(O / 'review.json').write_bytes((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(ref(O / 'review.json')))

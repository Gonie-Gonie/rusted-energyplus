"""Read-only bounded Native21 predictor-parent admission; no fixture or solver."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import re
import struct

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
OUT = D / 'full-predictor-parent-readset-Peer-P2-01'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    path = path.resolve()
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(R).as_posix() if path.is_relative_to(R) else path.as_posix(),
            'sha256': sha, 'bytes': path.stat().st_size}


def checked(row):
    path = R / row['path']
    actual = ref(path)
    need(actual['sha256'] == row['sha256'] and actual['bytes'] == row['bytes'], 'Changed input ' + str(path))
    return path


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'Duplicate JSON key ' + key)
        result[key] = value
    return result


def clean(value):
    if isinstance(value, dict):
        if 'value_bits' in value:
            need(set(value) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', value['value_bits']), 'Bad binary64')
            return value['value_bits']
        return {key: clean(child) for key, child in value.items()
                if key not in ('address', 'owner_address', 'state_address')}
    if isinstance(value, list):
        return [clean(child) for child in value]
    need(not isinstance(value, float), 'Unexpected decimal floating point transport')
    return value


capture_path = D / 'controlled-air-native-capture-Root-21/capture.json'
need(ref(capture_path)['sha256'] == '6845958c28d6eef55ce89100a13f2001d43ae7ca2fb3e86b2c189d2820b4c47f', 'Capture receipt differs')
capture = json.loads(capture_path.read_bytes(), object_pairs_hook=unique)
need(capture['accepted'] and not capture['findings'], 'Capture not accepted')
raw = checked(capture['full_retained_observation'])
reader = R / '.runtime/porting/CTF-10/surface-consumer05-original-data-review-prep-01/stream_events.py'
need(ref(reader)['sha256'] == '8e7f05196fe567c052352d4d0fe501eb02a0f8e5a623c20f7dcd3db669f6bab8', 'Reader differs')
reader_bytes = reader.read_bytes()
old = b"literal('],\"summary\":')"
new = b"literal('],\"terminal_summary\":')"
need(reader_bytes.count(old) == 1, 'Reader delimiter differs')
adapted = reader_bytes.replace(old, new)
namespace = {}
exec(compile(adapted, '<fixed-reader-terminal-key-only>', 'exec'), namespace)

events = 0
active = None
parents = []
phases = Counter()
groups = Counter()
shapes = defaultdict(Counter)
domains = defaultdict(Counter)
addresses = defaultdict(set)
float_counts = Counter()
sample = None
max_event_bytes = 0
sum_static = None


def check_shape(row, at, label):
    need(isinstance(row, dict) and isinstance(row['allocated'], bool), label + ': shape missing')
    need(row['allocated'] and row['size'] > 0, label + ': actual allocated row missing')
    if 'lower' in row:
        need(row['lower'] <= at <= row['upper'] and row['upper'] - row['lower'] + 1 == row['size'], label + ': bounds')
    else:
        need(row['index_domain'] == 'EPVector one-based operator()' and 1 <= at <= row['size'], label + ': EPVector domain')
    shapes[label][json.dumps(clean({k: v for k, v in row.items() if k not in ('value', 'values', 'index', 'NodeID')}), sort_keys=True)] += 1


def audit(value, path=''):
    if isinstance(value, dict):
        if 'value_bits' in value:
            bits = value['value_bits']
            need(set(value) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', bits), 'Bad binary64: ' + path)
            need((int(bits, 16) >> 52) & 0x7ff != 0x7ff, 'Nonfinite binary64: ' + path)
            float_counts[path] += 1
        else:
            for key, child in value.items():
                audit(child, path + '.' + key)
    elif isinstance(value, list):
        for child in value:
            audit(child, path + '[]')
    else:
        need(not isinstance(value, float), 'Decimal float at ' + path)


def check_state(event):
    s = event['state']
    a = s['aliases']
    check_shape(a['zoneHeatBalance'], 1, 'aliases.zoneHeatBalance')
    need(a['is_zone_row'] is True and a['is_space_row'] is None, 'Actual parent must alias genuine zoneHeatBalance(1) only')
    addresses['EnergyPlusData'].add(event['clock']['state_address'])
    addresses['air'].add(s['air']['owner_address'])
    addresses['Zone'].add(s['zone']['address'])
    n = s['zone_system_node']
    check_shape(n, n['index'], 'Node')
    need(n['index'] == s['zone']['SystemZoneNodeNumber'] and n['value'] is not None, 'Actual same ZoneNode')
    addresses['ZoneNode'].add(n['value']['address'])
    addresses['sensibleDemand'].add(s['demand']['zone']['value']['address'])
    for key in ('Setback', 'DeadBandOrSetback', 'CurDeadBandOrSetback', 'zone'):
        check_shape(s['demand'][key], 1, 'demand.' + key)
        need(s['demand'][key]['value'] is not None, 'Demand row not observed')
    for key in s['fan']:
        check_shape(s['fan'][key], 1, 'fan.' + key)
        need(s['fan'][key]['value'] is not None, 'Fan row not observed')
    cfg = s['zone_config']
    check_shape(cfg, 1, 'ZoneEquipConfig')
    need(cfg['value'] is not None and cfg['value']['ZoneName'] == s['zone']['Name'], 'Actual Config/Zone name identity')
    need(cfg['value']['ZoneNode'] == n['index'], 'Actual Config/Zone node identity')
    addresses['Config'].add(cfg['value']['address'])
    inlets = cfg['value']['InletNode']
    check_shape(inlets, 1, 'InletNode')
    need(len(inlets['values']) == cfg['value']['NumInletNodes'] == inlets['size'], 'Actual Inlet count')
    for row in inlets['values']:
        need(row['NodeNum'] == row['physical']['index'], 'Actual inlet physical ordinal')
        check_shape(row['physical'], row['NodeNum'], 'InletPhysical')
        addresses['inlet'].add(row['physical']['value']['address'])
        need(row['physical']['value']['address'] != n['value']['address'], 'Distinct actual inlet and ZoneNode')
    for key in ('XMAT', 'DSXMAT', 'WPrevZoneTS', 'DSWPrevZoneTS', 'ZTM', 'WPrevZoneTSTemp'):
        need(len(s['air'][key]) == 4, 'Actual four history entries ' + key)
    for key in ('ZoneAirSolutionAlgo', 'doSpaceHeatBalance', 'DoLatentSizing', 'NumStageCtrZone',
                'anyNonMixingRoomAirModel', 'FlagHybridModel_PC', 'multizone_always_simulated',
                'distribution_simulated', 'AFN_control_type', 'AirflowNetworkFanActivated'):
        domains['flags.' + key][json.dumps(s['flags'][key], sort_keys=True)] += 1
    for key in ('DoingSizing', 'WarmupFlag', 'KickOffSimulation', 'ShortenTimeStepSys', 'UseZoneTimeStepHistory'):
        domains['clock.' + key][json.dumps(event['clock'][key])] += 1
    domains['TempControlType'][str(s['fan']['TempControlType']['value'])] += 1
    audit({'state': s, 'clock': event['clock'], 'locals': event['locals']})


def check_sums(event):
    global sum_static
    s = event['state']
    rows = s['spaces']
    need([r['index'] for r in rows] == s['zone']['spaceIndexes'], 'Actual Zone->Space order')
    static = []
    for row in rows:
        check_shape(row['space_owner'], row['index'], 'space')
        v = row['value']
        need(v is not None, 'Actual space missing')
        addresses['Space'].add(v['address'])
        surfaces = v['surfaces']
        need([r['index'] for r in surfaces] == list(range(v['HTSurfaceFirst'], v['HTSurfaceLast'] + 1)), 'Actual HT surface order')
        surface_static = []
        for surf in surfaces:
            check_shape(surf['surface_owner'], surf['index'], 'Surface')
            z = surf['value']
            need(z is not None and z['Class'] != 11, 'Actual opaque surface required')
            addresses['Surface.' + str(surf['index'])].add(z['address'])
            check_shape(z['SurfTAirRef'], surf['index'], 'SurfTAirRef')
            for key in ('SurfHConvInt', 'SurfTempInTmp', 'SurfTempEffBulkAir'):
                check_shape(z[key], surf['index'], key)
                need(z[key]['value'] is not None, 'Actual surface parallel row')
            domains['SurfTAirRef'][str(z['SurfTAirRef']['value'])] += 1
            surface_static.append([surf['index'], z['address'], clean(z['Area']), z['Class']])
        gain = v['gains']
        check_shape(gain, row['index'], 'spaceIntGainDevices')
        g = gain['value']
        need(g is not None, 'Actual saved gain owner missing')
        devices = g['device']
        need(devices['allocated'] and devices['size'] >= g['numberOfDevices'], 'Actual active gain storage')
        need(len(devices['values']) == g['numberOfDevices'], 'Actual active gain count')
        need([d['index'] for d in devices['values']] == list(range(1, g['numberOfDevices'] + 1)), 'Actual saved gain order')
        domains['gain.count'][str(g['numberOfDevices'])] += 1
        static.append([row['index'], v['address'], v['HTSurfaceFirst'], v['HTSurfaceLast'], surface_static,
                       g['numberOfDevices'], g['maxNumberOfDevices'], devices['size'],
                       [[d['index'], d['address'], d['CompObjectName'], d['CompType'], d['ReturnAirNodeNum']] for d in devices['values']]])
    if sum_static is None:
        sum_static = static
    need(sum_static == static, 'Finite captured geometry/gain object identity changed')


def visit(event):
    global events, active, sample, max_event_bytes
    events += 1
    need(event['event_ordinal'] == events, 'Event order gap')
    method, phase = event['method'], event['phase']
    phases[method + ':' + phase] += 1
    if method == 'predictSystemLoad':
        if phase == 'entry':
            need(active is None and event['zoneNum'] == 1 and event['spaceNum'] == 0, 'Finite parent association')
            need(event['invocation_ordinal'] == len(parents) + 1, 'Parent order')
            active = {'id': event['invocation_ordinal'], 'entry': event, 'children': {}}
            check_state(event)
        elif phase == 'normal_exit':
            need(active is not None and event['invocation_ordinal'] == active['id'], 'Parent close association')
            check_state(event)
            need(set(active['children']) == {'updateTemperatures:entry', 'updateTemperatures:normal_exit',
                 'calcZoneOrSpaceSums:entry', 'calcZoneOrSpaceSums:normal_exit',
                 'calcPredictedSystemLoad:entry', 'calcPredictedSystemLoad:normal_exit'}, 'Full genuine nested method phases')
            start = active['entry']
            need(event['clock'] == start['clock'], 'Clock readonly throughout genuine parent')
            for name in ('zone', 'flags', 'aliases', 'zone_config'):
                need(start['state'][name] == event['state'][name], 'Parent readonly object changed: ' + name)
            s = active['children']['calcZoneOrSpaceSums:entry']
            t = active['children']['calcZoneOrSpaceSums:normal_exit']
            need(s['state']['spaces'] == t['state']['spaces'], 'Sums geometry/gains inputs readonly')
            for key in ('SumConvHTRadSys', 'SumConvPool', 'SumLatentHTRadSys', 'SumLatentPool'):
                need(start['state']['fan'][key] == s['state']['fan'][key] == event['state']['fan'][key], 'Parent external saved fan input changed')
            need(clean(start['state']['zone']) == clean(s['state']['zone']), 'Zone external first-consumed values changed')
            groups[tuple(start['clock'][k] for k in ('WarmupFlag', 'KickOffSimulation', 'ShortenTimeStepSys', 'UseZoneTimeStepHistory'))] += 1
            parents.append({'invocation': active['id'], 'entry_event': start['event_ordinal'], 'exit_event': event['event_ordinal'],
                            'sums_entry_event': s['event_ordinal'], 'sums_exit_event': t['event_ordinal']})
            if sample is None:
                sample = {'entry': start, 'sums_entry': s, 'exit': event}
            active = None
        else:
            need(active is not None and phase == 'predict_coefficients_before_child', 'Unexpected parent phase')
        return
    if active is None:
        return
    if event['parent_method'] != 'predictSystemLoad':
        return
    need(event['parent_invocation_ordinal'] == active['id'], 'Wrong actual parent ordinal')
    need(event['state']['air']['owner_address'] == active['entry']['state']['air']['owner_address'], 'Nested same Air owner')
    need(event['state']['zone_system_node']['value']['address'] == active['entry']['state']['zone_system_node']['value']['address'], 'Nested same physical ZoneNode')
    if phase in ('entry', 'normal_exit'):
        key = method + ':' + phase
        need(key not in active['children'], 'Duplicate nested phase')
        active['children'][key] = event
        check_state(event)
        if method == 'calcZoneOrSpaceSums':
            if phase == 'entry':
                need(event['locals']['CorrectorFlag'] == 0, 'Predictor genuine Sums false')
            check_sums(event)


transport = namespace['read'](raw, need, unique, visit)
need(active is None and events == 30445 and len(parents) == 1168, 'Incomplete capture')
need(transport['summary'] == capture['observation_checks']['terminal_summary'], 'Footer differs')
need(all(len(v) == 1 for v in addresses.values()), 'Same Native lifetime identities not stable')
raw_note_path = D / 'ordinary-source-B-raw-ingress-held-Audit-01/actual-B-input-preservation.json'
raw_note = json.loads(raw_note_path.read_bytes(), object_pairs_hook=unique)
converted = checked(raw_note['actual_failed_input'])
original = json.loads(converted.read_bytes(), object_pairs_hook=unique)
need('ZoneControl:Humidistat' not in original and 'RoomAirModelType' not in original, 'Actual no-humidistat/mixing input premise false')
need(all(json.loads(k) is False for k in domains['flags.DoLatentSizing']), 'Latent sizing branch can become active')
need(all(json.loads(k) == 0 for k in domains['flags.ZoneAirSolutionAlgo']), 'ThirdOrder-only admission false')
need(all(json.loads(k) is False for k in domains['flags.anyNonMixingRoomAirModel']), 'Nonmixing branch active')
need(all(json.loads(k) is False for k in domains['flags.FlagHybridModel_PC']), 'Hybrid people branch active')
OUT.mkdir(exist_ok=False)
(OUT / 'representative-captured-parent.json').write_text(json.dumps(sample, indent=2) + '\n', encoding='utf-8')
result = {'schema': 'src06-full-predictor-parent-consumed-readset-admission.v1', 'accepted': True, 'findings': [],
    'author': ref(Path(__file__)), 'capture': ref(capture_path), 'raw': ref(raw), 'reader': ref(reader),
    'reader_single_terminal_key_adaptation_sha256': hashlib.sha256(adapted).hexdigest(),
    'all_events_visited': events, 'actual_full_predictor_invocations': len(parents), 'actual_parent_event_joins': parents,
    'phase_counts': dict(sorted(phases.items())), 'terminal_summary': transport['summary'],
    'cohort_groups': [{'warmup': k[0], 'kickoff': k[1], 'shorten': k[2], 'zone_history': k[3], 'count': v} for k,v in sorted(groups.items())],
    'domains': {k: dict(v) for k,v in sorted(domains.items())},
    'actual_shape_counts': {k: [{'shape':json.loads(s),'count':n} for s,n in v.items()] for k,v in sorted(shapes.items())},
    'stable_actual_Native_addresses': {k: list(v) for k,v in sorted(addresses.items())},
    'selected_phase_finite_f64_observation_counts_by_path': dict(sorted(float_counts.items())),
    'fixed_external_object_graph': sum_static,
    'actual_raw_input_authority': ref(raw_note_path), 'actual_converted_input': ref(converted),
    'actual_absent_families': ['ZoneControl:Humidistat', 'RoomAirModelType'],
    'unobserved_code_derived_postconditions_NOT_captured_values': {
        'ShortenTimeStepSysRoomAir': {'value':False,'writer':'ZoneTempPredictorCorrector.cc:3212', 'qualification':'ThirdOrder normal-exit domain; no field is present in capture'},
        'moisture_outputs': {'value':'Native literal 0.0, three fields', 'writers':'ZoneTempPredictorCorrector.cc:3810-3812', 'qualification':'Actual input absent + ctor/getter writer census proof must accompany Source assertions; not captured f64 equality'}},
    'private_Cp_cache_observed': False,
    'large_fixture_created': False, 'Source_or_Native_execution': False,
    'qualification': '1168 independent captured full-parent calls. Intervening external engine updates prevent claiming one uninterrupted recurrence sequence. No computed coefficient answers will be injected into future Source parent inputs.',
    'representative_capture': ref(OUT / 'representative-captured-parent.json')}
(OUT / 'readset.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(ref(OUT / 'readset.json')))

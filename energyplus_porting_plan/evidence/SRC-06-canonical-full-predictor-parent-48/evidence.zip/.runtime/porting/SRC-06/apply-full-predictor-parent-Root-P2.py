"""Root-only four cfg-test Source application, explicitly waits committed End47."""
from pathlib import Path
import argparse, ast, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
PREP=D/'full-predictor-parent-prepared-WAIT-Peer-P2/prepared.json'
OUT=D/'Root-full-predictor-parent-cohort-application-P2'

def need(ok,message):
    if not ok: raise ValueError(message)

def ref(p):
    p=p.resolve()
    with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)

def checked(row):
    p=(R/row['path']).resolve();need(p.is_relative_to(R),'Reference outside workspace')
    need(ref(p)==row,'Changed reference '+row['path']);return p

def argument(value):
    name,sha=value.rsplit('#',1);p=(R/name).resolve();need(p.is_relative_to(R),'Reference outside workspace')
    actual=ref(p);need(actual['sha256']==sha,'Changed argument');return actual

def read(p):return json.loads(p.read_bytes())

def contains_ref(value,wanted):
    if isinstance(value,dict):
        if all(value.get(k)==v for k,v in wanted.items()):return True
        return any(contains_ref(v,wanted) for v in value.values())
    if isinstance(value,list):return any(contains_ref(v,wanted) for v in value)
    return False

def inventory():
    return {p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}

def exact(rows):
    need(inventory()==set(rows),'Compiler input inventory differs')
    for name,row in rows.items():
        actual=ref(R/name);need((actual['sha256'],actual['bytes'])==(row['final_sha256'],row['final_bytes']),name)

def literal():
    p=D/'seal-compact-annual-daygroup-helper-Peer-01.py';tree=ast.parse(p.read_text(encoding='utf-8-sig'))
    fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
    ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<accepted-literal-only>','exec'),ns)
    return ns['apply_literal']

def main(a):
    pr=argument(a.prepared);need(checked(pr)==PREP.resolve(),'Unexpected prepared path')
    p=read(PREP);need(p['status']=='WAIT_COMMITTED_END47_ACTUAL_PARENT','Unexpected preparation status')
    checked(p['application_Source']);need(ref(Path(__file__))==p['application_Source'],'Application changed')
    parent_actual_ref=argument(a.parent_actual);parent_actual=read(checked(parent_actual_ref))
    need(parent_actual.get('accepted') and not parent_actual.get('findings'),'End47 actual aggregate is not accepted')
    need(contains_ref(parent_actual,p['End47_producer']) and contains_ref(parent_actual,p['prior_complete_compiler_Source_plan']),
         'Actual End47 aggregate must bind this exact producer and full compiler plan')
    need(re.fullmatch('[0-9a-f]{40}',a.base_head) is not None,'Exact committed base HEAD required')
    need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a.base_head,'Actual HEAD differs')
    need(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'Committed clean End47 parent required')
    # Every End47 selected Source must be genuinely committed at this HEAD.
    end=read(checked(p['End47_producer']))
    for row in end['files']:
        rel=row['canonical_path'];blob=subprocess.check_output(['git','show',a.base_head+':'+rel],cwd=R)
        live=(R/rel).read_bytes();need(blob==live,'End47 selected Source not committed exact '+rel)
    original=read(checked(p['original_draft']));peer=read(checked(p['independent_full_semantic_peer']))
    need(peer['status']=='ACCEPTED Source and projection; actual focused execution and final End47 join pending'
         and not peer['findings'] and peer['reviewed_draft']==p['original_draft'],'Independent draft peer mismatch')
    parent=read(checked(p['prior_complete_compiler_Source_plan']))
    before_rows={row['path']:row for row in parent['entries']}
    need((parent['inputs'],parent['Rust_sources'],len(before_rows))==(4523,4510,4523),'Parent counts')
    exact(before_rows)
    plan=read(checked(p['complete_proposed_compiler_Source_plan']));rows={row['path']:row for row in plan['entries']}
    need((plan['inputs'],plan['Rust_sources'],len(rows))==(4525,4512,4525),'Final counts')
    apply=literal();materials=[]
    for row in original['files']:
        rel=row['canonical_path'];target=R/rel;old=checked(row['before']).read_bytes() if row['before'] else b''
        need(target.exists()==(row['before'] is not None),'Existence changed '+rel)
        if target.exists():need(target.read_bytes()==old,'Selected before differs '+rel)
        proposed=checked(row['proposed']).read_bytes()
        need(apply(old,checked(row['forward_diff']).read_bytes())==proposed,'Literal forward')
        need(apply(proposed,checked(row['inverse_diff']).read_bytes())==old,'Literal inverse')
        materials.append((rel,old,proposed,row['before'] is not None))
    need(not OUT.exists(),'Application output exists')
    OUT.mkdir()
    for rel,old,_,exists in materials:
        if exists:
            backup=OUT/'before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(old)
    try:
        for rel,_,proposed,_ in materials:
            target=R/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(proposed)
        exact(rows)
    except BaseException:
        for rel,old,_,exists in materials:
            if exists:(R/rel).write_bytes(old)
            elif (R/rel).exists():(R/rel).unlink()
        raise
    receipt=dict(schema='src06-full-predictor-parent-application.v1',accepted=True,findings=[],base_HEAD=a.base_head,
        prepared=pr,parent_End47_actual=parent_actual_ref,End47_producer=p['End47_producer'],
        original_draft=p['original_draft'],independent_full_semantic_peer=p['independent_full_semantic_peer'],
        complete_compiler_plan=p['complete_proposed_compiler_Source_plan'],application_Source=ref(Path(__file__)),
        selected_Source_files=4,existing=2,new=2,all4525_final_plan_inputs_exact=True,actual_test_or_CLI_invocations=0,
        qualification='Only cfg(test) Source/helper/fixture and existing process-main selection; no production numerical behavior or new test target/feature.')
    out=OUT/'receipt.json';out.write_bytes((json.dumps(receipt,indent=2)+'\n').encode('utf-8'));print(json.dumps(ref(out)))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepared',required=True);parser.add_argument('--base-head',required=True);parser.add_argument('--parent-actual',required=True)
    main(parser.parse_args())

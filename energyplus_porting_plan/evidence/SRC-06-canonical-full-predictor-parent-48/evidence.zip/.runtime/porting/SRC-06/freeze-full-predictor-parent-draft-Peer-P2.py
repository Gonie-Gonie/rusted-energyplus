"""Private test-only four-source preparation, no compiler/test or canonical edit."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
P = D / 'source-full-predictor-parent-draft-Peer-P2-01'
LEAF = 'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction'
HUB = LEAF + '/native_cohort.rs'
BODY = LEAF + '/native_cohort/full_predictor.rs'
FIX = LEAF + '/fixtures/native_full_predictor_b.rs'
LIB = 'crates/ep_runtime/src/lib.rs'


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


need(not (P / 'draft.json').exists(), 'Immutable draft already exists')
body_input = D / 'full-predictor-parent-body-Peer-P2.rs'
formatted = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'],
                           input=body_input.read_bytes(), capture_output=True)
need(formatted.returncode == 0, 'New helper syntax failed: ' + formatted.stderr.decode(errors='replace'))
body = formatted.stdout.replace(b'\r\n', b'\n')
hub = (R / HUB).read_bytes()
hub_append = b'''
// Test-only full predictSystemLoad parent. Existing 2336-body cohort is unchanged.
mod full_predictor;
impl SourceZoneAirPredictorCorrector {
    pub(crate) fn run_native_full_predictor_parent_cohort() -> Result<usize> {
        full_predictor::run()
    }
}
'''
lib = (R / LIB).read_bytes()
anchor = b'    if selection.len()==1 && selection[0]=="--sizer-only" {'
need(lib.count(anchor) == 1, 'Existing main selector changed')
branch = b'''    if selection.len()==1 && selection[0]=="--predictor-parent-only" {
        println!("running 1 full native predictor-parent cohort on process main");
        let cases=crate::heat_balance::ordinary_air_heat_balance::predictor_corrector::SourceZoneAirPredictorCorrector::run_native_full_predictor_parent_cohort()?;
        println!("cohort native_controlled_air_cohort ... ok");
        println!("cohort result: ok. 1 passed; 0 failed; genuine full predictor parents={cases}; code-derived literal postconditions=4 per call; private cache trace unobserved");
        return Ok(());
    }
'''
lib_proposed = lib.replace(anchor, branch + anchor)
need(lib_proposed.replace(branch, b'', 1) == lib, 'Main inverse not exact')
contents = {HUB: hub + hub_append, BODY: body, FIX: (P / 'proposed' / FIX).read_bytes(), LIB: lib_proposed}
files = []
for rel, proposed in contents.items():
    actual = R / rel
    before = actual.read_bytes() if actual.exists() else b''
    if actual.exists():
        target = P / 'before' / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(before)
        before_ref = ref(target)
    else:
        before_ref = None
    target = P / 'proposed' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(proposed)
    need(b'\r' not in proposed, 'New proposals must be LF')
    stem = rel.replace('/', '__')
    forward = ''.join(difflib.unified_diff(before.decode('utf-8-sig').splitlines(keepends=True),
                                         proposed.decode('utf-8-sig').splitlines(keepends=True),
                                         fromfile='a/' + rel, tofile='b/' + rel)).encode('utf-8')
    inverse = ''.join(difflib.unified_diff(proposed.decode('utf-8-sig').splitlines(keepends=True),
                                         before.decode('utf-8-sig').splitlines(keepends=True),
                                         fromfile='a/' + rel, tofile='b/' + rel)).encode('utf-8')
    diff_dir = P / 'diffs'
    diff_dir.mkdir(exist_ok=True)
    fp, ip = diff_dir / (stem + '.forward.diff'), diff_dir / (stem + '.inverse.diff')
    fp.write_bytes(forward)
    ip.write_bytes(inverse)
    parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'],
                           input=proposed, capture_output=True)
    need(parse.returncode == 0, 'Syntax failed: ' + rel + ': ' + parse.stderr.decode(errors='replace'))
    parse_path = P / (stem + '.syntax.stderr.txt')
    parse_path.write_bytes(parse.stderr)
    files.append({'canonical_path': rel, 'before': before_ref, 'before_absent': before_ref is None,
                  'proposed': ref(target), 'forward_diff': ref(fp), 'inverse_diff': ref(ip),
                  'fresh_syntax_only_exit_code': parse.returncode, 'syntax_stderr': ref(parse_path)})
preserve = [HUB, LEAF + '/fixtures/native_prediction_b.rs', LEAF + '/native_cohort/report_cohort.rs',
            LEAF + '/fixtures/native_system_report_b.rs']
# Preserve actual paths only; one report fixture uses a separately named leaf.
preserve = [path for path in preserve if (R / path).exists()]
result = {'schema': 'src06-full-predictor-parent-test-draft.v1', 'status': 'HELD semantic draft; no canonical writes or tests',
    'author': ref(Path(__file__)), 'projector': ref(D / 'project-full-predictor-parent-Peer-P2.py'),
    'projection': ref(P / 'projection.json'),
    'readset': ref(D / 'full-predictor-parent-readset-Peer-P2-01/readset.json'),
    'separate_unobserved_literal_proof': ref(D / 'full-predictor-parent-readset-Peer-P2-01/unobserved-literal-proof.json'),
    'observed_HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip(),
    'files': files, 'old_whole_bodies_or_fixtures_carried': [ref(R / path) for path in preserve],
    'Source_full_parent': ref(R / (LEAF + '.rs')),
    'input_answer_separation': 'Only actual parent-entry values and first-consumed external Sums geometry/gain inputs are supplied. Three current-operation outputs AirPowerCap/tempDepLoad/tempIndLoad are overwritten with explicit zero canaries before real full parent. No captured child-entry or output coefficient answers are supplied.',
    'actual_owner_graph': 'Existing IP/raw getter constructs Config and physical Nodes; real SourceAirHeatBalance.allocate_source_arrays owns actual zone row; same allocated Air/ZoneNode/sensible/moisture rows persist across cases. Geometry/gain rows allocated once then external scalar inputs updated in place.',
    'test_input_canaries_not_Native_observations': ['AirPowerCap/tempDepLoad/tempIndLoad=0.0 output-only',
        'ShortenTimeStepSysRoomAir=true', 'three moisture output fields=17,-19,23'],
    'expected_checks': 'Full 67 initialized Air scalar members+6 four-entry histories, sensible demand/sequence arrays, physical Node writes, thermostat/deadband writes; readonly actual inlets, external geometry/gain inputs and consumed Zone scalars. Four code-derived literal postconditions asserted separately.',
    'repeat_qualification': '1168 independent captured method calls; no continuous outside-engine recurrence claimed. Missing history/multiplier sequences belong to future genuine Native original-core batch and must not reset between their declared steps.',
    'existing_selector_only': '--predictor-parent-only before old Air/report/sizer paths on same harness=false process main; no new test function/feature/target/dependency',
    'private_cache_qualification': 'No Native cache observations or hit/miss/recurrence claim; no property-state resets between full-parent calls.',
    'final_compiler_parent_join': 'WAIT Root End47/latest compiler plan; this draft binds current whole sources only, not a final application',
    'scientific_pass_claimed': False, 'new_test_functions': 0, 'Cargo_Native_execution': False,
    'source_files': 4, 'existing': 2, 'new': 2, 'fresh_syntax_parses_zero': 4}
(P / 'draft.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(ref(P / 'draft.json')))

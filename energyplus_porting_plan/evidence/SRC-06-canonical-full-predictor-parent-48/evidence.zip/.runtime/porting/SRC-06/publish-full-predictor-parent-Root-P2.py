"""Finite P2 evidence and concise docs, after one genuine focused pass."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
PUBLIC = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-full-predictor-parent-48'
BACK = D / 'Root-full-predictor-parent-publication-48'

def ref(p):
    p = p.resolve()
    with p.open('rb') as f:
        h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(), sha256=h, bytes=p.stat().st_size)

def checked(x):
    p = (R / x['path']).resolve()
    assert p.is_relative_to(R)
    v = ref(p)
    assert v['sha256'] == x['sha256'] and v['bytes'] == x.get('bytes', x.get('size_bytes', v['bytes'])), x['path']
    return p

def read(p):
    return json.loads(p.read_bytes())

def write(p, v):
    p.write_bytes((json.dumps(v, ensure_ascii=False, indent=2) + '\n').encode('utf8'))

def no_raw_environment(v):
    if isinstance(v, dict):
        assert 'full_explicit_environment' not in v
        for x in v.values():
            no_raw_environment(x)
    elif isinstance(v, list):
        for x in v:
            no_raw_environment(x)

def main():
    assert not PUBLIC.exists() and not BACK.exists()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
    assert head == '58b9d6adc2f24241f2d4cedd97de65e3a0703d41'
    actual_path = D / 'Root-full-predictor-parent-actual-review-P2/review.json'
    assert ref(actual_path)['sha256'] == '3a023b7649744a15a0340053e4c08d3aaacb9a650ce8a1e2f9b632115246fde9'
    actual = read(actual_path)
    assert actual['accepted'] and not actual['findings'] and actual['actual_full_parent_cases'] == 1168
    assert actual['actual_focused_invocations'] == 1 and actual['actual_existing2336_471_59_bodies_reexecuted'] == 0
    assert actual['all4525_live_and_archived_inputs_exact'] and actual['compiler_artifact_capture_requested'] is False
    prepared = read(checked(actual['prepared']))
    draft = read(checked(actual['original_draft']))
    proof = read(checked(actual['separate_literal_proof']))
    peer = read(checked(actual['independent_semantic_peer']))
    readset = read(checked(actual['retained_Native_readset']))
    raw = Path(readset['raw']['path'])
    assert raw.stat().st_size == readset['raw']['bytes']
    with raw.open('rb') as f:
        assert hashlib.file_digest(f, 'sha256').hexdigest() == readset['raw']['sha256']
    plan = read(checked(actual['complete_compiler_plan']))
    for x in plan['entries']:
        v = ref(R / x['path'])
        assert (v['sha256'], v['bytes']) == (x['final_sha256'], x['final_bytes'])
    for x in draft['files']:
        assert (R / x['canonical_path']).read_bytes() == checked(x['proposed']).read_bytes()
    rows = {}
    def add(x):
        p = checked(x)
        assert p.suffix.lower() not in ('.zip', '.exe', '.dll', '.a', '.obj', '.map')
        if p.suffix == '.json':
            no_raw_environment(read(p))
        v = ref(p)
        assert p.as_posix() not in rows or rows[p.as_posix()] == v
        rows[p.as_posix()] = v
    for x in [ref(actual_path), actual['prepared'], actual['application'], actual['actual_receipt'], actual['actual_source_snapshot'], actual['complete_compiler_plan'], actual['original_draft'], actual['independent_semantic_peer'], actual['retained_Native_readset'], actual['separate_literal_proof'], actual['retained_Native_projection'], actual['raw_IDF_absent_family_proof'], actual['row_allocation_proof'], actual['stdout'], actual['stderr'], actual['author_Source'], prepared['application_Source'], prepared['launch_Source'], prepared['inherited_environment_guard'], prepared['record_command_Source'], draft['author'], draft['projector'], draft['Source_full_parent'], readset['author'], readset['reader'], readset['actual_raw_input_authority'], readset['actual_converted_input'], readset['representative_capture'], proof['author'], peer['reviewer_Source'], ref(Path(__file__))]:
        add(x)
    for x in draft['files']:
        for k in ['before', 'proposed', 'forward_diff', 'inverse_diff', 'syntax_stderr']:
            if x.get(k):
                add(x[k])
    # Only explicitly scoped Native authority trees. Do not recursively follow
    # prior checkpoints, old fixtures or the retained390MB observation stream.
    def native_refs(v):
        if isinstance(v, dict):
            if 'path' in v and 'sha256' in v:
                add(v)
            else:
                for x in v.values():
                    native_refs(x)
        elif isinstance(v, list):
            for x in v:
                native_refs(x)
    native_refs(proof['Native_authorities'])
    native_refs(peer['Native_git_wholes'])
    native_refs(peer['Native_strict_extent_checks'])
    native_refs(peer['allocation_extent_CRLF_transports'])
    assert sum(x['bytes'] for x in rows.values()) < 64 * 1024 * 1024
    doc_appends = {
        'CHECKLIST.md': '\uc2e4\uc81c Native \uc608\uce21\uae30 \uc0c1\uc704 \ud638\ucd9c 1,168\uac74\uc744 \uae30\uc874 \ub2e8\uc77c \uac80\uc99d \ub300\uc0c1\uc5d0 \ucd94\uac00\ud588\ub2e4. \uae30\uc874 2,336/471/59\uac74\uc740 \uc7ac\uc2e4\ud589\ud558\uc9c0 \uc54a\uc558\uc73c\uba70 \uac8c\uc774\ud2b8\ub294 \uc720\uc9c0\ud55c\ub2e4.',
        'STATE_CONTRACTS.md': '\uc0c1\uc704 \uc608\uce21\uae30\uac00 \uc138 \uacc4\uc218\ub97c \uc9c1\uc811 \uc0dd\uc131\ud558\uace0 \uc2e4\uc81c \ud560\ub2f9\ub41c Air/Node/\uc218\uc694 \uc18c\uc720\uc790\ub97c \uc720\uc9c0\ud558\ub294\uc9c0 \ud655\uc778\ud588\ub2e4. \ubbf8\uad00\uce21 \uc0c1\uc218 \ud6c4\uc870\uac74 4\uac1c\ub294 Native \uad00\uce21 \ube44\ud2b8\uc218\uc640 \ubd84\ub9ac\ud55c\ub2e4.',
        'cards/SRC-06.md': '\uc608\uce21\uae30 \uc0c1\uc704 \ud568\uc218 1,168\uac74\uc774 \uccab \ub2e8\uc77c \uc2e4\ud589\uc5d0\uc11c \ud1b5\uacfc\ud588\ub2e4. \uc774 \ubcc0\uacbd\uc740 cfg(test) \uacbd\ub85c\uc5d0\ub9cc \uc788\uc73c\uba70 \uc77c\ubc18 CLI\ub97c \uc7ac\uc2e4\ud589\ud558\uc9c0 \uc54a\uc558\ub2e4. \uc5f0\uc18d \uc774\ub825\u00b7\ubc30\uc218\u00b7\ube44\uacf5\uac1c \uce90\uc2dc \uac80\uc99d\uc740 \ubcc4\ub3c4 \uc758\ubb34\ub85c \ub0a8\uc544 \uc788\ub2e4.',
    }
    docs = {}
    for n, text in doc_appends.items():
        p = R / 'energyplus_porting_plan' / n
        b = p.read_bytes()
        assert b == subprocess.check_output(['git', 'show', head + ':energyplus_porting_plan/' + n], cwd=R)
        assert '?' not in text and '\ufffd' not in text and '\ufffd' not in b.decode('utf8')
        docs[n] = b
    pp = R / 'energyplus_porting_plan/plan.json'
    before = pp.read_bytes()
    assert before == subprocess.check_output(['git', 'show', head + ':energyplus_porting_plan/plan.json'], cwd=R)
    PUBLIC.mkdir(parents=True)
    BACK.mkdir()
    (BACK / 'plan-before.json').write_bytes(before)
    archive = PUBLIC / 'evidence.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for x in sorted(rows.values(), key=lambda v: v['path']):
            z.write(checked(x), x['path'])
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(rows)
        for x in rows.values():
            b = z.read(x['path'])
            assert len(b) == x['bytes'] and hashlib.sha256(b).hexdigest() == x['sha256']
    manifest = PUBLIC / 'manifest.json'
    write(manifest, dict(schema='src06-full-predictor-parent-finite-archive48.v1', archive=ref(archive), entries=sorted(rows.values(), key=lambda v: v['path']), retained_large_Native_stream=readset['raw'], retained_stream_copied=False))
    summary = dict(actual)
    summary.update(schema='src06-canonical-full-predictor-parent48.v1', A='14/54', B='14/64', gate_changes=False, policy_changes=0, archive=ref(archive), archive_manifest=ref(manifest), archive_entries=len(rows), retained390MB_Native_whole_SHA_bytes_rechecked=True, actual_Native_engine_reruns=0, normal_production_behavior_changed=False, selected_Source_files=[x['canonical_path'] for x in draft['files']], final_checkpoint=False)
    sp = PUBLIC / 'summary.json'
    write(sp, summary)
    proofs = []
    relative = 'evidence/SRC-06-canonical-full-predictor-parent-48/summary.json'
    for n, b in docs.items():
        old = BACK / 'docs-before' / n
        old.parent.mkdir(parents=True, exist_ok=True)
        old.write_bytes(b)
        link = ('../' if n.startswith('cards/') else '') + relative
        append = ('\n\n[Source48 full predictor parent](' + link + '). ' + doc_appends[n] + '\n').encode('utf8')
        p = R / 'energyplus_porting_plan' / n
        p.write_bytes(b + append)
        assert p.read_bytes()[:-len(append)] == b
        proofs.append(dict(path=p.relative_to(R).as_posix(), before=ref(old), after=ref(p), appended_UTF8_bytes=len(append)))
    after = json.loads(before)
    task = next(x for x in after['tasks'] if x['id'] == 'SRC-06')
    key = 'canonical_full_predictor_parent_48'
    assert key not in task
    task[key] = ref(sp)
    inv = json.loads(json.dumps(after))
    del next(x for x in inv['tasks'] if x['id'] == 'SRC-06')[key]
    assert inv == json.loads(before)
    write(pp, after)
    p = BACK / 'publication-readback.json'
    write(p, dict(status='PUBLISHED_PENDING_ROOT_QA_AND_COMMIT', summary=ref(sp), archive=ref(archive), archive_manifest=ref(manifest), archive_entries=len(rows), docs=proofs, plan_before=ref(BACK / 'plan-before.json'), plan_after=ref(pp), one_SRC06_key_inverse=True, base_HEAD=head, author_Source=ref(Path(__file__))))
    print(json.dumps(ref(p)))

if __name__ == '__main__':
    main()

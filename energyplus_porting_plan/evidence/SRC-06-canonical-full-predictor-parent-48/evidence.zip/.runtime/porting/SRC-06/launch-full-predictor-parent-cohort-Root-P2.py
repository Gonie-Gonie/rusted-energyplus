"""Root-only ONE process-main full-parent cohort; no old cohort or normal CLI."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main(a):
    g=module(D/'apply-full-predictor-parent-Root-P2.py','full_parent_readonly_guards')
    prepared=g.read(g.PREP)
    g.need(g.ref(Path(__file__))==prepared['launch_Source'],'Launcher changed')
    g.checked(prepared['application_Source'])
    ar=g.argument(a.application);g.need(g.checked(ar)==(g.OUT/'receipt.json').resolve(),'Unexpected application path')
    app=g.read(g.checked(ar));g.need(app['accepted'] and not app['findings'] and app['actual_test_or_CLI_invocations']==0,'Application not accepted')
    g.need(app['prepared']==g.ref(g.PREP) and app['complete_compiler_plan']==prepared['complete_proposed_compiler_Source_plan'],'Application binding')
    g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==app['base_HEAD'],'Actual HEAD differs')
    plan=g.read(g.checked(app['complete_compiler_plan']));g.need((plan['inputs'],plan['Rust_sources'])==(4525,4512),'Final counts')
    g.exact({row['path']:row for row in plan['entries']})
    old=g.read(g.checked(prepared['prior_focused59_receipt']));g.need(old['exit_code']==0,'Prior command not successful')
    cmd=list(old['command']);g.need(cmd[-1]=='--sizer-only','Original main selector differs');cmd[-1]='--predictor-parent-only'
    g.need(cmd==['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--predictor-parent-only'],'Exact focused command required')
    env_guard=module(g.checked(prepared['inherited_environment_guard']),'inherited_exact_environment')
    env=env_guard.environment()
    out=D/'canonical-source-full-predictor-parent-cohort-Root-P2';g.need(not out.exists(),'Focused invocation already exists')
    g.checked(prepared['record_command_Source'])
    print('Root P2: one full1168 parent process-main cohort; old2336/471/59 paths skipped.',flush=True)
    return subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',out.relative_to(R).as_posix(),'--',*cmd],cwd=R,env=env)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--application',required=True);raise SystemExit(main(p.parse_args()))

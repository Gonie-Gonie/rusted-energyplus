﻿"""Shared read-only Source43 command guards; no invocation on import."""
from pathlib import Path
import hashlib,json,os,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
MANIFEST=D/'source-hard-sized-purchased-air-cohort-combined-held-Peer-43/manifest.json';MANIFEST_SHA='07042064f18e8ccbf7eb42a3303c68b5d0cf393cc9f5acc0a1bcbc624a4712c2';PLAN_SHA='0e375beed2838380d857e424b6215c937d8a2b163945647e44a18eaf91280958';BASE='728bceba565cd960077f161c93865c6a4730c99a'
APP=D/'Root-hard-sized-purchased-air-cohort-application-43/receipt.json';TARGET=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
FOCUSED=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--sizer-only']
FOCUS_DIR=D/'canonical-source-hard-size-cohort-Root-43';FOCUS_REVIEW=D/'Root-source-hard-size-cohort-actual-review-43/review.json'
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(r):
 p=(R/r['path']).resolve();assert p.is_relative_to(R);v=ref(p);assert v['sha256']==r['sha256']and v['bytes']==r.get('bytes',v['bytes']),(r,v);return p
def read(p):return json.loads(p.read_bytes())
def argument(s):
 name,sha=s.rsplit('#',1);return ref(checked(dict(path=name,sha256=sha)))
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256'])or any(contains(x,r)for x in v.values())
 return isinstance(v,list)and any(contains(x,r)for x in v)
def authority(spec):
 ar=argument(spec);assert checked(ar)==APP.resolve();a=read(APP);assert a['accepted']and not a['findings']and a['base_HEAD']==BASE;assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
 mr=ref(MANIFEST);assert mr['sha256']==MANIFEST_SHA and contains(a,mr);m=read(MANIFEST);pr=a['complete_compiler_plan'];assert pr==m['complete_final_compiler_Source_plan'] and pr['sha256']==PLAN_SHA;plan=read(checked(pr));assert(plan['inputs'],plan['Rust_sources'],len(plan['entries']))==(4517,4504,4517)
 inventory={p.relative_to(R).as_posix()for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix()for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert inventory=={x['path']for x in plan['entries']}
 for row in plan['entries']:
  p=R/row['path'];b=p.read_bytes();assert len(b)==row['final_bytes']and hashlib.sha256(b).hexdigest()==row['final_sha256'],row['path']
 return ar,a,m,pr,plan

def environment():
 env=dict(os.environ);assert TARGET.is_dir();env['CARGO_TARGET_DIR']=str(TARGET);env['CARGO_INCREMENTAL']='0'
 for key in('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_HOME'):assert env.get(key)is None,(key,'Unexpected compiler override')
 assert Path(env['CARGO_TARGET_DIR']).resolve()==TARGET and env['CARGO_INCREMENTAL']=='0';return env

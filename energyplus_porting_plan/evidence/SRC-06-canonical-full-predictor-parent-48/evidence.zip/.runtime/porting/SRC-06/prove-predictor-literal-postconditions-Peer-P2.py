"""Pinned source/constructor proof for four intentionally UNOBSERVED literals."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
OUT = D / 'full-predictor-parent-readset-Peer-P2-01'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def authority(relative, spans):
    path = N / 'src/EnergyPlus' / relative
    raw = path.read_bytes()
    committed = subprocess.check_output(['git', '-C', str(N), 'show', PIN + ':src/EnergyPlus/' + relative])
    need(raw == committed, 'Native whole differs from pinned Git: ' + relative)
    lines = raw.decode('utf-8-sig').splitlines(keepends=True)
    extents = []
    for start, end in spans:
        text = ''.join(lines[start-1:end]).encode('utf-8')
        target = OUT / (relative.replace('/', '__') + f'.{start}-{end}.txt')
        need(not target.exists(), 'Immutable target already exists')
        target.write_bytes(text)
        extents.append({'first_line': start, 'last_line': end, 'exact_UTF8_extent': ref(target)})
    return {'whole': ref(path), 'pinned_Git_whole_exact': True, 'extents': extents}


readset_path = OUT / 'readset.json'
need(ref(readset_path)['sha256'] == 'f28ac4ac6f7b5b9a679af1dc2f960401a35364b33e10bd33f2a68c5c81d4255e', 'Readset changed')
readset = json.loads(readset_path.read_bytes())
need(readset['accepted'] and readset['actual_full_predictor_invocations'] == 1168, 'Full parent exits not admitted')
need(all(k == 'false' for k in readset['domains']['clock.DoingSizing']), 'Latent sizing premise not proven')
native = [authority('ZoneTempPredictorCorrector.cc', [(809, 855), (3146, 3257), (3462, 3495), (3625, 3667), (3793, 3815), (6835, 7243)]),
          authority('DataHeatBalance.hh', [(600, 610)]),
          authority('DataZoneControls.hh', [(270, 280)]),
          authority('InputProcessing/InputProcessor.cc', [(505, 541)])]
matches = []
for path in sorted((N / 'src/EnergyPlus').rglob('*')):
    if path.suffix not in ('.cc', '.hh'):
        continue
    for i, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
        if 'humidityControlZoneIndex' in line:
            matches.append({'path': path.relative_to(N).as_posix(), 'line': i, 'text': line})
need([(x['path'],x['line']) for x in matches] == [
    ('src/EnergyPlus/DataHeatBalance.hh',607),
    ('src/EnergyPlus/ZoneTempPredictorCorrector.cc',854),
    ('src/EnergyPlus/ZoneTempPredictorCorrector.cc',3491),
    ('src/EnergyPlus/ZoneTempPredictorCorrector.cc',3492)], 'Native humidity index producer census changed')
ztpc = (N / 'src/EnergyPlus/ZoneTempPredictorCorrector.cc').read_text(encoding='utf-8-sig').splitlines()
parent = '\n'.join(ztpc[3145:3257])
sensible = '\n'.join(ztpc[6834:7243])
moisture = '\n'.join(ztpc[3461:3815])
need(not re.search(r'\breturn\b', parent), 'Unexpected parent early return')
need('ShortenTimeStepSysRoomAir' not in sensible + moisture, 'A later child rewrites RoomAir literal')
need('humidityControlZoneIndex =' not in sensible + moisture, 'A later child rewrites humidity index')
need('TotalOutputRequired = 0.0;' in moisture and 'OutputRequiredToDehumidifyingSP = 0.0;' in moisture
     and 'OutputRequiredToHumidifyingSP = 0.0;' in moisture, 'Actual no-humidistat literal suffix missing')
source_paths = [
    'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs',
    'crates/ep_runtime/src/heat_balance/selected_input_processor.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/input.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/demand.rs',
    'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/subsystems.rs']
source = [ref(R / path) for path in source_paths]
result = {'schema':'src06-P2-unobserved-literal-source-proof.v1','accepted':True,'findings':[],
    'author':ref(Path(__file__)),'readset':ref(readset_path),'Native_pin':PIN,'Native_authorities':native,
    'complete_Native_cc_hh_humidity_index_token_census':matches,'current_Source_contexts':source,
    'proof':[
        {'postcondition':'ShortenTimeStepSysRoomAir == false','Native_writer':'ZoneTempPredictorCorrector.cc:3212',
         'conditions':'All 1168 captured parents normal-exit; all actual ZoneAirSolutionAlgo0=ThirdOrder. Conditional later true writer3236 is inside excluded non-ThirdOrder block. Neither subsequent child writes the field.',
         'Source_writer':'prediction.rs:128','observed_in_capture':False},
        {'postcondition':'Three ZoneSysMoistureDemand outputs == positive zero',
         'Native_writers':'ZoneTempPredictorCorrector.cc:3810-3812',
         'conditions':'Actual converted genuine B lacks Humidistat; Native getNumObjectsFound505-541 returns0; getter811 count0 makes818 loop empty. DataHeatBalance.hh607 constructor index0 is retained because sole positive writer854 is in that loop. All actual DoingSizing=false, DoLatentSizing=false. ControlledHumidZoneFlag3489 remainsfalse, spaceNum0 reaches3805 and literal suffix. No post-suffix write before normal parent exit.',
         'Source_writers':'prediction.rs:333-335','observed_in_capture':False}],
    'future_Source_assertions':'Separate code-derived postconditions, not Native captured bit comparison counts. May pre-seed test-only canaries in these four unobserved output-only cells to prove overwrite, explicitly labelled test inputs rather than observed entry state.',
    'genuine_moisture_row_allocation':'Existing Source demand.allocate_source_demands with actual NumZones1; allocation/constructor proof accompanies Source test. Native normal parent exit proves referenced row exists; observer did not record its shape.',
    'qualification':'No humidity-control/latent-sizing/non-ThirdOrder branch claim; no native observation synthesized; no private Cp cache observation; no new engine/compiler/test run.'}
target = OUT / 'unobserved-literal-proof.json'
need(not target.exists(), 'Immutable proof already exists')
target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(ref(target)))

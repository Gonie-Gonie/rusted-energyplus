"""Read actual focused P2 execution; no test/engine process is launched."""
from pathlib import Path
import hashlib, importlib.util, json

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'

def main():
    spec = importlib.util.spec_from_file_location('p2guards', D / 'apply-full-predictor-parent-Root-P2.py')
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    prepared = g.read(g.PREP)
    assert g.ref(g.PREP)['sha256'] == 'df4315dcd0b9cf2bd3ef4fbd9dbd47d0ae27d867f9f1b4d0cfb0752f78b83aa5'
    assert g.ref(D / 'apply-full-predictor-parent-Root-P2.py') == prepared['application_Source']
    app_path = g.OUT / 'receipt.json'
    assert g.ref(app_path)['sha256'] == 'b93959d6f6f9f41ced24a3c7dbbf3c2d01c6329a66e8d73e963a1d0bc2be6d4a'
    app = g.read(app_path)
    assert app['accepted'] and not app['findings'] and app['all4525_final_plan_inputs_exact']
    plan = g.read(g.checked(app['complete_compiler_plan']))
    rows = {x['path']: x for x in plan['entries']}
    assert (plan['inputs'], plan['Rust_sources'], len(rows)) == (4525, 4512, 4525)
    g.exact(rows)
    peer = g.read(g.checked(prepared['independent_full_semantic_peer']))
    assert peer['status'] == 'ACCEPTED Source and projection; actual focused execution and final End47 join pending'
    assert not peer['findings'] and peer['reviewed_draft'] == prepared['original_draft']
    original = g.read(g.checked(prepared['original_draft']))
    for f in original['files']:
        assert (R / f['canonical_path']).read_bytes() == g.checked(f['proposed']).read_bytes()
    rp = D / 'canonical-source-full-predictor-parent-cohort-Root-P2/receipt.json'
    assert g.ref(rp)['sha256'] == '20a831f4e742b7cac7f0488f2a4596afa257e83a734e26fa10001b1afb1c1e93'
    run = g.read(rp)
    assert run['exit_code'] == 0 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
    assert run['repository_before'] == run['repository_after'] and run['repository_before']['head'] == app['base_HEAD']
    assert run['command'] == ['cargo', 'test', '--locked', '-p', 'ep_runtime', '--features', 'native-controlled-air-cohort', '--test', 'native_controlled_air_cohort', '--', '--predictor-parent-only']
    expected_target = (D / 'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
    assert Path(run['launch_environment_selected']['CARGO_TARGET_DIR']).resolve() == expected_target
    assert all(v is None for k, v in run['launch_environment_selected'].items() if k != 'CARGO_TARGET_DIR')
    assert run['cargo_compiler_artifacts_capture']['requested'] is False
    snapshot = g.read(g.checked(dict(run['source_snapshot'], bytes=(R / run['source_snapshot']['path']).stat().st_size)))
    archived = {x['historical_path']: x for x in snapshot['files']}
    assert archived.keys() == rows.keys()
    for n, row in rows.items():
        a = archived[n]
        b = (R / a['archive']['path']).read_bytes()
        assert len(b) == a['size_bytes'] == row['final_bytes'] and hashlib.sha256(b).hexdigest() == a['archive']['sha256'] == row['final_sha256'], n
    stdout = R / run['stdout']['path']
    stderr = R / run['stderr']['path']
    assert g.ref(stdout)['sha256'] == run['stdout']['sha256']
    assert g.ref(stderr)['sha256'] == run['stderr']['sha256']
    assert stdout.read_text(encoding='utf8').splitlines() == [
        'running 1 full native predictor-parent cohort on process main',
        'cohort native_controlled_air_cohort ... ok',
        'cohort result: ok. 1 passed; 0 failed; genuine full predictor parents=1168; code-derived literal postconditions=4 per call; private cache trace unobserved',
    ]
    err = stderr.read_text(encoding='utf8')
    assert 'Finished `test` profile' in err and 'Running src\\lib.rs (' in err
    # Both changed existing files are behind the actual combined cfg gate.
    # All other parent inputs and production function bodies are unchanged.
    prediction = R / 'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs'
    assert '#[cfg(all(test, feature = "native-controlled-air-cohort"))]\nmod native_cohort;' in prediction.read_text(encoding='utf8')
    lib_before = g.checked(next(f for f in original['files'] if f['canonical_path'] == 'crates/ep_runtime/src/lib.rs')['before']).read_bytes()
    lib_after = (R / 'crates/ep_runtime/src/lib.rs').read_bytes()
    marker = b'// Explicit test target only:'
    assert lib_before.split(marker, 1)[0] == lib_after.split(marker, 1)[0]
    assert b'#[cfg(all(test, feature = "native-controlled-air-cohort"))]\nfn main()' in lib_after
    result = dict(schema='src06-full-predictor-parent-actual-review.v1', accepted=True, findings=[], application=g.ref(app_path), prepared=g.ref(g.PREP), base_HEAD=app['base_HEAD'], parent_End47_actual=app['parent_End47_actual'], complete_compiler_plan=app['complete_compiler_plan'], actual_receipt=g.ref(rp), actual_source_snapshot=run['source_snapshot'], all4525_live_and_archived_inputs_exact=True, Rust_sources=4512, independent_semantic_peer=prepared['independent_full_semantic_peer'], original_draft=prepared['original_draft'], actual_focused_invocations=1, actual_full_parent_cases=1168, shortened_actual_parent_cases=77, code_derived_unobserved_literal_postconditions_per_case=4, code_derived_postconditions_counted_as_Native_observed_bits=False, Native_captured_binary64_comparison_denominator_claimed=False, retained_Native_projection=original['projection'], retained_Native_readset=original['readset'], separate_literal_proof=original['separate_unobserved_literal_proof'], raw_IDF_absent_family_proof=prepared['additional_real_IDF_zero_control_proof'], row_allocation_proof=prepared['additional_genuine_row_allocation_proof'], stdout=g.ref(stdout), stderr=g.ref(stderr), selected_test_only_Source_files=4, actual_existing2336_471_59_bodies_reexecuted=0, new_test_functions=0, new_targets_or_features=0, normal_CLI_reruns=0, compiler_artifact_capture_requested=False, private_cache_trace_observed=False, qualification='Independent retained whole Native-parent entry replay on the same real Source owner allocations; no whole history/lifecycle integration claim. Four code-derived unobserved postconditions remain separate. This one actual main-context pass does not promote card gates or certify all branch inputs.', author_Source=g.ref(Path(__file__)))
    out = D / 'Root-full-predictor-parent-actual-review-P2'
    assert not out.exists()
    out.mkdir()
    p = out / 'review.json'
    p.write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(g.ref(p)))

if __name__ == '__main__':
    main()

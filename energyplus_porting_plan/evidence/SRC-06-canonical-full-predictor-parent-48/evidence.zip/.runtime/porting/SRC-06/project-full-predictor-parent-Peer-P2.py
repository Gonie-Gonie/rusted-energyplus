"""Lossless bounded projection of full Native21 parent calls, no numeric oracle."""
from pathlib import Path
import hashlib
import json
import re

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
P = D / 'source-full-predictor-parent-draft-Peer-P2-01'
LEAF = 'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction'
FIX = LEAF + '/fixtures/native_full_predictor_b.rs'
OLD = LEAF + '/fixtures/native_prediction_b.rs'


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(R).as_posix() if path.is_relative_to(R) else path.as_posix(),
            'sha256': digest, 'bytes': path.stat().st_size}


def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'Duplicate JSON key ' + key)
        out[key] = value
    return out


def stripped(value):
    if isinstance(value, dict):
        if 'value_bits' in value:
            need(set(value) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', value['value_bits']), 'Bad f64')
            return value['value_bits']
        return {key: stripped(child) for key, child in value.items()
                if key not in ('address', 'owner_address', 'state_address')}
    if isinstance(value, list):
        return [stripped(child) for child in value]
    need(not isinstance(value, float), 'Unexpected decimal float')
    return value


def state(e):
    s, c = e['state'], e['clock']
    f, n = s['fan'], s['zone_system_node']
    return stripped({'air': s['air'], 'zone': s['zone'], 'clock': c, 'flags': s['flags'],
        'node': n['value'], 'node_ordinal': n['index'], 'node_name': n['NodeID'],
        'fan': {'TempTstatAir': f['TempTstatAir']['value'], 'LoadCorrectionFactor': f['LoadCorrectionFactor']['value'],
            'TempControlType': f['TempControlType']['value'], 'setpoints': f['zoneTstatSetpts']['value'],
            **{key: f[key]['value'] for key in ('SumConvHTRadSys', 'SumConvPool', 'SumLatentHTRadSys', 'SumLatentPool')}},
        'demand': {'Setback': s['demand']['Setback']['value'], 'DeadBandOrSetback': s['demand']['DeadBandOrSetback']['value'],
            'CurDeadBandOrSetback': s['demand']['CurDeadBandOrSetback']['value'], 'sensible': s['demand']['zone']['value']},
        'config': s['zone_config']['value'],
        'actual_shapes': {key: s[key] for key in ('aliases',)}})


readset_path = D / 'full-predictor-parent-readset-Peer-P2-01/readset.json'
need(ref(readset_path)['sha256'] == 'f28ac4ac6f7b5b9a679af1dc2f960401a35364b33e10bd33f2a68c5c81d4255e', 'Readset changed')
readset = json.loads(readset_path.read_bytes(), object_pairs_hook=unique)
proof_path = D / 'full-predictor-parent-readset-Peer-P2-01/unobserved-literal-proof.json'
need(ref(proof_path)['sha256'] == '3a89488c710489fa919f6b498236239466c419225030bde1ad6154595358ad61', 'Literal proof changed')
need(json.loads(proof_path.read_bytes())['accepted'], 'Literal proof not accepted')
capture_path = R / readset['capture']['path']
need(ref(capture_path) == readset['capture'], 'Capture changed')
capture = json.loads(capture_path.read_bytes())
raw = R / readset['raw']['path']
need(ref(raw) == readset['raw'], 'Raw changed')
reader = R / readset['reader']['path']
need(ref(reader) == readset['reader'], 'Reader changed')
rb = reader.read_bytes().replace(b"literal('],\"summary\":')", b"literal('],\"terminal_summary\":')")
need(hashlib.sha256(rb).hexdigest() == readset['reader_single_terminal_key_adaptation_sha256'], 'Reader adapter differs')
ns = {}
exec(compile(rb, '<fixed-terminal-key-only>', 'exec'), ns)
need(not P.exists(), 'Immutable destination exists')
rows, active, events = [], None, 0


def visit(e):
    global active, events
    events += 1
    need(e['event_ordinal'] == events, 'Event sequence')
    if e['method'] == 'predictSystemLoad':
        if e['phase'] == 'entry':
            need(active is None and e['invocation_ordinal'] == len(rows) + 1, 'Parent entry order')
            active = {'invocation': e['invocation_ordinal'], 'arguments': stripped(e['locals']), 'entry': state(e),
                      'native_Air_address': e['state']['air']['owner_address'],
                      'native_Node_address': e['state']['zone_system_node']['value']['address'],
                      'entry_event': e['event_ordinal']}
        elif e['phase'] == 'normal_exit':
            need(active is not None and e['invocation_ordinal'] == active['invocation'], 'Parent exit join')
            active['exit'] = state(e)
            active['exit_event'] = e['event_ordinal']
            need('sums_inputs' in active, 'First-consumed external Sums operands absent')
            original_join = readset['actual_parent_event_joins'][len(rows)]
            need([active[k] for k in ('entry_event', 'exit_event', 'sums_entry_event')]
                 == [original_join[k] for k in ('entry_event', 'exit_event', 'sums_entry_event')], 'Admitted event join differs')
            rows.append(active)
            active = None
    elif e['method'] == 'calcZoneOrSpaceSums' and e['phase'] == 'entry' and e['parent_method'] == 'predictSystemLoad':
        need(active is not None and active['invocation'] == e['parent_invocation_ordinal'], 'Sums real parent')
        need(e['locals'] == {'CorrectorFlag': 0}, 'Predictor real Sums flag')
        need(e['state']['air']['owner_address'] == active['native_Air_address'], 'Actual same Air')
        need(e['state']['zone_system_node']['value']['address'] == active['native_Node_address'], 'Actual same Node')
        need('sums_inputs' not in active, 'Duplicate Sums input')
        active['sums_inputs'] = stripped(e['state']['spaces'])
        active['sums_entry_event'] = e['event_ordinal']


transport = ns['read'](raw, need, unique, visit)
need(active is None and len(rows) == 1168 and events == 30445, 'Complete cohort differs')
need(transport['summary'] == capture['observation_checks']['terminal_summary'], 'Actual terminal footer differs')
old = (R / OLD).read_bytes()
prefix = b'const NATIVE_PREDICTION_COHORT_JSON: &str = r###"'
old_json = json.loads(old.split(prefix, 1)[1].rsplit(b'"###;', 1)[0], object_pairs_hook=unique)
tables, indexes, packed = {}, {}, []
for row in rows:
    item = {key: value for key, value in row.items() if key not in ('entry', 'exit', 'sums_inputs')}
    for phase in ('entry', 'exit'):
        item[phase] = {}
        for key, value in row[phase].items():
            canonical = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
            table, lookup = tables.setdefault(key, []), indexes.setdefault(key, {})
            if canonical not in lookup:
                lookup[canonical] = len(table)
                table.append(value)
            item[phase][key] = lookup[canonical]
        need({key: tables[key][at] for key, at in item[phase].items()} == row[phase], 'Full state inverse differs')
    key = json.dumps(row['sums_inputs'], sort_keys=True, separators=(',', ':'), ensure_ascii=False)
    table, lookup = tables.setdefault('sums_inputs', []), indexes.setdefault('sums_inputs', {})
    if key not in lookup:
        lookup[key] = len(table)
        table.append(row['sums_inputs'])
    item['sums_inputs'] = lookup[key]
    need(table[item['sums_inputs']] == row['sums_inputs'], 'Full external input inverse differs')
    packed.append(item)
fixture = {'schema': 'src06-real-Native21-full-predictor-parent.v1', 'case_count': len(rows),
           'definitions': old_json['definitions'], 'raw': old_json['raw'], 'object_order': old_json['object_order'],
           'state_tables': tables, 'cases': packed}
target = P / 'proposed' / FIX
target.parent.mkdir(parents=True)
target.write_bytes(b'// Test-only genuine full Native parent entries/exits; no production reads.\n'
                  b'const NATIVE_FULL_PREDICTOR_JSON: &str = r###"'
                  + json.dumps(fixture, ensure_ascii=False, separators=(',', ':')).encode('utf-8') + b'"###;\n')
def f64s(value):
    if isinstance(value, str):
        return int(bool(re.fullmatch('[0-9a-f]{16}', value)))
    if isinstance(value, dict):
        return sum(f64s(v) for v in value.values())
    if isinstance(value, list):
        return sum(map(f64s, value))
    return 0
provenance = {'schema': 'src06-full-predictor-parent-lossless-projection.v1', 'author': ref(Path(__file__)),
    'readset': ref(readset_path), 'unobserved_literal_proof': ref(proof_path), 'capture': ref(capture_path),
    'raw': ref(raw), 'reader': ref(reader), 'adapted_reader_sha256': hashlib.sha256(rb).hexdigest(),
    'events_streamed': events, 'full_parents': len(rows), 'fixture': ref(target),
    'lossless_interned_tables': {key: len(value) for key,value in tables.items()},
    'all_2336_full_parent_states_and_1168_external_Sums_input_states_roundtrip_exact': True,
    'expected_exit_captured_f64_count': sum(f64s(row['exit']) for row in rows),
    'original_Air_fixture_unchanged': ref(R / OLD),
    'input_projection':'Actual parent ENTRY only + first-consumed external spaces/surfaces/saved gain cells. No local coefficient checkpoints or child entry coefficient values are selected. Parent output-only AirPowerCap/tempDepLoad/tempIndLoad will be set to explicit constructor-zero test canaries before the real Source parent, not seeded with captured answers.',
    'four_literal_postconditions':'NOT in fixture observations or f64 counts. Source asserts separately from pinned code proof.',
    'recurrence_scope':'1168 independent engine-captured parent calls; outside-parent engine updates are not reconstructed. No uninterrupted parent recurrence claim. Future named history sequences must not restore between their steps.',
    'Source_Native_or_compiler_execution': False}
(P / 'projection.json').write_text(json.dumps(provenance, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'fixture': ref(target), 'projection': ref(P / 'projection.json')}))

"""Seal isolated Source19 against Root's clean committed17 and actual17 receipts."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, re, subprocess

R = Path(__file__).resolve().parents[3]
B = R/'.runtime/porting/SRC-06'
D = B/'source-thermostat-current-draft-Outer-19'
O = B/'source-thermostat-current-held-Outer-19'
N = R/'.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
parser = argparse.ArgumentParser()
parser.add_argument('--committed17-head', required=True)
HEAD = parser.parse_args().committed17_head

def ref(p):
    data = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def get(record):
    p = R/record['path']; actual = ref(p)
    assert actual['sha256'] == record['sha256'], record
    assert actual['bytes'] == record.get('bytes', actual['bytes'])
    return p

def load(p):
    return json.loads(p.read_bytes())

assert HEAD == 'd33979a3ef658a3ff3966ebf71010a107b639ce7'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=R)
assert not O.exists(), 'immutable output exists'
review_path = B/'Root-source-thermostat-actual-review-17/review.json'
assert ref(review_path)['sha256'] == '694bda5d1001319b67acd9b6bbae157afa478deacf60193968572ce44f55f11f'
review = load(review_path)
assert review['accepted'] and not review['findings']
assert review['B_frontier'] == 'GetHeatBalanceInput: positive actual TempControlledZone2700'
assert not review['B_Node_lifecycle_execution']['setup_returned']
assert not review['B_Node_lifecycle_execution']['reset_returned']
assert review['same4489_archived_inputs_exact_final_plan']
snapshots = []
for key, expected in [('actual_owner_test',0), ('actual_B',6), ('actual_A24',0)]:
    receipt = load(get(review[key]))
    assert receipt['exit_code'] == expected and receipt['launch_error'] is None
    assert receipt['source_bytes_match_before_and_after'] is True
    snapshots.append(get(receipt['source_snapshot']))
assert snapshots[0].read_bytes() == snapshots[1].read_bytes() == snapshots[2].read_bytes()
snapshot = snapshots[1]
assert ref(snapshot)['sha256'] == '6df486de836be26b0e3439847f73710b30e38078cecb909d339bdecd16b6ef0b'
before = {row['historical_path']:row for row in load(snapshot)['files']}
assert len(before) == 4489 and sum(name.endswith('.rs') for name in before) == 4476
parent_plan_path = get(review['complete_compiler_plan'])
parent_plan = {row['path']:row for row in load(parent_plan_path)['entries']}
assert set(parent_plan) == set(before)
for name, row in before.items():
    data = get(row['archive']).read_bytes()
    assert len(data) == row['size_bytes'] and hashlib.sha256(data).hexdigest() == parent_plan[name]['final_sha256']
    assert (R/name).read_bytes() == data, name

freeze = load(D/'freeze.json')
frozen = {row['path']:row for row in freeze['sources']}
status = {row['path']:row for row in load(D/'parse-draft-01.json')}
proposed = {p.relative_to(D/'proposed').as_posix():p.read_bytes() for p in sorted((D/'proposed').rglob('*.rs'))}
assert len(proposed) == 12 and len(frozen) == 11 and set(status) == set(proposed)
for name, data in proposed.items():
    assert hashlib.sha256(data).hexdigest() == status[name]['sha256'] and status[name]['parse_exit'] == 0
    if name in frozen:
        old = (D/'parent'/name).read_bytes()
        assert old == get(frozen[name]['parent_Source']).read_bytes() == get(before[name]['archive']).read_bytes()
        assert old == (R/name).read_bytes() == subprocess.check_output(['git','show',HEAD+':'+name],cwd=R)
    else:
        assert name not in before and not (R/name).exists()
        old = b''
    additions = '\n'.join(line[1:] for line in difflib.unified_diff(old.decode().splitlines(),data.decode().splitlines())
                          if line.startswith('+') and not line.startswith('+++')).encode()
    assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unreachable|unimplemented)!',additions)
    assert b'#[test]' not in additions and b'.runtime' not in additions and b'ZONE ONE' not in additions

helper = (B/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')
fn = next(node for node in ast.parse(helper).body if isinstance(node,ast.FunctionDef) and node.name=='apply_literal')
ns = {'re':re}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<independent-literal-applier>','exec'),ns)
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip() == PIN
O.mkdir()

def put(name,data):
    p = O/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
    return ref(p)

def doc(name,value):
    return put(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf8'))

files = []; bridges = []
for number,(name,data) in enumerate(proposed.items(),1):
    old = (D/'parent'/name).read_bytes() if name in frozen else b''
    row = {'canonical_path':name,'before_absent':name not in before,
           'before':put('before/'+name,old),'proposed':put('proposed/'+name,data),
           'literal_inverse':put('literal-inverse/'+name,old)}
    for kind,left,right in [('forward_diff',old,data),('inverse_diff',data,old)]:
        diff = ''.join(difflib.unified_diff(left.decode().splitlines(True),right.decode().splitlines(True),
                                          fromfile='before/'+name,tofile='proposed/'+name,n=3)).encode()
        assert ns['apply_literal'](left,diff) == right
        row[kind] = put(f'diffs/{number:02}-{kind}.diff',diff)
    result = subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],
                            input=data,capture_output=True,cwd=R)
    assert result.returncode == 0,(name,result.stderr)
    row['Source_only_parse'] = {'exit_code':0,'stdout':put(f'parse/{number:02}.stdout',result.stdout),
                                'stderr':put(f'parse/{number:02}.stderr',result.stderr)}
    files.append(row)
    if name in before:
        bridges.append({'path':name,'committed_Git':HEAD,'actual17_archive':before[name]['archive'],
                        'draft_logical_accepted17_Source':frozen[name]['parent_Source'],'whole_equal':True,
                        'old_observed_HEAD_is_not_a_Git_equality_claim':freeze['observed_current_HEAD']})
assert sum(row['before_absent'] for row in files) == 1

planning_path = B/'thermostat-current-environment-readonly-plan-Audit-19/plan.json'
assert ref(planning_path)['sha256'] == '3f8acebfef06f6673fd42db80edf46148dbf318769e670778d4e22dd794172ed'
planning = load(planning_path)
wholes = []; extents = []
native_ranges = {
 'src/EnergyPlus/ZoneTempPredictorCorrector.cc':[(195,244),(2621,2816),(3259,3460),(5702,5713),(5863,5897),(6417,6458),(6460,6511)],
 'src/EnergyPlus/UtilityRoutines.hh':[(439,476)],
 'src/EnergyPlus/SystemAvailabilityManager.hh':[(563,568),(610,617)],
 'src/EnergyPlus/SystemAvailabilityManager.cc':[(1656,1668)],
 'src/EnergyPlus/FaultsManager.hh':[(385,410)],
 'src/EnergyPlus/FaultsManager.cc':[(237,268),(300,309)],
 'src/EnergyPlus/ScheduleManager.hh':[(254,272)],
}
for name,ranges in native_ranges.items():
    p = N/name; data = p.read_bytes()
    assert data == subprocess.check_output(['git','-C',str(N),'show',PIN+':'+name])
    wholes.append({**ref(p),'whole_equals_git':PIN})
    for first,last in ranges:
        literal = b''.join(data.splitlines(True)[first-1:last])
        extents.append({'native_path':name,'first':first,'last':last,'utf8_sha256':hashlib.sha256(literal).hexdigest(),
                        'literal':literal.decode('utf8')})
for authority in planning['Native_authorities']:
    p = get(authority['whole'])
    assert p.read_bytes() == subprocess.check_output(['git','-C',str(N),'show',PIN+':'+p.relative_to(N).as_posix()])
native_extents = doc('Native-literal-extents.json',extents)

by = {row['canonical_path']:row for row in files}
entries = []; census = []; constructors = dict.fromkeys(['SourceManageSurfaceOwners','SourceHvacOwners','SourceZoneAirOwners'],0)
symbols = re.compile(r'SourceManageSurfaceOwners|SourceHvacOwners|SourceZoneAirOwners|zone_air_update\s*\(|SourceFaultsManager|SourceAvailability|SourceOptimumStart|number_faulty_thermostat|verify_source_controlled_zone_for_thermostat|calculate_source_current_temperature_controls|override_source_air_setpoints_for_ems')
actual_calls = []
for name in sorted(set(before)|set(by)):
    record = by[name]['proposed'] if name in by else {**before[name]['archive'],'bytes':before[name]['size_bytes']}
    entries.append({'path':name,'final_sha256':record['sha256'],'final_bytes':record['bytes'],'source':record,
                    'origin':'held Source19 Thermostat proposal' if name in by else 'exact actual17 archived parent'})
    if name.endswith('.rs'):
        data = proposed[name] if name in proposed else get(before[name]['archive']).read_bytes()
        for line,text in enumerate(data.decode('utf8').splitlines(),1):
            if symbols.search(text): census.append({'path':name,'line':line,'literal':text})
            for constructor in constructors:
                constructors[constructor] += len(re.findall(r'\b'+constructor+r'\s*\{',text))
            if re.search(r'\bo\.zone_air_update\s*\(',text):actual_calls.append({'path':name,'line':line,'literal':text})
assert len(entries)==4490 and sum(row['path'].endswith('.rs') for row in entries)==4477
assert constructors == {'SourceManageSurfaceOwners':1,'SourceHvacOwners':2,'SourceZoneAirOwners':1}
assert len(actual_calls)==7 and all(row['path'].endswith('/ordinary_hvac_manager.rs') for row in actual_calls)
complete = doc('complete-final-compiler-Source-plan.json',{'base_HEAD':HEAD,'parent_actual_snapshot':ref(snapshot),
    'inputs':4490,'Rust_sources':4477,'entries':entries,'Root_full_rehash_required':True})
H = 'crates/ep_runtime/src/heat_balance/'
authorities = ['ordinary_equipment/management/availability.rs','ordinary_hvac_manager/ancillary.rs',
               'source_initialization.rs','source_initialization/kickoff_postlude.rs',
               'ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs','ctf_initialization_context.rs',
               'selected_schedule_manager/report.rs']
api = doc('whole-crates-concrete-API-inventory.json',{
    'scope':'All4490 logical final compiler inputs; all4477 Rust wholes including runtime/tests. No heat_balance-only search.',
    'occurrences':census,'actual_constructor_counts':constructors,'changed_actual_zone_air_update_calls':actual_calls,
    'test_literal_count_for_changed_private_owners':0,
    'unrelated_diagnostic_function':'diagnostic_probes/heat_balance.rs zone_air_update(feature) is a separate function and is unchanged.',
    'concrete_type_authorities':[before[H+name]['archive'] for name in authorities],
    'same_availability_borrow':'Seven manager calls borrow &self.ancillary.availability; no availability alias is retained on SourceHvacOwners while mutably borrowing manager self.',
    'same_fault_count_borrow':'reports.source_faults_manager -> surface/HVAC/predictor views; getter returns reference to actual retained i32. No fresh count or absence proxy.',
})
contract = doc('integration-contract.json',{
    'scope':'Observed17 TempControlledZone2700 -> real environment verification/demand loop and selected finite Dual current controls/EMS through the existing function returns. Source only; actual19 and fullB pending.',
    'same_owners':'Same controller.controls rows, flags, ZoneEquipConfig name array, fan setpoints/control arrays, live mutable ScheduleManager, actual manager.ancillary.availability OptStart and reports.source_faults_manager count. No alternate cache, copied schedule samples, extra retained flags or manufactured defaults.',
    'environment_order':'Native2681-2741 exact-name VerifyControlledZoneForThermostat when actual equipment-inputs-filled and not checked; no IsControlled proxy. Same actual manageDemand and four control cases, sequential chained writes. Existing comfort/fatal/checked tail retained.',
    'current_order':'Actual current schedule/control enum truncation/type/report; Dual cool -> thermostat-hi -> adaptive/operative -> heat -> thermostat-lo -> operative -> actual OptStart -> humidity -> real fault predicate. Mode4 scalar setpt untouched. Parent comfort guard precedes real EMS heating then cooling overrides in exact Native assignment order.',
    'defined_domain':'Control enum finite/i32-domain guard precedes truncating cast; no rounding/clamping. Missing owners/pointers remain typed unavailable. Same getCurrentVal honours actual EMSActuatedOn/EMSVal precedence.',
    'bounds':['SingleHeat used positive schedule3316, SingleCool3325, SingleHeatCool3342 remain typed at actual first unported value getter.',
              'Positive adaptive adjustment3379, operative fraction/MRT5886 and humidity overcool6441 remain typed before the first unported operation; real Any flags short-circuit before Invalid per-row modes.',
              'Actual OptStart matching-zone branch stops at first CEILING/day-value3394; other real OptStart rows use retained start_flag/occupied arrays without synthesized day samples.',
              'Positive real fault-count plus warmup/sizing/kickoff predicate stops before first fault-name3429; no inferred zero.',
              'Invalid/error diagnostics stop before unported diagnostic calls; comfort positives preserve their existing bound.',
              'Controlled3935/inlet5203 numerical correction and humidity/prediction remain separate; no18 CalcMoreNodeInfo operands or implementation included.',
              'Parent17 B Node setup/reset were unexecuted and BND header-only; this Source packet certifies no positive Node execution.'],
    'A_None':'Zero regular-control loops retain existing scientific assignments/streams. New view borrows/getter are deliberate; no blanket Legacy representation equality claim.',
    'validation':'Author performed12 Source-only stdin parses and24 forward/inverse literal applications, no Cargo/tests/Native/main. Root will run actual CLI B first then A24; no habitual unrelated existing-test/alltargets rerun. CLI build typechecks all new actual paths. Positive internal Native unit equivalence remains unclaimed until a meaningful cohort or fullB.',
    'new_tests':0,'main_mutations':0,'no_approximation_or_policy_change':True,
})
manifest = doc('manifest.json',{
    'schema':'src06-held-cohesive-finite-Thermostat-current.v1','status':'HELD Source only; compilation/actual19 pending',
    'base_HEAD':HEAD,'actual17_review':ref(review_path),'actual17_snapshot':ref(snapshot),'actual17_complete_plan':ref(parent_plan_path),
    'actual17_B':review['actual_B'],'actual17_A24':review['actual_A24'],'actual17_test':review['actual_owner_test'],
    'precise_selected_parent_bridges':bridges,'files':files,'existing_Source_files':11,'new_Source_files':1,
    'literal_applications':24,'Source_only_parses':12,'complete_final_compiler_Source_plan':complete,
    'whole_crates_API_inventory':api,'integration_contract':contract,'Native_commit':PIN,'Native_wholes':wholes,
    'Native_literal_extents':native_extents,'read_only_planning_authority':ref(planning_path),
    'draft_freeze':put('draft-freeze-at-seal.json',(D/'freeze.json').read_bytes()),
    'draft_status':put('draft-status-at-seal.json',(D/'parse-draft-01.json').read_bytes()),
    'author_Source':ref(B/'author-thermostat-current-draft-Outer-19.py'),'sealer_Source':ref(Path(__file__)),
    'new_test_bodies':0,'Cargo_Native_or_tests_executed':False,'main_mutations':0,
    'FP_tolerance_or_gate_changes':False,'full_B_or_positive_Node_execution_claim':False,
})
print(json.dumps({'manifest':manifest,'complete_plan':complete}))

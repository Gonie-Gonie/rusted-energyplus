from pathlib import Path
import re
R = Path(__file__).resolve().parents[3]
D = R/'.runtime/porting/SRC-06/source-thermostat-current-draft-Outer-19'
H = 'crates/ep_runtime/src/heat_balance/'
for p in (D/'parent').rglob('*.rs'):
    (D/'proposed'/p.relative_to(D/'parent')).write_bytes(p.read_bytes())

def change(name, before, after):
    p = D/'proposed'/(H+name); text = p.read_bytes().decode('utf8')
    assert text.count(before) == 1, (name, before[:90], text.count(before))
    p.write_bytes(text.replace(before, after).encode('utf8'))

change('ordinary_equipment.rs', 'impl OrdinaryEquipment {\n    /// Actual ReportLoopConnections2656',
       'impl OrdinaryEquipment {\n'
       '    /// Actual VerifyControlledZoneForThermostat5702 exact-name search.\n'
       '    pub(crate) fn verify_source_controlled_zone_for_thermostat(&self, name: &str) -> bool {\n'
       '        self.zone_config.as_ref().is_some_and(|rows| rows.iter().any(|row| row.zone_name == name))\n'
       '    }\n'
       '    /// Actual ReportLoopConnections2656')
change('source_initialization/kickoff_postlude/faults.rs', 'impl SourceFaultsManager {\n',
       'impl SourceFaultsManager {\n'
       '    /// Borrow actual retained FaultsManager count; no input-absence inference.\n'
       '    pub(crate) fn source_number_faulty_thermostat(&self) -> &i32 {\n'
       '        &self.number_faulty_thermostat\n'
       '    }\n')
change('ordinary_source_session/body.rs', '            shortcut: &mut reports.input_processor_shortcut,\n',
       '            shortcut: &mut reports.input_processor_shortcut,\n'
       '            faults: &reports.source_faults_manager,\n')
for name in ['ordinary_surface_management/provider_host.rs', 'ordinary_hvac_manager/owners.rs',
             'ordinary_air_heat_balance/predictor_corrector.rs']:
    change(name, "    pub(crate) source_is_epjson: &'a bool,\n",
           "    pub(crate) source_is_epjson: &'a bool,\n"
           "    pub(crate) faults: &'a crate::heat_balance::source_initialization::SourceFaultsManager,\n")
change('ordinary_air_heat_balance/predictor_corrector.rs',
       "    pub(crate) schedules: &'a mut crate::heat_balance::selected_schedule_manager::SelectedScheduleManager,\n",
       "    pub(crate) schedules: &'a mut crate::heat_balance::selected_schedule_manager::SelectedScheduleManager,\n"
       "    pub(crate) availability: &'a crate::heat_balance::ordinary_equipment::management::availability::SourceAvailability,\n")
for name in ['ordinary_air_heat_balance/provider_host.rs', 'ordinary_heat_balance_initialization/report.rs']:
    indent = '                ' if name.startswith('ordinary_air') else '            '
    change(name, indent+'source_is_epjson: o.source_is_epjson,\n',
           indent+'source_is_epjson: o.source_is_epjson,\n'+indent+'faults: o.faults,\n')
change('ordinary_hvac_manager/owners.rs', '        update: SourceAirUpdate,\n',
       '        availability: &crate::heat_balance::ordinary_equipment::management::availability::SourceAvailability,\n'
       '        update: SourceAirUpdate,\n')
change('ordinary_hvac_manager/owners.rs', '            source_is_epjson: self.source_is_epjson,\n',
       '            source_is_epjson: self.source_is_epjson,\n'
       '            faults: self.faults,\n            availability,\n')
p=D/'proposed'/(H+'ordinary_hvac_manager.rs');text=p.read_bytes().decode()
text,n = re.subn(r'(?m)^([ \t]*)o\.zone_air_update\(\n',
                 lambda match: match.group(0)+match.group(1)+'    &self.ancillary.availability,\n', text)
assert n == 7;p.write_bytes(text.encode())

change('ordinary_air_heat_balance/predictor_corrector/lifecycle/input.rs',
       'mod thermostat;\n', 'mod thermostat;\nmod current;\n')
change('ordinary_air_heat_balance/predictor_corrector/lifecycle/input.rs',
       '        if self.controls.number_temperature_zones > 0 {\n'
       '            return Err(Error::Unavailable("positive thermostat ActualZoneNum3303"));\n'
       '        }\n',
       '        self.calculate_source_current_temperature_controls(owners)?;\n')
change('ordinary_air_heat_balance/predictor_corrector/lifecycle/input.rs',
       '        // Genuine OverrideAirSetPointsforEMSCntrl6470 loops same actual control count.\n'
       '        if self.controls.number_temperature_zones > 0 {\n'
       '            return Err(Error::Unavailable("positive thermostat EMS override6471"));\n'
       '        }\n',
       '        self.override_source_air_setpoints_for_ems(owners)?;\n')

environment = r'''        for number in 1..=self.controls.number_temperature_zones {
            let row = self.controls.temperature_controlled_zones.as_ref()
                .and_then(|rows| rows.get(index(number).ok()?))
                .ok_or(Error::Unavailable("actual Init TempControlledZone2682"))?;
            if *owners.equipment.source_equipment_inputs_filled() && !self.flags.controlled_zones_checked {
                if !owners.equipment.verify_source_controlled_zone_for_thermostat(&row.zone_name) {
                    return Err(Error::Unavailable("actual uncontrolled thermostat ShowSevereError2685"));
                }
            }
            if row.manage_demand {
                let at = index(row.actual_zone_number)?;
                let setpoint = owners.fan.thermostat.zone_tstat_setpoints.as_mut()
                    .and_then(|rows| rows.get_mut(at))
                    .ok_or(Error::Unavailable("actual demand zoneTstatSetpts2697"))?;
                let mode = *owners.fan.thermostat.temp_control_type.as_ref()
                    .and_then(|rows| rows.get(at))
                    .ok_or(Error::Unavailable("actual demand TempControlType2699"))?;
                match mode {
                    1 => {
                        if setpoint.setpt > row.heating_reset_limit {
                            setpoint.setpt = row.heating_reset_limit;
                            setpoint.setpt_lo = row.heating_reset_limit;
                        }
                    }
                    2 => {
                        if setpoint.setpt < row.cooling_reset_limit {
                            setpoint.setpt = row.cooling_reset_limit;
                            setpoint.setpt_hi = row.cooling_reset_limit;
                        }
                    }
                    3 => {
                        if setpoint.setpt > row.heating_reset_limit || setpoint.setpt < row.cooling_reset_limit {
                            *owners.fan.thermostat.temp_control_type.as_mut().and_then(|rows| rows.get_mut(at))
                                .ok_or(Error::Unavailable("actual demand TempControlType2715"))? = 4;
                            *owners.fan.thermostat.temp_control_type_report.as_mut().and_then(|rows| rows.get_mut(at))
                                .ok_or(Error::Unavailable("actual demand TempControlTypeRpt2716"))? = 4;
                            setpoint.setpt_lo = setpoint.setpt;
                            setpoint.setpt_hi = setpoint.setpt;
                            if setpoint.setpt_lo > row.heating_reset_limit { setpoint.setpt_lo = row.heating_reset_limit; }
                            if setpoint.setpt_hi < row.cooling_reset_limit { setpoint.setpt_hi = row.cooling_reset_limit; }
                        }
                    }
                    4 => {
                        if setpoint.setpt_lo > row.heating_reset_limit { setpoint.setpt_lo = row.heating_reset_limit; }
                        if setpoint.setpt_hi < row.cooling_reset_limit { setpoint.setpt_hi = row.cooling_reset_limit; }
                    }
                    _ => {},
                }
            }
        }
'''
change('ordinary_air_heat_balance/predictor_corrector/lifecycle/environment.rs',
       '        if self.controls.number_temperature_zones > 0 {\n'
       '            return Err(Error::Unavailable("positive actual TempControlledZone2700"));\n'
       '        }\n', environment)
change('ordinary_air_heat_balance/predictor_corrector/lifecycle/environment.rs',
       '//! Exact environment/day and zero-control InitZoneAirSetPoints suffix.\n',
       '//! Native environment/day initialization and regular thermostat demand controls.\n')
print('Authored11 isolated Source19 successors directly on accepted17; no18 joins.')

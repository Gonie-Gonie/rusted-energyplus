"""Root-only canonical11 publication template; never run before real receipts.

Requires actual canonical check, accepted A24 checker and independent promotion
review. No Cargo/test/Native/Git mutations or gates. Finite archive: changed
Source bodies, exact custody, direct reviews and actual A24 artifacts, without
recursively copying prior checkpoint archives or diagnostic observer ancestry.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, zipfile

R=Path(__file__).resolve().parents[3]; D=R/'.runtime/porting/SRC-06'
READY=D/'canonical-source82-activation-publication-prepared-Audit-11'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-completed-source-activation-11'
BACK=D/'canonical-completed-source-publication-Audit-11'
MANIFEST_SHA='40a16bb8e3fe5b5bbf62c6d00f4b3cbf3cad56ab3bf165996b89b5b7328ac274'
PEER_SHA='605b6956dd9bad742d65393c1f1b982f262a7cf9d40a4ad5fdb2e2f96beb3a4a'

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def ref(p):
 p=p.resolve(); return dict(path=p.relative_to(R.resolve()).as_posix(),sha256=digest(p),bytes=p.stat().st_size)
def checked(v,base=R):
 p=(base/v['path']).resolve(); p.relative_to(R.resolve())
 assert digest(p)==v['sha256'] and p.stat().st_size==v.get('bytes',v.get('size_bytes',p.stat().st_size)),v['path']
 return p
def load(p): return json.loads(p.read_bytes())
def accepted(p):
 v=load(p); assert v.get('accepted') is True and v.get('findings')==[],p; return v
def command(v): return v['command'] if isinstance(v['command'],list) else v['command'].split()
def compiler_paths():
 q=subprocess.run(['rg','--files','--hidden','--no-ignore','-g','*.rs','-g','Cargo.toml','crates'],cwd=R,capture_output=True,check=True)
 return {n.replace('\\','/') for n in q.stdout.decode().splitlines()}|{n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (R/n).is_file()}

def main(args):
 assert args.publish and not PUBLIC.exists() and not BACK.exists()
 draftp=READY/'publication-template.json'; draft=load(draftp)
 assert draft['status']=='HELD_TEMPLATE_NO_CANONICAL_ACTUAL_CLAIM'
 mp=checked(draft['prepared_promotion']); assert digest(mp)==MANIFEST_SHA; m=load(mp)
 peerp=checked(draft['independent_promotion_review']); assert digest(peerp)==PEER_SHA
 peer=accepted(peerp); assert peer['manifest']==ref(mp)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(); assert head==m['base_HEAD']
 vp=(R/args.validation_refs).resolve(); vp.relative_to(R.resolve()); validation=load(vp)
 assert set(validation)=={'canonical_check','canonical_A24_review','independent_promotion_review','additional_case_reviews'}
 assert validation['independent_promotion_review']==ref(peerp)
 cp=checked(validation['canonical_check']); check=load(cp)
 ap=checked(validation['canonical_A24_review']); a=accepted(ap)
 assert a['canonical_prepared_manifest']==ref(mp) and a['complete_final_compiler_plan']==m['complete_final_compiler_Source_plan']
 assert a['actual_check']==ref(cp) and a['all4472_compiled_archived_live_planned_inputs_exact'] is True
 assert (a['Rust_sources'],a['selected_canonical_files'],a['JSON_CSV_scalar_roundtrips'])==(4459,10,5352)
 assert (a['full_table_lines'],a['exact_Native_table_lines'],a['metadata_difference_lines'],a['HTML_named_tables'])==(19312,19242,70,191)
 assert a['report_diagnostics_child_absent'] is True and a['all_six_nonselected_diagnostic_paths_whole_main_or_absent'] is True
 assert a['legacy_result_artifact_keys_and_files_absent'] is True and a['results_directory_contains_exact_three_Source_files'] is True
 cli_p=checked(a['actual_CLI']); cli=load(cli_p)
 assert check['exit_code']==cli['exit_code']==0 and check['launch_error'] is None and cli['launch_error'] is None
 for v in [check,cli]:
  assert Path(v['cwd']).resolve()==R.resolve() and v['source_bytes_match_before_and_after']
 assert check['source_snapshot']==cli['source_snapshot']
 assert '--workspace' in command(check) and '--all-targets' in command(check)
 cc=command(cli); assert cc[cc.index('--porting-scope')+1]=='A' and '--oracle-baseline' not in cc and '--compare-oracle' not in cc
 rootreview=accepted(checked(a['accepted_canonical_promotion_review'])); assert rootreview['manifest']==ref(mp)
 plan=load(checked(m['complete_final_compiler_Source_plan'])); idx={x['path']:x for x in plan['entries']}
 assert len(idx)==4472 and sum(n.endswith('.rs') for n in idx)==4459 and compiler_paths()==set(idx)
 snapshot=load(checked(check['source_snapshot'],Path(check['cwd']))); observed={x['historical_path']:x for x in snapshot['files']}
 assert set(observed)==set(idx)
 for n,x in idx.items():
  p=R/n; assert digest(p)==x['final_sha256'] and p.stat().st_size==x['final_bytes']
  assert digest(checked(observed[n]['archive'],R))==x['final_sha256']
 for x in plan['excluded']: assert not (R/x['path']).exists()
 for row in m['files']: assert (R/row['canonical_path']).read_bytes()==checked(row['proposed']).read_bytes()
 additional=[]
 for extra in validation['additional_case_reviews']:
  assert set(extra)=={'case_id','review'} and extra['case_id']!='A-24H'
  v=accepted(checked(extra['review'])); assert v['canonical_prepared_manifest']==ref(mp)
  additional.append(extra)
 assert len({x['case_id'] for x in additional})==len(additional)
 tol=load(checked(draft['original_A24_tolerance_audit'])); tp=accepted(checked(draft['independent_tolerance_review']))
 assert tp['manifest']==draft['original_A24_tolerance_audit'] and tol['policy_changes']==0 and tol['full15matrix_complete'] is False
 assert a['prior_operational_A24_tolerance_audit']==draft['original_A24_tolerance_audit']
 assert a['prior_independent_tolerance_peer']==draft['independent_tolerance_review']
 assert a['unchanged_original_tolerance_policy']==tol['policy']
 previous=load(checked(draft['previous_checkpoint'])); assert (previous['A'],previous['B'])==('14/54','14/64')
 names=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']; base=R/'energyplus_porting_plan'
 docs={n:(base/n).read_bytes() for n in names}; planp=base/'plan.json'; before=planp.read_bytes(); beforev=json.loads(before)
 for n,b in docs.items():
  assert b==subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+n],cwd=R)
  assert '\ufffd' not in b.decode('utf8','strict')
 assert before==subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)

 # Collect only finite direct evidence. Actual A24 physical/export operands and
 # sample ledger are retained; larger later-case evidence stays in its own
 # accepted checkpoint instead of recursively duplicating it here.
 files={}
 def add(p):
  p=p.resolve(); r=ref(p); n=r['path']
  assert n not in files or files[n]['ref']==r
  files[n]=dict(path=p,ref=r); return r
 def addref(r,base=R): return add(checked(r,base))
 for r in draft['finite_archive_inputs']: addref(r)
 for p in [Path(__file__),draftp,vp,cp,cli_p,ap,peerp]: add(p)
 for r in [a['accepted_canonical_promotion_review'],a['all5352_raw_tokens_bits_native_tuples_indices_and_physical_lines'],a['complete_metadata_differences'],a['reported_bundle'],a['run_summary'],a['diagnostics']]: addref(r)
 if 'author_Source' in a: addref(a['author_Source'])
 for v,p in [(check,cp),(cli,cli_p)]:
  add(p)
  for k in ['stdout','stderr','source_snapshot']: addref(v[k],Path(v['cwd']))
 for r in a['streams']:
  for k in ['physical','CSV']: addref(r[k])
 for r in a['full_tables']: addref(r['canonical11'])
 for r in a['canonical11_physical_streams_whole82_and79_equal']: addref(r['canonical11'])
 output=Path(cc[cc.index('--output-dir')+1]).resolve(); output.relative_to(D.resolve())
 for n in ['eplusrs.rdd','eplusrs.mdd','eplusrs.err','eplusrs.ctf.log']: add(output/n)
 for n in a['diagnostic_sidecar_and_two_snapshots_absent']: assert not (output/n).exists()
 for row in m['files']: add(R/row['canonical_path'])
 for x in additional: addref(x['review'])
 PUBLIC.mkdir(parents=True); BACK.mkdir(); (BACK/'plan-before.json').write_bytes(before)
 for n,b in docs.items():
  p=BACK/'docs-before'/n; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
 zp=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,r in sorted(files.items()):
   assert ref(r['path'])==r['ref']; z.write(r['path'],arcname=n)
 with zipfile.ZipFile(zp) as z:
  assert z.testzip() is None and set(z.namelist())==set(files)
  for n,r in files.items():
   h=hashlib.sha256(); total=0
   with z.open(n) as f:
    for b in iter(lambda:f.read(1024*1024),b''): h.update(b); total+=len(b)
   assert h.hexdigest()==r['ref']['sha256'] and total==r['ref']['bytes']
 inventory=PUBLIC/'manifest.json'
 inventory.write_bytes((json.dumps(dict(schema='src06-canonical11-finite-evidence-archive.v1',archive=ref(zp),entries=[r['ref'] for n,r in sorted(files.items())],scope='Finite changed Source bodies, before/proposed/parent/diffs, direct custody/reviews, actual canonical A24 receipts/logs/snapshot index and own physical/export operands. Unchanged compiler bodies are bound by complete4472 plan, actual archived-source equality and pinned base Git. Historical checkpoint ZIPs, observer sidecars and large later-case output bundles are not recopied.',full_transitive_rebuild_archive_claim=False),indent=2)+'\n').encode())
 summary=dict(draft['summary_template'])
 summary.update(schema='src06-canonical-completed-source-activation.v1',status='Canonical explicit Source activation and own complete reported-result export; bounded actual A24 validated',base_HEAD=head,canonical_A24_completed_Source_run=True,canonical_A24_reported_serialization_roundtrip=True,canonical_A24_original_named_tolerance_and_RMSE_PASS=True,production_explicit_scope_activation=True,canonical_check=ref(cp),canonical_A24_CLI=ref(cli_p),canonical_A24_independent_review=ref(ap),additional_accepted_case_reviews=additional,validation_refs=ref(vp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),author_Source=ref(Path(__file__)))
 sp=PUBLIC/'summary.json'; sp.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 paragraph=('명시한 `--porting-scope A/B` 실행을 실제 Source 경로에 연결했습니다. 같은 상태 소유자로 초기화·본 실행·종료 620을 거친 뒤 완성된 ESO/MTR만 읽고, 보고 ID·빈도·저장 방식·원문 값·Native 시간 튜플을 JSON/CSV로 보존합니다. '
  '정식 A-24H 실행과 전체 대상 컴파일이 성공했고, 58계열 5,352개 값의 물리 출력·JSON·CSV 일치를 검증했습니다. 보고값 차이 3,536개는 변경하지 않은 기존 허용오차와 계열별 RMSE 한계 안에 있습니다. '
  '기본 실행 경로는 보존하며, B는 처음 만나는 미구현 입력·분기에서 오류로 중단합니다. 진단 관측 파일은 배포 경로에서 제외했습니다. '
  '추가 기간·B 사례·전체 포팅 게이트는 이 A-24H 검증으로 완료 처리하지 않습니다. A14/54·B14/64와 기존 전체 비교 기록은 유지합니다.')
 rel='evidence/SRC-06-canonical-completed-source-activation-11/summary.json'
 for n,b in docs.items():
  p=base/n; assert p.read_bytes()==b; link='../'+rel if n.startswith('cards/') else rel
  p.write_bytes(b+('\n\n[Source 실행·결과 내보내기 검증]('+link+'). '+paragraph+'\n').encode())
 after=json.loads(before); task=next(x for x in after['tasks'] if x['id']=='SRC-06'); key='canonical_completed_source_activation_11'; assert key not in task
 task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=digest(sp),size_bytes=sp.stat().st_size)
 inverse=json.loads(json.dumps(after)); del next(x for x in inverse['tasks'] if x['id']=='SRC-06')[key]; assert inverse==beforev
 assert planp.read_bytes()==before; planp.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_INDEPENDENT_READBACK',summary=ref(sp),archive=ref(zp),archive_manifest=ref(inventory),archive_entries=len(files),canonical_check=ref(cp),canonical_A24_independent_review=ref(ap),base_HEAD=head,publisher=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),Git_mutated=False,Cargo_tests_Native_executed=False,gate_changes=False)
 rp=BACK/'publication-readback.json'; rp.write_bytes((json.dumps(result,indent=2)+'\n').encode()); print(json.dumps(ref(rp)))

if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--validation-refs',required=True); p.add_argument('--publish',action='store_true'); main(p.parse_args())

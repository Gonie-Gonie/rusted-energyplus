"""Independent read-only canonical11 Source/identity/dispatch peer. Never applies."""
from pathlib import Path
import ast, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
O=D/'Audit-canonical-source82-completed-activation-Source-review-01'
M=D/'canonical-source82-completed-activation-prepared-Outer-11/manifest.json'
assert not O.exists()
def ref(p):
    b=p.read_bytes(); return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(r):
    p=R/r['path']; assert ref(p)==r,r; return p.read_bytes()
def doc(r): return json.loads(load(r))
def run(a): return subprocess.run(a,cwd=R,capture_output=True)
def must(a):
    q=run(a); assert q.returncode==0,(a,q.stderr); return q.stdout
def sha(b): return hashlib.sha256(b).hexdigest()
def replace1(b,x,y):
    assert b.count(x)==1,(x[:120],b.count(x)); return b.replace(x,y,1)
def apply(a,d):
    """Apply every complete unified hunk, checking old coordinate and all bytes."""
    if not d: return a
    lines=d.splitlines(True); assert lines[0].startswith(b'--- ') and lines[1].startswith(b'+++ ')
    old=a.splitlines(True); out=[]; i=0; j=2
    while j<len(lines):
        h=re.fullmatch(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\r\n]*\r?\n',lines[j]); assert h,lines[j]
        pos=int(h[1])-1 if int(h[2] or b'1') else int(h[1]); assert pos>=i
        out.extend(old[i:pos]); i=pos; consumed=produced=0; j+=1
        while j<len(lines) and not lines[j].startswith(b'@@ '):
            row=lines[j]; mark=row[:1]; body=row[1:]
            assert mark in (b' ',b'-',b'+'),row
            if mark in (b' ',b'-'): assert i<len(old) and old[i]==body,(i,row); i+=1; consumed+=1
            if mark in (b' ',b'+'): out.append(body); produced+=1
            j+=1
        assert consumed==int(h[2] or b'1') and produced==int(h[4] or b'1')
    out.extend(old[i:]); return b''.join(out)

assert ref(M)['sha256']=='40a16bb8e3fe5b5bbf62c6d00f4b3cbf3cad56ab3bf165996b89b5b7328ac274'
m=json.loads(M.read_bytes()); H='05d8abddb0da6ffdfe237031dd128277d37edeb2'
assert m['base_HEAD']==H and must(['git','rev-parse','HEAD']).decode().strip()==H
assert not must(['git','status','--porcelain','--untracked-files=no'])
plan=doc(m['scope_plan']); checks=doc(m['checks']); full=doc(m['complete_final_compiler_Source_plan'])
actual=doc(m['accepted_actual82']); fm=doc(m['accepted_actual82_manifest']); census=doc(fm['compiler_Source_census'])
assert actual['accepted'] and actual['Source_CLI_exit_code']==0
assert actual['actual_Source_endrun620_and_strict_result_export_completed'] and actual['own_JSON_CSV_raw_token_timestamp_bits_roundtrips']==5352
assert ref(R/m['accepted_actual82']['path'])['sha256']=='3b9966785160ec62cd1de1d63d8d0008b812c884ec8c7b439af5139acedb0ca7'
assert actual['manifest']==m['accepted_actual82_manifest']==full['parent82_manifest']
assert full['parent82_census']==fm['compiler_Source_census']
for key in ['accepted_own_file_export_readback','accepted_tolerance_audit','accepted_tolerance_peer','integration_contract','author_Source','guarded_apply_Source']: load(m[key])
for key in ['manifest','actual_check','actual_CLI','independent_own_file_export_readback','unchanged_original_A24_reported_numeric_tolerance_audit','independent_tolerance_peer']: load(actual[key])
for key in ['draft_checks','draft_author','draft_input_inventory_author']: load(checks[key])
for key in ['frozen81','diagnostic_packet','earlier_predefined_observer','earlier_statistics_observer','accepted_reader','accepted_path_accessor']: load(plan['ancestry'][key])

U='crates/ep_run/src/'; HB='crates/ep_runtime/src/heat_balance/'
PIPE=U+'pipeline.rs'; CTF=U+'ctf_initialization_outputs.rs'; FILES=HB+'source_initialization/files.rs'
paths={HB+'mod.rs',U+'lib.rs',HB+'source_reported_catalog.rs',U+'source_reported_results.rs',U+'source_reported_results/parser.rs',U+'source_reported_results/export.rs',PIPE,CTF,FILES,U+'pipeline/source_outcome.rs'}
rows={r['canonical_path']:r for r in m['files']}; assert set(rows)==paths and len(rows)==10
before={}; parent={}; new={}; gitproof=[]; applications=[]
for name,r in rows.items():
    b=load(r['before']); p=load(r['parent_before']); n=load(r['proposed'])
    assert load(r['parent_source82'])==p and load(r['literal_inverse'])==b and load(r['literal_parent_inverse'])==p
    q=run(['git','show',H+':'+name]); assert q.returncode==(128 if r['canonical_absent_observed'] else 0) and q.stdout==b
    assert ((R/name).read_bytes() if (R/name).exists() else b'')==b
    assert (not (R/name).exists())==r['canonical_absent_observed']
    for role,x,y in [('complete_forward_diff',b,n),('complete_inverse_diff',n,b),('parent_forward_diff',p,n),('parent_inverse_diff',n,p)]:
        assert apply(x,load(r[role]))==y; applications.append(dict(path=name,role=role,whole_equal=True))
    before[name]=b; parent[name]=p; new[name]=n
    gitproof.append(dict(path=name,revision=H,exit_code=q.returncode,whole_bytes=len(b),sha256=sha(b),whole_equal=True))
assert len(applications)==40 and sum(r['canonical_absent_observed'] for r in rows.values())==5

# Independently reconstruct the entire compiler-input projection from accepted82.
W=R/fm['workspace']; source82={r['path']:r for r in census['files']}
entries={r['path']:r for r in full['entries']}; assert len(source82)==4473 and len(entries)==4472
diag={r['path']:r for r in plan['quarantine']['other_six_whole_preservations']}
assert len(diag)==6 and len(plan['quarantine']['all_nine_diagnostic_paths'])==9
rehashed=[]; excluded=[]; differing=[]; existing_rust=[]
for name,r in sorted(source82.items()):
    p=(W/name).read_bytes(); assert sha(p)==r['assembled82_sha256'] and len(p)==r['bytes82'],name
    if name in rows: assert parent[name]==p,name
    curpath=R/name; c=curpath.read_bytes() if curpath.exists() else None
    if name in diag and diag[name]['canonical_absent']:
        assert c is None and name not in entries; excluded.append(name); continue
    e=entries[name]; assert e['parent82_sha256']==sha(p) and e['parent82_bytes']==len(p)
    assert e['current_main_sha256']==(sha(c) if c is not None else None)
    assert e['current_main_bytes']==(len(c) if c is not None else None)
    if name in rows:
        assert (c if c is not None else b'')==before[name]; final=new[name]
        assert load(e['final_proposed'])==final
    elif name in diag:
        assert c==load(diag[name]['canonical']); final=c
    else:
        assert p==c,name; final=c
    assert sha(final)==e['final_sha256'] and len(final)==e['final_bytes'],name
    if c!=p: differing.append(name)
    if c is not None and name.endswith('.rs'): existing_rust.append(name)
    rehashed.append(dict(path=name,current_sha256=sha(c) if c is not None else None,parent82_sha256=sha(p),final_sha256=sha(final),final_bytes=len(final)))
assert len(excluded)==1 and excluded[0]==HB+'source_output_registration/report_diagnostics.rs'
assert [r['path'] for r in full['excluded']]==excluded
assert sorted(differing)==sorted(full['current_vs_parent82_differing_paths'])
inventory=set(must(['rg','--files','crates','--glob','*.rs']).decode().replace('\\','/').splitlines())
assert inventory==set(existing_rust) and len(inventory)==4454
assert sum(n.endswith('.rs') for n in entries)==4459
assert len(rehashed)==full['final_inputs']==4472 and full['final_Rust_sources']==4459
# All non-Rust crate manifests/build inputs and root Cargo/config inputs are
# included in the frozen compiler input domain; no unknown new .rs is omitted.
nonrust=sorted(n for n in entries if not n.endswith('.rs')); assert len(nonrust)==13

# Exact authenticated observer subtraction; no broad file cleanup.
stripped=dict(parent); removed=[]
for s in plan['ancestry']['exact_observer_removal_spans']:
    fragment=load(s['literal']); name=s['path']; stripped[name]=replace1(stripped[name],fragment,b''); removed.append(s)
assert len(removed)==8 and {n:sum(s['literal']['bytes'] for s in removed if s['path']==n) for n in [PIPE,CTF,FILES]}=={PIPE:1612,CTF:4848,FILES:1164}
assert stripped[CTF]==new[CTF] and stripped[FILES]==new[FILES]
assert replace1(new[CTF],load(plan['ancestry']['accepted_reader']),b'')==before[CTF]
assert replace1(new[FILES],load(plan['ancestry']['accepted_path_accessor']),b'')==before[FILES]
assert all(new[n]==parent[n] for n in paths-{PIPE,CTF,FILES})
assert new[CTF].split(b'#[cfg(test)]',1)[1]==before[CTF].split(b'#[cfg(test)]',1)[1]
assert b'if cfg!(windows) { "\\r\\n" } else { "\\n" }' in new[CTF]
for name,b in new.items():
    assert b.count(b'#[test]')==before[name].count(b'#[test]')
    for marker in [b'enable_source_report_binary64_diagnostic',b'persist_source_report_binary64_diagnostic',b'source-report-binary64.csv',b'source-input-statistics-observation.v1',b'source-predefined-table-observation.v1',b'report_diagnostics:']:
        assert marker not in b,(name,marker)

# None inverse is checked against the original whole preparation and complete
# execution startup, not only selected lines or the author's boolean claims.
c=before[PIPE].decode(); n=new[PIPE].decode(); p=stripped[PIPE].decode()
def span(s,a,b):
    i=s.index(a); return s[i:s.index(b,i)]
prep=span(n,'fn prepare_runtime_inputs(','fn execute_rust_runtime(')
oldprep=span(c,'fn prepare_runtime_inputs(','fn execute_rust_runtime(')
gate_start=prep.index('    // The already-admitted CLI scope selects Source explicitly.')
gate_end=prep.index('    let model = simulation_model',gate_start)
gate=prep[gate_start:gate_end]
assert '(None, _)' in gate and '(Some(crate::PortingScope::A), RuntimeClass::OneZoneHeatBalanceCompatibility)' in gate
assert '(Some(crate::PortingScope::B), RuntimeClass::IdealLoadsDirectZoneCoupledCompatibility)' in gate
assert 'return Err(format!(' in gate and 'scope.is_some();' in gate
project=replace1(prep,gate,'')
project=replace1(project,'    scope: Option<crate::PortingScope>,\n','')
assert project.count('source_initialization_required')==7
project=project.replace('source_initialization_required','runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility')
project=replace1(project,'if scope.is_none()\n                && runtime_class == RuntimeClass::IdealLoadsDirectZoneCoupledCompatibility','if runtime_class\n                == RuntimeClass::IdealLoadsDirectZoneCoupledCompatibility')
assert project==oldprep
assert prep.count('crate::ordinary_input_processor::resolve(raw_model)?')==1
assert prep.index('if source_initialization_required {\n                pending_ordinary_weather') < prep.index('let zone_timestep_schedule_cache = if scope.is_none()')
execute=span(n,'fn execute_rust_runtime(','    let cache = runtime_inputs')
oldexecute=span(c,'fn execute_rust_runtime(','    let cache = runtime_inputs')
body_start=execute.index('            if scope.is_some() {\n')
body_end=execute.index('            }\n            let weather =',body_start)+len('            }\n')
branch=execute[body_start:body_end]
project=replace1(execute,branch,'')
project=replace1(project,'    if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility || scope.is_some() {','    if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility {')
project=replace1(project,'    requested_hours: Option<usize>,\n    scope: Option<crate::PortingScope>,\n','')
project=replace1(project,') -> Result<RuntimeExecutionOutcome, String> {',') -> Result<RustRuntimeResult, String> {')
assert project==oldexecute
order=['initialize_unopened_source_weather','runtime_inputs.weather_series = Some(weather)','source_simulation_through_primary','source_simulation_endrun_prefix','source_reported_run_scope','validate_requested_hours','read_completed_source_reports()?','return Ok(RuntimeExecutionOutcome::Source']
positions=[branch.index(x) for x in order]; assert positions==sorted(positions)
dedent=''.join(line[4:] if line.strip() else line for line in branch.splitlines(True)[1:-1])
dedent=replace1(dedent,'            // Explicit porting runs use the same real Source owners through\n            // primary, complete endrun and the completed own-file reader.\n','            // HELD diagnostic Source continuation: completion after Native564\n            // still requires the genuine endrun and completed result exporter.\n')
parent_start=p.index('            // HELD diagnostic Source continuation:',p.index('fn execute_rust_runtime('))
parent_end=p.index('            })));\n',parent_start)+len('            })));\n')
assert dedent==p[parent_start:parent_end]
assert n.count('prepare_runtime_inputs(')==2 and n.count('execute_rust_runtime(')==2
assert '                    &raw_model,\n                    scope,\n' in n
assert '                            config.hours,\n                            scope,\n' in n

# Existing four legacy scientific payloads and fixture, entire huge legacy JSON
# payload and all unmodified public/helper functions retain canonical bytes.
ns={'re':re}
helper=D/'review-source-result-connector-Outer-02.py'
for node in ast.parse(helper.read_text(encoding='utf8')).body:
    if isinstance(node,ast.FunctionDef) and node.name in ['masked','expressions']:
        exec(compile(ast.Module([node],type_ignores=[]),'<bounded-Rust-expression-scanner>','exec'),ns)
assert ns['expressions'](c)==ns['expressions'](n) and len(ns['expressions'](c))==5
legacy_c=span(c,'            "runtime_class": result.runtime_class.id(),','        })),\n        "source_order_gate"')
legacy_n=span(n,'            "runtime_class": result.runtime_class.id(),','        }),\n            RuntimeExecutionOutcome::Source(result)')
assert legacy_c==legacy_n
# Whole unmodified functions and public type declarations are recovered via
# balanced braces using the same comment/string-masked source scanner.
def item(s,pattern):
    masked=ns['masked'](s); match=re.search(pattern,masked); assert match,pattern
    a=masked.index('{',match.start()); depth=1; i=a+1
    while depth:
        depth += (masked[i]=='{')-(masked[i]=='}'); i+=1
    return s[match.start():i]
preserved=[]
assert U+'config.rs' in entries and U+'config.rs' not in paths
for pat in [r'pub struct RunOutcome\b',r'struct RustRuntimeResult\b',r'fn artifact_map\(',r'fn write_runtime_artifacts\(',r'fn validate_runtime_demand_provenance\(',r'fn validate_runtime_selection\(',r'fn run_requested_oracle_baseline\(',r'fn compare_with_oracle\(']:
    assert item(c,pat)==item(n,pat),pat; preserved.append(pat)
assert n.index('SourceReportedOracleComparisonUnsupported')<n.index('let should_run_oracle =')
assert n.count('return Ok(RuntimeExecutionOutcome::Source')==1
assert 'if let RuntimeExecutionOutcome::Legacy(legacy) = &result {' in n
assert 'RunExitCode::Unsupported,\n            "Source oracle comparison is unsupported' in n
assert n.count('and_then(RuntimeExecutionOutcome::legacy_results)')==2
assert new[U+'pipeline/source_outcome.rs']==parent[U+'pipeline/source_outcome.rs']
assert b'.as_object_mut().ok_or(SourceArtifactMapError::ExpectedArtifactObject)?' in new[U+'pipeline/source_outcome.rs']
# No new prohibited panic macros or infallible unwrap/expect introduced in this
# promotion: scan all added Rust lines, and all five new whole Rust modules.
for name,r in rows.items():
    added=b'\n'.join(line[1:] for line in load(r['complete_forward_diff']).splitlines() if line.startswith(b'+') and not line.startswith(b'+++'))
    assert not re.search(rb'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)\s*!',added),name

# Pure inspection of Root-only guarded apply (it is not invoked here).
apply_bytes=load(m['guarded_apply_Source']); apply_text=apply_bytes.decode(); tree=ast.parse(apply_text)
allow=None
for node in tree.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CANONICAL' for t in node.targets): allow=ast.literal_eval(node.value)
assert allow==paths
for guard in ["digest(manifest_bytes)!=args.expect_manifest_sha","digest(peerbytes)!=args.expect_peer_sha","peer.get('accepted') is not True","peer.get('manifest')!=mr","peer.get('findings')","actual.get('Source_CLI_exit_code')!=0","actual.get('own_JSON_CSV_raw_token_timestamp_bits_roundtrips')!=5352","git(['rev-parse','HEAD'])","git(['status','--porcelain','--untracked-files=no'])","len(inputs['entries'])!=4472","inputs['final_Rust_sources']!=4459","target.relative_to(ROOT.resolve())","digest(b)!=r['current_main_sha256']","digest(b)!=r['final_sha256']","if args.apply:","os.replace(temp_path,target)"]:
    assert guard in apply_text,guard
assert not m['guarded_apply_executed'] and not m['new_candidate_Cargo_Native_or_tests_executed']
assert not m['B_completion_claim'] and not m['numerical_or_full15_gate_claim']

# Fresh independent Source-only parses, immutable inputs; no Cargo/check/tests.
parse=[]
for name in sorted(paths):
    q=run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout',str(R/rows[name]['proposed']['path'])])
    assert q.returncode==0,(name,q.stderr)
    assert load(rows[name]['proposed'])==new[name]
    parse.append(dict(path=name,exit_code=0,stdout_sha256=sha(q.stdout),stdout_bytes=len(q.stdout),stderr_sha256=sha(q.stderr),stderr_bytes=len(q.stderr),sealed_input_unchanged=True))
assert must(['git','rev-parse','HEAD']).decode().strip()==H and not must(['git','status','--porcelain','--untracked-files=no'])
assert ref(M)['sha256']=='40a16bb8e3fe5b5bbf62c6d00f4b3cbf3cad56ab3bf165996b89b5b7328ac274'
O.mkdir()
def put(name,obj):
    p=O/name; assert not p.exists(); p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8'); return ref(p)
inventory_ref=put('independent-input-plan.json',dict(parent82_inputs_rehashed=4473,final_inputs=4472,final_Rust_sources=4459,current_main_Rust_sources=4454,nonRust_inputs=nonrust,excluded=excluded,entries=rehashed))
review=put('review.json',dict(schema='src06-independent-canonical11-source-activation-peer.v1',accepted=True,manifest=ref(M),findings=[],reviewer_Source=ref(Path(__file__).resolve()),base_HEAD=H,accepted_actual82=m['accepted_actual82'],accepted_predecessor_only=True,compiler_input_plan=m['complete_final_compiler_Source_plan'],independent_compiler_plan=inventory_ref,whole_Source_files=10,whole_parent82_files_rehashed=4473,final_compiler_inputs=4472,final_Rust_sources=4459,literal_applications=applications,actual_Git_before_proofs=gitproof,Source_only_parses=parse,observer_removals=removed,all_nine_diagnostic_paths_quarantined=True,whole_CTF_reader_and_files_accessor_inverse_to_canonical10=True,whole_CTF_test_section_preserved=True,whole_None_preparation_inverse=True,whole_None_execution_startup_inverse=True,Some_continuation_whole_equal_accepted82_except_comment=True,Some_actual_owner_sequence=order,scope_class_checks=['None: original runtime class unchanged','SomeA: OneZoneHeatBalanceCompatibility','SomeB: IdealLoadsDirectZoneCoupledCompatibility'],seven_Source_preparation_guards_and_B_eager_cache_bypass=True,legacy_scientific_constructor_expressions_and_fixture_whole_equal=5,legacy_summary_payload_whole_equal=True,whole_preserved_public_types_and_helpers=preserved,public_API_and_support_policy_unchanged=True,source_errors_propagate_no_fallback=True,after620_same_files_catalog_read=True,typed_Source_artifact_map_preserved=True,Source_oracle_flags_explicit_Unsupported_after_export=True,guarded_apply_allowlist_and_custody_and_before_after_scope_read_only_reviewed=True,guarded_apply_executed=False,canonical_mutations=0,Cargo_Native_or_tests_executed=False,new_test_bodies=0,qualifications=['Acceptance is bounded to this exact held conditional Source promotion and its authenticated accepted82 predecessor. Fresh canonical compiler/lint/actual command receipts remain Root work.','Explicit SomeA/B selects Source only after unchanged support admission; SomeB is expected to stop honestly at its first unported positive raw input or Native boundary. This review does not claim any SourceB execution or full15 completion.','The original early TimeAxis/plan preflight remains metadata, not an actual Native caller trace. Some requested hours must equal full real selected environment scope; no truncation or frequency collapse.','Source reported raw files are the value boundary; no unreported internal history or civil year is reconstructed. Existing comparison/tolerance audit remains bounded to completedA24.','Only authenticated observer spans are removed. All numeric/control/getter/reporting implementations otherwise retain the accepted82 whole bytes. None default behavior and existing tests retain the exact checked projections.']))
print(json.dumps(review))

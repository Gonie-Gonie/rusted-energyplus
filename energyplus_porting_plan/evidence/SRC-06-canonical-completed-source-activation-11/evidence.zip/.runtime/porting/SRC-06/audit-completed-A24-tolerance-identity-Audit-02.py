from pathlib import Path
import hashlib,json,math,re,struct,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'completed-A24-tolerance-identity-audit-Audit-02';assert not O.exists()
def ref(p):
 z=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(z).hexdigest(),bytes=len(z))
def get(d):
 p=R/d['path'];r=ref(p);assert all(r[k]==v for k,v in d.items() if k in r),(d,r);return p
def read(p):return json.loads(p.read_bytes())
def bits(v):return struct.pack('>d',v).hex()
policy_path=R/'energyplus_porting_plan/contracts/output-tolerances.json';policy=read(policy_path)
assert policy['schema_version']=='con01-output-tolerances.v2' and all(x['rtol']==0 for rows in policy['profiles'].values() for x in rows)
scope_path=R/'energyplus_porting_plan/contracts/scope.json';scope=read(scope_path);cases={x['id']:x for x in scope['cases']};assert len(cases)==15
case_a=cases['A-24H'];metadata=read(get(case_a['metadata']));get(case_a['input']);get(case_a['weather'])
native_receipt=B/'native-installed-A-24H-command-Root-67/receipt.json';nr=read(native_receipt);assert nr['exit_code']==0 and nr['launch_error'] is None
revision=nr['repository_before']['head'];historical=subprocess.check_output(['git','show',revision+':'+policy_path.relative_to(R).as_posix()]);assert historical==policy_path.read_bytes()
assert str(get(case_a['input']).resolve()).replace('\\','/') in nr['command'] and str(get(case_a['weather']).resolve()).replace('\\','/') in nr['command']
source_receipt=B/'ordinary-provider-assembly-Root-79/workspace/.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-79/receipt.json';sr=read(source_receipt);assert sr['exit_code']==6 and sr['launch_error'] is None
assert str(get(case_a['input']).resolve()).replace('\\','/') in sr['command'] and str(get(case_a['weather']).resolve()).replace('\\','/') in sr['command']
root_review=B/'Root-ordinary-provider-union79-actual-review-01/review.json';rr=read(root_review);assert rr['accepted'] and rr['actual_endrun620_completed'] and not rr['result_export_complete']
physical=read(get(rr['comparison']));streams={Path(x['Source']['path']).suffix:x for x in physical['streams']};assert {'.eso','.mtr','.eio'}==set(streams)

def parse_completed(path,kind):
 z=path.read_bytes();assert z.endswith(b'\r\n') and z.count(b'\n')==z.count(b'\r\n');lines=z.decode('utf8').split('\r\n');assert lines.pop()==''
 assert lines[0].startswith('Program Version,') and lines.count('End of Data Dictionary')==lines.count('End of Data')==1
 di=lines.index('End of Data Dictionary');en=lines.index('End of Data');assert en==len(lines)-2 and di<en
 footer=re.fullmatch(r' Number of Records Written=\s*(\d+)',lines[-1]);assert footer;footer=int(footer[1])
 dictionary={};declared={};ids=set()
 for line in lines[1:di]:
  p=line.split(',',2);assert len(p)==3;rid,count=int(p[0]),int(p[1]);assert rid>0 and rid not in ids;ids.add(rid);dictionary[rid]=line
  if rid<=6:continue
  if kind=='eso':
   row=re.fullmatch(r'(\d+),(\d+),([^,]*),(.+) \[(.*)\] !(TimeStep|Hourly)',line);assert row,line
   key,name,unit,freq=row[3],row[4],row[5],row[6]
  else:
   row=re.fullmatch(r'(\d+),(\d+),(.+) \[(.*)\] !(TimeStep|Hourly)',line);assert row,line
   key,name,unit,freq=None,row[3],row[4],row[5]
  assert count==1;declared[rid]=dict(report_id=rid,key=key,name=name,units=unit,frequency=freq,kind='variable' if kind=='eso' else 'meter',raw_dictionary=line,samples=[])
 assert set(range(1,7))<=ids
 assert dictionary[1]=='1,5,Environment Title[],Latitude[deg],Longitude[deg],Time Zone[],Elevation[m]'
 assert dictionary[2]=='2,8,Day of Simulation[],Month[],Day of Month[],DST Indicator[1=yes 0=no],Hour[],StartMinute[],EndMinute[],DayType'
 identities=[(d['key'],d['name'],d['units'],d['frequency']) for d in declared.values()];assert len(identities)==len(set(identities))
 environments=[];stamps=[];current=None;env=None;records=0
 for line_no,line in enumerate(lines[di+1:en],di+2):
  rid,payload=line.split(',',1);rid=int(rid);assert rid in ids
  fields=tuple(payload.split(','))
  if rid==1:
   assert len(fields)==5;[float(x) for x in fields[1:]];environments.append(fields);env=len(environments);current=None;continue
  if rid==2:
   assert env is not None and len(fields)==8;[int(x) for x in fields[:5]];[float(x) for x in fields[5:7]];current=(env,fields);stamps.append(current);continue
  assert rid>6 and rid in declared and current is not None and len(fields)==1,(line_no,line)
  d=declared[rid];value=float(fields[0]);assert math.isfinite(value)
  if d['frequency']=='Hourly':assert float(current[1][5])==0.0 and float(current[1][6])==60.0
  records+=1;d['samples'].append(dict(stamp=current,environment=environments[current[0]-1],raw_fields=fields,value=value,line=line_no))
 assert records==footer
 for d in declared.values():
  stamps_for_d=[(x['environment'],x['stamp']) for x in d['samples']];assert stamps_for_d and len(set(stamps_for_d))==len(stamps_for_d)
 return dict(path=ref(path),version_line=lines[0],dictionary=dictionary,series=declared,environments=environments,stamps=stamps,records=records,physical_lines=len(lines))

def rdd(path):
 rows={}
 for line in path.read_text(encoding='utf8').splitlines():
  if line.startswith('!'):continue
  x=re.fullmatch(r'Output:Variable,\*,(.+),hourly; !- (Zone|HVAC) (Average|Sum) \[(.*)\]',line);assert x,line
  identity=(x[1],x[4]);assert identity not in rows,identity;rows[identity]=dict(raw_line=line,timestep_type=x[2],store_type=x[3])
 return rows
source_dir=get(streams['.eso']['Source']).parent;native_dir=get(streams['.eso']['Native']).parent
source_rdd_path=source_dir/'eplusrs.rdd';native_rdd_path=native_dir/'energyplusout.rdd';source_rdd=rdd(source_rdd_path);native_rdd=rdd(native_rdd_path)
source_mdd_path=source_dir/'eplusrs.mdd';native_mdd_path=native_dir/'energyplusout.mdd'
source_mdd=set(source_mdd_path.read_text(encoding='utf8').splitlines());native_mdd=set(native_mdd_path.read_text(encoding='utf8').splitlines())

# Policy binding uses the existing EnergyPlus/ep_compare case-insensitive key
# identity, while all Source-vs-Native physical metadata remains exact bytes.
def norm(s):return s.strip().upper()
def bind_variable(d,rows):
 candidates=[(i,r) for i,r in enumerate(rows) if norm(r['key'])==norm(d['key']) and norm(r['variable'])==norm(d['name']) and norm(r['frequency'])==norm(d['frequency'])]
 assert len(candidates)==1,(d['key'],d['name'],candidates)
 i,row=candidates[0]
 scalar=row['units']=='scalar (declared schedule type retained)'
 if scalar:
  assert row['variable']=='Schedule Value' and d['units']==''
 elif row['variable']=='Zone Air Humidity Ratio':
  # Preserve this preexisting descriptive-label/Native-None discrepancy rather
  # than inventing a unit conversion or rewriting either metadata/policy.
  assert row['units']=='kgWater/kgDryAir' and d['units']==''
 else:assert row['units']==d['units'],(row,d['units'])
 return i,row,scalar
def metrics(expected,observed,tolerance):
 assert len(expected)==len(observed) and expected
 maximum=0.0;maximum_relative=0.0;ss=0.0;failures=[];raw_unequal=0;bits_unequal=0;max_index=0
 for i,(a,b) in enumerate(zip(expected,observed)):
  assert a['environment']==b['environment'] and a['stamp']==b['stamp']
  x,y=a['value'],b['value'];delta=abs(x-y);scale=max(abs(x),abs(y));relative=0.0 if scale==0 else delta/scale
  if delta>maximum:maximum=delta;max_index=i
  maximum_relative=max(maximum_relative,relative);ss+=delta*delta
  raw_unequal+=a['raw_fields']!=b['raw_fields'];bits_unequal+=bits(x)!=bits(y)
  if not (delta<=tolerance['atol'] or delta<=tolerance['rtol']*scale):failures.append(dict(sample_index=i,expected=x,observed=y,delta=delta,expected_raw=a['raw_fields'],observed_raw=b['raw_fields'],stamp=a['stamp']))
 rmse=math.sqrt(ss/len(expected));assert math.isfinite(rmse)
 return dict(samples=len(expected),max_abs_delta=maximum,rmse_delta=rmse,max_relative_delta=maximum_relative,max_abs_sample_index=max_index,raw_operand_unequal=raw_unequal,parsed_binary64_unequal=bits_unequal,all_uncapped_tolerance_failures=failures,rmse_limit_met=rmse<=tolerance['rmse_max'],passed=not failures and rmse<=tolerance['rmse_max'])

results=[];stream_reports=[];bound_indices=[]
for ext,kind in [('.eso','eso'),('.mtr','mtr')]:
 pair=streams[ext];source=parse_completed(get(pair['Source']),kind);native=parse_completed(get(pair['Native']),kind)
 assert source['dictionary']==native['dictionary'] and source['environments']==native['environments'] and source['stamps']==native['stamps']
 assert source['records']==native['records'] and source['series'].keys()==native['series'].keys()
 bound=[]
 for rid,d in source['series'].items():
  expected=native['series'][rid]
  assert {k:v for k,v in d.items() if k!='samples'}=={k:v for k,v in expected.items() if k!='samples'}
  if kind=='eso':
   index,tolerance,scalar=bind_variable(d,policy['profiles']['A']);bound.append(index);rd=(d['name'],d['units']);assert rd in source_rdd and rd in native_rdd and source_rdd[rd]==native_rdd[rd]
   store=source_rdd[rd];assert tolerance['sampling_stage']=='zone'
   if d['name']=='Zone Air Humidity Ratio':assert store['timestep_type']=='HVAC'
   else:assert store['timestep_type']=='Zone'
   sampling=metadata['expected_zone_steps_excluding_warmup'];authority=dict(source_RDD=ref(source_rdd_path),Native_RDD=ref(native_rdd_path),selected_exact_RDD_line=store['raw_line'],store_type=store['store_type'],timestep_type=store['timestep_type'])
  else:
   candidates=[(i,r) for i,r in enumerate(policy['meter_profiles']['A']) if (r['meter'],r['units'],r['frequency'])==(d['name'],d['units'],d['frequency'])];assert len(candidates)==1;index,tolerance=candidates[0];bound.append(index);scalar=False
   selected=f"Output:Meter,{d['name']},hourly; !- [{d['units']}]";assert selected in source_mdd and selected in native_mdd
   authority=dict(source_MDD=ref(source_mdd_path),Native_MDD=ref(native_mdd_path),selected_exact_MDD_line=selected,store_type='Sum',store_type_authority='Native OutputProcessor meter report is cumulative interval energy, explicit StoreType::Sum in accepted Source catalog; not inferred from units or meter name')
   sampling=metadata['expected_zone_steps_excluding_warmup']//4
  assert len(d['samples'])==len(expected['samples'])==sampling
  met=metrics(expected['samples'],d['samples'],tolerance)
  stampbytes=json.dumps([(x['environment'],x['stamp']) for x in d['samples']],ensure_ascii=False,separators=(',',':')).encode()
  results.append(dict(stream=kind,report_id=rid,actual_key=d['key'],actual_name=d['name'],actual_units=d['units'],actual_frequency=d['frequency'],exact_dictionary=d['raw_dictionary'],policy_index=index,policy=tolerance,scalar_profile_label_not_physical_unit=scalar,humidity_policy_label_and_sampling_stage_discrepancy=d['name']=='Zone Air Humidity Ratio',type_authority=authority,exact_ordered_unique_environment_timestamp_sha256=hashlib.sha256(stampbytes).hexdigest(),metrics=met))
 assert len(bound)==len(set(bound))==(len(policy['profiles']['A']) if kind=='eso' else len(policy['meter_profiles']['A']))
 stream_reports.append(dict(stream=kind,Source=source['path'],Native=native['path'],Source_version_line=source['version_line'],Native_version_line=native['version_line'],complete_numeric_record_count=source['records'],dictionary_rows=len(source['dictionary']),enabled_series=len(source['series']),environments=len(source['environments']),timestamp_rows=len(source['stamps']),exact_Source_Native_dictionary_environment_tuples_and_timestamp_order=True,Source_and_Native_complete_footers_verified=True,all_profile_rows_bound_once=True))
totals=dict(series=len(results),samples=sum(x['metrics']['samples'] for x in results),raw_operand_unequal=sum(x['metrics']['raw_operand_unequal'] for x in results),parsed_binary64_unequal=sum(x['metrics']['parsed_binary64_unequal'] for x in results),tolerance_failures=sum(len(x['metrics']['all_uncapped_tolerance_failures']) for x in results),rmse_failures=sum(not x['metrics']['rmse_limit_met'] for x in results),all_declared_A24_reported_values_within_original_tolerances=all(x['metrics']['passed'] for x in results))
matrix=[]
for name,c in cases.items():
 md=read(get(c['metadata']));get(c['input']);get(c['weather']);profile=policy['case_profiles'][name];assert profile==md['scope'] and md['expected_weather_environments']==1
 matrix.append(dict(case=name,profile=profile,metadata=ref(get(c['metadata'])),input=ref(get(c['input'])),weather=ref(get(c['weather'])),variable_series=len(policy['profiles'][profile]),expected_Timestep_samples_each=md['expected_zone_steps_excluding_warmup'],meter_series=len(policy['meter_profiles'][profile]),expected_Hourly_meter_samples_each=md['expected_zone_steps_excluding_warmup']//4,numerically_compared_in_this_audit=name=='A-24H'))
readonly=['tools/porting/prepare_con01.py','tools/porting/trace_con01.py','tools/porting/README.md','crates/ep_compare/src/tolerance.rs','crates/ep_compare/src/series.rs','crates/ep_compare/src/eso.rs','crates/ep_compare/src/mtr.rs','crates/ep_compare/README.md','crates/ep_run/src/pipeline.rs','energyplus_porting_plan/plan.json']
N=R/'.reference/energyplus-src/26.1.0';pin='6f2e40d10250a105b49966baa24d843711e61048';assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD']).decode().strip()==pin
extents=[('ZoneTempPredictorCorrector.cc',2837,2870),('ZoneTempPredictorCorrector.hh',122,132),('OutputProcessor.cc',4039,4094)]
prepared_original=[];original_wholes={}
for name,lo,hi in extents:
 p=N/'src/EnergyPlus'/name;z=p.read_bytes();lines=z.splitlines(True);assert 1<=lo<=hi<=len(lines)
 if name not in original_wholes:assert subprocess.check_output(['git','-C',str(N),'show',pin+':src/EnergyPlus/'+name])==z;original_wholes[name]=ref(p)
 prepared_original.append((name,lo,hi,b''.join(lines[lo-1:hi])))
assert 'Constant::Units::None' in prepared_original[0][3].decode() and '"{} Air Humidity Ratio"' in prepared_original[0][3].decode()
assert 'StoreType::Sum' in prepared_original[2][3].decode()
O.mkdir();original=[]
for name,lo,hi,z in prepared_original:
 p=O/'Original'/f'{name}-{lo}-{hi}.txt';p.parent.mkdir(exist_ok=True);p.write_bytes(z);original.append(dict(source=original_wholes[name],first_line=lo,last_line=hi,literal_excerpt=ref(p)))
def write(name,value):
 p=O/name;p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
detail=write('reported-series-comparison.json',dict(case='A-24H',streams=stream_reports,series=results,totals=totals))
report=dict(schema='src06-existing-finite-case-output-policy-and-complete-A24-reported-comparison.v1',status='Read-only bounded operational comparison of already completed own Source79 and Native67 artifacts using unchanged preexisting policy; no production export/full15matrix/card gate claim',policy=ref(policy_path),policy_historical_authentication=dict(Native67_repository_revision=revision,Git_blob_sha256=hashlib.sha256(historical).hexdigest(),current_bytes_exact_equal_Native67_revision=True,all_rtol_zero=True,policy_not_modified=True),scope=ref(scope_path),Native_receipt=ref(native_receipt),Source_receipt=ref(source_receipt),Source_actual620_review=ref(root_review),prior_full_physical_comparison=ref(get(rr['comparison'])),detail=detail,totals=totals,finite_matrix=matrix,read_only_contract_sources=[ref(R/p) for p in readonly],author_Source=ref(Path(__file__).resolve()),operational_contract={'identity':'Source/Native entire dictionaries (including actual IDs, key/name/units/frequency/counts) and all environment+timestamp tuples are byte-exact after declared Program Version record exclusion. No ID-only or name-only fallback. Separate ESO/MTR domains; every expected policy identity bound once, no extra/drop/default rows.','policy_binding':'Profile key/name case-insensitive binding follows existing EnergyPlus names and ep_compare normalize_key/eq_ignore_ascii_case; Source-vs-Native metadata remain exact raw strings. Frequency and physical units are exact. The preexisting Schedule Value scalar-description policy label binds only the observed blank-unit Schedule Value plus actual input On/Off type, not a unit conversion.','variable_StoreType':'Unique actual selected name+unit rows in both completed RDD files agree exactly on Average/Sum and Zone/HVAC. RDD hourly is available-output example syntax, not selected reporting frequency; actual frequency comes from exact ESO dictionary. Fresh Source80 owner catalog must additionally agree with its actual Source RDD.','meter_StoreType':'Selected regular MDD records agree exactly; the genuine OutputProcessor meter pathway has explicit Sum semantics as authenticated by accepted catalog source/Native contract. No StoreType is guessed from units/name or ESO absent fields.','values':'Only actual complete physical reported decimal operands are parsed, no Source/Native rerun, no simulation state or accumulator reconstruction, no twelve-decimal reformatting, no injected answers. All58 series have complete exact ordered unique native stamps,96 Timestep or24 Hourly values.','numeric_rule':'Exactly existing Tolerance.accepts: delta <= atol OR delta <= rtol*max(abs(expected),abs(observed)); all fixed case rows have rtol0. Existing sequential binary64 sum_squared_delta/count/sqrt RMSE metric and predeclared per-row rmse_max applied independently; no tolerance relaxation.','exact_domains':'Dictionary/control/ID/key/name/unit/frequency/environment IDs/counts/array lengths and ordered native timestamp tuples are exact. No civil year is invented from ESO; no tolerance is applied to those domains.','comparator_limits':'Existing ep_compare ESO selector matches key/name and can overwrite another frequency; ignores footer; v2 general timestamp-set comparison sorts/coalesces. Use the accepted complete Source reader and explicit ordered timestamp contract for strict Source integration. Existing generic Tolerance::default (atol1e-9/rtol1e-6) and legacy pipeline compare_with_oracle are not the finite-case policy and are not used here.','B_system_outputs':'All12 B profiles retain102 named Timestep outputs, including43 originating from system-report state. Compare actual ESO Average/Sum Timestep reports; do not compare instantaneous zone-callback fields, downsample or average anew. No B numerical claim is made without its completed actual artifacts.','gate_limits':'This physical A24 reported-output comparison does not satisfy missing production exporter return,14 unexecuted case/duration comparisons, internal unit-card strict bit/ULP contracts, new strict optional Source oracle comparator, or any other plan gate. It changes no gates/main/input/policy and cannot turn diagnostic Source79 exit6 into whole production success.'},canonical_mutations=0,Git_mutations=0,Cargo_Native_or_tests_executed=False,new_test_bodies=0,policy_changes=0,full15matrix_complete=False,whole_production_path_complete=False,plan_gate_updates=0)
report['Original_commit']=pin
report['Original_authority']=original
report['qualified_preceding_audit']=ref(B/'completed-A24-tolerance-identity-audit-Audit-01/audit.json')
report['qualification_revision']='Previous audit01 metrics are retained exactly; this revision explicitly distinguishes policy descriptive labels/callback sampling hints from physical Native units/timestep type, and adds strict pinned Native registration authority. No numeric rule, data or policy byte changes.'
report['strict_literal_policy_units_and_RDD_timestep_type_match']=False
report['policy_metadata_notes']=[
 dict(variable='Schedule Value',profile_units='scalar (declared schedule type retained)',actual_Source_and_Native_ESO_units='',actual_Source_and_Native_RDD='Zone Average []',actual_input='Schedule:Constant AlwaysOn uses On/Off type limits0..1 DISCRETE',meaning='The profile explicitly uses a descriptive scalar label; physical blank units and actual schedule-type binding are retained separately. No scale or units conversion.'),
 dict(variable='Zone Air Humidity Ratio',profile_units='kgWater/kgDryAir',profile_sampling_stage='zone',actual_Source_and_Native_ESO_units='',actual_Source_and_Native_RDD='HVAC Average []',pinned_Native_registration='ZoneTempPredictorCorrector.cc2848 Constant::Units::None; direct airHumRat target, TimeStepType::System, StoreType::Average',meaning='Preexisting policy metadata differs from Native dictionary metadata. This audit does not rewrite either side or claim literal unit/timestep-type equivalence. Unique exact key/name/frequency and Source-vs-Native physical-unit/type equality identify the actual reported numeric pair; original named row atol1e-9 and rmse_max1e-9 are applied with no scale conversion. Trace sampling_stage is retained separately; actual Timestep Average report is used, never instantaneous callback airHumRat.')]
report['operational_contract']['policy_binding']='Profile key/name case-insensitive binding follows existing EnergyPlus names and ep_compare normalize_key/eq_ignore_ascii_case; Source-vs-Native metadata remain exact raw strings. Actual Source/Native units and frequency match exactly. The two explicit policy-label notes remain visible: Schedule Value descriptive scalar versus []; Zone Air Humidity Ratio kgWater/kgDryAir+zone hint versus actual Native []+HVAC Average. No generic unit alias, scale conversion, renamed actual metadata, substituted series or tolerance change is introduced.'
report['operational_contract']['variable_StoreType']='Unique actual selected name+unit rows in both completed RDD files agree exactly on Average/Sum and Zone/HVAC. For humidity the actual RDD HVAC type differs from the existing policy zone sampling hint; that discrepancy is reported, not normalized away. RDD hourly is available-output example syntax, not selected reporting frequency; actual frequency comes from exact ESO dictionary. Fresh Source80 owner catalog must additionally agree with its actual Source RDD.'
report['operational_contract']['gate_limits']+=' Literal policy metadata notes remain open documentation matters and are not silently declared fixed by these numeric metrics.'
print(json.dumps(write('audit.json',report)));print(json.dumps(totals))

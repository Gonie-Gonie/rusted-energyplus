"""Seal reviewed-parent canonical11 proposals; never applies them."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
DRAFT=D/'canonical-source82-completed-activation-draft-Outer-11'
OUT=D/'canonical-source82-completed-activation-prepared-Outer-11';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
    p=ROOT/r['path'];assert ref(p)==r;return p.read_bytes()
def run(a,required=True):
    p=subprocess.run(a,cwd=ROOT,capture_output=True)
    if required:assert p.returncode==0,(a,p.stderr)
    return p
ROOT_REVIEW=D/'Root-ordinary-provider-union82-actual-review-01/review.json'
assert ref(ROOT_REVIEW)['sha256']=='3b9966785160ec62cd1de1d63d8d0008b812c884ec8c7b439af5139acedb0ca7'
actual=json.loads(ROOT_REVIEW.read_bytes())
assert actual['accepted'] and actual['actual_Source_endrun620_and_strict_result_export_completed'] and actual['Source_CLI_exit_code']==0 and actual['own_JSON_CSV_raw_token_timestamp_bits_roundtrips']==5352
for k in ['manifest','independent_own_file_export_readback','actual_check','actual_CLI','unchanged_original_A24_reported_numeric_tolerance_audit','independent_tolerance_peer']:read(actual[k])
checks_path=DRAFT/'draft-checks.json';checks=json.loads(checks_path.read_bytes());HEAD=checks['base_HEAD'];assert checks['frozen82']==actual['manifest']
assert run(['git','rev-parse','HEAD']).stdout.decode().strip()==HEAD and run(['git','diff','--quiet']).returncode==0
plan=json.loads(read(checks['plan']));full_path=DRAFT/'complete-final-compiler-Source-plan.json';full=json.loads(full_path.read_bytes())
assert full['base_HEAD']==HEAD and full['final_inputs']==4472 and full['final_Rust_sources']==4459 and len(full['entries'])==4472
for node in ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8')).body:
    if isinstance(node,ast.FunctionDef) and node.name=='apply_literal':exec(compile(ast.Module([node],type_ignores=[]),'<literal>','exec'),globals())
prepared=[]
for r in checks['files']:
    n=r['canonical_path'];before=read(r['before']);parent=read(r['parent_source82']);new=read(r['proposed']);git=run(['git','show',HEAD+':'+n],required=False)
    assert git.returncode==(128 if r['canonical_absent'] else 0) and git.stdout==before
    p=ROOT/n;assert (p.read_bytes() if p.exists() else b'')==before
    prepared.append((r,before,parent,new,git))
assert len(prepared)==10
for r in checks['Source_only_parses']:assert r['exit_code']==0;read(r['stdout']);read(r['stderr'])
for r in full['entries']:
    n=r['path'];p=ROOT/n
    if r['current_main_sha256'] is None:assert not p.exists()
    else:assert p.exists() and len(p.read_bytes())==r['current_main_bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['current_main_sha256']
for r in full['excluded']:assert not (ROOT/r['path']).exists()
OUT.mkdir()
def put(n,b):
    p=OUT/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def doc(n,o):return put(n,(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode())
def delta(a,b,n,key):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile=key+'-before/'+n,tofile=key+'-after/'+n)).encode()
rows=[];apps=[];gits=[]
for i,(r,b,p,a,g) in enumerate(prepared,1):
    n=r['canonical_path'];row=dict(canonical_path=n,canonical_absent_observed=r['canonical_absent'],before=put('before/'+n,b),parent_before=put('parent-source82/'+n,p),parent_source82=r['parent_source82'],proposed=put('proposed/'+n,a),literal_inverse=put('literal-inverse/'+n,b),literal_parent_inverse=put('literal-parent-inverse/'+n,p))
    for k,x,y in [('complete_forward_diff',b,a),('complete_inverse_diff',a,b),('parent_forward_diff',p,a),('parent_inverse_diff',a,p)]:
        row[k]=put('diffs/'+f'{i:02}-'+k+'.diff',delta(x,y,n,k));assert apply_literal(x,read(row[k]))==y;apps.append(dict(path=n,role=k,exact_whole_application_passed=True))
    gits.append(dict(path=n,revision=HEAD,exit_code=g.returncode,stdout=put('Git/'+n,g.stdout),stderr=put('Git/'+n+'.stderr',g.stderr),whole_before_equal=True))
    rows.append(row)
assert len(apps)==40
by_path={r['canonical_path']:r for r in rows}
for r in full['entries']:
    if r['path'] in by_path:r['final_proposed']=by_path[r['path']]['proposed']
full['status']='HELD final exact content plan; candidate source not compiled/executed; Root82 predecessor accepted'
full['author_Source']=ref(Path(__file__).resolve());full_ref=doc('complete-final-compiler-Source-plan.json',full)
custody=doc('checks.json',dict(draft_checks=ref(checks_path),draft_author=ref(D/'prepare-canonical-completed-source-activation-Outer-11.py'),draft_input_inventory_author=ref(D/'inventory-canonical-completed-source-activation-Outer-11.py'),draft_parses=checks['Source_only_parses'],copy_proposals_byte_exact=True,literal_applications=apps,actual_canonical_Git=gits,None_prepare_whole_inverse_recovered=True,None_execute_native_prefix_whole_recovered=True,legacy_initializer_and_fixture_whole_equal=5,canonical10_test_body_whole_preserved=True,all_nine_diagnostics_quarantined=True,all_nonselected_nondiagnostic_inputs_whole_equal82=True,final_input_count=4472,final_Rust_count=4459,canonical_changes=0,Cargo_Native_or_tests=False))
contract=doc('integration-contract.json',dict(
    activation='Only explicit previously admitted Some(A/B) selects the genuine Source primary/endrun/result path. None preserves canonical10 default. This packet is HELD pending independent peer and Root fresh canonical checks/execution.',
    scope='Existing Copy Option<PortingScope> is passed from run_with_optional_porting_scope_impl to preparation and execution. SomeA must match OneZone class; SomeB must match existing DirectIdealLoads class. No support-policy change, RuntimeClass relabel or public CLI/RunConfig change.',
    preparation='Seven actual raw input/weather/reporting preparation guards include explicit SomeB. Same raw IP→Project/Schedules/Sizing/TAB/HB/material/reporting/equipment/radiation handoffs; SourceB bypasses eager legacy weather and both legacy schedule caches. All actual Native count/getter/owner producers remain intact.',
    control='Some→actual unopened weather on same reports/files/session→full primary→same13-owner endrun and actual ErrorsFound617/fatal618→genuine620→metadata/hours check→actual catalog/counters/exact retained paths strict reader→immediate private Source outcome before cache. Source errors propagate; no legacy retry/fallback/default values.',
    None_policy='Whole preparation function inverse and execution prefix projection recover exact canonical10. All four legacy result constructor expressions plus existing fixture remain whole equal, legacy provenance/writer/geometry remain Legacy-only, huge legacy JSON payload remains equal inside envelope.',
    observer_quarantine='All2pipeline+3CTF+3files spans are exact authenticated fragments from plan. CTF sole reader and files sole path accessor inverse recover whole canonical10. Other5existing registration/reporting diagnostic files stay wholemain and report_diagnostics child remains absent. No diagnostic module enable, collector, binary64 sidecar, table snapshot or input snapshot is promoted.',
    export='Exact Source82 corrected parser, streamed borrowed JSON serializer, unchanged raw CSV writer and typed artifact map error. Same allsample rawtokens, native tuples, ID/StoreType/frequency identities, f64+bits, counters and physical footer checks. Explicit Source oracle flags still Unsupported after Source export; no old comparison fallback.',
    validation='Inherited Source82 actualA24 success0, full5352 own-file JSON/CSV rawtokens/f64bits/tuples and original named tolerances accepted. This new conditional production candidate still requires independent full Source peer and Root canonical type/lint/actual checks. Accepted predecessor is not a new canonical execution receipt.',
    B='ScopeB will stop honestly at the first real unported input/Native child (including genuine NodeList/controlled-zone boundaries). No Legacy execution, forced-zero equipment, missing-node fabrication, boundary bypass or full B completion claim.',
    tests='The entire existing CTF test section, including both Windows CRLF expectations, is exact canonical10. No new tests, no suite expansion and no Cargo/Native execution by author.'))
apply_code=r'''"""Guarded Root-only application of an independently accepted canonical11 packet."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[4];PACKET=Path(__file__).resolve().parent
CANONICAL={
 'crates/ep_runtime/src/heat_balance/mod.rs',
 'crates/ep_run/src/lib.rs',
 'crates/ep_runtime/src/heat_balance/source_reported_catalog.rs',
 'crates/ep_run/src/source_reported_results.rs',
 'crates/ep_run/src/source_reported_results/parser.rs',
 'crates/ep_run/src/source_reported_results/export.rs',
 'crates/ep_run/src/pipeline.rs',
 'crates/ep_run/src/ctf_initialization_outputs.rs',
 'crates/ep_runtime/src/heat_balance/source_initialization/files.rs',
 'crates/ep_run/src/pipeline/source_outcome.rs',
}
def digest(b):return hashlib.sha256(b).hexdigest()
def get(r):
 p=(ROOT/r['path']).resolve();p.relative_to(ROOT.resolve());b=p.read_bytes()
 if digest(b)!=r['sha256'] or len(b)!=r['bytes']:raise RuntimeError('custody changed: '+r['path'])
 return b
def git(args):
 p=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
 if p.returncode:raise RuntimeError('Git guard failed: '+p.stderr.decode(errors='replace'))
 return p.stdout
parser=argparse.ArgumentParser()
parser.add_argument('--expect-manifest-sha',required=True)
parser.add_argument('--peer-review',required=True)
parser.add_argument('--expect-peer-sha',required=True)
parser.add_argument('--apply',action='store_true')
args=parser.parse_args();manifest_bytes=(PACKET/'manifest.json').read_bytes()
if digest(manifest_bytes)!=args.expect_manifest_sha:raise RuntimeError('manifest SHA guard failed')
m=json.loads(manifest_bytes);mr=dict(path=(PACKET/'manifest.json').relative_to(ROOT).as_posix(),sha256=digest(manifest_bytes),bytes=len(manifest_bytes))
peerpath=Path(args.peer_review).resolve();peerbytes=peerpath.read_bytes()
if digest(peerbytes)!=args.expect_peer_sha:raise RuntimeError('peer SHA guard failed')
peer=json.loads(peerbytes)
if peer.get('accepted') is not True or peer.get('manifest')!=mr or peer.get('findings'):raise RuntimeError('independent peer acceptance guard failed')
actual=json.loads(get(m['accepted_actual82']))
if actual.get('accepted') is not True or actual.get('Source_CLI_exit_code')!=0 or actual.get('own_JSON_CSV_raw_token_timestamp_bits_roundtrips')!=5352:raise RuntimeError('actual82 predecessor acceptance guard failed')
if git(['rev-parse','HEAD']).decode().strip()!=m['base_HEAD']:raise RuntimeError('HEAD guard failed')
if git(['status','--porcelain','--untracked-files=no']):raise RuntimeError('tracked worktree must be clean before application')
files={r['canonical_path']:r for r in m['files']}
if set(files)!=CANONICAL:raise RuntimeError('ten-path allowlist guard failed')
inputs=json.loads(get(m['complete_final_compiler_Source_plan']))
if len(inputs['entries'])!=4472 or inputs['final_Rust_sources']!=4459:raise RuntimeError('complete input count guard failed')
pending=[]
for name,r in files.items():
 target=(ROOT/name).resolve();target.relative_to(ROOT.resolve());before=get(r['before']);after=get(r['proposed'])
 if r['canonical_absent_observed']:
  if target.exists():raise RuntimeError('new Source target appeared: '+name)
 elif not target.exists() or target.read_bytes()!=before:raise RuntimeError('canonical before changed: '+name)
 pending.append((name,target,after))
for r in inputs['entries']:
 target=(ROOT/r['path']).resolve();target.relative_to(ROOT.resolve())
 if r['current_main_sha256'] is None:
  if target.exists():raise RuntimeError('absent compiler input appeared: '+r['path'])
 else:
  b=target.read_bytes()
  if digest(b)!=r['current_main_sha256'] or len(b)!=r['current_main_bytes']:raise RuntimeError('whole compiler before changed: '+r['path'])
for r in inputs['excluded']:
 if (ROOT/r['path']).exists():raise RuntimeError('quarantined diagnostic child appeared')
applied=[]
try:
 if args.apply:
  for name,target,after in pending:
   target.parent.mkdir(parents=True,exist_ok=True)
   with tempfile.NamedTemporaryFile(mode='wb',dir=target.parent,prefix='.canonical11-',suffix='.tmp',delete=False) as tmp:
    tmp.write(after);temp_path=Path(tmp.name)
   try:os.replace(temp_path,target)
   finally:
    if temp_path.exists():temp_path.unlink()
   applied.append(name)
  for r in inputs['entries']:
   b=(ROOT/r['path']).read_bytes()
   if digest(b)!=r['final_sha256'] or len(b)!=r['final_bytes']:raise RuntimeError('whole final compiler input mismatch: '+r['path'])
  for r in inputs['excluded']:
   if (ROOT/r['path']).exists():raise RuntimeError('diagnostic child created unexpectedly')
except Exception:
 print(json.dumps(dict(status='application failed',applied_paths=applied,all_proposals_retained=True)))
 raise
print(json.dumps(dict(status='applied' if args.apply else 'validated without application',base_HEAD=m['base_HEAD'],paths=sorted(files),applied_paths=applied,final_compiler_inputs=4472,canonical_diagnostic_child_absent=True)))
'''
ast.parse(apply_code);apply_ref=put('apply-prepared.py',apply_code.encode())
manifest=doc('manifest.json',dict(schema='src06-held-canonical11-explicit-scope-completed-source-activation.v1',status='PREPARED HELD; accepted actual82 predecessor bound; new canonical scope-conditional candidate requires independent peer and Root canonical checks before application/promotion',base_HEAD=HEAD,files=rows,existing_paths=5,new_paths=5,accepted_actual82=ref(ROOT_REVIEW),accepted_actual82_manifest=actual['manifest'],accepted_own_file_export_readback=actual['independent_own_file_export_readback'],accepted_tolerance_audit=actual['unchanged_original_A24_reported_numeric_tolerance_audit'],accepted_tolerance_peer=actual['independent_tolerance_peer'],scope_plan=checks['plan'],checks=custody,complete_final_compiler_Source_plan=full_ref,integration_contract=contract,guarded_apply_Source=apply_ref,guarded_apply_executed=False,requires_independent_peer=True,new_candidate_Cargo_Native_or_tests_executed=False,draft_Source_only_parse_count=10,new_test_bodies=0,canonical_mutations=0,Source82_mutations=0,all_nine_diagnostic_paths_quarantined=True,Some_AB_Source_only_No_fallback=True,None_legacy_default_preserved=True,B_completion_claim=False,numerical_or_full15_gate_claim=False,author_Source=ref(Path(__file__).resolve())))
print(json.dumps(manifest))

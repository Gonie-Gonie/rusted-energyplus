"""Guarded Root-only application of an independently accepted canonical11 packet."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[4];PACKET=Path(__file__).resolve().parent
CANONICAL={
 'crates/ep_runtime/src/heat_balance/mod.rs',
 'crates/ep_run/src/lib.rs',
 'crates/ep_runtime/src/heat_balance/source_reported_catalog.rs',
 'crates/ep_run/src/source_reported_results.rs',
 'crates/ep_run/src/source_reported_results/parser.rs',
 'crates/ep_run/src/source_reported_results/export.rs',
 'crates/ep_run/src/pipeline.rs',
 'crates/ep_run/src/ctf_initialization_outputs.rs',
 'crates/ep_runtime/src/heat_balance/source_initialization/files.rs',
 'crates/ep_run/src/pipeline/source_outcome.rs',
}
def digest(b):return hashlib.sha256(b).hexdigest()
def get(r):
 p=(ROOT/r['path']).resolve();p.relative_to(ROOT.resolve());b=p.read_bytes()
 if digest(b)!=r['sha256'] or len(b)!=r['bytes']:raise RuntimeError('custody changed: '+r['path'])
 return b
def git(args):
 p=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
 if p.returncode:raise RuntimeError('Git guard failed: '+p.stderr.decode(errors='replace'))
 return p.stdout
parser=argparse.ArgumentParser()
parser.add_argument('--expect-manifest-sha',required=True)
parser.add_argument('--peer-review',required=True)
parser.add_argument('--expect-peer-sha',required=True)
parser.add_argument('--apply',action='store_true')
args=parser.parse_args();manifest_bytes=(PACKET/'manifest.json').read_bytes()
if digest(manifest_bytes)!=args.expect_manifest_sha:raise RuntimeError('manifest SHA guard failed')
m=json.loads(manifest_bytes);mr=dict(path=(PACKET/'manifest.json').relative_to(ROOT).as_posix(),sha256=digest(manifest_bytes),bytes=len(manifest_bytes))
peerpath=Path(args.peer_review).resolve();peerbytes=peerpath.read_bytes()
if digest(peerbytes)!=args.expect_peer_sha:raise RuntimeError('peer SHA guard failed')
peer=json.loads(peerbytes)
if peer.get('accepted') is not True or peer.get('manifest')!=mr or peer.get('findings'):raise RuntimeError('independent peer acceptance guard failed')
actual=json.loads(get(m['accepted_actual82']))
if actual.get('accepted') is not True or actual.get('Source_CLI_exit_code')!=0 or actual.get('own_JSON_CSV_raw_token_timestamp_bits_roundtrips')!=5352:raise RuntimeError('actual82 predecessor acceptance guard failed')
if git(['rev-parse','HEAD']).decode().strip()!=m['base_HEAD']:raise RuntimeError('HEAD guard failed')
if git(['status','--porcelain','--untracked-files=no']):raise RuntimeError('tracked worktree must be clean before application')
files={r['canonical_path']:r for r in m['files']}
if set(files)!=CANONICAL:raise RuntimeError('ten-path allowlist guard failed')
inputs=json.loads(get(m['complete_final_compiler_Source_plan']))
if len(inputs['entries'])!=4472 or inputs['final_Rust_sources']!=4459:raise RuntimeError('complete input count guard failed')
pending=[]
for name,r in files.items():
 target=(ROOT/name).resolve();target.relative_to(ROOT.resolve());before=get(r['before']);after=get(r['proposed'])
 if r['canonical_absent_observed']:
  if target.exists():raise RuntimeError('new Source target appeared: '+name)
 elif not target.exists() or target.read_bytes()!=before:raise RuntimeError('canonical before changed: '+name)
 pending.append((name,target,after))
for r in inputs['entries']:
 target=(ROOT/r['path']).resolve();target.relative_to(ROOT.resolve())
 if r['current_main_sha256'] is None:
  if target.exists():raise RuntimeError('absent compiler input appeared: '+r['path'])
 else:
  b=target.read_bytes()
  if digest(b)!=r['current_main_sha256'] or len(b)!=r['current_main_bytes']:raise RuntimeError('whole compiler before changed: '+r['path'])
for r in inputs['excluded']:
 if (ROOT/r['path']).exists():raise RuntimeError('quarantined diagnostic child appeared')
applied=[]
try:
 if args.apply:
  for name,target,after in pending:
   target.parent.mkdir(parents=True,exist_ok=True)
   with tempfile.NamedTemporaryFile(mode='wb',dir=target.parent,prefix='.canonical11-',suffix='.tmp',delete=False) as tmp:
    tmp.write(after);temp_path=Path(tmp.name)
   try:os.replace(temp_path,target)
   finally:
    if temp_path.exists():temp_path.unlink()
   applied.append(name)
  for r in inputs['entries']:
   b=(ROOT/r['path']).read_bytes()
   if digest(b)!=r['final_sha256'] or len(b)!=r['final_bytes']:raise RuntimeError('whole final compiler input mismatch: '+r['path'])
  for r in inputs['excluded']:
   if (ROOT/r['path']).exists():raise RuntimeError('diagnostic child created unexpectedly')
except Exception:
 print(json.dumps(dict(status='application failed',applied_paths=applied,all_proposals_retained=True)))
 raise
print(json.dumps(dict(status='applied' if args.apply else 'validated without application',base_HEAD=m['base_HEAD'],paths=sorted(files),applied_paths=applied,final_compiler_inputs=4472,canonical_diagnostic_child_absent=True)))

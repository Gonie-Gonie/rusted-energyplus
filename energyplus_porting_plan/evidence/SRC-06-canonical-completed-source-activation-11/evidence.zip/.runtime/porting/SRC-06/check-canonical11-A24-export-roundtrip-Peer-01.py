"""Bounded canonical11 A24 own-result checker; requires actual main exit0 first.

Reads frozen Sources/receipts and existing actual artifacts only. Writes a fresh
immutable evidence directory after every check passes; no program/test/Cargo run.
"""
from pathlib import Path
import argparse,collections,csv,hashlib,io,itertools,json,math,re,struct,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
W=R;P=D/'through-primary-diagnostic-A-24H-Root-79/output';P82=D/'through-primary-diagnostic-A-24H-Root-82/output'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r,base=R):
 p=base/r['path'];b=p.read_bytes();assert len(b)==r.get('bytes',len(b)) and hashlib.sha256(b).hexdigest()==r['sha256'],r['path'];return p
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d,('duplicate JSON key',k);d[k]=v
 return d
def decode(b):
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON '+x)))
def load(p):return decode(p.read_bytes())
def bits(x):return struct.pack('>d',float(x)).hex()
def keys(v,expected):assert isinstance(v,dict) and set(v)==set(expected),(set(v),expected)
def path_equal(text,p):assert isinstance(text,str) and Path(text).resolve()==p.resolve(),(text,str(p))
def integer(v):assert type(v) is int;return v
args=argparse.ArgumentParser();args.add_argument('--review-successful-canonical11-A24',action='store_true')
for name in ['check-receipt','check-sha','actual-receipt','actual-sha','promotion-review','promotion-sha']:args.add_argument('--'+name,required=True)
args.add_argument('--artifact-name',default='Peer-canonical11-A24-export-roundtrip-01')
a=args.parse_args();assert a.review_successful_canonical11_A24
assert re.fullmatch(r'Peer-canonical11-A24-export-roundtrip-\d{2}',a.artifact_name);OUT=D/a.artifact_name
# This guard precedes all outcome/output reads and all writes.
checkp,clip=R/a.check_receipt,R/a.actual_receipt
assert ref(checkp)['sha256']==a.check_sha and ref(clip)['sha256']==a.actual_sha
check,cli=load(checkp),load(clip)
assert check['exit_code']==cli['exit_code']==0 and check['launch_error'] is None and cli['launch_error'] is None
assert not OUT.exists() and Path(check['cwd']).resolve()==Path(cli['cwd']).resolve()==W.resolve()
assert '--all-targets' in check['command'] and '--workspace' in check['command']
assert '--oracle-baseline' not in cli['command'] and '--compare-oracle' not in cli['command']
assert '--output-dir' in cli['command'];S=Path(cli['command'][cli['command'].index('--output-dir')+1]).resolve();assert S.is_relative_to(D.resolve()) and S!=P.resolve() and S!=P82.resolve()
assert '--porting-scope' in cli['command'] and cli['command'][cli['command'].index('--porting-scope')+1]=='A'
assert check['source_bytes_match_before_and_after'] and cli['source_bytes_match_before_and_after'] and check['source_snapshot']==cli['source_snapshot']
mp=D/'canonical-source82-completed-activation-prepared-Outer-11/manifest.json';assert ref(mp)['sha256']=='40a16bb8e3fe5b5bbf62c6d00f4b3cbf3cad56ab3bf165996b89b5b7328ac274';M=load(mp)
preflight=R/a.promotion_review;assert ref(preflight)['sha256']==a.promotion_sha
F=load(preflight);assert F['accepted'] and F['findings']==[] and F['manifest']==ref(mp)
plan=load(checked(M['complete_final_compiler_Source_plan']));planned={x['path']:x for x in plan['entries']}
assert len(planned)==plan['final_inputs']==4472 and sum(n.endswith('.rs') for n in planned)==plan['final_Rust_sources']==4459
selected={x['canonical_path']:x for x in M['files']};assert len(selected)==10 and M['new_paths']==5 and M['existing_paths']==5
for n,x in selected.items():assert (R/n).read_bytes()==checked(x['proposed']).read_bytes()
inventory=subprocess.run(['rg','--files','--hidden','--no-ignore','-g','*.rs','-g','Cargo.toml','crates'],cwd=R,capture_output=True,check=True)
paths={x.replace('\\','/') for x in inventory.stdout.decode().splitlines()}|{n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if(R/n).is_file()};assert paths==set(planned)
for x in plan['excluded']:assert not(R/x['path']).exists() and x['path'] not in planned
scope_plan=load(checked(M['scope_plan']));quarantine=scope_plan['quarantine'];assert len(quarantine['all_nine_diagnostic_paths'])==9
for x in quarantine['other_six_whole_preservations']:
 if x['canonical_absent']:assert not(R/x['path']).exists()
 else:assert (R/x['path']).read_bytes()==checked(x['canonical']).read_bytes()
actual82=load(checked(M['accepted_actual82']));assert M['accepted_actual82']['sha256']=='3b9966785160ec62cd1de1d63d8d0008b812c884ec8c7b439af5139acedb0ca7' and actual82['accepted'] and not actual82['findings'] and actual82['Source_CLI_exit_code']==0
readback82=load(checked(M['accepted_own_file_export_readback']));assert M['accepted_own_file_export_readback']['sha256']=='b7dcbba5b1f1abf170d9a468606fc5d27e585d488ba334b8e1c94354afd150bc' and readback82['accepted'] and readback82['findings']==[]
for x in readback82['streams']:checked(x['physical']);checked(x['CSV'])
for x in readback82['Source82_physical_streams_and_binary64_sidecar_whole79_equal']:
 checked(x['Source82']);checked(x['Source79'])
snapshot=load(checked(cli['source_snapshot'],W));observed={x['historical_path']:x for x in snapshot['files']};assert set(observed)==set(planned)
for name,x in observed.items():
 b=(W/name).read_bytes();row=planned[name];assert b==checked(x['archive'],W).read_bytes() and len(b)==row['final_bytes'] and hashlib.sha256(b).hexdigest()==row['final_sha256']
compiler=[]
for line in checked(cli['stdout'],W).read_bytes().splitlines():
 try:v=decode(line)
 except (ValueError,UnicodeError,AssertionError):continue
 if isinstance(v,dict) and v.get('reason')=='compiler-artifact' and v.get('target',{}).get('name') in ['ep_runtime','ep_run','eplus-rs']:
  expected_src={'ep_runtime':'crates/ep_runtime/src/lib.rs','ep_run':'crates/ep_run/src/lib.rs','eplus-rs':'crates/ep_cli/src/main.rs'}[v['target']['name']]
  assert Path(v['target']['src_path']).resolve()==(R/expected_src).resolve();compiler.append(v)
assert len(compiler)==3
tolp=D/'completed-A24-tolerance-identity-audit-Audit-02/audit.json';tolpeer=D/'Peer-completed-A24-tolerance-identity-review-01/review.json'
assert ref(tolp)['sha256']=='3cd42ca127c9eef3edff9d38a127dfa0d63cf8edcb4bc9ccab31079240e379a4' and ref(tolpeer)['sha256']=='7bb564ccdb175c90b56ef71ed2bf0bad948abe4e2aea9ecb5b30851cd850731b'
T,TP=load(tolp),load(tolpeer);assert TP['accepted'] and TP['findings']==[] and TP['manifest']==ref(tolp)
policy=checked(T['policy']);assert T['policy_changes']==0 and T['full15matrix_complete'] is False
prior=load(checked(T['prior_full_physical_comparison']));assert prior['accepted'] and not prior['findings']
case=next(x for x in load(checked(T['scope']))['cases'] if x['id']=='A-24H')
for name in ['input','weather']:
 p=checked(case[name]);assert str(p.resolve()).replace('\\','/') in cli['command']
physical_unchanged=[]
for name in ['eplusrs.eso','eplusrs.mtr','eplusrs.eio','eplusrs.audit','eplusrs.shd']:
 assert (S/name).read_bytes()==(P82/name).read_bytes()==(P/name).read_bytes(),('canonical physical differs82/79',name)
 physical_unchanged.append(dict(canonical11=ref(S/name),Source82=ref(P82/name),Source79=ref(P/name),whole_bytes_equal=True))
absent_diagnostics=['logs/source-report-binary64.csv','logs/source-predefined-table.json','logs/source-input-statistics.json']
for name in absent_diagnostics:assert not(S/name).exists(),('quarantined observer output exists',name)
for name in ['eplusrs.rdd','eplusrs.mdd']:assert (S/name).read_bytes()==(P82/name).read_bytes()==(P/name).read_bytes()
def parse_stream(path,stream):
 raw=path.read_bytes();assert raw.endswith(b'\r\n') and raw.count(b'\r\n')==raw.count(b'\n')
 lines=raw[:-2].decode('utf8').split('\r\n');assert lines[0].startswith('Program Version,')
 assert lines.count('End of Data Dictionary')==lines.count('End of Data')==1
 di=lines.index('End of Data Dictionary');en=lines.index('End of Data');assert en==len(lines)-2
 foot=re.fullmatch(r' Number of Records Written= *(\d+)',lines[-1]);assert foot
 dictionary={};declared=[];series={}
 for line in lines[1:di]:
  x=line.split(',',2);rid,width=int(x[0]),int(x[1]);assert rid>0 and rid not in dictionary;dictionary[rid]=line
  if rid<=6:continue
  if stream=='eso':key,tail=x[2].split(',',1)
  else:key,tail=None,x[2]
  m=re.fullmatch(r'(.+) \[(.*)\] !(TimeStep|Hourly)',tail);assert m and width==1
  d=dict(report_id=rid,key=key,name=m[1],units=m[2],frequency={'TimeStep':'timestep','Hourly':'hourly'}[m[3]],kind='variable' if stream=='eso' else 'meter')
  declared.append(d);series[rid]=[]
 assert set(range(1,7))<=set(dictionary)
 environments=[];stamps=[];current=None;count=0
 for physical,line in enumerate(lines[di+1:en],di+2):
  head,payload=line.split(',',1);rid=int(head);assert rid in dictionary
  if rid==1:
   fields=payload.rsplit(',',4);assert len(fields)==5 and all(math.isfinite(float(s)) for s in fields[1:])
   environments.append(dict(ordinal=len(environments)+1,fields=fields,physical_line=physical));current=None;continue
  if rid==2:
   fields=payload.split(',');assert len(fields)==8 and environments and all(re.fullmatch(r'-?\d+',s.strip()) for s in fields[:5]) and all(math.isfinite(float(s)) for s in fields[5:7]) and fields[7]
   current=len(stamps);stamps.append(dict(report_id=rid,kind='interval',environment_ordinal=len(environments),physical_line=physical,fields=fields));continue
  assert rid>6 and rid in series and current is not None
  fields=payload.split(',');assert len(fields)==1;value=float(fields[0]);assert math.isfinite(value);count+=1
  series[rid].append(dict(reported_fields=fields,value=value,parsed_binary64_bits=bits(value),stamp_index=current,physical_line=physical,stream_data_ordinal=count))
 assert count==int(foot[1])
 for values in series.values():
  ids=[(stamps[v['stamp_index']]['environment_ordinal'],tuple(stamps[v['stamp_index']]['fields'])) for v in values];assert values and len(set(ids))==len(ids)
 return dict(stream=stream,path=path,version_line=lines[0],dictionary=dictionary,declarations=declared,series=series,environments=environments,stamps=stamps,count=count)
rdd={}
for line in (S/'eplusrs.rdd').read_text(encoding='utf8').splitlines():
 if line.startswith('!'):continue
 m=re.fullmatch(r'Output:Variable,\*,(.+),hourly; !- (Zone|HVAC) (Average|Sum) \[(.*)\]',line);assert m
 identity=(m[1],m[4]);assert identity not in rdd;rdd[identity]=dict(raw=line,timestep_type=m[2],store_type={'Average':'average','Sum':'sum'}[m[3]])
mdd=set((S/'eplusrs.mdd').read_text(encoding='utf8').splitlines())
bundlep=S/'results/source-reported-results.json';bundle=load(bundlep)
parent_bundlep=checked(readback82['reported_bundle']);parent_bundle=load(parent_bundlep);bridged_parent_bytes=parent_bundlep.read_bytes();owned_path_bridges=[]
for stream in ['eso','mtr']:
 old,new=parent_bundle[stream]['path'],bundle[stream]['path'];path_equal(old,P82/f'eplusrs.{stream}');path_equal(new,S/f'eplusrs.{stream}')
 oldtoken=b'"path": '+json.dumps(old,ensure_ascii=False).encode();newtoken=b'"path": '+json.dumps(new,ensure_ascii=False).encode()
 assert bridged_parent_bytes.count(oldtoken)==1;bridged_parent_bytes=bridged_parent_bytes.replace(oldtoken,newtoken,1)
 owned_path_bridges.append(dict(stream=stream,accepted82_owned_path=old,canonical_owned_path=new,only_declared_path_field_changed=True))
assert bridged_parent_bytes==bundlep.read_bytes(),('complete JSON differs82 beyond exact owned path fields')
keys(bundle,['schema','timestamp_boundary','value_boundary','eso','mtr'])
assert bundle['schema']=='rusted-energyplus.source-reported-streams.v1'
assert bundle['value_boundary']=='exact reported decimal tokens plus parsed binary64; not unformatted internal state'
assert bundle['timestamp_boundary']=='actual ESO/MTR tuples; no civil year inferred for interval/daily/monthly/run-period records'
csv_header=['stream','report_id','key','name','units','frequency','store_type','kind','sample_index','stream_data_ordinal','environment_ordinal','environment_fields_json','timestamp_report_id','timestamp_kind','timestamp_fields_json','reported_fields_json','reported_decimal','parsed_binary64_bits']
streams={};sample_evidence=[];stream_evidence=[];csv_total=0
for stream,record_count,series_count,per_series in [('eso',5280,55,96),('mtr',72,3,24)]:
 p=parse_stream(S/f'eplusrs.{stream}',stream);q=bundle[stream];streams[stream]=p
 keys(q,['deleted_empty','environment_tuples','path','reported_record_count','series','stream','timestamp_tuples','version_line'])
 assert q['stream']==stream and q['deleted_empty'] is False and integer(q['reported_record_count'])==p['count']==record_count
 path_equal(q['path'],p['path']);assert q['version_line']==p['version_line'] and q['environment_tuples']==p['environments'] and q['timestamp_tuples']==p['stamps']
 assert len(q['series'])==len(p['declarations'])==series_count and [integer(x['report_id']) for x in q['series']]==[x['report_id'] for x in p['declarations']]
 expected_csv=[]
 for actual,d in zip(q['series'],p['declarations']):
  keys(actual,['frequency','key','kind','name','report_id','sample_count','samples','store_type','units'])
  if stream=='eso':authority=rdd[(d['name'],d['units'])];store=authority['store_type']
  else:
   selected=f"Output:Meter,{d['name']},hourly; !- [{d['units']}]";assert selected in mdd;authority=dict(raw=selected,Native_sum_authority=T['Original_authority'][2]);store='sum'
  for k in ['frequency','key','kind','name','report_id','units']:assert actual[k]==d[k]
  assert actual['store_type']==store and integer(actual['sample_count'])==len(actual['samples'])==len(p['series'][d['report_id']])==per_series
  for index,(exported,physical) in enumerate(zip(actual['samples'],p['series'][d['report_id']])):
   keys(exported,['parsed_binary64_bits','physical_line','reported_fields','stamp_index','stream_data_ordinal','value'])
   assert isinstance(exported['value'],(int,float)) and not isinstance(exported['value'],bool) and math.isfinite(exported['value'])
   assert bits(exported['value'])==physical['parsed_binary64_bits']==exported['parsed_binary64_bits'] and re.fullmatch('[0-9a-f]{16}',exported['parsed_binary64_bits'])
   for k in ['reported_fields','stamp_index','physical_line','stream_data_ordinal']:assert exported[k]==physical[k]
   for k in ['stamp_index','physical_line','stream_data_ordinal']:integer(exported[k])
   stamp=p['stamps'][physical['stamp_index']];env=p['environments'][stamp['environment_ordinal']-1]
   expected_csv.append([stream,str(d['report_id']),d['key'] if d['key'] is not None else '',d['name'],d['units'],d['frequency'],store,d['kind'],str(index),str(physical['stream_data_ordinal']),str(stamp['environment_ordinal']),env['fields'],str(stamp['report_id']),stamp['kind'],stamp['fields'],physical['reported_fields'],physical['reported_fields'][0],physical['parsed_binary64_bits']])
   sample_evidence.append(dict(stream=stream,report_id=d['report_id'],sample_index=index,raw_reported_fields=physical['reported_fields'],parsed_binary64_bits=physical['parsed_binary64_bits'],native_environment=env,native_stamp=stamp,stamp_index=physical['stamp_index'],physical_line=physical['physical_line'],stream_data_ordinal=physical['stream_data_ordinal'],JSON_and_CSV_exact_physical_roundtrip=True))
 csvp=S/f'results/source-{stream}.csv';assert csvp.read_bytes()==(P82/f'results/source-{stream}.csv').read_bytes()
 rows=list(csv.reader(io.StringIO(csvp.read_bytes().decode('utf8'),newline=''),strict=True));assert rows[0]==csv_header and len(rows)-1==len(expected_csv)==record_count
 for row,expected in zip(rows[1:],expected_csv):
  assert len(row)==len(csv_header)
  for i,(v,e) in enumerate(zip(row,expected)):
   if i in [11,14,15]:assert decode(v)==e
   else:assert v==e,(stream,i,v,e)
 csv_total+=len(expected_csv)
 stream_evidence.append(dict(stream=stream,physical=ref(p['path']),CSV=ref(csvp),records=record_count,series=series_count,per_series_samples=per_series,environment_rows=len(p['environments']),timestamp_rows=len(p['stamps']),all_JSON_fields_and_CSV_rows_exact=True))
assert csv_total==len(sample_evidence)==5352
summaryp=S/'run-summary.json';summary=load(summaryp);assert summary['schema_version']==1 and summary['status']=='success' and summary['exit_code']==0
assert summary['oracle'] is None and summary['comparison'] is None and summary['oracle_status']==summary['compare_status']=='not-requested'
assert summary['config']['oracle_baseline'] is False and summary['config']['compare_oracle'] is False and summary['config']['dry_run'] is False
runtime=summary['rust_runtime'];keys(runtime,['schema','runtime_class','execution','value_boundary','timestamp_boundary','native_environment_hour_scope','requested_hours','native_options','native_environment_scope','reported_streams'])
assert runtime['schema']=='rusted-energyplus.source-runtime.v1' and runtime['execution']=='actual Source ManageSimulation successful through620'
assert runtime['value_boundary']=='own completed ESO/MTR reported decimal tokens; no internal history reconstruction' and runtime['timestamp_boundary']=='native physical tuple; no civil year assigned where absent'
assert runtime['runtime_class']=='one-zone-heat-balance-compatibility' and integer(runtime['native_environment_hour_scope'])==24
assert runtime['requested_hours']==summary['config']['hours']
if runtime['requested_hours'] is not None:assert integer(runtime['requested_hours'])==24
assert runtime['native_options']=={'DoDesDaySim':False,'DoWeathSim':True,'DDOnly':False,'FullAnnualRun':False}
envscope=runtime['native_environment_scope'];assert envscope and [integer(x['ordinal']) for x in envscope]==list(range(1,len(envscope)+1))
selected=[]
for env in envscope:
 keys(env,['ordinal','title','kind_of_environment','total_days','selected_by_primary_flags']);kind=integer(env['kind_of_environment']);assert kind in range(1,6)
 chosen=not((not runtime['native_options']['DoDesDaySim'] and kind!=3) or (not runtime['native_options']['DoWeathSim'] and kind==3) or kind in [4,5])
 assert env['selected_by_primary_flags'] is chosen
 if chosen:assert integer(env['total_days'])>0;selected.append(env)
assert len(selected)==1 and selected[0]['kind_of_environment']==3 and selected[0]['total_days']==1 and sum(x['total_days']*24 for x in selected)==24
assert streams['eso']['environments'][0]['fields'][0]==streams['mtr']['environments'][0]['fields'][0]==selected[0]['title']
assert summary['source_order_gate_scope']=='execution-plan preflight; not an actual Source caller trace'
assert isinstance(summary['source_order_gate'],dict) and summary['source_order_gate']
assert summary['support']['conformance_claim'] is False
assert len(runtime['reported_streams'])==2
for q,stream in zip(runtime['reported_streams'],['eso','mtr']):
 keys(q,['stream','owned_path','deleted_empty','reported_numeric_records','series','series_samples']);p=streams[stream];assert q['stream']==stream and q['deleted_empty'] is False;path_equal(q['owned_path'],p['path'])
 assert q['reported_numeric_records']==p['count'] and q['series']==len(p['declarations'])
 assert len(q['series_samples'])==len(bundle[stream]['series'])
 for meta,full in zip(q['series_samples'],bundle[stream]['series']):
  keys(meta,['report_id','key','name','units','frequency','store_type','kind','samples'])
  for k in ['report_id','key','name','units','frequency','store_type','kind']:assert meta[k]==full[k]
  assert meta['samples']==full['sample_count']
artifacts=summary['artifacts'];assert not {'result_store_json','selected_outputs_csv','meters_csv'}&set(artifacts)
for k,name in [('source_reported_results_json','source-reported-results.json'),('source_eso_csv','source-eso.csv'),('source_mtr_csv','source-mtr.csv')]:path_equal(artifacts[k],S/'results'/name)
assert {p.name for p in (S/'results').iterdir()}=={'source-reported-results.json','source-eso.csv','source-mtr.csv'}
for name in ['result-store.json','selected-outputs.csv','meters.csv']:assert not(S/'results'/name).exists()
diagnostics=load(S/'diagnostics.json');assert summary['diagnostics']['error']==0 and not any(x['severity']=='error' or x['blocking'] for x in diagnostics['diagnostics'])
metadata={(x['format'],x['line']):x for x in prior['all_uncapped_raw_table_mismatches']};assert len(metadata)==70
def typed_metadata(current,previous,classification,ext,index):
 if classification=='producer version/build':return current==previous
 if classification=='actual wall clock':
  pattern=rb'( *)\d{2}:\d{2}:\d{2}(</b></p>)?(\r?\n)?'
 else:
  assert classification=='actual wall date'
  pattern=rb'( *)\d{4}-\d{2}-\d{2}(\r?\n)?'
  if ext=='htm' and previous.startswith((b'<p>Timestamp: <b>',b'<p>Simulation Timestamp: <b>')):pattern=rb'(<p>(?:Simulation )?Timestamp: <b>)\d{4}-\d{2}-\d{2}(\r?\n)?'
 a,b=re.fullmatch(pattern,current),re.fullmatch(pattern,previous);return a is not None and b is not None and a.groups()==b.groups()
table_reports=[];table_mismatches=[];previous_mismatches=[];parent82_mismatches=[];line_count=exact_native=0
for old in prior['physical_formats']:
 ext=old['format'];sp=S/f'eplustbl.{ext}';np=checked(old['Native']);pp=checked(old['Source']);p82=P82/f'eplustbl.{ext}'
 sl,pl,nl,l82=sp.read_bytes().splitlines(keepends=True),pp.read_bytes().splitlines(keepends=True),np.read_bytes().splitlines(keepends=True),p82.read_bytes().splitlines(keepends=True)
 assert len(sl)==len(pl)==len(nl)==len(l82)
 for i,(s,p,n,previous82) in enumerate(zip(sl,pl,nl,l82),1):
  auth=metadata.get((ext,i))
  if s!=p:
   assert auth is not None and auth['classification'] in ['actual wall date','actual wall clock'] and typed_metadata(s,p,auth['classification'],ext,i)
   previous_mismatches.append(dict(format=ext,line=i,classification=auth['classification'],canonical11_complete_raw_hex=s.hex(),Source79_complete_raw_hex=p.hex()))
  if s!=previous82:
   assert auth is not None and auth['classification'] in ['actual wall date','actual wall clock'] and typed_metadata(s,previous82,auth['classification'],ext,i)
   parent82_mismatches.append(dict(format=ext,line=i,classification=auth['classification'],canonical11_complete_raw_hex=s.hex(),Source82_complete_raw_hex=previous82.hex()))
  if s!=n:
   assert auth is not None and n.hex()==auth['Native_complete_raw_hex'] and p.hex()==auth['Source_complete_raw_hex'] and typed_metadata(s,p,auth['classification'],ext,i)
   table_mismatches.append(dict(format=ext,line=i,classification=auth['classification'],canonical11_complete_raw_hex=s.hex(),Native_complete_raw_hex=n.hex()))
  else:exact_native+=1
 line_count+=len(sl);table_reports.append(dict(format=ext,canonical11=ref(sp),Source82=ref(p82),Source79=ref(pp),Native=ref(np),all_four_complete_line_counts=len(sl)))
assert line_count==19312 and len(table_mismatches)==70 and exact_native==19242
names=re.findall(rb'<!-- FullName:(.*?)-->',(S/'eplustbl.htm').read_bytes());assert len(names)==191 and [x.decode() for x in names]==prior['HTML_named_table_comments']
# No input/policy/Source file or output artifact is edited by this checker.
OUT.mkdir();samplep=OUT/'all5352-export-roundtrip-samples.jsonl';samplep.write_bytes(b''.join((json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode() for v in sample_evidence))
tablesp=OUT/'full-physical-table-metadata-differences.json';tablesp.write_bytes((json.dumps(dict(canonical11_vs_Native_all_uncapped=table_mismatches,canonical11_vs_Source82_all_uncapped=parent82_mismatches,canonical11_vs_Source79_all_uncapped=previous_mismatches),indent=2)+'\n').encode())
report=dict(
 schema='src06-canonical11-A24-own-completed-export-roundtrip.v1',accepted=True,findings=[],
 canonical_prepared_manifest=ref(mp),accepted_canonical_promotion_review=ref(preflight),complete_final_compiler_plan=M['complete_final_compiler_Source_plan'],
 accepted_actual82=M['accepted_actual82'],accepted_actual82_own_export_readback=M['accepted_own_file_export_readback'],
 actual_check=ref(checkp),actual_CLI=ref(clip),all4472_compiled_archived_live_planned_inputs_exact=True,Rust_sources=4459,selected_canonical_files=10,
 all_ten_canonical_proposals_exact=True,report_diagnostics_child_absent=True,all_six_nonselected_diagnostic_paths_whole_main_or_absent=True,
 diagnostic_sidecar_and_two_snapshots_absent=absent_diagnostics,compiler_artifact_rows=compiler,
 reported_bundle=ref(bundlep),accepted82_bundle=ref(parent_bundlep),whole_JSON_exact82_with_only_owned_path_field_bridge=owned_path_bridges,both_CSV_files_whole_exact82=True,
 run_summary=ref(summaryp),diagnostics=ref(S/'diagnostics.json'),streams=stream_evidence,JSON_CSV_scalar_roundtrips=5352,
 all5352_raw_tokens_bits_native_tuples_indices_and_physical_lines=ref(samplep),native_hour_scope=24,selected_native_environments=selected,
 Source_schema_separate_from_legacy=True,legacy_result_artifact_keys_and_files_absent=True,results_directory_contains_exact_three_Source_files=True,
 canonical11_physical_streams_whole82_and79_equal=physical_unchanged,
 full_tables=table_reports,full_table_lines=19312,exact_Native_table_lines=19242,metadata_difference_lines=70,complete_metadata_differences=ref(tablesp),HTML_named_tables=191,
 unchanged_original_tolerance_policy=ref(policy),prior_operational_A24_tolerance_audit=ref(tolp),prior_independent_tolerance_peer=ref(tolpeer),policy_metadata_notes=T['policy_metadata_notes'],
 numerical_observation='Exact same whole physical ESO/MTR as accepted82/79 operational audit:3536 unequal reported values remain within unchanged original named atols/RMSE. Serialization, native tuples and complete physical tables are verified; no new thresholds or whole15case/internal-bit conformance.',
 qualifications=['This checker requires stable actual main canonical check and explicit --porting-scope A CLI exit0 before any output read/write. It validates bounded A24 only.','Current output directory has precisely three Source results and no legacy result files or three quarantined observer artifacts. Root owns prelaunch unique-directory custody; no unseen prelaunch file state is inferred.','No B completion,default None-path execution,14 other case/duration comparisons,strict optional Source oracle comparator,internal unit-card or plan/card gate completion is claimed.','The binary64 diagnostic sidecar is intentionally absent. Whole physical output equality transfers the accepted reported-value tolerance observation without claiming unformatted internal-state bitwise identity.'],
 canonical_mutations=0,Cargo_Native_tests_executed_by_checker=False,new_test_bodies=0,Git_mutations=False,gate_changes=False,author_Source=ref(Path(__file__)))
p=OUT/'review.json';p.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(ref(p)))

"""Prepare a concise HELD publication template; no canonical/docs mutations."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3]; D=R/'.runtime/porting/SRC-06'
O=D/'canonical-source82-activation-publication-prepared-Audit-11'; assert not O.exists()
def ref(p):
 b=p.read_bytes(); return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=R/v['path']; assert ref(p)==v,v; return p
def load(p): return json.loads(p.read_bytes())
mp=D/'canonical-source82-completed-activation-prepared-Outer-11/manifest.json'; assert ref(mp)['sha256']=='40a16bb8e3fe5b5bbf62c6d00f4b3cbf3cad56ab3bf165996b89b5b7328ac274'; m=load(mp)
pp=D/'Audit-canonical-source82-completed-activation-Source-review-01/review.json'; assert ref(pp)['sha256']=='605b6956dd9bad742d65393c1f1b982f262a7cf9d40a4ad5fdb2e2f96beb3a4a'; peer=load(pp); assert peer['accepted'] and peer['findings']==[] and peer['manifest']==ref(mp)
publisher=D/'publish-canonical-source-activation-Audit-11-template.py'; ast.parse(publisher.read_text(encoding='utf8'))
checker=D/'check-canonical11-A24-export-roundtrip-Peer-01.py'; assert ref(checker)['sha256']=='b599ac84ab3b8987836b7e7279c0a4b6a673694b40dd6a5fe3d198ba7cbb4646'; ast.parse(checker.read_text(encoding='utf8'))
previous=R/'energyplus_porting_plan/evidence/SRC-06-canonical-completed-endrun-core-10/summary.json'; old=load(previous); assert (old['A'],old['B'])==('14/54','14/64')
tolp=D/'completed-A24-tolerance-identity-audit-Audit-02/audit.json'; assert ref(tolp)['sha256']=='3cd42ca127c9eef3edff9d38a127dfa0d63cf8edcb4bc9ccab31079240e379a4'; tol=load(tolp)
tp=D/'Peer-completed-A24-tolerance-identity-review-01/review.json'; assert ref(tp)['sha256']=='7bb564ccdb175c90b56ef71ed2bf0bad948abe4e2aea9ecb5b30851cd850731b'
assert tol['policy_changes']==0 and tol['totals']==dict(series=58,samples=5352,raw_operand_unequal=3536,parsed_binary64_unequal=3536,tolerance_failures=0,rmse_failures=0,all_declared_A24_reported_values_within_original_tolerances=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==m['base_HEAD']
plan=load(checked(m['complete_final_compiler_Source_plan'])); assert len(plan['entries'])==4472 and plan['final_Rust_sources']==4459
inputs={}
def add(p):
 r=ref(p); assert r['path'] not in inputs or inputs[r['path']]==r; inputs[r['path']]=r
def addref(r): add(checked(r))
for p in [Path(__file__),publisher,checker,mp,pp,previous,tolp,tp]: add(p)
for k in ['scope_plan','checks','complete_final_compiler_Source_plan','integration_contract','guarded_apply_Source','author_Source','accepted_actual82','accepted_own_file_export_readback']: addref(m[k])
for k in ['reviewer_Source','independent_compiler_plan']: addref(peer[k])
for k in ['policy','scope','detail','author_Source']: addref(tol[k])
for row in m['files']:
 for k in ['before','parent_before','proposed','complete_forward_diff','complete_inverse_diff','parent_forward_diff','parent_inverse_diff']: addref(row[k])
scope=load(checked(m['scope_plan']))
for row in scope['ancestry']['exact_observer_removal_spans']: addref(row['literal'])
for k in ['accepted_reader','accepted_path_accessor']: addref(scope['ancestry'][k])
for name in ['ordinary-source-reported-results-held-Audit-01/manifest.json','Outer-ordinary-source-reported-results-Source-review-01/review.json','ordinary-source-result-connector-held-Audit-02/manifest.json','Outer-ordinary-source-result-connector-typed-artifact-fix-Source-review-01/review.json','ordinary-source-reported-parser-index-fix-held-Audit-01/manifest.json','Peer-reported-parser-index-fix-Source-review-01/review.json','ordinary-source-reported-streaming-export-held-Outer-01/manifest.json','Audit-ordinary-source-reported-streaming-export-Source-review-02/review.json']: add(D/name)
O.mkdir()
def put(name,v):
 p=O/name; p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()); return ref(p)
summary=dict(
 status='HELD template; no new canonical check or actual run asserted',
 Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',
 prepared_promotion=ref(mp),independent_promotion_review=ref(pp),
 changed_Rust_files=10,new_Rust_files=5,existing_Rust_files=5,compiler_inputs=4472,Rust_sources=4459,literal_applications=40,
 dispatch='Existing explicit Some(A/B) selects Source after unchanged support admission. SomeA requires existing OneZone class; SomeB requires existing direct IdealLoads class. None retains canonical10 default. Source errors propagate without a Legacy retry.',
 real_sequence='Same retained raw InputProcessor, report/files/weather owners; actual primary, full endrun620, checked selected native Environment/TotalDays scope, same-owned completed ESO/MTR strict reader, immediate separate Source outcome before legacy schedule cache.',
 result_contract='Separate Source schema retains stream/report ID, key/name/units, frequency/StoreType, every actual native tuple, raw decimal operands, parsed f64 and bits, complete dictionary/end/footer/counters. No civil year, reset-accumulator history, profile result series, frequency collapse or reconstructed samples.',
 serialization='Borrowed streamed JSON and exact raw-token CSV; typed artifact-map failures. The existing optional Source oracle comparison flags return Unsupported after completed export, without a Native/Legacy fallback.',
 diagnostic_observer_paths_quarantined=9,diagnostic_new_child_absent='crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs',
 None_path_verification='Whole preparation and execution-startup inverse against canonical10; five existing legacy payloads/fixture and public helpers remain whole equal. This is Source preservation evidence, not a new None runtime execution.',
 canonical10_existing_CTF_test_section_whole_preserved=True,new_test_bodies=0,full_suite_rerun=False,
 accepted_isolated_Source82_A24= m['accepted_actual82'],
 canonical_A24_completed_Source_run=None,canonical_A24_reported_serialization_roundtrip=None,canonical_A24_original_named_tolerance_and_RMSE_PASS=None,production_explicit_scope_activation=None,
 original_A24_reported_tolerance_audit=ref(tolp),independent_original_tolerance_review=ref(tp),original_A24_reported_metrics=tol['totals'],original_tolerance_policy=tol['policy'],policy_metadata_notes=tol['policy_metadata_notes'],
 numeric_scope='Original named reported-value atol/rtol and per-series RMSE only. Existing3536 unequal reported operands are retained. This does not assert internal binary64 identity or complete literal descriptive policy-unit/timestep-type equivalence.',
 A='14/54',B='14/64',gate_changes=False,full15matrix_complete=False,B_completion_claim=False,internal_unit_card_completion_claim=False,
 retained_prior_whole_comparison=old['retained_whole_old_comparison'],retained_prior_whole_comparison_scope='Historical whole comparison remains retained; bounded new A24 reported-value success does not replace it or alter plan/card gates.',previous_checkpoint=ref(previous),
 remaining=['Actual remaining A/B case and duration gates, beginning with current SourceB raw-admission/positive equipment and NodeList branches.','Strict optional Source oracle comparator integration, with exact identities/native tuples and unchanged original policies.','Internal branch/unit/integration evidence and original full plan completion requirements.'],
 reconstruction='Finite ten Source before/accepted82 parent/proposed bodies and four literal diffs, complete4472 input plan, direct reviews/receipts and actual A24 raw output/export operands. Base Git plus command snapshot custody binds unchanged compiler inputs; no recursive historical checkpoint ZIP duplication or full transitive archive claim.')
template=put('publication-template.json',dict(schema='src06-held-canonical11-publication-template.v1',status='HELD_TEMPLATE_NO_CANONICAL_ACTUAL_CLAIM',prepared_promotion=ref(mp),independent_promotion_review=ref(pp),accepted_predecessor82=m['accepted_actual82'],original_A24_tolerance_audit=ref(tolp),independent_tolerance_review=ref(tp),previous_checkpoint=ref(previous),canonical_A24_checker_Source=ref(checker),publisher_Source=ref(publisher),finite_archive_inputs=[r for n,r in sorted(inputs.items())],finite_archive_input_count=len(inputs),finite_archive_input_bytes=sum(r['bytes'] for r in inputs.values()),summary_template=summary,publication_targets=['energyplus_porting_plan/evidence/SRC-06-canonical-completed-source-activation-11/summary.json','energyplus_porting_plan/evidence/SRC-06-canonical-completed-source-activation-11/manifest.json','energyplus_porting_plan/evidence/SRC-06-canonical-completed-source-activation-11/evidence.zip'],append_existing_docs=['energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/cards/SRC-06.md'],plan_add_only='tasks[SRC-06].canonical_completed_source_activation_11',validation_refs_contract=dict(canonical_check='Exact stable Root main all-targets workspace exit0 receipt ref',canonical_A24_review='Accepted Coil main A24 strict own-export checker review ref;0/4472/5352/19312 guards',independent_promotion_review=ref(pp),additional_case_reviews='Array of {case_id,review}; actual accepted refs only, no implicit duration or B success'),publisher_executed=False,canonical_or_docs_mutations=0,Cargo_Native_or_tests_executed=False,gate_changes=False,author_Source=ref(Path(__file__).resolve())))
print(json.dumps(template))

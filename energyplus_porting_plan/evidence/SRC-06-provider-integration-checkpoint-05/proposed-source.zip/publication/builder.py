"""Publish reproducible compiled proposed Sources; explicitly no production/Native PASS."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,difflib
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06'
WORK=BASE/'ordinary-provider-assembly-Root-42/workspace'
OUT=BASE/'provider-integration-publication-Root-06';assert not (OUT/'publication-readback.json').exists();OUT.mkdir(exist_ok=True)
PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-provider-integration-checkpoint-05';assert not PUBLIC.exists() or not any(PUBLIC.iterdir());PUBLIC.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=sha(b),size_bytes=len(b))
def read(r,base=ROOT):
    b=(base/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',r.get('size_bytes',len(b)));return b
def encoded(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)==b''
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='1d2c71b677d1c10d8e3c4ec55baea747690736e6'
receipt_path=WORK/'.runtime/porting/SRC-06/provider-assembly-typecheck-command-42-fresh-target/receipt.json';receipt=json.loads(receipt_path.read_bytes());assert receipt['exit_code']==0 and receipt['source_bytes_match_before_and_after']
snapshot=read(receipt['source_snapshot'],WORK);index=json.loads(snapshot);payloads={};files=[];newtests=0
for r in index['files']:
    path=r['historical_path'];b=read(r['archive'],WORK);assert len(b)==r['size_bytes'];actual=WORK/path;assert actual.read_bytes()==b
    original=ROOT/path;a=original.read_bytes()if original.exists()else b''
    if a==b:continue
    if path.endswith('.rs'):assert a.count(b'#[test]')==b.count(b'#[test]'),path
    proposed='proposed/'+path;inverse='before/'+path;patch='diffs/'+path+'.diff'
    payloads[proposed]=b;payloads[inverse]=a;payloads[patch]=''.join(difflib.unified_diff(a.decode('utf8').splitlines(True),b.decode('utf8').splitlines(True),fromfile='base/'+path,tofile='proposed/'+path)).encode()
    files.append(dict(path=path,base_absent=not original.exists(),before_sha256=sha(a),before_bytes=len(a),proposed_sha256=sha(b),proposed_bytes=len(b),proposal_entry=proposed,inverse_entry=inverse,complete_diff_entry=patch))
assert files
assembly=BASE/'ordinary-provider-assembly-Root-42/manifest.json'
payloads['metadata/assembly42-manifest.json']=assembly.read_bytes();payloads['metadata/compiled-source-index.json']=snapshot
payloads['commands/typecheck42/receipt.json']=receipt_path.read_bytes()
for name in ['stdout','stderr']:payloads['commands/typecheck42/'+name+'.log']=read(receipt[name],WORK)
reviews=[]
previous_public=json.loads((ROOT/'energyplus_porting_plan/evidence/SRC-06-provider-integration-checkpoint-04/summary.json').read_bytes())
review_paths=[r['path']for r in previous_public['independent_bounded_reviews']]
for number in [39,40,41,42]:
    am=json.loads((BASE/f'ordinary-provider-assembly-Root-{number}/manifest.json').read_bytes())
    review_paths += [r['path']for r in am['independent_reviews']]
review_paths += [
    '.runtime/porting/SRC-06/Reviewer-ordinary-utility-bills-Source-review-02/review.json',
    '.runtime/porting/SRC-06/Fix-ordinary-heat-balance-report-Source-review-01/review.json',
]
review_paths=list(dict.fromkeys(review_paths))
for name in [str(Path(path).parent.name)for path in review_paths]:
    p=BASE/name/'review.json';m=json.loads(p.read_bytes())
    known_decisions={
        'Fix-ordinary-air-provider-Source-review-01':'ACCEPTED within declared ordinary bounded child scope',
        'Fix-ordinary-node-report-Source-review-02':'ACCEPTED within same bounded zero-node and successful standard-condition child scope',
    }
    assert m.get('accepted') is True or str(m.get('verdict','')).startswith('ACCEPTED bounded') or (name in known_decisions and m.get('decision')==known_decisions[name] and not m['findings'])
    payloads['reviews/'+name+'.json']=p.read_bytes();reviews.append(ref(p))
for number in [39,40,41]:
    q=BASE/f'ordinary-provider-assembly-Root-{number}/manifest.json'
    payloads[f'metadata/assembly{number}-manifest.json']=q.read_bytes()
    cw=BASE/f'ordinary-provider-assembly-Root-{number}/workspace'
    rp=cw/f'.runtime/porting/SRC-06/provider-assembly-typecheck-command-{number}-fresh-target/receipt.json'
    cr=json.loads(rp.read_bytes());assert cr['exit_code']==0 and cr['source_bytes_match_before_and_after']
    payloads[f'commands/previous{number}/receipt.json']=rp.read_bytes()
for name in ['Root-ordinary-output-attachment-Source-review-01','Root-ordinary-output-attachment-Source-review-02']:
    payloads['reviews/retained-history/'+name+'.json']=(BASE/name/'review.json').read_bytes()
assert json.loads((BASE/'Root-ordinary-output-attachment-Source-review-02/review.json').read_bytes())['accepted']is False
fixtures=['energyplus_porting_plan/cases/A-24H/input.idf','energyplus_porting_plan/cases/CLK-03/decoy-three-days.epw','energyplus_porting_plan/cases/CLK-03/missing-target-complete-days.epw','scripts/quality/ideal-loads-structure-audit/cp424-cooling-supply-mass-flow-positive-guard-else-branch-entry.ps1']
for path in fixtures:assert (ROOT/path).read_bytes()==(WORK/path).read_bytes()
payloads['metadata/proposal-map.json']=encoded(dict(schema='src06-compiled-proposal-reconstruction.v1',base_HEAD=head,Original_commit='6f2e40d10250a105b49966baa24d843711e61048',compiled_SourceSnapshot_sha256=sha(snapshot),files=files,compile_external_fixtures=[ref(ROOT/p)for p in fixtures],limits='Proposed integration only; no production activation or same-input Native numerical proof. Other unchanged Source files reconstruct from base HEAD. Same Source scope checked before/after.'))
payloads['REPRODUCE.txt']=b'''This archive contains compiled PROPOSED integration Sources, not production activation.
Use a separate checkout of base commit1d2c71b677d1c10d8e3c4ec55baea747690736e6.
Overlay only proposed/ entries onto their canonical relative paths in that checkout.
metadata/proposal-map.json includes SHA256/bytes, full inverses and complete diffs.
metadata/compiled-source-index.json identifies every recorded compiler Source input.
Use a fresh CARGO_TARGET_DIR for an independent compile (avoid another checkout cache).
Run: cargo check --manifest-path Cargo.toml --locked -p ep_runtime -p ep_run -p ep_cli --all-targets
Compilation checks types and existing test targets; it executes no test bodies.
The retained source helpers have inactive-code warnings pending actual caller activation.
No four-card gate or numerical counter is increased by this checkpoint.
'''
failed=BASE/'ordinary-provider-assembly-Root-34/workspace/.runtime/porting/SRC-06/provider-assembly-typecheck-command-34-fresh-target'
for name in ['receipt.json','stderr.log']:
    payloads['commands/previous34-failed/'+name]=(failed/name).read_bytes()
payloads['publication/builder.py']=Path(__file__).resolve().read_bytes()
archive=PUBLIC/'proposed-source.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,b in sorted(payloads.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b,compresslevel=9)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and sorted(z.namelist())==sorted(payloads)
    for name,b in payloads.items():assert z.read(name)==b
summary=dict(schema='src06-proposed-provider-integration-compile-checkpoint.v1',status='COMPILED PROPOSED INTEGRATION; production/Native verification incomplete',base_HEAD=head,Original_pinned_HEAD='6f2e40d10250a105b49966baa24d843711e61048',archive=ref(archive),archive_CRC_and_all_payload_SHA_bytes_readback=True,archive_entries=len(payloads),changed_Source_files=len(files),changed_Source_proposed_bytes=sum(r['proposed_bytes']for r in files),whole_compiler_Source_files=len(index['files']),compiled_SourceSnapshot_sha256=sha(snapshot),isolated_union=ref(assembly),compiler_receipt=ref(receipt_path),compiler_command=receipt['command'],compiler_exit_code=0,compiler_elapsed_seconds=receipt['elapsed_seconds'],source_bytes_match_before_and_after=True,independent_bounded_reviews=reviews,compiler_runtime_warnings=int(__import__('re').search(r'`ep_runtime` \(lib\) generated (\d+) warnings',read(receipt['stderr'],WORK).decode()).group(1)),compiler_warning_scope="Inactive pending caller activation plus unused/import/style warnings; warnings are not suppressed",new_test_bodies=0,test_bodies_executed=0,new_Native_runs=0,new_numerical_comparisons=0,
    implemented_proposed_connections=['Concrete Surface-to-Air-to-HVAC calls and real stateless remaining-child router; direct live normal SimElec and dummy update calls, no copied state.', 'Genuine SimHVAC zero Plant/SetPoint/Availability/ZoneEquipment/NonZone/WaterUse/WaterManager/AirLoop/DOAS state and operation order.', 'Full temperature-oscillation numeric/report declaration path and sole zone-list/group load owner; actual resource/Plant/Cogeneration/Carbon Equivalent meter functions and typed generic predefined cause.', 'Fresh same-owner CTF/Solar InitHeatBalance providers; accepted lifecycle26 Air outputs and actual typed output identities.','Same-owner HVAC orchestration and actual zero-input simple airflow getters/reset operations; mandatory unresolved children remain explicit.','Real thermal history same-owner bridge with unchanged10777-byte scientific tail and same actual Area.','Genuine Exterior:Lights raw/shared getter, schedule/control/astronomical producer and same live electricity meter bindings; real default electric center and eleven outputs. Full TAB input/unit/TOC/date and empty monthly first-call path.','Actual Node-report zero route, real Demand/Ice/EIR/PlantHistory postlude and live Pollution energy meter/kernel; surface output borrow change completes all54 existing consumer references.','Actual SystemReports initialization/ventilation/System energy, full zero-simple-air ReportAir expressions, heat-emission traversals and sole contaminant-array per-call ownership.','Same live Schedule currentVal target and genuine registration/update leaf; actual empty Monthly/Annual/Bin then BEPS/source-factor/end-use/peak-demand gathers use actual completed meter CurTSValue.','Actual System/Zone OutputProcessor period accumulation, normal meter reports/reset, same unconditional RF meter frames and finite Milo formatting.','Genuine weather Site:Location local getter, actual43-field EnvironmentData ctor, standard-condition producer, shared OP report headers and unopened first-weather prefix with mandatory missing children.','Actual meter requests/shared dictionary+MTD setup, same OutputProcessor/Results/ESO/MTR owner attachment and corrected temporary MTD borrow.', 'Actual39 weather outputs and same-clock solar illuminance/efficacy producer; complete heat-gain and actual second heat-emission gather on true BuildingPreDefRep.', 'Actual ManageSimulation183-204 reporting/PostIP/flag order plus same raw TAB input and reusable System/Zone child.', 'Full callable ReportHeatBalance schedule/normal/warmup/external branches, true nullable sizing-log guard and genuine zero-tariff/Currency111 initialization; actual ManageHB/session remains pending.'],
    remaining=['Actual runtime owner/session attachment and active ManageHeatBalance/Surface/Air/HVAC/Report/Warmup caller path.','Genuine physical weather Open/full ReadUserWeatherInput/environment/suffix and remaining positive child paths.','Fresh same-input/state Native A/B, active nonzero/boundary/multiple timestep scientific validation.'],card_gates_updated=False,A_completed=14,A_total=54,B_completed=14,B_total=64,retained_whole_comparison='FAIL:235456 mismatches;2754 unavailable/unpaired boundaries; unchanged',production_behavior_changed_by_publication=False)
p=PUBLIC/'summary.json';p.write_bytes(encoded(summary));public_ref=ref(p)
plan=ROOT/'energyplus_porting_plan/plan.json';oldplan=plan.read_bytes();m=json.loads(oldplan);gatekeys=['scope_review','unit_gate','integration_gate','production_gate'];oldgates=[{k:r.get(k)for k in gatekeys}for r in m['tasks']]
row=next(r for r in m['tasks']if r['id']=='SRC-06');assert row['held_provider_compilation_checkpoint']['path']=='energyplus_porting_plan/evidence/SRC-06-provider-integration-checkpoint-04/summary.json';row['held_provider_compilation_checkpoint_previous']=row['held_provider_compilation_checkpoint'];row['held_provider_compilation_checkpoint']=public_ref
assert oldgates==[{k:r.get(k)for k in gatekeys}for r in m['tasks']];(OUT/'plan-before.json').write_bytes(oldplan);plan.write_bytes(encoded(m))
paragraph='[호출 연결 중간 체크포인트](evidence/SRC-06-provider-integration-checkpoint-05/summary.json)는 검토한 제안 코드와 재현용 ZIP을 보존한다. 실제 미터 요청·사전·MTD 기록, 동일한 출력 파일·Results 소유자, 날씨 출력 39개와 조도·발광효율, 실제 건물 열취득·열배출 집계, ManageSimulation의 초기 보고·PostIP 순서 및 System/Zone 집계 호출을 통합했다. 열수지 보고의 스케줄·일반·warmup·외부 인터페이스 분기와 실제 nullable sizing 로그 조건, 요금 없음 분기 및 통화 111개 초기화도 포함한다. 같은 동결 소스에서 runtime·run·CLI와 기존 테스트 대상 전체의 컴파일을 통과했다. 컴파일 뒤 발견한 실제 MTD 이중 빌림 문제와 거절·수정 검토를 함께 보존한다. 새 테스트 본문·테스트 실행·Native 실행·수치 비교는 없다. 실제 ManageHeatBalance·세션 및 전체 A/B 실행 연결은 미완료이며 네 gate·A14/54·B14/64 및 기존 수치 FAIL는 유지한다.'
for rel in ['energyplus_porting_plan/STATE_CONTRACTS.md','energyplus_porting_plan/CHECKLIST.md','energyplus_porting_plan/cards/SRC-06.md']:
    path=ROOT/rel;a=path.read_bytes();(OUT/path.name).write_bytes(a)
    lines=a.decode('utf8').splitlines(True)
    matches=[i for i,line in enumerate(lines) if 'SRC-06-provider-integration-checkpoint-04/summary.json' in line]
    assert len(matches)==1,rel
    new=paragraph.replace('(evidence/','(../evidence/') if '/cards/' in rel else paragraph
    lines[matches[0]]=new+'\n';path.write_text(''.join(lines),encoding='utf8',newline='\n')
(OUT/'publication-readback.json').write_bytes(encoded(dict(summary=public_ref,archive=ref(archive),all_payloads=len(payloads),Source_files=len(files),whole_gate_states_unchanged=True,author_Source=ref(Path(__file__).resolve()))))
print(json.dumps(dict(summary=public_ref,archive=ref(archive),Source_files=len(files),entries=len(payloads),snapshot_files=len(index['files']))))

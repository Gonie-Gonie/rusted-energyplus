from pathlib import Path
import ast, hashlib, json, re, subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.runtime/porting/SRC-06/Root-canonical69-selective-promotion-review-01'
assert not OUT.exists()
OUT.mkdir()

def sha(b): return hashlib.sha256(b).hexdigest()
def checked(ref):
    b = (ROOT / ref['path']).read_bytes()
    assert len(b) == ref['bytes'] and sha(b) == ref['sha256'], ref['path']
    return b

parser = ast.parse((ROOT / '.runtime/porting/SRC-06/review-meter-final-predefined-Root-01.py').read_text(encoding='utf-8'))
fn = next(n for n in parser.body if isinstance(n, ast.FunctionDef) and n.name == 'apply')
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<independent-literal-apply>', 'exec'))
mp = ROOT / '.runtime/porting/SRC-06/canonical-source69-selective-promotion-prepared-Fix-02/manifest.json'
m = json.loads(mp.read_bytes())
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == m['base_HEAD']
for key in ['Source69_manifest', 'actual69_receipt', 'actual69_snapshot', 'complete_compiler_Source_plan', 'literal_applications', 'readonly_current_Git', 'unexecuted_Root_apply_script']:
    checked(m[key])
for ref in m['independent_packet_peers']: checked(ref)
c = json.loads(checked(m['complete_compiler_Source_plan']))
rows = {e['canonical_path']: e for e in m['files']}
assert len(rows) == 20 and sum(e['before_absent'] for e in rows.values()) == 8
literal_apps = 0
for path, e in rows.items():
    a, b = checked(e['before']), checked(e['proposed'])
    assert checked(e['literal_inverse']) == a
    assert apply(a, checked(e['forward_diff'])) == b
    assert apply(b, checked(e['inverse_diff'])) == a
    literal_apps += 2
    actual = checked(e['actual69_source'])
    assert actual == checked(e['actual69_archive'])
    if path.endswith('/pipeline.rs'):
        assert not e['copy_exact_actual69']
        assert a.count(b'.initialize_input_processor(input)') == 1
        assert a.replace(b'.initialize_input_processor(input)', b'.initialize_source_input_processor(input)', 1) == b
    else: assert e['copy_exact_actual69'] and actual == b
assert len(c['files']) == 4421 and len({e['path'] for e in c['files']}) == 4421
for e in c['files']:
    p = ROOT / e['path']
    if e['before_absent']: assert not p.exists()
    else:
        old = p.read_bytes()
        assert len(old) == e['before_bytes'] and sha(old) == e['before_sha256']
    planned = checked(rows[e['path']]['proposed']) if e['path'] in rows else p.read_bytes()
    assert sha(planned) == e['planned_sha256'] and len(planned) == e['planned_bytes']
    actual = (ROOT / '.runtime/porting/SRC-06/ordinary-provider-assembly-Root-69/workspace' / e['path']).read_bytes()
    assert sha(actual) == e['actual69_sha256']
    if e['path'] != 'crates/ep_run/src/pipeline.rs': assert planned == actual
    assert e['selected'] == (e['path'] in rows)
script = checked(m['unexecuted_Root_apply_script']).decode()
assert 'parents[4]' in script and 'os.replace' in script and '--apply' in script
ast.parse(script)
result = dict(status='PASS: independent complete before/proposed/actual69 census and literal inversion; apply/QA remain separate', prepared_manifest_sha256=sha(mp.read_bytes()), base_HEAD=m['base_HEAD'], unique_Source_paths=20, new_Source_paths=8, existing_Source_paths=12, compiler_inputs=4421, nonpipeline_inputs_exact_actual69=4420, literal_applications=literal_apps, canonical_pipeline_only_method_extension=True, clean_before=True, writes_to_canonical=False, Cargo_or_Native_or_Git_mutation=False)
(OUT / 'review.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))

"""Publish bounded input statistics and real tabular file creation, without activating held diagnostics."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/porting/SRC-06'
WORK = BASE / 'ordinary-provider-assembly-Root-69/workspace'
PUBLIC = ROOT / 'energyplus_porting_plan/evidence/SRC-06-canonical-input-statistics-tabular-05'
assert not PUBLIC.exists()
payload = {}

def ref(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b))

def add(p):
    p = p.resolve()
    key = p.relative_to(ROOT).as_posix()
    b = p.read_bytes()
    assert key not in payload or payload[key] == b
    payload[key] = b
    return ref(p)

def add_ref(r, base=ROOT):
    p = base / r['path']
    b = p.read_bytes()
    assert hashlib.sha256(b).hexdigest() == r['sha256'] and len(b) == r.get('bytes', len(b))
    return add(p)

prepared = BASE / 'canonical-source69-selective-promotion-prepared-Fix-02/manifest.json'
assert ref(prepared)['sha256'] == 'a993b802bdf55f7661183b37c68c39a279e00dc273df6bbad0984341cb03e505'
m = json.loads(prepared.read_bytes())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == m['base_HEAD']
add(prepared)
add(Path(__file__).resolve())
for key in ['Source69_manifest', 'actual69_receipt', 'actual69_snapshot', 'complete_compiler_Source_plan', 'literal_applications', 'readonly_current_Git', 'unexecuted_Root_apply_script']:
    add_ref(m[key])
for r in m['independent_packet_peers']: add_ref(r)
for row in m['files']:
    add_ref(row['proposed'])
    assert (ROOT / row['canonical_path']).read_bytes() == (ROOT / row['proposed']['path']).read_bytes()
    for key in ['before', 'literal_inverse', 'forward_diff', 'inverse_diff']: add_ref(row[key])
    add(ROOT / row['canonical_path'])
review = BASE / 'Root-canonical69-selective-promotion-review-01/review.json'
add(review)
add(BASE / 'review-canonical69-selective-promotion-Root-01.py')
actual_peer = BASE / 'Audit-ordinary-provider-union69-Source-and-frontier-review-01/review.json'
assert ref(actual_peer)['sha256'] == 'cd2bcc0d1235d516868ee2b061a189f2fa525a49409ed1c22b34690c7a811704'
ap = json.loads(actual_peer.read_bytes())
assert ap['accepted']
add(actual_peer)
add_ref(ap['actual_frontier_ledger'])
add_ref(ap['reviewer_Source'])
actual = json.loads((ROOT / m['actual69_receipt']['path']).read_bytes())
assert actual['exit_code'] == 6 and actual['source_bytes_match_before_and_after']
for key in ['stdout', 'stderr', 'source_snapshot']: add_ref(actual[key], WORK)
out = BASE / 'through-primary-diagnostic-A-24H-Root-69/output'
for name in ['diagnostics.json', 'run-summary.json', 'eplusrs.ctf.log', 'eplusrs.eio', 'eplustbl.csv', 'eplustbl.tab', 'eplustbl.txt', 'eplustbl.htm', 'eplustbl.xml', 'logs/source-input-statistics.json']:
    add(out / name)
qa_path = BASE / 'canonical-source69-existing-arbitrary-run-tests-Root-05-8MiB/receipt.json'
qa = json.loads(qa_path.read_bytes())
assert qa['exit_code'] == 0 and qa['source_bytes_match_before_and_after']
add(qa_path)
for key in ['stdout', 'stderr', 'source_snapshot']: add_ref(qa[key])
qstdout = (ROOT / qa['stdout']['path']).read_text(encoding='utf-8')
assert '27 passed; 0 failed' in qstdout and '8388608' in qstdout
add(BASE / 'run-with-explicit-test-stack-Root-01.py')
prior = ROOT / 'energyplus_porting_plan/evidence/SRC-06-canonical-thermal-weather-04/summary.json'
assert ref(prior)['sha256'] == '0e8ae1b4406bf1892f623a97ac996b3a7f80f7813d5407ab6da3eb9df7812bb6'
PUBLIC.mkdir()
z = PUBLIC / 'evidence.zip'
with zipfile.ZipFile(z, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for key, b in sorted(payload.items()):
        item = zipfile.ZipInfo(key, date_time=(2026, 10, 17, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(item, b)
with zipfile.ZipFile(z) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(payload)
    for key, b in payload.items(): assert archive.read(key) == b
summary = dict(
    schema='src06-canonical-input-statistics-tabular.v1',
    status='Genuine input statistics and report prerequisites integrated; held Source actual creates five header-only files and stops at WriteTabularReports596',
    Original_version='26.1.0', Original_commit='6f2e40d10250a105b49966baa24d843711e61048', base_HEAD=head,
    prepared_selective_promotion=ref(prepared), independent_promotion_review=ref(review),
    changed_Rust_files=20, new_Rust_files=8, existing_Rust_files=12, compiler_inputs=4421,
    canonical_pipeline_policy=m['canonical_pipeline_policy'], nonpipeline_compiler_inputs_exact_actual69=4420,
    actual_command=m['actual69_receipt'], independent_Source_and_actual_peer=ref(actual_peer),
    canonical_existing_tests=ref(qa_path), existing_tests_passed=27, test_stack_bytes=8388608,
    new_test_bodies=0, full_suite_rerun=False, evidence_archive=ref(z),
    archive_files=[dict(path=k, sha256=hashlib.sha256(b).hexdigest(), bytes=len(b)) for k, b in sorted(payload.items())],
    scope=[
        'Raw selected input lexical values, field presence and exact schema defaults/Autosize/Autocalculate metadata feed the original322 seven counters before later query mutation. No expected counters are supplied.',
        'All seven actual A-24H integer counters match the existing same-input Native CSV exactly: 96,25,241,0,0,3,15. This is a finite observed unit comparison.',
        'The actual held Source traversal now executes the original endrun566-592 prefix and OpenTabular594 on the same session/files/reports. Five physical CSV/TAB/TXT/HTML/XML initial headers are written.',
        'Rainfall report Source is integrated but not yet called: original FillWeather5212 and FillRemaining5213 must precede Rainfall5214.',
        'Canonical pipeline receives only the genuine input-statistics initializer method name. Held through-primary dispatch and readonly observer are excluded.'
    ],
    numeric_observation='Actual69 ESO/MTR/EIO are whole-byte identical to68 and67. The existing reported comparison still has3536/5280 unequal ESO parsed binary64 values;72 MTR values match. No tolerance or new numerical PASS.',
    previous_reported_comparison=ref(prior),
    remaining=['FillWeather/FillRemaining/Rainfall and later tabular bodies; physical endrun closes and completed Source exporter.', 'Canonical genuine dispatcher activation and same-input/state numerical parity; remaining A/B input and owner domains.'],
    reconstruction='Git holds all20 canonical Sources. Compact archive binds proposals, before/diffs, complete compiled hash census, actual receipt/output headers, existing-test receipt and independent reviews. No new complete offline replay claim.',
    completed_Source_run_or_export=False, whole_Native_numeric_PASS=False, pipeline_activation=False,
    gate_changes=False, A='14/54', B='14/64', retained_whole_old_comparison=dict(mismatches=235456, required_unavailable_or_unpaired=2754),
    author_Source=ref(Path(__file__).resolve()))
s = PUBLIC / 'summary.json'
s.write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8', newline='\n')
relative = 'evidence/SRC-06-canonical-input-statistics-tabular-05/summary.json'
paragraph = '입력 원시 필드와 스키마 메타데이터로 원본 입력 통계 7개를 계산하도록 연결했습니다. 실제 A-24H 통계 7개는 동일 입력의 Native 출력과 일치합니다. 종료 보고 선행 단계와 실제 표 파일 열기를 반영했으며, 진단 실행은 CSV·TAB·TXT·HTML·XML의 초기 헤더를 생성한 뒤 596번 날씨 통계 보고 진입 전 미구현 경계에서 exit6으로 끝납니다. 강우 보고는 원본의 날씨·나머지 보고 순서를 기다리므로 아직 실행되지 않았습니다. 기본 파이프라인은 입력 통계 초기화 호출만 갱신했고 진단 경로는 전환하지 않았습니다. 관련 기존 테스트 27개는 원래 8MiB 설정에서 통과했으며 새 테스트와 전체 테스트 반복은 없습니다. ESO·MTR·EIO는 직전 진단과 바이트까지 같아 기존 수치 차이가 유지됩니다. 전체 실행·수치 동등성·카드 완료를 뜻하지 않으며 A14/54·B14/64와 기존 전체 FAIL은 유지합니다.'
for name in ['CHECKLIST.md', 'STATE_CONTRACTS.md', 'cards/SRC-06.md']:
    p = ROOT / 'energyplus_porting_plan' / name
    text = p.read_text(encoding='utf-8')
    assert 'canonical-input-statistics-tabular-05' not in text
    link = '../'+relative if name.startswith('cards/') else relative
    text += '\n\n[입력 통계와 실제 표 파일 생성 검증]('+link+'). '+paragraph+'\n'
    p.write_text(text, encoding='utf-8', newline='\n')
p = ROOT / 'energyplus_porting_plan/plan.json'
before = json.loads(p.read_bytes())
after = json.loads(p.read_bytes())
task = next(t for t in after['tasks'] if t['id'] == 'SRC-06')
key = 'canonical_input_statistics_tabular_05'
assert key not in task
task[key] = dict(path=s.relative_to(ROOT).as_posix(), sha256=ref(s)['sha256'], size_bytes=s.stat().st_size)
check = json.loads(json.dumps(after))
del next(t for t in check['tasks'] if t['id'] == 'SRC-06')[key]
assert check == before
p.write_text(json.dumps(after, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(ref(s)))
print(json.dumps(ref(z)))
print('archive_entries', len(payload))

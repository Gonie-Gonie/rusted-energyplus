"""ROOT-ONLY explicit apply of the exact prepared Source69 promotion; no tests or Git mutations."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
if sys.argv[1:]!=["--apply"]:raise SystemExit("Prepared only. Root may run with explicit --apply after review.")
plan=json.loads((HERE/"manifest.json").read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(ref):
 p=ROOT/ref["path"];b=p.read_bytes()
 assert sha(b)==ref["sha256"] and len(b)==ref["bytes"]
 return b
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT).decode().strip()==plan["base_HEAD"]
scope=json.loads(checked(plan["complete_compiler_Source_plan"]))
for e in scope["files"]:
 p=ROOT/e["path"];assert p.resolve().is_relative_to(ROOT.resolve())
 assert (not p.exists()) if e["before_absent"] else (p.exists() and sha(p.read_bytes())==e["before_sha256"] and len(p.read_bytes())==e["before_bytes"])
for row in plan["files"]:
 checked(row["before"]);checked(row["proposed"]);checked(row["literal_inverse"])
for row in plan["files"]:
 p=ROOT/row["canonical_path"];assert p.resolve().is_relative_to(ROOT.resolve())
 p.parent.mkdir(parents=True,exist_ok=True)
 temporary=p.with_name(p.name+".source69-promotion-tmp")
 assert temporary.resolve().is_relative_to(ROOT.resolve()) and not temporary.exists()
 temporary.write_bytes(checked(row["proposed"]))
 os.replace(temporary,p)
for e in scope["files"]:
 p=ROOT/e["path"];assert sha(p.read_bytes())==e["planned_sha256"] and len(p.read_bytes())==e["planned_bytes"]
print(json.dumps({"applied_Source_paths":len(plan["files"]),"new_Source":plan["new_Source_files"],"existing_Source":plan["existing_Source_files"],"canonical_pipeline_only_statistics_method_token":True,"tests_or_Git_mutations":False}))

"""Expose the exact inherited test-stack setting in recorded QA stdout."""
import argparse,json,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--bytes',type=int,required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
assert a.bytes>0 and a.command
os.environ['RUST_MIN_STACK']=str(a.bytes)
print(json.dumps(dict(test_process_environment=dict(RUST_MIN_STACK=os.environ['RUST_MIN_STACK']),command=a.command,scope='Explicit existing stack setting; no source/config/test-body changes')),flush=True)
raise SystemExit(subprocess.call(a.command,env=os.environ.copy()))

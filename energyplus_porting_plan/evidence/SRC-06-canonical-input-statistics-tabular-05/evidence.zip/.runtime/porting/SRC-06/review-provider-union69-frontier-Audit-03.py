from pathlib import Path
import ast,csv,hashlib,json,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();B=R/'.runtime/porting/SRC-06';MP=B/'ordinary-provider-assembly-Root-69/manifest.json';O=B/'Audit-ordinary-provider-union69-Source-and-frontier-review-01';assert not O.exists()
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def get(d,base=R):
 b=(base/d['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==d['sha256'],d['path'];assert len(b)==d.get('bytes',len(b));return b
def visit(v):
 if isinstance(v,dict):
  if {'path','sha256'}<=v.keys():get(v)
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
assert ref(MP)['sha256']=='48f6ab5c206616146e35e924e71423a7c5d04a6bb192ca2c7c46ec35d33f1fa5'
M=json.loads(MP.read_bytes());visit(M);W=R/M['workspace'];P=json.loads(get(M['parent']));PW=R/P['workspace']
packets={r['path']:json.loads(get(r))for r in M['packets']}
for r in M['independent_reviews']:
 d=json.loads(get(r));assert d.get('accepted',str(d.get('decision',d.get('status',''))).startswith('ACCEPTED'))and not d.get('findings',[])
tree=ast.parse((B/'seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));ns={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='apply_diff'],type_ignores=[]),'<literal-diff>','exec'),ns)
apps=0
for packet in packets.values():
 visit(packet)
 for r in packet['files']:
  a=get(r['before']);pa=get(r['parent_before']);z=get(r['proposed']);assert get(r['literal_inverse'])==a and get(r['literal_parent_inverse'])==pa
  for fk,ik,base in [('complete_forward_diff','complete_inverse_diff',a),('parent_forward_diff','parent_inverse_diff',pa)]:
   assert ns['apply_diff'](base,get(r[fk]))==z and ns['apply_diff'](z,get(r[ik]))==base;apps+=2
  assert a.count(b'#[test]')==z.count(b'#[test]')
selected={};pipeline='crates/ep_run/src/pipeline.rs';old=b'.initialize_input_processor(input)';new=b'.initialize_source_input_processor(input)'
for stage in M['composition']:
 n=stage['path'];a=get(stage['packet_parent_before']);z=get(stage['packet_proposed']);original=(PW/n).read_bytes()if(PW/n).exists()else b'';current=selected.get(n,original)
 assert hashlib.sha256(current).hexdigest()==stage['current_before_sha256'] and stage['conflicts']==0 and stage['normalization']=='none'
 if stage['packet_role']=='statistics'and n==pipeline:
  assert a.count(old)==original.count(old)==1 and z==a.replace(old,new,1);merged=original.replace(old,new,1)
 elif stage['packet_role']=='observer594'and n==pipeline:
  marker=b'                // HELD diagnostic observer: after actual Native322 succeeds,';assert z.count(marker)==1
  start=z.index(marker);end=z.index(b'            }\n            initialization.reports.heat_balance_input',start)
  assert a==original and z[:start]+z[end:]==current;merged=z
 else:
  assert a==current,(stage['packet_role'],n);merged=z
 assert hashlib.sha256(merged).hexdigest()==stage['merged_sha256'];selected[n]=merged
assert len(M['composition'])==18 and len(selected)==len(M['files'])==17
for r in M['files']:
 n=r['canonical_path'];a=get(r['before']);z=get(r['proposed']);assert z==selected[n]==(W/n).read_bytes()and get(r['literal_inverse'])==a
 assert (a==b''and not(PW/n).exists())if r['before_absent']else a==(PW/n).read_bytes()
 assert ns['apply_diff'](a,get(r['forward_diff']))==z and ns['apply_diff'](z,get(r['inverse_diff']))==a;apps+=2
assert apps==M['literal_application_count']==106
RP=W/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-69/receipt.json';assert ref(RP)['sha256']=='15fc415cf4a1b40c99957e611bca5b3b5f282fd9222ea99f4210b8ad062a49ba';Q=json.loads(RP.read_bytes());assert Q['exit_code']==6 and Q['launch_error']is None and Q['source_bytes_match_before_and_after'] and Q['repository_before']==Q['repository_after']
snap=json.loads(get(Q['source_snapshot'],W));sr={r['historical_path']:r for r in snap['files']};C=json.loads(get(M['compiler_Source_census']));cr={r['path']:r for r in C['files']};assert cr.keys()==sr.keys()and len(sr)==4421 and not snap['bytes_normalized']
ps=json.loads(get(C['parent_recorded_snapshot']));psr={r['historical_path']:r for r in ps['files']};assert len(psr)==4415 and not set(psr)-set(sr)
all_live={};existing=[];fresh=sorted(set(sr)-set(psr));shared=0;separate=[]
for n,r in sr.items():
 z=get(r['archive'],W);assert len(z)==r['size_bytes']==cr[n]['bytes69'] and z==(W/n).read_bytes()and hashlib.sha256(z).hexdigest()==cr[n]['assembled69_sha256'];all_live[n]=z
 if n in psr:
  a=get(psr[n]['archive'],PW);assert a==(PW/n).read_bytes()and hashlib.sha256(a).hexdigest()==cr[n]['parent68_sha256']and cr[n]['parent68_preserved_after_overlay']
  if a!=z:
   existing.append(n);assert(PW/n).stat().st_ino!=(W/n).stat().st_ino
  elif(PW/n).stat().st_ino==(W/n).stat().st_ino:shared+=1
  else:separate.append(n)
for n in fresh:assert(W/n).stat().st_nlink==1
assert sorted(existing)==sorted(C['existing_changed'])and fresh==sorted(C['new_paths'])and len(existing)==11 and len(fresh)==6
assert shared==C['shared_unchanged_file_ids']==4401 and sorted(separate)==sorted(C['separate_unchanged_root_configs'])==['Cargo.lock','Cargo.toml','rust-toolchain.toml']
assert sum(n.endswith('.rs')for n in sr)==4408 and{p.relative_to(W).as_posix()for p in(W/'crates').rglob('*.rs')}=={n for n in sr if n.endswith('.rs')}
q=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True);head=q.stdout.decode().strip();assert head==M['base_HEAD']
git=[]
for n in selected:
 p=R/n;q=subprocess.run(['git','show',f'{head}:{n}'],capture_output=True)
 assert q.returncode==(0 if p.exists()else 128)
 if p.exists():assert q.stdout==p.read_bytes()
 git.append({'path':n,'revision':head,'exit_code':q.returncode,'sha256':hashlib.sha256(q.stdout).hexdigest(),'bytes':len(q.stdout)})
out=B/'through-primary-diagnostic-A-24H-Root-69/output';oldout=B/'through-primary-diagnostic-A-24H-Root-68/output'
diagp=out/'diagnostics.json';diag=json.loads(diagp.read_bytes());errors=[d for d in diag['diagnostics']if d['severity']=='error'];frontier='selected heat-balance input unavailable: actual endrun WriteTabularReports596 entry before FillWeather';assert len(errors)==1 and errors[0]['message']==frontier
stdout=get(Q['stdout'],W);stderr=get(Q['stderr'],W);assert b'Finished `dev` profile'in stderr and b'Running `'in stderr and b'error[E'not in stderr
physics=[]
for name in ['eplusrs.eso','eplusrs.mtr','eplusrs.eio']:
 assert(out/name).read_bytes()==(oldout/name).read_bytes();physics.append({'Source69':ref(out/name),'Source68':ref(oldout/name),'whole_bytes_equal':True})
for name in ['original.idf','converted.epJSON']:assert(out/'input'/name).read_bytes()==(oldout/'input'/name).read_bytes()
assert(out/'input/original.idf').read_bytes()==(R/'energyplus_porting_plan/cases/A-24H/input.idf').read_bytes()
before=(oldout/'eplusrs.ctf.log').read_bytes();after=(out/'eplusrs.ctf.log').read_bytes();assert after.startswith(before)
added=after[len(before):].decode('utf8').splitlines();expected=['Writing tabular output file results using '+v+' format.'for v in ['comma','tab','text','HTML','XML']];assert added==expected
tables=[]
for name,size in [('eplustbl.csv',215),('eplustbl.tab',212),('eplustbl.txt',226),('eplustbl.htm',774),('eplustbl.xml',474)]:
 p=out/name;b=p.read_bytes();assert len(b)==size and b'\r\n'in b and b'\n'not in b.replace(b'\r\n',b'');tables.append(ref(p))
assert b'Program Version:,rusted-energyplus 0.1.0'in(out/'eplustbl.csv').read_bytes()
observation=out/'logs/source-input-statistics.json';obs=json.loads(observation.read_bytes());assert obs['schema']=='source-input-statistics-observation.v1'and obs['timing']=='after successful actual Native322 and before later getter-owner handoffs'
fields=['number_input_records','number_defaulted_fields','total_fields_with_defaults','number_autosized_fields','total_autosizable_fields','number_autocalculated_fields','total_autocalculatable_fields']
labels=['IDF Objects','Defaulted Fields','Fields with Defaults','Autosized Fields','Autosizable Fields','Autocalculated Fields','Autocalculatable Fields'];assert[r['field']for r in obs['counters']]==fields
witnessp=B/'Fix-ordinary-input-statistics-Source-review-02/reference-A-seven-counters.json';wit=json.loads(witnessp.read_bytes());native_csv=get(wit['Native_table']);nrows=list(csv.reader(native_csv.decode('latin1').splitlines()));matches=[]
for field,label,actual in zip(fields,labels,obs['counters']):
 rows=[(i,r)for i,r in enumerate(nrows)if len(r)==3 and r[0]==''and r[1].strip()==label];assert len(rows)==1;ordinal,row=rows[0];value=int(row[2]);assert actual['value']==value==wit['actual_Native_counters'][label]
 matches.append({'Source_field':field,'Native_label':label,'Native_csv_row_1based':ordinal+1,'Source_observed_integer':actual['value'],'Native_observed_integer':value,'exact_equal':True})
assert[r['Source_observed_integer']for r in matches]==[96,25,241,0,0,3,15]
native_receipt=json.loads(get(wit['Native_receipt']));assert native_receipt['exit_code']==0 and native_receipt['source_bytes_match_before_and_after'];assert(out/'input/converted.epJSON').read_bytes()==get(wit['converted_input'])
# Read the actual observer/caller and unique frontier, beyond stage labels.
pipe=all_live[pipeline];assert pipe.count(b'logs").join("source-input-statistics.json')==1
assert pipe.index(b'.initialize_source_input_processor(input)')<pipe.index(b'source-input-statistics.json')<pipe.index(b'initialization.reports.heat_balance_input = runtime_inputs.heat_balance_input.take()')
endrun='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';code=all_live[endrun];needle=b'actual endrun WriteTabularReports596 entry before FillWeather';assert code.count(needle)==1
assert code.index(b'.report_source_for_tabular_reports(')<code.index(b'.open_source_output_tabular_file_on_session(')<code.index(needle)
assert b'report_source_rainfall'not in code and b'fill_source_weather_predefined_entries'not in code
N=R/'.reference/energyplus-src/26.1.0';np=N/'src/EnergyPlus/SimulationManager.cc';nb=np.read_bytes();q=subprocess.run(['git','-C',str(N),'show','6f2e40d10250a105b49966baa24d843711e61048:src/EnergyPlus/SimulationManager.cc'],capture_output=True,check=True);assert q.stdout==nb
excerpt=b''.join(nb.splitlines(keepends=True)[589:604]);assert excerpt.index(b'ReportForTabularReports')<excerpt.index(b'OpenOutputTabularFile')<excerpt.index(b'WriteTabularReports')
O.mkdir();(O/'SimulationManager.cc-590-604.txt').write_bytes(excerpt)
ledger={'actual_receipt':ref(RP),'actual_diagnostics':ref(diagp),'whole_unchanged_physics_artifacts':physics,'Source69_LOG':ref(out/'eplusrs.ctf.log'),'Source68_LOG':ref(oldout/'eplusrs.ctf.log'),'only_added_LOG_lines':added,'actual_five_physical_TAB_files':tables,'Source_statistics':ref(observation),'existing_independent_reference_witness':ref(witnessp),'actual_Native_csv':wit['Native_table'],'actual_Native_receipt':wit['Native_receipt'],'independently_parsed_seven_integer_comparisons':matches,'exact_same_input':ref(out/'input/original.idf'),'exact_same_converted_input':ref(out/'input/converted.epJSON'),'actual_new_frontier':frontier}
(O/'actual-frontier-and-counter-ledger.json').write_bytes((json.dumps(ledger,indent=2)+'\n').encode());(O/'readonly-Git.json').write_bytes((json.dumps(git,indent=2)+'\n').encode())
review={'schema':'src06-independent-provider-union69-and-actual-frontier-review.v1','status':'ACCEPTED_BOUNDED_SOURCE_COMPOSITION_ACTUAL594_AND_SEVEN_NATIVE_COUNTERS','accepted':True,'manifest':ref(MP),'parent':M['parent'],'independent_leaf_peers':M['independent_reviews'],'actual_receipt':ref(RP),'actual_frontier_ledger':ref(O/'actual-frontier-and-counter-ledger.json'),'readonly_Git':ref(O/'readonly-Git.json'),
 'checks':{'composition_stages':18,'unique_changed_paths':17,'existing_changed':11,'new_Source':6,'literal_packet_and_union_applications':apps,'whole4421_archive_live_census_equal':True,'Rust_Source':4408,'all4415_parent_inputs_preserved':True,'shared_unchanged_file_ids':shared,'three_separate_root_configs':True,'selected_existing_detached_new_fresh':True,'actual_CLI_build_finished_before_execution':True,'actual_exit6_Source_unchanged':True,'five_physical_TAB_headers_written':True,'LOG_only_five_expected_lines_added':True,'ESO_MTR_EIO_whole_equal68':True,'actual_seven_counter_labels_and_integers_equal_existing_Native_csv':True,'observer_reads_actual_fields_after322_before_owner_handoffs':True,'actual594_returns_before_typed596_frontier':True,'Rainfall_not_executed_out_of_order':True},
 'Native_order':{'source':ref(np),'Original_commit':'6f2e40d10250a105b49966baa24d843711e61048','first_line':590,'last_line':604,'literal_excerpt':ref(O/'SimulationManager.cc-590-604.txt')},
 'findings':[],'approval_scope':'Exact Root69 composition and actual Source594 header creation plus seven observed Native322 integer counter values accepted. Endrun remains explicitly unavailable at596 before FillWeather; Source registration/table-body/export completion is not approved.',
 'qualifications':['Review does not self-accept Audit-authored OpenFiles leaf; its independently accepted Reviewer112057 body is only byte-bound into Root composition.','Actual CLI Cargo build succeeded on recorded Source4421; no workspace alltargets/fullsuite/fresh-target claim is added. Reviewer executed no Cargo/Native/tests.','Seven integer counters compare actual Source observer output with existing actual Native Latin1 CSV, using exact labels and same input. No physical floating quantum/raw-state/FP/Native numerical gate equality follows.','Five TAB files contain initial headers only. Existing Rust product version/date policy remains qualified; no complete Native TAB byte equality or completed24h export is asserted.','Rainfall compiled leaf is retained but unexecuted because FillWeather and FillRemaining precede it. All historical68/earlier exit6 boundaries remain preserved.'],
 'reviewer_preflight_history':{'Sources':[ref(B/'review-provider-union69-frontier-Audit-01.py'),ref(B/'review-provider-union69-frontier-Audit-02.py')],'reason':'Initial verifier assumed presentation arrays lexical; second guessed Report592 helper spelling. Fresh verifier compares exact path sets/counts and actual report_source_for_tabular_reports locator; no Source finding or payload change.'},'canonical_changes':0,'Git_mutations':0,'Cargo_or_Native_executed':False,'tests_executed':0,'canonical_pipeline_activation':False,'whole_run_or_gate_claim':False,'reviewer_Source':ref(Path(__file__).resolve())}
(O/'review.json').write_bytes((json.dumps(review,indent=2)+'\n').encode());print(json.dumps(ref(O/'review.json')))

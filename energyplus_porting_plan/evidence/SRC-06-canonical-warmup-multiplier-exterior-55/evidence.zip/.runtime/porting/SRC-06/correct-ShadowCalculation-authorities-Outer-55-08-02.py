"""Metadata-only strict authority successor; all two proposed Sources unchanged."""
from pathlib import Path
import copy,hashlib,json
R=Path(__file__).resolve().parents[3]; A=R/'.runtime/porting/SRC-06'
I=A/'source-ShadowCalculation-explicit-Outer-55-08'; O=A/'source-ShadowCalculation-explicit-Outer-55-08-02'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def save(p,j):return put(p,(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode())
assert not O.exists(); O.mkdir(); j=json.loads((I/'draft.json').read_bytes())
for row in j['files']:
 for k in ('before','proposed','forward_diff','inverse_diff'):
  q=R/row[k]['path'];assert ref(q)==row[k]
for row in j['Native_authorities']:
 if row['Native_path']=='src/EnergyPlus/SolarShading.cc': bounds=[(414,744)]
 elif row['Native_path']=='src/EnergyPlus/InputProcessing/InputProcessor.cc': bounds=[(790,893),(932,1137)]
 else: continue
 p=R/row['whole']['path'];b=p.read_bytes()
 row['extents']=[dict(first=a,last=z,source=put(O/'Native'/f'{p.name}.{a}-{z}',b''.join(b.splitlines(True)[a-1:z]))) for a,z in bounds]
j['original_draft']=ref(I/'draft.json')
j['authority_correction']='Only full SolarShading getter closing brace744 and exact setObjectItemValue790-893 extent bounds; all two Source wholes/diffs/parses/compiler plan are identical01.'
j['author_Source']=ref(Path(__file__))
print(json.dumps(dict(draft=save(O/'draft.json',j),plan=j['complete_proposed_compiler_Source_plan']),indent=2))

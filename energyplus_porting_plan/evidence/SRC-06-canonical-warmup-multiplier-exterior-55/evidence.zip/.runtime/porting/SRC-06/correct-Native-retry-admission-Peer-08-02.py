"""Preserve ready08; code-derived genuine four-plus-five catalogue admission correction."""
from pathlib import Path
import ast,copy,difflib,hashlib,importlib.util,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'P4-Exterior-Native-recipes-ready-Peer-08-02'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
 p=(R/v['path']).resolve();a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']);return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def main():
 assert not O.exists();O.mkdir();prior=D/'P4-Exterior-Native-recipes-ready-Peer-08/manifest.json';p=read(prior)
 old=D/'run-original-core-gap-batch-Root-08.py';new=D/'run-original-core-gap-batch-Root-08-02.py';a=old.read_text();needle="len(final['ddOutVars']) == 5";replacement="len(final['ddOutVars']) == 9";assert a.count(needle)==1;b=a.replace(needle,replacement);assert b.replace(replacement,needle)==a;ast.parse(b);new.write_text(b,encoding='utf-8',newline='\n')
 record=dict(before=ref(old),proposed=ref(new))
 for key,x,y in [('forward_diff',a,b),('inverse_diff',b,a)]:
  f=O/(key+'.diff');f.write_text(''.join(difflib.unified_diff(x.splitlines(keepends=True),y.splitlines(keepends=True),fromfile=old.name,tofile=new.name)),encoding='utf-8',newline='\n');record[key]=ref(f)
 correction=save(O/'correction.json',dict(schema='src06-P4-genuine-dictionary-admission-correction.v1',run_Source=record,reason='Real GetZoneData produced four initialized DD declarations before the five explicit distinct P4 SetupOutputVariable calls. Total nine declarations, with35 requested live records and five named lvalues. This is a code-derived cardinality check, not reconstructed scientific output.',Native_factory_guard=p['P4_factory_guard02'],independent_Root_peer=p['P4_factory_guard_independent_peer02'],no_CPP_input_math_FP_cache_or_build_flag_changes=True,prior_ready_unexecuted=ref(prior),author_Source=ref(Path(__file__))))
 p['run_Source']=ref(new);p['preserved_pre_execution_READY08']=ref(prior);p['admission_count_correction']=correction;p['admission_catalogue_counts']=dict(genuine_GetZoneData_declarations=4,new_explicit_declarations=5,total_dictionary_declarations=9,live_requested_records=35,named_primary_lvalues=5)
 olddelta=read(checked(p['root_helper_Source_deltas']));rows=copy.deepcopy(olddelta['files']);rr=rows[1];assert rr['proposed']==ref(old)
 rr['proposed']=ref(new)
 previous=checked(rr['before']).read_text()
 for key,x,y in [('forward_diff',previous,b),('inverse_diff',b,previous)]:
  f=O/('run.whole07-to08-02.'+key+'.diff');f.write_text(''.join(difflib.unified_diff(x.splitlines(keepends=True),y.splitlines(keepends=True),fromfile=rr['before']['path'],tofile=new.name)),encoding='utf-8',newline='\n');rr[key]=ref(f)
 p['root_helper_Source_deltas']=save(O/'Root-helper-Source-deltas.json',dict(schema='src06-P4-Exterior-ready08-02-complete-helper-deltas.v1',files=rows,additional_admission_correction=correction,only_changes=olddelta['only_changes']+' Final code-derived DD count9 replaces inherited5; no C++ or scientific-body change.',no_compile_run_or_canonical_execution=True));p['author_Source']=ref(Path(__file__))
 manifest=save(O/'manifest.json',p)
 spec=importlib.util.spec_from_file_location('readonly_ready08_custody',checked(p['build_Source']));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);verified=module.union_custody(p)
 # Independently apply both complete helper forward/inverse diffs before delivery.
 tree=ast.parse(checked(p['literal_application_Source']).read_text(encoding='utf-8-sig'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal');import re;ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal-only>','exec'),ns)
 for row in rows:
  x=checked(row['before']).read_bytes();y=checked(row['proposed']).read_bytes();assert ns['apply_literal'](x,checked(row['forward_diff']).read_bytes())==y and ns['apply_literal'](y,checked(row['inverse_diff']).read_bytes())==x
 pre=save(O/'private-precheck.json',dict(accepted=True,manifest=manifest,metadata_refs_rehashed=len(verified),Native_wholes=len(p['Native_authorities']),full_helper_literal_apps=4,selected_groups=p['allowed_run_groups'],no_compile_run_or_canonical_execution=True));print(json.dumps(dict(manifest=manifest,build=p['build_Source'],run=p['run_Source'],deltas=p['root_helper_Source_deltas'],correction=correction,precheck=pre)))
if __name__=='__main__':main()

"""Freeze exact two-TU original-core recipe successor; no build/run or canonical mutation."""
from pathlib import Path
import ast,copy,difflib,hashlib,importlib.util,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'warmup-multiplier-Native-recipes-ready-Peer-02'
def ref(p):
 p=p.resolve()
 with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix()if p.is_relative_to(R)else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):p=(R/v['path']).resolve();assert ref(p)==v;return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return ref(p)
def function(text,name):
 node=next(x for x in ast.parse(text).body if isinstance(x,ast.FunctionDef)and x.name==name);return ''.join(text.splitlines(keepends=True)[node.lineno-1:node.end_lineno])
def replace_function(text,name,new):
 old=function(text,name);assert text.count(old)==1;return text.replace(old,new,1)
def main():
 assert not O.exists();O.mkdir();parent_ref=ref(D/'P4-Exterior-Native-recipes-ready-Peer-08-02/manifest.json');parent=read(checked(parent_ref));driver_ref=ref(D/'warmup-multiplier-Native-driver-draft-Peer-01/draft.json');driver=read(checked(driver_ref));driver_peer=ref(D/'Peer-warmup-multiplier-Native-driver-review-Outer-01/review.json');peer=read(checked(driver_peer));assert peer['accepted']and not peer['findings']and peer['reviewed_draft']==driver_ref
 warm=read(checked(driver['warmup_draft']));mult=read(checked(driver['multiplier_draft']));snippets_path=D/'warmup-multiplier-helper-snippets-Peer-01.py';snippets=snippets_path.read_text(encoding='utf-8');newunion=function(snippets,'union_custody');newadmit=function(snippets,'admit')
 oldbuild=checked(parent['build_Source']);oldrun=checked(parent['run_Source']);b=oldbuild.read_text(encoding='utf-8');r=oldrun.read_text(encoding='utf-8')
 b=replace_function(b,'union_custody',newunion);r=replace_function(r,'union_custody',newunion);r=replace_function(r,'admit',newadmit)
 b=b.replace('import argparse, ast, hashlib','import argparse, ast, importlib.util, hashlib');r=r.replace('import argparse, ast, ast, ctypes','import argparse, ast, ast, importlib.util, ctypes')
 pairs=[('Root-only three private caller compiles','Root-only two private caller compiles'),('READY_FOR_ROOT_THREE_COMPILES_ONE_ORIGINAL_CORE_LINK','READY_FOR_ROOT_TWO_COMPILES_ONE_ORIGINAL_CORE_LINK'),("assert len(p['independent_leaves']) == 3","assert len(p['independent_leaves']) == 2"),("assert len(p['compile_argvs']) == 3 and len(p['caller_Sources']) == 3 and len(p['objects']) == 3","assert len(p['compile_argvs']) == 2 and len(p['caller_Sources']) == 2 and len(p['objects']) == 2"),('if len(compiles) == 3 and all','if len(compiles) == 2 and all'),('ok = len(compiles) == 3 and link','ok = len(compiles) == 2 and link'),('planned_caller_compiles=3','planned_caller_compiles=2'),('original-core-gap-batch-Root-07','original-core-gap-batch-Root-08'),('original-core-gap-batch-build-Root-07','original-core-gap-batch-build-Root-08')]
 for a,z in pairs:assert a in b,a;b=b.replace(a,z)
 r=r.replace("a.group in ['output_processor','exterior']","a.group in ['warmup','multiplier_predictor']").replace('Only incomplete groups may retry','Only new warmup/multiplier groups may execute').replace("choices=['output_processor','exterior']","choices=['warmup','multiplier_predictor']").replace('original-core-gap-batch-run-Root-07-','original-core-gap-batch-run-Root-08-')
 # New receipt parent fields distinguish the actual07 build from inherited earlier history.
 b=b.replace("reviewed_manifest=ref(mp), independent_leaves=", "reviewed_manifest=ref(mp), new_parent_READY08=p['new_parent_READY08'], actual_accepted_build07=p['actual_accepted_build07'], independent_leaves=",1)
 r=r.replace("reviewed_manifest=ref(mp), independent_leaves=", "reviewed_manifest=ref(mp), new_parent_READY08=p['new_parent_READY08'], actual_accepted_build07=p['actual_accepted_build07'], independent_leaves=",1)
 bp=D/'build-warmup-multiplier-Native-Root-02.py';rp=D/'run-warmup-multiplier-Native-Root-02.py';assert not bp.exists()and not rp.exists();bp.write_text(b,encoding='utf-8',newline='\n');rp.write_text(r,encoding='utf-8',newline='\n');ast.parse(b);ast.parse(r)
 deltas=[]
 for old,new in [(oldbuild,bp),(oldrun,rp)]:
  diffs={}
  for kind,a,z in [('forward',old.read_bytes(),new.read_bytes()),('inverse',new.read_bytes(),old.read_bytes())]:
   p=O/(new.name+'.'+kind+'.diff');p.write_text(''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),z.decode().splitlines(keepends=True),fromfile=old.name,tofile=new.name)),encoding='utf-8',newline='\n');diffs[kind]=ref(p)
  deltas.append(dict(before=ref(old),proposed=ref(new),diffs=diffs))
 # Only the complete accepted literal patch function is evaluated, no parent main.
 literal=checked(parent['literal_application_Source']);node=next(x for x in ast.parse(literal.read_text(encoding='utf-8-sig')).body if isinstance(x,ast.FunctionDef)and x.name=='apply_literal');ns=dict(re=re);exec(compile(ast.Module(body=[node],type_ignores=[]),'<accepted literal only>','exec'),ns)
 for d in deltas:
  a=checked(d['before']).read_bytes();z=checked(d['proposed']).read_bytes();assert ns['apply_literal'](a,checked(d['diffs']['forward']).read_bytes())==z and ns['apply_literal'](z,checked(d['diffs']['inverse']).read_bytes())==a
 delta_ref=save(O/'helper-full-forward-inverse.json',dict(schema='src06-two-new-Native-group-helper-deltas.v1',files=deltas,literal_applications=4,Python_syntax_parses=2,inherited_PID_gate_and_process_launch_block_whole_unchanged=True,author_Source=ref(Path(__file__))))
 p=copy.deepcopy(parent);p.update(schema='src06-warmup-multiplier-original-core-recipe.v1',status='READY_FOR_ROOT_TWO_COMPILES_ONE_ORIGINAL_CORE_LINK',new_parent_READY08=parent_ref,actual_accepted_build07=ref(D/'original-core-gap-batch-build-Root-07/native-build.json'),inherited_build_Source=ref(oldbuild),inherited_run_Source=ref(oldrun),new_driver_draft=driver_ref,new_driver_peer=driver_peer,independent_leaves=[dict(draft=driver['warmup_draft'],peer=driver['independent_leaf_peers'][0]),dict(draft=driver['multiplier_draft'],peer=driver['independent_leaf_peers'][1])],caller_Sources=[driver['driver_files'][0]['proposed'],driver['combined_TU']],common_header=driver['driver_files'][1]['proposed'],named_inputs=driver['named_inputs'],allowed_run_groups=['warmup','multiplier_predictor'],build_Source=ref(bp),run_Source=ref(rp),helper_full_deltas=delta_ref,helper_function_snippets=ref(snippets_path),author_Source=ref(Path(__file__)))
 unit=Path('D:/CodexBuild/rusted-energyplus/SRC-06/original-core-gap-batch-Root-08');assert not unit.exists();p['fresh_unit_directory']=unit.as_posix();p['objects']=[(unit/Path(v['path']).name).as_posix()+'.obj'for v in p['caller_Sources']]
 for k,base in [('binary','native-gap-batch.exe'),('map','native-gap-batch.map'),('implib','native-gap-batch.dll.a')]:p[k]=(unit/base).as_posix()
 base=read(checked(p['inherited_original_core_recipe']));include='-I'+checked(p['common_header']).parent.as_posix();oldinclude='-I'+(D/'system-report-native-draft-Peer-39').as_posix();p['compile_argvs']=[]
 for source,obj in zip(p['caller_Sources'],p['objects'],strict=True):
  argv=list(base['one_compile_argv']);assert argv.count(oldinclude)==1;argv[argv.index(oldinclude)]=include;argv[argv.index('-c')+1]=checked(source).as_posix();argv[argv.index('-o')+1]=obj;p['compile_argvs'].append(argv)
 argv=list(base['one_link_argv']);oi=next(i for i,x in enumerate(argv)if Path(x).as_posix().casefold()==Path(base['object']).as_posix().casefold());argv[oi:oi+1]=p['objects'];argv[argv.index('-o')+1]=p['binary'];p['link_argv']=[('-Wl,-Map,'+p['map'])if x.startswith('-Wl,-Map,')else('-Wl,--out-implib,'+p['implib'])if x.startswith('-Wl,--out-implib,')else x for x in argv]
 authority={x.get('Native_path',x.get('canonical_path')):copy.deepcopy(x)for x in parent['Native_authorities']}
 for doc in [warm,mult]:
  for row in doc['Native_authorities']:
   name=row['Native_path']
   if name not in authority:authority[name]=copy.deepcopy(row)
   else:
    assert (authority[name]['whole']['sha256'],authority[name]['whole']['bytes'])==(row['whole']['sha256'],row['whole']['bytes']);extents={x['source']['path']:x for x in authority[name].get('extents',[])}
    for e in row.get('extents',[]):extents[e['source']['path']]=e
    authority[name]['extents']=list(extents.values())
 p['Native_authorities']=list(authority.values());inputs=[]
 for key in p['allowed_run_groups']:
  for case in read(checked(p['named_inputs']))[key]['cases']:inputs.append(ref(Path(case['factory']['input_file'])))
 p['input_files']=list({v['path']:v for v in inputs}.values());assert len(p['input_files'])==7
 p['scope']='Exactly two new full original-core scientific unit groups:69 RecKeep/Check operations and21 multiplier2 Predict/Correct/history operations. All older P1/P4/history/Surface/Exterior groups remain linked only as unchanged prefix dependencies and are never selected. No CMake/registry/core/provider/environment/FP changes.'
 p['original_core_members_required']=list(dict.fromkeys(parent['original_core_members_required']+['RoomAirModelManager.cc.obj']))
 manifest=save(O/'manifest.json',p)
 # Read-only composition authentication; no protected-core hash duplication, compiler, or process launch.
 spec=importlib.util.spec_from_file_location('new_Native_recipe_readonly',bp);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);bound=module.union_custody(p)
 for row in p['Native_authorities']:
  checked(row['whole'])
  for e in row.get('extents',[]):checked(e['source'])
 pre=save(O/'read-only-preflight.json',dict(schema='src06-two-new-Native-groups-readonly-preflight.v1',accepted=True,findings=[],manifest=manifest,binding_refs_checked=len(bound),Native_wholes=len(p['Native_authorities']),input_files=7,new_TU_compiles=2,new_core_links=1,old_scientific_groups_selected=False,canonical_Cargo_Native_or_compiler_execution=False))
 print(json.dumps(dict(manifest=manifest,preflight=pre,build=ref(bp),run=ref(rp),helper_deltas=delta_ref,Native_wholes=len(p['Native_authorities']))))
if __name__=='__main__':main()

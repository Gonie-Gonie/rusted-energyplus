"""Root-only original-core unit caller, exact PID module gate before science.

Uses the frozen Native environment without recording its contents. No engine,
Cargo or Source test is launched; no FPU/cache controls are changed.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ast, ast, ctypes, hashlib, json, math, os, re, struct, subprocess, time
from ctypes import wintypes
R = Path(__file__).resolve().parents[3]; D = R / '.runtime/porting/SRC-06'


def need(ok, why):
    if not ok: raise ValueError(why)


def ref(p):
    p = p.resolve()
    with p.open('rb') as f: h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(), sha256=h, bytes=p.stat().st_size)


def checked(v):
    p = (R / v['path']).resolve(); actual = ref(p)
    need(actual['sha256'] == v['sha256'] and actual['bytes'] == v.get('bytes', actual['bytes']), 'Changed authenticated file: ' + v['path'])
    return p


def read(p): return json.loads(p.read_bytes())


def scalar_count(value):
    if isinstance(value, dict):
        if 'value_bits' in value:
            need(set(value) == {'value_bits'} and re.fullmatch('[0-9a-f]{16}', value['value_bits']) is not None, 'One raw16hex scalar')
            number = struct.unpack('>d', bytes.fromhex(value['value_bits']))[0]; need(math.isfinite(number), 'Finite observed scalar'); return 1
        return sum(scalar_count(x) for x in value.values())
    if isinstance(value, list): return sum(scalar_count(x) for x in value)
    need(not isinstance(value, float), 'No unwrapped floating JSON field'); return 0



def admit_exterior(p, result, named, selected):
    need(selected in ['purchased_air','surface','exterior'],'One authenticated whole group')
    need(result['schema'] == 'src06-original-core-gap-batch-output.v1' and result['normal_completion'] is True,'Normal complete selected group schema')
    need(result['group_order'] == [selected] and set(result['groups']) == {selected},'Exactly selected complete group, no other science')
    count = scalar_count(result); output = result['groups'][selected]
    if selected == 'purchased_air':
        need(output['schema'] == 'src06-purchased-air-full-function-batch-output.v1','PurchasedAir full-function schema')
        need(len(output['cases']) == len(named[selected]['factories']) == 4,'Four actual raw-input factory lifetimes')
        calls = 0; lifetimes = []
        for actual, expected in zip(output['cases'],named[selected]['factories'],strict=True):
            need(actual['factory'] == expected['name'] and actual['origin'] == expected['origin'],'Factory identity/input provenance')
            need(len(actual['steps']) == len(expected['steps']) == 15,'All fifteen persistent calls')
            state = actual['setup']['context']['state_address']; need(state is not None,'Actual state constructor address')
            units = {}; nodes = {}; which = {}; operations = {}; snapshots = [actual['setup']]
            for ordinal,(step,definition) in enumerate(zip(actual['steps'],expected['steps'],strict=True),1):
                need(step['ordinal'] == ordinal and step['name'] == definition['name'] and step['operation'] == definition['operation'] and step['named_inputs'] == definition['inputs'],'Exact named operation/input sequence')
                need(step['exception'] is None,'Normal finite original full-function call')
                need((step['actual_caller_InitZoneEquipment_prefix'] is not None) == (step['operation'] == 'simulate'),'Actual prefix exactly at full Sim calls')
                if step['actual_caller_InitZoneEquipment_prefix'] is not None:
                    snapshots += [step['actual_caller_InitZoneEquipment_prefix'][k] for k in ['entry','exit']]
                snapshots += [step['entry'],step['exit']]
                manager = step['exit']['manager']
                need(manager['NumPurchAir'] == 1 and not manager['GetPurchAirInputFlag'] and len(manager['PurchAir']['items']) == 1,'Genuine lazy getter count/latch/row')
                need(0 < step['exit']['context']['CompIndex'] <= manager['NumPurchAir'],'Actual retained CompIndex lvalue')
                operations[step['operation']] = operations.get(step['operation'],0)+1;calls += 1
            for snap in snapshots:
                need(snap['context']['state_address'] == state,'Same state throughout complete factory lifetime')
                node_rows=snap['nodes']['Node']['items']; ids=snap['nodes']['NodeID']['items']
                need(len(ids) == len(node_rows)+1 and ids[0] == 'Undefined','Actual NodeID lower0/physical Node association')
                for ordinal,row in enumerate(node_rows,1):
                    need(len(row) == 49 and row['address'] is not None,'All48 initialized actual Node members plus address')
                    if ordinal in nodes:need(nodes[ordinal] == row['address'],'Same physical Node row over retained calls')
                    else:nodes[ordinal]=row['address']
                for ordinal,row in enumerate(snap['manager']['PurchAir']['items'],1):
                    need(len(row) == 135 and row['address'] is not None,'All134 initialized actual unit members plus address')
                    if ordinal in units:need(units[ordinal] == row['address'],'Same retained unit row over calls')
                    else:units[ordinal]=row['address']
                for ordinal,row in enumerate(snap['registration']['live']):
                    need(row['Which'] is not None,'Real registered Which target')
                    key=(ordinal,row['name'],row['key'])
                    if key in which:need(which[key] == row['Which'],'Same live Which target over calls')
                    else:which[key]=row['Which']
                    for match in row['same_unit_field']:
                        unit=snap['manager']['PurchAir']['items'][match['unit']-1]
                        need(unit[match['member']] == row['live_value'],'Live Which read equals actual same unit member, no cached answer')
            lifetimes.append(dict(name=actual['factory'],step_count=15,direct_operation_counts=operations,snapshots_checked=len(snapshots),physical_Node_rows=len(nodes),unit_rows=len(units),live_Which_targets=len(which),same_state_address=state,qualification='Identity only within this factory; later lifetimes may reuse allocator addresses.'))
        need(calls == 60,'All sixty original PurchasedAir calls')
        return dict(selected_group=selected,raw_finite_binary64_fields=count,purchased_air_factories=4,PurchasedAir_full_function_calls=60,same_lifetime_physical_owners=lifetimes)
    need(output['schema'] == ('src06-original-surface-gap-output.v1' if selected == 'surface' else 'src06-original-exterior-gap-output.v1'),'Exact selected full-function schema')
    shapes = {}; call_counts = {}
    for key,values in named[selected].items():
        if key == 'schema':continue
        need(isinstance(values,list) and isinstance(output[key],list) and len(output[key]) == len(values),'Every named case retained: '+key)
        need([x['name'] for x in output[key]] == [x['name'] for x in values],'Exact named case order: '+key)
        shapes[key]=len(values);calls=0
        for case,definition in zip(output[key],values,strict=True):
            if 'input' in case:need(case['input'] == definition,'Actual primary input provenance: '+key)
            source_key='exchanges' if key == 'radiation' else 'calls' if key == 'schedule_minute' else 'times' if key == 'solar_clock' else 'steps'
            if source_key in definition:
                extra=2 if key == 'radiation' else 0
                need(len(case['calls']) == len(definition[source_key])+extra,'Every ordered full call: '+key);calls += len(case['calls'])
                for actual,primary in zip(case['calls'][extra:],definition[source_key],strict=True):
                    operand='primary_call' if key == 'schedule_minute' else 'primary_time' if key == 'solar_clock' else 'primary_clock' if key in ['internal_gains','beam_producer','surface_internal_gains'] else 'primary_step'
                    need(actual[operand] == primary,'Exact actual named call input: '+key)
            else:calls += 1
        call_counts[key]=calls
    return dict(selected_group=selected,raw_finite_binary64_fields=count,supplemental_named_case_counts=shapes,ordered_full_call_record_counts=call_counts,qualification='Actual original full-method outputs from named primary INPUTS. Absorption/solar paired records each invoke two full methods; not Source equivalence or whole-engine/card completion.')



def admit(p, result, named, selected):
    need(selected in ['output_processor','air_history','exterior'],'One authenticated new complete group')
    if selected == 'exterior': return admit_exterior(p,result,named,selected)
    need(result['schema'] == 'src06-original-core-gap-batch-output.v1' and result['normal_completion'] is True,'Normal selected output schema')
    need(result['group_order'] == [selected] and set(result['groups']) == {selected},'Exactly selected complete group only')
    count = scalar_count(result); group = result['groups'][selected]; primary = named[selected]
    if selected == 'output_processor':
        need(group['schema'] == 'src06-output-processor-full-method-batch-output.v1','P4 original full-method schema')
        need(len(group['cases']) == len(primary['cases']) == 1,'One persistent output lifecycle')
        case = group['cases'][0]; definition = primary['cases'][0]
        need(case['name'] == definition['name'] and case['origin'] == definition['origin'],'P4 named input origin')
        setup = ['SetupTimePointers.Zone','SetupTimePointers.System','GetReportVariableInput','SetupOutputVariable.ZoneAverage','SetupOutputVariable.SystemAverage','SetupOutputVariable.SystemEnergy','SetupOutputVariable.SystemInteger','SetupOutputVariable.ZoneIntegerSum','UpdateMeterReporting']
        need([x['operation'] for x in case['setup']] == setup,'All nine original setup methods')
        need(len(case['steps']) == len(definition['steps']) == case['calls'] == 38,'All38 original update/reset calls')
        snapshots = [case['initial']]
        for event in case['setup']: snapshots += [event['entry'],event['exit']]
        counts = {}; state_address = case['initial']['context']['state_address']; lvalues = case['initial']['named_lvalues']['addresses']
        for ordinal,(step,source) in enumerate(zip(case['steps'],definition['steps'],strict=True),1):
            need(step['ordinal'] == ordinal and step['name'] == source['name'] and step['operation'] == source['operation'] and step['named_inputs'] == source['inputs'],'Exact P4 named operation/input sequence')
            counts[step['operation']] = counts.get(step['operation'],0)+1;snapshots += [step['entry'],step['exit']]
        need(counts == dict(system=25,zone=12,warmup_reset=1),'P4 full-method call counts')
        for snap in snapshots:
            need(snap['context']['state_address'] == state_address and snap['named_lvalues']['addresses'] == lvalues,'Same persistent actual state and all five lvalues')
            op=snap['output_processor']
            for var in op['outVars']:
                key=var['same_named_lvalue'];need(key in lvalues and var['Which'] == lvalues[key] and var['live_value'] == snap['named_lvalues'][key],'Actual live Which target identity/value')
                need(var['sched'] is None,'Unscheduled actual request domain')
        final=case['setup'][-1]['exit']['output_processor']
        need(len(final['outVars']) == 35 and len(final['ddOutVars']) == 9 and len(final['meters']) > 0,'Genuine declaration/meter producers')
        need(len(final['meterValues']) == len(final['meters']),'Actual meter values extent')
        pointers=final['time_values'];need(sum(x['is_actual_zone_pointer'] for x in pointers)==1 and sum(x['is_actual_system_pointer'] for x in pointers)==1,'Both real timestep lvalue aliases')
        return dict(selected_group=selected,raw_finite_binary64_fields=count,persistent_state_lifetimes=1,named_lvalues=5,real_request_records=35,setup_original_method_calls=9,original_update_reset_calls=38,operation_counts=counts,snapshots_checked=len(snapshots),qualification='Full original OP unit route and observed outputs only; not Source equivalence, private RF catalogue or whole engine/calendar duration coverage.')
    need(group['schema'] == 'src06-air-history-original-core-output.v1','History original full-method schema')
    need(len(group['cases']) == len(primary['cases']) == 4,'Four actual raw getter lifetimes')
    calls=0;lifetimes=[]
    for case,definition in zip(group['cases'],primary['cases'],strict=True):
        need(case['name'] == definition['name'] and case['origin'] == definition['origin'],'History factory origin')
        need(len(case['steps']) == len(definition['steps']) == 10,'All ten persistent original calls')
        first=case['before_real_RoomAir_getter'];state_address=first['P1_owners']['context']['state_address'];nodes={};counts={}
        snapshots=[first,case['after_real_RoomAir_getter']]
        for ordinal,(step,source) in enumerate(zip(case['steps'],definition['steps'],strict=True),1):
            need(step['ordinal'] == ordinal and step['name'] == source['name'] and step['operation'] == source['operation'] and step['named_inputs'] == source['inputs'],'Exact history named operation/input sequence')
            counts[step['operation']]=counts.get(step['operation'],0)+1;snapshots += [step['entry'],step['exit']];calls+=1
        need(counts == dict(push_zone=5,push_system=4,revert_zone=1),'History full-call counts')
        for snap in snapshots:
            need(snap['P1_owners']['context']['state_address'] == state_address,'Same actual state over history lifetime')
            for i,node in enumerate(snap['P1_owners']['nodes']['Node']['items'],1):
                if i in nodes:need(nodes[i] == node['address'],'Same physical Node row retained')
                else:nodes[i]=node['address']
            for row in snap['zoneHeatBalance']['items'] + snap['spaceHeatBalance']['items']:
                need(len(row)==75 and all(len(row[key])==4 for key in ['XMAT','DSXMAT','WPrevZoneTS','DSWPrevZoneTS','ZTM','WPrevZoneTSTemp']),'All67 real+6 history+initialized integer+address observations')
        lifetimes.append(dict(name=case['name'],original_calls=10,snapshots_checked=len(snapshots),physical_Node_rows=len(nodes),actual_state_address=state_address))
    need(calls==40,'All forty history calls')
    return dict(selected_group=selected,raw_finite_binary64_fields=count,persistent_state_lifetimes=4,original_history_method_calls=40,lifetimes=lifetimes,qualification='Actual full mixed/ThirdOrder history functions, getter-created models and retained input-only sequence. Not Source equivalence, multiplier2 or nonmixing/Space branch coverage.')





def parent_union_custody(p):
    parent = read(checked(p['previous_ready_manifest']))
    actual = read(checked(p['actual_accepted_build04']))
    assert actual['accepted'] and not actual['findings'] and actual['Native_bytes_match_before_and_after'] and actual['reviewed_manifest'] == p['previous_ready_manifest']
    assert all(actual['original_core_member_counts'].values()) and not actual['forbidden_derived_object_witnesses']
    assert p['inherited_original_core_recipe'] == parent['inherited_original_core_recipe'] and p['actual_original_core_build43'] == parent['actual_original_core_build43']
    driver = read(checked(p['new_driver_draft']))
    driver_peer = read(checked(p['new_driver_peer']))
    assert (driver_peer.get('accepted') is True or driver_peer.get('status','').startswith('ACCEPTED_')) and not driver_peer['findings'] and driver_peer['reviewed_draft'] == p['new_driver_draft']

    original_driver = driver
    driver = read(checked(p['history_ADL_driver05']))
    correction = read(checked(driver['history_compile_correction']))
    compile_peer = read(checked(p['history_ADL_independent_peer']))
    assert compile_peer['accepted'] and not compile_peer['findings'] and compile_peer.get('reviewed_draft',compile_peer.get('reviewed_packet')) == p['history_ADL_driver05']
    assert correction['actual_failed_build'] == p['preserved_failed_build05'] and correction['original_driver'] == p['new_driver_draft']
    failed = read(checked(p['preserved_failed_build05']))
    assert not failed['accepted'] and failed['Native_bytes_match_before_and_after'] and failed['actual_caller_compile_invocations'] == 2 and failed['actual_link_invocations'] == 0
    assert driver['Exterior_independent_peer'] == p['independent_leaves'][2]['peer']
    assert driver['named_inputs'] == original_driver['named_inputs'] and driver['Exterior_Source'] == original_driver['Exterior_Source']
    for old,new in zip(original_driver['driver_files'],driver['driver_files'],strict=True): assert checked(old['proposed']).read_bytes() == checked(new['proposed']).read_bytes()
    assert correction['before_combined'] == original_driver['combined_TU'] and correction['proposed_combined'] == driver['combined_TU']
    def qualify(old):
        a=b'        apply_inputs(factory,step.at("inputs"));auto operation='
        b=b'        AirHistoryDetail::apply_inputs(factory,step.at("inputs"));auto operation='
        assert old.count(a)==1
        result=old.replace(a,b);assert result.replace(b,a)==old
        return result
    assert qualify(checked(correction['before_fragment']).read_bytes()) == checked(correction['proposed_fragment']).read_bytes()
    assert qualify(checked(correction['before_combined']).read_bytes()) == checked(correction['proposed_combined']).read_bytes()
    assert p['caller_Sources'] == [driver['driver_files'][0]['proposed'], driver['combined_TU'],driver['Exterior_Source']] and p['common_header'] == driver['driver_files'][1]['proposed']
    assert p['named_inputs'] == driver['named_inputs'] and driver['actual_accepted_parent_build'] == p['actual_accepted_build04']
    p4 = read(checked(p['independent_leaves'][0]['draft']))
    history = read(checked(p['independent_leaves'][1]['draft']))
    exterior = read(checked(p['independent_leaves'][2]['draft']))
    assert driver['P4_draft'] == p['independent_leaves'][0]['draft'] and driver['history_draft'] == p['independent_leaves'][1]['draft']
    assert p4['accepted_P1_prefix'] == history['accepted_P1_prefix'] == driver['accepted_P1_prefix'] == parent['caller_Sources'][1]
    parts = [p4['accepted_P1_prefix'], p4['appended_P4_only_fragment'], history['appended_fragment']]
    assert parts[2] == correction['before_fragment']
    parts[2] = correction['proposed_fragment']
    assert checked(driver['combined_TU']).read_bytes() == b''.join(checked(x).read_bytes() for x in parts)
    assert driver['Exterior_draft'] == p['independent_leaves'][2]['draft'] and p['caller_Sources'][2] == exterior['proposed']
    named = read(checked(p['named_inputs']))
    assert named == dict(schema='src06-original-core-gap-batch-input.v1', output_processor=read(checked(p4['named_inputs'])), air_history=read(checked(history['named_inputs'])),exterior=read(checked(exterior['named_inputs']))['exterior'])
    rows = [p['previous_ready_manifest'],p['actual_accepted_build04'],p['new_driver_draft'],p['new_driver_peer'],*parts]
    def collect(value):
        if isinstance(value,dict):
            if {'path','sha256','bytes'} <= value.keys(): rows.append(value)
            else:
                for key,child in value.items():
                    # Rust Source-context files are review context, not a Native build dependency.
                    if key not in ['Source_context','Source_contexts']: collect(child)
        elif isinstance(value,list):
            for child in value: collect(child)
    for value in [original_driver,driver,p4,history,exterior,correction,p['history_ADL_independent_peer'],p['history_ADL_driver05'],p['preserved_failed_build05'],p['preserved_predecessor_READY']]: collect(value)
    return [ref(checked(v)) for v in {x['path']:x for x in rows}.values()]


def union_custody(p):
    parent = read(checked(p['retry_parent_READY07']))
    rows = parent_union_custody(parent)
    actual = read(checked(p['actual_accepted_build06']))
    assert actual['accepted'] and not actual['findings'] and actual['reviewed_manifest'] == p['retry_parent_READY07'] and actual['Native_bytes_match_before_and_after']
    assert all(actual['original_core_member_counts'].values()) and not actual['forbidden_derived_object_witnesses']
    history = read(checked(p['preserved_completed_history06']))
    assert history['accepted'] and not history['findings'] and history['exit_code'] == 0 and history['selected_group'] == 'air_history' and history['actual_build'] == p['actual_accepted_build06']
    assert history['admission']['original_history_method_calls'] == 40 and history['Native_bytes_match_before_and_after']
    assert p['allowed_run_groups'] == ['output_processor','exterior']
    assert p['caller_Sources'][0] == parent['caller_Sources'][0] and p['common_header'] == parent['common_header'] and p['named_inputs'] == parent['named_inputs']
    # Authenticate exact bounded inverses; no patch is ever applied to Native.
    literal_source = checked(p['literal_application_Source'])
    tree = ast.parse(literal_source.read_text(encoding='utf-8-sig'))
    node = next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name == 'apply_literal')
    ns = {'re':re}; exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-literal-function-only>','exec'),ns); apply=ns['apply_literal']
    correction_docs=[]
    for i, correction_ref, peer_ref, keys in [
        (1,p['P4_factory_guard02'],p['P4_factory_guard_independent_peer02'],('forward_diff','inverse_diff')),
        (2,p['Exterior_calendar11'],p['Exterior_calendar_independent_peer11'],('forward','inverse'))]:
        correction=read(checked(correction_ref));peer=read(checked(peer_ref))
        assert peer['accepted'] and not peer['findings'] and peer.get('reviewed_draft',peer.get('reviewed_packet')) == correction_ref
        assert correction['before'] == parent['caller_Sources'][i] and correction['proposed'] == p['caller_Sources'][i]
        before=checked(correction['before']).read_bytes();after=checked(correction['proposed']).read_bytes()
        diff=correction if i==1 else correction['diffs']
        assert apply(before,checked(diff[keys[0]]).read_bytes()) == after and apply(after,checked(diff[keys[1]]).read_bytes()) == before
        assert (correction['named_inputs'] if i==1 else correction['named_inputs_unchanged']) == p['named_inputs']
        failed_ref=correction['actual_failed_P4_run'] if i==1 else correction['actual_failed_06']
        failed=read(checked(failed_ref));assert not failed['accepted'] and failed['actual_build'] == p['actual_accepted_build06'] and failed['Native_bytes_match_before_and_after']
        correction_docs += [correction,peer,correction_ref,peer_ref,failed_ref]
    assert p['inherited_original_core_recipe'] == parent['inherited_original_core_recipe'] and p['actual_original_core_build43'] == parent['actual_original_core_build43']
    def collect(value):
        if isinstance(value,dict):
            if {'path','sha256','bytes'} <= value.keys(): rows.append(value)
            else:
                for key,child in value.items():
                    if key not in ['Source_context','Source_contexts']: collect(child)
        elif isinstance(value,list):
            for child in value: collect(child)
    for v in correction_docs+[p['retry_parent_READY07'],p['actual_accepted_build06'],p['preserved_completed_history06'],p['literal_application_Source']]:collect(v)
    return [ref(checked(v)) for v in {x['path']:x for x in rows}.values()]


def main(a):
    need(a.run_only, 'Root explicit run-only flag')
    need(a.group in ['output_processor','exterior'], 'Only incomplete groups may retry')
    name, sha = a.build.rsplit('#', 1); bp = (R / name).resolve(); need(ref(bp)['sha256'] == sha, 'Authenticated actual build receipt')
    build = read(bp); need(build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after'], 'Actual accepted original-core build')
    need(all(build['original_core_member_counts'].values()) and not build['forbidden_derived_object_witnesses'], 'Original core symbols witnessed')
    mp = checked(build['reviewed_manifest']); p = read(mp); need(checked(p['run_Source']) == Path(__file__).resolve(), 'Exact reviewed run Source')
    binding_rows = union_custody(p)
    base = read(checked(p['inherited_original_core_recipe'])); binary = checked(build['binary']); ip = checked(p['named_inputs']); named = read(ip)
    need(named['schema'] == 'src06-original-core-gap-batch-input.v1', 'Named input schema')
    frozen = read(checked(base['frozen_environment'])); need(frozen['accepted'], 'Frozen accepted environment')
    environment = frozen['environment']; env = {k.casefold(): v for k, v in environment.items()}; need(len(env) == len(environment), 'No environment key collision')
    env_hash = hashlib.sha256(json.dumps(environment, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf8')).hexdigest()
    need(env_hash == build['environment_values_sha256'], 'Same true frozen environment values by hash only')
    systemroot = Path(env['systemroot'])
    query_source = checked(base['inherited_module_query_Source']); tree = ast.parse(query_source.read_bytes())
    classes = [x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'ChildModules']; need(len(classes) == 1, 'One complete inherited PSAPI query class')
    ns = dict(need=need, os=os, ctypes=ctypes, wintypes=wintypes, Path=Path)
    exec(compile(ast.Module(body=classes, type_ignores=[]), '<unchanged inherited child module observer>', 'exec'), ns)
    output = D / ('original-core-gap-batch-run-Root-07-' + a.group); need(not output.exists(), 'Fresh run metadata directory')
    result_path = Path(p['fresh_unit_directory']) / (a.group + '.unit-output.json'); need(not result_path.exists(), 'Fresh actual result path')
    rows = [ref(bp), ref(mp), build['binary'], p['named_inputs'], p['common_header'], *p['caller_Sources'], *base['protected_files'], ref(systemroot / 'System32/kernel32.dll'), ref(systemroot / 'System32/psapi.dll')]
    rows += [x[k] for x in p['independent_leaves'] for k in ['draft', 'peer']]
    rows += p['input_files']
    rows += binding_rows
    checkout = p['Native_checkout']; native = (R / checkout['path']).resolve()
    def checkout_unchanged():
        need(subprocess.check_output(['git', '-C', str(native), 'rev-parse', 'HEAD'], text=True).strip() == checkout['pinned_HEAD'], 'Pinned Native checkout HEAD')
        need(subprocess.check_output(['git', '-C', str(native), 'status', '--porcelain=v1', '--untracked-files=no'], text=True) == checkout['tracked_status'], 'Unchanged Native tracked source/header state')
    checkout_unchanged()
    protected = list({x['path']: x for x in rows}.values()); before = [ref(checked(x)) for x in protected]
    expected = {Path(x['path']).name.casefold(): checked(x) for x in base['pinned_runtime_DLLs']}; need(len(expected) == 3, 'Three exact GNU providers')
    output.mkdir()

    def write(name, value):
        target = output / name
        with target.open('xb') as f: f.write((json.dumps(value, indent=2) + '\n').encode())
        return ref(target)

    br = write('Native-before.json', dict(protected_files=before, frozen_environment_ref=base['frozen_environment'], environment_values_sha256=env_hash, no_environment_values_recorded=True))
    command = [str(binary), str(ip), str(result_path), '--group', a.group]; so, se = output / 'stdout.log', output / 'stderr.log'
    process = None; code = None; error = None; query = None; modules = None; bindings = []; errors = []; attempts = 0; ready = False; released = False
    start = datetime.now(timezone.utc).isoformat(); tick = time.monotonic()
    with so.open('xb') as out, se.open('xb') as err:
        try:
            process = subprocess.Popen(command, cwd=R, env=environment, stdout=out, stderr=err, stdin=subprocess.PIPE)
            deadline = time.monotonic() + 30
            while process.poll() is None and time.monotonic() < deadline:
                ready = so.read_bytes() in [b'NATIVE_GAP_BATCH_READY\n', b'NATIVE_GAP_BATCH_READY\r\n']
                if ready:
                    attempts += 1
                    try:
                        if query is None: query = ns['ChildModules'](process.pid, systemroot)
                        snapshot = query.snapshot()
                        if set(expected).issubset({Path(x['actual_path']).name.casefold() for x in snapshot}): modules = snapshot; break
                    except (OSError, ValueError) as e:
                        if len(errors) < 16: errors.append(dict(type=type(e).__name__, message=str(e)))
                time.sleep(.01)
            need(ready and modules is not None and process.poll() is None, 'Actual ready child and all three modules before any science call')
            for name, path in expected.items():
                matches = [x for x in modules if Path(x['actual_path']).name.casefold() == name]
                need(len(matches) == 1 and Path(matches[0]['actual_path']).resolve() == path, 'Exact PID GNU provider path')
                bindings.append(dict(module=matches[0], actual_file=ref(path)))
            need(len(bindings) == 3, 'All provider hashes bound before release')
            process.stdin.write(b'g'); process.stdin.flush(); process.stdin.close(); released = True; code = process.wait(timeout=600)
        except (OSError, ValueError, subprocess.TimeoutExpired) as e:
            error = dict(type=type(e).__name__, message=str(e))
            if process is not None and process.poll() is None: process.kill()
            if process is not None: code = process.wait()
        finally:
            if query is not None: query.close()
    checkout_unchanged()
    after = [ref(checked(x)) for x in protected]; need(before == after, 'Protected original-core/provider/recipe bytes unchanged')
    ar = write('Native-after.json', dict(protected_files=after, environment_values_sha256=env_hash, no_environment_values_recorded=True))
    mr = write('actual-child-modules.json', dict(child_PID=process.pid if process else None, ready_before_release=ready, module_proof_before_release=len(bindings) == 3, one_byte_release_sent=released, attempts=attempts, first16_query_errors=errors, all_observed_modules=modules, actual_three_GNU_bindings=bindings))
    findings = []; admission = None
    if code != 0 or error: findings.append('Original-core scientific caller did not complete0 after genuine module admission.')
    if not findings:
        try:
            admission = admit(p, read(result_path), named, a.group)
            completed = Path(str(result_path) + '.' + a.group + '.json'); checkpoint = Path(str(result_path) + '.checkpoint.json')
            data = read(result_path); need(read(completed) == dict(schema='src06-original-core-gap-completed-group.v1',group=a.group,native_group=data['groups'][a.group],normal_completion=True),'Exact completed-group checkpoint provenance')
            partial = read(checkpoint); need(partial['normal_completion'] is False and partial['groups'] == data['groups'] and partial['group_order'] == [a.group] and partial['schema'] == data['schema'],'Passive partial checkpoint never claims normal completion')
        except (AssertionError, KeyError, TypeError, ValueError, OSError) as e: findings.append(dict(type=type(e).__name__, message=str(e)))
    accepted = code == 0 and error is None and not findings and admission is not None
    receipt = dict(schema='src06-original-core-gap-batch-run.v1', accepted=accepted, findings=findings, actual_build=ref(bp), reviewed_manifest=ref(mp), independent_leaves=p['independent_leaves'], actual_accepted_build04=p['actual_accepted_build04'], new_driver_draft=p['new_driver_draft'], new_driver_peer=p['new_driver_peer'], selected_group=a.group, retry_independent_peers=p['retry_independent_peers'], retry_parent_READY07=p['retry_parent_READY07'], actual_accepted_build06=p['actual_accepted_build06'], P4_factory_guard02=p['P4_factory_guard02'], P4_factory_guard_independent_peer02=p['P4_factory_guard_independent_peer02'], Exterior_calendar11=p['Exterior_calendar11'], Exterior_calendar_independent_peer11=p['Exterior_calendar_independent_peer11'], preserved_completed_history06=p['preserved_completed_history06'], history_ADL_driver05=p['history_ADL_driver05'], history_ADL_independent_peer=p['history_ADL_independent_peer'], preserved_failed_build05=p['preserved_failed_build05'], preserved_accepted_build02=p['preserved_accepted_build02'], preserved_failed_science_run02=p['preserved_failed_science_run02'], binding_only_correction=p['binding_only_correction'], independent_binding_only_peer=p['independent_binding_only_peer'], preserved_first_failed_build=p['preserved_first_failed_build'], compile_only_correction08=p['compile_only_correction08'], independent_compile_only_peer08=p['independent_compile_only_peer08'], preserved_failed_compile_build03=p['preserved_failed_compile_build03'], retry_predecessor_READY05=p['retry_predecessor_READY05'], command=command, cwd=R.as_posix(), child_PID=process.pid if process else None, exit_code=code, launch_error=error, started_utc=start, finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-tick, stdout=ref(so), stderr=ref(se), Native_before=br, Native_after=ar, Native_bytes_match_before_and_after=before == after, actual_child_modules=mr, actual_three_GNU_DLL_binding_proved_before_any_science_call=len(bindings) == 3 and released, full_unit_output=ref(result_path) if result_path.exists() else None, completed_group_output=ref(Path(str(result_path)+'.'+a.group+'.json')) if Path(str(result_path)+'.'+a.group+'.json').exists() else None, partial_checkpoint=ref(Path(str(result_path)+'.checkpoint.json')) if Path(str(result_path)+'.checkpoint.json').exists() else None, Exterior_progress=ref(Path(str(result_path)+'.exterior-progress.json')) if Path(str(result_path)+'.exterior-progress.json').exists() else None, admission=admission, frozen_environment_ref=base['frozen_environment'], environment_values_sha256=env_hash, no_environment_values_recorded=True, previous59_2336_471_Source_suites_executed=False, engine_Cargo_or_Source_test_executed=False, author_Source=ref(Path(__file__)))
    print(json.dumps(write('receipt.json', receipt))); return 0 if accepted else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--build', required=True); p.add_argument('--run-only', action='store_true'); p.add_argument('--group',required=True,choices=['output_processor','exterior']); raise SystemExit(main(p.parse_args()))

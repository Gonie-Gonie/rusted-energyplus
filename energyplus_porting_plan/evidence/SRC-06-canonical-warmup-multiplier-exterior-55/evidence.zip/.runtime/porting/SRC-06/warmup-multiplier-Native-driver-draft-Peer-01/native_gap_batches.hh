// Private original-core unit batch ABI. No scientific initialization here.
#pragma once
#include <nlohmann/json_fwd.hpp>
#include <string>

namespace NativeGapBatch {
nlohmann::json run_warmup_batch(nlohmann::json const &named_inputs);
nlohmann::json run_multiplier_predictor_batch(nlohmann::json const &named_inputs);
} // namespace NativeGapBatch

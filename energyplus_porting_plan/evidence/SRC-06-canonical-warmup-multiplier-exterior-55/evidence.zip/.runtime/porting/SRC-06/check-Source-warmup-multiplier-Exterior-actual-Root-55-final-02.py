"""Read-only final55 aggregate: six explicitly different evidence scopes.

No Cargo/Native invocation or canonical mutation. Writes one fresh review only.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re, subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
GUARD=D/'Constant-Exterior-category-guards-Peer-55-06.py'
assert hashlib.sha256(GUARD.read_bytes()).hexdigest()=='aeb1e6934ed858fcf8a52f5f8b788ec03fcb6a9a4e9cd308bdc8ef16813c947d'
s=importlib.util.spec_from_file_location('qualified55_final_guard',GUARD);g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
APP_NAMES=[
 'Root-Exterior-factory-phase-context-application-55-07',
 'Root-ShadowCalculation-application-55-08',
 'Root-Zone-primary-convection-application-55-09',
 'Root-Setup-cold-weather-application-55-10',
 'Root-SkyDif-output-predicate-application-55-11',
]

def logs(run):
    out={k:g.ref(g.checked(run[k])) for k in ('stdout','stderr')}
    return out

def genuine(run,command,head):
    g.need(run['exit_code']==0 and run['launch_error'] is None and run['command']==command and run['source_bytes_match_before_and_after'] and run['repository_before']==run['repository_after'] and run['repository_before']['head']==head,'Actual successful isolated process/argv/Source/repository custody')
    env=run['launch_environment_selected'];target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
    g.need(Path(env['CARGO_TARGET_DIR']).resolve()==target and all(v is None for k,v in env.items() if k!='CARGO_TARGET_DIR') and not run['cargo_compiler_artifacts_capture']['requested'],'Existing target55 and recorder-selected environment')

def plan_of(doc):
    for key in ('complete_proposed_compiler_Source_plan','complete_compiler_plan'):
        if key in doc:return doc[key]
    raise AssertionError('Explicit complete compiler plan reference')

def setup(pr,p,draft):
    _,p3,c3=g.h.prepared(p['carried03_prepared']['path']+'#'+p['carried03_prepared']['sha256'])
    _,p2,c2=g.h.prior(p3)
    _,_,original=g.h.old.original.prepared(p2['original_prepared']['path']+'#'+p2['original_prepared']['sha256'])
    diag_ref=g.ref(D/'source-Weather-gap-diagnostic-Outer-55-04/draft.json');diag=g.read(diag_ref)
    math_ref=g.ref(D/'source-Weather-UCRT-math-provider-Outer-55-05-02/draft.json');math=g.read(math_ref)
    app06_ref=g.ref(g.APP/'receipt.json');app06=g.read(app06_ref)
    g.need(app06['accepted'] and not app06['findings'] and app06['prepared']==pr and app06['all_final_compiler_bytes_exact'] and app06['complete_compiler_plan']==p['complete_compiler_plan'],'Actual06 application')
    g.peer(app06['independent_mechanical_peer'],p['coherent_draft'])
    stages=[];previous=p['complete_compiler_plan']
    for name in APP_NAMES:
        ar=g.ref(D/name/'receipt.json');app=g.read(ar);dr=app['draft'];doc=g.read(dr)
        peer=app.get('independent_review',app.get('independent_peer'))
        g.need(app['accepted'] and not app['findings'] and app['base_HEAD']==p['base_HEAD'] and app['prior_complete_compiler_plan']==previous and app['complete_compiler_plan']==plan_of(doc),'Exact chronological application '+name)
        g.peer(peer,dr)
        g.need(set(app['changed_files'])=={r['canonical_path'] for r in doc['files']} and app['literal_applications']==2*len(doc['files']),'Actual bounded changed rows '+name)
        stages.append(dict(name=name,application=ar,independent_peer=peer,draft=dr,prior_compiler_plan=previous,complete_compiler_plan=app['complete_compiler_plan'],author_Source=app.get('author_Source') or g.read(peer)['author_Source']))
        previous=app['complete_compiler_plan']
    g.need(previous['sha256']=='685fee2a4addd8ae015d82d243148df4ad9a9a716430ca502a00d496262c975d','Root actual final11 plan')
    docs=[original,c2,c3,diag,math,draft]+[g.read(v['draft']) for v in stages]
    apply=g.h.g.literal();first={};last={};literal_count=0
    for doc in docs:
        for row in doc['files']:
            n=row['canonical_path'];absent=row.get('before_absent',row['before'] is None)
            a=b'' if absent else g.checked(row['before']).read_bytes();b=g.checked(row['proposed']).read_bytes();fw,iv=g.h.diffs(row)
            g.need(apply(a,g.checked(fw).read_bytes())==b and apply(b,g.checked(iv).read_bytes())==a,'Successive exact forward/inverse '+n);literal_count+=2
            if n in last:g.need(g.checked(last[n]['proposed']).read_bytes()==a,'True successive whole Source parent '+n)
            else:
                first[n]=dict(before=row['before'],before_absent=absent)
                if absent:g.need(subprocess.run(['git','cat-file','-e','HEAD:'+n],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0,'Genuine new Source '+n)
                else:g.need(subprocess.check_output(['git','show','HEAD:'+n],cwd=R)==a,'Actual committed before Source '+n)
            last[n]=row
    final=g.read(previous);rows={e['path']:e for e in final['entries']};items=[]
    for n,row in sorted(last.items()):
        actual=g.ref(R/n);entry=rows[n]
        g.need((actual['sha256'],actual['bytes'])==(row['proposed']['sha256'],row['proposed']['bytes'])==(entry['final_sha256'],entry['final_bytes']),'Final selected live/archive/whole '+n)
        items.append(dict(canonical_path=n,first=first[n],final=row['proposed']))
    g.need((len(items),sum(v['before_absent'] for v in first.values()),literal_count)==(53,18,136),'Final53 Source35old18new136 literal applications')
    g.exact(final)
    return p3,p2,diag,math,stages,previous,final,items

def old_passes(p,p3,p2,fixtures,protected):
    out=[]
    for group,stage,count,bits,plan_ref,app_ref,launcher in [
      ('warmup','55-02',69,45072,p3['prior_compiler_plan'],p3['prior_application'],p2['launch_Source']),
      ('multiplier_predictor','55-03',21,17893,p3['complete_compiler_plan'],g.ref(g.h.APP/'receipt.json'),p3['launch_Source'])]:
        rr=g.ref(D/('canonical-source-gap-batch-'+group+'-Root-'+stage+'/receipt.json'));run=g.read(rr)
        command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',group,str(g.checked(fixtures[group]))]
        genuine(run,command,p['base_HEAD']);snapshot=g.archive(run,g.read(plan_ref));actual_logs=logs(run)
        lines=g.checked(actual_logs['stdout']).read_text(encoding='utf8').splitlines()
        count_line='Native warmup cohort: 69 full persistent RecKeep/Check calls; 45072 strict finite fields; no prior cohort rerun' if group=='warmup' else 'Multiplier2 genuine persistent full calls=21; strict raw-bit state/return observations=17893; raw getter multiplier2; no history/expected restore; private cache unobserved'
        g.need(lines==['running 1 original-core gap cohort group='+group+' on process main',count_line,'cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; group='+group+'; full-call records='+str(count)+'; private cache state unobserved'],'Exact historical PASS/count/stdout')
        guards=[]
        for phase in ('before','after'):
            gr=g.ref(D/('Root-runtime-fixture-'+group+'-guard-'+stage)/(phase+'.json'));guard=g.read(gr)
            g.need(guard['application']==app_ref and guard['command']==command and guard['selected_group']==group,'Historical real application/command guard')
            if phase=='before':g.need(guard['protected']==protected,'Historical original path-spelling fixture refs')
            else:g.need(guard['accepted'] and not guard['findings'] and guard['actual_receipt']==rr and guard['exit_code']==0 and guard['protected_before']==guard['protected_after']==protected and guard['launch_Source']==launcher,'Whole historical guards, not relabelled current executions')
            guards.append(gr)
        out.append(dict(group=group,actual_stage=stage,Source_compared_call_records=count,Source_strict_state_and_return_raw_fields=bits,actual_Source_receipt=rr,complete_compiler_plan=plan_ref,recorded_source_snapshot=snapshot,all_stage_archived_compiler_inputs_exact=True,external_fixture=fixtures[group],fixture_projection=p3['fixture_proofs'][group],fixture_before_after_guards=guards,logs=actual_logs,launch_Source=launcher))
    return out

def categories(p,fixtures,protected,stages):
    normalized=[g.ref(g.checked(v)) for v in protected];out=[]
    cases=[('internal_gains','55-06',g.APP,p['complete_compiler_plan'],g.ref(g.APP/'receipt.json')),
      ('surface_internal_gains','55-10',D/APP_NAMES[3],stages[3]['complete_compiler_plan'],stages[3]['application']),
      ('beam_producer','55-11',D/APP_NAMES[4],stages[4]['complete_compiler_plan'],stages[4]['application'])]
    for cat,stage,folder,plan_ref,app_ref in cases:
        if stage=='55-06':folder=D/('Root-Exterior-category-'+cat+'-guard-55-06')
        before_ref=g.ref(folder/('before.json' if stage=='55-06' else cat+'-before.json'))
        after_ref=g.ref(folder/('after.json' if stage=='55-06' else cat+'-after.json'))
        before=g.read(before_ref);after=g.read(after_ref);rr=after['actual_receipt'];run=g.read(rr);command=g.command(fixtures,cat)
        genuine(run,command,p['base_HEAD']);count,excluded=g.COUNTS[cat]
        g.need(after['accepted'] and not after['findings'] and after['exit_code']==0 and before['application']==after['application']==app_ref and before['command']==command and before['complete_compiler_plan']==after['complete_compiler_plan']==plan_ref,'Real category application/plan/argv/success guards '+cat)
        g.need(before['protected']==after['protected_before']==after['protected_after']==normalized,'All seven actual external fixtures stable with normalized path spelling '+cat)
        if stage=='55-06':g.need(after['Source_and_seven_fixtures_stable'] and after['success_milestone_directly_observed'],'Original06 direct completion')
        else:g.need(after['Source_and_fixtures_stable'],'Later isolated stable selected category')
        snapshot=g.archive(run,g.read(plan_ref));actual_logs=logs(run);g.need(after['logs']==actual_logs,'Complete actual logs '+cat)
        lines=g.checked(actual_logs['stdout']).read_text(encoding='utf8').splitlines()
        g.need(len(lines)==5 and lines[0]=='running 1 original-core gap cohort group=exterior category='+cat+' on process main' and lines[1]=='Source Exterior category complete: category='+cat+'; admitted_records='+str(count)+'; Native_retained_records='+str(count+excluded)+'; excluded_records='+str(excluded)+'; Weather_phase_checks=0' and lines[2].startswith('Source Exterior selected category: '+cat+'; admitted call records '+str(count)+'; Native retained records '+str(count+excluded)+'; excluded exploratory records '+str(excluded)+'; Weather phase checks 0; Source output directory ') and lines[3]=='cohort native_controlled_air_cohort ... ok' and lines[4]=='cohort result: ok. 1 passed; 0 failed; group=exterior; category='+cat+'; admitted-call records='+str(count)+'; private cache state unobserved','Direct actual whole-category completion milestone '+cat)
        stderr=g.checked(actual_logs['stderr']).read_text(encoding='utf8')
        g.need('Finished `test` profile' in stderr and 'Running src\\lib.rs (' in stderr and not re.search(r'^error(?:\[|:)',stderr,re.M),'Actual same-target process main '+cat)
        launch_ref=after.get('launch_Source',after.get('author_Source'))
        if launch_ref is None:launch_ref=stages[4]['author_Source']
        g.checked(launch_ref)
        out.append(dict(category=cat,actual_stage=stage,Source_compared_call_records=count,Native_retained_records=count+excluded,excluded_records=excluded,actual_Source_receipt=rr,complete_compiler_plan=plan_ref,recorded_source_snapshot=snapshot,fixture_before_after_guards=[before_ref,after_ref],logs=actual_logs,launch_Source=launch_ref,success_milestone_directly_observed=True,ep_runtime_compile_messages=len(re.findall(r'^\s*Compiling ep_runtime ',stderr,re.M))))
    g.need(sum(v['Source_compared_call_records'] for v in out)==33,'Exactly33 direct successful remaining records')
    return out

def failures(p2,p3,diag,math,p,stages):
    # Explicit whitelist, never a filesystem glob or historical-failure erasure.
    values=[(p2['failed_Source_attempt'],p2['prior_compiler_plan'],'initial cfg compile'),
      (p3['failed_Source_attempts'][0],p3['prior_compiler_plan'],'multiplier observer resolver setup'),
      (p3['failed_Source_attempts'][1],p3['prior_compiler_plan'],'Exterior workspace-path setup'),
      (diag['actual_failed_Exterior_receipt'],p3['complete_compiler_plan'],'strict Weather inverse-trig'),
      (math['actual_Source_failure'],plan_of(diag),'Weather diagnostic strict inverse-trig'),
      (g.ref(D/'canonical-source-gap-batch-exterior-Root-55-05/receipt.json'),plan_of(math),'genuine Constant blank-type warning boundary')]
    for category,stage,plan_ref in [
      ('beam_producer','55-06',p['complete_compiler_plan']),('surface_internal_gains','55-06',p['complete_compiler_plan']),
      ('beam_producer','55-07',stages[0]['complete_compiler_plan']),('beam_producer','55-08',stages[1]['complete_compiler_plan']),
      ('beam_producer','55-09',stages[2]['complete_compiler_plan']),('beam_producer','55-10',stages[3]['complete_compiler_plan'])]:
        values.append((g.ref(D/('canonical-source-gap-batch-exterior-'+category+'-Root-'+stage+'/receipt.json')),plan_ref,'actual '+category+' setup/producer boundary '+stage))
    out=[]
    for rr,plan_ref,kind in values:
        run=g.read(rr);g.need(run['exit_code'] in (1,101) and run['launch_error'] is None and run['source_bytes_match_before_and_after'],'Preserved actual failed command')
        snapshot=g.archive(run,g.read(plan_ref));out.append(dict(actual_Source_receipt=rr,kind=kind,exit_code=run['exit_code'],complete_compiler_plan=plan_ref,recorded_source_snapshot=snapshot,logs=logs(run)))
    g.need(len(out)==12 and len({v['actual_Source_receipt']['path'] for v in out})==12,'All twelve actual prior failed commands retained')
    metadata=[]
    for path in ('Root55-04-Weather-diagnostic-launch.log','Root55-06-02-surface-gains-launch.log','Root55-10-Setup-cold-weather-launch.log'):
        metadata.append(dict(log=g.ref(D/path),scientific_command_not_started=True,qualification='Root-reviewed helper metadata preflight stop; separate from twelve actual failed Source commands. Whole original encoding retained.'))
    return out,metadata

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepared',required=True);ap.add_argument('--progress-review',required=True);a=ap.parse_args()
    pr,p,draft,old,plan06,fixtures,protected,snapshot05=g.prepared(a.prepared)
    progress_ref=g.argument(a.progress_review);progress=g.peer(progress_ref,p['coherent_draft'])
    g.need(progress.get('qualified_code_derived_progress') is not None,'Explicit independently qualified code-derived prefix')
    p3,p2,diag,math,stages,final_ref,final,items=setup(pr,p,draft)
    earlier=old_passes(p,p3,p2,fixtures,protected);later=categories(p,fixtures,protected,stages)
    failed,metadata=failures(p2,p3,diag,math,p,stages)
    impact=dict(accepted=True,all_three_groups_same_Source_snapshot=False,all_three_groups_same_compiled_binary_claim=False,all_three_Exterior_categories_same_Source_snapshot=False,
      scopes=[dict(scope='warmup',stage='55-02',records=69),dict(scope='multiplier',stage='55-03',records=21),dict(scope='Exterior ordered inferred prefix',stage='55-05',records=137,direct_milestones=False),dict(scope='internal_gains',stage='55-06',records=9),dict(scope='surface_internal_gains',stage='55-10',records=6),dict(scope='beam_producer',stage='55-11',records=18)],
      original_cfg_bridge=g.read(g.ref(g.h.APP/'receipt.json'))['warmup_impact_bridge'],
      warmup_multiplier='Accepted bodies, primary inputs and expected fixtures unchanged. Later cfg Exterior factories/category orchestration and explicit Shadow/geometry setup/SkyDif output alias changes are outside these isolated warmup/multiplier consumed paths. UCRT is a local inverse-trig provider called only by Weather DetermineSunUpDown, with no eager/global symbol rebinding. Historical process results remain at their actual plans.',
      prior05_prefix='Actual ordered checked137 completions independently inferred before unique first no-surface GainFactory blank Constant warning. The first4 numerical helpers/primary inputs/expected fixture are whole-preserved; no later physical producer is inferred from that failed process.',
      internal06='All9 no-surface full IHG calls directly passed06. Later failure diagnostics, actual geometry-only Shadow/Zone/cold-weather setup and SkyDif alias changes do not alter the no-surface factory/body inputs or observed IHG outputs; no rerun/same-binary claim.',
      surface10='All6 actual surface IHG calls directly passed10. Final11 changes only the computed SkyDif detailed predicate handed to the output declaration child; it does not rewrite the successful IHG numerical methods/actual primary/expected fixtures. Historical10 pass is preserved with its exact full compiler snapshot, not relabelled as a new11 invocation.',
      beam11='All18 admitted beam producer records directly passed final11, with9 exploratory shading records retained in fixture and explicitly excluded. No previous successful body was rerun solely for metadata symmetry.')
    result=dict(schema='src06-qualified-six-scope-55-final-actual.v1',accepted=True,findings=[],base_HEAD=p['base_HEAD'],prepared=pr,application=stages[-1]['application'],complete_compiler_plan=final_ref,compiler_inputs=4556,Rust_sources=4542,
      selected_Source_files=items,selected_count=53,existing=35,new=18,literal_applications=136,correction_stages=stages,
      groups=earlier,Exterior_remaining_categories=later,Exterior_prior05_qualified_progress=dict(**draft['source05_qualified_progress'],independent_progress_review=progress_ref,recorded_source_snapshot=snapshot05),
      Exterior_external_fixture=fixtures['exterior'],Exterior_fixture_projection=p3['fixture_proofs']['exterior'],Exterior_admitted_records=170,Exterior_direct_new_milestone_records=33,Exterior_ordered_checked_prefix_records=137,Exterior_Native_full_retained_records=179,Exterior_exploratory_records_excluded=9,Exterior_raw_bit_denominator_unclaimed=True,
      total_admitted_record_units=260,record_unit_qualification='260 admitted record units, not260 full function calls: Weather47 records include101 phase checks; paired-call and unit records retain their own Native/Source definitions.',known_strict_state_and_return_raw_fields_warmup_and_multiplier=62965,all_seven_external_fixtures_stable=True,all4556_current_and_each_actual_stage_archived_wholes_exact=True,qualified_impact_bridge=impact,
      preserved_failed_Source_attempts=[v['actual_Source_receipt'] for v in failed],preserved_failed_Source_attempt_details=failed,metadata_only_preflight_stops=metadata,actual_accepted_selected_invocations=5,actual_failed_prior_invocations=12,
      gate_changes=0,policy_changes=0,new_old_scientific_body_or_normal_CLI_or_Native_invocations=0,
      math_draft=g.ref(D/'source-Weather-UCRT-math-provider-Outer-55-05-02/draft.json'),math_independent_peer=g.ref(D/'Peer-Weather-UCRT-math-provider-review-55-05-02/review.json'),diagnostic_draft=g.ref(D/'source-Weather-gap-diagnostic-Outer-55-04/draft.json'),category_warning_draft=p['coherent_draft'],
      math_import_provenance=math['actual_binary_imports'],same_operand_CRT_diagnosis=math['Root_same_operand_CRT_diagnosis'],environment_guard=p['environment_guard'],record_command_Source=p['record_command_Source'],
      qualification='All170 admitted Exterior records covered across inferred failed05 ordered137 and direct successful06/10/11 categories33. No single successful fullExterior170 process, same-binary/snapshot across all scopes, complete latest fifteen production CLI certificate, full Surface cadence proof, positive Propane numerical proof or private cache-state claim.',author_Source=g.ref(Path(__file__)))
    out=D/'Root-Source-warmup-multiplier-Exterior-actual-review-55-final';g.need(not out.exists(),'Fresh immutable final actual aggregate');out.mkdir();print(json.dumps(g.save(out/'review.json',result)))
if __name__=='__main__':main()

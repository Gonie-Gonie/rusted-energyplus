"""Passive IHG observations and exact Native-only constructor scope ledger."""
from pathlib import Path
import copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-IHG-beam-owner-observer-draft-Outer-08'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode());return ref(p)
def diff(p,a,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='preserved07-or-current',tofile='passive-gain-observers08')).encode());return ref(p)
def main():
 assert not O.exists();O.mkdir();prior=D/'source-IHG-beam-owner-observer-draft-Outer-07/draft.json';v=json.loads(prior.read_bytes());rows=copy.deepcopy(v['Sources']);root='crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress/'
 ingress=(R/rows[0]['proposed']['path']).read_bytes().decode();a='mod beam_observe;';assert ingress.count(a)==1;ingress=ingress.replace(a,a+'\nmod gains_observe;\nmod surface_gain_observe;',1)
 # Exact refinement requested by independent Root contextual read: same two
 # actual time-target calls before the actual Zone getter, like Native caller.
 marker='''        {
            let mut backend = error_backend(&mut error_state, &mut errors, &mut console);
            for kind in [
                hb::source_output_registration::TimeStepKind::Zone,
                hb::source_output_registration::TimeStepKind::System,
            ] {
                registration
                    .time_pointers
                    .setup_time_pointer(kind, &mut backend)?;
            }
        }
''';assert ingress.count(marker)==1;ingress=ingress.replace(marker,'',1);at='        zones.get_zone_data(';assert ingress.count(at)==1;ingress=ingress.replace(at,marker+at,1)
 source_gain=R/'crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input.rs';sg=source_gain.read_bytes().decode();report=sg[sg.index('pub(crate) struct SourceGainReport'):sg.index('pub(crate) struct SourceMiscGainObject')]
 members=re.findall(r'pub\(crate\) (\w+): f64,\s*// (\w+)',report)
 total=['TotRadiantGain','TotRadiantGainRate','TotVisHeatGain','TotVisHeatGainRate','TotConvectiveGain','TotConvectiveGainRate','TotLatentGain','TotLatentGainRate','TotTotalHeatGain','TotTotalHeatGainRate']
 other=['OtherRadGain','OtherRadGainRate','OtherConGain','OtherConGainRate','OtherLatGain','OtherLatGainRate','OtherLost','OtherLostRate','OtherTotGain','OtherTotGainRate']
 mapping=[(f'row.{field}',key)for field,key in members]+[(f'row.total[{i}]',key)for i,key in enumerate(total)]+[(f'row.other[{i}]',key)for i,key in enumerate(other)]
 gain=(D/'source-geometry-owner-bootstrap-work-Outer-01/gains_observe.rs').read_bytes().decode();mark='    // REPORT_FIELDS\n';assert gain.count(mark)==1;gain=gain.replace(mark,''.join(f'    bits({field},member(f,"{key}")?,"actual report {key}")?;\n'for field,key in mapping),1)
 native_cpp=D/'genuine-solar-gain-producers-draft-Outer-11/exterior_gap_batch.cpp';ns=native_cpp.read_bytes().decode();nr=ns[ns.index('json gain_report'):ns.index('json gain_state')];native_keys=re.findall(r'GAIN_REPORT\((\w+)\)',nr)[1:];missing=sorted(set(native_keys)-{key for _,key in mapping});assert len(mapping)==101 and len(native_keys)==114 and len(missing)==13
 obs_cp='crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/observation.rs';obs=(R/obs_cp).read_bytes()+(D/'source-geometry-owner-bootstrap-work-Outer-01/device_binding_observer.rs.fragment').read_bytes()
 specs=[(rows[0]['canonical_future_path'],ingress.encode()),(root+'beam_observe.rs',(D/'source-geometry-owner-bootstrap-work-Outer-01/beam_observe.rs').read_bytes()),(root+'gains_observe.rs',gain.encode()),(root+'surface_gain_observe.rs',(D/'source-geometry-owner-bootstrap-work-Outer-01/surface_gain_observe.rs').read_bytes()),(obs_cp,obs)]
 for cp,b in specs:
  old=next((r for r in rows if r['canonical_future_path']==cp),None);a=(R/old['proposed']['path']).read_bytes() if old else ((R/cp).read_bytes() if (R/cp).exists() else b'')
  run=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert run.returncode==0,run.stderr
  if cp!=obs_cp:b=run.stdout
  p=O/'proposed'/cp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  parse=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert parse.returncode==0,parse.stderr
  po=O/'parse'/f'{cp}.stdout.rs';po.parent.mkdir(parents=True,exist_ok=True);po.write_bytes(parse.stdout);pe=po.with_suffix('.stderr.txt');pe.write_bytes(parse.stderr)
  row={'canonical_future_path':cp,'proposed':ref(p),'forward':diff(O/'diffs'/f'{cp}.forward.diff',a,b),'inverse':diff(O/'diffs'/f'{cp}.inverse.diff',b,a),'Source_only_parse':{'argv':['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],'stdin':ref(p),'stdout':ref(po),'stderr':ref(pe),'exit_code':0,'syntax_only_no_contextual_typecheck':True}}
  if old:row['preserved07_proposed']=old['proposed'];rows[rows.index(old)]=row
  else:
   if (R/cp).exists():row['before']=ref(R/cp)
   rows.append(row)
 authorities=[]
 for np,ranges in [('src/EnergyPlus/DataHeatBalance.hh',[(861,898),(1719,1752),(1867,1874)]),('src/EnergyPlus/InternalHeatGains.cc',[(195,245),(1795,2014),(2580,2595),(6819,6869),(6925,6937),(7119,7172)]),('src/EnergyPlus/DemandManager.cc',[(1450,1555)])]:
  p=R/'.reference/energyplus-src/26.1.0'/np;b=p.read_bytes();git=subprocess.run(['git','-C',str(R/'.reference/energyplus-src/26.1.0'),'show','6f2e40d10250a105b49966baa24d843711e61048:'+np],capture_output=True,check=True).stdout;assert git==b;ls=b.splitlines(True);ext=[]
  for first,last in ranges:
   q=O/'Native'/f'{Path(np).name}-{first}-{last}';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b''.join(ls[first-1:last]));ext.append({'first':first,'last':last,'source':ref(q)})
  authorities.append({'Native_path':np,'whole':ref(p),'pinned_Git_whole_exact':True,'extents':ext})
 ledger=save(O/'observed-field-and-omitted-ctor-ledger.json',{'schema':'src06-precise-IHG-observation-scope.v1','Native_observer':ref(native_cpp),'actual_Source_owner':ref(source_gain),'represented_report_f64_members':{'count':101,'member_map':mapping},'represented_report_fuel_arrays':{'OtherPower':15,'OtherConsump':15},'Native_only_ZoneEquipData_fields':[{'field':'ManageDemand','ctor':False,'scope':'Actual OtherEquipment array never targeted by the retained DemandManager SetLimitLoad switch (only ExteriorLights/Lights/ZoneElectric/thermostats). The direct unit route does not call DemandManager; no fake Source bool exists.'},{'field':'DemandLimit','ctor_raw_bits':'0000000000000000','scope':'Same actual ZoneOtherEq no-demand writer exclusion; no Source value fabricated.'},{'field':'CO2DesignRate','ctor_raw_bits':'0000000000000000','scope':'Original2590 writer and6927 consumer target separate ZoneCO2Gen rows. The actual OtherEquipment getter uses CO2RateFactor; no Source CO2DesignRate field or value fabricated.'}],'Native_only_ZoneReportVars_f64_fields':{'fields':missing,'each_ctor_raw_bits':'0000000000000000','writer_exclusion':'CalcZoneITEq contains the whole ITE reset/calculation writes, and the sole actual InitInternalHeatGains call6931 is guarded by TotITEquip>0. All admitted primary IDFs contain zero ElectricEquipment:ITE:AirCooled objects; the real getter count0 and observed total0 are independently checked. No Source ITE/SumTin/SumTout scalar exists and none is serialized as Source.'},'Source_only_or_unobserved_state_qualification':['Native gain_state does not expose full OP registry/SpaceType/meter metadata; production Propane/OP semantics retain the independent static08ea peer, no new OP numerical equivalence claim from these IHG rows.','Source errors_found, zeroPointerValue, people/co2 allocation shapes, space power-reduction factor, refrigeration credit, other module internal counters/flags and complete Facility owner are not all present in Native gain_state. Their true source owners/getters remain unchanged; no whole all-owner equivalence claim.','SourceAir zone/space allocation and Solar enclosure allocation are executed at their genuine caller positions. Native AllocateHeatBalArrays also owns unobserved fan/resiliency/cadence state; this cohort does not claim whole allocator output equivalence. Source surface allocator retains its real history owner, but all unobserved CTF histories/reports are outside this comparison.'],'scope':'Native-only constructor/writer-exclusion proof is separate from actual Source numerical comparisons and never counted as observed Source assertions. No expected state is used as input.','Native_authorities':authorities})
 result=copy.deepcopy(v);result['author_Source']=ref(Path(__file__));result['preserved07']=ref(prior);result['Sources']=rows;result['omitted_ctor_and_observed_member_ledger']=ledger;result['primary_ingress']=ref(D/'source-Exterior-primary-ingress-draft-Outer-02/draft.json');result['caller_order_correction']='Root full06 read requested moving the same two actual SetupTimePointers calls before NoSurface Zone getter. 08 performs only that move; geometry factory already ordered them before full HB. No duplicate calls/state seeds.';result['observer_scope']+=['Full represented IHG equipment fields/rates/energies, all101 represented report scalar fields and both15-fuel arrays, four26-element end-use arrays, live latent rows, actual cached7-device values and stored target relationships, actual refrigeration flags/count/shape and full diagnostics.','Positive opaque surface observer adds actual enclosure names/counts/SpacePtrs/areas/absorptance/F/ScriptF/recalc/multipliers/radiant gain and actual per-Surface Construction/enclosure/area/absorptance/radiant-gain fields. Source matrix storage is projected to Native passive physical flattening only, never recomputed.'];result['pending']=['Full independent NEW contextual/member/borrow/observer review and eventual single Root contextual build/run.','Final cfg Exterior module/finite input-based selection/dispatch is not supplied yet. No complete Exterior Source result or170 passed-record claim.'];print(json.dumps({'draft':save(O/'draft.json',result),'ledger':ledger}))
if __name__=='__main__':main()

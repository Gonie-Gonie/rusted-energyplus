"""Root-only two private caller compiles and one unchanged original-core link.

Requires a final peer-bound READY manifest. Never executes any resulting binary.
Frozen environment values are read in memory only; no value dump is recorded.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ast, importlib.util, hashlib, json, re, subprocess, time
R = Path(__file__).resolve().parents[3]; D = R / '.runtime/porting/SRC-06'; B = R / '.runtime/ep261-gcc13-o0'


def ref(p):
    p = p.resolve()
    with p.open('rb') as f: h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(), sha256=h, bytes=p.stat().st_size)


def checked(v):
    p = (R / v['path']).resolve(); actual = ref(p)
    assert actual['sha256'] == v['sha256'] and actual['bytes'] == v.get('bytes', actual['bytes'])
    return p


def read(p): return json.loads(p.read_bytes())


def norm(v): return str(v).replace('\\', '/').casefold()





def parent_union_custody(p):
    parent = read(checked(p['previous_ready_manifest']))
    actual = read(checked(p['actual_accepted_build04']))
    assert actual['accepted'] and not actual['findings'] and actual['Native_bytes_match_before_and_after'] and actual['reviewed_manifest'] == p['previous_ready_manifest']
    assert all(actual['original_core_member_counts'].values()) and not actual['forbidden_derived_object_witnesses']
    assert p['inherited_original_core_recipe'] == parent['inherited_original_core_recipe'] and p['actual_original_core_build43'] == parent['actual_original_core_build43']
    driver = read(checked(p['new_driver_draft']))
    driver_peer = read(checked(p['new_driver_peer']))
    assert (driver_peer.get('accepted') is True or driver_peer.get('status','').startswith('ACCEPTED_')) and not driver_peer['findings'] and driver_peer['reviewed_draft'] == p['new_driver_draft']

    original_driver = driver
    driver = read(checked(p['history_ADL_driver05']))
    correction = read(checked(driver['history_compile_correction']))
    compile_peer = read(checked(p['history_ADL_independent_peer']))
    assert compile_peer['accepted'] and not compile_peer['findings'] and compile_peer.get('reviewed_draft',compile_peer.get('reviewed_packet')) == p['history_ADL_driver05']
    assert correction['actual_failed_build'] == p['preserved_failed_build05'] and correction['original_driver'] == p['new_driver_draft']
    failed = read(checked(p['preserved_failed_build05']))
    assert not failed['accepted'] and failed['Native_bytes_match_before_and_after'] and failed['actual_caller_compile_invocations'] == 2 and failed['actual_link_invocations'] == 0
    assert driver['Exterior_independent_peer'] == p['independent_leaves'][2]['peer']
    assert driver['named_inputs'] == original_driver['named_inputs'] and driver['Exterior_Source'] == original_driver['Exterior_Source']
    for old,new in zip(original_driver['driver_files'],driver['driver_files'],strict=True): assert checked(old['proposed']).read_bytes() == checked(new['proposed']).read_bytes()
    assert correction['before_combined'] == original_driver['combined_TU'] and correction['proposed_combined'] == driver['combined_TU']
    def qualify(old):
        a=b'        apply_inputs(factory,step.at("inputs"));auto operation='
        b=b'        AirHistoryDetail::apply_inputs(factory,step.at("inputs"));auto operation='
        assert old.count(a)==1
        result=old.replace(a,b);assert result.replace(b,a)==old
        return result
    assert qualify(checked(correction['before_fragment']).read_bytes()) == checked(correction['proposed_fragment']).read_bytes()
    assert qualify(checked(correction['before_combined']).read_bytes()) == checked(correction['proposed_combined']).read_bytes()
    assert p['caller_Sources'] == [driver['driver_files'][0]['proposed'], driver['combined_TU'],driver['Exterior_Source']] and p['common_header'] == driver['driver_files'][1]['proposed']
    assert p['named_inputs'] == driver['named_inputs'] and driver['actual_accepted_parent_build'] == p['actual_accepted_build04']
    p4 = read(checked(p['independent_leaves'][0]['draft']))
    history = read(checked(p['independent_leaves'][1]['draft']))
    exterior = read(checked(p['independent_leaves'][2]['draft']))
    assert driver['P4_draft'] == p['independent_leaves'][0]['draft'] and driver['history_draft'] == p['independent_leaves'][1]['draft']
    assert p4['accepted_P1_prefix'] == history['accepted_P1_prefix'] == driver['accepted_P1_prefix'] == parent['caller_Sources'][1]
    parts = [p4['accepted_P1_prefix'], p4['appended_P4_only_fragment'], history['appended_fragment']]
    assert parts[2] == correction['before_fragment']
    parts[2] = correction['proposed_fragment']
    assert checked(driver['combined_TU']).read_bytes() == b''.join(checked(x).read_bytes() for x in parts)
    assert driver['Exterior_draft'] == p['independent_leaves'][2]['draft'] and p['caller_Sources'][2] == exterior['proposed']
    named = read(checked(p['named_inputs']))
    assert named == dict(schema='src06-original-core-gap-batch-input.v1', output_processor=read(checked(p4['named_inputs'])), air_history=read(checked(history['named_inputs'])),exterior=read(checked(exterior['named_inputs']))['exterior'])
    rows = [p['previous_ready_manifest'],p['actual_accepted_build04'],p['new_driver_draft'],p['new_driver_peer'],*parts]
    def collect(value):
        if isinstance(value,dict):
            if {'path','sha256','bytes'} <= value.keys(): rows.append(value)
            else:
                for key,child in value.items():
                    # Rust Source-context files are review context, not a Native build dependency.
                    if key not in ['Source_context','Source_contexts']: collect(child)
        elif isinstance(value,list):
            for child in value: collect(child)
    for value in [original_driver,driver,p4,history,exterior,correction,p['history_ADL_independent_peer'],p['history_ADL_driver05'],p['preserved_failed_build05'],p['preserved_predecessor_READY']]: collect(value)
    return [ref(checked(v)) for v in {x['path']:x for x in rows}.values()]


def union_custody(p):
    parent = read(checked(p['new_parent_READY08']))
    inherited_source = checked(p['inherited_build_Source'])
    spec = importlib.util.spec_from_file_location('exact_prior_Native08_readonly_guards', inherited_source)
    inherited = importlib.util.module_from_spec(spec); spec.loader.exec_module(inherited)
    rows = inherited.union_custody(parent)
    actual = read(checked(p['actual_accepted_build07']))
    assert actual['accepted'] and not actual['findings'] and actual['reviewed_manifest'] == p['new_parent_READY08'] and actual['Native_bytes_match_before_and_after']
    assert all(actual['original_core_member_counts'].values()) and not actual['forbidden_derived_object_witnesses']
    assert p['inherited_original_core_recipe'] == parent['inherited_original_core_recipe'] and p['actual_original_core_build43'] == parent['actual_original_core_build43']
    driver = read(checked(p['new_driver_draft'])); peer = read(checked(p['new_driver_peer']))
    assert peer['accepted'] and not peer['findings'] and peer.get('reviewed_draft',peer.get('reviewed_packet')) == p['new_driver_draft']
    assert driver['original_READY'] == p['new_parent_READY08'] and driver['accepted_prefix'] == parent['caller_Sources'][1]
    warm = read(checked(driver['warmup_draft'])); mult = read(checked(driver['multiplier_draft']))
    assert p['independent_leaves'] == [dict(draft=driver['warmup_draft'],peer=driver['independent_leaf_peers'][0]),dict(draft=driver['multiplier_draft'],peer=driver['independent_leaf_peers'][1])]
    assert warm['parent_original_caller_Source'] == mult['accepted_prefix'] == driver['accepted_prefix']
    assert driver['warmup_fragment'] == warm['fragment'] and driver['multiplier_fragment'] == mult['appended_fragment']
    assert checked(driver['combined_TU']).read_bytes() == b''.join(checked(v).read_bytes()for v in [driver['accepted_prefix'],warm['fragment'],mult['appended_fragment']])
    assert p['caller_Sources'] == [driver['driver_files'][0]['proposed'],driver['combined_TU']] and p['common_header'] == driver['driver_files'][1]['proposed']
    assert p['named_inputs'] == driver['named_inputs'] and p['allowed_run_groups'] == driver['allowed_run_groups'] == ['warmup','multiplier_predictor']
    named = read(checked(p['named_inputs']))
    assert named == dict(schema='src06-original-core-gap-batch-input.v1',warmup=read(checked(warm['named_inputs'])),multiplier_predictor=read(checked(mult['named_inputs'])))
    literal_source = checked(p['literal_application_Source']); tree = ast.parse(literal_source.read_text(encoding='utf-8-sig'))
    fn = next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name == 'apply_literal')
    ns = dict(re=re); exec(compile(ast.Module(body=[fn],type_ignores=[]),'<accepted exact literal only>','exec'),ns)
    for row in driver['driver_files']:
        before=checked(row['before']).read_bytes();after=checked(row['proposed']).read_bytes()
        assert ns['apply_literal'](before,checked(row['diffs']['forward']).read_bytes()) == after
        assert ns['apply_literal'](after,checked(row['diffs']['inverse']).read_bytes()) == before
    def collect(value):
        if isinstance(value,dict):
            if {'path','sha256','bytes'} <= value.keys(): rows.append(value)
            else:
                for key,child in value.items():
                    if key not in ['Source_context','Source_contexts','Source_same_owner_contexts','current_Source_bodies']: collect(child)
        elif isinstance(value,list):
            for child in value: collect(child)
    for value in [driver,warm,mult,p['new_parent_READY08'],p['actual_accepted_build07'],p['inherited_build_Source'],p['inherited_run_Source'],p['build_Source'],p['run_Source'],p['new_driver_peer']]: collect(value)
    return [ref(checked(v))for v in {x['path']:x for x in rows}.values()]


def main(a):
    assert a.build_only
    name, sha = a.manifest.rsplit('#', 1); mp = (R / name).resolve(); assert ref(mp)['sha256'] == sha
    p = read(mp); assert p['status'] == 'READY_FOR_ROOT_TWO_COMPILES_ONE_ORIGINAL_CORE_LINK'
    assert checked(p['build_Source']) == Path(__file__).resolve()
    binding_rows = union_custody(p)
    base = read(checked(p['inherited_original_core_recipe']))
    parent = read(checked(p['actual_original_core_build43'])); assert parent['accepted'] and not parent['findings'] and parent['Native_bytes_match_before_and_after']
    assert len(p['independent_leaves']) == 2
    for leaf in p['independent_leaves']:
        peer = read(checked(leaf['peer'])); assert peer['accepted'] and not peer['findings'] and peer.get('reviewed_draft', peer.get('reviewed_packet')) == leaf['draft']
        checked(leaf['draft'])
    frozen = read(checked(base['frozen_environment'])); assert frozen['accepted'] and frozen['provider_set_complete_for_this_build']
    environment = frozen['environment']; assert len(environment) == len({k.casefold() for k in environment}) and all(isinstance(k, str) and isinstance(v, str) for k, v in environment.items())
    # Values never leave this process except as the actual child environment.
    env_hash = hashlib.sha256(json.dumps(environment, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf8')).hexdigest()
    compiler = checked(frozen['compiler']); sr = Path(next(v for k, v in environment.items() if k.casefold() == 'systemroot'))
    assert norm(next(v for k, v in environment.items() if k.casefold() == 'path').split(';')[0]) == norm(compiler.parent)
    unit = Path(p['fresh_unit_directory']).resolve(); assert unit == Path('D:/CodexBuild/rusted-energyplus/SRC-06/original-core-gap-batch-Root-08').resolve() and not unit.exists()
    output = D / 'original-core-gap-batch-build-Root-08'; assert not output.exists()
    assert len(p['compile_argvs']) == 2 and len(p['caller_Sources']) == 2 and len(p['objects']) == 2
    original_compile = list(base['one_compile_argv'])
    old_include = '-I' + (D / 'system-report-native-draft-Peer-39').as_posix()
    new_include = '-I' + checked(p['common_header']).parent.as_posix()
    assert original_compile.count(old_include) == 1
    for argv, source, obj in zip(p['compile_argvs'], p['caller_Sources'], p['objects'], strict=True):
        expected = list(original_compile); expected[expected.index(old_include)] = new_include
        expected[expected.index('-c') + 1] = checked(source).as_posix(); expected[expected.index('-o') + 1] = obj
        assert argv == expected and norm(argv[0]) == norm(compiler)
        assert Path(obj).resolve().is_relative_to(unit)
    expected_link = list(base['one_link_argv']); matches = [i for i, x in enumerate(expected_link) if norm(x) == norm(base['object'])]; assert len(matches) == 1; oi = matches[0]; expected_link[oi:oi+1] = p['objects']
    expected_link[expected_link.index('-o') + 1] = p['binary']
    expected_link = [('-Wl,-Map,' + p['map']) if x.startswith('-Wl,-Map,') else ('-Wl,--out-implib,' + p['implib']) if x.startswith('-Wl,--out-implib,') else x for x in expected_link]
    assert expected_link == p['link_argv'] and norm(p['link_argv'][0]) == norm(compiler)
    for argv in [*p['compile_argvs'], p['link_argv']]:
        assert '-ffp-contract=off' in argv and not any('fast-math' in x for x in argv)
    assert all('-UNDEBUG' in argv for argv in p['compile_argvs'])
    for key in ['binary', 'map', 'implib']: assert Path(p[key]).resolve().is_relative_to(unit)

    def custody():
        rows = [ref(mp), p['inherited_original_core_recipe'], p['actual_original_core_build43'], *base['protected_files'], *p['caller_Sources'], p['common_header'], p['named_inputs']]
        rows += [x[k] for x in p['independent_leaves'] for k in ['draft', 'peer']]
        rows += p['input_files']
        rows += binding_rows
        checkout = p['Native_checkout']; native = (R / checkout['path']).resolve()
        assert subprocess.check_output(['git', '-C', str(native), 'rev-parse', 'HEAD'], text=True).strip() == checkout['pinned_HEAD']
        assert subprocess.check_output(['git', '-C', str(native), 'status', '--porcelain=v1', '--untracked-files=no'], text=True) == checkout['tracked_status']
        for row in p['Native_authorities']:
            rows.append(row['whole']); rows += [x['source'] for x in row.get('extents', [])]
        rows = [ref(checked(v)) for v in {x['path']: x for x in rows}.values()]
        assert len(read(checked(base['live_compile_registry']))) == base['registry_count'] == 800
        assert all(not (folder / Path(row['path']).name).exists() for folder in [unit, R, sr / 'System32', sr / 'System', sr] for row in base['pinned_runtime_DLLs'])
        return dict(protected_files=rows, frozen_environment_ref=base['frozen_environment'], environment_values_sha256=env_hash, environment_key_count=len(environment), no_environment_values_recorded=True, live_compile_registry=base['live_compile_registry'], registry_count=800, earlier_DLL_shadows_absent=True)

    before = custody(); output.mkdir(); unit.mkdir()

    def write(name, value):
        p0 = output / name
        with p0.open('xb') as f: f.write((json.dumps(value, indent=2) + '\n').encode())
        return ref(p0)

    def record(argv, label):
        tick = time.monotonic(); start = datetime.now(timezone.utc).isoformat(); code = None; error = None
        so, se = output / (label + '.stdout'), output / (label + '.stderr')
        with so.open('xb') as out, se.open('xb') as err:
            try: code = subprocess.run(argv, cwd=B, env=environment, stdout=out, stderr=err).returncode
            except OSError as e: error = dict(type=type(e).__name__, message=str(e))
        return dict(command=argv, cwd=B.as_posix(), exit_code=code, launch_error=error, started_utc=start, finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-tick, stdout=ref(so), stderr=ref(se))

    br = write('Native-before.json', before); compiles = []; link = None
    for i, argv in enumerate(p['compile_argvs'], 1):
        value = record(argv, 'compile-' + str(i)); compiles.append(write('compile-' + str(i) + '-receipt.json', value))
        if value['exit_code'] != 0 or value['launch_error'] is not None: break
    if len(compiles) == 2 and all(read(checked(x))['exit_code'] == 0 and read(checked(x))['launch_error'] is None for x in compiles):
        assert all(Path(x).is_file() for x in p['objects']); link = write('link-receipt.json', record(p['link_argv'], 'link'))
    after = None; error = None
    try: after = custody(); assert after == before
    except (AssertionError, OSError) as e: error = dict(type=type(e).__name__, message=str(e))
    ar = write('Native-after.json', dict(custody=after, error=error))
    ok = len(compiles) == 2 and link is not None and read(checked(link))['exit_code'] == 0 and read(checked(link))['launch_error'] is None and error is None
    counts = {x: 0 for x in p['original_core_members_required']}; witnesses = {x: [] for x in counts}; bad = []; lines = 0
    if ok:
        with Path(p['map']).open(encoding='utf8', errors='strict') as f:
            for lines, line in enumerate(f, 1):
                for name in counts:
                    if ('libenergypluslib.a(' + name + ')') in line:
                        counts[name] += 1
                        if len(witnesses[name]) < 3: witnesses[name].append(dict(line=lines, literal=line.rstrip('\r\n')))
                if any(x in line for x in base['forbidden_derived_objects']): bad.append(dict(line=lines, literal=line.rstrip('\r\n')))
        ok = all(counts.values()) and not bad and Path(p['binary']).is_file()
    result = dict(schema='src06-original-core-gap-batch-build.v1', accepted=bool(ok), findings=[] if ok else ['Compile/link/original-core witnesses/custody did not close0.'], reviewed_manifest=ref(mp), new_parent_READY08=p['new_parent_READY08'], actual_accepted_build07=p['actual_accepted_build07'], independent_leaves=p['independent_leaves'], actual_accepted_build04=p['actual_accepted_build04'], new_driver_draft=p['new_driver_draft'], new_driver_peer=p['new_driver_peer'], retry_independent_peers=p['retry_independent_peers'], retry_parent_READY07=p['retry_parent_READY07'], actual_accepted_build06=p['actual_accepted_build06'], P4_factory_guard02=p['P4_factory_guard02'], P4_factory_guard_independent_peer02=p['P4_factory_guard_independent_peer02'], Exterior_calendar11=p['Exterior_calendar11'], Exterior_calendar_independent_peer11=p['Exterior_calendar_independent_peer11'], preserved_completed_history06=p['preserved_completed_history06'], history_ADL_driver05=p['history_ADL_driver05'], history_ADL_independent_peer=p['history_ADL_independent_peer'], preserved_failed_build05=p['preserved_failed_build05'], preserved_accepted_build02=p['preserved_accepted_build02'], preserved_failed_science_run02=p['preserved_failed_science_run02'], binding_only_correction=p['binding_only_correction'], independent_binding_only_peer=p['independent_binding_only_peer'], preserved_first_failed_build=p['preserved_first_failed_build'], compile_only_correction08=p['compile_only_correction08'], independent_compile_only_peer08=p['independent_compile_only_peer08'], preserved_failed_compile_build03=p['preserved_failed_compile_build03'], retry_predecessor_READY05=p['retry_predecessor_READY05'], actual_original_core_build43=p['actual_original_core_build43'], compiles=compiles, link=link, Native_before=br, Native_after=ar, Native_bytes_match_before_and_after=after == before and error is None, original_core_member_counts=counts, first3_map_witnesses=witnesses, forbidden_derived_object_witnesses=bad, map_lines_streamed=lines, planned_caller_compiles=2, actual_caller_compile_invocations=len(compiles), actual_link_invocations=int(link is not None), registry_count=800, frozen_environment_ref=base['frozen_environment'], environment_values_sha256=env_hash, no_environment_values_recorded=True, no_CMake_cache_registry_Native_or_canonical_mutation=True, science_engine_Cargo_tests_executed=False, author_Source=ref(Path(__file__)))
    for key in ['binary', 'map']: result[key] = ref(Path(p[key])) if Path(p[key]).exists() else None
    print(json.dumps(write('native-build.json', result))); return 0 if ok else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--manifest', required=True); p.add_argument('--build-only', action='store_true'); raise SystemExit(main(p.parse_args()))

from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];A=R/'.runtime/porting/SRC-06';O=A/'source-Weather-UCRT-math-provider-Outer-55-05-02'
def ref(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def save(p,v):return write(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
assert not O.exists();O.mkdir()
oldpath=A/'source-Weather-UCRT-math-provider-Outer-55-05/draft.json';assert ref(oldpath)['sha256']=='164a1d30308f620834743f11c6cc4fe49b76292b804947312438d6fb92d781df'
old=json.loads(oldpath.read_bytes());new=copy.deepcopy(old)
name='crates/ep_platform_math/src/lib.rs';row=next(v for v in new['files'] if v['canonical_path']==name)
before=(R/row['proposed']['path']).read_bytes();assert before.count(bytes([0]))==2
after=before.replace(bytes([0]),bytes([92,48]));assert after.replace(bytes([92,48]),bytes([0]))==before
cp=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True,cwd=R)
assert cp.returncode==0 and cp.stdout==after
oldref=row['proposed'];row['proposed']=write(O/'proposed'/name,after)
def diff(a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)).encode()
row['forward_diff']=write(O/'diffs/lib.canonical.forward.diff',diff(b'',after));row['inverse_diff']=write(O/'diffs/lib.canonical.inverse.diff',diff(after,b''))
row['Source_only_parse']=dict(exit_code=0,stdout=write(O/'parse/stdout.rs',after),stderr=write(O/'parse/stderr.txt',cp.stderr),syntax_only=True)
correction=save(O/'literal-NUL-escape-correction.json',dict(schema='src06-exact-two-NUL-to-Rust-escape-correction.v1',original_draft=ref(oldpath),before=oldref,after=row['proposed'],
 exact_two_literal_NUL_offsets=[i for i,b in enumerate(before) if b==0],runtime_byte_string_contents_unchanged=True,
 forward=write(O/'diffs/lib.05-to-02.forward.diff',diff(before,after)),inverse=write(O/'diffs/lib.02-to-05.inverse.diff',diff(after,before)),other7_Source_wholes_unchanged=True))
plan=json.loads((R/old['complete_proposed_compiler_Source_plan']['path']).read_bytes())
for e in plan['entries']:
    if e['path']==name:e.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'])
plan['literal_text_correction']=correction
new['complete_proposed_compiler_Source_plan']=save(O/'complete-proposed-compiler-Source-plan.json',plan)
new.update(schema='src06-genuine-CRT-math-provider-Source-draft02.v1',original_draft=ref(oldpath),exact_literal_correction=correction,author_Source=ref(Path(__file__)),
 original_author_Source=old['author_Source'],qualification='Only actual NUL source bytes become textual Rust zero escapes. Runtime byte strings/scientific behavior/other7whole Sources unchanged. No canonical or compiler execution.')
print(json.dumps(dict(draft=save(O/'draft.json',new),plan=new['complete_proposed_compiler_Source_plan']),indent=2))

"""Root-only P1 cfg-test application. Requires genuine accepted Native group first."""
from pathlib import Path
import argparse, ast, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PREP=D/'purchased-air-gap-prepared-WAIT-Peer-P1/prepared.json'
OUT=D/'Root-purchased-air-gap-cohort-application-P1'

def need(ok,message):
    if not ok: raise ValueError(message)

def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)

def checked(row):
    p=(R/row['path']).resolve();need(ref(p)==row,'Changed reference '+row['path']);return p

def argument(value):
    name,sha=value.rsplit('#',1);p=(R/name).resolve();actual=ref(p)
    need(actual['sha256']==sha,'Changed argument '+name);return actual

def read(p):return json.loads(p.read_bytes())

def inventory():
    return {p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}

def exact(rows):
    need(inventory()==set(rows),'Compiler input inventory differs')
    for name,row in rows.items():
        actual=ref(R/name);need((actual['sha256'],actual['bytes'])==(row['final_sha256'],row['final_bytes']),name)

def literal():
    p=D/'seal-compact-annual-daygroup-helper-Peer-01.py';tree=ast.parse(p.read_text(encoding='utf-8-sig'))
    fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply_literal')
    ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<accepted-literal-only>','exec'),ns)
    return ns['apply_literal']

def fixture(proof_ref):
    proof=read(checked(proof_ref));need(proof['accepted'] and not proof['findings'],'Fixture projection not accepted')
    actual=read(checked(proof['actual_Native_group_run']))
    need(actual['accepted'] and not actual['findings'] and actual['exit_code']==0 and actual['selected_group']=='purchased_air','Accepted actual P1 Native run')
    need(actual['Native_bytes_match_before_and_after'] and actual['actual_three_GNU_DLL_binding_proved_before_any_science_call'],'Native actual custody/module gate')
    need(actual['full_unit_output']==proof['exact_Native_output'],'Actual output binding')
    build=read(checked(actual['actual_build']));need(build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after'],'Native original-core build')
    manifest=read(checked(actual['reviewed_manifest']));need(manifest['named_inputs']==proof['exact_Native_named_inputs'],'Actual named inputs binding')
    output=read(checked(proof['exact_Native_output']));named=read(checked(proof['exact_Native_named_inputs']))
    wrapper=read(checked(proof['fixture']))
    need(wrapper==dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output),'Entire lossless authentic input/output wrapper')
    need(output['normal_completion'] is True and output['group_order']==['purchased_air'] and set(output['groups'])=={'purchased_air'},'Exactly completed P1 group')
    need(actual['admission']['PurchasedAir_full_function_calls']==60 and actual['admission']['purchased_air_factories']==4,'All sixty Native calls admitted')
    rows=[proof_ref,proof['fixture'],proof['exact_Native_output'],proof['exact_Native_named_inputs'],proof['actual_Native_group_run'],actual['actual_build'],actual['reviewed_manifest'],proof['author_Source']]
    return proof,[ref(checked(v)) for v in rows]

def main(a):
    pr=argument(a.prepared);need(checked(pr)==PREP.resolve(),'Unexpected prepared path');p=read(PREP)
    need(p['status']=='WAIT_ACCEPTED_NATIVE_P1_GROUP_AND_RUNNER_PEER','Unexpected preparation state')
    need(ref(Path(__file__))==p['application_Source'],'Application changed')
    need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==p['base_HEAD'],'Actual HEAD differs')
    need(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'Committed clean Source49 parent required')
    parent_actual=read(checked(p['parent_Source49_actual']));need(parent_actual['accepted'] and not parent_actual['findings'],'Source49 actual not accepted')
    parent=read(checked(p['prior_complete_compiler_Source_plan']));before_rows={x['path']:x for x in parent['entries']}
    need((parent['inputs'],parent['Rust_sources'],len(before_rows))==(4525,4512,4525),'Parent counts');exact(before_rows)
    scaffold_peer=read(checked(p['independent_P1_scaffold_peer']))
    need(scaffold_peer['accepted'] and not scaffold_peer['findings'] and scaffold_peer['reviewed_draft']==p['P1_scaffold'],'P1 scaffold peer')
    rp=argument(a.runner_peer);runner_peer=read(checked(rp))
    need(runner_peer['accepted'] and not runner_peer['findings'] and runner_peer['reviewed_draft']==p['runtime_runner'],'Runner independent peer')
    fp=argument(a.fixture_proof);proof,protected=fixture(fp)
    need(proof['P1_Source_scaffold']==p['P1_scaffold'],'Fixture input bridge bound to same Source scaffold')
    plan=read(checked(p['complete_proposed_compiler_Source_plan']));rows={x['path']:x for x in plan['entries']}
    need((plan['inputs'],plan['Rust_sources'],len(rows))==(4528,4515,4528),'Final counts')
    apply=literal();materials=[]
    for row in p['files']:
        rel=row['canonical_path'];target=R/rel;old=checked(row['before']).read_bytes() if row['before'] else b''
        need(target.exists()==(row['before'] is not None),'Existence changed '+rel)
        if target.exists():
            need(target.read_bytes()==old,'Selected before differs '+rel)
            need(subprocess.check_output(['git','show',p['base_HEAD']+':'+rel],cwd=R)==old,'Selected Git before differs '+rel)
        proposed=checked(row['proposed']).read_bytes()
        need(apply(old,checked(row['forward_diff']).read_bytes())==proposed,'Literal forward')
        need(apply(proposed,checked(row['inverse_diff']).read_bytes())==old,'Literal inverse')
        materials.append((rel,old,proposed,row['before'] is not None))
    need(len(materials)==7 and sum(x[3] for x in materials)==4,'Seven disjoint cfg-test Sources')
    need(not OUT.exists(),'Application directory already exists');OUT.mkdir()
    for rel,old,_,exists in materials:
        if exists:
            backup=OUT/'before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(old)
    try:
        for rel,_,proposed,_ in materials:
            target=R/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(proposed)
        exact(rows);need([ref(checked(v)) for v in protected]==protected,'Fixture changed across application')
    except BaseException:
        for rel,old,_,exists in materials:
            if exists:(R/rel).write_bytes(old)
            elif (R/rel).exists():(R/rel).unlink()
        raise
    receipt=dict(schema='src06-purchased-air-gap-application.v1',accepted=True,findings=[],base_HEAD=p['base_HEAD'],prepared=pr,
        parent_Source49_actual=p['parent_Source49_actual'],complete_compiler_plan=p['complete_proposed_compiler_Source_plan'],
        P1_scaffold=p['P1_scaffold'],independent_P1_scaffold_peer=p['independent_P1_scaffold_peer'],runtime_runner=p['runtime_runner'],independent_runner_peer=rp,
        actual_Native_group_run=proof['actual_Native_group_run'],fixture_proof=fp,fixture=proof['fixture'],protected_external_fixture_refs=protected,
        selected_Source_files=7,existing=4,new=3,compiler_inputs=4528,Rust_sources=4515,all_final_plan_inputs_exact=True,
        actual_test_or_CLI_invocations=0,application_Source=ref(Path(__file__)),qualification='Only cfg-test retained owner/observer bridges and existing process-main selector; no production numerical implementation or new test target/feature.')
    out=OUT/'receipt.json';out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(out)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepared',required=True);p.add_argument('--runner-peer',required=True);p.add_argument('--fixture-proof',required=True);main(p.parse_args())

"""Root-only coherent21 application; require full peers and actual two new fixtures."""
from pathlib import Path
import argparse,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
s=importlib.util.spec_from_file_location('guard54',D/'gap-P4-history-guards-Peer-54.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
def main(a):
 prepared,p,draft,union=h.prepared(a.prepared);g.need(g.checked(p['application_Source'])==Path(__file__).resolve(),'Exact application Source')
 h.current_head(p['base_HEAD']);g.need(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'Clean committed current Source parent')
 old=g.read(g.checked(p['prior_compiler_plan']));g.need((old['inputs'],old['Rust_sources'])==(4534,4521),'Exact parent compiler counts');before={x['path']:x for x in old['entries']};g.exact(before)
 final=g.read(g.checked(p['complete_compiler_plan']));g.need((final['compiler_inputs'],final['Rust_sources'])==(4538,4525),'Exact final compiler counts');rows={x['path']:x for x in final['entries']}
 fixture_map,protected=h.fixtures(p,draft,union);apply=g.literal();materials=[]
 for f in draft['files']:
  name=f['canonical_path'];target=(R/name).resolve();g.need(target.is_relative_to(R) and name.startswith('crates/ep_runtime/src/'),'Bounded exact Source target')
  oldbytes=g.checked(f['before']).read_bytes() if f['before'] else b'';after=g.checked(f['proposed']).read_bytes();exists=f['before'] is not None
  g.need(target.exists()==exists,'Selected target existence '+name)
  if exists:g.need(target.read_bytes()==oldbytes and subprocess.check_output(['git','show','HEAD:'+name],cwd=R)==oldbytes,'Actual/Git selected before '+name)
  g.need(apply(oldbytes,g.checked(f['diffs']['forward']).read_bytes())==after and apply(after,g.checked(f['diffs']['inverse']).read_bytes())==oldbytes,'Exact full forward/inverse '+name);materials.append((name,oldbytes,after,exists))
 g.need(len(materials)==21 and sum(x[3]for x in materials)==17,'Exactly21 Sources17existing4new');g.need(not h.APP.exists(),'Fresh Root application path');h.APP.mkdir()
 for name,oldbytes,_,exists in materials:
  if exists:
   target=h.APP/'before'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(oldbytes)
 try:
  for name,_,after,_ in materials:
   target=R/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after)
  g.exact(rows);g.need([g.ref(g.checked(v))for v in protected]==protected,'All four external fixtures/proofs stable across application')
 except BaseException:
  for name,oldbytes,_,exists in materials:
   target=R/name
   if exists:target.write_bytes(oldbytes)
   elif target.exists():target.unlink()
  raise
 result=dict(schema='src06-P4-history-coherent-application54.v1',accepted=True,findings=[],prepared=prepared,base_HEAD=p['base_HEAD'],draft=p['draft'],joint_independent_peer=p['joint_independent_peer'],history_independent_peer=p['history_independent_peer'],prior_compiler_plan=p['prior_compiler_plan'],complete_compiler_plan=p['complete_compiler_plan'],changed_Source_files=21,existing=17,new=4,compiler_inputs=4538,Rust_sources=4525,all_final_compiler_bytes_exact=True,fixtures=fixture_map,protected_all_four_external_fixtures=protected,actual_Cargo_or_CLI_invocations=0,application_Source=g.ref(Path(__file__)))
 out=h.APP/'receipt.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(out)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prepared',required=True);main(p.parse_args())

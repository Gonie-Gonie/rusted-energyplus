"""Private append-only full current Source multiplier caller; no Cargo or writes to crates."""
from pathlib import Path
import copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-multiplier-predictor-draft-Peer-02'
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def check(v):
 p=R/v['path'];assert ref(p)==v;return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def replace(b,x,y):assert b.count(x)==1,x;return b.replace(x,y)
def diff_apply(a,p):
 lines=a.decode().splitlines(keepends=True);patch=p.read_text(encoding='utf-8').splitlines(keepends=True);i=2;at=0;out=[]
 while i<len(patch):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch[i]);assert m
  start=int(m[1])-1 if int(m[1])else 0;out.extend(lines[at:start]);at=start;i+=1
  while i<len(patch)and not patch[i].startswith('@@ '):
   line=patch[i];assert line[:1]in(' ','-','+')
   if line[:1]in(' ','-'):assert lines[at]==line[1:];at+=1
   if line[:1]in(' ','+'):out.append(line[1:])
   i+=1
 out.extend(lines[at:]);return ''.join(out).encode()
def main():
 assert not O.exists();O.mkdir()
 wp=D/'source-warmup-complete-draft-Audit-02/draft.json';warm=read(wp);assert ref(wp)['sha256']=='8240ea51e7aa4417eb735a0e7e6b9323ed06cd3e4dfdaad7627850b16e6e1113'
 wrows={x['canonical_path']:x for x in warm['files']};warmpeer=D/'Peer-Source-warmup-complete-review-Outer-02/review.json';wpeer=read(warmpeer);assert wpeer['accepted']and not wpeer['findings']
 allocp=D/'source-real-class-allocation-draft-Peer-01/draft.json';alloc=read(allocp);allocpeer=D/'Root-real-class-allocation-independent-review-01/review.json';assert read(allocpeer)['accepted']
 p1='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs'
 hist='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort/air_history.rs'
 predict='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs'
 correct='crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/temperature.rs'
 hub='crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs'
 child='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort/multiplier_predictor.rs'
 before={p1:check(wrows[p1]['proposed']).read_bytes(),hub:check(wrows[hub]['proposed']).read_bytes(),hist:(R/hist).read_bytes(),predict:(R/predict).read_bytes(),correct:(R/correct).read_bytes(),child:b''}
 history_append=b'''
// Test-only sibling access: the accepted history observer/caller/checker above
// stays whole and remains the only implementation of these shared operations.
pub(super) fn multiplier_state(factory: &Factory) -> Result<Value> { state(factory) }
pub(super) fn multiplier_history_call(factory: &mut Factory, operation: &str) -> Result { call(factory, operation) }
#[derive(Default)]
pub(super) struct MultiplierObservations(HistoryIdentities);
impl MultiplierObservations {
    pub(super) fn check(&mut self, source: &Value, native: &Value, path: &str) -> Result { self.0.check(source, native, path) }
    pub(super) fn raw_bits(&self) -> usize { self.0.raw_bits }
}
'''
 predict_append=b'''
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
impl SourceZoneSpaceHeatBalanceData {
    /// Caller bridge only; the original full member body above owns all math.
    pub(crate) fn predict_native_multiplier_cohort(
        &mut self, number: i32, shorten: bool, use_zone_history: bool,
        prior_step: f64, controller: &mut SourceZoneAirPredictorCorrector,
        owners: &mut SourceZoneAirOwners<'_, '_>,
    ) -> Result<(), Error> {
        self.predict_source_system_load(number, shorten, use_zone_history, prior_step, controller, owners)
    }
}
'''
 correct_append=b'''
#[cfg(all(test, feature = "native-controlled-air-cohort"))]
impl SourceZoneSpaceHeatBalanceData {
    /// Caller bridge only; the original full member body above owns all math.
    pub(crate) fn correct_native_multiplier_cohort(
        &mut self, number: i32, use_zone_history: bool,
        controller: &mut SourceZoneAirPredictorCorrector,
        owners: &mut SourceZoneAirOwners<'_, '_>,
    ) -> Result<f64, Error> {
        self.correct_source_zone_temperature(number, use_zone_history, controller, owners)
    }
}
'''
 proposed={p1:before[p1]+b'\nmod multiplier_predictor;\n',hist:before[hist]+history_append,predict:before[predict]+predict_append,correct:before[correct]+correct_append}
 h=replace(before[hub],b'"air_history"|"warmup")',b'"air_history"|"warmup"|"multiplier_predictor")') if b'"air_history"|"warmup")'in before[hub]else replace(before[hub],b'"air_history")',b'"air_history"|"multiplier_predictor")')
 needle=b'        "warmup"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_warmup_cohort(&fixture),'
 h=replace(h,needle,needle+b'\n        "multiplier_predictor"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_multiplier_predictor_cohort(&fixture),');proposed[hub]=h
 template=D/'multiplier-predictor-Source-child-Peer-01.rs.txt';t=template.read_text(encoding='utf-8')
 base=[('RemainingOutputRequired','base.remaining_output_required'),('UnadjRemainingOutputRequired','base.unadjusted_remaining_output_required'),('TotalOutputRequired','base.total_output_required'),('SupplyAirAdjustFactor','base.supply_air_adjust_factor')]
 sensible=[('OutputRequiredToHeatingSP','output_required_to_heating_sp'),('OutputRequiredToCoolingSP','output_required_to_cooling_sp'),('RemainingOutputReqToHeatSP','remaining_output_to_heat_sp'),('RemainingOutputReqToCoolSP','remaining_output_to_cool_sp'),('UnadjRemainingOutputReqToHeatSP','unadjusted_remaining_output_to_heat_sp'),('UnadjRemainingOutputReqToCoolSP','unadjusted_remaining_output_to_cool_sp'),('predictedRate','predicted_rate'),('predictedHSPRate','predicted_heating_sp_rate'),('predictedCSPRate','predicted_cooling_sp_rate'),('airSysHeatRate','air_sys_heat_rate'),('airSysCoolRate','air_sys_cool_rate'),('airSysHeatEnergy','air_sys_heat_energy'),('airSysCoolEnergy','air_sys_cool_energy')]
 moisture=[('OutputRequiredToHumidifyingSP','output_required_to_humidifying_sp'),('OutputRequiredToDehumidifyingSP','output_required_to_dehumidifying_sp'),('RemainingOutputReqToHumidSP','remaining_output_to_humid_sp'),('RemainingOutputReqToDehumidSP','remaining_output_to_dehumid_sp'),('UnadjRemainingOutputReqToHumidSP','unadjusted_remaining_output_to_humid_sp'),('UnadjRemainingOutputReqToDehumidSP','unadjusted_remaining_output_to_dehumid_sp'),('predictedRate','predicted_rate'),('predictedHumSPRate','predicted_humid_sp_rate'),('predictedDehumSPRate','predicted_dehumid_sp_rate'),('airSysHeatRate','air_sys_heat_rate'),('airSysCoolRate','air_sys_cool_rate'),('airSysHeatEnergy','air_sys_heat_energy'),('airSysCoolEnergy','air_sys_cool_energy'),('airSysSensibleHeatRatio','air_sys_sensible_heat_ratio'),('vaporPressureDifference','vapor_pressure_difference')]
 seqs={'sensible':[('SequencedOutputRequired','sequenced_output_required'),('SequencedOutputRequiredToHeatingSP','sequenced_output_to_heating_sp'),('SequencedOutputRequiredToCoolingSP','sequenced_output_to_cooling_sp')], 'moisture':[('SequencedOutputRequired','sequenced_output_required'),('SequencedOutputRequiredToHumidSP','sequenced_output_to_humid_sp'),('SequencedOutputRequiredToDehumidSP','sequenced_output_to_dehumid_sp')]}
 inserts=[]
 for obj,out,pairs in [('sensible','ds',base+sensible),('moisture','dm',base+moisture)]:
  for native,source in pairs:inserts.append(f'    {out}.insert("{native}".into(),number({obj}.{source}));')
  for native,source in seqs[obj]:inserts.append(f'    {out}.insert("{native}".into(),real_values(&{obj}.{source},false));')
 assert t.count('    // GENERATED_REAL_DEMAND_OBSERVATIONS')==1;t=t.replace('    // GENERATED_REAL_DEMAND_OBSERVATIONS','\n'.join(inserts))
 fmt=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=t.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert fmt.returncode==0,fmt.stderr;proposed[child]=fmt.stdout
 rows=[]
 for name in [p1,hist,predict,correct,child,hub]:
  b,a=before[name],proposed[name];assert b'\r'not in a
  bp=O/'before'/name;ap=O/'proposed'/name;bp.parent.mkdir(parents=True,exist_ok=True);ap.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(b);ap.write_bytes(a)
  row=dict(canonical_path=name,before_absent=name==child,before=None if name==child else ref(bp),proposed=ref(ap),before_qualification='accepted warmup02 logical parent'if name in(p1,hub)else'actual Source54 canonical before')
  if name!=child:
   cp=O/'canonical-before'/name;cp.parent.mkdir(parents=True,exist_ok=True);cp.write_bytes((R/name).read_bytes());row['canonical_before']=ref(cp)
   assert subprocess.check_output(['git','show','HEAD:'+name],cwd=R)==cp.read_bytes()
  else:assert not(R/name).exists()
  for key,x,y in [('forward_diff',b,a),('inverse_diff',a,b)]:
   p=O/'diffs'/(name+'.'+key+'.diff');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');assert diff_apply(x,p)==y;row[key]=ref(p)
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=a,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0,parse.stderr
  p=O/'parse'/(name+'.stdout.rs');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(parse.stdout);q=p.with_suffix('.stderr.txt');q.write_bytes(parse.stderr);row['syntax_only']=dict(exit_code=0,stdout=ref(p),stderr=ref(q));rows.append(row)
 assert proposed[p1][:-len(b'\nmod multiplier_predictor;\n')]==before[p1]
 assert proposed[hist][:-len(history_append)]==before[hist]and proposed[predict][:-len(predict_append)]==before[predict]and proposed[correct][:-len(correct_append)]==before[correct]
 baseplan=D/'source-Propane-P4-history-coherent-draft-Peer-01/complete-proposed-compiler-Source-plan.json';plan=read(baseplan);assert len(plan['entries'])==4538
 for e in plan['entries']:
  b=(R/e['path']).read_bytes();assert len(b)==e['final_bytes']and hashlib.sha256(b).hexdigest()==e['final_sha256']
 union={r['canonical_path']:r for r in alloc['files']}
 for r in warm['files']:union[r['canonical_path']]=r
 for r in rows:union[r['canonical_path']]=r
 assert len(union)==11
 final=copy.deepcopy(plan);entries={e['path']:e for e in final['entries']}
 for name,row in union.items():
  v=row['proposed'];check(v)
  if name not in entries:entries[name]=dict(path=name)
  entries[name].update(final_sha256=v['sha256'],final_bytes=v['bytes'],source=v,origin='private exact3allocator +accepted warmup02 +multiplier full caller overlay')
 final.update(schema='src06-private-warmup-multiplier-three-allocator-proposed-plan.v1',entries=[entries[k]for k in sorted(entries)],compiler_inputs=len(entries),Rust_sources=sum(k.endswith('.rs')for k in entries),selected=11,existing=9,new=2,prior_complete_compiler_Source_plan=ref(baseplan),contextual_compilation_and_final_integration_pending=True)
 assert(final['compiler_inputs'],final['Rust_sources'])==(4540,4527)
 pp=save(O/'complete-proposed-compiler-Source-plan.json',final)
 fixturep=D/'source-multiplier-runtime-fixture-Peer-01/projection.json';fixture=read(fixturep);assert fixture['accepted']and not fixture['findings'];fv=read(check(fixture['fixture']))
 native=fv['native_output']['groups']['multiplier_predictor']['cases'][0];snapshots=[native['after_real_getter_and_initializer_chain']]
 for s in native['steps']:snapshots.extend([s['entry'],s['exit']])
 assert len(snapshots)==43
 for key,pairs in [('sensible',base+sensible),('moisture',base+moisture)]:
  expected={'address','NumZoneEquipment','StageNum'}|{x for x,y in pairs}|{x for x,y in seqs[key]}
  assert all(set(s[key])==expected for s in snapshots)
 context_paths=['crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/output_registration.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs','crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/environment/fan_zone.rs','crates/ep_runtime/src/heat_balance/ordinary_heat_balance_initialization/owners.rs','crates/ep_runtime/src/heat_balance/ordinary_heat_balance_initialization/provider_host.rs','crates/ep_runtime/src/heat_balance/ordinary_heat_balance_initialization/allocation.rs','crates/ep_runtime/src/heat_balance/ordinary_heat_balance_initialization/state.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment.rs','crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs','crates/ep_runtime/src/heat_balance/warmup_report.rs']
 contexts=[dict(canonical_path=p,whole=ref(R/p))for p in context_paths]
 ledger=save(O/'consumed-owner-input-observation-ledger.json',dict(schema='src06-Source-multiplier2-full-member-caller-ledger.v1',
  actual_Native_fixture_projection=ref(fixturep),input_only_projection=fixture['exact_Source_primary_input_projection'],
  genuine_constructor_getter_chain=['unchanged accepted P1 Factory::new with only primary raw Zone N6 value2; real retained IP/getters/availability/InitZoneEquipment; no CompIndex/GetInput/multiplier setters','full genuine Source get_project_control_data from same retained raw families','actual SourceHeatBalanceManager constructor +same SourceOrdinaryInitHeatBalanceHost calling exact shared allocator bridge; actual P1 Air/Zone/fan/gain owners borrowed; no manual Some-clears or default rows in adapter','same RoomAir real getter','declared phase inputs, full manage_source_zone_air_updates(GetZoneSetPoints) with genuine live output registration host','21 persistent actual member/history calls, all observations are passive'],
  shared_initializer_bridge=dict(accepted_warmup_draft=ref(wp),accepted_warmup_peer=ref(warmpeer),reused_whole=wrows['crates/ep_runtime/src/heat_balance/ordinary_heat_balance_initialization.rs']['proposed']),
  new_production_allocator_leaf=ref(allocp),production_allocator_Root_peer=ref(allocpeer),allocator_policy_qualification='Root ce9595 notes -UNDEBUG follows -DNDEBUG in actual Native argv; same-size Array1D retention derives from absence of OBJEXXFCL_ARRAY_INIT / OBJEXXFCL_ARRAY_INIT_DEBUG, not from disabled assertions.',
  physical_primary_writes=['same actual Config.InletNode(1) Temp/HumRat/MassFlowRate only when named','same Config.ZoneNode MassFlowRate only when named','real caller phase/calendar/pressure/outdoor humidity/system-time/count inputs','actual upstream Air MAT/NonAirSystemResponse/SysDepZoneLoadsLagged/latentGain/ZTAV/airHumRatAvg only when explicitly named'],
  no_computed_inputs=['no histories or exit values restored','no multiplier/list fields assigned','no Sums/three-coefficient/Rho/Cp/H/RH answers injected','no control/count/latch forced to bypass a genuine getter','no cache/FP/environment reset between declared calls'],
  shared_history_observer='Old complete helper body/prefix whole exact. Appended facade invokes its only state/call/HistoryIdentities implementations. Both new member bridges are cfg-only forwarders inside actual owning leaves; no numeric implementation duplicated.',
  sensible_observer=base+sensible,moisture_observer=base+moisture,sequence_observers=seqs,
  observations=dict(whole_snapshots=43,observed_state_finite_fields=17888,correct_return_fields=5,Source_strict_raw_fields_if_executed=17893,Native_whole_output_fields=17953,whole_keysets_arrays_rawbits_text_checked=True,physical_pointer_correspondence='Accepted same-owner HistoryIdentities mapping retained across whole lifetime; actual source/native addresses are paired, not compared as equal machine addresses.'),
  scope='One private real raw multiplier2 mixed ThirdOrder one-zone/default-space getter lifetime; actual geometry/gain producer absent. Full current direct member Predict/Correct plus initializer dispatcher and interleaved history only. CON01 production admission unchanged. No Source numerical/typecheck pass until Root execution.',
  contexts=contexts,accepted_Native_leaf=ref(D/'multiplier2-full-predictor-Native-draft-Peer-01/draft.json'),accepted_Native_Root_peer=ref(D/'Root-multiplier2-Native-independent-review-01/review.json'),actual_Native_run=fixture['actual_Native_group_run'],old_proofs_not_rerun=['P1 60','Surface55','P2 1168','2336 Air','471 reports','59 sizing','40 histories','38 output processor']))
 census=[]
 for path in (R/'crates').rglob('*.rs'):
  hits=[dict(line=i,text=line)for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1)if any(token in line for token in ['predict_source_system_load(', 'correct_source_zone_temperature(', 'mod air_history;', 'run_native_gap_air_history_cohort'])]
  if hits:census.append(dict(whole=ref(path),hits=hits))
 cp=save(O/'crate-caller-and-privacy-census.json',dict(current_whole_files=census,new_methods_only_in_cfg_test_feature=True,new_methods=['predict_native_multiplier_cohort','correct_native_multiplier_cohort'],original_prediction_corrector_and_history_prefixes_whole_exact=True,production_visibility_not_widened=True))
 draft=save(O/'draft.json',dict(schema='src06-private-full-Source-multiplier2-predictor-corrector-draft.v1',status='FROZEN_PRIVATE_INDEPENDENT_PEER_CONTEXTUAL_COMPILE_AND_RUNTIME_PENDING',private_author_precheck_note='Incomplete01 retained: exact Native keyset self-check rejected two moisture observation key aliases before manifest or execution.02 uses declared predictedHumSPRate/predictedDehumSPRate; no input/expected/numerical body change.',observed_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),files=rows,literal_applications=12,fresh_syntax_parses=6,existing=5,new=1,
  logical_parent_qualification='Six multiplier proposals are reviewed against accepted warmup02 logical suffix/root for their two overlapping files. Other parents are current Source54. Final complete proposed plan additionally carries all exact3 accepted allocator proposals and four accepted warmup proposals; no application is claimed.',
  accepted_warmup_draft=ref(wp),accepted_warmup_peer=ref(warmpeer),accepted_allocator_leaf=ref(allocp),accepted_allocator_Root_peer=ref(allocpeer),fixture=fixture['fixture'],fixture_projection=ref(fixturep),consumed_owner_input_observation_ledger=ledger,crate_caller_privacy_census=cp,
  complete_proposed_compiler_Source_plan=pp,proposed_inputs=4540,proposed_Rust_sources=4527,coherent_overlay_unique_Source_files=11,coherent_overlay_existing=9,coherent_overlay_new=2,current4538_rows_whole_verified=True,child_template=ref(template),author_Source=ref(Path(__file__)),canonical_writes=0,Cargo_Native_executions=0,tests_targets_features_dependencies_added=0))
 print(json.dumps(dict(draft=draft,ledger=ledger,plan=pp)))
if __name__=='__main__':main()

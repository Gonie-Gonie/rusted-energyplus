"""Transport actual whole Native output and classify approved Source unit scope.
No Native rerun, expected value recomputation, Source execution or canonical edit.
"""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Exterior-runtime-fixture-Outer-01'
def ref(p):
 p=p.resolve();b=p.read_bytes()
 try:k=p.relative_to(R).as_posix()
 except ValueError:k=p.as_posix()
 return {'path':k,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):p=R/v['path'];assert ref(p)==v;return p
def save(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode());return ref(p)
def main():
 assert not O.exists();O.mkdir();receipt=D/'original-core-gap-batch-run-Root-07-exterior/receipt.json'
 assert ref(receipt)['sha256']=='2db8829515917a11f0a13341ad810c185f44c7b11d393db833cf59293527b935'
 v=json.loads(receipt.read_bytes());assert v['accepted'] and v['exit_code']==0 and v['selected_group']=='exterior' and v['Native_bytes_match_before_and_after'] and v['actual_three_GNU_DLL_binding_proved_before_any_science_call']
 native=checked(v['full_unit_output']);nbytes=native.read_bytes();output=json.loads(nbytes);assert output['normal_completion'] is True and output['group_order']==['exterior'] and list(output['groups'])==['exterior']
 named=Path(v['command'][1]);ibytes=named.read_bytes();inputs=json.loads(ibytes);assert inputs['schema']=='src06-original-core-gap-batch-input.v1'
 group=output['groups']['exterior'];given=inputs['exterior'];assert given['schema']=='src06-exterior-gap-input.v1'
 input_manifest=D/'source-Exterior-primary-ingress-draft-Outer-01/draft.json';iv=json.loads(input_manifest.read_bytes());ingress=checked(iv['input_only_payload']);ingress_bytes=ingress.read_bytes();ip=json.loads(ingress_bytes)
 categories=['solar_clock','exterior_coefficients','absorption','solar_surface','internal_gains','beam_producer','surface_internal_gains'];all_case_rows=[]
 for category in categories:
  assert len(given[category])==len(group[category])==v['admission']['supplemental_named_case_counts'][category]
  for index,(primary,result) in enumerate(zip(given[category],group[category])):
   assert primary==result['input'] and primary['name']==result['name']
   all_case_rows.append({'category':category,'native_index':index,'case_name':primary['name'],'Native_input_whole_equal_named':True,'call_records':len(result['calls'])})
 beam_rows=[]
 for index,(primary,result) in enumerate(zip(given['beam_producer'],group['beam_producer'])):
  factory=ip['factories'][primary['name']];assert factory['actual_primary_IDF']==primary['input_authority'];checked(primary['input_authority'])
  counts={f:len(rows) for f,rows in factory['raw'].items() if f.lower().startswith(('shading:','fenestrationsurface:'))}
  outside=any(counts.values())
  beam_rows.append({'native_index':index,'case_name':primary['name'],'actual_primary_IDF':primary['input_authority'],'actual_window_shading_family_counts':counts,'Source_unit_selected':not outside,'Native_full_function_success_retained':True,'actual_call_records':len(result['calls']),'classification':'Outside CON01 window/shading-geometry scope; genuine successful Native exploration retained, no Source equivalence claimed.' if outside else 'No window or shading geometry in actual primary IDF; eligible for declared Source beam unit scope only, not added to production finite admission.'})
 selected=[r['native_index'] for r in beam_rows if r['Source_unit_selected']];excluded=[r['native_index'] for r in beam_rows if not r['Source_unit_selected']]
 assert selected==[0,1] and excluded==[2]
 card=R/'energyplus_porting_plan/cards/CON-01.md';clines=card.read_bytes().decode().splitlines();assert '창호·차양기하' in clines[67]
 src=R/'energyplus_porting_plan/cards/SRC-04.md';slines=src.read_bytes().decode().splitlines();assert '차양기하가 없는' in slines[13] and '차양 폴리곤 중첩' in slines[40]
 scope={'schema':'src06-Exterior-Source-unit-scope.v1','Native_full_output_preserved':True,'source_unit_beam_indices':selected,'outside_CON01_beam_indices':excluded,'beam_classification':beam_rows,
 'other_categories':'All actual named lifetimes remain selected obligations; no input/output rows are deleted. Implementation/typecheck/actual Source validation is pending and separately qualified.',
 'source_unit_expected_lookup':'Use only exact supported indices into native_output.groups.exterior.beam_producer; entire original Native root still retained byte-for-byte in this fixture.',
 'does_not_expand_production_finite_15_input_admission':True,'no_whole_three_beam_Source_equivalence_claim':True,
 'authoritative_contracts':[{'whole':ref(card),'first':68,'last':68,'actual_text':clines[67]},{'whole':ref(src),'first':14,'last':14,'actual_text':slines[13]},{'whole':ref(src),'first':41,'last':41,'actual_text':slines[40]}]}
 scope_ref=save(O/'Source-finite-scope.json',scope)
 fixture=O/'fixture.json';fixture.write_bytes(b'{\n"schema":"src06-Native-gap-batch-fixture.v1",\n"named_inputs":'+ibytes+b',\n"native_output":'+nbytes+b',\n"source_ingress":'+ingress_bytes+b',\n"source_scope":'+(json.dumps(scope,indent=2,ensure_ascii=False)+'\n').encode()+b'\n}\n')
 fb=fixture.read_bytes();parsed=json.loads(fb);assert parsed['named_inputs']==inputs and parsed['native_output']==output and parsed['source_ingress']==ip and parsed['source_scope']==scope
 assert fb.count(ibytes)==1 and fb.count(nbytes)==1 and fb.count(ingress_bytes)==1
 proof={'schema':'src06-Exterior-lossless-runtime-fixture-proof.v1','status':'FROZEN_PRIVATE_TRANSPORT_ONLY_NO_SOURCE_EXECUTION','actual_Native_receipt':ref(receipt),'actual_complete_Native_output':v['full_unit_output'],'actual_named_inputs':ref(named),'primary_only_Source_ingress_authority':ref(input_manifest),'scope_classification':scope_ref,'fixture':ref(fixture),
 'whole_transport':{'original_named_input_bytes_once_exact':True,'original_Native_output_bytes_once_exact':True,'input_only_ingress_bytes_once_exact':True,'whole_JSON_inverse_equal':True,'all_Native_lifetimes_and_states_retained':True},
 'Native_case_rows':all_case_rows,'Native_actual_admission':v['admission'],'selected_Source_beam_lifetimes':2,'selected_Source_beam_records':sum(len(group['beam_producer'][i]['calls']) for i in selected),'retained_outside_scope_Native_beam_lifetimes':1,'retained_outside_scope_Native_beam_records':len(group['beam_producer'][2]['calls']),
 'qualification':'Transport/scope proof only. No Source field is restored from an expected exit or computed child answer. Neither eligibility nor actual Native completion proves Source numerical, whole-parent, whole-engine, full IO or card completion. All other Source implementations/observers must still be completed, independently reviewed and executed by Root.',
 'Cargo_Native_or_canonical_execution':False,'author_Source':ref(Path(__file__))}
 print(json.dumps({'proof':save(O/'proof.json',proof),'fixture':ref(fixture),'scope':scope_ref}))
if __name__=='__main__':main()

"""Read-only exact Source55 authorities, seven external fixtures and full-plan guards."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
BASE=D/'gap-P4-history-guards-Peer-54.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='89f2f230b0faebf72e44117b19d0598f460fde4c441c3a3907510ac7c0438400'
s=importlib.util.spec_from_file_location('previous54_readonly55',BASE);h54=importlib.util.module_from_spec(s);s.loader.exec_module(h54);g=h54.g
APP=D/'Root-warmup-multiplier-Exterior-application-55'
GROUPS=['warmup','multiplier_predictor','exterior']
def peer(peer_ref,draft_ref,field=None,index=None):
 p=g.read(g.checked(peer_ref));reviewed=p[field]if field else p.get('reviewed_packet',p.get('reviewed_draft'))
 if index is not None:reviewed=reviewed[index]
 for v in draft_ref if isinstance(draft_ref,list)else[draft_ref]:g.checked(v)
 g.need(p['accepted']and not p['findings']and reviewed==draft_ref,'Exact accepted independent peer '+peer_ref['path']);return p
def counts(p):return p.get('compiler_inputs',p.get('inputs')),p['Rust_sources'],len(p['entries'])
def diffs(row):return(row['forward_diff'],row['inverse_diff'])if'forward_diff'in row else(row['diffs']['forward'],row['diffs']['inverse'])
def current_head(expected):g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==expected,'Committed Source55 parent changed')
def prepared(spec):
 rr=g.argument(spec);p=g.read(g.checked(rr));g.need(p['status']=='READY_FOR_ROOT_ONE_APPLICATION_THREE_SELECTED_GROUPS','Prepared55 not READY')
 d=g.read(g.checked(p['draft']));g.need(d['base_HEAD']==p['base_HEAD'],'Exact final union HEAD')
 peer(p['joint_independent_peer'],p['draft'])
 links=g.read(g.checked(p['semantic_link_table']));g.need(links['coherent_manifest']==p['draft']and links['leaf_semantic_pairs']==p['semantic_peers'],'Exact explicit semantic link table')
 for x in p['semantic_peers']:peer(x['peer'],x['draft'],x.get('review_field'),x.get('review_index'))
 for x in links['additional_whole_Source_reviews']:
  review=g.read(g.checked(x['peer']));g.need(review['accepted']and not review['findings'],'Accepted direct whole-Source review')
  for row in x['accepted_whole_Source_files']:g.checked(row['proposed'])
 for key in ['guard_Source','application_Source','launch_Source','actual_checker_Source','environment_guard','record_command_Source']:g.checked(p[key])
 g.need(g.checked(p['guard_Source'])==Path(__file__).resolve(),'Exact selected guard')
 g.need(p['environment_guard']['sha256']=='fc76790e89122784da36a9687c22079a2aefe67cdf498b0d55e32ac9d52b598e'and p['record_command_Source']['sha256']=='18168e36c2c759d55811d1c19695a4c0f7c0e5bba67b1e13f5e499d54d8780c8','Frozen environment/recorder policy')
 for v in p['inherited_guard_dependencies']:g.checked(v)
 a=g.read(g.checked(p['prior_actual_review']));g.need(a['accepted']and not a['findings']and a['complete_compiler_plan']==p['prior_compiler_plan'],'Authentic accepted Source54 actual parent')
 g.need(p['complete_compiler_plan']==d['complete_proposed_compiler_Source_plan']and p['prior_compiler_plan']==d['prior_complete_compiler_Source_plan'],'Final complete plan links')
 g.need(p['selected_groups_in_order']==GROUPS,'Only three new groups')
 return rr,p,d
def new_fixture(pr,group):
 proof=g.read(g.checked(pr));extras=[]
 if group=='exterior':
  runref=proof['actual_Native_receipt'];nr=proof['actual_named_inputs'];orr=proof['actual_complete_Native_output'];fr=proof['fixture']
  g.need(proof['whole_transport']['whole_JSON_inverse_equal']and proof['whole_transport']['all_Native_lifetimes_and_states_retained'],'Complete Exterior lossless proof')
  primaryref=proof['primary_only_Source_ingress_authority'];primary=g.read(g.checked(primaryref));source_ref=primary['input_only_payload'];scope=proof['scope_classification']
  expected_extra=dict(source_ingress=g.read(g.checked(source_ref)),source_scope=g.read(g.checked(scope)));extras=[primaryref,source_ref,scope]
 else:
  g.need(proof['accepted']and not proof['findings'],'Accepted new lossless fixture proof')
  runref=proof['actual_Native_group_run'];nr=proof['exact_Native_named_inputs'];orr=proof['exact_Native_output'];fr=proof['fixture']
  source_ref=proof['Source_primary_input']if group=='warmup'else proof['exact_Source_primary_input_projection']
  expected_extra=dict(source_inputs=g.read(g.checked(source_ref)));extras=[source_ref]
  if group=='warmup':extras.append(proof['Source_primary_transport'])
  else:extras.extend([proof['Native_raw_input_single_field_inverse'],proof['authentic_original_Source_ingress'],proof['original_Source_raw_transport']])
 run=g.read(g.checked(runref));g.need(run['accepted']and not run['findings']and run['exit_code']==0 and run['selected_group']==group,'Genuine successful Native '+group)
 g.need(run['Native_bytes_match_before_and_after']and run['actual_three_GNU_DLL_binding_proved_before_any_science_call'],'Native modules/custody '+group)
 g.need(run['full_unit_output']==orr,'Actual whole output ref '+group)
 build=g.read(g.checked(run['actual_build']));ready=g.read(g.checked(run['reviewed_manifest']));g.need(build['accepted']and not build['findings']and build['Native_bytes_match_before_and_after']and ready['named_inputs']==nr,'Original-core build/true named inputs '+group)
 named=g.read(g.checked(nr));output=g.read(g.checked(orr));wrapper=g.read(g.checked(fr))
 expected=dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output,**expected_extra)
 g.need(wrapper==expected,'Entire lossless expected-only Native and primary-input wrapper '+group)
 g.need(output['normal_completion']is True and output['group_order']==[group]and set(output['groups'])=={group},'One complete true Native group '+group)
 if group=='warmup':g.need(run['admission']['original_method_calls']==69 and proof['strict_state_binary64_fields']==45072,'All warmup methods/observations')
 if group=='multiplier_predictor':g.need(run['admission']['original_method_calls']==21 and proof['observed_state_snapshots']==43 and proof['observed_state_raw_finite_fields']==17888,'All full multiplier methods/observations')
 refs=[pr,fr,runref,nr,orr,run['actual_build'],run['reviewed_manifest'],*extras]
 return fr,[g.ref(g.checked(v))for v in refs]
def fixtures(p):
 _,old,od,ou=h54.prepared(p['prior_prepared']['path']+'#'+p['prior_prepared']['sha256']);values,protected=h54.fixtures(old,od,ou)
 for group in GROUPS:
  f,refs=new_fixture(p['fixture_proofs'][group],group);g.need(group not in values,'New group fixture identity');values[group]=f;protected.extend(refs)
 protected=list({v['path']:v for v in protected}.values());g.need(set(values)=={'purchased_air','surface','output_processor','air_history',*GROUPS},'All seven external fixtures protected')
 return values,protected

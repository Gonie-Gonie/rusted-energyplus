"""Seal isolated helper Sources; no shared/main edits, Cargo, simulation or tests."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'source-compact-annual-daygroup-helper-held-Peer-01'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
BASE = '1435b44537a920ded21ae732bdc7c81051df0282'
PFX = 'crates/ep_runtime/src/heat_balance/selected_schedule_manager/'
assert O.exists() and not (O / 'manifest.json').exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def check(row):
    path = R / row['path']
    result = ref(path)
    assert result['sha256'] == row['sha256'] and result['bytes'] == row.get('bytes', result['bytes'])
    return path

def put(name, data):
    path = O / name
    assert not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return ref(path)

def doc(name, value):
    return put(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

def git(root, revision, path):
    return subprocess.check_output(['git', 'show', revision + ':' + path], cwd=root)

def apply_literal(original, difference):
    old = original.decode().splitlines(keepends=True)
    lines = difference.decode().splitlines(keepends=True)
    assert lines[0].startswith('--- ') and lines[1].startswith('+++ ')
    output = []
    position = 0
    cursor = 2
    while cursor < len(lines):
        match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', lines[cursor])
        assert match, lines[cursor]
        start, old_count = int(match[1]), int(match[2] or '1')
        target = start - 1 if old_count else start
        assert position <= target
        output.extend(old[position:target])
        position = target
        consumed = added = 0
        cursor += 1
        while cursor < len(lines) and not lines[cursor].startswith('@@ '):
            row = lines[cursor]
            assert row[0] in ' +-'
            if row[0] in ' -':
                assert position < len(old) and old[position] == row[1:]
                position += 1
                consumed += 1
            if row[0] in ' +':
                output.append(row[1:])
                added += 1
            cursor += 1
        assert consumed == old_count and added == int(match[4] or '1')
    output.extend(old[position:])
    return ''.join(output).encode()

plan_path = D / 'source-compact-schedule-owner-plan-Outer-01/plan.json'
plan = json.loads(plan_path.read_bytes())
assert ref(plan_path)['sha256'].startswith('704076')
freeze_path = D / 'source-compact-schedules-draft-Outer-01/freeze.json'
assert ref(freeze_path)['sha256'] == 'ba2d444ac3871e6840801e92b7616dcbe2ad2a7feb7223e79d27361580a69e31'
freeze = json.loads(freeze_path.read_bytes())
assert freeze['actual_compiler_input_count'] == 4473
snapshot_path = check(freeze['actual_parent_snapshot'])
assert ref(snapshot_path)['sha256'] == '7b46d6f55ae7f001d95d5f0f3762ff8d46e7be7172f373703f5f7cae15021a99'
snapshot = json.loads(snapshot_path.read_bytes())
assert len(snapshot['files']) == 4473
observed = {row['historical_path']: row for row in snapshot['files']}
parent_context = []
for row in freeze['files']:
    name = row['canonical_path']
    assert check(row['parent']).read_bytes() == check(row['actual_archive']).read_bytes() == (R / name).read_bytes()
    assert row['actual_archive'] == observed[name]['archive']
    parent_context.append({'canonical_path': name, 'frozen_parent': row['parent'], 'actual_archive': row['actual_archive'], 'current_whole_equal_actual': True})
before = git(R, BASE, PFX + 'annual.rs')
assert before == (R / (PFX + 'annual.rs')).read_bytes()
native_wholes = []
for name in ['src/EnergyPlus/ScheduleManager.cc', 'src/EnergyPlus/ScheduleManager.hh', 'src/EnergyPlus/EnergyPlus.hh', 'third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh']:
    data = git(N, PIN, name)
    assert data == (N / name).read_bytes()
    native_wholes.append({'Native_path': name, 'revision': PIN, 'whole_Git_equal': True, 'frozen_whole': put('Original-Git/' + name, data)})
extents = []
for name, first, last, purpose in [
    ('src/EnergyPlus/ScheduleManager.cc', 3534, 3610, 'Complete Constant/Detailed day-group methods and cache write order'),
    ('src/EnergyPlus/ScheduleManager.cc', 3743, 3859, 'Complete Constant/Detailed annual and common weekly methods'),
    ('src/EnergyPlus/ScheduleManager.hh', 72, 143, 'Complete DayType/DayTypeGroup/SchedType enum mapping'),
    ('src/EnergyPlus/ScheduleManager.hh', 165, 359, 'Common/day/week/detailed retained fields and constructors'),
    ('src/EnergyPlus/EnergyPlus.hh', 161, 168, 'Actual ObjexxFCL min/max imports'),
    ('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh', 90, 106, 'Actual double min selects SECOND on equality'),
    ('third_party/ObjexxFCL/src/ObjexxFCL/Fmath.hh', 338, 345, 'Actual double max selects FIRST on equality'),
]:
    data = git(N, PIN, name)
    literal = b''.join(data.splitlines(keepends=True)[first - 1:last])
    extents.append({'Native_path': name, 'first_line': first, 'last_line': last, 'purpose': purpose, 'literal': put('Native/' + name.replace('/', '_') + f'.L{first}-{last}.txt', literal)})
rows = []
parses = []
for index, (name, old) in enumerate([(PFX + 'annual.rs', before), (PFX + 'day_group.rs', b'')], 1):
    proposed_path = O / 'proposed' / name
    proposed = proposed_path.read_bytes()
    assert b'#[test]' not in proposed and b'.unwrap(' not in proposed and b'.expect(' not in proposed
    row = {'canonical_path': name, 'before_absent': not bool(old), 'before': put('before/' + name, old), 'proposed': ref(proposed_path)}
    for role, original, target in [('forward_diff', old, proposed), ('inverse_diff', proposed, old)]:
        delta = ''.join(difflib.unified_diff(original.decode().splitlines(keepends=True), target.decode().splitlines(keepends=True), fromfile='before/' + name, tofile='after/' + name)).encode()
        row[role] = put(f'diffs/{index:02}-{role}.diff', delta)
        assert apply_literal(original, delta) == target
    assert not (R / name).exists() if not old else (R / name).read_bytes() == old
    run = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], cwd=R, input=proposed, capture_output=True)
    assert run.returncode == 0, (name, run.stderr)
    parses.append({'canonical_path': name, 'exit_code': run.returncode, 'stdout': put(f'parse/{index:02}.stdout', run.stdout), 'stderr': put(f'parse/{index:02}.stderr', run.stderr), 'proposed_unchanged': proposed_path.read_bytes() == proposed})
    rows.append(row)
api = doc('owner-and-API-contract.json', {
    'consumer_error': 'crate::heat_balance::selected_heat_balance_input::HeatBalanceInputError',
    'common_owner': 'SelectedScheduleManager.schedules Vec<SelectedSchedule> with common current_value/is_min_max_set and data:SelectedScheduleData',
    'data': 'SelectedScheduleData::{Constant{timestep_values:Vec<f64>},Detailed(SelectedDetailedSchedule)}',
    'Detailed_fields_read_or_written': {'week_schedules': '[Option<usize>;367]', 'max_min_by_day_type_set': '[bool;13]', 'min_by_day_type': '[f64;13]', 'max_by_day_type': '[f64;13]'},
    'week_owner': 'self.week_schedules Vec<SelectedWeekSchedule> .number:usize .day_schedules:[Option<usize>;13]',
    'day_owner': 'self.day_schedules Vec<SelectedDaySchedule> .number:usize .is_min_max_set:bool .min_value/max_value/sum_timestep_values:f64 .timestep_values:Vec<f64>',
    'required_parent_methods': ['ensure_source_min_max(&mut self,index:SourceScheduleIndex)->Result<(),HeatBalanceInputError>', 'source_day_min_max(&mut self,day_index:usize)->Result<(f64,f64),HeatBalanceInputError>'],
    'parent_minmax_clock_qualification': 'Parent author confirmed uncached reductions without an actual TimeStepsInHour explicitly stop. Actual input validation uses ensure_source_min_max_with_steps with real clock; both finite Compacts have limited Fraction and genuinely establish reached caches before consumer calls. No vector.len clock inference.',
    'callers': ['nominal.rs passes the actual group0..3 to source_day_group_min_max', 'TAB remaining.rs passes actual time_steps_in_hour:i32 to annual/full-load/weekly and time_step_zone:f64 additionally to greater-than1-percent'],
    'new_module_registration_required': 'Parent selected_schedule_manager.rs must declare mod day_group; integration remains parent-owned.',
})
manifest = doc('manifest.json', {
    'schema': 'src06-held-Compact-Detailed-annual-daygroup-consumer-helper.v1',
    'status': 'HELD isolated helper Sources only; requires owner integration, independent full peer and Root compiler/actual validation',
    'Native_revision': PIN, 'historical_manager_revision': BASE,
    'accepted_parent_freeze': ref(freeze_path), 'actual_parent_snapshot': freeze['actual_parent_snapshot'],
    'actual_B_receipt': freeze['actual_B_receipt'], 'bounded_owner_plan': ref(plan_path),
    'parent_context': parent_context, 'files': rows,
    'existing_Source_files': 1, 'new_Source_files': 1, 'literal_applications': 4,
    'owner_API_contract': api, 'Native_wholes': native_wholes, 'Native_literal_extents': extents,
    'Source_only_parses': parses,
    'annual_math': 'Actual DaysInYear365/366 and weekday1..7 start/advance/wrap. Detailed full-load adds each actual day.sum_timestep_values / f64::from(actual TimeStepsInHour) in day order; no cache or reordered sum. Nonzero method iterates each actual day tick and literally tests >0.0 then adds actual TimeStepZone; no1% threshold. Common weekly divides dispatched annual by366.0/7.0 or365.0/7.0. Constant current_value arithmetic/invalid weekday return0 retained.',
    'day_group_math_and_state': 'Native0Weekday1WeekendHoliday2Summer3Winter exact13-slot filters. Constant returns common current_value without setting caches. Detailed ensures global min/max at Native first operation, checks actual group cache, allocates per-call real week/day checked vectors, zeros groupMax then groupMin, traverses real slots1..366 and day types1..12, skips by actual owner.number, lazily calls day min/max, updates retained group cache immediately in Native firstSet/reduction order, then marks checked day/week and final cache flag. No end-of-method commit proxy.',
    'minmax_operator_authority': 'EnergyPlus.hh imports ObjexxFCL::min/max. Double min(a,b) is a<b?a:b (second on equality), max(a,b) is a<b?b:a (first on equality). Literal comparisons preserve signed-zero/NaN operand behavior; no Rust f64::min/max replacement.',
    'defined_domain_limits': 'Missing actual pointers/arrays and signed24*TimeStepsInHour overflow return typed Unavailable at the reached dereference/condition. No positive-clock/default-state fabrication or arbitrary threshold. Native valid-domain arithmetic is unaltered; exceptional allocation/undefined Native index behavior is not claimed.',
    'not_implemented_by_this_packet': ['Compact input producer/owner structs', 'current clock lookup/EMS/use propagation/minmax producer', 'other Detailed hasVal/getDayVals/getValAndCountOnDay methods', 'caller bridges/module registration'],
    'main_mutations': 0, 'shared_proposal_mutations': 0, 'Cargo_Native_or_tests_executed': False,
    'new_test_bodies': 0, 'gate_changes': 0, 'integration_or_actual_success_claim': False,
    'author_Source': ref(Path(__file__)),
})
for row in freeze['files']:
    assert (R / row['canonical_path']).read_bytes() == check(row['parent']).read_bytes()
print(json.dumps(manifest))

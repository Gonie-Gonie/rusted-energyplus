"""Three cfg-only contextual compile corrections on applied coherent55."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Exterior-warmup-multiplier-correction-Outer-55-02'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=Path(v['path']);p=p if p.is_absolute() else R/p;a=ref(p);assert (a['sha256'],a['bytes'])==(v['sha256'],v['bytes']);return p
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode());return ref(p)
def main():
 assert not O.exists();original=D/'source-Exterior-warmup-multiplier-coherent-Outer-55/manifest.json';v=json.loads(original.read_bytes());assert ref(original)['sha256']=='2f4396d7dba94037a55f2d57207d1669aea25cd260533ebf31bee4b48b31fc9b'
 prior=checked(v['complete_proposed_compiler_Source_plan']);plan=json.loads(prior.read_bytes());assert (plan['compiler_inputs'],plan['Rust_sources'])==(4554,4541)
 failed=D/'canonical-source-gap-batch-warmup-Root-55/receipt.json';run=json.loads(failed.read_bytes());assert ref(failed)['sha256']=='fb77752e257b68e6879e01dbe4a9df3916eaa6067f4f4b063babdc8c32828679'
 assert run['exit_code']==101 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
 snapshot=R/run['source_snapshot']['path'];archived={r['historical_path']:r for r in json.loads(snapshot.read_bytes())['files']};assert len(archived)==4554
 parent={r['path']:r for r in plan['entries']}
 for cp,row in parent.items():
  b=(R/cp).read_bytes();assert b==checked(row['source']).read_bytes();ar=archived[cp];assert b==(R/ar['archive']['path']).read_bytes() and len(b)==ar['size_bytes']
 stderr=R/run['stderr']['path'];text=stderr.read_text(encoding='utf-8');assert 'E0425' in text and 'E0599' in text and 'E0631' in text
 specs=[
 ('crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress.rs',
 b'    pub(super) fn invoke_actual_gains(&mut self) -> Result {\n',
 b'    pub(super) fn invoke_actual_gains(&mut self) -> Result {\n        let schedules = self\n            .reports\n            .selected_schedule_manager\n            .as_mut()\n            .ok_or("same schedule owner")?;\n',
 'Reborrow the same retained schedule owner for the real manager context. Actual schedule update remains once in prepare_gain_clock; no call, value or state writer is added.'),
 ('crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source/native_gap_cohort.rs',
 b'let input_owner=SelectedInputProcessor::default();',
 b'let input_owner=SelectedInputProcessor::from_admitted_input(Vec::new(),std::collections::BTreeMap::new())?;',
 'Use the real fallible admitted-input constructor with genuinely absent families/definitions. Actual cold getter only calls get_num_objects_found and gets zero on absence; no fake schema or readiness is supplied.'),
 ('crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress/geometry.rs',
 b'            outside_boundary_condition_object: alpha(raw, "outside_boundary_condition_object")?\n                .map(NormalizedName::new),',
 b'            outside_boundary_condition_object: alpha(raw, "outside_boundary_condition_object")?\n                .as_deref()\n                .map(NormalizedName::new),',
 'Borrow the existing Option<String> as Option<&str> for the actual NormalizedName::new signature. Same optional raw string and normalization function; no primary value or geometry calculation changes.')]
 script=D/'assemble-Source-Exterior-warmup-multiplier-Outer-55.py';tree=ast.parse(script.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<literal-patch-only>','exec'),ns)
 prepared=[]
 for cp,a,b,reason in specs:
  before=(R/cp).read_bytes();assert before.count(a)==1;after=before.replace(a,b,1);assert after.count(b)==1 and after.replace(b,a,1)==before
  forward=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=cp,tofile=cp)).encode();inverse=''.join(difflib.unified_diff(after.decode().splitlines(True),before.decode().splitlines(True),fromfile=cp,tofile=cp)).encode();assert ns['apply'](before,forward)==after and ns['apply'](after,inverse)==before
  parse=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert parse.returncode==0,parse.stderr
  prepared.append((cp,before,after,forward,inverse,parse.stdout,parse.stderr,reason))
 O.mkdir();files=[]
 for cp,a,b,f,i,out,err,reason in prepared:
  refs=[]
  for folder,suffix,data in [('before','',a),('proposed','',b),('diffs','.forward.diff',f),('diffs','.inverse.diff',i),('parse','.stdout.rs',out),('parse','.stderr.txt',err)]:
   p=O/folder/(cp+suffix);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);refs.append(ref(p))
  files.append({'canonical_path':cp,'before_absent':False,'before':refs[0],'proposed':refs[1],'forward_diff':refs[2],'inverse_diff':refs[3],'Source_only_parse':{'exit_code':0,'stdout':refs[4],'stderr':refs[5],'syntax_only':True},'reason':reason})
 final=copy.deepcopy(parent)
 for row in files:
  p=row['proposed'];final[row['canonical_path']]={'path':row['canonical_path'],'final_sha256':p['sha256'],'final_bytes':p['bytes'],'source':p,'origin':'55-02 exact contextual cfg binding correction'}
 newplan={'schema':'src06-complete-Source55-02-corrected-compiler-plan.v1','base_HEAD':v['base_HEAD'],'prior_complete_compiler_Source_plan':ref(prior),'original_coherent_draft':ref(original),
  'preserved_compile_failure':ref(failed),'compiler_inputs':4554,'inputs':4554,'Rust_sources':4541,'corrective_selected':3,'coherent_selected_total':38,'coherent_existing':22,'coherent_new':16,
  'exactly_three_rows_changed':True,'other4551_Source_and_metadata_rows_whole_equal':True,'entries':[final[p] for p in sorted(final)],
  'qualification':'Fresh retry-stage metadata; parent entries only are inherited. Initial compile101 is preserved, no science ran. No successful contextual/typecheck/numeric result is implied by syntax parsing.'}
 planref=save(O/'complete-proposed-compiler-Source-plan.json',newplan)
 contexts=[ref(R/p) for p in ['crates/ep_runtime/src/heat_balance/selected_input_processor.rs','crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source.rs','crates/ep_model/src/names.rs','crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input/state.rs'] if (R/p).exists()]
 result={'schema':'src06-three-contextual-cfg-bindings-correction-55-02.v1','status':'FROZEN_MINIMAL_ROOT_PEER_AND_CONTEXTUAL_RETRY_PENDING','base_HEAD':v['base_HEAD'],'files':files,'literal_applications':6,'fresh_Source_only_syntax_parses':3,
  'original_coherent_draft':ref(original),'prior_complete_compiler_Source_plan':ref(prior),'complete_proposed_compiler_Source_plan':planref,
  'initial_compile_failure':ref(failed),'failed_stdout':ref(R/run['stdout']['path']),'failed_stderr':ref(stderr),'failed_snapshot':ref(snapshot),
  'all4554_failed_snapshot_parent_archive_live_whole_equal':True,'all_other35_coherent_selected_Source_wholes_unchanged':True,'source_contexts':contexts,
  'external_fixture_before_after_protection':v['external_fixture_before_after_protection'],'new_group_fixtures':v['new_group_fixtures'],
  'scientific_input_output_formula_cache_flags_or_tolerances_changed':False,'canonical_Cargo_Native_execution':False,'author_Source':ref(Path(__file__))}
 print(json.dumps({'draft':save(O/'draft.json',result),'plan':planref}))
if __name__=='__main__':main()

// Passive same-owner observations. No Native output is restored.
fn report_array_shape<T>(values: &[T], allocated: bool) -> Value {
    json!({"allocated":allocated,"size":values.len(),"lower":1,"upper":values.len()})
}
fn observed_real_array(values: &Option<Vec<f64>>) -> Value {
    let mut out = array1(values);
    out["items"] = Value::Array(values.as_deref().unwrap_or(&[]).iter().copied().map(number).collect());
    out
}
fn observed_report_array(values: &[f64], allocated: bool) -> Value {
    let mut out = report_array_shape(values, allocated);
    out["items"] = Value::Array(values.iter().copied().map(number).collect());
    out
}
fn observed_report_matrix(values: &[Vec<f64>], allocated: bool, zones: usize, points: usize) -> Result<Value> {
    if values.len() != points || values.iter().any(|row| row.len() != zones) {
        return Err(invalid("same real warmup report matrix shape").into());
    }
    Ok(json!({"allocated":allocated,"size":zones.checked_mul(points).ok_or_else(||invalid("warmup matrix size"))?,
        "lower1":1,"upper1":zones,"lower2":1,"upper2":points,
        "items_by_point":values.iter().map(|row| Value::Array(row.iter().copied().map(number).collect())).collect::<Vec<_>>()}))
}
fn observed_manager(factory: &WarmupFactory) -> Result<Value> {
    let m = &factory.session.heat_balance;
    let report = &m.report;
    let available = report.source_allocations.ok_or_else(||invalid("actual Source warmup array availability"))?;
    let mut arrays = Map::new();
    macro_rules! real_array {
        ($native:literal, $field:ident) => { arrays.insert($native.into(), observed_real_array(&m.$field)); };
    }
    real_array!("MaxCoolLoadPrevDay", max_cool_load_prev_day);
    real_array!("MaxCoolLoadZone", max_cool_load_zone);
    real_array!("MaxHeatLoadPrevDay", max_heat_load_prev_day);
    real_array!("MaxHeatLoadZone", max_heat_load_zone);
    real_array!("MaxTempPrevDay", max_temp_prev_day);
    real_array!("MaxTempZone", max_temp_zone);
    real_array!("MinTempPrevDay", min_temp_prev_day);
    real_array!("MinTempZone", min_temp_zone);
    arrays.insert("WarmupTempDiff".into(), observed_report_array(&report.temperature_difference, available[0]));
    arrays.insert("WarmupLoadDiff".into(), observed_report_array(&report.load_difference, available[1]));
    real_array!("TempZoneSecPrevDay", temp_zone_sec_prev_day);
    real_array!("LoadZoneSecPrevDay", load_zone_sec_prev_day);
    real_array!("TempZonePrevDay", temp_zone_prev_day);
    real_array!("LoadZonePrevDay", load_zone_prev_day);
    real_array!("TempZone", temp_zone);
    real_array!("LoadZone", load_zone);
    let mut convergence = array1(&m.convergence);
    convergence["items"] = Value::Array(m.convergence.as_deref().unwrap_or(&[]).iter().map(|row|json!({
        "address":pointer(row),"PassFlag":{"allocated":true,"size":row.pass_flags.len(),"lower":1,"upper":row.pass_flags.len(),"items":row.pass_flags},
        "TestMaxTempValue":number(row.test_values[0]),"TestMinTempValue":number(row.test_values[1]),
        "TestMaxHeatLoadValue":number(row.test_values[2]),"TestMaxCoolLoadValue":number(row.test_values[3])})).collect());
    let mut temp_scratch = report_array_shape(&report.temperature_stddev, available[5]);
    let mut load_scratch = report_array_shape(&report.load_stddev, available[6]);
    // Native allocated primitive scratch is indeterminate until another routine writes it.
    // This unit never invokes that writer; Source's None entries are not numeric answers.
    if report.temperature_stddev.iter().any(Option::is_some) || report.load_stddev.iter().any(Option::is_some) {
        return Err(invalid("warmup scratch has an unexpected actual writer").into());
    }
    temp_scratch["items"] = Value::Null;
    temp_scratch["values_written"] = json!(false);
    load_scratch["items"] = Value::Null;
    load_scratch["values_written"] = json!(false);
    let zones = usize::try_from(factory.globals.num_of_zones)?;
    Ok(json!({"owner_address":pointer(m),"arrays":arrays,
        "TempZoneRpt":observed_report_matrix(&report.temperature,available[2],zones,report.points_per_day)?,
        "LoadZoneRpt":observed_report_matrix(&report.load,available[3],zones,report.points_per_day)?,
        "MaxLoadZoneRpt":observed_report_matrix(&report.maximum_load,available[4],zones,report.points_per_day)?,
        "TempZoneRptStdDev":temp_scratch,"LoadZoneRptStdDev":load_scratch,"WarmupConvergenceValues":convergence,
        "CountWarmupDayPoints":report.count,"ManageHeatBalanceGetInputFlag":m.manage_heat_balance_get_input_flag,
        "ChangeSet":m.change_set,"FirstWarmupWrite":report.first_detailed_write,
        "WarmupConvergenceWarning":report.warmup_convergence_warning,"SizingWarmupConvergenceWarning":report.sizing_warmup_convergence_warning,
        "ReportWarmupConvergenceFirstWarmupWrite":report.first_summary_write,
        "CurrentModuleObject":factory.reports.heat_balance_current_module_object}))
}
fn observed_state(factory: &WarmupFactory) -> Result<Value> {
    let zones = factory.zones.zones.as_deref().ok_or_else(||invalid("real warmup Zone owner"))?;
    let air = factory.session.air.zones.as_deref().ok_or_else(||invalid("real warmup Air owner"))?;
    let demand = factory.session.controller.demand.zones.as_deref().ok_or_else(||invalid("real warmup demand owner"))?;
    let count = usize::try_from(factory.globals.num_of_zones)?;
    if zones.len() != count || air.len() != count || demand.len() != count {
        return Err(invalid("genuine warmup physical row extents").into());
    }
    let rows = zones.iter().zip(air).zip(demand).enumerate().map(|(at,((zone,air),demand))|json!({
        "ordinal":at+1,"zone_address":pointer(zone),"air_address":pointer(&air.air),"demand_address":pointer(demand),
        "name":zone.name,"ZTAV":number(air.air.ztav),"airSysHeatRate":number(demand.air_sys_heat_rate),"airSysCoolRate":number(demand.air_sys_cool_rate)})).collect::<Vec<_>>();
    let clock = &factory.weather.global;
    let project = &factory.control;
    let error = &factory.error_state;
    let tracking = &error.tracking;
    let recurring = &factory.reports.source_recurring_errors;
    Ok(json!({"state_address":pointer(factory),"manager":observed_manager(factory)?,"zones":rows,
        "clock":{"NumOfZones":factory.globals.num_of_zones,"TimeStepsInHour":clock.time_steps_in_hour,"TimeStep":clock.time_step,
            "HourOfDay":clock.hour_of_day,"DayOfSim":clock.day_of_sim,"WarmupFlag":clock.warmup_flag,
            "DoingSizing":factory.globals.doing_sizing,"DoPureLoadCalc":factory.globals.do_pure_load_calc,
            "KickOffSimulation":error.kickoff_simulation,"DoingInputProcessing":error.doing_input_processing},
        "project":{"LoadsConvergTol":number(project.loads_convergence_tolerance),"TempConvergTol":number(project.temperature_convergence_tolerance),
            "MaxNumberOfWarmupDays":project.max_number_of_warmup_days,"MinNumberOfWarmupDays":factory.project.min_number_of_warmup_days,
            "ReportDetailedWarmupConvergence":factory.project.system.report_detailed_warmup_convergence},
        "environment":{"EnvironmentName":factory.weather.environment.environment_name,"RunPeriodEnvironment":factory.weather.environment.run_period_environment},
        "allocation_context":{"numSpaces":factory.globals.num_spaces,"NumOfSolarEnclosures":factory.radiation.num_solar_enclosures(),
            "CO2Simulation":project.carbon_dioxide_simulation,"GenericContamSimulation":project.generic_contaminant_simulation,
            "TotThermalReportPers":factory.weather.weather.tot_thermal_report_periods,"TotCO2ReportPers":factory.weather.weather.tot_co2_report_periods,
            "TotVisualReportPers":factory.weather.weather.tot_visual_report_periods},
        "surface_child_domain":{"AnyMovableInsulation":factory.geometry.any_movable_insulation,
            "AllHTWindowSurfaceList":factory.geometry.surface_lists.all_ht_window,"TotSurfaces":factory.geometry.total_surfaces},
        "eio":std::str::from_utf8(&factory.eio)?,
        "errors":{"text":std::str::from_utf8(&factory.error)?,"TotalWarningErrors":tracking.total_warning_errors,
            "TotalSevereErrors":tracking.total_severe_errors,"TotalWarningErrorsDuringWarmup":tracking.total_warning_errors_during_warmup,
            "TotalSevereErrorsDuringWarmup":tracking.total_severe_errors_during_warmup,"TotalWarningErrorsDuringSizing":tracking.total_warning_errors_during_sizing,
            "TotalSevereErrorsDuringSizing":tracking.total_severe_errors_during_sizing,"NumRecurringErrors":recurring.number,
            "RecurringErrors":array1(&recurring.rows),"MatchCounts":{"allocated":true,"size":tracking.match_counts.len(),"lower":1,"upper":tracking.match_counts.len(),"items":tracking.match_counts}},
        "error_context":{"LastSevereError":tracking.last_severe_error,"AbortProcessing":tracking.abort_processing,
            "outputErrorHeader":error.output_error_header,"VerStringVar":error.version_string,"IDDVerString":error.idd_version_string,
            "sqlite_present":factory.reports.source_sqlite.present(),
            // All actual backend views in this factory pass the genuine optional callback as None.
            "error_callback_present":false}}))
}

#[derive(Default)]
struct WarmupIdentities {
    pairs: BTreeMap<(String,String),String>,
    raw_bits: usize,
}
impl WarmupIdentities {
    fn compare(&mut self, source: &Value, native: &Value, path: &str) -> Result {
        match (source,native) {
            (Value::Object(a),Value::Object(b))=>{
                assert_eq!(a.keys().collect::<Vec<_>>(),b.keys().collect::<Vec<_>>(),"{path} complete admitted keyset");
                if a.len()==1 && a.contains_key("value_bits") {self.raw_bits+=1;}
                for (key,actual) in a {
                    let expected=b.get(key).ok_or_else(||invalid("observed warmup key"))?;
                    if matches!(key.as_str(),"address"|"owner_address"|"state_address"|"zone_address"|"air_address"|"demand_address") {
                        let actual=text(actual)?;let expected=text(expected)?;
                        assert!(actual.starts_with("0x")&&expected.starts_with("0x"),"{path} real pointer transport");
                        let kind=key.clone();let identity=(kind.clone(),expected.to_owned());
                        if let Some(previous)=self.pairs.get(&identity) {assert_eq!(previous,actual,"{path} persistent same owner");}
                        else {
                            assert!(!self.pairs.iter().any(|((old_kind,old_native),old_source)|old_kind==&kind && old_native!=expected && old_source==actual),"{path} distinct real rows");
                            self.pairs.insert(identity,actual.to_owned());
                        }
                    } else {self.compare(actual,expected,&format!("{path}.{key}"))?;}
                }
            }
            (Value::Array(a),Value::Array(b))=>{
                assert_eq!(a.len(),b.len(),"{path} complete array extent");
                for (at,(actual,expected)) in a.iter().zip(b).enumerate(){self.compare(actual,expected,&format!("{path}[{at}]"))?;}
            }
            _=>assert_eq!(source,native,"{path} exact observed value"),
        }
        Ok(())
    }
    fn check(&mut self, factory:&WarmupFactory,native:&Value,path:&str)->Result {
        let source=observed_state(factory)?;
        let mut admitted=native.clone();
        let manager=admitted.get_mut("manager").and_then(Value::as_object_mut).ok_or_else(||invalid("actual Native manager observation"))?;
        if !manager.remove("DoReport").is_some_and(|v|v.is_boolean()) {return Err(invalid("actual unused Native DoReport shape").into());}
        let surface=admitted.get_mut("surface_child_domain").and_then(Value::as_object_mut).ok_or_else(||invalid("actual Native surface observation"))?;
        let insulation=surface.remove("intMovInsulSurfNums").ok_or_else(||invalid("actual Native unused insulation list"))?;
        assert!(array(&insulation)?.is_empty(),"unit genuinely has no movable-insulation rows");
        // No Source cells represent these two unconsumed legacy fields. All other
        // observed values, including entire diagnostics and all consumed arrays, compare.
        self.compare(&source,&admitted,path)
    }
}

pub(super) fn run(fixture:&Value)->Result<usize> {
    let ingress=member(fixture,"source_inputs")?;
    assert_eq!(member(ingress,"schema")?,"src06-warmup-Source-primary-ingress.v1");
    let definitions=member(ingress,"definitions")?;
    let factories=array(member(ingress,"factories")?)?;
    let named=member(member(fixture,"named_inputs")?,"warmup")?;
    let expected=member(member(member(fixture,"native_output")?,"groups")?,"warmup")?;
    assert_eq!(member(named,"schema")?,"src06-warmup-RecKeep-Check-input.v1");
    assert_eq!(member(expected,"schema")?,"src06-warmup-RecKeep-Check-output.v1");
    let cases=array(member(named,"cases")?)?;
    let outputs=array(member(expected,"cases")?)?;
    assert_eq!(cases.len(),6);assert_eq!(outputs.len(),6);assert_eq!(factories.len(),6);
    let mut calls=0;let mut bits=0;
    for (case,output) in cases.iter().zip(outputs) {
        let name=member(case,"name")?;
        assert_eq!(name,member(output,"name")?);assert_eq!(member(case,"origin")?,member(output,"origin")?);
        assert_eq!(member(case,"initial_phase")?,member(output,"initial_phase")?);
        let definition=factories.iter().find(|v|v.get("name")==Some(name)).ok_or_else(||invalid("exact real warmup factory ingress"))?;
        assert_eq!(member(definition,"input_file")?,member(member(case,"factory")?,"input_file")?);
        assert_eq!(member(definition,"steps")?,member(case,"steps")?);
        let mut factory=WarmupFactory::new(definitions,definition,member(case,"initial_phase")?)?;
        let mut identities=WarmupIdentities::default();
        identities.check(&factory,member(output,"after_real_factory_project_and_allocation")?,&format!("{name}.allocated"))?;
        let steps=array(member(case,"steps")?)?;let actuals=array(member(output,"steps")?)?;
        assert_eq!(steps.len(),actuals.len());
        for (at,(step,actual)) in steps.iter().zip(actuals).enumerate() {
            assert_eq!(count(member(actual,"ordinal")?)?,at+1);
            assert_eq!(member(step,"name")?,member(actual,"name")?);assert_eq!(member(step,"operation")?,member(actual,"operation")?);
            assert_eq!(step,member(actual,"named_inputs")?);
            // Caller clock and current primary values precede the genuine method entry.
            factory.prepare_call(step)?;
            identities.check(&factory,member(actual,"entry")?,&format!("{name}.step{at}.entry"))?;
            factory.invoke(step)?;
            identities.check(&factory,member(actual,"exit")?,&format!("{name}.step{at}.exit"))?;
            calls+=1;
        }
        bits+=identities.raw_bits;
    }
    assert_eq!(calls,69);
    println!("Native warmup cohort: {calls} full persistent RecKeep/Check calls; {bits} strict finite fields; no prior cohort rerun");
    Ok(calls)
}

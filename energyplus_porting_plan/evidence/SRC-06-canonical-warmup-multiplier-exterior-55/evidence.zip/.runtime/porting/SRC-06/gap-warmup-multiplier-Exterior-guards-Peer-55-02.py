"""Read-only Source55-02 correction guards; retain initial38 and actual compile failure."""
from pathlib import Path
import hashlib,importlib.util,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
BASE=D/'gap-warmup-multiplier-Exterior-guards-Peer-55.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='a259dc6dbb56a09807846af4078d2b089c81c8582b0e0d15f213c633aa0044ad'
s=importlib.util.spec_from_file_location('original55_retry_readonly',BASE);original=importlib.util.module_from_spec(s);s.loader.exec_module(original);g=original.g
APP=D/'Root-warmup-multiplier-Exterior-application-55-02';GROUPS=original.GROUPS
counts=original.counts;diffs=original.diffs;current_head=original.current_head
def prepared(spec):
 rr=g.argument(spec);p=g.read(g.checked(rr));g.need(p['status']=='READY_FOR_ROOT_THREE_CORRECTIONS_THREE_SELECTED_RETRIES','55-02 preparation not READY')
 _,old,d=original.prepared(p['original_prepared']['path']+'#'+p['original_prepared']['sha256'])
 correction=g.read(g.checked(p['correction']));original.peer(p['correction_independent_peer'],p['correction'])
 app=g.read(g.checked(p['initial_application']));g.need(app['accepted']and not app['findings']and app['prepared']==p['original_prepared']and app['all_final_compiler_bytes_exact'],'Genuine initial38 application')
 g.need(p['base_HEAD']==old['base_HEAD']==app['base_HEAD']==correction['base_HEAD'],'Same committed parent across initial applied WIP')
 g.need(correction['original_coherent_draft']==old['draft']and correction['prior_complete_compiler_Source_plan']==p['prior_compiler_plan']==app['complete_compiler_plan'],'Exact original applied55 whole parent')
 g.need(correction['complete_proposed_compiler_Source_plan']==p['complete_compiler_plan'],'Only corrected final plan')
 failed=g.read(g.checked(p['failed_Source_attempt']));g.need(failed['exit_code']==101 and failed['launch_error']is None and failed['source_bytes_match_before_and_after'],'Actual compile failure retained')
 g.need(failed['repository_before']==failed['repository_after']and failed['repository_before']['head']==p['base_HEAD'],'Failed compilation repository stable')
 log=g.checked(p['failed_stderr']).read_text(encoding='utf-8');g.need('error[E0425]'in log and 'error[E0599]'in log and 'error[E0631]'in log and 'running 1 original-core gap'not in g.checked(p['failed_stdout']).read_text(encoding='utf-8'),'Exactly compile-stage failure, no scientific comparison')
 for key in ['guard_Source','application_Source','launch_Source','actual_checker_Source','environment_guard','record_command_Source']:g.checked(p[key])
 g.need(g.checked(p['guard_Source'])==Path(__file__).resolve(),'Exact retry guard');g.need(p['environment_guard']==old['environment_guard']and p['record_command_Source']==old['record_command_Source'],'Inherited command/environment policies unchanged')
 g.need(p['selected_groups_in_order']==GROUPS,'Only three fresh selected retries');return rr,p,correction
def fixtures(p):
 _,old,_=original.prepared(p['original_prepared']['path']+'#'+p['original_prepared']['sha256']);return original.fixtures(old)
def parent_archive(p):
 run=g.read(g.checked(p['failed_Source_attempt']));sr=g.ref(R/run['source_snapshot']['path']);g.need(sr['sha256']==run['source_snapshot']['sha256'],'Original failed Source archive ledger')
 snapshot=g.read(g.checked(sr));plan=g.read(g.checked(p['prior_compiler_plan']));rows={r['path']:r for r in plan['entries']};archive={r['historical_path']:r for r in snapshot['files']};g.need(archive.keys()==rows.keys(),'All initial4554 names archived')
 for name,row in rows.items():
  v=archive[name];a=g.ref(R/v['archive']['path']);g.need(a['sha256']==v['archive']['sha256']==row['final_sha256']and a['bytes']==v['size_bytes']==row['final_bytes'],'Exact initial failed4554 archived bytes '+name)
 return sr
def coherent_selected(p,correction):
 _,old,d=original.prepared(p['original_prepared']['path']+'#'+p['original_prepared']['sha256']);replacement={r['canonical_path']:r for r in correction['files']};g.need(len(replacement)==3,'Exactly three corrected existing cfg Sources');apply=g.literal();selected=[]
 for row in d['files']:
  name=row['canonical_path'];b=b''if row.get('before_absent',row['before']is None)else g.checked(row['before']).read_bytes();a=g.checked(row['proposed']).read_bytes();fw,iv=diffs(row)
  g.need(apply(b,g.checked(fw).read_bytes())==a and apply(a,g.checked(iv).read_bytes())==b,'Original38 literal Source '+name)
  if name in replacement:
   c=replacement[name];g.need(g.checked(c['before']).read_bytes()==a,'Correction exact before proposal '+name);after=g.checked(c['proposed']).read_bytes();fw,iv=diffs(c)
   g.need(apply(a,g.checked(fw).read_bytes())==after and apply(after,g.checked(iv).read_bytes())==a,'Three correction full literal inverses '+name);a=after
  g.need((R/name).read_bytes()==a,'Final current corrected38 Source '+name);selected.append(name)
 g.need(len(set(selected))==38 and set(replacement)<=set(selected),'Original38 footprint retained');return selected
def bounded_existing_worktree(p):
 app=g.read(g.checked(p['initial_application']));_,_,d=original.prepared(app['prepared']['path']+'#'+app['prepared']['sha256']);allowed={r['canonical_path']for r in d['files']}
 changed=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines());new=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
 g.need(changed|new<=allowed,'No unrelated tracked/untracked worktree mutation');return dict(tracked_changed=sorted(changed),untracked=sorted(new))

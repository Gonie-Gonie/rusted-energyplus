"""Lossless actual Native multiplier fixture plus input-only raw getter projection."""
from pathlib import Path
import copy,hashlib,json,struct
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-multiplier-runtime-fixture-Peer-01'
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix()if p.is_relative_to(R)else p.as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def check(v):
 p=(R/v['path']).resolve();assert all(ref(p)[k]==v[k]for k in ('sha256','bytes'));return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def bits(v):
 if isinstance(v,dict):
  if set(v)=={'value_bits'}:
   s=v['value_bits'];assert len(s)==16 and s==s.lower();x=struct.unpack('>d',bytes.fromhex(s))[0];assert x==x and abs(x)!=float('inf');return 1
  return sum(bits(x)for x in v.values())
 if isinstance(v,list):return sum(bits(x)for x in v)
 return 0
def main():
 assert not O.exists();O.mkdir()
 ap=D/'original-core-gap-batch-run-Root-08-multiplier_predictor/receipt.json';a=read(ap)
 assert ref(ap)['sha256']=='7b29caa2694d108439e47244c1a94a812c063f10ea632d3f1f3859a8f2db2d92'
 assert a['accepted']and not a['findings']and a['exit_code']==0 and a['Native_bytes_match_before_and_after']and a['actual_three_GNU_DLL_binding_proved_before_any_science_call']
 build=read(check(a['actual_build']));assert build['accepted']and not build['findings']and build['Native_bytes_match_before_and_after']
 ready=read(check(a['reviewed_manifest']));named_ref=ready['named_inputs'];named=read(check(named_ref));out_ref=a['full_unit_output'];out=read(check(out_ref))
 assert out['normal_completion']is True and out['group_order']==['multiplier_predictor']and set(out['groups'])=={'multiplier_predictor'}
 leaf=D/'multiplier2-full-predictor-Native-draft-Peer-01/draft.json';l=read(leaf);assert named['multiplier_predictor']==read(check(l['named_inputs']))
 cases=named['multiplier_predictor']['cases'];outputs=out['groups']['multiplier_predictor']['cases'];assert len(cases)==len(outputs)==1
 case=cases[0];actual=outputs[0];assert case['name']==actual['name']and case['origin']==actual['origin']
 ip=read(check(l['input_field_inverse']));base=check(ip['original']).read_bytes();unit=check(ip['proposed']).read_bytes();old=ip['original_Zone_object'].encode();new=ip['proposed_Zone_object'].encode()
 assert base.count(old)==1 and unit==base.replace(old,new,1)and unit.replace(new,old,1)==base
 assert case['factory']['input_authority']==ip['proposed']
 srcp=D/'source-purchased-air-gap-scaffold-Peer-01/input-only.json';src=read(srcp);first=src['factories'][0]
 assert first['case']=='B-NOLIMIT-24H'and first['source_is_epjson']is False
 factory=copy.deepcopy(first);assert factory['raw']['Zone']['ZONE ONE']['multiplier']==1
 factory['raw']['Zone']['ZONE ONE']['multiplier']=2
 inverse=copy.deepcopy(factory);inverse['raw']['Zone']['ZONE ONE']['multiplier']=1;assert inverse==first
 assert set(factory['raw']['Zone'])=={'ZONE ONE'}and factory['object_order']==first['object_order']and factory['steps']==first['steps']
 source=dict(schema='src06-multiplier2-primary-Source-getter-input.v1',definitions=src['definitions'],factory=factory)
 sp=save(O/'source-input-only.json',source);assert read(check(sp))==source
 operations={};states=[actual['after_real_getter_and_initializer_chain']]
 for i,(step,observed)in enumerate(zip(case['steps'],actual['steps'],strict=True)):
  assert observed['name']==step['name']and observed['operation']==step['operation']and observed['named_inputs']==step['inputs']
  if 'arguments'in step:assert observed['arguments']==step['arguments']
  else:assert 'arguments'not in observed
  operations[step['operation']]=operations.get(step['operation'],0)+1;states.extend([observed['entry'],observed['exit']])
 assert operations=={'predict':5,'correct':5,'push_system':5,'push_zone':5,'revert_zone':1}and len(states)==43
 for state in states:
  z=state['Zone_metadata'];assert len(z)==1 and z[0]['Multiplier']==2 and z[0]['ListMultiplier']==1
  assert state['NumOfZones']==1 and not state['doSpaceHeatBalance']and not state['anyNonMixingRoomAirModel']and state['ZoneAirSolutionAlgo']==0
  assert state['predictor_flags']['humidityControlZoneIndex']==0
 total=bits(out);owner=sum(bits(s)for s in states);returned=sum(bits(s.get('returned_temp_change'))for s in actual['steps'])
 assert total==a['admission']['raw_finite_binary64_fields']==17953
 fixture=dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=out,source_inputs=source)
 fp=save(O/'fixture.json',fixture);f=read(check(fp));assert set(f)=={'schema','named_inputs','native_output','source_inputs'}and f['named_inputs']==named and f['native_output']==out and f['source_inputs']==source
 proof=save(O/'projection.json',dict(schema='src06-multiplier2-lossless-runtime-fixture-provenance.v1',accepted=True,findings=[],actual_Native_group_run=ref(ap),actual_original_core_build=a['actual_build'],actual_reviewed_manifest=a['reviewed_manifest'],exact_Native_named_inputs=named_ref,exact_Native_output=out_ref,exact_Source_primary_input_projection=sp,fixture=fp,
  accepted_Native_unit_leaf=ref(leaf),Native_raw_input_single_field_inverse=l['input_field_inverse'],authentic_original_Source_ingress=ref(srcp),original_Source_raw_transport=ref(D/'source-purchased-air-gap-scaffold-Peer-01/input-transport-proof.json'),
  Source_primary_change=dict(path='factory.raw.Zone.ZONE ONE.multiplier',before=1,after=2,unit_raw_field='Zone N6',all_other_factory_tree_and_definition_rows_whole_exact=True,whole_inverse_to_original_first_P1_factory=True,actual_object_order_and_shape_metadata_preserved=True,production_case_files_or_admission_changed=False),
  Native_whole_output_raw_finite_fields=total,observed_state_snapshots=43,observed_state_raw_finite_fields=owner,returned_corrector_raw_fields=returned,operations=operations,whole_JSON_inverses_exact=True,
  no_formula_expected_reconstruction=True,no_observed_output_or_history_restored_as_input=True,Source_execution=False,qualification='Only complete documents losslessly wrapped. Input-only Source projection changes exactly genuine raw Zone N6 before getters. Other old raw family/definition/order operands are retained; Native current exit/state bits remain expected-only.',author_Source=ref(Path(__file__))))
 print(json.dumps(dict(fixture=fp,projection=proof,source_inputs=sp,Native_whole_bits=total,state_bits=owner,returned_bits=returned)))
if __name__=='__main__':main()

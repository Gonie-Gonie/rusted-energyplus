void CHKGSS(EnergyPlusData &state,
            int const NRS,     // Surface number of the potential shadow receiving surface
            int const NSS,     // Surface number of the potential shadow casting surface
            Real64 const ZMIN, // Lowest point of the receiving surface
            bool &CannotShade  // TRUE if shadow casting surface cannot shade receiving surface.
)
{

    // SUBROUTINE INFORMATION:
    //       AUTHOR         Legacy Code
    //       DATE WRITTEN
    //       MODIFIED       na
    //       RE-ENGINEERED  Lawrie, Oct 2000

    // PURPOSE OF THIS SUBROUTINE:
    // Determines the possible shadowing combinations.  The
    // routine checks detached shadowing or base heat transfer surfaces
    // for the possibility that they cannot shade a given base heat transfer surface.

    // METHODOLOGY EMPLOYED:
    // Shadowing is not possible if:
    // 1.  The lowest point of the shadow receiving surface (receiving surface)
    //     Is higher than the highest point of the shadow casting surface (s.s.)
    // 2.  The shadow casting surface Faces up (e.g. A flat roof)
    // 3.  The shadow casting surface Is behind the receiving surface
    // 4.  The receiving surface is behind the shadow casting surface

    // REFERENCES:
    // BLAST/IBLAST code, original author George Walton

    // Using/Aliasing
    using namespace Vectors;

    // Object Data

    CannotShade = true;

    auto &s_surf = state.dataSurface;

    // see if no point of shadow casting surface is above low point of receiving surface

    auto const &surface_C = s_surf->Surface(NSS);
    if (surface_C.OutNormVec(3) > 0.9999) {
        return; // Shadow Casting Surface is horizontal and facing upward
    }
    auto const &vertex_C = surface_C.Vertex;
    Real64 ZMAX(vertex_C(1).z);
    for (int i = 2, e = surface_C.Sides; i <= e; ++i) {
        ZMAX = std::max(ZMAX, vertex_C(i).z);
    }
    if (ZMAX <= ZMIN) {
        return;
    }

    // SEE IF ANY VERTICES OF THE Shadow Casting Surface ARE ABOVE THE PLANE OF THE receiving surface

    auto const &surface_R = s_surf->Surface(NRS);
    auto const &vertex_R = surface_R.Vertex;
    Vector const &vertex_R_2 = vertex_R(2);
    Vector const AVec = (vertex_R(1) - vertex_R_2); // Vector from vertex 2 to vertex 1 of receiving surface
    Vector const BVec = (vertex_R(3) - vertex_R_2); // Vector from vertex 2 to vertex 3 of receiving surface

    Vector const CVec = cross(BVec, AVec); // Vector perpendicular to surface at vertex 2

    int const NVSS = surface_C.Sides; // Number of vertices of the shadow casting surface
    Real64 DOTP(0.0);                 // Dot Product
    for (int I = 1; I <= NVSS; ++I) {
        DOTP = dot(CVec, vertex_C(I) - vertex_R_2);
        if (DOTP > state.dataSolarShading->TolValue) {
            break; // DO loop
        }
    }

    // SEE IF ANY VERTICES OF THE receiving surface ARE ABOVE THE PLANE OF THE S.S.

    if (DOTP > state.dataSolarShading->TolValue) {

        Vector const &vertex_C_2 = vertex_C(2);
        Vector const AVector(vertex_C(1) - vertex_C_2);
        Vector const BVector(vertex_C(3) - vertex_C_2);

        Vector const CVector(cross(BVector, AVector));

        int const NVRS = surface_R.Sides; // Number of vertices of the receiving surface
        for (int I = 1; I <= NVRS; ++I) {
            DOTP = dot(CVector, vertex_R(I) - vertex_C_2);
            if (DOTP > state.dataSolarShading->TolValue) {
                CannotShade = false;
                break; // DO loop
            }
        }
    }
}

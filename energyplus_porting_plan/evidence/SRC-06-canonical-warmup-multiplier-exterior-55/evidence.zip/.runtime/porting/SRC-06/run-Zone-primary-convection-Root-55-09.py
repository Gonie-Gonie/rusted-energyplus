"""Apply input-only typed convection transport; run only remaining categories."""
from pathlib import Path
import hashlib, importlib.util, json, re, subprocess, sys

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'

def main():
    path = D / 'Constant-Exterior-category-guards-Peer-55-06.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == 'aeb1e6934ed858fcf8a52f5f8b788ec03fcb6a9a4e9cd308bdc8ef16813c947d'
    spec = importlib.util.spec_from_file_location('zone09_guard', path)
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    pr = g.ref(D / 'Constant-Exterior-category-Root-helpers-ready-Peer-55-06/prepared.json')
    g.need(pr['sha256'] == '1d0bb4f61e2a381871248401308dbdae0dd1a716951a09aea42c3585f027c019', 'Original prepared06 policy')
    _, p, _, _, _, fixtures, protected, _ = g.prepared(pr['path'] + '#' + pr['sha256'])
    dr = g.ref(D / 'source-Zone-primary-convection-Outer-55-09/draft.json')
    g.need(dr['sha256'] == '8f643618b1c394dfad2a3c03bf8cf561da78bc78607b9006ecba5ad4eebe4aec', 'Reviewed exact typed convection input draft')
    draft = g.read(dr)
    old = g.read(draft['prior_complete_compiler_Source_plan'])
    new = g.read(draft['complete_proposed_compiler_Source_plan'])
    g.need(draft['prior_complete_compiler_Source_plan']['sha256'] == '252cf72faff2fde39664ccc3bb7e1e2be59bacf41abf31690b3d040c144b754a', 'Actual Shadow08 parent')
    g.need(draft['complete_proposed_compiler_Source_plan']['sha256'] == '34c21aa4b41ee4206dc11000082744b4b88bf49ff5736f7329fbd46794abed58', 'Exact proposed compiler plan')
    g.exact(old)
    g.need(draft['base_HEAD'] == p['base_HEAD'], 'Unchanged actual committed parent')
    native = R / '.reference/energyplus-src/26.1.0'
    g.need(subprocess.check_output(['git', '-C', str(native), 'rev-parse', 'HEAD'], text=True).strip() == draft['Native_commit'] == '6f2e40d10250a105b49966baa24d843711e61048', 'Pinned Native revision')
    for authority in draft['Native_authorities']:
        whole = g.checked(authority['whole']).read_bytes()
        git_whole = subprocess.check_output(['git', '-C', str(native), 'show', draft['Native_commit'] + ':' + authority['Native_path']])
        g.need(whole == git_whole, 'Exact pinned Git authority ' + authority['Native_path'])
        lines = whole.splitlines(keepends=True)
        for extent in authority['extents']:
            g.need(b''.join(lines[extent['first']-1:extent['last']]) == g.checked(extent['source']).read_bytes(), 'Exact strict Native extent')
    for context in draft['concrete_same_owner_contexts']:
        g.checked(context['whole'])
    ledger_ref = draft['actual_primary_ledger']
    ledger = g.read(ledger_ref)
    g.checked(ledger['whole_fixture'])
    g.need(len(ledger['geometry_factories']) == 4, 'All four geometry input-only raw ledgers')
    for factory in ledger['geometry_factories']:
        g.checked(factory['actual_primary_IDF'])
        g.need(next(iter(factory['inside'].values()))['algorithm'] == 'TARP' and next(iter(factory['outside'].values()))['algorithm'] == 'DOE-2', 'Actual authored global primary algorithms')
    before = {row['path']: row for row in old['entries']}
    after = {row['path']: row for row in new['entries']}
    names = {row['canonical_path'] for row in draft['files']}
    g.need(names == {'crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress/geometry.rs'}, 'Exactly one cfg input carrier; production getters and guard unchanged')
    g.need(before.keys() == after.keys() and {name for name in before if before[name] != after[name]} == names, 'Other4555 compiler rows exact')
    apply = g.h.g.literal()
    changes = []
    for row in draft['files']:
        a, b = g.checked(row['before']).read_bytes(), g.checked(row['proposed']).read_bytes()
        target = (R / row['canonical_path']).resolve()
        g.need(target.is_relative_to(R) and not row['before_absent'] and target.read_bytes() == a, 'Exact current old whole')
        g.need(apply(a, g.checked(row['forward_diff']).read_bytes()) == b and apply(b, g.checked(row['inverse_diff']).read_bytes()) == a, 'Both exact literal applications')
        parse = row['Source_only_parse']
        g.need(parse['exit_code'] == 0 and parse['syntax_only'] and g.checked(parse['stdout']).read_bytes() == b, 'Fresh whole syntax parse only')
        g.checked(parse['stderr'])
        changes.append((target, b))
    failed = g.read(draft['actual_failed_55_08'])
    g.need(failed['exit_code'] == 1 and failed['launch_error'] is None and failed['source_bytes_match_before_and_after'], 'Actual prior08 failure retained')
    g.archive(failed, old)
    folder = D / 'Root-Zone-primary-convection-application-55-09'
    outputs = {category: D / ('canonical-source-gap-batch-exterior-' + category + '-Root-55-09') for category in ['beam_producer', 'surface_internal_gains']}
    g.need(not folder.exists() and all(not out.exists() for out in outputs.values()), 'Fresh immutable09 outputs')
    protected_before = [g.ref(g.checked(v)) for v in protected]
    env = g.environment(p)
    folder.mkdir()
    review = g.save(folder / 'independent-review.json', dict(accepted=True, findings=[], reviewed_draft=dr, reviewer='Root, independent of Outer author', files=[row['proposed'] for row in draft['files']], literal_applications=2, exact_pinned_Native_wholes_and_extents=True, actual_primary_ledger=ledger_ref, semantics='Root fully read the one cfg literal delta and pinned HeatBalanceManager724-807/2285-2412, actual four raw primary ledgers, existing identity transport and production Zone equality guard. Typed global and per-Zone metadata now consumes actual raw Algorithm objects and explicit overrides, with pinned TARP/DOE-2 absent-getter defaults. All live getter/control writes, branch order, equality guard, math, fixtures and tolerances remain unchanged. Syntax checks do not claim context compilation.', author_Source=g.ref(Path(__file__))))
    for target, value in changes:
        target.write_bytes(value)
    g.exact(new)
    app = g.save(folder / 'receipt.json', dict(accepted=True, findings=[], base_HEAD=p['base_HEAD'], draft=dr, independent_review=review, prior_complete_compiler_plan=draft['prior_complete_compiler_Source_plan'], complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'], compiler_inputs=4556, Rust_sources=4542, changed_files=sorted(names), literal_applications=2, all_current_and_archived_wholes_exact=True, carried06_prepared=pr, protected_before=protected_before, prior_failed_attempt=draft['actual_failed_55_08']))
    results = []
    for category, out in outputs.items():
        command = g.command(fixtures, category)
        g.save(folder / (category + '-before.json'), dict(application=app, command=command, complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'], protected=protected_before))
        code = subprocess.call([sys.executable, str(g.checked(p['record_command_Source'])), '--output-dir', str(out), '--', *command], cwd=R, env=env)
        g.exact(new)
        protected_after = [g.ref(g.checked(v)) for v in protected]
        g.need(protected_before == protected_after, 'Seven fixture authorities unchanged')
        runref = g.ref(out / 'receipt.json')
        run = g.read(runref)
        g.need(run['exit_code'] == code and run['launch_error'] is None and run['source_bytes_match_before_and_after'] and run['repository_before'] == run['repository_after'] and run['command'] == command, 'Actual complete command custody')
        logs = {key: g.ref(R / run[key]['path']) for key in ['stdout', 'stderr']}
        g.need(all(logs[key]['sha256'] == run[key]['sha256'] for key in logs), 'Complete actual logs')
        item = dict(accepted=code == 0, findings=[] if code == 0 else ['Actual selected category failed; complete failure retained, no numerical PASS.'], category=category, application=app, actual_receipt=runref, complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'], Source_and_fixtures_stable=True, protected_before=protected_before, protected_after=protected_after, exit_code=code, logs=logs)
        results.append(g.save(folder / (category + '-after.json'), item))
        if code:
            print(json.dumps(results))
            return code
    print(json.dumps(results))
    return 0

if __name__ == '__main__':
    sys.exit(main())

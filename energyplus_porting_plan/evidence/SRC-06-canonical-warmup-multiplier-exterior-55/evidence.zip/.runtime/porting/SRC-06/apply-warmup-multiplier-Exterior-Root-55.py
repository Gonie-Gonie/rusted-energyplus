"""Root-only one exact coherent Source55 application, with reversible rollback."""
from pathlib import Path
import argparse,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
s=importlib.util.spec_from_file_location('guard55',D/'gap-warmup-multiplier-Exterior-guards-Peer-55.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
def main(a):
 pr,p,d=h.prepared(a.prepared);g.need(g.checked(p['application_Source'])==Path(__file__).resolve(),'Exact application Source')
 h.current_head(p['base_HEAD']);g.need(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'Clean committed Source54 parent')
 old=g.read(g.checked(p['prior_compiler_plan']));g.need(h.counts(old)==(4538,4525,4538),'Full actual parent counts');g.exact({e['path']:e for e in old['entries']})
 final=g.read(g.checked(p['complete_compiler_plan']));g.need(h.counts(final)==(4554,4541,4554),'Exact final compiler counts');rows={e['path']:e for e in final['entries']}
 fixture_map,protected=h.fixtures(p);apply=g.literal();materials=[]
 for f in d['files']:
  name=f['canonical_path'];target=(R/name).resolve();g.need(target.is_relative_to(R)and name.startswith('crates/ep_runtime/src/'),'Bounded selected Source path')
  exists=not f.get('before_absent',f['before']is None);oldbytes=g.checked(f['before']).read_bytes()if exists else b'';after=g.checked(f['proposed']).read_bytes()
  g.need(target.exists()==exists,'Target existence '+name)
  if exists:g.need(target.read_bytes()==oldbytes and subprocess.check_output(['git','show','HEAD:'+name],cwd=R)==oldbytes,'Current/Git selected before '+name)
  fw,iv=h.diffs(f);g.need(apply(oldbytes,g.checked(fw).read_bytes())==after and apply(after,g.checked(iv).read_bytes())==oldbytes,'Exact two whole literal applications '+name);materials.append((name,oldbytes,after,exists))
 g.need(len(materials)==38 and sum(x[3]for x in materials)==22,'Exact38 Sources22existing16new');g.need(not h.APP.exists(),'Fresh Root application path');h.APP.mkdir()
 for name,oldbytes,_,exists in materials:
  if exists:
   target=h.APP/'before'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(oldbytes)
 try:
  for name,_,after,_ in materials:
   target=R/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after)
  g.exact(rows);g.need([g.ref(g.checked(v))for v in protected]==protected,'All seven fixtures/proofs unchanged')
 except BaseException:
  for name,oldbytes,_,exists in materials:
   target=R/name
   if exists:target.write_bytes(oldbytes)
   elif target.exists():target.unlink()
  raise
 result=dict(schema='src06-Source55-three-group-application.v1',accepted=True,findings=[],prepared=pr,base_HEAD=p['base_HEAD'],draft=p['draft'],joint_independent_peer=p['joint_independent_peer'],semantic_peers=p['semantic_peers'],prior_compiler_plan=p['prior_compiler_plan'],complete_compiler_plan=p['complete_compiler_plan'],changed_Source_files=38,existing=22,new=16,compiler_inputs=4554,Rust_sources=4541,all_final_compiler_bytes_exact=True,fixtures=fixture_map,protected_all_seven_external_fixtures=protected,actual_Cargo_or_CLI_invocations=0,application_Source=g.ref(Path(__file__)))
 out=h.APP/'receipt.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(out)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prepared',required=True);main(p.parse_args())

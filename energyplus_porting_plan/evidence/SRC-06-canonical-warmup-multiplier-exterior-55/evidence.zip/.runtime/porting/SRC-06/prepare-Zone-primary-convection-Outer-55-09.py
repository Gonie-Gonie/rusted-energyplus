"""Private input-only typed metadata fix. Real production guard/getters unchanged."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];A=R/'.runtime/porting/SRC-06';O=A/'source-Zone-primary-convection-Outer-55-09'
P=A/'source-ShadowCalculation-explicit-Outer-55-08/complete-proposed-compiler-Source-plan.json'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def save(p,j):return put(p,(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode())
def diff(n,a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n)).encode()
assert not O.exists();O.mkdir();plan=json.loads(P.read_bytes());assert (plan['compiler_inputs'],plan['Rust_sources'])==(4556,4542)
n='crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress/geometry.rs';before=(R/n).read_bytes();s=before.decode()
old='    let mut model = identity_model(factory, control, steps)?;\n';assert s.count(old)==1
s=s.replace(old,old+(A/'Zone-primary-convection-UNSEALED-Outer-55-09.rs').read_text(encoding='utf-8'))
helper='''fn primary_inside_convection(value: &str) -> Result<InsideSurfaceConvectionAlgorithm> {
    Ok(match value {
        "SIMPLE" => InsideSurfaceConvectionAlgorithm::Simple,
        "TARP" => InsideSurfaceConvectionAlgorithm::Tarp,
        "CEILINGDIFFUSER" => InsideSurfaceConvectionAlgorithm::CeilingDiffuser,
        "TROMBEWALL" => InsideSurfaceConvectionAlgorithm::TrombeWall,
        "ADAPTIVECONVECTIONALGORITHM" => InsideSurfaceConvectionAlgorithm::AdaptiveConvectionAlgorithm,
        "ASTMC1340" => InsideSurfaceConvectionAlgorithm::AstmC1340,
        _ => return Err(invalid("primary inside convection enum").into()),
    })
}
fn primary_outside_convection(value: &str) -> Result<OutsideSurfaceConvectionAlgorithm> {
    Ok(match value {
        "SIMPLECOMBINED" => OutsideSurfaceConvectionAlgorithm::SimpleCombined,
        "TARP" => OutsideSurfaceConvectionAlgorithm::Tarp,
        "MOWITT" => OutsideSurfaceConvectionAlgorithm::MoWitt,
        "DOE-2" => OutsideSurfaceConvectionAlgorithm::Doe2,
        "ADAPTIVECONVECTIONALGORITHM" => OutsideSurfaceConvectionAlgorithm::AdaptiveConvectionAlgorithm,
        _ => return Err(invalid("primary outside convection enum").into()),
    })
}
'''
needle='fn primary_model(\n';assert s.count(needle)==1;s=s.replace(needle,helper+needle)
q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=s.encode(),capture_output=True,cwd=R);assert q.returncode==0,q.stderr.decode();after=q.stdout
e=next(e for e in plan['entries'] if e['path']==n);assert e['final_sha256']==hashlib.sha256(before).hexdigest()
row=dict(canonical_path=n,before_absent=False,before=put(O/'before'/n,before),proposed=put(O/'proposed'/n,after),forward_diff=put(O/'diffs'/(n+'.forward.diff'),diff(n,before,after)),inverse_diff=put(O/'diffs'/(n+'.inverse.diff'),diff(n,after,before)),Source_only_parse=dict(exit_code=q.returncode,stdout=ref(O/'proposed'/n),stderr=put(O/'parse/stderr.txt',q.stderr),syntax_only=True))
e.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'])
pr=save(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-complete-compiler-Source-plan.v1',compiler_inputs=4556,inputs=4556,Rust_sources=4542,entries=plan['entries'],prior_complete_compiler_Source_plan=ref(P),current_stage='55-09 input-only geometry Zone convection transport',selected_inputs=1,other4555_parent_wholes_unchanged=True))
fixture=A/'source-Exterior-runtime-fixture-Outer-01/fixture.json';j=json.loads(fixture.read_bytes());cases=[]
for name,f in j['source_ingress']['factories'].items():
 if 'BuildingSurface:Detailed' not in f['raw']:continue
 cases.append(dict(name=name,actual_primary_IDF=f['actual_primary_IDF'],Zone=f['raw']['Zone'],inside=f['raw'].get('SurfaceConvectionAlgorithm:Inside',{}),outside=f['raw'].get('SurfaceConvectionAlgorithm:Outside',{})))
assert len(cases)==4
ledger=save(O/'actual-primary-Zone-convection-ledger.json',dict(schema='src06-actual-primary-Zone-convection-transport.v1',whole_fixture=ref(fixture),geometry_factories=cases,diagnosis='Old cfg identity_model inherited Simple/SimpleCombined from cold control before real project getter. Actual four raw projects author TARP/DOE-2 and omit Zone overrides. Real ProcessZoneData inherits those actual project algorithms; production equality guard is correct and unchanged.',qualifications=['Named primary objects only; no native_output/expected field is read.','TARP/DOE-2 absent-object defaults are pinned Original getter defaults, not constructor replacement or readiness writes.','No real getter is skipped/reordered; typed model remains metadata and actual raw getter independently executes.']))
native=[]
for name,ranges in [('src/EnergyPlus/HeatBalanceManager.cc',[(724,807),(2285,2412)]),('idd/Energy+.idd.in',[(698,740)])]:
 p=R/'.reference/energyplus-src/26.1.0'/name;b=p.read_bytes();assert subprocess.check_output(['git','show','6f2e40d10250a105b49966baa24d843711e61048:'+name],cwd=R/'.reference/energyplus-src/26.1.0')==b
 native.append(dict(Native_path=name,whole=ref(p),extents=[dict(first=a,last=z,source=put(O/'Native'/f'{p.name}.{a}-{z}',b''.join(b.splitlines(True)[a-1:z]))) for a,z in ranges]))
contexts=[dict(canonical_path=n,whole=ref(R/n)) for n in ['crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/control.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/input.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input.rs','crates/ep_model/src/objects/building.rs']]
failure=A/'canonical-source-gap-batch-exterior-beam_producer-Root-55-08/receipt.json';assert json.loads(failure.read_bytes())['exit_code']==1
d=dict(schema='src06-input-only-Zone-convection-Source-draft.v1',status='FROZEN_CFG_SOURCE_ONLY_ROOT_PEER_PENDING',base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),files=[row],prior_complete_compiler_Source_plan=ref(P),complete_proposed_compiler_Source_plan=pr,actual_failed_55_08=ref(failure),actual_primary_ledger=ledger,Native_commit='6f2e40d10250a105b49966baa24d843711e61048',Native_authorities=native,concrete_same_owner_contexts=contexts,author_Source=ref(Path(__file__)),scope=['One cfg-only typed primary transport; no production change.','Global authored convection algorithms and Zone overrides parsed only from actual raw primary fields.','Production raw-versus-typed guard and all actual getter call ordering remain unchanged.','No expected fixture, scientific math/state, provider, cache, tolerance, admission or shape/readiness assignment changes.','No Source/Native execution or canonical mutation; complete Exterior result remains pending actual calls.'])
print(json.dumps(dict(draft=save(O/'draft.json',d),plan=pr),indent=2))

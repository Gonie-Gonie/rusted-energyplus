"""Minimal observer shape/definedness checks; preserve numerical body/old draft."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-absorption-cohort-draft-Outer-02'
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
def diff(p,a,b):p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='preserved01',tofile='strict-observer02')).encode());return ref(p)
def main():
 assert not O.exists();O.mkdir();old_path=D/'source-absorption-cohort-draft-Outer-01/draft.json';old=json.loads(old_path.read_bytes());new=copy.deepcopy(old)
 row=next(x for x in new['files'] if x['canonical_path'].endswith('/absorption.rs'));a=(R/row['proposed']['path']).read_bytes();b=a
 fragments=[(
 b'        vector(thermal,&e["inside_thermal_absorptance"],"actual inside thermal values")?;',
 b'        if e["inside_thermal_absorptance"]["values_defined"].as_bool()!=Some(true)||e["inside_solar_absorptance"]["values_defined"].as_bool()!=Some(true){return Err("Native absorption arrays must have genuine defined values".into());}\n        vector(thermal,&e["inside_thermal_absorptance"],"actual inside thermal values")?;'),(
 b'                    let state=&call[key];let addresses=',
 b'                    let state=&call[key];\n                    for name in ["state_address","radiant_owner_address","solar_owner_address"]{if state[name].as_u64().filter(|v|*v>0).is_none(){return Err("Native absorption identity must be an actual nonnull address".into());}}\n                    let addresses=')]
 for x,y in fragments:assert b.count(x)==1;b=b.replace(x,y,1)
 back=b
 for x,y in reversed(fragments):assert back.count(y)==1;back=back.replace(y,x,1)
 assert back==a
 p=O/'absorption.rs';p.write_bytes(b);row['proposed']=ref(p)
 row['diffs']=dict(forward=diff(O/'canonical.forward.diff',b'',b),inverse=diff(O/'canonical.inverse.diff',b,b''))
 parse=subprocess.run(['rustfmt','--edition','2021','--emit','stdout'],input=b,capture_output=True);q=O/'syntax.stdout.rs';q.write_bytes(parse.stdout);assert parse.returncode==0,parse.stderr;row['Source_only_parse']=dict(exit_code=0,stdout=ref(q))
 new['preserved_01']=ref(old_path);new['observer_only_correction']=dict(forward=diff(O/'observer.forward.diff',a,b),inverse=diff(O/'observer.inverse.diff',b,a),exact_inverse_whole_01=True,notes=['Require both Native observed numeric vectors values_defined=true.','Require actual nonnull unsigned Native state/radiant/solar addresses before repeated identity comparison.','Other hub whole, every scientific call/formula/input/writer/sequence and all existing assertions unchanged.'])
 new['author_Source']=ref(Path(__file__));print(json.dumps(dict(draft=save(O/'draft.json',new))))
if __name__=='__main__':main()

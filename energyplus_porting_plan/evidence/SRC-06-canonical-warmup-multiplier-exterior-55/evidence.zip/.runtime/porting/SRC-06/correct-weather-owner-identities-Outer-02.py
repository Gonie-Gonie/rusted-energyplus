"""Ignored-only Weather3 passive identity correction; no scientific execution."""
from pathlib import Path
import copy, difflib, hashlib, json, subprocess
R=Path(__file__).resolve().parents[3]; D=R/'.runtime/porting/SRC-06'
O=D/'source-weather-owner-cohort-draft-Outer-02'
def ref(p):
 p=p.resolve(); b=p.read_bytes(); return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=R/v['path']; assert ref(p)==v; return p
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode());return ref(p)
def diff(p,a,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='preserved-weather01',tofile='strict-weather02')).encode());return ref(p)
def main():
 assert not O.exists();O.mkdir(); prior=D/'source-exterior-closed-draft-Outer-02/draft.json';v=json.loads(prior.read_bytes());rows=[];bridges=[]
 for row in v['Sources'][:4]:
  cp=row['canonical_path'];a=checked(row['proposed']).read_bytes();b=a
  if cp.endswith('/native_gap_cohort.rs'):
   s=a.decode();marker='fn state(v:&WeatherDayState,e:&Value)->Result<()> {';assert s.count(marker)==1
   s=s.replace(marker,'''fn native_identity(e: &Value) -> Result<u64> {
    let address = e["state_address"].as_u64().ok_or("Native Weather owner address must be unsigned")?;
    if address == 0 { return Err("Native Weather owner address must be nonnull".into()); }
    Ok(address)
}
fn state(v:&WeatherDayState,e:&Value,native_owner:u64,source_owner:usize)->Result<()> {
    if native_identity(e)? != native_owner { return Err("Native Weather owner changed within lifetime".into()); }
    if v as *const WeatherDayState as usize != source_owner { return Err("actual Source WeatherDayState owner changed within lifetime".into()); }
''',1)
   old='let mut owner=Self::default();';assert s.count(old)==1
   s=s.replace(old,old+'\n            let source_owner=&owner as *const WeatherDayState as usize;\n            let native_owner=native_identity(&oracle["initial"])?;',1)
   for expr in ['&oracle["initial"]','&expected["before"]','&expected["after"]']:
    old=f'state(&owner,{expr})?;';assert s.count(old)==1;s=s.replace(old,f'state(&owner,{expr},native_owner,source_owner)?;',1)
   run=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=s.encode(),capture_output=True);assert run.returncode==0,run.stderr;b=run.stdout
  p=O/'proposed'/cp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);nr=copy.deepcopy(row);nr['proposed']=ref(p)
  before=b'' if row['before_absent'] else checked(row['before']).read_bytes()
  nr['forward']=diff(O/'diffs'/f'{cp}.forward.diff',before,b);nr['inverse']=diff(O/'diffs'/f'{cp}.inverse.diff',b,before)
  run=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert run.returncode==0,run.stderr
  out=O/'parse'/f'{cp}.stdout.rs';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(run.stdout);err=out.with_suffix('.stderr.txt');err.write_bytes(run.stderr)
  nr['Source_only_parse']={'argv':['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],'stdin':nr['proposed'],'stdout':ref(out),'stderr':ref(err),'exit_code':0,'syntax_only_no_contextual_typecheck':True}
  if cp.endswith('/native_gap_cohort.rs'):assert run.stdout==b
  rows.append(nr);bridges.append({'canonical_path':cp,'whole_unchanged':a==b,'forward':diff(O/'correction-diffs'/f'{cp}.forward.diff',a,b),'inverse':diff(O/'correction-diffs'/f'{cp}.inverse.diff',b,a)})
 new={'schema':'src06-weather-owner-cohort-draft.v1','status':'SOURCE_ONLY_WEATHER_IDENTITY_CORRECTION_NO_TYPECHECK_OR_RUN','author_Source':ref(Path(__file__)),'preserved_prior':ref(prior),'Sources':rows,'correction':{'scope':'Only passive owner checks plus rustfmt of the new child. Native nonnull unsigned state identity is required initially and at every before/after phase. Actual separate Source WeatherDayState pointer is retained across all real daily/direction/Determine calls; no cross-process address equality or scientific input/math/call changes.','bridges':bridges},'Native_commit':v['Native_commit'],'Native_authorities':v['Native_authorities'],'same_owner_contexts':v['same_owner_contexts'],'scope':'The first four Weather3 Sources only; production opaque and cold/absorption/sky leaves remain separately authenticated. No complete Exterior/Source execution claimed.'}
 print(json.dumps({'draft':save(O/'draft.json',new)}))
if __name__=='__main__':main()

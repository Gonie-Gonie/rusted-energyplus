"""Private metadata preparation only; never calls application, Cargo, or Native."""
from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
guard=D/'Constant-Exterior-category-guards-Peer-55-06.py';sha=ref(guard)['sha256']
for name in ['apply-Constant-Exterior-category-Root-55-06.py','launch-Constant-Exterior-category-Root-55-06.py']:
 p=D/name;b=p.read_bytes();assert b.count(b'GUARD_SHA')==1;p.write_bytes(b.replace(b'GUARD_SHA',sha.encode()))
for name in [guard.name,'apply-Constant-Exterior-category-Root-55-06.py','launch-Constant-Exterior-category-Root-55-06.py']:ast.parse((D/name).read_text(encoding='utf8'))
s=importlib.util.spec_from_file_location('prepare_category06_guard',guard);g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
dr=g.ref(D/'source-Constant-Exterior-category-coherent-Peer-55-06/draft.json');draft=g.read(dr);pr3=g.ref(D/'warmup-multiplier-Exterior-Root-helpers-ready-Peer-55-03/prepared.json');_,p3,c3=g.h.prepared(pr3['path']+'#'+pr3['sha256']);_,p2,c2=g.h.prior(p3);_,_,original=g.h.old.original.prepared(p2['original_prepared']['path']+'#'+p2['original_prepared']['sha256']);diag=g.read(g.ref(D/'source-Weather-gap-diagnostic-Outer-55-04/draft.json'));math=g.read(g.ref(D/'source-Weather-UCRT-math-provider-Outer-55-05-02/draft.json'));apply=g.h.g.literal();first={};last={};apps=0
for document in [original,c2,c3,diag,math,draft]:
 for row in document['files']:
  n=row['canonical_path'];absent=row.get('before_absent',row['before'] is None);a=b'' if absent else g.checked(row['before']).read_bytes();b=g.checked(row['proposed']).read_bytes();fw,iv=g.h.diffs(row);assert apply(a,g.checked(fw).read_bytes())==b and apply(b,g.checked(iv).read_bytes())==a;apps+=2
  if n in last:assert g.checked(last[n]['proposed']).read_bytes()==a
  else:
   first[n]=dict(before=row['before'],before_absent=absent)
   if not absent:assert subprocess.check_output(['git','show','HEAD:'+n],cwd=R)==a
  last[n]=row
plan=g.read(draft['complete_proposed_compiler_Source_plan']);rows={r['path']:r for r in plan['entries']}
for n,row in last.items():assert (rows[n]['final_sha256'],rows[n]['final_bytes'])==(row['proposed']['sha256'],row['proposed']['bytes'])
assert (len(last),sum(x['before_absent'] for x in first.values()),apps)==(48,18,118)
folder=D/'Constant-Exterior-category-Root-helpers-ready-Peer-55-06';assert not folder.exists();folder.mkdir()
ledger=g.save(folder/'full-selected-Source-ledger.json',dict(schema='src06-final48-selected-custody-ledger.v1',selected=48,existing=30,new=18,literal_applications=118,files=[dict(canonical_path=n,first=first[n],final=last[n]['proposed']) for n in sorted(last)],qualification='Full successive exact literal chain from committed54 to final06. All48 selected final proposals map to exact4556 final plan rows; no canonical write or scientific execution.'))
p=dict(schema='src06-Root-warning-category-helpers-ready.v1',status='READY_FOR_ROOT_SEVEN_ROWS_THREE_REMAINING_CATEGORIES',base_HEAD=draft['base_HEAD'],coherent_draft=dr,prior_compiler_plan=draft['prior_complete_compiler_Source_plan'],complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'],selected_Source_ledger=ledger,selected=48,existing=30,new=18,compiler_inputs=4556,Rust_sources=4542,carried03_prepared=pr3,guard_Source=g.ref(guard),application_Source=g.ref(D/'apply-Constant-Exterior-category-Root-55-06.py'),launch_Source=g.ref(D/'launch-Constant-Exterior-category-Root-55-06.py'),environment_guard=p3['environment_guard'],record_command_Source=p3['record_command_Source'],selected_categories_in_order=g.CATEGORIES,category_records={k:dict(admitted=v[0],excluded=v[1]) for k,v in g.COUNTS.items()},mechanical_peer_supplied_as_application_argument=True,prior05_progress=draft['source05_qualified_progress'],old_passed_scientific_groups_rerun=False,gate_changes=0,policy_changes=0,preparation_only=True,author_Source=ref(Path(__file__)))
rr=g.save(folder/'prepared.json',p);g.prepared(rr['path']+'#'+rr['sha256']);g.exact(g.read(draft['prior_complete_compiler_Source_plan']));g.environment(p)
print(json.dumps(dict(prepared=rr,helpers={k:p[k] for k in ['guard_Source','application_Source','launch_Source']},selected_ledger=ledger)))

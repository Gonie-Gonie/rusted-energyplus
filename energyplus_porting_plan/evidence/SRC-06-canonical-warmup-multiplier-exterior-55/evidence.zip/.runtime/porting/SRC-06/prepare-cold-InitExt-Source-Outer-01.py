"""Owner-aware cold InitExt/GetUser production continuation, isolated only."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-cold-exterior-convection-draft-Outer-01'
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
def diff(p,a,b):
 p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='actual-current-Source',tofile='private-cold-InitExt')).encode());return ref(p)
def main():
 assert not O.exists();O.mkdir();files=[]
 source='crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source.rs'
 dispatcher='crates/ep_runtime/src/heat_balance/inside_convection_dispatcher.rs'
 child='crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source/cold_external.rs'
 initial={p:(R/p).read_bytes() for p in [source,dispatcher]}
 assert not(R/child).exists();s=initial[source].decode();nl='\r\n' if b'\r\n' in initial[source] else '\n'
 assert s.count('use super::{')==1;s=s.replace('use super::{','mod cold_external;'+nl+'use super::{',1)
 # Move the existing exact Zone-view expressions into a shared helper; the
 # ordinary full-geometry path continues to call the identical expressions.
 start=s.index('    let zones = owners',s.index('fn static_views('))
 end=s.index('    let source = geometry',start)
 original=s[start:end]
 helper='fn static_zone_views(owners: &SelectedZoneInputOwners) -> Result<Vec<InsideConvectionZone>, Error> {'+nl+original.replace('    let zones = owners','    owners',1)
 helper=helper.replace('.collect::<Result<Vec<_>, Error>>()?;', '.collect::<Result<Vec<_>, Error>>()')+'}'+nl+nl
 s=s[:start]+'    let zones = static_zone_views(owners)?;'+nl+s[end:]
 insertion=s.index('fn static_views(');s=s[:insertion]+helper+s[insertion:]
 needle='        let layout = source_layout(geometry, zones)?;'+nl+'        Ok(Self {'
 replacement='''        let layout = match cold_external::layout(geometry, zones)? {
            Some(layout) => layout,
            None => source_layout(geometry, zones)?,
        };
        Ok(Self {'''.replace('\n',nl)
 assert s.count(needle)==1;s=s.replace(needle,replacement,1)
 anchor='''        if !self.state.get_user_input {
            return Ok(());
        }
        let layout = source_layout(geometry, zones)?;'''.replace('\n',nl)
 repl='''        if !self.state.get_user_input {
            return Ok(());
        }
        if self.prepare_cold_external_convection(geometry, zones, input, reports, scan, backend)? {
            return Ok(());
        }
        let layout = source_layout(geometry, zones)?;'''.replace('\n',nl)
 assert s.count(anchor)==1;s=s.replace(anchor,repl,1)
 outputs={source:s.encode()}
 t=initial[dispatcher].decode();dn='\r\n' if b'\r\n' in initial[dispatcher] else '\n'
 before='''    let mut building_volume = 0.0;
    for zone in zones {'''.replace('\n',dn)
 after='''    let mut building_volume = 0.0;
    // Native declares this one local before the entire Zone loop. If neither
    // branch assigns it, keep its previous value (or genuinely unrepresented).
    let mut diameter = None;
    for zone in zones {'''.replace('\n',dn)
 assert t.count(before)==1;t=t.replace(before,after,1)
 before='''        let diameter = if simple_perimeter > 0.0 {
            4.0 * zone.floor_area / simple_perimeter
        } else {
            zone.floor_area.sqrt()
        };'''.replace('\n',dn)
 after='''        if simple_perimeter > 0.0 {
            diameter = Some(4.0 * zone.floor_area / simple_perimeter);
        } else if zone.floor_area > 0.0 {
            diameter = Some(zone.floor_area.sqrt());
        }'''.replace('\n',dn)
 assert t.count(before)==1;t=t.replace(before,after,1)
 needle='                    [zone.ceiling_height, perimeter, diameter, ratio],'
 repl='''                    [
                        zone.ceiling_height,
                        perimeter,
                        diameter.ok_or(InsideConvectionUnavailable::Geometry)?,
                        ratio,
                    ],'''.replace('\n',dn)
 assert t.count(needle)==1;t=t.replace(needle,repl,1);outputs[dispatcher]=t.encode()
 outputs[child]=r'''//! Actual cold InitExt first call: no Space traversal and no heat-transfer rows.
//! Physical Surface rows remain allocated in the same geometry owner. Only
//! the Native-skipped interior/roof/facade traversal views are empty here.
use super::*;

pub(super) fn layout(
    geometry: &SurfaceGeometryInputState,
    owners: &SelectedZoneInputOwners,
) -> Result<Option<InsideConvectionLayout>, Error> {
    let zones = owners.zones.as_deref()
        .ok_or(Error::Unavailable("actual cold external Zones"))?;
    let surfaces = geometry.final_surfaces.as_deref()
        .ok_or(Error::Unavailable("actual cold external physical Surface rows"))?;
    if owners.spaces.as_deref().is_some_and(|rows| !rows.is_empty())
        || zones.iter().any(|zone| !zone.space_indexes.is_empty())
        || surfaces.iter().any(|surface| surface.row.heat_transfer_surface)
    {
        return Ok(None);
    }
    let ids = zones.iter().map(|zone| zone.typed_zone_id
        .ok_or(Error::Unavailable("actual cold external Zone identity")))
        .collect::<Result<Vec<_>, _>>()?;
    // These are association/traversal views, not physical owner allocations.
    InsideConvectionLayout::new(ids, Vec::new(), Vec::new(), Vec::new())
        .map(Some)
        .map_err(|_| Error::Unavailable("actual cold external identity closure"))
}

impl SourceInsideConvection {
    pub(super) fn prepare_cold_external_convection(
        &mut self,
        geometry: &mut SurfaceGeometryInputState,
        owners: &SelectedZoneInputOwners,
        input: &SelectedInputProcessor,
        reports: &ReportInputs,
        scan: &mut ReportScanState,
        backend: &mut SourceErrorBackend<'_>,
    ) -> Result<bool, Error> {
        let Some(layout) = layout(geometry, owners)? else { return Ok(false); };
        if self.state.layout != layout || !self.state.surfaces.is_empty() {
            return Err(Error::Unavailable("same actual cold external control owner"));
        }
        // Real six input families and the two repeated passes are queried;
        // each genuine zero-length array writer remains in its original order.
        let actual = self.get_source_user_input(input)?;
        self.actual_no_user_input = Some(actual);
        let zones = static_zone_views(owners)?;
        // Native still sums the actual Zone.Volume and multipliers. In the
        // constructor domain AutoCalculate remains -99999, never invented 0.
        // Actual empty spaceIndexes skip every interior metadata write; each
        // physical HeatTransSurf=false skips roof/facade reads of vertices.
        initialize_user_convection_metadata(
            &layout, &zones, &[], &mut self.state, geometry, reports, scan, backend,
        ).map_err(translate)?;
        Ok(true)
    }
}
'''.encode()
 for cp,data in outputs.items():
  bp=O/'before'/cp;pp=O/'proposed'/cp;pp.parent.mkdir(parents=True,exist_ok=True);pp.write_bytes(data)
  before=initial.get(cp,b'');br=None
  if cp in initial:bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before);br=ref(bp)
  dp=O/'diffs'/cp;dp.parent.mkdir(parents=True,exist_ok=True)
  p=subprocess.run(['rustfmt','--edition','2021','--emit','stdout'],input=data,capture_output=True)
  out=O/'syntax'/cp;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.stdout);assert p.returncode==0,p.stderr
  files.append(dict(canonical_path=cp,before=br,before_absent=br is None,proposed=ref(pp),forward_diff=diff(Path(str(dp)+'.forward.diff'),before,data),inverse_diff=diff(Path(str(dp)+'.inverse.diff'),data,before),Source_only_parse=dict(exit_code=p.returncode,stdout=ref(out),qualification='stdin parse only; no child resolution or typecheck')))
 # Raw slices and pinned whole files, no inferred Internet authority.
 authorities=[]
 for path,extents in [
  ('src/EnergyPlus/ConvectionCoefficients.cc',[(393,443),(733,797),(1635,1673),(2800,3102)]),
  ('src/EnergyPlus/DataHeatBalance.hh',[(434,456)]),
  ('src/EnergyPlus/SurfaceGeometry.cc',[(15576,15848)]),
 ]:
  p=R/'.reference/energyplus-src/26.1.0'/path;b=p.read_bytes()
  git=subprocess.run(['git','-C',str(R/'.reference/energyplus-src/26.1.0'),'show','6f2e40d10250a105b49966baa24d843711e61048:'+path],capture_output=True,check=True).stdout;assert b==git
  rows=[]
  for first,last in extents:
   ex=O/(path.replace('/','__')+f'.{first}-{last}.txt');ex.write_bytes(b''.join(b.splitlines(True)[first-1:last]));rows.append(dict(first=first,last=last,source=ref(ex)))
  authorities.append(dict(Native_path=path,whole=ref(p),extents=rows))
 contexts=[]
 for cp in ['crates/ep_runtime/src/heat_balance/inside_convection_layout.rs','crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/geometry.rs','crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source/exterior.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs','crates/ep_runtime/src/heat_balance/ordinary_source_session/first_input.rs']:
  contexts.append(dict(canonical_path=cp,whole=ref(R/cp)))
 draft=save(O/'draft.json',dict(schema='src06-cold-owner-aware-InitExt-production-draft.v1',status='FROZEN_PRIVATE_SOURCE_ONLY_WAIT_INDEPENDENT_FULL_PEER',files=files,Sources=3,existing=2,new=1,literal_applications=6,Source_only_parses=3,
  Native_commit='6f2e40d10250a105b49966baa24d843711e61048',Native_authorities=authorities,concrete_same_owner_contexts=contexts,
  actual_domain='Real same-owner Zone scalars, empty actual Zone.spaceIndexes, unallocated/empty actual Spaces, and every actual physical Surface.HeatTransSurf=false. No physical count, Surface, Space, vertex or ready flag is invented.',
  Native_reused_writers=['Existing real input-count/zero-length user-array path.','Shared setup_static actual Zone-volume sum/pow, genuine roof/facade kernels over Native-skipped traversal rows, real report scan, original latch writer.'],
  ordinary_positive_HT_path='Existing full geometry/source_layout/static validation remains unchanged except exact Zone-view extraction and Native hydraulic-diameter else-if. Current admitted floorArea>0 guarantees the same numeric branch.',
  unassigned_local='One hydraulic-diameter Option persists across all Zones in this setup call, exactly as the one Native local declaration. Both false assignment predicates retain previous value; first-use None is typed unavailable rather than fabricated 0. Cold actual empty groups never read it.',
  scientific_scope_limits=['No new inside-coefficient or full cold InitInt caller support is claimed.','No numerical equivalence, compiler or execution claim. Native negative constructor-volume pow remains a real computation, not a seeded 0 or claimed observed output.','No physical geometry association or metadata owner is duplicated; empty association views cover exactly Native skipped rows.'],
  new_test_functions_or_targets=0,Source_Native_Cargo_engine_or_canonical_execution=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(draft=draft)))
if __name__=='__main__':main()

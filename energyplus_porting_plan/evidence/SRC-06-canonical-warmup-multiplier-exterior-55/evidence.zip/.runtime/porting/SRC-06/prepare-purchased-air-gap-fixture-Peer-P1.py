"""Private lossless unit fixture wrapper; refuses anything except accepted actual P1."""
from pathlib import Path
import argparse,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'source-purchased-air-runtime-fixture-Peer-P1-01'
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
    p=(R/v['path']).resolve();need(ref(p)==v,'Reference changed '+v['path']);return p
def read(p):return json.loads(p.read_bytes())
def save(p,v):
    p.write_text(json.dumps(v,ensure_ascii=True,separators=(',',':'))+'\n',encoding='utf-8',newline='\n');return ref(p)
def main(a):
    name,sha=a.native_run.rsplit('#',1);rp=(R/name).resolve();actual_ref=ref(rp);need(actual_ref['sha256']==sha,'Actual run hash')
    actual=read(rp)
    need(actual['accepted'] and not actual['findings'] and actual['exit_code']==0 and actual['selected_group']=='purchased_air','Actual successful selected P1 run required')
    need(actual['Native_bytes_match_before_and_after'] and actual['actual_three_GNU_DLL_binding_proved_before_any_science_call'],'Actual Native bytes and pre-science modules')
    build=read(checked(actual['actual_build']));need(build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after'],'Actual original-core build required')
    manifest=read(checked(actual['reviewed_manifest']));named_ref=manifest['named_inputs'];output_ref=actual['full_unit_output']
    named=read(checked(named_ref));output=read(checked(output_ref))
    need(output['schema']=='src06-original-core-gap-batch-output.v1' and output['normal_completion'] is True and output['group_order']==['purchased_air'] and set(output['groups'])=={'purchased_air'},'Entire selected complete group')
    need(actual['admission']['PurchasedAir_full_function_calls']==60 and actual['admission']['purchased_air_factories']==4,'All60 calls admitted')
    scaffold_path=D/'source-purchased-air-gap-scaffold-Peer-01/draft.json';scaffold=read(scaffold_path)
    input_path=D/'source-purchased-air-gap-scaffold-Peer-01/input-only.json';ingress=read(input_path)
    need([x['name'] for x in ingress['factories']]==[x['name'] for x in named['purchased_air']['factories']],'Source raw getter factory association')
    for source,primary in zip(ingress['factories'],named['purchased_air']['factories'],strict=True):
        need(source['steps']==primary['steps'],'All fifteen named primary input operations unchanged')
    need(not O.exists(),'Fresh private fixture directory required');O.mkdir()
    wrapper=dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output)
    wr=save(O/'fixture.json',wrapper);roundtrip=read(checked(wr));need(roundtrip['named_inputs']==named and roundtrip['native_output']==output,'Lossless whole input/output inverse')
    proof=dict(schema='src06-P1-lossless-runtime-fixture-provenance.v1',accepted=True,findings=[],actual_Native_group_run=actual_ref,
        exact_Native_named_inputs=named_ref,exact_Native_output=output_ref,fixture=wr,P1_Source_scaffold=ref(scaffold_path),
        authentic_Source_raw_ingress=ref(input_path),Source_ingress_transport_proof=scaffold['input_transport'],
        actual_original_core_build=actual['actual_build'],actual_reviewed_manifest=actual['reviewed_manifest'],
        all_four_factories_and_sixty_primary_input_steps_exact=True,whole_named_input_JSON_inverse=True,whole_Native_output_JSON_inverse=True,
        transformations='Only lossless JSON container/serialization; all Native member values, raw f64 strings, addresses, order, shapes and output fields retained. No formulas, selected output projection, computed input injection or sampling.',
        Source_numerical_execution=False,Root_only_Cargo=True,author_Source=ref(Path(__file__)))
    pr=save(O/'projection.json',proof);print(json.dumps(dict(fixture=wr,projection=pr)))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--native-run',required=True);main(p.parse_args())

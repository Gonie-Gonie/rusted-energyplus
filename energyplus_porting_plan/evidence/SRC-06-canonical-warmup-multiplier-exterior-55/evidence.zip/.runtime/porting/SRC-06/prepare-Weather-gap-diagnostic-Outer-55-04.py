"""One cfg-only diagnostic successor; no production or science invocation."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];A=R/'.runtime/porting/SRC-06';O=A/'source-Weather-gap-diagnostic-Outer-55-04'
def ref(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def save(p,v):return write(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
assert not O.exists();O.mkdir()
prior=A/'source-two-cfg-observer-path-corrections-Peer-55-03-02/complete-proposed-compiler-Source-plan.json';plan=json.loads(prior.read_bytes())
failure=A/'canonical-source-gap-batch-exterior-Root-55-03/receipt.json';failed=json.loads(failure.read_bytes())
assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after']
snapshot=json.loads((R/failed['source_snapshot']['path']).read_bytes());arch={r['historical_path']:r for r in snapshot['files']}
assert len(arch)==4554==len(plan['entries'])
for row in plan['entries']:
    live=ref(R/row['path']);s=arch[row['path']]
    assert live['sha256']==row['final_sha256']==s['archive']['sha256'] and live['bytes']==row['final_bytes']==s['size_bytes']
    assert ref(R/s['archive']['path'])['sha256']==live['sha256']
name='crates/ep_runtime/src/weather_day/native_gap_cohort.rs';before=(R/name).read_bytes();text=before.decode()
replacements=[
('return Err(format!("{label}: actual Source/Native bits differ").into());',
 '''return Err(format!(
            "{label}: actual Source/Native bits differ: Source={:016x} Native={}",
            v.to_bits(), e["value_bits"].as_str().unwrap_or("<missing>")
        ).into());'''),
('fn values(v: &[f64], e: &Value, label: &str) -> Result<()> {',
'''fn contextual<T>(result: Result<T>, case: &Value, time: Option<&Value>, phase: &str) -> Result<T> {
    result.map_err(|error| {
        format!(
            "Weather3 case={} phase={phase} time_bits={}: {error}",
            case["name"].as_str().unwrap_or("<missing>"),
            time.and_then(|v| v["value_bits"].as_str()).unwrap_or("<none>")
        ).into()
    })
}
fn values(v: &[f64], e: &Value, label: &str) -> Result<()> {'''),
('                bits(value, &oracle["daily"][key], key)?;',
 '                contextual(bits(value, &oracle["daily"][key], key), case, None, "daily-return")?;'),
('            state(&owner, &oracle["initial"], native_owner, source_owner)?;',
 '            contextual(state(&owner, &oracle["initial"], native_owner, source_owner), case, None, "initial")?;'),
('''                values(
                    &direction,
                    &expected["direction"],
                    "CalculateSunDirectionCosines",
                )?;''',
 '''                contextual(values(
                    &direction,
                    &expected["direction"],
                    "CalculateSunDirectionCosines",
                ), case, Some(time), "CalculateSunDirectionCosines-return")?;'''),
('                state(&owner, &expected["before"], native_owner, source_owner)?;',
 '                contextual(state(&owner, &expected["before"], native_owner, source_owner), case, Some(time), "before-DetermineSunUpDown")?;'),
('                state(&owner, &expected["after"], native_owner, source_owner)?;',
 '                contextual(state(&owner, &expected["after"], native_owner, source_owner), case, Some(time), "after-DetermineSunUpDown")?;')]
for old,new in replacements:assert text.count(old)==1;text=text.replace(old,new)
parsed=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=text.encode(),capture_output=True,cwd=R)
assert parsed.returncode==0
after=parsed.stdout;bref=write(O/'before'/name,before);aref=write(O/'proposed'/name,after)
fwd=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)).encode()
inv=''.join(difflib.unified_diff(after.decode().splitlines(True),before.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)).encode()
row=dict(canonical_path=name,before_absent=False,before=bref,proposed=aref,forward_diff=write(O/'weather.forward.diff',fwd),inverse_diff=write(O/'weather.inverse.diff',inv),
 Source_only_parse=dict(exit_code=0,stdout=write(O/'parse/stdout.rs',after),stderr=write(O/'parse/stderr.txt',parsed.stderr),syntax_only=True))
entries=copy.deepcopy(plan['entries'])
for e in entries:
    if e['path']==name:e.update(final_sha256=aref['sha256'],final_bytes=aref['bytes'],source=aref)
newplan=dict(schema='src06-one-cfg-diagnostic-compiler-plan-55-04.v1',base_HEAD=plan['base_HEAD'],prior_complete_compiler_Source_plan=ref(prior),
 compiler_inputs=4554,inputs=4554,Rust_sources=4541,exactly_one_row_changed=name,other4553_rows_whole_equal=True,entries=entries,
 qualification='Only cfg mismatch strings/context change; all production methods, primary fixture bytes, scientific calls/order/state writes and comparisons unchanged. Prior55 stages remain linked historical evidence, not current stage claims.')
pr=save(O/'complete-proposed-compiler-Source-plan.json',newplan)
manifest=dict(schema='src06-Weather3-cfg-mismatch-diagnostic-55-04.v1',status='FROZEN_ROOT_INDEPENDENT_REVIEW_PENDING',base_HEAD=plan['base_HEAD'],files=[row],
 prior_complete_compiler_Source_plan=ref(prior),complete_proposed_compiler_Source_plan=pr,actual_failed_Exterior_receipt=ref(failure),
 failed_stdout=failed['stdout'],failed_stderr=failed['stderr'],actual_failed_Source_snapshot=failed['source_snapshot'],
 all4554_actual_failed_snapshot_archives_and_live_exact=True,
 actual_reached_failure='SolarAltitudeAngle actual Source/Native bits differ, specific case/time unknown from old message.',
 change='Errors now include actual Source and Native rawhex plus case/time/checkpoint context. No scientific expression/state write/call order or expected value change.',
 unchanged_fixture=ref(A/'source-Exterior-runtime-fixture-Outer-01/fixture.json'),
 canonical_or_Cargo_Source_Native_or_test_invocations=0,author_Source=ref(Path(__file__)))
print(json.dumps(dict(draft=save(O/'draft.json',manifest),plan=pr),indent=2))

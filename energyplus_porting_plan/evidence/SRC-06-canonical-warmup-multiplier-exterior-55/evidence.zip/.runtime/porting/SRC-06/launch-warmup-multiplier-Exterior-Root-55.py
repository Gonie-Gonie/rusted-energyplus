"""Root-only selected warmup, multiplier, Exterior commands on one frozen snapshot."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
s=importlib.util.spec_from_file_location('guard55',D/'gap-warmup-multiplier-Exterior-guards-Peer-55.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
def main(a):
 ar=g.argument(a.application);app=g.read(g.checked(ar));g.need(g.checked(ar)==(h.APP/'receipt.json').resolve()and app['accepted']and not app['findings'],'Exact accepted application55')
 _,p,d=h.prepared(app['prepared']['path']+'#'+app['prepared']['sha256']);g.need(g.checked(p['launch_Source'])==Path(__file__).resolve(),'Exact launcher Source');h.current_head(app['base_HEAD'])
 rows={e['path']:e for e in g.read(g.checked(app['complete_compiler_plan']))['entries']};g.exact(rows)
 fixture_map,protected=h.fixtures(p);g.need(fixture_map==app['fixtures']and protected==app['protected_all_seven_external_fixtures'],'Exact seven fixture bindings')
 at=h.GROUPS.index(a.group)
 if at:
  prior=g.read(D/('canonical-source-gap-batch-'+h.GROUPS[at-1]+'-Root-55/receipt.json'))
  g.need(prior['source_bytes_match_before_and_after']and prior['launch_error']is None,'Prior selected attempt completed with stable Source')
  log=R/prior['stderr']['path'];g.need(g.ref(log)['sha256']==prior['stderr']['sha256']and 'Running src\\lib.rs ('in log.read_text(encoding='utf-8'),'Prior contextual compilation completed before binary reuse')
 es=importlib.util.spec_from_file_location('fixed_env55',g.checked(p['environment_guard']));em=importlib.util.module_from_spec(es);es.loader.exec_module(em);env=em.environment();g.need(env['CARGO_INCREMENTAL']=='0','Incremental disabled')
 fixture=fixture_map[a.group];command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',a.group,str(g.checked(fixture))]
 output=D/('canonical-source-gap-batch-'+a.group+'-Root-55');guard=D/('Root-runtime-fixture-'+a.group+'-guard-55');g.need(not output.exists()and not guard.exists(),'Fresh group command/guard paths');guard.mkdir();before=[g.ref(g.checked(v))for v in protected]
 (guard/'before.json').write_text(json.dumps(dict(application=ar,selected_group=a.group,command=command,protected=before,all_seven_fixtures=fixture_map),indent=2)+'\n',encoding='utf-8',newline='\n')
 print('Root55: only selected '+a.group+'; all completed old scientific groups skipped.',flush=True)
 code=subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',output.relative_to(R).as_posix(),'--',*command],cwd=R,env=env)
 after=[g.ref(g.checked(v))for v in protected];g.exact(rows)
 result=dict(schema='src06-seven-runtime-fixture-custody55.v1',accepted=before==after,findings=[]if before==after else['External fixture changed'],application=ar,selected_group=a.group,command=command,exit_code=code,protected_before=before,protected_after=after,all_seven_fixtures=fixture_map,all4554_compiler_inputs_unchanged=True,actual_receipt=g.ref(output/'receipt.json'),launch_Source=g.ref(Path(__file__)))
 (guard/'after.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');return code if before==after else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);p.add_argument('--group',required=True,choices=h.GROUPS);raise SystemExit(main(p.parse_args()))

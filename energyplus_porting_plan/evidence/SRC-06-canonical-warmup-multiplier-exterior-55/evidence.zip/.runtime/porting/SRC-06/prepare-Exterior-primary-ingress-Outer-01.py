"""Input-only projection of selected original unit IDFs for real Source getters.
This transports primary tokens/schema; it never reads Native scientific output.
No engine/compiler/Cargo or canonical mutation.
"""
from pathlib import Path
import hashlib,json,math,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Exterior-primary-ingress-draft-Outer-01'
N=R/'.reference/energyplus-src/26.1.0';NC='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):p=R/v['path'];assert ref(p)==v;return p
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode());return ref(p)
def parse_idf(p,schemas):
 text=p.read_bytes().decode('utf-8-sig');text=re.sub(r'![^\r\n]*','',text)
 assert '"' not in text and "'" not in text,'selected input scope has no quoted field syntax'
 tokens=[];buf=[];objects=[]
 for c in text:
  if c not in ',;':buf.append(c);continue
  tokens.append(''.join(buf).strip());buf=[]
  if c==';':objects.append(tokens);tokens=[]
 assert not ''.join(buf).strip() and not tokens,'closed semicolon input only'
 canonical={k.upper():k for k in schemas};raw={};order={};ledger=[]
 for ordinal,obj in enumerate(objects,1):
  family=canonical[obj[0].upper()];v=schemas[family];idd=v['legacy_idd'];fields=idd['fields'];extensions=idd.get('extensibles',[]);extension=idd.get('extension')
  values=obj[1:];row={'idf_order':ordinal,'idf_max_fields':max(len(values),int(v.get('min_fields',0))),'idf_max_extensible_fields':max(0,len(values)-len(fields))}
  props=next(iter(v['patternProperties'].values()))['properties'];exprops=props.get(extension,{}).get('items',{}).get('properties',{}) if extension else {}
  ext=[];extrow={};operands=[]
  for i,token in enumerate(values):
   if i<len(fields):key=fields[i];loc=v.get('name',{}) if key=='name' else props[key];target=row
   else:
    assert extensions and extension,(family,'unexpected extensible input')
    at=i-len(fields);key=extensions[at%len(extensions)];loc=exprops[key];target=extrow
   value=None
   if token:
    kind=loc.get('type')
    numeric=kind in ('integer','number') or (kind is None and re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?',token) is not None)
    if numeric:
     try:value=float(token)
     except ValueError:value=token
     if isinstance(value,float):
      assert math.isfinite(value)
      if kind=='integer':assert value.is_integer(),'no rounding-required primary input in this finite transport';value=int(value)
    else:
     value=token
     if 'enum' in loc:
      value=next((x for x in loc['enum'] if str(x).upper()==token.upper()),token)
     elif token.upper() in ('AUTOSIZE','AUTOCALCULATE'):
      enums=[x for x in loc.get('anyOf',[]) if 'enum'in x]
      assert len(enums)==1,(family,key,'automatic primary schema')
      value=next(x for x in enums[0]['enum'] if str(x).upper()==token.upper())
    target[key]=value
   operands.append({'physical_field':i+1,'schema_field':key,'raw_token':token,'parsed_value':value,'blank_omitted':not bool(token)})
   if i>=len(fields) and (i-len(fields)+1)%len(extensions)==0:ext.append(extrow);extrow={}
  if extrow:ext.append(extrow)
  if ext:row[extension]=ext
  name=row.pop('name', '' if 'name'in v else f'{family} {len(raw.get(family,{}))+1}')
  assert name not in raw.get(family,{})
  raw.setdefault(family,{})[name]=row;order.setdefault(family,[]).append(name)
  ledger.append({'family':family,'object_name':name,'idf_order':ordinal,'physical_fields':len(values),'semicolon_min_fields':int(v.get('min_fields',0)),'consumed_field_operands':operands})
 return {'raw':raw,'object_order':order},ledger
def main():
 assert not O.exists();O.mkdir();sp=R/'.runtime/energyplus/26.1.0/Energy+.schema.epJSON';schemas=json.loads(sp.read_bytes())['properties']
 base=json.loads((D/'ordinary-source-B-raw-ingress-held-Audit-01/schema-authority.json').read_bytes());assert ref(sp)==base['installed_full_schema']
 selected=json.loads((D/'P4-history-Exterior-Native-driver-draft-Peer-03/named-inputs.json').read_bytes())['exterior'];files={}
 for key in ['internal_gains','beam_producer','surface_internal_gains']:
  for case in selected[key]:files[case['name']]=case['input_authority']
 definitions=[]
 for family,v in sorted(schemas.items()):
  if 'legacy_idd'not in v:continue
  idd=v['legacy_idd'];definitions.append([family,len(idd['alphas']['fields']),len(idd['numerics']['fields']),len(idd['alphas'].get('extensions',[])),len(idd['numerics'].get('extensions',[])),idd.get('extension')])
 projected={};ledgers=[]
 for name,authority in files.items():
  p=checked(authority);factory,operands=parse_idf(p,schemas);projected[name]={'actual_primary_IDF':authority,**factory};ledgers.append({'case_name':name,'actual_primary_IDF':authority,'objects':operands})
 payload={'schema':'src06-Exterior-primary-Source-ingress.v1','definitions':definitions,'factories':projected}
 # All inputs are selected primary IDFs and schema. No Native output file,
 # emitted coefficients, reports or expected JSON is ever opened here.
 proof={'schema':'src06-Exterior-primary-ingress-derivation.v1','status':'FROZEN_INPUT_ONLY_WAIT_INDEPENDENT_PARSER_READSET_AND_SOURCE_FACTORY_PEER',
 'installed_schema':ref(sp),'schema_producer_bridge':ref(D/'ordinary-source-B-raw-ingress-held-Audit-01/schema-authority.json'),
 'selected_named_inputs':ref(D/'P4-history-Exterior-Native-driver-draft-Peer-03/named-inputs.json'),
 'input_only_payload':save(O/'source-ingress.json',payload),'primary_operand_ledger':save(O/'primary-operands.json',ledgers),
 'Source_loader_pattern':ref(R/'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs'),
 'scope':['Retains actual schema-normalized enum spelling, object identity/declaration order, explicit fields, omitted blanks, raw numeric primary values, extension order and original semicolon/min-field metadata.',
 'No inserted field defaults, no typed model outputs, no area/view-factor/shadow/gain result inputs and no scientific output reading.',
 'Finite selected IDFs contain no quote syntax or integer-rounding-required operands; this is not a new generic production parser or an assertion that Native converter execution was performed.'],
 'definitions':len(definitions),'factories':len(projected),'Cargo_Native_engine_or_canonical_execution':False,'author_Source':ref(Path(__file__))}
 authorities=[]
 for cp,spans in [('src/EnergyPlus/InputProcessing/IdfParser.cc',[(223,309),(309,463),(463,556),(612,677)]),('src/EnergyPlus/InputProcessing/IdfParser.hh',[(66,155)])]:
  p=N/cp;b=p.read_bytes();git=subprocess.run(['git','-C',str(N),'show',f'{NC}:{cp}'],capture_output=True,check=True).stdout;assert git==b
  q=O/'Native-wholes'/cp;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);lines=b.splitlines(keepends=True);ext=[]
  for first,last in spans:
   e=O/f'{p.name}.{first}-{last}.txt';e.write_bytes(b''.join(lines[first-1:last]));ext.append({'first':first,'last':last,'source':ref(e)})
  authorities.append({'canonical_path':cp,'whole':ref(q),'pinned_Git_whole_exact':True,'extents':ext})
 proof['Native_commit']=NC;proof['Native_authorities']=authorities;print(json.dumps({'draft':save(O/'draft.json',proof),'factories':list(projected)}))
if __name__=='__main__':main()

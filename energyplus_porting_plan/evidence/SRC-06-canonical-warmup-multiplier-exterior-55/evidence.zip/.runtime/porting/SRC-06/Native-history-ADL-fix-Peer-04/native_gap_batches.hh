// Private original-core unit batch ABI. No scientific initialization here.
#pragma once
#include <nlohmann/json_fwd.hpp>
#include <string>

namespace NativeGapBatch {
nlohmann::json run_output_processor_batch(nlohmann::json const &named_inputs);
nlohmann::json run_air_history_batch(nlohmann::json const &named_inputs);
nlohmann::json run_exterior_batch(nlohmann::json const &named_inputs, std::string const &checkpoint_path);
} // namespace NativeGapBatch

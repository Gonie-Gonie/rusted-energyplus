// Private driver only. All science lives in the original core, called by group TUs.
#include "native_gap_batches.hh"
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

int main(int argc, char **argv)
{
    try {
        if (argc != 3 && argc != 5) throw std::runtime_error("expected input-json output-json [--group output_processor|air_history|exterior]");
        std::string selected;
        if (argc == 5) {
            if (std::string(argv[3]) != "--group") throw std::runtime_error("expected --group selector");
            selected = argv[4];
            if (selected != "output_processor" && selected != "air_history" && selected != "exterior") {
                throw std::runtime_error("unsupported whole-group selector");
            }
        }
        std::ifstream in(argv[1]);
        if (!in) throw std::runtime_error("input-json open failed");
        nlohmann::json input;
        in >> input;
        if (input.at("schema") != "src06-original-core-gap-batch-input.v1") {
            throw std::runtime_error("input schema mismatch");
        }
        if (!selected.empty() && !input.contains(selected)) throw std::runtime_error("selected whole group absent from primary inputs");
        // Parent approves this exact PID's three actual GNU runtime modules first.
        // No EnergyPlusData, Sizer or Psy call exists above this gate.
        std::cout << "NATIVE_GAP_BATCH_READY\n" << std::flush;
        char gate = 0;
        if (!std::cin.get(gate) || gate != 'g') throw std::runtime_error("parent did not approve module gate");
        nlohmann::json result{{"schema", "src06-original-core-gap-batch-output.v1"},
                              {"groups", nlohmann::json::object()},
                              {"group_order", nlohmann::json::array()}};
        // Passive completed-group recovery: a later original-core abort must not erase
        // an earlier group's genuine observations. This file never claims completion.
        result["normal_completion"] = false;
        auto checkpoint_completed_groups = [&](char const *completed_group) {
            std::ofstream checkpoint(std::string(argv[2]) + ".checkpoint.json", std::ios::binary | std::ios::trunc);
            if (!checkpoint) throw std::runtime_error("checkpoint-json open failed");
            checkpoint << result.dump(2) << '\n';
            checkpoint.flush();
            if (!checkpoint) throw std::runtime_error("checkpoint-json write failed");
            // This separate document claims completion of ONLY the returned group.
            nlohmann::json completed{{"schema", "src06-original-core-gap-completed-group.v1"},
                                     {"group", completed_group},
                                     {"native_group", result.at("groups").at(completed_group)},
                                     {"normal_completion", true}};
            std::ofstream group_out(std::string(argv[2]) + "." + completed_group + ".json", std::ios::binary | std::ios::trunc);
            if (!group_out) throw std::runtime_error("completed-group-json open failed");
            group_out << completed.dump(2) << '\n';
            group_out.flush();
            if (!group_out) throw std::runtime_error("completed-group-json write failed");
        };
        if (input.contains("output_processor") && (selected.empty() || selected == "output_processor")) {
            result["groups"]["output_processor"] = NativeGapBatch::run_output_processor_batch(input.at("output_processor"));
            result["group_order"].push_back("output_processor");
            checkpoint_completed_groups("output_processor");
        }
        if (input.contains("air_history") && (selected.empty() || selected == "air_history")) {
            result["groups"]["air_history"] = NativeGapBatch::run_air_history_batch(input.at("air_history"));
            result["group_order"].push_back("air_history");
            checkpoint_completed_groups("air_history");
        }
        if (input.contains("exterior") && (selected.empty() || selected == "exterior")) {
            result["groups"]["exterior"] = NativeGapBatch::run_exterior_batch(input.at("exterior"), std::string(argv[2]) + ".exterior-progress.json");
            result["group_order"].push_back("exterior");
            checkpoint_completed_groups("exterior");
        }
        if (result["group_order"].empty()) throw std::runtime_error("no scientific group selected");
        result["normal_completion"] = true;
        std::ofstream out(argv[2], std::ios::binary);
        if (!out) throw std::runtime_error("output-json open failed");
        out << result.dump(2) << '\n';
        out.flush();
        if (!out) throw std::runtime_error("output-json write failed");
        return 0;
    } catch (std::exception const &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}

"""Metadata-only corrected derivative-plan counters; immutable Source/diffs carried."""
from pathlib import Path
import copy,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2)+'\n').encode());return ref(p)
def main():
 results=[]
 for stem,n in [('source-multiplier-live-output-observer-Peer-55-03',1),('source-two-cfg-observer-path-corrections-Peer-55-03',2)]:
  olddir=D/stem;out=D/(stem+'-02');assert not out.exists();oldref=ref(olddir/'draft.json');v=json.loads((olddir/'draft.json').read_bytes());pr=v['complete_proposed_compiler_Source_plan'];p=R/pr['path'];plan=json.loads(p.read_bytes());assert ref(p)==pr
  del plan['exactly_three_rows_changed'];del plan['other4551_Source_and_metadata_rows_whole_equal'];plan['exactly_changed_plan_rows']=n;plan['unchanged_plan_rows']=4554-n
  plan['qualification']='Initial compile101, passed warmup69 on55-02, and two pre-comparison runtime setup/observer failures are preserved. Only cfg observer/output-domain and fixture-path changes are proposed; no new successful retry or numerical result is implied by syntax parsing.'
  newplan=save(out/'complete-proposed-compiler-Source-plan.json',plan);v['complete_proposed_compiler_Source_plan']=newplan;v['metadata_only_predecessor']=oldref;v['metadata_correction']='Replace stale inherited three-row/no-science qualification with actual derivative row counts and preserved completed/failed runtime history; all Source/diff/parse refs are unchanged.'
  if n==2:
   leaf=json.loads((D/'source-multiplier-live-output-observer-Peer-55-03-02/draft.json').read_bytes());v['correction_leaf_drafts'][0]=ref(D/'source-multiplier-live-output-observer-Peer-55-03-02/draft.json');assert leaf['files'][0]==v['files'][0]
  v['author_Source']=ref(Path(__file__));dr=save(out/'draft.json',v)
  a=json.loads((olddir/'draft.json').read_bytes());assert v['files']==a['files'];before=json.loads(p.read_bytes());assert plan['entries']==before['entries'];results.append(dict(draft=dr,plan=newplan))
 print(json.dumps(results))
if __name__=='__main__':main()

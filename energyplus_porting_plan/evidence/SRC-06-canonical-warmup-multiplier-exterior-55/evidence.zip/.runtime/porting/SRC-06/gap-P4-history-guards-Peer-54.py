"""Read-only exact Source54 authorities and four external fixture custody guards."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
BASE=D/'apply-Source-gap-batch-Root-50.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='03f08ddbc7f1ccfcaafeec69f9105cf0de23d3da453f01fa0149f9d8c385fb2e'
s=importlib.util.spec_from_file_location('Source50_shared_exact_guards54',BASE);base=importlib.util.module_from_spec(s);s.loader.exec_module(base);g=base.g
APP=D/'Root-Propane-P4-history-application-54'
def accepted_peer(peer_ref,draft_ref):
 p=g.read(g.checked(peer_ref));g.need(p['accepted'] and not p['findings'] and p.get('reviewed_packet',p.get('reviewed_draft'))==draft_ref,'Exact accepted independent peer');return p
def prepared(spec):
 rr=g.argument(spec);p=g.read(g.checked(rr));g.need(p['status']=='READY_FOR_ROOT_ONE_APPLICATION_TWO_SELECTED_GROUPS','Prepared54 still WAIT')
 draft=g.read(g.checked(p['draft']));g.need(p['base_HEAD']==draft['base_HEAD'],'Prepared parent/draft HEAD')
 accepted_peer(p['joint_independent_peer'],p['draft']);accepted_peer(p['history_independent_peer'],draft['history_scaffold'])
 union=g.read(g.checked(draft['accepted_Propane_P4_union']));accepted_peer(draft['independent_Propane_P4_union_peer'],draft['accepted_Propane_P4_union'])
 accepted_peer(draft['original_production_peer'],union['original_production_draft']);accepted_peer(p['original_P4_Source_peer'],union['original_P4_scaffold'])
 g.need(p['complete_compiler_plan']==draft['complete_proposed_compiler_Source_plan'] and p['prior_compiler_plan']==draft['prior_complete_compiler_Source_plan'],'Prepared full compiler plans')
 g.checked(p['guard_Source']);g.checked(p['application_Source']);g.checked(p['launch_Source']);g.checked(p['environment_guard']);g.checked(p['record_command_Source'])
 for dependency in p['inherited_guard_dependencies']:g.checked(dependency)
 g.need(p['environment_guard']['sha256']=='fc76790e89122784da36a9687c22079a2aefe67cdf498b0d55e32ac9d52b598e' and p['record_command_Source']['sha256']=='18168e36c2c759d55811d1c19695a4c0f7c0e5bba67b1e13f5e499d54d8780c8','Frozen environment/recorder policies')
 g.need(g.checked(p['guard_Source'])==Path(__file__).resolve(),'Exact selected guard helper')
 return rr,p,draft,union
def new_fixture(proof_ref,group,source_ref):
 proof=g.read(g.checked(proof_ref));g.need(proof['accepted'] and not proof['findings'],'Accepted genuine whole fixture proof')
 run=g.read(g.checked(proof['actual_Native_group_run']));g.need(run['accepted'] and not run['findings'] and run['exit_code']==0 and run['selected_group']==group,'Accepted actual Native '+group)
 g.need(run['Native_bytes_match_before_and_after'] and run['actual_three_GNU_DLL_binding_proved_before_any_science_call'],'Genuine Native modules/custody '+group)
 g.need(run['full_unit_output']==proof['exact_Native_output'],'Actual Native output ref '+group)
 build=g.read(g.checked(run['actual_build']));ready=g.read(g.checked(run['reviewed_manifest']));g.need(build['accepted'] and not build['findings'] and build['Native_bytes_match_before_and_after'] and ready['named_inputs']==proof['exact_Native_named_inputs'],'Actual Native build/input binding '+group)
 keys=['Source_history_scaffold'] if group=='air_history' else ['P4_Source_scaffold','Source_P4_scaffold','Source_scaffold']
 present=[proof[k]for k in keys if k in proof];g.need(len(present)==1 and present[0]==source_ref,'Exact Source scaffold fixture input bridge '+group)
 wrapper=g.read(g.checked(proof['fixture']));named=g.read(g.checked(proof['exact_Native_named_inputs']));output=g.read(g.checked(proof['exact_Native_output']))
 expected=dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output)
 extra=[]
 if group=='output_processor':
  primary=proof['exact_Source_primary_input_projection'];primary_proof=proof['Source_primary_input_proof'];g.checked(primary_proof)
  scaffold=g.read(g.checked(source_ref));g.need(scaffold['input_only']==primary and scaffold['primary_input_projection_proof']==primary_proof,'Accepted Source-only primary input projection binding')
  expected['source_inputs']=g.read(g.checked(primary));extra=[primary,primary_proof]
  accepted_peer(proof['independent_Source_scaffold_peer'],source_ref)
 g.need(wrapper==expected,'Entire lossless genuine input/output/primary wrapper '+group)
 g.need(output['normal_completion'] is True and output['group_order']==[group] and set(output['groups'])=={group},'One whole completed Native group '+group)
 field='original_update_reset_calls' if group=='output_processor' else 'original_history_method_calls';g.need(run['admission'][field]==(38 if group=='output_processor' else 40),'Exact full Native method counts')
 refs=[proof_ref,proof['fixture'],proof['actual_Native_group_run'],proof['exact_Native_named_inputs'],proof['exact_Native_output'],run['actual_build'],run['reviewed_manifest'],*extra]
 return proof['fixture'],[g.ref(g.checked(v))for v in refs]
def fixtures(p,draft,union):
 original=g.read(g.checked(g.read(D/'Root-gap-batch-P1-Surface-application-50/receipt.json')['draft']));values={};protected=[]
 for group in ['purchased_air','surface']:
  f,refs=base.fixtures(original,group);values[group]=f;protected+=refs
 for group,key,scaffold in [('output_processor','P4_fixture_proof',union['original_P4_scaffold']),('air_history','history_fixture_proof',draft['history_scaffold'])]:
  f,refs=new_fixture(p[key],group,scaffold);values[group]=f;protected+=refs
 return values,list({x['path']:x for x in protected}.values())
def current_head(expected):
 g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==expected,'Actual committed Source parent changed')

"""Current-owner/identity/exact storage schema observer correction only."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-cold-exterior-cohort-draft-Outer-02'
def ref(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
def diff(p,a,b):p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='preserved01',tofile='current-owner02')).encode());return ref(p)
def main():
 assert not O.exists();O.mkdir();prior=D/'source-cold-exterior-cohort-draft-Outer-01/draft.json';old=json.loads(prior.read_bytes());new=copy.deepcopy(old)
 row=next(x for x in new['files'] if x['canonical_path'].endswith('/source/native_gap_cohort.rs'));a=(R/row['proposed']['path']).read_bytes();b=a
 fragments=[]
 def replace(x,y):
  nonlocal b
  x=x.encode();y=y.encode();assert b.count(x)==1,(x,b.count(x));b=b.replace(x,y,1);fragments.append((x,y))
 replace('    fn assert_native_gap_external(&self,model:i32,state:&SourceErrorState,bytes:&[u8],e:&Value)->Result<()> {',
 '''    fn assert_native_gap_external(&self,geometry:&SurfaceGeometryInputState,zones:&SelectedZoneInputOwners,state:&SourceErrorState,bytes:&[u8],e:&Value)->Result<()> {
        let surface_model=geometry.parallel_arrays.as_ref().and_then(|p|p.exterior_convection.first()).ok_or("same actual exterior model owner")?.model;
        let zone=zones.zones.as_ref().and_then(|r|r.first()).ok_or("same actual zone model owner")?;
        let zone_model=match zone.outside_algorithm {Outside::SimpleCombined=>3,Outside::Tarp=>4,Outside::MoWitt=>6,Outside::Doe2=>7,Outside::AdaptiveConvectionAlgorithm=>9};''')
 replace('|| e["actual_surface_model"].as_i64()!=Some(i64::from(model)) || e["actual_zone_model"].as_i64()!=Some(i64::from(model))',
         '|| e["actual_surface_model"].as_i64()!=Some(i64::from(surface_model)) || e["actual_zone_model"].as_i64()!=Some(zone_model)')
 replace('            if !native["lower"].is_null() && (native["lower"].as_i64()!=Some(1)||native["upper"].as_i64()!=Some(v.as_ref().map_or(0,Vec::len) as i64)){return Err("InitExt zero-row bounds differ".into());}',
 '''            if i<2 {
                // True Array1D declarations retain explicit 1..0 bounds even
                // before allocation; EPVector model rows expose no l/u API.
                if native["lower"].as_i64()!=Some(1)||native["upper"].as_i64()!=Some(v.as_ref().map_or(0,Vec::len) as i64){return Err("InitExt Array1D bounds schema differs".into());}
            } else if native.get("lower").is_some()||native.get("upper").is_some(){return Err("InitExt EPVector must have no Objexx bounds fields".into());}''')
 replace('            module.assert_native_gap_external(model,&errors,&bytes,&e["initial"])?;',
 '''            let native_identity=|state:&Value|->Result<(u64,u64)> {
                Ok((state["state_address"].as_u64().filter(|v|*v>0).ok_or("actual Native nonnull state identity")?,
                    state["surface_address"].as_u64().filter(|v|*v>0).ok_or("actual Native nonnull Surface identity")?))
            };
            let initial_identity=native_identity(&e["initial"])?;
            let actual_source_surface=geometry.final_surfaces.as_ref().and_then(|r|r.first()).ok_or("actual Source Surface row")? as *const _;
            let actual_source_physical=physical.as_ptr();
            module.assert_native_gap_external(&geometry,&zones,&errors,&bytes,&e["initial"])?;''')
 replace('                module.assert_native_gap_external(model,&errors,&bytes,&call["before"])?;',
 '''                if native_identity(&call["before"])?!=initial_identity||native_identity(&call["after"])?!=initial_identity{return Err("Native retained InitExt state/Surface identity differs".into());}
                module.assert_native_gap_external(&geometry,&zones,&errors,&bytes,&call["before"])?;''')
 replace('                module.assert_native_gap_external(model,&errors,&bytes,&call["after"])?;',
 '''                module.assert_native_gap_external(&geometry,&zones,&errors,&bytes,&call["after"])?;
                if geometry.final_surfaces.as_ref().and_then(|r|r.first()).ok_or("same Source Surface row")? as *const _!=actual_source_surface
                    ||physical.as_ptr()!=actual_source_physical{return Err("Source retained Surface/physical owner identity differs".into());}''')
 inverse=b
 for x,y in reversed(fragments):assert inverse.count(y)==1;inverse=inverse.replace(y,x,1)
 assert inverse==a
 p=O/'native_gap_cohort.rs';p.write_bytes(b);row['proposed']=ref(p);row['diffs']=dict(forward=diff(O/'canonical.forward.diff',b'',b),inverse=diff(O/'canonical.inverse.diff',b,b''))
 parse=subprocess.run(['rustfmt','--edition','2021','--emit','stdout'],input=b,capture_output=True);q=O/'syntax.stdout.rs';q.write_bytes(parse.stdout);assert parse.returncode==0,parse.stderr;row['Source_only_parse']=dict(exit_code=0,stdout=ref(q))
 authorities=[]
 for path,spans in [('src/EnergyPlus/ConvectionCoefficients.hh',[(787,794)]),('src/EnergyPlus/DataSurfaces.hh',[(1820,1827)]),('third_party/ObjexxFCL/src/ObjexxFCL/Array1.hh',[(1050,1072)]),('third_party/ObjexxFCL/src/ObjexxFCL/IndexRange.hh',[(47,58)]),('src/EnergyPlus/EPVector.hh',[(58,105)])]:
  p=R/'.reference/energyplus-src/26.1.0'/path;data=p.read_bytes();git=subprocess.run(['git','-C',str(R/'.reference/energyplus-src/26.1.0'),'show','6f2e40d10250a105b49966baa24d843711e61048:'+path],capture_output=True,check=True).stdout;assert data==git
  extents=[]
  for first,last in spans:q=O/(path.replace('/','__')+f'.{first}-{last}.txt');q.write_bytes(b''.join(data.splitlines(True)[first-1:last]));extents.append(dict(first=first,last=last,source=ref(q)))
  authorities.append(dict(Native_path=path,whole=ref(p),extents=extents))
 new['preserved_01']=ref(prior);new['observer_only_correction']=dict(forward=diff(O/'observer.forward.diff',a,b),inverse=diff(O/'observer.inverse.diff',b,a),exact_whole_inverse=True,notes=['Models are now resolved from actual current geometry/Zone owner fields at every observation, never local expected input.','Two nonnull Native owner identities and Source Surface/physical row identity retained per lifetime.','True Array1D bounds mandatory, EPVector bounds strictly absent based on actual concrete declarations.','Other two Source wholes, all scientific inputs/formulas/calls/order/canaries unchanged.'])
 new['exact_storage_schema_authorities']=authorities;new['author_Source']=ref(Path(__file__));print(json.dumps(dict(draft=save(O/'draft.json',new))))
if __name__=='__main__':main()

"""Historical code-derived ordered progress, never fabricated direct milestones."""
from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Audit-prior-Exterior-prefix-55-05'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def check(v):
 p=R/v['path'];r=ref(p);assert r['sha256']==v['sha256'] and ('bytes' not in v or r['bytes']==v['bytes']);return p
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
packet=D/'source-Constant-Exterior-category-coherent-Peer-55-06/draft.json';draft=json.loads(packet.read_bytes());assert ref(packet)['sha256'].startswith('a371a39b')
receipt_path=check(draft['source05_qualified_progress']['actual_Source05_receipt']);receipt=json.loads(receipt_path.read_bytes())
assert receipt['exit_code']==1 and receipt['launch_error'] is None and receipt['source_bytes_match_before_and_after']
stderr=check(receipt['stderr']);stdout=check(receipt['stdout']);tail=stderr.read_bytes()
assert b'Error: Unavailable("blank or unknown type warning")' in tail
assert stdout.read_text(encoding='utf-8').strip()=='running 1 original-core gap cohort group=exterior on process main'
assert receipt['command'][-3:-1]==['--gap-batch-only','exterior']
snapshot_path=check(receipt['source_snapshot']);snapshot=json.loads(snapshot_path.read_bytes());archives={r['historical_path']:r for r in snapshot['files']}
names=['crates/ep_runtime/src/lib.rs','crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs',
 'crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior.rs','crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress.rs',
 'crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs','crates/ep_runtime/src/weather_day/native_gap_cohort.rs',
 'crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source/native_gap_cohort.rs',
 'crates/ep_runtime/src/heat_balance/inside_convection_dispatcher/source/cold_external.rs',
 'crates/ep_runtime/src/heat_balance/radiation/ordinary/native_gap_cohort/absorption.rs',
 'crates/ep_runtime/src/heat_balance/radiation/ordinary/native_gap_cohort/sky_opaque.rs']
contexts=[];texts={}
for name in names:
 row=archives[name];p=check(row['archive']);assert len(p.read_bytes())==row['size_bytes'];texts[name]=p.read_text(encoding='utf-8');contexts.append(dict(historical_path=name,actual_execution_archive=ref(p)))
ex=texts[names[2]];ing=texts[names[3]];sched=texts[names[4]]
start=ex.index('pub(super) fn run(fixture:');body=ex[start:]
calls=['WeatherDayState::run_native_gap_solar_clock(named, observed)?','SourceInsideConvection::native_gap_external_convection_cases(named, observed)?','OrdinarySolarRadiation::native_gap_absorption_cases(named, observed)?','OrdinarySolarRadiation::native_gap_sky_opaque_cases(named, observed)?','no_surface_gains(ingress, named, observed)?']
positions=[body.index(x) for x in calls];assert positions==sorted(positions)
for count in range(4):assert f'counts[{count}]' in body[positions[count]:positions[count+1]]
for name in names[5:]:assert 'process_schedule_input(' not in texts[name],name
assert sched.count('"blank or unknown type warning"')==1
assert '.ok_or(SelectedScheduleError::Unavailable(\n                    "blank or unknown type warning",' in sched
assert 'let mut owner = GainFactory::new(ingress, name)?;' in ex
assert ex.index('let mut owner = GainFactory::new(ingress, name)?;')<ex.index('owner.assert_gains(member(expected, "before_getter")?)?;')<ex.index('owner.get_input()?;')
assert 'type_name: alpha(raw, "schedule_type_limits_name")?' in ing
assert 'schedules.process_schedule_input(' in ing and ing.index('schedules.process_schedule_input(')<ing.index('zones.get_zone_data(')
actual_path=D/'Root-Weather-UCRT-application-55-05/actual.json';actual=json.loads(actual_path.read_bytes())
assert actual['exit_code']==1 and actual['Source_and_seven_fixtures_stable'] and actual['protected_before']==actual['protected_after']
fixture_path=Path(receipt['command'][-1]);fixture_ref=ref(fixture_path)
assert fixture_ref in actual['protected_before'];fixture=json.loads(fixture_path.read_bytes())
native=fixture['native_output'];assert native['normal_completion'] is True and native['group_order']==['exterior']
named=fixture['named_inputs']['exterior'];observed=native['groups']['exterior'];keys=['solar_clock','exterior_coefficients','absorption','solar_surface']
counts=[sum(len(row['calls']) for row in observed[k]) for k in keys];assert counts==[47,57,18,15]
first=named['internal_gains'][0];factory=fixture['source_ingress']['factories'][first['name']]
constant=factory['raw']['Schedule:Constant'];assert len(constant)==1
row=next(iter(constant.values()));assert 'schedule_type_limits_name' not in row and row['hourly_value']==1.0
unique=subprocess.run(['rg','-n','--fixed-strings','"blank or unknown type warning"','crates/ep_runtime/src'],cwd=R,capture_output=True,check=True).stdout
assert len(unique.splitlines())==1
assert not O.exists();O.mkdir()
review=dict(schema='src06-independent-historical-ordered-prefix-inference.v1',accepted=True,findings=[],reviewed_draft=ref(packet),
 proof_kind='CODE_DERIVED_FROM_AUTHENTICATED_EXECUTED_SNAPSHOT_AND_UNIQUE_ACTUAL_FAILURE_NOT_DIRECT_MILESTONES',
 actual_receipt=ref(receipt_path),actual_Source_snapshot=ref(snapshot_path),actual_guard=ref(actual_path),actual_stdout=ref(stdout),actual_stderr=ref(stderr),
 current_unique_text_census=put(O/'current-unique-failure-census.txt',unique),executed_Source_contexts=contexts,external_fixture=fixture_ref,
 inferred_completed_categories=[dict(category=k,records=n) for k,n in zip(keys,counts)],inferred_completed_records=sum(counts),
 reason='Authenticated historical dispatcher calls the four scalar-only category helpers in exact sequence, propagates every failure with ?, and checks their complete47/57/18/15 counts. Their paths do not process schedules. The next first no-surface GainFactory consumes an actual Constant without type-limits-name and must reach the sole old Schedule manager Unavailable warning before gain getter/observation/call. Exact actual typed failure therefore establishes that all prior category returns/count/assertions completed.',
 qualifications=['Historical stdout contains only starting line; there are no direct category milestones in55-05. Do not invent them.',
 'This is a static control-flow inference attached to the recorded failed actual command/snapshot/fixture and preserved logs; no rerun or new numerical comparison.',
 'Weather101 phase checks are separate from47 call records. No whole170 Source Exterior PASS or later9/18/6 records inferred.',
 'No compiled binary was captured by this command (compiler-artifact request false); do not claim independently hashed executable custody.',
 'First setup failure happens before any no-surface IHG getter or repeated call. Future selected3 runs remain distinct directly observed invocations.',
 'Current clause uniqueness was also searched in the crate; actual producing Source whole is authenticated from execution archive, not inferred from a future corrected tree.'],
 no_canonical_Cargo_engine_or_scientific_execution=True,author_Source=ref(Path(__file__)))
out=put(O/'review.json',(json.dumps(review,indent=2,ensure_ascii=True)+'\n').encode());print(json.dumps(out))

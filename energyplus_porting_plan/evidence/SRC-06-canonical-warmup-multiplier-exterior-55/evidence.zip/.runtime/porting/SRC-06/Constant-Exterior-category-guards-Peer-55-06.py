"""Read-only seven-row application and selected-category command guards."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(path):
 b=path.read_bytes();return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path.resolve()),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def need(condition,message):
 if not condition:raise AssertionError(message)
def checked(v):
 p=R/v['path'];a=ref(p);need(a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']),'Authenticated whole '+v['path']);return p
def read(v):return json.loads(checked(v).read_bytes())
def argument(value):
 path,sha=value.rsplit('#',1);return ref(checked(dict(path=path,sha256=sha)))
def save(path,value):
 need(not path.exists(),'Fresh immutable metadata '+str(path));path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf8',newline='\n');return ref(path)
def contains(value,wanted):
 if isinstance(value,dict):return (value.get('path'),value.get('sha256'))==(wanted['path'],wanted['sha256']) or any(contains(x,wanted) for x in value.values())
 return isinstance(value,list) and any(contains(x,wanted) for x in value)
def peer(v,draft):
 p=read(v);need(p['accepted'] and not p['findings'] and contains(p,draft),'Exact independently accepted draft link');return p
BASE=D/'gap-warmup-multiplier-Exterior-guards-Peer-55-03.py'
need(ref(BASE)['sha256']=='5f7912efe50ee22b3962f125bb5a82278e22a4d6a6013c90a857766bd0fac75f','Carried whole guard')
s=importlib.util.spec_from_file_location('carried55_03_for_category06',BASE);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
APP=D/'Root-Constant-Exterior-category-application-55-06'
CATEGORIES=['internal_gains','beam_producer','surface_internal_gains'];COUNTS={'internal_gains':(9,0),'beam_producer':(18,9),'surface_internal_gains':(6,0)}
def exact(plan):
 rows={e['path']:e for e in plan['entries']};need(len(rows)==len(plan['entries'])==plan['compiler_inputs']==4556 and sum(n.endswith('.rs') for n in rows)==plan['Rust_sources']==4542,'4556/4542 full compiler census')
 names={p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};need(names==rows.keys(),'Exact full compiler inventory')
 for name,e in rows.items():
  actual=ref(R/name);archive=ref(checked(e['source']));need((actual['sha256'],actual['bytes'])==(e['final_sha256'],e['final_bytes'])==(archive['sha256'],archive['bytes']),'Whole current/archive compiler input '+name)
def archive(run,plan):
 snapshot=ref(R/run['source_snapshot']['path']);need(snapshot['sha256']==run['source_snapshot']['sha256'],'Recorded snapshot identity');files={e['historical_path']:e for e in read(snapshot)['files']};rows={e['path']:e for e in plan['entries']};need(files.keys()==rows.keys(),'Entire historical snapshot inventory')
 for name,row in rows.items():
  e=files[name];a=ref(R/e['archive']['path']);need(a['sha256']==e['archive']['sha256']==row['final_sha256'] and a['bytes']==e['size_bytes']==row['final_bytes'],'Historical compiler whole '+name)
 return snapshot
def prepared(spec):
 rr=argument(spec);p=read(rr);need(p['status']=='READY_FOR_ROOT_SEVEN_ROWS_THREE_REMAINING_CATEGORIES','Ready06 status');draft=read(p['coherent_draft']);need(draft['base_HEAD']==p['base_HEAD'],'Exact committed parent');need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==p['base_HEAD'],'Actual HEAD unchanged')
 for key in ['guard_Source','application_Source','launch_Source','environment_guard','record_command_Source']:checked(p[key])
 need(checked(p['guard_Source'])==Path(__file__).resolve(),'This exact guard');need(p['selected_categories_in_order']==CATEGORIES,'Only three remaining complete category lifetimes')
 for pair in draft['independent_leaf_pairs']:peer(pair['peer'],pair['draft'])
 old=read(draft['prior_complete_compiler_Source_plan']);new=read(draft['complete_proposed_compiler_Source_plan']);need(p['complete_compiler_plan']==draft['complete_proposed_compiler_Source_plan'] and p['prior_compiler_plan']==draft['prior_complete_compiler_Source_plan'],'Exact live math05 to category06 plans');before={e['path']:e for e in old['entries']};after={e['path']:e for e in new['entries']};need(before.keys()==after.keys() and {n for n in before if before[n]!=after[n]}=={r['canonical_path'] for r in draft['files']} and len(draft['files'])==7,'Exactly seven existing disjoint rows, other4549 whole metadata exact')
 apply=h.g.literal()
 for row in draft['files']:
  a=checked(row['before']).read_bytes();b=checked(row['proposed']).read_bytes();need(not row['before_absent'] and apply(a,checked(row['forward_diff']).read_bytes())==b and apply(b,checked(row['inverse_diff']).read_bytes())==a,'Two exact literal applications '+row['canonical_path']);need((before[row['canonical_path']]['final_sha256'],before[row['canonical_path']]['final_bytes'])==(row['before']['sha256'],len(a)) and (after[row['canonical_path']]['final_sha256'],after[row['canonical_path']]['final_bytes'])==(row['proposed']['sha256'],len(b)),'Exact selected plan operands')
 _,p3,_=h.prepared(p['carried03_prepared']['path']+'#'+p['carried03_prepared']['sha256']);need(p['environment_guard']==p3['environment_guard'] and p['record_command_Source']==p3['record_command_Source'],'Unchanged approved environment and recorder policy');fixtures,protected=h.fixtures(p3)
 failed=read(draft['source05_qualified_progress']['actual_Source05_receipt']);need(failed['exit_code']==1 and failed['source_bytes_match_before_and_after'] and failed['launch_error'] is None,'Preserved actual failed05 runtime');snapshot=archive(failed,old)
 for key in ['stdout','stderr']:need(ref(R/failed[key]['path'])['sha256']==failed[key]['sha256'],'Complete failed05 log '+key)
 need('blank or unknown type warning' in (R/failed['stderr']['path']).read_text(encoding='utf8'),'Actual unique prior Schedule boundary, not a numeric mismatch')
 return rr,p,draft,old,new,fixtures,protected,snapshot
def command(fixtures,category):
 need(category in CATEGORIES,'Remaining category only');return ['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only','exterior',str(checked(fixtures['exterior'])),category]
def environment(p):
 s=importlib.util.spec_from_file_location('approved43_environment_for_category06',checked(p['environment_guard']));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);env=m.environment();need(env['CARGO_INCREMENTAL']=='0' and Path(env['CARGO_TARGET_DIR']).resolve()==(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve(),'Same target55/incremental0');return env

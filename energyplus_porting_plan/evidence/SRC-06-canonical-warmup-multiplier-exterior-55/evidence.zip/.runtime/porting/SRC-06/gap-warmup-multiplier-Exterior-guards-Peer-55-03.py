"""Read-only exact55-03 two-cfg correction guards; carry warmup02 separately."""
from pathlib import Path
import hashlib,importlib.util
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
BASE=D/'gap-warmup-multiplier-Exterior-guards-Peer-55-02.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='513f4c08f60b1f7160976b98a36957200b30497f250fcc1277738ed17488a899'
s=importlib.util.spec_from_file_location('previous55_02_readonly',BASE);old=importlib.util.module_from_spec(s);s.loader.exec_module(old);g=old.g
APP=D/'Root-warmup-multiplier-Exterior-application-55-03';GROUPS=['multiplier_predictor','exterior']
counts=old.counts;diffs=old.diffs;current_head=old.current_head
def prior(p):return old.prepared(p['prior_prepared']['path']+'#'+p['prior_prepared']['sha256'])
def prepared(spec):
 rr=g.argument(spec);p=g.read(g.checked(rr));g.need(p['status']=='READY_FOR_ROOT_TWO_CFG_CORRECTIONS_TWO_SELECTED_RETRIES','55-03 READY status')
 _,previous,previous_c=prior(p);c=g.read(g.checked(p['correction']));g.need(c['base_HEAD']==p['base_HEAD']==previous['base_HEAD'],'Same committed parent')
 app=g.read(g.checked(p['prior_application']));g.need(app['accepted']and not app['findings']and app['prepared']==p['prior_prepared']and app['all_final_compiler_bytes_exact'],'Genuine three-correction application55-02')
 g.need(app['complete_compiler_plan']==c['prior_complete_compiler_Source_plan']==p['prior_compiler_plan'],'Exact actual55-02 parent plan');g.need(c['complete_proposed_compiler_Source_plan']==p['complete_compiler_plan'],'Exact55-03 final plan')
 g.need(len(c['files'])==2 and len({x['canonical_path']for x in c['files']})==2,'Two disjoint existing cfg corrections')
 g.need([x['draft']for x in p['correction_leaf_peers']]==c['correction_leaf_drafts'],'Two authentic leaf links')
 for x in p['correction_leaf_peers']:old.original.peer(x['peer'],x['draft'])
 old.original.peer(p['joint_correction_peer'],p['correction'])
 for key in ['guard_Source','application_Source','launch_Source','actual_checker_Source','environment_guard','record_command_Source']:g.checked(p[key])
 g.need(g.checked(p['guard_Source'])==Path(__file__).resolve(),'Exact55-03 guard');g.need(p['environment_guard']==previous['environment_guard']and p['record_command_Source']==previous['record_command_Source'],'Unchanged environment/recorder policy')
 g.need(p['selected_groups_in_order']==GROUPS,'Only multiplier and Exterior retries')
 for f in p['failed_Source_attempts']:
  r=g.read(g.checked(f));g.need(r['exit_code']==1 and r['launch_error']is None and r['source_bytes_match_before_and_after']and r['repository_before']==r['repository_after'],'Preserved actual pre-comparison failure')
 w=g.read(g.checked(p['carried_warmup_receipt']));g.need(w['exit_code']==0 and w['source_bytes_match_before_and_after']and w['launch_error']is None,'Genuine warmup02 pass retained')
 return rr,p,c
def fixtures(p):
 _,previous,_=prior(p);return old.fixtures(previous)
def bounded_existing_worktree(p):
 _,previous,_=prior(p);return old.bounded_existing_worktree(previous)
def parent_archive(p):
 plan=g.read(g.checked(p['prior_compiler_plan']));rows={x['path']:x for x in plan['entries']};snapshots=[]
 for rr in [p['carried_warmup_receipt'],*p['failed_Source_attempts']]:
  r=g.read(g.checked(rr));sr=g.ref(R/r['source_snapshot']['path']);g.need(sr['sha256']==r['source_snapshot']['sha256'],'Actual55-02 snapshot ref');archive={x['historical_path']:x for x in g.read(g.checked(sr))['files']};g.need(archive.keys()==rows.keys(),'All4554 parent archive names')
  for name,row in rows.items():
   e=archive[name];a=g.ref(R/e['archive']['path']);g.need(a['sha256']==e['archive']['sha256']==row['final_sha256']and a['bytes']==e['size_bytes']==row['final_bytes'],'Exact55-02 archived Source '+name)
  snapshots.append(sr)
 g.need(all(x==snapshots[0]for x in snapshots),'Warmup/pass and two failures exact same55-02 snapshot');return snapshots[0]
def coherent_selected(p,c):
 _,previous,c2=prior(p);_,_,original=old.original.prepared(previous['original_prepared']['path']+'#'+previous['original_prepared']['sha256']);apply=g.literal();selected=[]
 corrections=[{r['canonical_path']:r for r in doc['files']}for doc in [c2,c]]
 for row in original['files']:
  name=row['canonical_path'];b=b''if row.get('before_absent',row['before']is None)else g.checked(row['before']).read_bytes();a=g.checked(row['proposed']).read_bytes();fw,iv=diffs(row);g.need(apply(b,g.checked(fw).read_bytes())==a and apply(a,g.checked(iv).read_bytes())==b,'Original38 whole literal pair')
  for replacement in corrections:
   if name in replacement:
    r=replacement[name];g.need(g.checked(r['before']).read_bytes()==a,'Successive correction before '+name);b=a;a=g.checked(r['proposed']).read_bytes();fw,iv=diffs(r);g.need(apply(b,g.checked(fw).read_bytes())==a and apply(a,g.checked(iv).read_bytes())==b,'Successive correction literal inverse '+name)
  g.need((R/name).read_bytes()==a,'Actual final38 Source '+name);selected.append(name)
 g.need(len(set(selected))==38 and all(set(x)<=set(selected)for x in corrections),'Same coherent38 footprint');return selected
def warmup_impact_bridge(p,c):
 rows={x['path']:x for x in g.read(g.checked(p['prior_compiler_plan']))['entries']};final={x['path']:x for x in g.read(g.checked(p['complete_compiler_plan']))['entries']};changed={name for name in rows if (rows[name]['final_sha256'],rows[name]['final_bytes'])!=(final[name]['final_sha256'],final[name]['final_bytes'])};g.need(changed=={r['canonical_path']for r in c['files']},'Only two corrected cfg plan rows')
 parent='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort.rs';r=next(x for x in c['files']if x['canonical_path']==parent);a=g.checked(r['before']).read_bytes();b=g.checked(r['proposed']).read_bytes();anchor=b'/// Compose the same persistent output domains for passive registered-Which reads.\n';g.need(a.split(b'fn registration(',1)[0]==b.split(anchor,1)[0],'Entire genuine Factory bootstrap prefix unchanged')
 warm='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/native_gap_cohort/warmup.rs';body=g.checked(rows[warm]['source']).read_text(encoding='utf-8');g.need('registration('not in body and 'snapshot('not in body and 'run_native_gap_purchased_air'not in body,'Warmup observer does not call P1 snapshot/resolver');g.need(rows[warm]==final[warm],'Warmup entire observer file unchanged')
 for name in ['crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs','crates/ep_runtime/src/lib.rs']:g.need(rows[name]==final[name],'Shared dispatcher/main whole unchanged')
 return dict(accepted=True,changed_plan_rows=sorted(changed),all_other4552_entries_exact=True,warmup_observer_and_own_kernels_and_fixture_whole_unchanged=True,Factory_constructor_prefix_whole_unchanged=True,two_changed_cfg_functions_outside_warmup_call_chain=True,carried_warmup_actual=p['carried_warmup_receipt'],carried_plan=p['prior_compiler_plan'],final_plan=p['complete_compiler_plan'],same_recorded_Source_snapshot_claim=False,same_compiled_binary_claim=False,qualification='Warmup69 actual02 is carried through a reviewed cfg-only readset/whole-body bridge. Only multiplier/Exterior are newly executed on final03.')

// Private original-core Weather/InitExt unit consumers; no copied numerical body.
#include "native_gap_batches.hh"
#include <EnergyPlus/Data/EnergyPlusData.hh>
#include <EnergyPlus/ConvectionCoefficients.hh>
#include <EnergyPlus/ConvectionConstants.hh>
#include <EnergyPlus/DataEnvironment.hh>
#include <EnergyPlus/DataErrorTracking.hh>
#include <EnergyPlus/DataGlobals.hh>
#include <EnergyPlus/DataHeatBalance.hh>
#include <EnergyPlus/DataHeatBalSurface.hh>
#include <EnergyPlus/DataSurfaces.hh>
#include <EnergyPlus/InputProcessing/InputProcessor.hh>
#include <EnergyPlus/IOFiles.hh>
#include <EnergyPlus/Material.hh>
#include <EnergyPlus/WeatherManager.hh>
#include <EnergyPlus/Construction.hh>
#include <EnergyPlus/DataViewFactorInformation.hh>
#include <EnergyPlus/DataSystemVariables.hh>
#include <EnergyPlus/HeatBalanceSurfaceManager.hh>
#include <EnergyPlus/SolarShading.hh>
#include <EnergyPlus/DataBSDFWindow.hh>
#include <EnergyPlus/DataHVACGlobals.hh>
#include <EnergyPlus/DataStringGlobals.hh>
#include <EnergyPlus/DataShadowingCombinations.hh>
#include <EnergyPlus/HeatBalanceManager.hh>
#include <EnergyPlus/HeatBalanceIntRadExchange.hh>
#include <EnergyPlus/InternalHeatGains.hh>
#include <EnergyPlus/OutputProcessor.hh>
#include <EnergyPlus/OutputReportPredefined.hh>
#include <EnergyPlus/Plant/PlantLocation.hh>
#include <EnergyPlus/RefrigeratedCase.hh>
#include <EnergyPlus/ElectricPowerServiceManager.hh>
#include <EnergyPlus/ReportCoilSelection.hh>
#include <EnergyPlus/SimulationManager.hh>
#include <EnergyPlus/ScheduleManager.hh>
#include <EnergyPlus/ZoneEquipmentManager.hh>
#include <EnergyPlus/ZoneTempPredictorCorrector.hh>
#include <nlohmann/json.hpp>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <memory>
#include <exception>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

namespace NativeGapBatch {
namespace {
using namespace EnergyPlus;
using EnergyPlus::EnergyPlusData;
using json=nlohmann::json;
void require(bool ok,char const*m){if(!ok)throw std::runtime_error(m);}
json raw(double v){std::uint64_t b;std::memcpy(&b,&v,sizeof b);std::ostringstream s;s<<std::hex<<std::setfill('0')<<std::setw(16)<<b;return json{{"value_bits",s.str()}};}
double real(json const&v){auto s=v.at("value_bits").get<std::string>();require(v.size()==1&&s.size()==16,"one raw16 scalar");std::uint64_t b=0;for(char c:s){require((c>='0'&&c<='9')||(c>='a'&&c<='f'),"lowercase rawhex");b=(b<<4)|unsigned(c<='9'?c-'0':c-'a'+10);}double x;std::memcpy(&x,&b,sizeof x);return x;}
template<class T>std::uintptr_t address(T const*p){return reinterpret_cast<std::uintptr_t>(p);}
template<class A>json shape(A const&a){json out{{"allocated",a.allocated()},{"size",a.size()}};if constexpr(requires{a.l();a.u();}){out["lower"]=a.l();out["upper"]=a.u();}return out;}
std::unique_ptr<EnergyPlusData>state(){auto s=std::make_unique<EnergyPlusData>();s->files.err_stream=std::make_unique<std::ostringstream>();return s;}
json diagnostics(EnergyPlusData const&s){return json{{"text",static_cast<std::ostringstream const&>(*s.files.err_stream).str()},{"warnings",s.dataErrTracking->TotalWarningErrors},{"severe",s.dataErrTracking->TotalSevereErrors},{"recurring",s.dataErrTracking->NumRecurringErrors}};}
json solar_state(EnergyPlusData const&s){auto const&e=*s.dataEnvrn;auto const&w=*s.dataWeather;return json{{"state_address",address(&s)},{"SunIsUp",e.SunIsUp},{"SunIsUpPrevTS",e.SunIsUpPrevTS},{"SOLCOS",{raw(e.SOLCOS.x),raw(e.SOLCOS.y),raw(e.SOLCOS.z)}},{"HrAngle",raw(w.HrAngle)},{"SolarAltitudeAngle",raw(w.SolarAltitudeAngle)},{"SolarAzimuthAngle",raw(w.SolarAzimuthAngle)},{"TodaySinDeclin",raw(w.TodayVariables.SinSolarDeclinAngle)},{"TodayCosDeclin",raw(w.TodayVariables.CosSolarDeclinAngle)},{"TodayEquationOfTime",raw(w.TodayVariables.EquationOfTime)}};}
json solar_case(json const&c){auto s=state();auto&e=*s->dataEnvrn;auto&w=*s->dataWeather;e.Latitude=real(c.at("latitude"));e.SinLatitude=real(c.at("sin_latitude"));e.CosLatitude=real(c.at("cos_latitude"));e.Longitude=real(c.at("longitude"));e.TimeZoneMeridian=real(c.at("time_zone_meridian"));e.TS1TimeOffset=real(c.at("TS1TimeOffset"));s->dataGlobal->TimeStepsInHour=c.at("steps_per_hour").get<int>();require(s->dataGlobal->TimeStepsInHour>0,"positive native timestep count");
    double a,b,d,annual,eq,sin_decl,cos_decl;
    Weather::CalculateDailySolarCoeffs(*s,c.at("day_of_year").get<int>(),a,b,d,annual,eq,sin_decl,cos_decl);
    // These are the actual upstream returns, transported without recalculation.
    w.TodayVariables.EquationOfTime=eq;w.TodayVariables.SinSolarDeclinAngle=sin_decl;w.TodayVariables.CosSolarDeclinAngle=cos_decl;
    json out{{"name",c.at("name")},{"input",c},{"daily",{{"A",raw(a)},{"B",raw(b)},{"C",raw(d)},{"AnnVarSolConstant",raw(annual)},{"EquationOfTime",raw(eq)},{"SineSolarDeclination",raw(sin_decl)},{"CosineSolarDeclination",raw(cos_decl)}}},{"initial",solar_state(*s)},{"calls",json::array()}};
    for(auto const&step:c.at("times")){s->dataGlobal->CurrentTime=real(step);Vector3<Real64> direction;Weather::CalculateSunDirectionCosines(*s,s->dataGlobal->CurrentTime,eq,sin_decl,cos_decl,direction);json before=solar_state(*s);Weather::DetermineSunUpDown(*s,e.SOLCOS);out["calls"].push_back({{"primary_time",step},{"direction",{raw(direction.x),raw(direction.y),raw(direction.z)}},{"before",before},{"after",solar_state(*s)}});}return out;
}
json convection_state(EnergyPlusData const&s){auto const&surface=s.dataSurface->Surface(1);return json{{"state_address",address(&s)},{"surface_address",address(&surface)},{"GetUserSuppliedConvectionCoeffs",s.dataConvect->GetUserSuppliedConvectionCoeffs},{"inside_user_curves",shape(s.dataConvect->hcIntUserCurve)},{"outside_user_curves",shape(s.dataConvect->hcExtUserCurve)},{"inside_user_model_storage",shape(s.dataSurface->userIntConvModels)},{"outside_user_model_storage",shape(s.dataSurface->userExtConvModels)},{"user_inside_models",s.dataSurface->TotUserIntConvModels},{"user_outside_models",s.dataSurface->TotUserExtConvModels},{"actual_surface_model",static_cast<int>(s.dataSurface->surfExtConv(1).model)},{"actual_zone_model",static_cast<int>(s.dataHeatBal->Zone(1).ExtConvAlgo)},{"diagnostics",diagnostics(s)}};}
json exterior_case(json const&c){auto s=state();s->dataGlobal->NumOfZones=1;s->dataHeatBal->Zone.allocate(1);s->dataSurface->TotSurfaces=1;s->dataSurface->Surface.allocate(1);auto&surface=s->dataSurface->Surface(1);surface.Name=c.at("name").get<std::string>();surface.Zone=1;surface.BaseSurf=1;surface.Class=surface.OriginalClass=DataSurfaces::SurfaceClass::Wall;surface.ExtWind=c.at("wind_exposed").get<bool>();surface.GrossArea=real(c.at("gross_area"));surface.Height=real(c.at("height"));surface.CosTilt=real(c.at("cos_tilt"));surface.Azimuth=real(c.at("azimuth"));surface.ViewFactorSkyIR=real(c.at("view_factor_sky"));surface.ViewFactorGroundIR=real(c.at("view_factor_ground"));
    s->dataSurface->SurfOutDryBulbTemp.allocate(1);s->dataSurface->SurfOutWindSpeed.allocate(1);s->dataSurface->SurfOutWindDir.allocate(1);s->dataSurface->SurfAirSkyRadSplit.allocate(1);s->dataSurface->SurfEMSOverrideExtConvCoef.dimension(1,false);s->dataHeatBalSurf->SurfWinCoeffAdjRatio.allocate(1);s->dataSurface->surfExtConv.allocate(1);
    std::string model=c.at("model").get<std::string>();auto selected=model=="DOE2"?Convect::HcExt::DOE2HcOutside:model=="ASHRAESimple"?Convect::HcExt::ASHRAESimple:throw std::runtime_error("selected exterior algorithm");s->dataSurface->surfExtConv(1).model=selected;s->dataHeatBal->Zone(1).ExtConvAlgo=selected;
    int rough=c.at("roughness").get<int>();require(rough>=0&&rough<6,"actual SurfaceRoughness ordinal0..5");
    // The original constructor's empty epJSON is a genuine no-user-override
    // input. InitExt itself invokes GetUserConvCoeffs and changes its true latch.
    require(s->dataInputProcessing->inputProcessor->epJSON.empty(),"actual ctor-owned empty input domain");
    json out{{"name",c.at("name")},{"input",c},{"initial",convection_state(*s)},{"lifetime","one native state; GetUserConvCoeffs not bypassed; repeated calls retain latch/arrays"},{"calls",json::array()}};
    for(auto const&step:c.at("steps")){s->dataSurface->SurfOutDryBulbTemp(1)=real(step.at("dry_bulb"));s->dataSurface->SurfOutWindSpeed(1)=real(step.at("wind_speed"));s->dataSurface->SurfOutWindDir(1)=real(step.at("wind_direction"));s->dataSurface->SurfAirSkyRadSplit(1)=real(step.at("air_sky_split"));s->dataEnvrn->SkyTempKelvin=real(step.at("sky_temperature_kelvin"));s->dataHeatBalSurf->SurfWinCoeffAdjRatio(1)=real(step.at("adjustment"));double h,sky,ground,air,surround;json before=convection_state(*s);Convect::InitExtConvCoeff(*s,1,real(step.at("HMovInsul")),static_cast<Material::SurfaceRoughness>(rough),real(step.at("absorptance")),real(step.at("surface_temperature")),h,sky,ground,air,surround);out["calls"].push_back({{"primary_step",step},{"before",before},{"after",convection_state(*s)},{"HExt",raw(h)},{"HSky",raw(sky)},{"HGround",raw(ground)},{"HAir",raw(air)},{"HSrdSurf",raw(surround)}});}return out;
}
// Direct full original consumers. Geometry/coefficients below are declared
// narrow-call primary inputs, not results of unclaimed beam/gain producers.
template<class A>json consumer_vector(A const&a,bool defined){auto out=shape(a);out["values_defined"]=defined;if(a.allocated())out["data_address"]=address(a.data());out["values"]=nullptr;if(defined&&a.allocated()){out["values"]=json::array();for(int i=a.l();i<=a.u();++i)out["values"].push_back(raw(a(i)));}return out;}
json absorption_state(EnergyPlusData const&s){auto const&r=s.dataViewFactor->EnclRadInfo(1);auto const&v=s.dataViewFactor->EnclSolInfo(1);json ptr=json::array();for(int i=1;i<=r.SurfacePtr.isize();++i)ptr.push_back(r.SurfacePtr(i));return json{{"state_address",address(&s)},{"radiant_owner_address",address(&r)},{"solar_owner_address",address(&v)},{"radiant_count",s.dataViewFactor->NumOfRadiantEnclosures},{"solar_count",s.dataViewFactor->NumOfSolarEnclosures},{"radReCalc",r.radReCalc},{"solar_radReCalc",v.radReCalc},{"NumOfSurfaces",r.NumOfSurfaces},{"SurfacePtr",ptr},{"inside_thermal_absorptance",consumer_vector(s.dataHeatBalSurf->SurfAbsThermalInt,true)},{"inside_solar_absorptance",consumer_vector(s.dataHeatBalSurf->SurfAbsSolarInt,true)},{"radThermAbsMult",raw(r.radThermAbsMult)},{"solVMULT",raw(v.solVMULT)},{"solAbsFirstCalc",v.solAbsFirstCalc},{"diagnostics",diagnostics(s)}};}
json absorption_case(json const&c){auto s=state();int n=int(c.at("areas").size());require(n>0&&n<=8,"bounded primary opaque surface count");
    s->dataGlobal->NumOfZones=1;s->dataGlobal->numSpaces=1;s->dataHeatBal->Zone.allocate(1);s->dataHeatBal->Zone(1).Name=c.at("name").get<std::string>();s->dataHeatBal->Zone(1).spaceIndexes.push_back(1);s->dataHeatBal->space.allocate(1);s->dataHeatBal->space(1).Name="Declared opaque unit space";s->dataHeatBal->space(1).zoneNum=1;
    // Native Space constructor WindowSurfaceFirst0/Last-1 is retained.
    s->dataSurface->TotSurfaces=n;s->dataSurface->Surface.allocate(n);s->dataConstruction->Construct.allocate(n);s->dataSurface->SurfActiveConstruction.allocate(n);s->dataSurface->SurfWinShadingFlag.dimension(n,DataSurfaces::WinShadingType::NoShade);s->dataSurface->SurfWinFrameArea.dimension(n,0.0);s->dataSurface->SurfWinDividerArea.dimension(n,0.0);s->dataHeatBalSurf->SurfAbsThermalInt.allocate(n);s->dataHeatBalSurf->SurfAbsSolarInt.allocate(n);
    s->dataViewFactor->NumOfRadiantEnclosures=1;s->dataViewFactor->NumOfSolarEnclosures=1;s->dataViewFactor->EnclRadInfo.allocate(1);s->dataViewFactor->EnclSolInfo.allocate(1);for(auto*e:{&s->dataViewFactor->EnclRadInfo(1),&s->dataViewFactor->EnclSolInfo(1)}){e->Name=c.at("name").get<std::string>();e->NumOfSurfaces=n;e->spaceNums.push_back(1);e->SurfacePtr.allocate(n);for(int i=1;i<=n;++i)e->SurfacePtr(i)=i;}
    for(int i=1;i<=n;++i){auto&v=s->dataSurface->Surface(i);v.Name="Declared opaque "+std::to_string(i);v.Area=real(c.at("areas")[i-1]);v.Construction=i;v.Class=v.OriginalClass=DataSurfaces::SurfaceClass::Wall;s->dataSurface->SurfActiveConstruction(i)=i;require(s->dataConstruction->Construct(i).TransDiff==0.0,"actual opaque constructor");}
    json out{{"name",c.at("name")},{"input",c},{"scope","two full opaque absorption consumers; no geometry/material/getter producer claim"},{"lifetime","one native state; no output restoration between calls"},{"calls",json::array()}};
    for(auto const&step:c.at("steps")){require(step.at("thermal").size()==std::size_t(n)&&step.at("shortwave").size()==std::size_t(n),"primary absorption vector extents");for(int i=1;i<=n;++i){s->dataHeatBalSurf->SurfAbsThermalInt(i)=real(step.at("thermal")[i-1]);s->dataHeatBalSurf->SurfAbsSolarInt(i)=real(step.at("shortwave")[i-1]);}s->dataViewFactor->EnclRadInfo(1).radReCalc=step.at("recalculate").get<bool>();s->dataViewFactor->EnclSolInfo(1).radReCalc=step.at("recalculate").get<bool>();json before=absorption_state(*s);HeatBalanceSurfaceManager::ComputeIntThermalAbsorpFactors(*s);json thermal=absorption_state(*s);HeatBalanceSurfaceManager::ComputeIntSWAbsorpFactors(*s);out["calls"].push_back({{"primary_step",step},{"before",before},{"after_thermal",thermal},{"after_shortwave",absorption_state(*s)}});}return out;}
json solar_consumer_state(EnergyPlusData const&s,bool anisotropic_defined,bool current_ratio_defined,bool opaque_defined){auto const&m=*s.dataSolarShading;json surfaces=json::array();for(int i=1;i<=s.dataSurface->TotSurfaces;++i){auto const&v=s.dataSurface->Surface(i);surfaces.push_back({{"ordinal",i},{"address",address(&v)},{"Name",v.Name},{"Construction",v.Construction},{"Class",static_cast<int>(v.Class)},{"OriginalClass",static_cast<int>(v.OriginalClass)},{"ExtSolar",v.ExtSolar},{"OutNormVec",{raw(v.OutNormVec.x),raw(v.OutNormVec.y),raw(v.OutNormVec.z)}},{"Tilt",raw(v.Tilt)},{"SinTilt",raw(v.SinTilt)},{"ViewFactorSky",raw(v.ViewFactorSky)},{"OutsideAbsorpSolar",raw(s.dataConstruction->Construct(v.Construction).OutsideAbsorpSolar)},{"TransDiff",raw(s.dataConstruction->Construct(v.Construction).TransDiff)},{"current_cosine",raw(s.dataHeatBal->SurfCosIncAng(s.dataGlobal->HourOfDay,s.dataGlobal->TimeStep,i))},{"current_sunlit",raw(s.dataHeatBal->SurfSunlitFrac(s.dataGlobal->HourOfDay,s.dataGlobal->TimeStep,i))},{"isotropic_ratio",raw(m.SurfDifShdgRatioIsoSky(i))},{"horizon_ratio",raw(m.SurfDifShdgRatioHoriz(i))},{"hrts_isotropic_ratio",raw(m.SurfDifShdgRatioIsoSkyHRTS(s.dataGlobal->TimeStep,s.dataGlobal->HourOfDay,i))},{"hrts_horizon_ratio",raw(m.SurfDifShdgRatioHorizHRTS(s.dataGlobal->TimeStep,s.dataGlobal->HourOfDay,i))}});}
    return json{{"state_address",address(&s)},{"module_address",address(&m)},{"HourOfDay",s.dataGlobal->HourOfDay},{"TimeStep",s.dataGlobal->TimeStep},{"SOLCOS",{raw(s.dataEnvrn->SOLCOS.x),raw(s.dataEnvrn->SOLCOS.y),raw(s.dataEnvrn->SOLCOS.z)}},{"Elevation",raw(s.dataEnvrn->Elevation)},{"BeamSolarRad",raw(s.dataEnvrn->BeamSolarRad)},{"DifSolarRad",raw(s.dataEnvrn->DifSolarRad)},{"DetailedSkyDiffuseAlgorithm",s.dataSysVars->DetailedSkyDiffuseAlgorithm},{"ShadingTransmittanceVaries",s.dataSurface->ShadingTransmittanceVaries},{"SolarDistribution",static_cast<int>(s.dataHeatBal->SolarDistribution)},{"surfaces",surfaces},{"SurfAnisoSkyMult",consumer_vector(m.SurfAnisoSkyMult,anisotropic_defined)},{"SurfMultIsoSky",consumer_vector(m.SurfMultIsoSky,anisotropic_defined)},{"SurfMultCircumSolar",consumer_vector(m.SurfMultCircumSolar,anisotropic_defined)},{"SurfMultHorizonZenith",consumer_vector(m.SurfMultHorizonZenith,anisotropic_defined)},{"SurfCurDifShdgRatioIsoSky",consumer_vector(m.SurfCurDifShdgRatioIsoSky,current_ratio_defined)},{"SurfOpaqAO",consumer_vector(s.dataSurface->SurfOpaqAO,opaque_defined)},{"diagnostics",diagnostics(s)}};}
json solar_consumer_case(json const&c){auto s=state();int n=int(c.at("surfaces").size());require(n>0&&n<=8,"bounded primary solar surface count");int steps=c.at("steps_per_hour").get<int>();require(steps>0&&steps<=60,"primary clock extent");s->dataGlobal->NumOfZones=1;s->dataGlobal->numSpaces=1;s->dataGlobal->TimeStepsInHour=steps;s->dataHeatBal->Zone.allocate(1);s->dataHeatBal->Zone(1).spaceIndexes.push_back(1);s->dataHeatBal->space.allocate(1);s->dataHeatBal->space(1).HTSurfaceFirst=1;s->dataHeatBal->space(1).HTSurfaceLast=n;s->dataSurface->TotSurfaces=n;s->dataSurface->Surface.allocate(n);s->dataSurface->SurfActiveConstruction.allocate(n);s->dataSurface->SurfOpaqAO.allocate(n);s->dataConstruction->Construct.allocate(n);s->dataHeatBal->SurfCosIncAng.allocate(24,steps,n);s->dataHeatBal->SurfSunlitFrac.allocate(24,steps,n);
    auto&m=*s->dataSolarShading;m.SurfAnisoSkyMult.allocate(n);m.SurfMultIsoSky.allocate(n);m.SurfMultCircumSolar.allocate(n);m.SurfMultHorizonZenith.allocate(n);m.SurfCurDifShdgRatioIsoSky.allocate(n);m.SurfDifShdgRatioIsoSky.allocate(n);m.SurfDifShdgRatioHoriz.allocate(n);m.SurfDifShdgRatioIsoSkyHRTS.allocate(steps,24,n);m.SurfDifShdgRatioHorizHRTS.allocate(steps,24,n);
    for(int i=1;i<=n;++i){auto const&p=c.at("surfaces")[i-1];auto&v=s->dataSurface->Surface(i);v.Name=p.at("name").get<std::string>();v.Construction=i;v.Class=v.OriginalClass=DataSurfaces::SurfaceClass::Wall;v.OutNormVec={real(p.at("normal")[0]),real(p.at("normal")[1]),real(p.at("normal")[2])};v.Tilt=real(p.at("tilt"));v.SinTilt=real(p.at("sin_tilt"));v.ViewFactorSky=real(p.at("sky_view"));s->dataSurface->SurfActiveConstruction(i)=i;s->dataConstruction->Construct(i).OutsideAbsorpSolar=real(p.at("outside_absorptance"));require(s->dataConstruction->Construct(i).TransDiff==0.0,"actual opaque constructor");s->dataSurface->AllExtSolarSurfaceList.push_back(i);}
    bool anisotropic_defined=false,current_ratio_defined=false,opaque_defined=false;json out{{"name",c.at("name")},{"input",c},{"scope","full AnisoSkyViewFactors and opaque CalcAbsorbed consumers; no FigureSolarBeam/SHADOW/weather/geometry producer equivalence"},{"lifetime","one native state, all selected slots written before first value observation; no restoring output cells"},{"calls",json::array()}};
    for(auto const&step:c.at("steps")){s->dataGlobal->HourOfDay=step.at("hour").get<int>();s->dataGlobal->TimeStep=step.at("timestep").get<int>();require(s->dataGlobal->HourOfDay>=1&&s->dataGlobal->HourOfDay<=24&&s->dataGlobal->TimeStep>=1&&s->dataGlobal->TimeStep<=steps,"selected actual clock bounds");s->dataEnvrn->SOLCOS={real(step.at("SOLCOS")[0]),real(step.at("SOLCOS")[1]),real(step.at("SOLCOS")[2])};s->dataEnvrn->Elevation=real(step.at("elevation"));s->dataEnvrn->BeamSolarRad=real(step.at("beam"));s->dataEnvrn->DifSolarRad=real(step.at("diffuse"));s->dataSysVars->DetailedSkyDiffuseAlgorithm=step.at("detailed_sky").get<bool>();s->dataSurface->ShadingTransmittanceVaries=step.at("varying_transmittance").get<bool>();s->dataHeatBal->SolarDistribution=step.at("minimal_distribution").get<bool>()?DataHeatBalance::Shadowing::Minimal:DataHeatBalance::Shadowing::FullExterior;
        bool all_opaque_slots_will_write=true;for(int i=1;i<=n;++i){auto const&p=step.at("surface_inputs")[i-1];auto&v=s->dataSurface->Surface(i);v.ExtSolar=p.at("solar_exposed").get<bool>();s->dataHeatBal->SurfCosIncAng(s->dataGlobal->HourOfDay,s->dataGlobal->TimeStep,i)=real(p.at("incidence"));s->dataHeatBal->SurfSunlitFrac(s->dataGlobal->HourOfDay,s->dataGlobal->TimeStep,i)=real(p.at("sunlit"));m.SurfDifShdgRatioIsoSky(i)=real(p.at("isotropic_ratio"));m.SurfDifShdgRatioHoriz(i)=real(p.at("horizon_ratio"));m.SurfDifShdgRatioIsoSkyHRTS(s->dataGlobal->TimeStep,s->dataGlobal->HourOfDay,i)=real(p.at("hrts_isotropic_ratio"));m.SurfDifShdgRatioHorizHRTS(s->dataGlobal->TimeStep,s->dataGlobal->HourOfDay,i)=real(p.at("hrts_horizon_ratio"));if(!v.ExtSolar||!(s->dataHeatBal->SurfSunlitFrac(s->dataGlobal->HourOfDay,s->dataGlobal->TimeStep,i)>0.0))all_opaque_slots_will_write=false;}
        // Declared first call must really write every selected opaque slot;
        // later exposure/zero-sunlit cases retain genuine previous outputs.
        require(opaque_defined||all_opaque_slots_will_write,"first opaque call requires defined full-write prefix");json before=solar_consumer_state(*s,anisotropic_defined,current_ratio_defined,opaque_defined);SolarShading::AnisoSkyViewFactors(*s);anisotropic_defined=true;if(s->dataSysVars->DetailedSkyDiffuseAlgorithm&&s->dataSurface->ShadingTransmittanceVaries&&s->dataHeatBal->SolarDistribution!=DataHeatBalance::Shadowing::Minimal)current_ratio_defined=true;json after_sky=solar_consumer_state(*s,anisotropic_defined,current_ratio_defined,opaque_defined);SolarShading::CalcAbsorbedOnExteriorOpaqueSurfaces(*s);opaque_defined=true;out["calls"].push_back({{"primary_step",step},{"before",before},{"after_anisotropic",after_sky},{"after_opaque",solar_consumer_state(*s,anisotropic_defined,current_ratio_defined,opaque_defined)}});}return out;}

// Full original input/gain producer lifetimes. All scientific allocations and
// gain pointers below come from the real getters/allocators; no output seeds.
// Observer-only recovery. No scientific state is changed by these writes.
struct ExteriorProgress {
    std::string const &path;
    json const &completed;
    void write(json const &failure = nullptr, json const &active = nullptr) const {
        if (path.empty()) return;
        json record{{"schema", "src06-exterior-incomplete-progress.v1"},
                    {"normal_completion", false}, {"completed_whole_lifetimes", completed},
                    {"failure", failure}, {"active_phase", active}};
        std::ofstream output(path, std::ios::binary | std::ios::trunc);
        if (!output) throw std::runtime_error("Exterior progress open failed");
        output << record.dump(2) << '\n';
        output.flush();
        if (!output) throw std::runtime_error("Exterior progress write failed");
    }
    void phase(EnergyPlusData const &state, std::string const &name, std::string const &phase) const {
        json active{{"case_name", name}, {"actual_phase", phase}, {"state_address", address(&state)},
                    {"live_diagnostics", nullptr}};
        if (state.files.err_stream) active["live_diagnostics"] = diagnostics(state);
        write(nullptr, active);
    }
    void failure(EnergyPlusData const &state, std::string const &name, std::string const &phase) const {
        json detail{{"case_name", name}, {"actual_phase", phase},
                    {"state_address", address(&state)}, {"live_diagnostics", nullptr}};
        if (state.files.err_stream) detail["live_diagnostics"] = diagnostics(state);
        write(detail);
    }
};
struct ProducerFactory {
    std::unique_ptr<EnergyPlusData> value;
    ExteriorProgress const *observer = nullptr;
    std::string case_name;
    std::string phase = "construct genuine EnergyPlusData";
    int uncaught_at_entry = std::uncaught_exceptions();
    ProducerFactory() = default;
    ProducerFactory(ProducerFactory &&) = default;
    void checkpoint(std::string const &next_phase) {
        phase = next_phase;
        if (value && observer) observer->phase(*value, case_name, phase);
    }
    // The destructor body runs while value and its real err_stream are alive.
    // Preserve the original active exception even if observation I/O fails.
    ~ProducerFactory() noexcept {
        if (value && observer && std::uncaught_exceptions() > uncaught_at_entry) {
            try { observer->failure(*value, case_name, phase); }
            catch (std::exception const &error) { std::cerr << "Exterior recovery failed: " << error.what() << '\n'; }
            catch (...) { std::cerr << "Exterior recovery failed with nonstandard observer exception\n"; }
        }
    }
};
ProducerFactory producer_input(json const&c,ExteriorProgress const&observer){ProducerFactory f;f.observer=&observer;f.case_name=c.at("name").get<std::string>();f.value=std::make_unique<EnergyPlusData>();auto&s=*f.value;
    s.files.eio.open_as_stringstream();s.files.eso.open_as_stringstream();s.files.mtr.open_as_stringstream();s.files.audit.open_as_stringstream();s.files.bnd.open_as_stringstream();s.files.debug.open_as_stringstream();s.files.mtd.open_as_stringstream();s.files.edd.open_as_stringstream();s.files.err_stream=std::make_unique<std::ostringstream>();
    f.checkpoint("init_constant_state");s.init_constant_state(s);s.dataStrGlobals->inputFilePath=c.at("input_file").get<std::string>();
    f.checkpoint("InputProcessor::processInput");s.dataInputProcessing->inputProcessor->processInput(s);
    f.checkpoint("SimulationManager::PostIPProcessing");SimulationManager::PostIPProcessing(s);
    f.checkpoint("EnergyPlusData::init_state");s.init_state(s);
    f.checkpoint("OutputReportPredefined::SetPredefinedTables / HeatBalanceManager::SetPreConstructionInputParameters");OutputReportPredefined::SetPredefinedTables(s);HeatBalanceManager::SetPreConstructionInputParameters(s);
    OutputProcessor::SetupTimePointers(s,OutputProcessor::TimeStepType::Zone,s.dataGlobal->TimeStepZone);
    OutputProcessor::SetupTimePointers(s,OutputProcessor::TimeStepType::System,s.dataHVACGlobal->TimeStepSys);
    f.checkpoint("actual electric-service / coil-selection factories");createFacilityElectricPowerServiceObject(s);createCoilSelectionReportObj(s);return f;
}
void producer_clock(EnergyPlusData&s,json const&p){s.dataGlobal->HourOfDay=p.at("hour").get<int>();s.dataGlobal->TimeStep=p.at("timestep").get<int>();
    require(s.dataGlobal->HourOfDay>=1&&s.dataGlobal->HourOfDay<=24&&s.dataGlobal->TimeStep>=1&&s.dataGlobal->TimeStep<=s.dataGlobal->TimeStepsInHour,"getter-produced clock bounds");
    s.dataEnvrn->DayOfYear_Schedule=p.at("day_of_year").get<int>();s.dataEnvrn->DayOfWeek=p.at("day_of_week").get<int>();
    s.dataGlobal->BeginEnvrnFlag=p.at("begin_environment").get<bool>();
    Sched::UpdateScheduleVals(s);
}
json gain_equipment(DataHeatBalance::ZoneEquipData const&e){json v{{"address",address(&e)},{"Name",e.Name},{"ZonePtr",e.ZonePtr},{"spaceIndex",e.spaceIndex},{"schedule_address",address(e.sched)},{"fuel",static_cast<int>(e.OtherEquipFuelType)},{"EMSZoneEquipOverrideOn",e.EMSZoneEquipOverrideOn},{"ManageDemand",e.ManageDemand},{"EndUseSubcategory",e.EndUseSubcategory}};
    if(e.sched)v["actual_schedule_current"]=raw(e.sched->getCurrentVal());
    v["f64"]={};
#define GAIN_MEMBER(m) v["f64"][#m]=raw(e.m)
    GAIN_MEMBER(DesignLevel);GAIN_MEMBER(EMSEquipPower);GAIN_MEMBER(FractionLatent);GAIN_MEMBER(FractionRadiant);GAIN_MEMBER(FractionLost);GAIN_MEMBER(FractionConvected);GAIN_MEMBER(CO2DesignRate);GAIN_MEMBER(CO2RateFactor);GAIN_MEMBER(NomMinDesignLevel);GAIN_MEMBER(NomMaxDesignLevel);GAIN_MEMBER(DemandLimit);GAIN_MEMBER(Power);GAIN_MEMBER(RadGainRate);GAIN_MEMBER(ConGainRate);GAIN_MEMBER(LatGainRate);GAIN_MEMBER(LostRate);GAIN_MEMBER(TotGainRate);GAIN_MEMBER(CO2GainRate);GAIN_MEMBER(Consumption);GAIN_MEMBER(RadGainEnergy);GAIN_MEMBER(ConGainEnergy);GAIN_MEMBER(LatGainEnergy);GAIN_MEMBER(LostEnergy);GAIN_MEMBER(TotGainEnergy);
#undef GAIN_MEMBER
    return v;
}
json gain_report(DataHeatBalance::ZoneReportVars const&e){json v{{"address",address(&e)},{"f64",json::object()},{"OtherPower",json::array()},{"OtherConsump",json::array()}};
#define GAIN_REPORT(m) v["f64"][#m]=raw(e.m)
    GAIN_REPORT(PeopleRadGain);GAIN_REPORT(PeopleConGain);GAIN_REPORT(PeopleSenGain);GAIN_REPORT(PeopleNumOcc);GAIN_REPORT(PeopleLatGain);GAIN_REPORT(PeopleTotGain);GAIN_REPORT(PeopleRadGainRate);GAIN_REPORT(PeopleConGainRate);GAIN_REPORT(PeopleSenGainRate);GAIN_REPORT(PeopleLatGainRate);GAIN_REPORT(PeopleTotGainRate);GAIN_REPORT(LtsPower);GAIN_REPORT(LtsElecConsump);GAIN_REPORT(LtsRadGain);GAIN_REPORT(LtsVisGain);GAIN_REPORT(LtsConGain);GAIN_REPORT(LtsRetAirGain);GAIN_REPORT(LtsTotGain);GAIN_REPORT(LtsRadGainRate);GAIN_REPORT(LtsVisGainRate);GAIN_REPORT(LtsConGainRate);GAIN_REPORT(LtsRetAirGainRate);GAIN_REPORT(LtsTotGainRate);GAIN_REPORT(BaseHeatPower);GAIN_REPORT(BaseHeatElecCons);GAIN_REPORT(BaseHeatRadGain);GAIN_REPORT(BaseHeatConGain);GAIN_REPORT(BaseHeatTotGain);GAIN_REPORT(BaseHeatRadGainRate);GAIN_REPORT(BaseHeatConGainRate);GAIN_REPORT(BaseHeatTotGainRate);GAIN_REPORT(ElecPower);GAIN_REPORT(ElecConsump);GAIN_REPORT(ElecRadGain);GAIN_REPORT(ElecConGain);GAIN_REPORT(ElecLatGain);GAIN_REPORT(ElecLost);GAIN_REPORT(ElecTotGain);GAIN_REPORT(ElecRadGainRate);GAIN_REPORT(ElecConGainRate);GAIN_REPORT(ElecLatGainRate);GAIN_REPORT(ElecLostRate);GAIN_REPORT(ElecTotGainRate);GAIN_REPORT(GasPower);GAIN_REPORT(GasConsump);GAIN_REPORT(GasRadGain);GAIN_REPORT(GasConGain);GAIN_REPORT(GasLatGain);GAIN_REPORT(GasLost);GAIN_REPORT(GasTotGain);GAIN_REPORT(GasRadGainRate);GAIN_REPORT(GasConGainRate);GAIN_REPORT(GasLatGainRate);GAIN_REPORT(GasLostRate);GAIN_REPORT(GasTotGainRate);GAIN_REPORT(HWPower);GAIN_REPORT(HWConsump);GAIN_REPORT(HWRadGain);GAIN_REPORT(HWConGain);GAIN_REPORT(HWLatGain);GAIN_REPORT(HWLost);GAIN_REPORT(HWTotGain);GAIN_REPORT(HWRadGainRate);GAIN_REPORT(HWConGainRate);GAIN_REPORT(HWLatGainRate);GAIN_REPORT(HWLostRate);GAIN_REPORT(HWTotGainRate);GAIN_REPORT(SteamPower);GAIN_REPORT(SteamConsump);GAIN_REPORT(SteamRadGain);GAIN_REPORT(SteamConGain);GAIN_REPORT(SteamLatGain);GAIN_REPORT(SteamLost);GAIN_REPORT(SteamTotGain);GAIN_REPORT(SteamRadGainRate);GAIN_REPORT(SteamConGainRate);GAIN_REPORT(SteamLatGainRate);GAIN_REPORT(SteamLostRate);GAIN_REPORT(SteamTotGainRate);GAIN_REPORT(OtherRadGain);GAIN_REPORT(OtherConGain);GAIN_REPORT(OtherLatGain);GAIN_REPORT(OtherLost);GAIN_REPORT(OtherTotGain);GAIN_REPORT(OtherRadGainRate);GAIN_REPORT(OtherConGainRate);GAIN_REPORT(OtherLatGainRate);GAIN_REPORT(OtherLostRate);GAIN_REPORT(OtherTotGainRate);GAIN_REPORT(ITEqAirVolFlowStdDensity);GAIN_REPORT(ITEqAirMassFlow);GAIN_REPORT(ITEqSHI);GAIN_REPORT(ITEqTimeOutOfOperRange);GAIN_REPORT(ITEqTimeAboveDryBulbT);GAIN_REPORT(ITEqTimeBelowDryBulbT);GAIN_REPORT(ITEqTimeAboveDewpointT);GAIN_REPORT(ITEqTimeBelowDewpointT);GAIN_REPORT(ITEqTimeAboveRH);GAIN_REPORT(ITEqTimeBelowRH);GAIN_REPORT(ITEAdjReturnTemp);GAIN_REPORT(TotRadiantGain);GAIN_REPORT(TotVisHeatGain);GAIN_REPORT(TotConvectiveGain);GAIN_REPORT(TotLatentGain);GAIN_REPORT(TotTotalHeatGain);GAIN_REPORT(TotRadiantGainRate);GAIN_REPORT(TotVisHeatGainRate);GAIN_REPORT(TotConvectiveGainRate);GAIN_REPORT(TotLatentGainRate);GAIN_REPORT(TotTotalHeatGainRate);GAIN_REPORT(CO2Rate);GAIN_REPORT(GCRate);GAIN_REPORT(SumTinMinusTSup);GAIN_REPORT(SumToutMinusTSup);
#undef GAIN_REPORT
    for(auto x:e.OtherPower){v["OtherPower"].push_back(raw(x));}
    for(auto x:e.OtherConsump){v["OtherConsump"].push_back(raw(x));}
    return v;
}
json gain_state(EnergyPlusData const&s){json out{{"state_address",address(&s)},{"manager_address",address(s.dataInternalHeatGains.get())},{"GetInternalHeatGainsInputFlag",s.dataInternalHeatGains->GetInternalHeatGainsInputFlag},{"NumOfZones",s.dataGlobal->NumOfZones},{"numSpaces",s.dataGlobal->numSpaces},{"TotSurfaces",s.dataSurface->TotSurfaces},{"radiant_enclosures",s.dataViewFactor->NumOfRadiantEnclosures},{"solar_enclosures",s.dataViewFactor->NumOfSolarEnclosures},{"TimeStepZoneSec",raw(s.dataGlobal->TimeStepZoneSec)},{"BeginEnvrnFlag",s.dataGlobal->BeginEnvrnFlag},{"HourOfDay",s.dataGlobal->HourOfDay},{"TimeStep",s.dataGlobal->TimeStep},{"counts",json::object()},{"equipment",json::array()},{"zone_reports",json::array()},{"space_reports",json::array()},{"spaces",json::array()},{"diagnostics",diagnostics(s)}};
#define GAIN_COUNT(m) out["counts"][#m]=s.dataHeatBal->m
    GAIN_COUNT(TotPeople);GAIN_COUNT(TotLights);GAIN_COUNT(TotElecEquip);GAIN_COUNT(TotGasEquip);GAIN_COUNT(TotHWEquip);GAIN_COUNT(TotStmEquip);GAIN_COUNT(TotOthEquip);GAIN_COUNT(TotITEquip);GAIN_COUNT(TotBBHeat);GAIN_COUNT(TotCO2Gen);
#undef GAIN_COUNT
    for(auto const&e:s.dataHeatBal->ZoneOtherEq)out["equipment"].push_back(gain_equipment(e));
    for(auto const&e:s.dataHeatBal->ZoneRpt)out["zone_reports"].push_back(gain_report(e));
    for(auto const&e:s.dataHeatBal->spaceRpt)out["space_reports"].push_back(gain_report(e));
    out["zone_air_latent"]=json::array();out["space_air_latent"]=json::array();
    for(auto const&e:s.dataZoneTempPredictorCorrector->zoneHeatBalance)out["zone_air_latent"].push_back({{"address",address(&e)},{"latentGain",raw(e.latentGain)}});
    for(auto const&e:s.dataZoneTempPredictorCorrector->spaceHeatBalance)out["space_air_latent"].push_back({{"address",address(&e)},{"latentGain",raw(e.latentGain)}});
    out["zone_int_gain"]=json::array();out["space_int_gain"]=json::array();
    for(auto const&e:s.dataHeatBal->ZoneIntGain)out["zone_int_gain"].push_back({{"address",address(&e)},{"NOFOCC",raw(e.NOFOCC)},{"QLTSW",raw(e.QLTSW)}});
    for(auto const&e:s.dataHeatBal->spaceIntGain)out["space_int_gain"].push_back({{"address",address(&e)},{"NOFOCC",raw(e.NOFOCC)},{"QLTSW",raw(e.QLTSW)}});
    if(s.dataHeatBal->spaceIntGainDevices.allocated())for(int i=1;i<=s.dataGlobal->numSpaces;++i){auto const&owner=s.dataHeatBal->spaceIntGainDevices(i);json r{{"ordinal",i},{"address",address(&owner)},{"numberOfDevices",owner.numberOfDevices},{"maxNumberOfDevices",owner.maxNumberOfDevices},{"device_storage",shape(owner.device)},{"devices",json::array()}};
        for(int j=1;j<=owner.numberOfDevices;++j){auto const&d=owner.device(j);json v{{"address",address(&d)},{"CompObjectName",d.CompObjectName},{"CompType",static_cast<int>(d.CompType)},{"spaceGainFrac",raw(d.spaceGainFrac)},{"ReturnAirNodeNum",d.ReturnAirNodeNum},{"pointers",json::object()},{"values",json::object()}};
#define GAIN_DEVICE(m) v["values"][#m]=raw(d.m)
            GAIN_DEVICE(ConvectGainRate);GAIN_DEVICE(ReturnAirConvGainRate);GAIN_DEVICE(RadiantGainRate);GAIN_DEVICE(LatentGainRate);GAIN_DEVICE(ReturnAirLatentGainRate);GAIN_DEVICE(CarbonDioxideGainRate);GAIN_DEVICE(GenericContamGainRate);
#undef GAIN_DEVICE
#define GAIN_POINTER(m) v["pointers"][#m]=address(d.m)
            GAIN_POINTER(PtrConvectGainRate);GAIN_POINTER(PtrReturnAirConvGainRate);GAIN_POINTER(PtrRadiantGainRate);GAIN_POINTER(PtrLatentGainRate);GAIN_POINTER(PtrReturnAirLatentGainRate);GAIN_POINTER(PtrCarbonDioxideGainRate);GAIN_POINTER(PtrGenericContamGainRate);
#undef GAIN_POINTER
            r["devices"].push_back(v);
        }out["spaces"].push_back(r);
    }
    auto const&r=*s.dataRefrigCase;out["refrigeration"]={{"address",address(&r)},{"GetRefrigerationInputFlag",r.GetRefrigerationInputFlag},{"ManageRefrigeration",r.ManageRefrigeration},{"HaveCasesOrWalkins",r.HaveCasesOrWalkins},{"HaveChillers",r.HaveChillers},{"NumRefrigSystems",r.NumRefrigSystems},{"NumTransRefrigSystems",r.NumTransRefrigSystems},{"NumRefrigeratedRacks",r.NumRefrigeratedRacks},{"NumSimulationCases",r.NumSimulationCases},{"NumSimulationWalkIns",r.NumSimulationWalkIns},{"NumSimulationRefrigAirChillers",r.NumSimulationRefrigAirChillers},{"RefrigPresentInZone",shape(r.RefrigPresentInZone)}};
    out["zone_category_end_use"]=json::array();for(auto const&e:s.dataHeatBal->ZoneIntEEuse)out["zone_category_end_use"].push_back({{"address",address(&e)},{"EEConvected",consumer_vector(e.EEConvected,true)},{"EERadiated",consumer_vector(e.EERadiated,true)},{"EELost",consumer_vector(e.EELost,true)},{"EELatent",consumer_vector(e.EELatent,true)}});
    out["actual_electric_service_address"]=address(s.dataElectPwrSvcMgr->facilityElectricServiceObj.get());return out;
}
json internal_gain_producer_case(json const&c,ExteriorProgress const&observer){auto f=producer_input(c,observer);auto&s=*f.value;bool error=false;f.checkpoint("HeatBalanceManager::GetZoneData");HeatBalanceManager::GetZoneData(s,error);require(!error,"real gain GetZoneData");f.checkpoint("ZoneEquipmentManager::GetZoneEquipment");ZoneEquipmentManager::GetZoneEquipment(s);f.checkpoint("HeatBalanceManager::AllocateHeatBalArrays");HeatBalanceManager::AllocateHeatBalArrays(s);
    require(s.dataInputProcessing->inputProcessor->getNumObjectsFound(s,"BuildingSurface:Detailed")==0&&s.dataSurface->TotSurfaces==0,"original no-surface unit domain, no invented geometry count");
    require(s.dataGlobal->NumOfZones==1&&s.dataGlobal->numSpaces==1,"actual getter-produced finite zone/space domain");
    json out{{"name",c.at("name")},{"input",c},{"scope","full original ManageInternalHeatGains GetInput/Init/Report/CheckReturn, genuine OtherEquipment unit domain; no surface radiant-distribution claim"},{"lifetime","one real state; actual schedule updates, no output or latch restores"},{"before_getter",gain_state(s)},{"calls",json::array()}};
    f.checkpoint("InternalHeatGains::ManageInternalHeatGains true");InternalHeatGains::ManageInternalHeatGains(s,true);out["after_getter"]=gain_state(s);
    for(auto const&p:c.at("steps")){f.checkpoint("actual schedule update / InternalHeatGains::ManageInternalHeatGains false");producer_clock(s,p);json before=gain_state(s);InternalHeatGains::ManageInternalHeatGains(s,false);out["calls"].push_back({{"primary_clock",p},{"before",before},{"after",gain_state(s)}});}return out;
}
template<class A>json producer_integers(A const&a){auto out=shape(a);out["values"]=json::array();if(a.allocated())for(int i=a.l();i<=a.u();++i)out["values"].push_back(a(i));return out;}
json beam_producer_state(EnergyPlusData const&s){auto const&m=*s.dataSolarShading;auto const&h=*s.dataHeatBal;int hour=s.dataGlobal->HourOfDay,step=s.dataGlobal->TimeStep;json out{{"state_address",address(&s)},{"module_address",address(&m)},{"HourOfDay",hour},{"TimeStep",step},{"BeginSimFlag",s.dataGlobal->BeginSimFlag},{"BeginEnvrnFlag",s.dataGlobal->BeginEnvrnFlag},{"GetInputFlag",m.GetInputFlag},{"firstTime",m.firstTime},{"ShadowOneTimeFlag",m.ShadowOneTimeFlag},{"NumOfZones",s.dataGlobal->NumOfZones},{"numSpaces",s.dataGlobal->numSpaces},{"TotSurfaces",s.dataSurface->TotSurfaces},{"MaxVerticesPerSurface",s.dataSurface->MaxVerticesPerSurface},{"SolarDistribution",static_cast<int>(h.SolarDistribution)},{"ShadingTransmittanceVaries",s.dataSurface->ShadingTransmittanceVaries},{"DetailedSkyDiffuseAlgorithm",s.dataSysVars->DetailedSkyDiffuseAlgorithm},{"DetailedSolarTimestepIntegration",s.dataSysVars->DetailedSolarTimestepIntegration},{"SUNCOS",{raw(m.SUNCOS.x),raw(m.SUNCOS.y),raw(m.SUNCOS.z)}},{"surfaces",json::array()},{"shadow_combinations",json::array()},{"diagnostics",diagnostics(s)}};
    for(int i=1;i<=s.dataSurface->TotSurfaces;++i){auto const&v=s.dataSurface->Surface(i);json row{{"ordinal",i},{"address",address(&v)},{"Name",v.Name},{"Class",static_cast<int>(v.Class)},{"Construction",v.Construction},{"Zone",v.Zone},{"BaseSurf",v.BaseSurf},{"Sides",v.Sides},{"ExtSolar",v.ExtSolar},{"IsShadowing",v.IsShadowing},{"OutNormVec",{raw(v.OutNormVec.x),raw(v.OutNormVec.y),raw(v.OutNormVec.z)}},{"Area",raw(v.Area)},{"NetAreaShadowCalc",raw(v.NetAreaShadowCalc)},{"vertices",json::array()},{"SurfSunCosTheta",raw(m.SurfSunCosTheta(i))},{"SurfSunlitArea",raw(m.SurfSunlitArea(i))},{"current_SurfCosIncAngHR",raw(h.SurfCosIncAngHR(hour,i))},{"current_SurfCosIncAng",raw(h.SurfCosIncAng(hour,step,i))},{"current_SurfSunlitFracHR",raw(h.SurfSunlitFracHR(hour,i))},{"current_SurfSunlitFrac",raw(h.SurfSunlitFrac(hour,step,i))},{"isotropic_ratio_HRTS",nullptr},{"horizon_ratio_HRTS",nullptr}};
        if(m.SurfDifShdgRatioIsoSkyHRTS.allocated())row["isotropic_ratio_HRTS"]=raw(m.SurfDifShdgRatioIsoSkyHRTS(step,hour,i));
        if(m.SurfDifShdgRatioHorizHRTS.allocated())row["horizon_ratio_HRTS"]=raw(m.SurfDifShdgRatioHorizHRTS(step,hour,i));
        for(int j=1;j<=v.Sides;++j){auto const&p=v.Vertex(j);row["vertices"].push_back({raw(p.x),raw(p.y),raw(p.z)});}out["surfaces"].push_back(row);
    }
    if(s.dataShadowComb->ShadowComb.allocated())for(int i=1;i<=s.dataSurface->TotSurfaces;++i){auto const&v=s.dataShadowComb->ShadowComb(i);out["shadow_combinations"].push_back({{"ordinal",i},{"address",address(&v)},{"UseThisSurf",v.UseThisSurf},{"NumGenSurf",v.NumGenSurf},{"GenSurf",producer_integers(v.GenSurf)},{"NumBackSurf",v.NumBackSurf},{"BackSurf",producer_integers(v.BackSurf)},{"NumSubSurf",v.NumSubSurf},{"SubSurf",producer_integers(v.SubSurf)}});}
    out["SurfSunCosTheta_all"]=consumer_vector(m.SurfSunCosTheta,true);out["SurfSunlitArea_all"]=consumer_vector(m.SurfSunlitArea,true);out["SurfIntAbsFac"]=consumer_vector(m.SurfIntAbsFac,true);
    out["actual_shadow_scratch"]={{"XVrt",shape(m.XVrt)},{"YVrt",shape(m.YVrt)},{"ZVrt",shape(m.ZVrt)}};
    // SHADOW polygon scratch has branch-specific definitions: shapes only.
    // Full externally consumed outputs above have genuine allocator writers.
    return out;
}
json beam_producer_case(json const&c,ExteriorProgress const&observer){auto f=producer_input(c,observer);auto&s=*f.value;
    // These are real caller phase/transport operands, not manager ready flags.
    s.dataGlobal->BeginSimFlag=true;s.dataGlobal->BeginEnvrnFlag=true;
    s.dataStrGlobals->outputShdFilePath=c.at("native_shd_file").get<std::string>();
    f.checkpoint("Weather::GetLocationInfo / CheckLocationValidity");bool error=false;Weather::GetLocationInfo(s,error);require(!error,"actual location getter");Weather::CheckLocationValidity(s);
    f.checkpoint("HeatBalanceManager::GetHeatBalanceInput");HeatBalanceManager::GetHeatBalanceInput(s);f.checkpoint("HeatBalanceManager::AllocateHeatBalArrays / HeatBalanceSurfaceManager::AllocateSurfaceHeatBalArrays");HeatBalanceManager::AllocateHeatBalArrays(s);HeatBalanceSurfaceManager::AllocateSurfaceHeatBalArrays(s);
    require(s.dataGlobal->NumOfZones==1&&s.dataGlobal->numSpaces==1,"actual finite geometry identity");
    require(s.dataInputProcessing->inputProcessor->getNumObjectsFound(s,"FenestrationSurface:Detailed")==0,"no-window primary geometry input");
    // Genuine caller primary calendar/time, before the first schedule-consuming
    // sky/shadow call. Original unit sets these before InitSolar/SkyDif too.
    // Use only the named first step; no current schedule value, output, count,
    // getter flag, or allocation/latch is assigned by this handoff.
    f.checkpoint("named primary setup calendar before InitSolarCalculations/SkyDif");
    auto const &setup_clock = c.at("steps").at(0);
    int const setup_day = setup_clock.at("day_of_year").get<int>();
    int const setup_weekday = setup_clock.at("day_of_week").get<int>();
    int const setup_hour = setup_clock.at("hour").get<int>();
    int const setup_timestep = setup_clock.at("timestep").get<int>();
    require(setup_day >= 1 && setup_day <= 366 && setup_weekday >= 1 && setup_weekday <= 7 &&
            setup_hour >= 1 && setup_hour <= 24 && setup_timestep >= 1 &&
            setup_timestep <= s.dataGlobal->TimeStepsInHour, "named genuine setup calendar/time bounds");
    s.dataEnvrn->DayOfYear_Schedule = setup_day;
    s.dataEnvrn->DayOfYear = setup_day;
    s.dataEnvrn->DayOfWeek = setup_weekday;
    s.dataGlobal->HourOfDay = setup_hour;
    s.dataGlobal->TimeStep = setup_timestep;
    // BeginSimFlag/BeginEnvrnFlag retain their existing true caller phase.
    f.checkpoint("SolarShading::InitSolarCalculations");SolarShading::InitSolarCalculations(s); // real GetInput, allocation and DetermineShadowingCombinations
    // Literal CalcPerSolarBeam caller phase prefix, also used by the original
    // beam unit: this flag selects sky-patch incidence, never skips a getter.
    f.checkpoint("SolarShading::SkyDifSolarShading");s.dataSolarShading->CalcSkyDifShading=true;SolarShading::SkyDifSolarShading(s);s.dataSolarShading->CalcSkyDifShading=false;
    require(!s.dataSolarShading->GetInputFlag&&!s.dataSolarShading->firstTime,"actual original init returned through latch writers");
    if(c.at("require_positive_casting").get<bool>()){bool positive=false;for(auto const&v:s.dataShadowComb->ShadowComb)if(v.UseThisSurf&&v.NumGenSurf>0)positive=true;require(positive,"actual geometry producer did not yield named positive casting domain");}
    s.dataGlobal->BeginSimFlag=false;s.dataGlobal->BeginEnvrnFlag=false;
    json out{{"name",c.at("name")},{"input",c},{"scope","full original FigureSolarBeamAtTimestep and SHADOW, true original input/geometry/shadow-combination producer and actual Weather return handoff"},{"lifetime","one Native owner; initial allocator outputs remain genuine; no count/latch/output restores"},{"calls",json::array()}};
    for(auto const&p:c.at("steps")){f.checkpoint("actual schedule / Weather solar returns / SolarShading::FigureSolarBeamAtTimestep");producer_clock(s,p);double a,b,d,annual,eq,sin_decl,cos_decl;Weather::CalculateDailySolarCoeffs(s,p.at("day_of_year").get<int>(),a,b,d,annual,eq,sin_decl,cos_decl);Vector3<Real64>direction;double time=real(p.at("time"));Weather::CalculateSunDirectionCosines(s,time,eq,sin_decl,cos_decl,direction);
        int hour=s.dataGlobal->HourOfDay,step=s.dataGlobal->TimeStep;s.dataBSDFWindow->SUNCOSTS(step,hour)=direction;
        json before=beam_producer_state(s);SolarShading::FigureSolarBeamAtTimestep(s,hour,step);out["calls"].push_back({{"primary_clock",p},{"actual_weather_direction",{raw(direction.x),raw(direction.y),raw(direction.z)}},{"actual_daily_returns",{{"A",raw(a)},{"B",raw(b)},{"C",raw(d)},{"AnnVarSolConstant",raw(annual)},{"EquationOfTime",raw(eq)},{"SinDecl",raw(sin_decl)},{"CosDecl",raw(cos_decl)}}},{"before",before},{"after",beam_producer_state(s)}});
    }return out;
}

template<class A>json producer_matrix(A const&a){auto out=shape(a);out["values"]=json::array();if(a.allocated()){out["lower1"]=a.l1();out["upper1"]=a.u1();out["lower2"]=a.l2();out["upper2"]=a.u2();for(int j=a.l2();j<=a.u2();++j)for(int i=a.l1();i<=a.u1();++i)out["values"].push_back(raw(a(i,j)));}return out;}
json gain_surface_state(EnergyPlusData const&s){json out=gain_state(s);out["radiant_enclosures"]=json::array();out["solar_enclosures"]=json::array();out["surface_rows"]=json::array();
    for(auto const&e:s.dataViewFactor->EnclRadInfo)out["radiant_enclosures"].push_back({{"address",address(&e)},{"Name",e.Name},{"NumOfSurfaces",e.NumOfSurfaces},{"spaceNums",e.spaceNums},{"SurfacePtr",producer_integers(e.SurfacePtr)},{"Area",consumer_vector(e.Area,true)},{"Emissivity",consumer_vector(e.Emissivity,true)},{"F",producer_matrix(e.F)},{"ScriptF",producer_matrix(e.ScriptF)},{"radReCalc",e.radReCalc},{"radThermAbsMult",raw(e.radThermAbsMult)},{"radQThermalRad",raw(e.radQThermalRad)}});
    for(auto const&e:s.dataViewFactor->EnclSolInfo)out["solar_enclosures"].push_back({{"address",address(&e)},{"Name",e.Name},{"NumOfSurfaces",e.NumOfSurfaces},{"spaceNums",e.spaceNums},{"SurfacePtr",producer_integers(e.SurfacePtr)},{"Area",consumer_vector(e.Area,true)},{"SolAbsorptance",consumer_vector(e.SolAbsorptance,true)},{"F",producer_matrix(e.F)},{"radReCalc",e.radReCalc},{"solVMULT",raw(e.solVMULT)},{"solAbsFirstCalc",e.solAbsFirstCalc}});
    for(int i=1;i<=s.dataSurface->TotSurfaces;++i){auto const&v=s.dataSurface->Surface(i);out["surface_rows"].push_back({{"ordinal",i},{"address",address(&v)},{"Name",v.Name},{"Construction",v.Construction},{"RadEnclIndex",v.RadEnclIndex},{"SolarEnclIndex",v.SolarEnclIndex},{"Area",raw(v.Area)},{"inside_thermal_absorptance",raw(s.dataHeatBalSurf->SurfAbsThermalInt(i))},{"inside_solar_absorptance",raw(s.dataHeatBalSurf->SurfAbsSolarInt(i))},{"SurfQdotRadIntGainsInPerArea",raw(s.dataHeatBal->SurfQdotRadIntGainsInPerArea(i))}});}return out;
}
json internal_gain_surface_producer_case(json const&c,ExteriorProgress const&observer){auto f=producer_input(c,observer);auto&s=*f.value;s.dataGlobal->BeginSimFlag=true;s.dataGlobal->BeginEnvrnFlag=true;
    f.checkpoint("HeatBalanceManager::GetHeatBalanceInput");HeatBalanceManager::GetHeatBalanceInput(s);f.checkpoint("HeatBalanceManager::AllocateHeatBalArrays / HeatBalanceSurfaceManager::AllocateSurfaceHeatBalArrays");HeatBalanceManager::AllocateHeatBalArrays(s);HeatBalanceSurfaceManager::AllocateSurfaceHeatBalArrays(s);
    require(s.dataGlobal->NumOfZones==1&&s.dataGlobal->numSpaces==1,"actual positive surface-gain zone/space domain");require(s.dataInputProcessing->inputProcessor->getNumObjectsFound(s,"FenestrationSurface:Detailed")==0,"actual opaque input");
    f.checkpoint("HeatBalanceIntRadExchange::InitInteriorRadExchange");HeatBalanceIntRadExchange::InitInteriorRadExchange(s);
    // Exact metadata-only InitSurfaceHeatBalance365-366 caller handoff.
    // The actual getter-produced construction members supply physical inputs;
    // no area sum, absorption multiplier, view factor, or gain answer is seeded.
    for(int z=1;z<=s.dataGlobal->NumOfZones;++z)for(int p:s.dataHeatBal->Zone(z).spaceIndexes){auto const&space=s.dataHeatBal->space(p);for(int i=space.HTSurfaceFirst;i<=space.HTSurfaceLast;++i){auto const&construction=s.dataConstruction->Construct(s.dataSurface->SurfActiveConstruction(i));s.dataHeatBalSurf->SurfAbsSolarInt(i)=construction.InsideAbsorpSolar;s.dataHeatBalSurf->SurfAbsThermalInt(i)=construction.InsideAbsorpThermal;}}
    f.checkpoint("SolarShading::CheckGlazingShadingStatusChange / actual absorption factors");SolarShading::CheckGlazingShadingStatusChange(s); // actual BeginEnvrn recalc writer
    HeatBalanceSurfaceManager::ComputeIntThermalAbsorpFactors(s);HeatBalanceSurfaceManager::ComputeIntSWAbsorpFactors(s);
    require(!s.dataInternalHeatGains->GetInternalHeatGainsInputFlag,"actual full HB getter ran the real IHG input routine");
    s.dataGlobal->BeginSimFlag=false;s.dataGlobal->BeginEnvrnFlag=false;
    json out{{"name",c.at("name")},{"input",c},{"scope","full ManageInternalHeatGains with positive actual geometry/enclosure and original absorption producers; no full InitSurfaceHeatBalance/caller equivalence"},{"setup",gain_surface_state(s)},{"calls",json::array()}};
    for(auto const&p:c.at("steps")){f.checkpoint("actual schedule update / InternalHeatGains::ManageInternalHeatGains false");producer_clock(s,p);json before=gain_surface_state(s);InternalHeatGains::ManageInternalHeatGains(s,false);out["calls"].push_back({{"primary_clock",p},{"before",before},{"after",gain_surface_state(s)}});}return out;
}

} // namespace
nlohmann::json run_exterior_batch(nlohmann::json const&input,std::string const&checkpoint_path){
    require(input.at("schema")=="src06-exterior-gap-input.v1","exterior input schema");
    json out{{"schema","src06-original-exterior-gap-output.v1"},{"solar_clock",json::array()},
             {"exterior_coefficients",json::array()},{"absorption",json::array()},{"solar_surface",json::array()}};
    ExteriorProgress observer{checkpoint_path,out};
    for(auto const&c:input.value("solar_clock",json::array())){out["solar_clock"].push_back(solar_case(c));observer.write();}
    for(auto const&c:input.value("exterior_coefficients",json::array())){out["exterior_coefficients"].push_back(exterior_case(c));observer.write();}
    for(auto const&c:input.value("absorption",json::array())){out["absorption"].push_back(absorption_case(c));observer.write();}
    for(auto const&c:input.value("solar_surface",json::array())){out["solar_surface"].push_back(solar_consumer_case(c));observer.write();}
    out["internal_gains"]=json::array();out["beam_producer"]=json::array();
    for(auto const&c:input.value("internal_gains",json::array())){out["internal_gains"].push_back(internal_gain_producer_case(c,observer));observer.write();}
    for(auto const&c:input.value("beam_producer",json::array())){out["beam_producer"].push_back(beam_producer_case(c,observer));observer.write();}
    out["surface_internal_gains"]=json::array();
    for(auto const&c:input.value("surface_internal_gains",json::array())){out["surface_internal_gains"].push_back(internal_gain_surface_producer_case(c,observer));observer.write();}
    return out;
}
// Existing one-argument callers retain their ABI and all scientific behavior.
nlohmann::json run_exterior_batch(nlohmann::json const&input){return run_exterior_batch(input,std::string{});}
} // namespace NativeGapBatch

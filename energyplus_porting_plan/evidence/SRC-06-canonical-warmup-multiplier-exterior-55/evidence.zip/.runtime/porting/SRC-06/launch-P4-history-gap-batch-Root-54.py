"""Root-only sequential selectedOP then history; never invokes old scientific groups."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
s=importlib.util.spec_from_file_location('guard54',D/'gap-P4-history-guards-Peer-54.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
def main(a):
 app_ref=g.argument(a.application);app=g.read(g.checked(app_ref));g.need(g.checked(app_ref)==(h.APP/'receipt.json').resolve() and app['accepted'] and not app['findings'],'Exact accepted application54')
 _,p,draft,union=h.prepared(app['prepared']['path']+'#'+app['prepared']['sha256']);g.need(g.checked(p['launch_Source'])==Path(__file__).resolve(),'Exact launcher Source');h.current_head(app['base_HEAD'])
 plan=g.read(g.checked(app['complete_compiler_plan']));rows={x['path']:x for x in plan['entries']};g.exact(rows)
 fixture_map,protected=h.fixtures(p,draft,union);g.need(fixture_map==app['fixtures'] and protected==app['protected_all_four_external_fixtures'],'Same all4 fixture bindings')
 if a.group=='air_history':
  prior_path=D/'canonical-source-gap-batch-output_processor-Root-54/receipt.json';prior=g.read(prior_path);g.need(prior['source_bytes_match_before_and_after'] and prior['launch_error'] is None,'Prior selected OP attempt completed unchanged')
  err=R/prior['stderr']['path'];g.need(g.ref(err)['sha256']==prior['stderr']['sha256'] and 'Running src\\lib.rs (' in err.read_text(encoding='utf-8'),'OP compilation completed before reusing selected history binary')
 env_spec=importlib.util.spec_from_file_location('exact_env54',g.checked(p['environment_guard']));envmod=importlib.util.module_from_spec(env_spec);env_spec.loader.exec_module(envmod);env=envmod.environment()
 g.need(env['CARGO_INCREMENTAL']=='0','No incremental compilation');fixture=fixture_map[a.group];command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',a.group,str(g.checked(fixture))]
 output=D/('canonical-source-gap-batch-'+a.group+'-Root-54');guard=D/('Root-runtime-fixture-'+a.group+'-guard-54');g.need(not output.exists() and not guard.exists(),'Fresh selected command/guard paths');guard.mkdir();before=[g.ref(g.checked(v))for v in protected]
 (guard/'before.json').write_text(json.dumps(dict(application=app_ref,selected_group=a.group,command=command,protected=before,all_four_fixtures=fixture_map),indent=2)+'\n',encoding='utf-8',newline='\n')
 print('Root54: only selected '+a.group+'; priorP1/Surface/2336/471/59/P2 bodies are not invoked.',flush=True)
 code=subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',output.relative_to(R).as_posix(),'--',*command],cwd=R,env=env)
 after=[g.ref(g.checked(v))for v in protected];g.exact(rows);result=dict(schema='src06-four-runtime-fixture-custody54.v1',accepted=before==after,findings=[]if before==after else['External fixture changed'],application=app_ref,selected_group=a.group,command=command,exit_code=code,protected_before=before,protected_after=after,all_four_fixtures=fixture_map,all4538_compiler_inputs_unchanged=True,actual_receipt=g.ref(output/'receipt.json'),launch_Source=g.ref(Path(__file__)))
 (guard/'after.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');return code if before==after else 1
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--application',required=True);p.add_argument('--group',required=True,choices=['output_processor','air_history']);raise SystemExit(main(p.parse_args()))

"""Metadata-only exact scope-ref correction; preserve group01 and all Sources."""
from pathlib import Path
import difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Exterior-group-draft-Outer-02'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def main():
 assert not O.exists();a=D/'source-Exterior-group-draft-Outer-01/draft.json';old=a.read_bytes();v=json.loads(old)
 proof=json.loads((D/'source-Exterior-runtime-fixture-Outer-01/proof.json').read_bytes())
 assert v['Source_finite_scope'] is None
 v['Source_finite_scope']=proof['scope_classification'];v['preserved01_metadata']=ref(a);v['author_Source']=ref(Path(__file__))
 v['metadata_correction']='The01 scope-ref alias lookup recorded null.02 binds actual proof.scope_classification; all three Source wholes, literal diffs and syntax refs remain unchanged.'
 for row in v['Sources']:
  p=R/row['proposed']['path'];assert ref(p)==row['proposed']
 new=(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode();O.mkdir();p=O/'draft.json';p.write_bytes(new)
 for name,x,y in [('forward',old,new),('inverse',new,old)]:
  (O/f'{name}.diff').write_bytes(''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile='preserved01',tofile='scope-ref02')).encode())
 print(json.dumps(ref(p)))
if __name__=='__main__':main()

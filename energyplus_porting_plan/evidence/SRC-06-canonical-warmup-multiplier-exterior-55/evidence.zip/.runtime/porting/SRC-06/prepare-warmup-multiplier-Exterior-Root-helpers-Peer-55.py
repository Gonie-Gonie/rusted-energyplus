"""Private read-only Root55 preparation: exact54 parent,38 deltas and seven fixtures."""
from pathlib import Path
import ast,difflib,hashlib,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'warmup-multiplier-Exterior-Root-helpers-ready-Peer-55'
def main():
 s=importlib.util.spec_from_file_location('prepared55_readonly',D/'gap-warmup-multiplier-Exterior-guards-Peer-55.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
 g.need(not O.exists(),'Fresh immutable Root55 preparation');O.mkdir()
 def save(path,v):path.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');return g.ref(path)
 dr=g.ref(D/'source-Exterior-warmup-multiplier-coherent-Outer-55/manifest.json');d=g.read(g.checked(dr))
 linkref=g.ref(D/'source-Exterior-warmup-multiplier-coherent-Outer-55/leaf-semantic-peer-links.json');links=g.read(g.checked(linkref));g.need(links['coherent_manifest']==dr,'Exact13 peer documents/14 leaf links')
 names=['gap-warmup-multiplier-Exterior-guards-Peer-55.py','apply-warmup-multiplier-Exterior-Root-55.py','launch-warmup-multiplier-Exterior-Root-55.py','check-Source-warmup-multiplier-Exterior-actual-Root-55.py']
 parents=['gap-P4-history-guards-Peer-54.py','apply-P4-history-gap-batch-Root-54.py','launch-P4-history-gap-batch-Root-54.py','check-Source-P4-history-actual-Root-54-02.py']
 delta=[];apply=g.literal()
 for name,parent in zip(names,parents,strict=True):
  a=(D/parent).read_bytes();b=(D/name).read_bytes();ast.parse(b.decode('utf-8'));g.need(b'\r'not in b,'New helper LF');diffs={}
  for kind,x,y in [('forward',a,b),('inverse',b,a)]:
   p=O/(name+'.'+kind+'.diff');p.write_text(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n');g.need(apply(x,p.read_bytes())==y,'Full helper parent literal '+kind);diffs[kind]=g.ref(p)
  delta.append(dict(before=g.ref(D/parent),proposed=g.ref(D/name),diffs=diffs,syntax_only=True))
 de=save(O/'helper-full-parent-forward-inverse.json',dict(schema='src06-Root55-helper-full54-parent-deltas.v1',files=delta,literal_applications=8,Python_syntax_parses=4,execution=False))
 p=dict(schema='src06-warmup-multiplier-Exterior-Root55-preparation.v1',status='READY_FOR_ROOT_ONE_APPLICATION_THREE_SELECTED_GROUPS',base_HEAD=d['base_HEAD'],draft=dr,
  joint_independent_peer=g.ref(D/'Root-coherent-Source-independent-review-55/review.json'),semantic_link_table=linkref,semantic_peers=links['leaf_semantic_pairs'],
  prior_actual_review=g.ref(D/'Root-Source-P4-history-actual-review-54/review.json'),prior_prepared=g.ref(D/'P4-history-Root-helpers-ready-Peer-54/prepared.json'),prior_compiler_plan=d['prior_complete_compiler_Source_plan'],complete_compiler_plan=d['complete_proposed_compiler_Source_plan'],
  fixture_proofs=dict(warmup=g.ref(D/'source-warmup-runtime-fixture-Audit-01/projection.json'),multiplier_predictor=g.ref(D/'source-multiplier-runtime-fixture-Peer-01/projection.json'),exterior=g.ref(D/'source-Exterior-runtime-fixture-Outer-01/proof.json')),
  guard_Source=g.ref(D/names[0]),application_Source=g.ref(D/names[1]),launch_Source=g.ref(D/names[2]),actual_checker_Source=g.ref(D/names[3]),environment_guard=g.ref(D/'hard-size-command-guards-Peer-43.py'),record_command_Source=g.ref(R/'tools/porting/record_command.py'),
  inherited_guard_dependencies=[g.ref(D/x)for x in ['gap-P4-history-guards-Peer-54.py','apply-Source-gap-batch-Root-50.py','apply-purchased-air-gap-cohort-Root-P1.py','seal-compact-annual-daygroup-helper-Peer-01.py']],helper_full_deltas=de,
  expected_before=dict(compiler_inputs=4538,Rust_sources=4525),expected_after=dict(compiler_inputs=4554,Rust_sources=4541,Source_files=38,existing=22,new=16),selected_groups_in_order=h.GROUPS,
  exact_application_receipt_path=(h.APP/'receipt.json').relative_to(R).as_posix(),focused_command_outputs=['.runtime/porting/SRC-06/canonical-source-gap-batch-'+x+'-Root-55'for x in h.GROUPS],exact_aggregate_path='.runtime/porting/SRC-06/Root-Source-warmup-multiplier-Exterior-actual-review-55/review.json',
  qualifications=['One Root-only application, one contextual Cargo rebuild, three fresh selected process-main commands only. All previous P1/Surface/P2/2336/471/59/P4/history groups skipped.','Whole seven external fixtures/provenance protected before and after each command. Source primary inputs are distinct from expected-only complete Native documents.','Exterior retains179 Native records, executes170 admitted records and explicitly excludes9 exploratory shading records outside finite CON01 admission. No whole final15/private-cache/warmup-parent-cadence claim.'],
  canonical_Cargo_Native_or_test_execution=False,author_Source=g.ref(Path(__file__)))
 pr=save(O/'prepared.json',p);_,p,d=h.prepared(pr['path']+'#'+pr['sha256']);h.current_head(p['base_HEAD']);g.need(not subprocess.check_output(['git','status','--porcelain'],cwd=R),'Current54 clean committed parent')
 old=g.read(g.checked(p['prior_compiler_plan']));g.need(h.counts(old)==(4538,4525,4538),'Exact54 parent');before={x['path']:x for x in old['entries']};g.exact(before)
 final=g.read(g.checked(p['complete_compiler_plan']));g.need(h.counts(final)==(4554,4541,4554),'Exact final counts');overlay={k:(v['final_sha256'],v['final_bytes'])for k,v in before.items()}
 for f in d['files']:
  name=f['canonical_path'];exists=not f.get('before_absent',f['before']is None);b=g.checked(f['before']).read_bytes()if exists else b'';a=g.checked(f['proposed']).read_bytes();fw,iv=h.diffs(f)
  g.need((R/name).exists()==exists,'Actual selected existence '+name)
  if exists:g.need((R/name).read_bytes()==b and subprocess.check_output(['git','show','HEAD:'+name],cwd=R)==b,'Actual/Git selected before '+name)
  g.need(apply(b,g.checked(fw).read_bytes())==a and apply(a,g.checked(iv).read_bytes())==b,'Selected full forward/inverse '+name);overlay[name]=(f['proposed']['sha256'],f['proposed']['bytes'])
 g.need(overlay=={e['path']:(e['final_sha256'],e['final_bytes'])for e in final['entries']},'Entire4554 final plan is exact38 overlay')
 fixtures,protected=h.fixtures(p)
 g.need({v['path']:v for v in fixtures.values()}=={v['path']:v for v in d['external_fixture_before_after_protection']},'Exact union seven fixture set')
 preflight=save(O/'read-only-preflight.json',dict(schema='src06-Root55-readonly-helper-preflight.v1',accepted=True,findings=[],prepared=pr,current4538_compiler_inputs_exact=True,selected22_current_Git_before_wholes_exact=True,all76_selected_literal_applications_exact=True,final4554_plan_exact38_overlay=True,all_seven_external_fixtures=fixtures,protected_reference_count=len(protected),helper_literal_applications=8,Python_syntax_parses=4,canonical_Cargo_Native_or_test_execution=False))
 print(json.dumps(dict(prepared=pr,preflight=preflight,helper_deltas=de,guard=p['guard_Source'],application=p['application_Source'],launch=p['launch_Source'],checker=p['actual_checker_Source'])))
if __name__=='__main__':main()

"""Private three-producer allocation port. No canonical writes or compiler run."""
from pathlib import Path
import copy, difflib, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
N=R/'.reference/energyplus-src/26.1.0'
O=D/'source-real-class-allocation-draft-Peer-01'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 p=p.resolve(); b=p.read_bytes(); return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n');return ref(p)
def check(v):
 p=R/v['path'];assert ref(p)==v;return p
def git(*args,cwd=R):return subprocess.check_output(['git',*args],cwd=cwd)
def replace_once(b,a,z):
 assert b.count(a)==1,a; return b.replace(a,z)
def main():
 assert not O.exists();O.mkdir()
 files=[]
 names=['crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance.rs',
 'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/demand.rs',
 'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/initialization.rs']
 changes={}
 for k in range(2):
  b=(R/names[k]).read_bytes();assert b'\r' not in b
  if k==0:
   for field,typ,num in [('zones','SourceZoneHeatBalanceData','zones'),('spaces','SourceSpaceHeatBalanceData','spaces')]:
    pos=b.index(('        if self.'+field+'.is_some() {').encode(),b.index(b'pub(crate) fn allocate_source_arrays'))
    end=b.index(('        self.'+field+' = Some(vec!['+typ+'::default(); '+num+']);').encode(),pos)
    end+=len(('        self.'+field+' = Some(vec!['+typ+'::default(); '+num+']);').encode())
    old=b[pos:end]
    new=('        // EPVector::allocate resets every class row, including existing rows.\n'
     '        let rows = self.'+field+'.get_or_insert_with(Vec::new);\n'
     '        rows.resize('+num+', '+typ+'::default());\n'
     '        rows.fill('+typ+'::default());').encode()
    changes.setdefault(k,[]).append((old,new));b=replace_once(b,old,new)
  else:
   start=b.index(b'pub(crate) fn allocate_source_demands')
   for field,typ,num,indent in [('zones','SourceSystemSensibleDemand','zones','        '),('zone_moisture','SourceSystemMoistureDemand','zones','        '),('spaces','SourceSystemSensibleDemand','spaces','            '),('space_moisture','SourceSystemMoistureDemand','spaces','            ')]:
    pos=b.index((indent+'if self.'+field+'.is_some() {').encode(),start)
    tail=(indent+'self.'+field+' = Some(vec!['+typ+'::default(); '+num+']);').encode()
    end=b.index(tail,pos)+len(tail);old=b[pos:end]
    new=(indent+'let rows = self.'+field+'.get_or_insert_with(Vec::new);\n'+indent+'rows.resize('+num+', '+typ+'::default());\n'+indent+'rows.fill('+typ+'::default());').encode()
    changes.setdefault(k,[]).append((old,new));b=replace_once(b,old,new)
  assert all(new in b for old,new in changes[k]);changes[k].append((b'',b''))
  before=(R/names[k]).read_bytes();inverse=b
  for a,z in reversed(changes[k][:-1]):inverse=replace_once(inverse,z,a)
  assert inverse==before
  files.append((names[k],before,b))
 b=(R/names[2]).read_bytes();assert b'\r' not in b
 old=b'''            if fan.zone_tstat_setpoints.is_some() {
                return Err(Error::Unavailable(
                    "repeated actual zoneTstatSetpts allocate2382",
                ));
            }
            fan.zone_tstat_setpoints = Some(vec![controls::SourceZoneTstatSetpoint::default(); n]);'''
 new=b'''            // Array1D::allocate retains an equal-size class array in the
            // original non-debug build; changed extents reconstruct its rows.
            if fan.zone_tstat_setpoints.as_ref().map(Vec::len) != Some(n) {
                fan.zone_tstat_setpoints =
                    Some(vec![controls::SourceZoneTstatSetpoint::default(); n]);
            }'''
 a=replace_once(b,old,new);assert replace_once(a,new,old)==b
 files.append((names[2],b,a))
 rows=[]
 for name,b,a in files:
  bp=O/'before'/name;ap=O/'proposed'/name;bp.parent.mkdir(parents=True,exist_ok=True);ap.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(b);ap.write_bytes(a)
  assert git('show','HEAD:'+name)==b
  fr=dict(canonical_path=name,before=ref(bp),proposed=ref(ap),Git_HEAD_blob_equal_before=True)
  for key,x,y in [('forward_diff',b,a),('inverse_diff',a,b)]:
   p=O/'diffs'/(name+'.'+key+'.diff');p.parent.mkdir(parents=True,exist_ok=True)
   p.write_text(''.join(difflib.unified_diff(x.decode().splitlines(keepends=True),y.decode().splitlines(keepends=True),fromfile=name,tofile=name)),encoding='utf-8',newline='\n')
   test=O/'literal-application'/key/name;test.parent.mkdir(parents=True,exist_ok=True);test.write_bytes(x)
   # The genuine patch tool authenticates full forward/inverse applications.
   run=subprocess.run(['git','apply','--no-index','--directory='+str(test.parent),'--unsafe-paths',str(p)],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE) if False else None
   # Apply the unified hunk text in an isolated exact-byte patch reader.
   out=[];at=0;lines=x.decode().splitlines(keepends=True);hunks=p.read_text(encoding='utf-8').splitlines(keepends=True);i=2
   while i<len(hunks):
    m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',hunks[i]);assert m
    start=int(m[1])-1;out.extend(lines[at:start]);at=start;i+=1
    while i<len(hunks) and not hunks[i].startswith('@@ '):
     line=hunks[i];assert line[:1] in (' ','-','+')
     if line[:1] in (' ','-'):assert lines[at]==line[1:];at+=1
     if line[:1] in (' ','+'):out.append(line[1:])
     i+=1
   out.extend(lines[at:]);assert ''.join(out).encode()==y
   test.write_bytes(y);fr[key]=ref(p)
  parse=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=a,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert parse.returncode==0
  pp=O/'parse'/(Path(name).name+'.stdout.rs');pp.parent.mkdir(parents=True,exist_ok=True);pp.write_bytes(parse.stdout);ep=pp.with_suffix('.stderr.txt');ep.write_bytes(parse.stderr)
  fr['syntax_only']=dict(exit_code=0,stdout=ref(pp),stderr=ref(ep));rows.append(fr)
 # Every declaration and allocator implementation is retained whole from pinned Git.
 authorities=[]
 specs={'src/EnergyPlus/EPVector.hh':[(57,160)],'src/EnergyPlus/HeatBalanceManager.cc':[(2824,2890)],
 'src/EnergyPlus/ZoneTempPredictorCorrector.cc':[(2350,2420)],'src/EnergyPlus/ZoneTempPredictorCorrector.hh':[(101,261),(416,434)],
 'src/EnergyPlus/DataZoneEnergyDemands.hh':[(63,174)],'src/EnergyPlus/DataHeatBalFanSys.hh':[(101,111),(145,160)],
 'src/EnergyPlus/DataHeatBalance.hh':[(424,433)],'third_party/ObjexxFCL/src/ObjexxFCL/Array1D.hh':[(925,945),(1375,1460)],
 'third_party/ObjexxFCL/src/ObjexxFCL/Array.hh':[(1520,1570)],'cmake/CompilerFlags.cmake':[(1,8)]}
 for name,ranges in specs.items():
  b=(N/name).read_bytes();assert git('show',PIN+':'+name,cwd=N)==b
  p=O/'Native'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);ext=[]
  for first,last in ranges:
   q=O/'Native-extents'/(name.replace('/','__')+f'.{first}-{last}.txt');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b''.join(b.splitlines(keepends=True)[first-1:last]));ext.append(dict(first_line=first,last_line=last,exact_whole_slice=ref(q)))
  authorities.append(dict(Native_path=name,pinned_Git=PIN,whole=ref(p),extents=ext))
 native_writers=[]
 for p in (N/'src').rglob('*'):
  if p.suffix not in ('.hh','.cc'):continue
  for ln,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
   if re.search(r'zoneTstatSetpts\.(allocate|dimension|redimension|reserve|resize|clear|deallocate)\(',line):native_writers.append(dict(path=p.relative_to(N).as_posix(),line=ln,text=line))
 assert len(native_writers)==1 and 'allocate(NumOfZones)' in native_writers[0]['text']
 census=[];tokens=['allocate_source_arrays(', 'allocate_source_demands(', 'initialize_source_air_setpoints(', 'zone_tstat_setpoints =']
 for p in (R/'crates').rglob('*.rs'):
  hits=[dict(line=ln,text=line) for ln,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1) if any(t in line for t in tokens)]
  if hits:census.append(dict(whole=ref(p),hits=hits))
 cp=save(O/'crate-API-caller-census.json',dict(tokens=tokens,files=census,Native_zoneTstat_allocation_family_writers=native_writers,
  no_signature_or_caller_change=True,unrelated_report_allocation_guards_unchanged=files[1][1].split(b'impl SourceZoneAirDemand {')[0]==files[1][2].split(b'impl SourceZoneAirDemand {')[0]))
 # Full existing constructor fields, not zero-only replacement records.
 air=files[0][1].decode();member_pairs=re.findall(r'/// Source ([A-Za-z0-9_]+)\.\s+pub\(crate\) ([a-z0-9_]+): ([^,\n]+),',air)
 defaults=air[air.index('impl Default for SourceZoneSpaceHeatBalanceData'):air.index('/// Actual derived Zone class')]
 air_ledger=[]
 for native,source,typ in member_pairs:
  m=re.search(r'\b'+source+r': ([^\n]+),',defaults);assert m,(native,source)
  air_ledger.append(dict(Native_member=native,Source_member=source,Source_type=typ,Source_constructor=m[1]))
 assert len(air_ledger)==74,len(air_ledger)
 demand_types={}
 for typ in ['SourceSystemDemandBase','SourceSystemSensibleDemand','SourceSystemMoistureDemand']:
  t=files[1][1].decode();body=t.split('pub(crate) struct '+typ+' {',1)[1].split('\n}',1)[0]
  fields=re.findall(r'pub\(crate\) (\w+): ([^\n]+),',body);demand_types[typ]=[dict(Source_member=f,Source_type=v,constructor=('1.0' if f=='supply_air_adjust_factor' else 'SourceSystemDemandBase::default()' if f=='base' else 'None' if 'Option' in v else '0' if v=='i32' else '0.0')) for f,v in fields]
 assert [len(v) for v in demand_types.values()]==[6,17,19]
 controls=R/'crates/ep_runtime/src/heat_balance/ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs'
 c=controls.read_text(encoding='utf-8');body=c.split('pub(crate) struct SourceZoneTstatSetpoint {',1)[1].split('\n}',1)[0]
 thermostat=[dict(Source_member=f,Source_type=v,constructor='0.0') for f,v in re.findall(r'pub\(crate\) (\w+): ([^\n]+),',body)];assert len(thermostat)==6
 ready=json.loads((D/'warmup-multiplier-Native-recipes-ready-Peer-03/manifest.json').read_bytes())
 flag_lists=[]
 def collect(v):
  if isinstance(v,list):
   if '-DNDEBUG' in v:flag_lists.append(v)
   for x in v:collect(x)
  elif isinstance(v,dict):
   for x in v.values():collect(x)
 collect(ready);assert flag_lists and all(not any('OBJEXXFCL_ARRAY_INIT' in str(x) for x in v) for v in flag_lists)
 ledger=save(O/'constructor-container-order-ledger.json',dict(
  EPVector=dict(implementation='m_allocated=true; vector.resize(count); fill(all,T{}); existing equal-size records reset in place; shrink destroys tail; grow reconstructs tail then all rows assign T{}',Source='get_or_insert_with(Vec::new); resize(count,Default); fill(Default)',arrays=['zoneHeatBalance','spaceHeatBalance','ZoneSysEnergyDemand','ZoneSysMoistureDemand','spaceSysEnergyDemand','spaceSysMoistureDemand'],zero_count='Option remains Some(empty), representing allocated true',negative_count='existing checked i32->usize failure remains; no newly admitted negative extent'),
  thermostat_Array1D=dict(implementation='allocate->dimension_real->size_real->Array.resize; equal size and existing storage returns false, non-debug dimension_real performs no assignment; first/different extent allocates and placement-default-constructs the six fields',Source='retain Some(rows) if rows.len()==n, otherwise Some(vec![genuine Default;n])',sole_allocate_writer=native_writers,capacity_qualification='This actual member has no reserve/redimension/resize writer. Its allocator starts with capacity=size and every changed extent reallocates; no spare-capacity branch is claimed.',build_flag_authority=ref(D/'warmup-multiplier-Native-recipes-ready-Peer-03/manifest.json'),DNDEBUG_present=True,OBJEXXFCL_ARRAY_INIT_and_DEBUG_absent=True,debug_array_init_policy_not_claimed=True),
  order=['checked Zone extent','zoneHeatBalance EPVector allocate/reset','checked Space extent','spaceHeatBalance EPVector allocate/reset unconditionally',
  'InitSetPoints one-time latch check','checked NumOfZones','zoneTstat Array1D allocate/retain','existing scalar EPVector dimensions and boolean/report dimensions unchanged','Zone sensible EPVector allocate/reset','Zone moisture EPVector allocate/reset','space simulation||sizing predicate','checked Space extent','space sensible EPVector allocate/reset','space moisture EPVector allocate/reset','existing caller reference/output initialization and latch writes unchanged'],
  air_base_members=air_ledger,air_derived_classes='Zone/Space add no data members; both retain genuine SourceZoneSpaceHeatBalanceData::default()',demand_members=demand_types,thermostat_members=thermostat,
  unchanged_constructor_context=ref(controls),normal_first_allocation='Exact same genuine default fields/lengths and caller order as predecessor. Only repeated EPVector reset and equal-size Array1D retention newly represented.',
  no_physics_formula_output_expected_default_injection=True,no_adapter_clear_or_factory_change=True))
 prior=D/'source-Propane-P4-history-coherent-draft-Peer-01/complete-proposed-compiler-Source-plan.json';plan=json.loads(prior.read_bytes());assert(len(plan['entries']),plan['compiler_inputs'],plan['Rust_sources'])==(4538,4538,4525)
 for e in plan['entries']:
  p=R/e['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==e['final_sha256'] and len(b)==e['final_bytes'],e['path']
 final=copy.deepcopy(plan)
 for row in rows:
  e=next(e for e in final['entries'] if e['path']==row['canonical_path']);v=row['proposed'];e.update(final_sha256=v['sha256'],final_bytes=v['bytes'],source=v,origin='faithful actual-container repeated class allocation producer')
 final.update(schema='src06-private-three-class-allocation-proposed-plan.v1',prior_complete_compiler_Source_plan=ref(prior),selected=3,existing=3,new=0)
 pp=save(O/'complete-proposed-compiler-Source-plan.json',final)
 out=save(O/'draft.json',dict(schema='src06-private-three-real-class-allocation-Source-draft.v1',status='FROZEN_PRIVATE_ROOT_INDEPENDENT_PEER_PENDING',observed_HEAD=git('rev-parse','HEAD').decode().strip(),files=rows,Native_authority=authorities,constructor_container_order_ledger=ledger,crate_API_caller_census=cp,prior_complete_compiler_Source_plan=ref(prior),complete_proposed_compiler_Source_plan=pp,compiler_inputs=4538,Rust_sources=4525,whole_current_compiler_rows_verified=4538,literal_applications=6,fresh_syntax_parses=3,canonical_writes=0,Cargo_Native_executions=0,tests_added=0,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(draft=out,plan=pp,ledger=ledger,census=cp)))
if __name__=='__main__':main()

"""Run independent Surface gains after the common GetHB setup has returned."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys
R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'

def main():
    path = D / 'Constant-Exterior-category-guards-Peer-55-06.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == 'aeb1e6934ed858fcf8a52f5f8b788ec03fcb6a9a4e9cd308bdc8ef16813c947d'
    spec = importlib.util.spec_from_file_location('independent_surface10_guard', path)
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    pr = g.ref(D / 'Constant-Exterior-category-Root-helpers-ready-Peer-55-06/prepared.json')
    assert pr['sha256'] == '1d0bb4f61e2a381871248401308dbdae0dd1a716951a09aea42c3585f027c019'
    _, p, _, _, _, fixtures, protected, _ = g.prepared(pr['path'] + '#' + pr['sha256'])
    folder = D / 'Root-Setup-cold-weather-application-55-10'
    appref = g.ref(folder / 'receipt.json')
    app = g.read(appref)
    g.need(app['accepted'] and not app['findings'] and app['complete_compiler_plan']['sha256'] == '8db317b10465947da290e522ecf64d969b3a620384a778e01991878f4d777721', 'Actual reviewed Setup10 application')
    plan = g.read(app['complete_compiler_plan'])
    g.exact(plan)
    prior = g.read(g.ref(folder / 'beam_producer-after.json'))
    g.need(prior['exit_code'] == 1 and prior['Source_and_fixtures_stable'] and prior['complete_compiler_plan'] == app['complete_compiler_plan'], 'Independent beam failed after common GetHB; no prior-category PASS dependency')
    category = 'surface_internal_gains'
    out = D / 'canonical-source-gap-batch-exterior-surface_internal_gains-Root-55-10'
    g.need(not out.exists() and not (folder / (category + '-before.json')).exists() and not (folder / (category + '-after.json')).exists(), 'Fresh previously unexecuted Surface10')
    before = [g.ref(g.checked(v)) for v in protected]
    g.need(before == app['protected_before'], 'Same seven whole fixture authorities')
    command = g.command(fixtures, category)
    env = g.environment(p)
    g.save(folder / (category + '-before.json'), dict(application=appref, command=command, complete_compiler_plan=app['complete_compiler_plan'], protected=before, independent_launch_Source=g.ref(Path(__file__))))
    code = subprocess.call([sys.executable, str(g.checked(p['record_command_Source'])), '--output-dir', str(out), '--', *command], cwd=R, env=env)
    g.exact(plan)
    after = [g.ref(g.checked(v)) for v in protected]
    g.need(before == after, 'Seven fixtures unchanged')
    runref = g.ref(out / 'receipt.json')
    run = g.read(runref)
    g.need(run['exit_code'] == code and run['launch_error'] is None and run['source_bytes_match_before_and_after'] and run['repository_before'] == run['repository_after'] and run['command'] == command, 'Actual complete Source invocation custody')
    logs = {key: g.ref(R / run[key]['path']) for key in ['stdout', 'stderr']}
    g.need(all(logs[key]['sha256'] == run[key]['sha256'] for key in logs), 'Whole actual logs')
    result = dict(accepted=code == 0, findings=[] if code == 0 else ['Actual independent Surface category failure retained; no numerical PASS.'], category=category, application=appref, actual_receipt=runref, complete_compiler_plan=app['complete_compiler_plan'], Source_and_fixtures_stable=True, protected_before=before, protected_after=after, exit_code=code, logs=logs, author_Source=g.ref(Path(__file__)))
    print(json.dumps(g.save(folder / (category + '-after.json'), result)))
    return code

if __name__ == '__main__':
    sys.exit(main())

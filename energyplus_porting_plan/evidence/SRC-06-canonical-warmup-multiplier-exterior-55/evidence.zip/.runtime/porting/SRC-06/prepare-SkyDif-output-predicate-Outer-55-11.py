"""Private exact SkyDif local predicate handoff to real output declaration child."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];A=R/'.runtime/porting/SRC-06';O=A/'source-SkyDif-output-predicate-Outer-55-11'
P=A/'source-Setup-cold-weather-Outer-55-10/complete-proposed-compiler-Source-plan.json'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def save(p,j):return put(p,(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode())
def diff(n,a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n)).encode()
def replace(s,a,b):assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
assert not O.exists();O.mkdir();plan=json.loads(P.read_bytes());assert (plan['compiler_inputs'],plan['Rust_sources'])==(4556,4542)
changes=[]
for n,old,new in [
 ('crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep.rs',
  '    fn register_sky_diffuse_outputs(&mut self, solar: &OrdinarySolarRadiation,\n        geometry: &SurfaceGeometryInputState) -> Result<(), Error>;',
  '    fn register_sky_diffuse_outputs(&mut self, solar: &OrdinarySolarRadiation,\n        geometry: &SurfaceGeometryInputState, detailed_shading: bool) -> Result<(), Error>;'),
 ('crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep/sky.rs',
  '        children.register_sky_diffuse_outputs(self, geometry)?;',
  '        children.register_sky_diffuse_outputs(self, geometry, detailed)?;'),
 ('crates/ep_runtime/src/heat_balance/radiation/ordinary/source_children.rs',
  '        geometry: &SurfaceGeometryInputState,\n    ) -> Result<(), Error> {\n        let live = SourceSolarOutputOwners',
  '        geometry: &SurfaceGeometryInputState,\n        detailed_shading: bool,\n    ) -> Result<(), Error> {\n        let live = SourceSolarOutputOwners'),
]:
 before=(R/n).read_bytes();s=replace(before.decode(),old,new)
 if n.endswith('/source_children.rs'):
  s=replace(s,'            self.shadowing.detailed_sky_diffuse_algorithm,\n            &mut output,','            detailed_shading,\n            &mut output,')
 after=s.encode();q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True,cwd=R);assert q.returncode==0,q.stderr.decode()
 row=dict(canonical_path=n,before_absent=False,before=put(O/'before'/n,before),proposed=put(O/'proposed'/n,after),forward_diff=put(O/'diffs'/(n+'.forward.diff'),diff(n,before,after)),inverse_diff=put(O/'diffs'/(n+'.inverse.diff'),diff(n,after,before)),Source_only_parse=dict(exit_code=q.returncode,stdout=put(O/'parse'/(n+'.stdout.rs'),q.stdout),stderr=put(O/'parse'/(n+'.stderr.txt'),q.stderr),syntax_only=True,qualification='Existing accepted surrounding bytes retained; actual rustfmt stdout is syntax evidence and need not equal the mixed-format proposed whole.'))
 e=next(e for e in plan['entries'] if e['path']==n);assert e['final_sha256']==hashlib.sha256(before).hexdigest();e.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed']);changes.append(row)
pr=save(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-complete-compiler-Source-plan.v1',compiler_inputs=4556,inputs=4556,Rust_sources=4542,entries=plan['entries'],prior_complete_compiler_Source_plan=ref(P),current_stage='55-11 actual SkyDif local detailedShading predicate to output child',selected_inputs=3,other4553_parent_wholes_unchanged=True))
native=[]
for name,ranges in [('src/EnergyPlus/SolarShading.cc',[(10524,10589)]),('src/EnergyPlus/SolarShading.hh',[(407,431)])]:
 p=R/'.reference/energyplus-src/26.1.0'/name;b=p.read_bytes();assert subprocess.check_output(['git','show','6f2e40d10250a105b49966baa24d843711e61048:'+name],cwd=R/'.reference/energyplus-src/26.1.0')==b
 native.append(dict(Native_path=name,whole=ref(p),extents=[dict(first=a,last=z,source=put(O/'Native'/f'{p.name}.{a}-{z}',b''.join(b.splitlines(True)[a-1:z]))) for a,z in ranges]))
contexts=[dict(canonical_path=n,whole=ref(R/n)) for n in ['crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_output_registration/debug.rs','crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_output_registration/bindings.rs','crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep/array.rs','crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep/allocation.rs','crates/ep_runtime/src/heat_balance/selected_heat_balance_input/shadowing.rs']]
census=[]
for path in (R/'crates/ep_runtime/src').rglob('*.rs'):
 for line,text in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
  if 'register_sky_diffuse_outputs' in text:census.append(dict(canonical_path=path.relative_to(R).as_posix(),line=line,source=text))
assert len(census)==3
failure=A/'canonical-source-gap-batch-exterior-beam_producer-Root-55-10/receipt.json';assert json.loads(failure.read_bytes())['exit_code']==1
d=dict(schema='src06-SkyDif-real-output-predicate-Source-draft.v1',status='FROZEN_PRODUCTION_SOURCE_ONLY_ROOT_PEER_PENDING',base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),files=changes,prior_complete_compiler_Source_plan=ref(P),complete_proposed_compiler_Source_plan=pr,actual_failed_55_10=ref(failure),Native_commit='6f2e40d10250a105b49966baa24d843711e61048',Native_authorities=native,concrete_same_owner_contexts=contexts,whole_crate_API_census=census,author_Source=ref(Path(__file__)),scope=[
 'Native10527 detailedShading local chooses both allocation and SetupOutputVariable Which. Source computes that exact local already; pass the same boolean to its actual declaration child.',
 'Old child incorrectly chose current-ratio Which using raw DetailedSky flag alone, even when actual ShadingTransmittanceVaries false leaves that array genuinely unallocated.',
 'Exactly one trait method, one call, one sole actual implementation; no other callers/implementations exist in the complete runtime Source census.',
 'No array allocator, values, local detailed predicate, storage, raw flag, scientific formula, declaration name/order, primary, readiness, cache, expected fixture, policy or tolerance changes.',
 'No compiler/scientific execution/canonical edit or full Exterior PASS claim.',
])
print(json.dumps(dict(draft=save(O/'draft.json',d),plan=pr),indent=2))

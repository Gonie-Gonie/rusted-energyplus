"""Private correction of a Rust-only Setup800 weather-readiness precondition."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];A=R/'.runtime/porting/SRC-06';O=A/'source-Setup-cold-weather-Outer-55-10'
P=A/'source-Zone-primary-convection-Outer-55-09/complete-proposed-compiler-Source-plan.json'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def save(p,j):return put(p,(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode())
def diff(n,a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n)).encode()
assert not O.exists();O.mkdir();plan=json.loads(P.read_bytes());assert (plan['compiler_inputs'],plan['Rust_sources'])==(4556,4542)
n='crates/ep_runtime/src/heat_balance/ctf_initialization_context/setup_zone_geometry.rs';before=(R/n).read_bytes();s=before.decode()
old='''        // Existing returned getters witness the actual Site/Station operands;
        // their absence cannot silently substitute constructor parameters.
        if !environment.source_weather_station_initialized
            || !environment.source_site_atmosphere_initialized
        {
            return Err(hb_input_error(E::Unavailable(
                "actual returned Site/Station before Setup800",
            )));
        }
'''
new='''        // Original797-801 consumes the same live DataEnvironment directly.
        // A direct GetHeatBalanceInput caller can still have constructor-cold
        // station operands; no Station return or fabricated witness is required.
'''
assert s.count(old)==1;after=s.replace(old,new).encode()
q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True,cwd=R);assert q.returncode==0,q.stderr.decode()
e=next(e for e in plan['entries'] if e['path']==n);assert e['final_sha256']==hashlib.sha256(before).hexdigest()
row=dict(canonical_path=n,before_absent=False,before=put(O/'before'/n,before),proposed=put(O/'proposed'/n,after),forward_diff=put(O/'diffs'/(n+'.forward.diff'),diff(n,before,after)),inverse_diff=put(O/'diffs'/(n+'.inverse.diff'),diff(n,after,before)),Source_only_parse=dict(exit_code=q.returncode,stdout=put(O/'parse/stdout.rs',q.stdout),stderr=put(O/'parse/stderr.txt',q.stderr),syntax_only=True,qualification='Existing accepted surrounding mixed-format Source bytes retained; the only authored replacement is a comment and guard removal. Fresh rustfmt stdout is actual syntax output, not claimed identical proposed bytes.'))
e.update(final_sha256=row['proposed']['sha256'],final_bytes=row['proposed']['bytes'],source=row['proposed'])
pr=save(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-complete-compiler-Source-plan.v1',compiler_inputs=4556,inputs=4556,Rust_sources=4542,entries=plan['entries'],prior_complete_compiler_Source_plan=ref(P),current_stage='55-10 direct Setup800 actual cold weather operands',selected_inputs=1,other4555_parent_wholes_unchanged=True))
native=[]
for name,ranges in [('src/EnergyPlus/SurfaceGeometry.cc',[(785,802)]),('src/EnergyPlus/DataHeatBalance.cc',[(144,173),(302,321)]),('src/EnergyPlus/DataEnvironment.hh',[(129,140),(189,198)])]:
 p=R/'.reference/energyplus-src/26.1.0'/name;b=p.read_bytes();assert subprocess.check_output(['git','show','6f2e40d10250a105b49966baa24d843711e61048:'+name],cwd=R/'.reference/energyplus-src/26.1.0')==b
 native.append(dict(Native_path=name,whole=ref(p),extents=[dict(first=a,last=z,source=put(O/'Native'/f'{p.name}.{a}-{z}',b''.join(b.splitlines(True)[a-1:z]))) for a,z in ranges]))
context_names=[
 'crates/ep_runtime/src/heat_balance/convection/surface_environment/ordinary/source.rs',
 'crates/ep_runtime/src/heat_balance/convection/surface_environment.rs',
 'crates/ep_runtime/src/weather_day/context.rs',
 'crates/ep_runtime/src/weather_day/production/source_environment.rs',
 'crates/ep_runtime/src/heat_balance/ctf_initialization_context/source_heat_balance_input.rs',
 'crates/ep_runtime/src/heat_balance/ctf_initialization_context/post_building_input.rs',
 'crates/ep_runtime/src/heat_balance/radiation/ordinary/source_initialization.rs',
 'crates/ep_runtime/src/heat_balance/ctf_initialization_context/internal_heat_gains_input.rs',
 'crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress/geometry.rs',
 'crates/ep_runtime/src/heat_balance/gap_batch_cohort/exterior/ingress/producer_calls.rs',
]
contexts=[dict(canonical_path=n,whole=ref(R/n)) for n in context_names]
cpp=A/'genuine-solar-gain-producers-draft-Outer-11/exterior_gap_batch.cpp'
fixture=A/'source-Exterior-runtime-fixture-Outer-01/fixture.json';fixture_j=json.loads(fixture.read_bytes())
families=['SurfaceProperty:IncidentSolarMultiplier','SurfaceProperty:SolarIncidentInside','ComplexFenestrationProperty:SolarAbsorbedLayers','ZoneProperty:UserViewFactors:BySurfaceName','PerformancePrecisionTradeoffs','DaylightingDevice:Shelf','Pipe:Indoor','Pipe:Outdoor','Pipe:Underground','GroundHeatExchanger:Surface','DaylightingDevice:Tubular','EnergyManagementSystem:ConstructionIndexVariable']
counts=[]
for name,f in fixture_j['source_ingress']['factories'].items():
 if 'BuildingSurface:Detailed' not in f['raw']:continue
 counts.append(dict(case=name,counts={family:len(f['raw'].get(family,{})) for family in families},surface_types=[v['surface_type'] for v in f['raw']['BuildingSurface:Detailed'].values()]))
assert len(counts)==4 and all(all(v==0 for v in row['counts'].values()) for row in counts)
audit=save(O/'remaining-full-GetHB-prerequisite-readset.json',dict(schema='src06-static-selected-GetHB-prerequisite-readset.v1',actual_whole_fixture=ref(fixture),actual_raw_count_census=counts,unchanged_current_contexts=contexts,Native_factory=ref(cpp),conclusions=[
 'Original direct factory processInput/PostIP/init_state/real factories/clock pointers -> GetLocationInfo (beam only) -> GetHeatBalanceInput has no GetWeatherStation. Surface-gains caller intentionally omits GetLocationInfo too.',
 'Actual Source GetProjectControlData/GetSiteAtmosphere, full material/construction/Zone/Surface/Setup/enclosure producers have already executed before Setup800; no constructor value is assigned here and existing witnesses remain as actually written.',
 'Post-building positive incident/scheduled/variable-absorptance/TC/representative/Kiva branches remain honest; current raw special-family counts are zero and actual opaque construction/default flags come from real getters.',
 'InitSolar requires actual enclosures/Space surface lists/final physical rows/used constructions; all are real earlier producer outputs. Selected classes are Wall/Floor/Roof and user-F input count zero. Its existing Fix wrapper delegates the accepted shared full kernel but retains balanced N>3 diagnostic scope; no claim of numerical success before actual call.',
 'No other returned Site/Station witness check exists inside this full GetHB producer path. Later normal weather driver and runtime outdoor lifecycle checks are separate and unchanged.',
 'Subsequent InitSolar/Shadowing/Radiant/IHG result/shape/numerical boundaries are not asserted passed by this static readset; only actual Root execution can close them.',
]))
failure=A/'canonical-source-gap-batch-exterior-beam_producer-Root-55-09/receipt.json';assert json.loads(failure.read_bytes())['exit_code']==1
d=dict(schema='src06-Setup800-constructor-weather-Source-draft.v1',status='FROZEN_PRODUCTION_SOURCE_ONLY_ROOT_PEER_PENDING',base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),files=[row],prior_complete_compiler_Source_plan=ref(P),complete_proposed_compiler_Source_plan=pr,actual_failed_55_09=ref(failure),Native_commit='6f2e40d10250a105b49966baa24d843711e61048',Native_authorities=native,concrete_same_owner_contexts=contexts,remaining_producer_prerequisites=audit,prior_independent_cold_site_peer=ref(A/'Peer-site-shadow-production-review-Audit-01/site-review.json'),author_Source=ref(Path(__file__)),scope=['Remove only an extra Rust lifecycle guard that is absent from Original SurfaceGeometry797–801.','Same actual Zone array, current environment values, actual gradient/station constructor values, setter math and diagnostic backend/order remain unchanged.','No inserted Station/Site getter, coefficient seed, ready flag assignment, fake return, ignored producer, primary or expected-data change.','Default/returned Source witness fields remain truthful and unchanged; normal runtime weather-specific guards are untouched.','No compiler/Native/Source science/canonical mutation; whole Exterior result remains pending.'])
print(json.dumps(dict(draft=save(O/'draft.json',d),plan=pr),indent=2))

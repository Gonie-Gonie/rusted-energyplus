"""Metadata-only successor: bind fresh syntax output of actual frozen02 child."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-sky-opaque-cohort-draft-Outer-03'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def write(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode());return ref(p)
def main():
 assert not O.exists();O.mkdir();prior=D/'source-sky-opaque-cohort-draft-Outer-02/draft.json';a=prior.read_bytes();v=json.loads(a);new=copy.deepcopy(v)
 rows=[r for r in new['files'] if r['canonical_path'].endswith('/sky_opaque.rs')];assert len(rows)==1;row=rows[0];p=R/row['proposed']['path'];b=p.read_bytes();assert ref(p)==row['proposed']
 run=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert run.returncode==0 and run.stdout==b
 out=O/'sky_opaque.rustfmt.stdout.rs';err=O/'sky_opaque.rustfmt.stderr.txt';out.write_bytes(run.stdout);err.write_bytes(run.stderr)
 receipt=write(O/'Source-only-parse.json',{'argv':['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],'stdin':row['proposed'],'stdout':ref(out),'stderr':ref(err),'exit_code':run.returncode,'stdout_whole_equals_proposed':True,'qualification':'Syntax only, no Rust contextual typecheck or scientific execution.'})
 old=row['Source_only_parse'];row['Source_only_parse']={'exit_code':0,'stdout':ref(out),'stderr':ref(err),'actual_receipt':receipt}
 new['preserved_metadata02']=ref(prior);new['metadata_only_correction']={'finding':'02 retained the old01 child syntax stdout reference after changing/formatting the child. Fresh recorded rustfmt now binds actual02 proposed bytes.','old_Source_only_parse':old,'all3_proposed_Source_wholes_unchanged':True,'no_numerical_rerun_or_canonical_write':True}
 new['author_Source']=ref(Path(__file__));target=O/'draft.json';r=write(target,new);bb=target.read_bytes()
 for name,x,y in [('forward',a,bb),('inverse',bb,a)]:
  (O/f'metadata.{name}.diff').write_bytes(''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile='preserved02',tofile='parse-custody03')).encode())
 print(json.dumps({'draft':r,'parse_receipt':receipt,'forward_diff':ref(O/'metadata.forward.diff'),'inverse_diff':ref(O/'metadata.inverse.diff')}))
if __name__=='__main__':main()

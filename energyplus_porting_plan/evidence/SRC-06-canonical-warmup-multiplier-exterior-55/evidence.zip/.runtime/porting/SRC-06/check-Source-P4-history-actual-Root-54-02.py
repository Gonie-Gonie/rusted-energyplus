"""Authenticate two actual Source54 groups and complete recorded compiler inputs."""
from pathlib import Path
import hashlib,importlib.util,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
helper=D/'gap-P4-history-guards-Peer-54.py'
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='89f2f230b0faebf72e44117b19d0598f460fde4c441c3a3907510ac7c0438400'
s=importlib.util.spec_from_file_location('guards54_actual',helper);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);g=m.g
def main():
 ar=g.ref(D/'Root-Propane-P4-history-application-54/receipt.json');assert ar['sha256']=='4d5a264807d75a3d9ec26f9f35e75158a6b32b29ee92e8b0fce33ffdaae9c2ea'
 app=g.read(g.checked(ar));assert app['accepted'] and not app['findings'] and app['all_final_compiler_bytes_exact']
 pr,p,d,u=m.prepared(app['prepared']['path']+'#'+app['prepared']['sha256']);assert pr==app['prepared']
 m.current_head(app['base_HEAD']);fixtures,protected=m.fixtures(p,d,u);assert fixtures==app['fixtures'] and protected==app['protected_all_four_external_fixtures']
 planref=app['complete_compiler_plan'];plan=g.read(g.checked(planref));rows={x['path']:x for x in plan['entries']}
 assert (plan['compiler_inputs'],plan['Rust_sources'],len(rows))==(4538,4525,4538);g.exact(rows)
 apply=g.literal();selected=[]
 for f in d['files']:
  a=b'' if f['before_absent'] else g.checked(f['before']).read_bytes();b=g.checked(f['proposed']).read_bytes()
  assert (R/f['canonical_path']).read_bytes()==b
  assert apply(a,g.checked(f['diffs']['forward']).read_bytes())==b and apply(b,g.checked(f['diffs']['inverse']).read_bytes())==a
  selected.append(f['canonical_path'])
 assert len(set(selected))==21
 target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve();results=[]
 for group,calls,count,token,nativecount in [
  ('output_processor',38,34321,'P4 original-core full-operation cohort: 38 calls / 35 live OutVars / 34321 exact rawbinary64 observations',34470),
  ('air_history',40,23232,'Air-history genuine persistent calls=40; strict raw-bit state observations=23232; four getter factories; no history/exit restore; private cache unobserved',23352)]:
  rr=g.ref(D/('canonical-source-gap-batch-'+group+'-Root-54/receipt.json'));run=g.read(g.checked(rr))
  assert run['exit_code']==0 and run['launch_error'] is None and run['source_bytes_match_before_and_after']
  assert run['repository_before']==run['repository_after'] and run['repository_before']['head']==app['base_HEAD']
  command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',group,str(g.checked(fixtures[group]))];assert run['command']==command
  env=run['launch_environment_selected'];assert Path(env['CARGO_TARGET_DIR']).resolve()==target and all(v is None for k,v in env.items() if k!='CARGO_TARGET_DIR')
  assert not run['cargo_compiler_artifacts_capture']['requested']
  guards=[]
  for phase in ['before','after']:
   gr=g.ref(D/('Root-runtime-fixture-'+group+'-guard-54')/(phase+'.json'));guard=g.read(g.checked(gr));assert guard['application']==ar and guard['command']==command and guard['selected_group']==group
   if phase=='before':assert guard['protected']==protected
   else:
    assert guard['accepted'] and not guard['findings']
    assert guard['exit_code']==0 and guard['actual_receipt']==rr and guard['command']==command and guard['all4538_compiler_inputs_unchanged']
    assert guard['protected_before']==guard['protected_after']==protected and guard['launch_Source']==p['launch_Source']
   guards.append(gr)
  sr=g.ref(R/run['source_snapshot']['path']);assert sr['sha256']==run['source_snapshot']['sha256'];snap=g.read(g.checked(sr));archived={x['historical_path']:x for x in snap['files']};assert archived.keys()==rows.keys()
  for name,row in rows.items():
   item=archived[name];ref=g.ref(R/item['archive']['path']);assert ref['sha256']==item['archive']['sha256']==row['final_sha256'] and ref['bytes']==item['size_bytes']==row['final_bytes'],name
  logs={}
  for key in ['stdout','stderr']:
   lr=g.ref(R/run[key]['path']);assert lr['sha256']==run[key]['sha256'];logs[key]=lr
  lines=g.checked(logs['stdout']).read_text(encoding='utf8').splitlines();assert lines==['running 1 original-core gap cohort group='+group+' on process main',token,'cohort native_controlled_air_cohort ... ok','cohort result: ok. 1 passed; 0 failed; group='+group+'; full-call records='+str(calls)+'; private cache state unobserved']
  err=g.checked(logs['stderr']).read_text(encoding='utf8');assert 'Finished `test` profile' in err and 'Running src\\lib.rs (' in err and not re.search(r'^error(?:\[|:)',err,re.M)
  compiles=len(re.findall(r'^\s*Compiling ep_runtime ',err,re.M));assert compiles==(1 if group=='output_processor' else 0)
  proofref=p['P4_fixture_proof'] if group=='output_processor' else p['history_fixture_proof'];proof=g.read(g.checked(proofref));nr=proof['actual_Native_group_run'];native=g.read(g.checked(nr));assert native['admission']['raw_finite_binary64_fields']==nativecount
  results.append(dict(group=group,full_calls=calls,Source_exact_raw_bit_state_observations=count,Native_whole_output_finite_fields=nativecount,denominators_distinct=True,actual_Source_receipt=rr,actual_Native_receipt=nr,external_fixture=fixtures[group],fixture_projection=proofref,fixture_before_after_guards=guards,recorded_source_snapshot=sr,all4538_archived_compiler_inputs_exact=True,logs=logs,ep_runtime_compile_messages=compiles))
 assert results[0]['recorded_source_snapshot']==results[1]['recorded_source_snapshot']
 g.exact(rows)
 result=dict(schema='src06-Source54-P4-history-actual-independent-review.v1',accepted=True,findings=[],base_HEAD=app['base_HEAD'],application=ar,prepared=pr,complete_compiler_plan=planref,compiler_inputs=4538,Rust_sources=4525,selected_Source_files=selected,literal_forward_inverse_applications=42,all4538_current_and_both_archived_inputs_exact=True,both_groups_same_recorded_Source_snapshot=True,groups=results,full_calls=78,Source_exact_raw_bit_state_observations=57553,all_four_external_fixtures_stable=True,original_Propane_production_peer=d['original_production_peer'],joint_independent_peer=app['joint_independent_peer'],history_independent_peer=app['history_independent_peer'],P4_independent_peer=p['original_P4_Source_peer'],inherited_environment_guard=p['environment_guard'],record_command_Source=p['record_command_Source'],Source_launch=p['launch_Source'],gate_changes=False,policy_changes=0,additional_engine_or_Cargo_invocations=0,qualification='Two actual genuine original-core comparisons only. Propane production changes are statically reviewed; positive IHG numerical coverage awaits Exterior. Prior P1/Surface passes remain historical evidence, not Source54 reexecution or one final fifteen-case snapshot. Full warmup, full surface-parent handoff, multiplier2 and final15 remain open. Private cache state unobserved.',author_Source=g.ref(Path(__file__)))
 out=D/'Root-Source-P4-history-actual-review-54';assert not out.exists();out.mkdir();p=out/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(g.ref(p)))
if __name__=='__main__':main()

"""Root-only seven-row correction, after whole current compiler/readset guards."""
from pathlib import Path
import argparse,hashlib,importlib.util,json
D=Path(__file__).resolve().parent
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prepared',required=True);ap.add_argument('--peer',required=True);a=ap.parse_args();path=D/'Constant-Exterior-category-guards-Peer-55-06.py';needsha='aeb1e6934ed858fcf8a52f5f8b788ec03fcb6a9a4e9cd308bdc8ef16813c947d';assert hashlib.sha256(path.read_bytes()).hexdigest()==needsha
 s=importlib.util.spec_from_file_location('category06_application_guard',path);g=importlib.util.module_from_spec(s);s.loader.exec_module(g);rr,p,draft,old,new,fixtures,protected,snapshot=g.prepared(a.prepared);pr=g.argument(a.peer);g.peer(pr,p['coherent_draft']);g.exact(old);g.need(not g.APP.exists(),'Fresh Root06 application');g.environment(p)
 changes=[]
 for row in draft['files']:
  target=(g.R/row['canonical_path']).resolve();g.need(target.is_relative_to(g.R) and target.read_bytes()==g.checked(row['before']).read_bytes(),'Exact canonical old whole');changes.append((target,g.checked(row['proposed']).read_bytes()))
 fixture_before=[g.ref(g.checked(v)) for v in protected];g.APP.mkdir()
 for target,value in changes:target.write_bytes(value)
 g.exact(new);fixture_after=[g.ref(g.checked(v)) for v in protected];g.need(fixture_before==fixture_after,'All seven fixtures untouched')
 result=dict(schema='src06-seven-row-Constant-category-application.v1',accepted=True,findings=[],prepared=rr,coherent_draft=p['coherent_draft'],independent_mechanical_peer=pr,base_HEAD=p['base_HEAD'],complete_compiler_plan=p['complete_compiler_plan'],prior_complete_compiler_plan=p['prior_compiler_plan'],prior_actual05_snapshot=snapshot,changed_files=[r['canonical_path'] for r in draft['files']],compiler_inputs=4556,Rust_sources=4542,literal_applications=14,all_final_compiler_bytes_exact=True,protected_before=fixture_before,protected_after=fixture_after,qualified_prior05_progress=draft['source05_qualified_progress'],qualification='Actual05 first137 records are inferred from ordered checked calls before the unique first GainFactory warning boundary, not direct historical milestones. Only the remaining three complete categories are launched; prior warmup/multiplier passes remain qualified readset carries, never same-binary claims.',author_Source=g.ref(Path(__file__)))
 print(json.dumps(g.save(g.APP/'receipt.json',result)))
if __name__=='__main__':main()

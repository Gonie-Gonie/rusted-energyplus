from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];A=R/'.runtime/porting/SRC-06';O=A/'source-Exterior-factory-phase-context-Outer-55-07-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def save(p,v):return put(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
old=A/'source-Exterior-factory-phase-context-Outer-55-07/draft.json';d=json.loads(old.read_bytes());assert not O.exists();O.mkdir();plan=json.loads((R/d['complete_proposed_compiler_Source_plan']['path']).read_bytes())
for r in d['files']:
 n=r['canonical_path'];a=(R/r['before']['path']).read_bytes();b=(R/r['Source_only_parse']['stdout']['path']).read_bytes();r['proposed']=put(O/'proposed'/n,b)
 for x,y,label in [(a,b,'forward'),(b,a,'inverse')]:r[label+'_diff']=put(O/'diffs'/(n+'.'+label+'.diff'),''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n)).encode())
 cp=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True,cwd=R);assert cp.returncode==0 and cp.stdout==b
 r['Source_only_parse']=dict(exit_code=0,stdout=r['proposed'],stderr=put(O/'parse'/(n+'.stderr.txt'),cp.stderr),syntax_only=True)
 e=next(e for e in plan['entries'] if e['path']==n);e.update(final_sha256=r['proposed']['sha256'],final_bytes=r['proposed']['bytes'],source=r['proposed'])
d['complete_proposed_compiler_Source_plan']=save(O/'complete-proposed-compiler-Source-plan.json',plan)
failure=A/'canonical-source-gap-batch-exterior-beam_producer-Root-55-06/receipt.json';assert ref(failure)['sha256']=='8278b99c981f3a2ed2df684ba9b067d1e5767b72a28ee6e3b76fb043acb6cdbc'
d.update(schema='src06-cfg-only-Exterior-failed-phase-context02.v1',original_draft=ref(old),actual_failed_beam_55_06=ref(failure),author_Source=ref(Path(__file__)),qualification='Only fresh rustfmt stdout for newly changed cfg contexts and correct actual failed command ref; all scientific operations/state/operands/call order and old01 history preserved.')
print(json.dumps(dict(draft=save(O/'draft.json',d),plan=d['complete_proposed_compiler_Source_plan']),indent=2))

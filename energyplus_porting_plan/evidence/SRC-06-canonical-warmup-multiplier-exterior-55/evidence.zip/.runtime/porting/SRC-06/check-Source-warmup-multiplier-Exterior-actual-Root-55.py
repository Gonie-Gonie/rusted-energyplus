"""Read-only actual55 checker. This never launches any scientific command."""
from pathlib import Path
import importlib.util,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
s=importlib.util.spec_from_file_location('guard55_actual',D/'gap-warmup-multiplier-Exterior-guards-Peer-55.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
def main():
 ar=g.ref(h.APP/'receipt.json');app=g.read(g.checked(ar));g.need(app['accepted']and not app['findings']and app['all_final_compiler_bytes_exact'],'Genuine application55')
 pr,p,d=h.prepared(app['prepared']['path']+'#'+app['prepared']['sha256']);g.need(g.checked(p['actual_checker_Source'])==Path(__file__).resolve(),'Exact checker Source');h.current_head(app['base_HEAD'])
 fixture_map,protected=h.fixtures(p);g.need(fixture_map==app['fixtures']and protected==app['protected_all_seven_external_fixtures'],'Application fixtures exact')
 plan=g.read(g.checked(app['complete_compiler_plan']));g.need(h.counts(plan)==(4554,4541,4554),'Actual final compiler counts');rows={x['path']:x for x in plan['entries']};g.exact(rows)
 apply=g.literal();selected=[]
 for f in d['files']:
  b=b''if f.get('before_absent',f['before']is None)else g.checked(f['before']).read_bytes();a=g.checked(f['proposed']).read_bytes();fw,iv=h.diffs(f)
  g.need(apply(b,g.checked(fw).read_bytes())==a and apply(a,g.checked(iv).read_bytes())==b and(R/f['canonical_path']).read_bytes()==a,'Exact current/forward/inverse Source '+f['canonical_path']);selected.append(f['canonical_path'])
 g.need(len(set(selected))==38,'All38 selected Sources');results=[]
 target=(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
 for at,(group,records,bits,token)in enumerate([
  ('warmup',69,45072,'Native warmup cohort: 69 full persistent RecKeep/Check calls; 45072 strict finite fields; no prior cohort rerun'),
  ('multiplier_predictor',21,17893,'Multiplier2 genuine persistent full calls=21; strict raw-bit state/return observations=17893; raw getter multiplier2; no history/expected restore; private cache unobserved'),
  ('exterior',170,None,None)]):
  rr=g.ref(D/('canonical-source-gap-batch-'+group+'-Root-55/receipt.json'));run=g.read(g.checked(rr));g.need(run['exit_code']==0 and run['launch_error']is None and run['source_bytes_match_before_and_after'],'Actual successful stable '+group)
  g.need(run['repository_before']==run['repository_after']and run['repository_before']['head']==app['base_HEAD'],'Actual repository custody '+group)
  command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only',group,str(g.checked(fixture_map[group]))];g.need(run['command']==command,'Exact selected actual argv')
  env=run['launch_environment_selected'];g.need(Path(env['CARGO_TARGET_DIR']).resolve()==target and all(v is None for k,v in env.items()if k!='CARGO_TARGET_DIR'),'Exact target/environment profile');g.need(not run['cargo_compiler_artifacts_capture']['requested'],'Original recorder mode')
  guards=[]
  for phase in ['before','after']:
   gr=g.ref(D/('Root-runtime-fixture-'+group+'-guard-55')/(phase+'.json'));guard=g.read(g.checked(gr));g.need(guard['application']==ar and guard['command']==command and guard['selected_group']==group,'Actual custody '+phase)
   if phase=='before':g.need(guard['protected']==protected,'Before seven-fixture custody')
   else:g.need(guard['accepted']and not guard['findings']and guard['exit_code']==0 and guard['actual_receipt']==rr and guard['protected_before']==guard['protected_after']==protected and guard['all4554_compiler_inputs_unchanged']and guard['launch_Source']==p['launch_Source'],'After Source/all-seven fixture custody')
   guards.append(gr)
  sr=g.ref(R/run['source_snapshot']['path']);g.need(sr['sha256']==run['source_snapshot']['sha256'],'Recorded Source snapshot ref');snap=g.read(g.checked(sr));archive={x['historical_path']:x for x in snap['files']};g.need(archive.keys()==rows.keys(),'All recorded compiler input names')
  for name,row in rows.items():
   e=archive[name];v=g.ref(R/e['archive']['path']);g.need(v['sha256']==e['archive']['sha256']==row['final_sha256']and v['bytes']==e['size_bytes']==row['final_bytes'],'Whole archived Source '+name)
  logs={k:g.ref(R/run[k]['path'])for k in ['stdout','stderr']};g.need(all(logs[k]['sha256']==run[k]['sha256']for k in logs),'Exact actual logs');lines=g.checked(logs['stdout']).read_text(encoding='utf-8').splitlines()
  g.need(len(lines)==4 and lines[0]=='running 1 original-core gap cohort group='+group+' on process main'and lines[2]=='cohort native_controlled_air_cohort ... ok'and lines[3]=='cohort result: ok. 1 passed; 0 failed; group='+group+'; full-call records='+str(records)+'; private cache state unobserved','Only selected complete Source group')
  exterior=None
  if token:g.need(lines[1]==token,'Exact declared numeric observation summary')
  else:
   match=re.fullmatch(r'Source Exterior cohort: 170 admitted call records; Native full 179 retained; 9 exploratory shading records outside CON-01; Weather phase checks (\d+); same-process owner assertions only; Source output directory (.+)',lines[1]);g.need(match and int(match[1])>0,'Complete qualified Exterior summary');exterior=dict(admitted_records=170,Native_retained_records=179,excluded_exploratory_records=9,weather_phase_checks=int(match[1]),Source_output_directory=match[2],raw_bit_denominator_not_invented=True)
  err=g.checked(logs['stderr']).read_text(encoding='utf-8');g.need('Finished `test` profile'in err and 'Running src\\lib.rs ('in err and not re.search(r'^error(?:\[|:)',err,re.M),'Contextual compilation and actual invocation');compiles=len(re.findall(r'^\s*Compiling ep_runtime ',err,re.M));g.need(compiles==(1 if at==0 else 0),'Exactly one contextual ep_runtime rebuild')
  results.append(dict(group=group,Source_compared_call_records=records,Source_strict_state_and_return_raw_fields=bits,qualified_Exterior=exterior,actual_Source_receipt=rr,external_fixture=fixture_map[group],fixture_projection=p['fixture_proofs'][group],fixture_before_after_guards=guards,recorded_source_snapshot=sr,all4554_archived_compiler_inputs_exact=True,logs=logs,ep_runtime_compile_messages=compiles))
 g.need(all(r['recorded_source_snapshot']==results[0]['recorded_source_snapshot']for r in results),'All three actual groups same Source snapshot');g.exact(rows)
 result=dict(schema='src06-Source55-three-group-actual-review.v1',accepted=True,findings=[],base_HEAD=app['base_HEAD'],application=ar,prepared=pr,complete_compiler_plan=app['complete_compiler_plan'],compiler_inputs=4554,Rust_sources=4541,selected_Source_files=selected,literal_applications=76,all4554_current_and_three_archived_inputs_exact=True,three_groups_same_recorded_Source_snapshot=True,groups=results,all_seven_external_fixtures_stable=True,semantic_peers=p['semantic_peers'],joint_independent_peer=p['joint_independent_peer'],environment_guard=p['environment_guard'],record_command_Source=p['record_command_Source'],gate_changes=False,policy_changes=0,additional_engine_or_Cargo_invocations=0,qualification='Only selected genuine warmup69, multiplier21 and admitted Exterior170 records. Nine whole retained Exterior exploratory shading records are explicitly outside finite admission. Full warmup-parent timestep cadence/whole final fifteen input snapshots and unobserved private property-cache state remain unclaimed. Prior successful cohorts are not reexecuted by these commands.',author_Source=g.ref(Path(__file__)))
 out=D/'Root-Source-warmup-multiplier-Exterior-actual-review-55';g.need(not out.exists(),'Fresh aggregate55 directory');out.mkdir();p=out/'review.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(p)))
if __name__=='__main__':main()

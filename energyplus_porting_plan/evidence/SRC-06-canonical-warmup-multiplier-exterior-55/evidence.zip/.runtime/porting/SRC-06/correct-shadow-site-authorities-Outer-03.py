"""Narrow comments and exact CHKGSS source-span custody; no formula changes."""
from pathlib import Path
import copy,difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode());return ref(p)
def diff(p,a,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='preserved',tofile='precise-authority')).encode());return ref(p)
def change_row(row,folder,old,new):
 a=(R/row['proposed']['path']).read_bytes();assert a.count(old.encode())==1;b=a.replace(old.encode(),new.encode(),1);p=folder/'proposed'/row['canonical_path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);row['proposed']=ref(p)
 before=(R/row['before']['path']).read_bytes();row['forward']=diff(folder/'diffs'/f"{row['canonical_path']}.forward.diff",before,b);row['inverse']=diff(folder/'diffs'/f"{row['canonical_path']}.inverse.diff",b,before)
 run=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert run.returncode==0,run.stderr
 po=folder/'parse'/f"{row['canonical_path']}.stdout.rs";po.parent.mkdir(parents=True,exist_ok=True);po.write_bytes(run.stdout);pe=po.with_suffix('.stderr.txt');pe.write_bytes(run.stderr)
 row['Source_only_parse']={'argv':['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],'stdin':ref(p),'stdout':ref(po),'stderr':ref(pe),'exit_code':0,'syntax_only':True}
 return {'forward':diff(folder/'correction.forward.diff',a,b),'inverse':diff(folder/'correction.inverse.diff',b,a)}
def main():
 result={}
 p=D/'source-site-atmosphere-cold-owner-draft-Outer-01/draft.json';v=json.loads(p.read_bytes());o=D/'source-site-atmosphere-cold-owner-draft-Outer-02';assert not o.exists();o.mkdir()
 v['preserved01']=ref(p);v['comment_only_correction']=change_row(v['Sources'][0],o,'    /// Uses the already reached station and sole HBM string/IP/EIO owners.','    /// Uses the same live environment and sole HBM string/IP/EIO owners.');v['author_Source']=ref(Path(__file__));result['site02']=save(o/'draft.json',v)
 p=D/'source-general-shadow-shared-Figure-draft-Outer-02/draft.json';v=json.loads(p.read_bytes());o=D/'source-general-shadow-shared-Figure-draft-Outer-03';assert not o.exists();o.mkdir()
 row=[r for r in v['Sources'] if r['canonical_path'].endswith('/general_shadow.rs')][0]
 v['preserved02']=ref(p);v['comment_only_Source_correction']=change_row(row,o,'SolarShading2855-2947 CHKGSS','SolarShading2851-2943 CHKGSS');v['author_Source']=ref(Path(__file__))
 authority=v['Native_authorities'][0];first,last=2851,2943;whole=R/authority['whole']['path'];ls=whole.read_bytes().splitlines(True);q=o/'Native-CHKGSS-2851-2943.cc';q.write_bytes(b''.join(ls[first-1:last]));authority['extents'][0]={'first':first,'last':last,'source':ref(q)}
 v['authority_correction']='02 CHKGSS supplemental span2855-2948 omitted its header and included the next function signature. Full pinned Native whole was correct. 03 binds the actual full2851-2943 function; only matching Source doc line changes. Determine5247-5619 is explicitly the numerical prefix through local deallocations; existing separate genuine shading-report child owns its later effects.'
 result['shadow03']=save(o/'draft.json',v);print(json.dumps(result))
if __name__=='__main__':main()

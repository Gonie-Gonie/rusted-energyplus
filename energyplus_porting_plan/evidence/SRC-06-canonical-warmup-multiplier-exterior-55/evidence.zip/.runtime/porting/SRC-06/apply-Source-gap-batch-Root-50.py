"""Root-only one Source50 application over actual failed-but-stable P1 compiler inputs."""
from pathlib import Path
import argparse,importlib.util,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OUT=D/'Root-gap-batch-P1-Surface-application-50'
def module(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
g=module(D/'apply-purchased-air-gap-cohort-Root-P1.py','original_P1_readonly_guards')

def fixtures(d,group):
 if group=='purchased_air':
  proof,refs=g.fixture(d['P1_fixture_proof']);g.need(proof['fixture']==d['P1_fixture'],'Same P1 runtime fixture');return proof['fixture'],refs
 g.need(group=='surface','Only implemented Source50 group')
 hub=g.read(g.checked(d['Surface_hub_fixture']));actual=g.read(g.checked(hub['actual_Native_receipt']))
 g.need(actual['accepted'] and not actual['findings'] and actual['exit_code']==0 and actual['selected_group']=='surface','Accepted actual Native Surface group')
 g.need(actual['Native_bytes_match_before_and_after'] and actual['actual_three_GNU_DLL_binding_proved_before_any_science_call'],'Actual Native Surface custody/modules')
 g.need(actual['full_unit_output']==hub['actual_Native_full_output'] and actual['actual_build']==hub['actual_Native_build'],'Actual Surface output/build binding')
 manifest=g.read(g.checked(actual['reviewed_manifest']));g.need(manifest['named_inputs']==hub['actual_Native_named_inputs'],'Actual Surface named input binding')
 named=g.read(g.checked(hub['actual_Native_named_inputs']));output=g.read(g.checked(hub['actual_Native_full_output']));wrapper=g.read(g.checked(hub['runtime_fixture']))
 g.need(wrapper==dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output),'Entire lossless Surface wrapper')
 g.need(output['normal_completion'] is True and output['group_order']==['surface'] and set(output['groups'])=={'surface'},'Exactly completed Surface group')
 refs=[d['Surface_hub_fixture'],hub['runtime_fixture'],hub['actual_Native_receipt'],hub['actual_Native_build'],hub['actual_Native_named_inputs'],hub['actual_Native_full_output'],actual['reviewed_manifest']]
 return hub['runtime_fixture'],[g.ref(g.checked(x)) for x in refs]

def main(a):
 dr=g.argument(a.draft);d=g.read(g.checked(dr));g.need(d['status']=='FROZEN_WAIT_NARROW_CORRECTION_HUB_JOIN_PEER','Expected immutable Source50 draft')
 peer_ref=g.argument(a.peer);peer=g.read(g.checked(peer_ref));g.need(peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==dr,'Exact accepted correction/hub/join peer')
 for pk,dk in [('original_P1_full_peer','original_P1_scaffold'),('runtime_runner_peer','original_runtime_runner'),('Surface_full_independent_peer','Surface_adapter'),('P1_independent_correction_peer','P1_two_binding_correction')]:
  p=g.read(g.checked(d[pk]));g.need(p['accepted'] and not p['findings'] and p['reviewed_draft']==d[dk],'Carried actual peer '+pk)
 g.need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==d['base_HEAD'],'Actual committed Source49 HEAD')
 failed=g.read(g.checked(d['failed_initial_P1_compile']));g.need(failed['exit_code']==101 and failed['source_bytes_match_before_and_after'],'Actual first failed compile retained, no pass inferred')
 parent=g.read(g.checked(d['actual_parent4528_plan']));g.need((parent['inputs'],parent['Rust_sources'])==(4528,4515),'Current compiler parent counts')
 g.exact({x['path']:x for x in parent['entries']})
 plan=g.read(g.checked(d['complete_proposed_compiler_Source_plan']));g.need((plan['inputs'],plan['Rust_sources'])==(4534,4521),'Final compiler counts');final={x['path']:x for x in plan['entries']}
 protected=[]
 for group in ['purchased_air','surface']:
  _,refs=fixtures(d,group);protected+=refs
 protected=list({x['path']:x for x in protected}.values());apply=g.literal();materials=[]
 for row in d['actual_apply_delta']:
  name=row['canonical_path'];target=R/name;old=g.checked(row['before']).read_bytes() if row['before'] else b'';proposed=g.checked(row['proposed']).read_bytes()
  g.need(target.exists()==(row['before'] is not None),'Delta target existence '+name)
  if target.exists():g.need(target.read_bytes()==old,'Actual delta before '+name)
  g.need(apply(old,g.checked(row['forward_diff']).read_bytes())==proposed and apply(proposed,g.checked(row['inverse_diff']).read_bytes())==old,'Exact two literal applications '+name)
  materials.append((name,old,proposed,row['before'] is not None))
 g.need(len(materials)==15 and sum(x[3] for x in materials)==9,'Exactly15 delta Sources,9existing6new')
 g.need(not OUT.exists(),'Fresh application directory');OUT.mkdir()
 for name,old,_,exists in materials:
  if exists:
   p=OUT/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old)
 try:
  for name,_,proposed,_ in materials:
   p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(proposed)
  g.exact(final);g.need([g.ref(g.checked(x)) for x in protected]==protected,'Both external fixtures unchanged')
 except BaseException:
  for name,old,_,exists in materials:
   if exists:(R/name).write_bytes(old)
   elif (R/name).exists():(R/name).unlink()
  raise
 result=dict(schema='src06-coherent-gap-Source50-application.v1',accepted=True,findings=[],draft=dr,independent_join_peer=peer_ref,base_HEAD=d['base_HEAD'],
  complete_compiler_plan=d['complete_proposed_compiler_Source_plan'],initial_failed_P1_compile=d['failed_initial_P1_compile'],initial_P1_application=d['initial_P1_application'],
  changed_files_this_application=15,existing=9,new=6,unique_Source_bundle_vs49=20,compiler_inputs=4534,Rust_sources=4521,all_final_compiler_bytes_exact=True,
  protected_external_fixture_refs=protected,all_original_2336_471_59_P2_bodies_unchanged=True,test_or_CLI_invocations=0,application_Source=g.ref(Path(__file__)))
 p=OUT/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(p)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--draft',required=True);p.add_argument('--peer',required=True);main(p.parse_args())

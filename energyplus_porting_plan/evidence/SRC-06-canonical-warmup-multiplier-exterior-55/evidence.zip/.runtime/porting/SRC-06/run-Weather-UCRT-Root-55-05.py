"""Root-only reviewed scalar CRT correction and one failed Exterior retry."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
    b=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p.resolve()),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
    p=R/v['path'];a=ref(p)
    assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',a['bytes']),v
    return p
def load(v): return json.loads(checked(v).read_bytes())
def save(p,v):
    assert not p.exists();p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf8',newline='\n');return ref(p)
def contains(v,r):
    if isinstance(v,dict): return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
    return isinstance(v,list) and any(contains(x,r) for x in v)
def exact(plan):
    entries=plan['entries'];assert len(entries)==plan['compiler_inputs']
    names={p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')}
    names|={p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')}
    names|={'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
    assert names=={e['path'] for e in entries}
    for e in entries:
        a=ref(R/e['path']);z=ref(checked(e['source']))
        assert (a['sha256'],a['bytes'])==(e['final_sha256'],e['final_bytes'])==(z['sha256'],z['bytes'])
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--peer',required=True);a=ap.parse_args()
    dr=dict(path='.runtime/porting/SRC-06/source-Weather-UCRT-math-provider-Outer-55-05-02/draft.json',sha256='9574855e44ac558d08b3be57721e2efe9812807b1d0a4d81986c3a4488e4acc0')
    draft=load(dr);path,sha=a.peer.rsplit('#',1);peerref=ref(checked(dict(path=path,sha256=sha)));peer=load(peerref)
    assert peer['accepted'] and not peer['findings'] and contains(peer,dr)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==draft['base_HEAD']
    oldplan=load(draft['prior_complete_compiler_Source_plan']);newplan=load(draft['complete_proposed_compiler_Source_plan']);exact(oldplan)
    assert (len(oldplan['entries']),len(newplan['entries']))==(4554,4556)
    oldrows={e['path']:e for e in oldplan['entries']};newrows={e['path']:e for e in newplan['entries']}
    assert oldrows.keys()<=newrows.keys()
    assert {n for n in newrows if newrows[n]!=oldrows.get(n)}=={x['canonical_path'] for x in draft['files']}
    guardpath=D/'gap-warmup-multiplier-Exterior-guards-Peer-55-03.py'
    assert ref(guardpath)['sha256']=='5f7912efe50ee22b3962f125bb5a82278e22a4d6a6013c90a857766bd0fac75f'
    s=importlib.util.spec_from_file_location('reviewed55guard',guardpath);h=importlib.util.module_from_spec(s);s.loader.exec_module(h);apply=h.g.literal()
    changes=[]
    for row in draft['files']:
        target=(R/row['canonical_path']).resolve();assert target.is_relative_to(R)
        before=b'' if row['before_absent'] else checked(row['before']).read_bytes();after=checked(row['proposed']).read_bytes()
        assert (not target.exists()) if row['before_absent'] else target.read_bytes()==before
        assert apply(before,checked(row['forward_diff']).read_bytes())==after
        assert apply(after,checked(row['inverse_diff']).read_bytes())==before
        assert not target.suffix=='.rs' or b'\x00' not in after
        changes.append((target,after))
    assert len(changes)==8 and sum(row['before_absent'] for row in draft['files'])==2
    assert b'unsafe_code = "forbid"' in dict((p.relative_to(R).as_posix(),b) for p,b in changes)['Cargo.toml']
    assert b'[lints]\nworkspace = true' in dict((p.relative_to(R).as_posix(),b) for p,b in changes)['crates/ep_runtime/Cargo.toml']
    failed=load(draft['actual_Source_failure']);assert failed['exit_code']==1 and failed['source_bytes_match_before_and_after']
    for key in ['actual_failure_stderr','actual_Source_snapshot','actual_binary_imports','Root_same_operand_CRT_diagnosis']:checked(draft[key])
    p=json.loads((D/'warmup-multiplier-Exterior-Root-helpers-ready-Peer-55-03/prepared.json').read_bytes());fixtures,protected=h.fixtures(p)
    fixture_before=[ref(checked(v)) for v in protected]
    envpath=checked(p['environment_guard']);es=importlib.util.spec_from_file_location('reviewedenv55',envpath);em=importlib.util.module_from_spec(es);es.loader.exec_module(em);env=em.environment()
    folder=D/'Root-Weather-UCRT-application-55-05';output=D/'canonical-source-gap-batch-exterior-Root-55-05'
    assert not folder.exists() and not output.exists();folder.mkdir()
    for target,after in changes:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after)
    exact(newplan)
    app=save(folder/'receipt.json',dict(schema='src06-Root-UCRT-inverse-trig-application.v1',accepted=True,findings=[],draft=ref(checked(dr)),independent_peer=peerref,base_HEAD=draft['base_HEAD'],complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'],changed_files=[p.relative_to(R).as_posix() for p,_ in changes],compiler_inputs=4556,Rust_sources=4542,all_unchanged_parent_entries_exact=True,all_literal_applications=16,workspace_and_Runtime_unsafe_forbid_preserved=True,qualification='Only actual DetermineSunUpDown inverse trig selects System32 UCRT. Other math symbols and original expressions remain. Typed provider failure has no numeric fallback. Earlier warmup02/multiplier03 results require explicit disjoint readset carry; no same binary/snapshot claim.',prior_failed_Exterior=draft['actual_Source_failure'],author_Source=ref(Path(__file__))))
    command=['cargo','test','--locked','-p','ep_runtime','--features','native-controlled-air-cohort','--test','native_controlled_air_cohort','--','--gap-batch-only','exterior',str(checked(fixtures['exterior']))]
    print('Root55-05: actual UCRT inverse trig; retry failed Exterior only; no old passed group rerun.',flush=True)
    code=subprocess.call([sys.executable,str(checked(p['record_command_Source'])),'--output-dir',str(output),'--',*command],cwd=R,env=env)
    exact(newplan);fixture_after=[ref(checked(v)) for v in protected];assert fixture_before==fixture_after
    save(folder/'actual.json',dict(schema='src06-Root-UCRT-Exterior-attempt.v1',accepted=code==0,findings=[] if code==0 else ['Actual Exterior failed; retain complete recorded command/logs.'],application=app,actual_receipt=ref(output/'receipt.json'),command=command,exit_code=code,protected_before=fixture_before,protected_after=fixture_after,complete_compiler_plan=draft['complete_proposed_compiler_Source_plan'],Source_and_seven_fixtures_stable=True,author_Source=ref(Path(__file__))))
    return code
if __name__=='__main__':sys.exit(main())

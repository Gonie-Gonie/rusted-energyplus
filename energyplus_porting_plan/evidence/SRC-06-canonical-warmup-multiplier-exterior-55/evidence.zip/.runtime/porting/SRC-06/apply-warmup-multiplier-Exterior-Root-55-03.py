"""Root-only two cfg corrections on authentic55-02; passed warmup is not reexecuted."""
from pathlib import Path
import argparse,importlib.util,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
s=importlib.util.spec_from_file_location('guard55_retry',D/'gap-warmup-multiplier-Exterior-guards-Peer-55-03.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);g=h.g
def main(a):
 pr,p,d=h.prepared(a.prepared);g.need(g.checked(p['application_Source'])==Path(__file__).resolve(),'Exact corrective application Source');h.current_head(p['base_HEAD']);worktree=h.bounded_existing_worktree(p)
 old=g.read(g.checked(p['prior_compiler_plan']));g.need(h.counts(old)==(4554,4541,4554),'Exact applied55-02 parent');before={x['path']:x for x in old['entries']};g.exact(before);snapshot=h.parent_archive(p)
 final=g.read(g.checked(p['complete_compiler_plan']));g.need(h.counts(final)==(4554,4541,4554),'Corrected compiler counts');rows={x['path']:x for x in final['entries']};fixtures,protected=h.fixtures(p);apply=g.literal();materials=[]
 for f in d['files']:
  name=f['canonical_path'];target=(R/name).resolve();g.need(target.is_relative_to(R)and name.startswith('crates/ep_runtime/src/'),'Bounded cfg correction target')
  b=g.checked(f['before']).read_bytes();after=g.checked(f['proposed']).read_bytes();g.need(target.is_file()and target.read_bytes()==b,'Actual reviewed correction before '+name);fw,iv=h.diffs(f)
  g.need(apply(b,g.checked(fw).read_bytes())==after and apply(after,g.checked(iv).read_bytes())==b,'Exact corrected literal pair '+name);materials.append((name,b,after))
 g.need(len(materials)==2,'Two corrective Sources only');overlay={name:(row['final_sha256'],row['final_bytes'])for name,row in before.items()}
 for name,_,after in materials:overlay[name]=(g.ref(g.checked(next(f['proposed']for f in d['files']if f['canonical_path']==name)))['sha256'],len(after))
 g.need(overlay=={name:(row['final_sha256'],row['final_bytes'])for name,row in rows.items()},'Only two full-plan rows change');g.need(not h.APP.exists(),'Fresh retry application path');h.APP.mkdir()
 for name,b,_ in materials:
  path=h.APP/'before'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
 try:
  for name,_,after in materials:(R/name).write_bytes(after)
  g.exact(rows);selected=h.coherent_selected(p,d);g.need([g.ref(g.checked(v))for v in protected]==protected,'All seven fixtures/proofs unchanged')
 except BaseException:
  for name,b,_ in materials:(R/name).write_bytes(b)
  raise
 result=dict(schema='src06-Source55-03-two-cfg-corrections-application.v1',accepted=True,findings=[],prepared=pr,base_HEAD=p['base_HEAD'],correction=p['correction'],correction_leaf_peers=p['correction_leaf_peers'],prior_application=p['prior_application'],preserved_failed_Source_attempts=p['failed_Source_attempts'],carried_warmup=p['carried_warmup_receipt'],prior_compiler_plan=p['prior_compiler_plan'],complete_compiler_plan=p['complete_compiler_plan'],changed_Source_files=2,original_selected_Source_files=selected,original_bundle_files=38,compiler_inputs=4554,Rust_sources=4541,all_final_compiler_bytes_exact=True,prior55_02_compiler_snapshot=snapshot,warmup_impact_bridge=h.warmup_impact_bridge(p,d),prior_worktree=worktree,fixtures=fixtures,protected_all_seven_external_fixtures=protected,actual_Cargo_or_CLI_invocations=0,application_Source=g.ref(Path(__file__)))
 out=h.APP/'receipt.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(g.ref(out)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prepared',required=True);main(p.parse_args())

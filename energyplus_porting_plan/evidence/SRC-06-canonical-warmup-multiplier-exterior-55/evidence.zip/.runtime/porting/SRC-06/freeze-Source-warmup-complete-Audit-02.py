"""Freeze the genuine warmup caller/observer and whole actual runtime fixture; no compiler/run."""
from pathlib import Path
import ast, copy, difflib, hashlib, json, re, subprocess

R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
O=D/'source-warmup-complete-draft-Audit-02'
F=D/'source-warmup-runtime-fixture-Audit-01'

def ref(p):
    b=p.read_bytes()
    try:path=p.relative_to(R).as_posix()
    except ValueError:path=p.as_posix()
    return dict(path=path,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

def checked(v):
    p=Path(v['path']);p=p if p.is_absolute() else R/p
    a=ref(p);assert (a['sha256'],a['bytes'])==(v['sha256'],v['bytes']);return p

def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n')
    return ref(p)

def formatted(b):
    r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True)
    assert r.returncode==0,r.stderr.decode();return r.stdout

assert not O.exists() and not F.exists()
old_path=D/'source-warmup-owner-caller-draft-Audit-01/draft.json'
old=json.loads(old_path.read_bytes())
run_path=D/'original-core-gap-batch-run-Root-08-warmup/receipt.json'
assert ref(run_path)['sha256']=='9c7b8e7ea7885e5e080bb5fc846fbb19d539d5ee694cdec0f4dc3d4a9c69a56f'
run=json.loads(run_path.read_bytes())
assert run['accepted'] and run['exit_code']==0 and run['launch_error'] is None
assert run['Native_bytes_match_before_and_after'] and run['actual_three_GNU_DLL_binding_proved_before_any_science_call']
ready=json.loads(checked(run['reviewed_manifest']).read_bytes())
named_path=checked(ready['named_inputs']);named=json.loads(named_path.read_bytes())
unit=json.loads(checked(old['Native_unit']).read_bytes())
assert named['warmup']==json.loads(checked(unit['named_inputs']).read_bytes())
output_path=checked(run['full_unit_output']);output=json.loads(output_path.read_bytes())
assert output['normal_completion'] is True and output['group_order']==['warmup'] and set(output['groups'])=={'warmup'}
assert output['groups']['warmup']['schema']=='src06-warmup-RecKeep-Check-output.v1'
source_path=checked(old['primary_input']);source=json.loads(source_path.read_bytes())
assert len(source['factories'])==len(named['warmup']['cases'])==len(output['groups']['warmup']['cases'])==6
states=[];records=checks=0
for case,out,factory in zip(named['warmup']['cases'],output['groups']['warmup']['cases'],source['factories']):
    assert case['name']==out['name']==factory['name'] and case['origin']==out['origin']
    assert case['initial_phase']==out['initial_phase']
    assert case['factory']['input_file']==factory['input_file'] and case['steps']==factory['steps']
    assert len(case['steps'])==len(out['steps'])
    states.append(out['after_real_factory_project_and_allocation'])
    for at,(step,observed) in enumerate(zip(case['steps'],out['steps']),1):
        assert observed['ordinal']==at and observed['named_inputs']==step
        assert observed['name']==step['name'] and observed['operation']==step['operation']
        assert step['operation'] in ('record','check')
        records+=step['operation']=='record';checks+=step['operation']=='check'
        states.extend((observed['entry'],observed['exit']))
assert (records,checks,len(states))==(50,19,144)
def bits(v):
    if isinstance(v,dict):
        if set(v)=={'value_bits'}:
            assert re.fullmatch('[0-9a-f]{16}',v['value_bits']);return 1
        return sum(map(bits,v.values()))
    if isinstance(v,list):return sum(map(bits,v))
    return 0
state_bits=sum(map(bits,states))
assert all(isinstance(s['manager']['DoReport'],bool) and s['surface_child_domain']['intMovInsulSurfNums']==[] for s in states)

# Whole lossless external wrapper. Preserve each source tree separately, with no projection of results.
F.mkdir()
fixture=save(F/'fixture.json',dict(schema='src06-Native-gap-batch-fixture.v1',named_inputs=named,native_output=output,source_inputs=source))
roundtrip=json.loads(checked(fixture).read_bytes())
assert roundtrip['named_inputs']==named and roundtrip['native_output']==output and roundtrip['source_inputs']==source
projection=save(F/'projection.json',dict(schema='src06-whole-warmup-runtime-fixture-proof.v1',accepted=True,findings=[],
    actual_Native_group_run=ref(run_path),exact_Native_named_inputs=ref(named_path),exact_Native_output=ref(output_path),
    Source_scaffold=ref(old_path),Source_primary_input=ref(source_path),Source_primary_transport=old['primary_transport'],fixture=fixture,
    whole_named_inputs_inverse=True,whole_Native_output_inverse=True,whole_Source_input_inverse=True,
    wrapper_exact_keys=['schema','named_inputs','native_output','source_inputs'],persistent_lifetimes=6,original_method_calls=69,
    operations=dict(record=50,check=19),snapshots=144,strict_state_binary64_fields=state_bits,
    entire_Native_output_finite_binary64_fields=bits(output),actual_Native_admission=run['admission'],
    no_expected_output_used_as_live_input=True,external_fixture_not_compiled_constant=True,
    qualification='Whole original Native output retained. Source compares all modeled observations with explicit exclusions only for unused DoReport and unconsumed constructor-empty intMovInsulSurfNums; native named primary bit fields are counted separately from observed state fields.',
    author_Source=ref(Path(__file__))))

base=(D/'Source-warmup-caller-author-Audit-01.rs').read_text(encoding='utf-8')
base=base.replace('    fn call(&mut self,step:&Value)->Result {','    fn prepare_call(&mut self,step:&Value)->Result {',1)
anchor='''        self.weather.global.day_of_sim=int(member(clock,"day_of_sim")?)?;
        self.weather.global.hour_of_day=int(member(clock,"hour")?)?;
        self.weather.global.time_step=int(member(clock,"timestep")?)?;'''
replacement='''        if object(clock)?.len()!=3 {return Err(invalid("exact named warmup clock fields").into());}
        let day=int(member(clock,"day_of_sim")?)?;let hour=int(member(clock,"hour")?)?;let timestep=int(member(clock,"timestep")?)?;
        if day<=0 || !(1..=24).contains(&hour) || !(1..=self.weather.global.time_steps_in_hour).contains(&timestep) {
            return Err(invalid("actual named warmup clock domain").into());
        }
        self.weather.global.day_of_sim=day;self.weather.global.hour_of_day=hour;self.weather.global.time_step=timestep;'''
assert base.count(anchor)==1;base=base.replace(anchor,replacement,1)
needle='''                if index(int(member(row,"ordinal")?)?)?!=at {return Err(invalid("actual warmup Zone input ordinal").into());}'''
assert base.count(needle)==1;base=base.replace(needle,'''                if object(row)?.len()!=4 || index(int(member(row,"ordinal")?)?)?!=at {return Err(invalid("actual warmup Zone input fields/ordinal").into());}''',1)
anchor='''        self.synchronize_diagnostic_inputs();
        match operation {'''
assert base.count(anchor)==1;base=base.replace(anchor,'''        if !matches!(operation,"record"|"check") {return Err(invalid("actual full warmup operation").into());}
        self.synchronize_diagnostic_inputs();
        Ok(())
    }
    fn invoke(&mut self,step:&Value)->Result {
        let operation=text(member(step,"operation")?)?;
        match operation {''',1)
needle='''        let mut input = make_input(definitions, definition)?;'''
assert base.count(needle)==1;base=base.replace(needle,'''        if object(phase)?.len()!=5 {return Err(invalid("exact initial warmup caller phase fields").into());}
'''+needle,1)
base=base[:base.index('// Complete same-owner observations')]
observer=(D/'Source-warmup-observer-author-Audit-02.rs').read_text(encoding='utf-8')
bridge='''
impl OrdinaryEquipment {
    pub(crate) fn run_native_gap_warmup_cohort(fixture: &Value) -> Result<usize> {
        run(fixture)
    }
}
'''
child_bytes=formatted((base+'\n'+observer+'\n'+bridge).encode())
parent=old['files'][0]['canonical_future_path'];init=old['files'][1]['canonical_future_path'];child=old['files'][2]['canonical_future_path']
hub='crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs'
before_parent=checked(old['files'][0]['before']).read_bytes();before_init=checked(old['files'][1]['before']).read_bytes()
assert (R/parent).read_bytes()==before_parent and (R/init).read_bytes()==before_init
hub_before=(R/hub).read_bytes();hub_after=hub_before.replace(b'|"air_history")',b'|"air_history"|"warmup")',1)
needle=b'        "air_history"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_air_history_cohort(&fixture),'
assert hub_after.count(needle)==1
hub_after=hub_after.replace(needle,needle+b'\n        "warmup"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_warmup_cohort(&fixture),',1)
assert hub_after!=hub_before
proposals=[(parent,before_parent,checked(old['files'][0]['proposed']).read_bytes()),
    (init,before_init,checked(old['files'][1]['proposed']).read_bytes()),(child,b'',child_bytes),(hub,hub_before,hub_after)]
tree=ast.parse((D/'freeze-Source-P4-scaffold-Audit-01.py').read_text(encoding='utf-8'))
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply');ns={'re':re}
exec(compile(ast.Module(body=[node],type_ignores=[]),'<literal-only>','exec'),ns)
O.mkdir();files=[]
for path,before,after in proposals:
    p=O/'proposed'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after)
    a=O/'before'/path;a.parent.mkdir(parents=True,exist_ok=True);a.write_bytes(before)
    forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=path,tofile=path)).encode()
    inverse=''.join(difflib.unified_diff(after.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile=path,tofile=path)).encode()
    f=O/'diffs'/(path+'.forward.diff');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(forward)
    i=f.with_name(f.name.replace('forward','inverse'));i.write_bytes(inverse)
    assert ns['apply'](before,forward)==after and ns['apply'](after,inverse)==before
    q=O/'parse'/(path+'.stdout.rs');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(formatted(after))
    files.append(dict(canonical_path=path,before_absent=not before,before=ref(a),proposed=ref(p),forward_diff=ref(f),inverse_diff=ref(i),
        Source_only_parse=dict(exit_code=0,stdout=ref(q),syntax_only=True)))

draft=save(O/'draft.json',dict(schema='src06-private-full-Source-warmup-caller-observer-draft.v1',
    status='FROZEN_FULL_PRIVATE_SOURCE_ACTUAL_NATIVE_FIXTURE_ROOT_TYPECHECK_AND_RUNTIME_PENDING',
    observed_HEAD=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),
    files=files,original_primary_caller_draft=ref(old_path),primary_input=ref(source_path),primary_transport=old['primary_transport'],
    actual_Native_group_run=ref(run_path),actual_Native_build=run['actual_build'],runtime_fixture=fixture,runtime_fixture_projection=projection,
    Native_unit=old['Native_unit'],independent_Native_unit_peer=old['independent_Native_unit_peer'],
    Source_owner_contexts=old['Source_owner_contexts'],literal_applications=8,Source_syntax_parses=4,
    same_owner_observations=dict(persistent_lifetimes=6,full_method_calls=69,snapshots=144,strict_state_binary64_fields=state_bits,
        rolling_arrays=16,report_matrices=3,convergence_flags_and_values=8,whole_error_text_and_six_counters=True,
        primary_stage_view='Before true calls and after true Check, Source backend warmup/sizing views derive from the same live clock/globals. No Native expected phase field is restored.'),
    explicit_unmodeled_unconsumed_Native_observations=[
        dict(path='manager.DoReport',qualification='Native unused legacy constructor bool; neither RecKeep nor Check reads/writes it. No Source cell manufactured.'),
        dict(path='surface_child_domain.intMovInsulSurfNums',qualification='Native constructor-empty unused list verified by real unit factory and every output snapshot. AnyMovableInsulation actualfalse makes the consumer path unreachable. No Source empty row invented.')],
    no_Native_expected_output_restored=True,no_expected_tolerance_or_math_change=True,
    no_new_feature_target_or_test_body=True,old_scientific_cohort_bodies_and_fixtures_unchanged=True,
    source_execution_status='No Cargo, context compilation, Source numerical run or Native execution by author. Root will apply only after independent full Source/privacy/member/readset review and final compiler parent join.',
    real_demand_extra_storage=old['real_existing_demand_allocator_extra_storage_qualification'],
    author_Source=ref(Path(__file__)),observer_author_Source=ref(D/'Source-warmup-observer-author-Audit-02.rs')))
print(json.dumps(dict(draft=draft,fixture=fixture,projection=projection)))

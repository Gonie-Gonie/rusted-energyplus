"""Private finite55 archive/template; Root alone publishes, edits docs, stages, and commits."""
from pathlib import Path
import argparse,hashlib,json,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'warmup-multiplier-Exterior-publication-draft-Peer-55-final-03'
def ref(p):
 p=p.resolve()
 with p.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),sha256=sha,bytes=p.stat().st_size)
def checked(v):
 p=Path(v['path']);p=p if p.is_absolute() else R/p;a=ref(p);assert a['sha256']==v['sha256'] and a['bytes']==v.get('bytes',v.get('size_bytes',a['bytes']));return p
def read(v):return json.loads(checked(v).read_bytes())
def save(p,value):
 assert not p.exists();p.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf8',newline='\n');return ref(p)
def main(a):
 actual_ref=ref(checked(dict(path=a.actual,sha256=a.sha256)));actual=read(actual_ref);assert actual['accepted'] and not actual['findings'] and (actual['compiler_inputs'],actual['Rust_sources'],actual['selected_count'],actual['existing'],actual['new'])==(4556,4542,53,35,18);assert actual['Exterior_ordered_checked_prefix_records']==137 and actual['Exterior_direct_new_milestone_records']==33 and actual['Exterior_admitted_records']==170;assert not actual['qualified_impact_bridge']['all_three_groups_same_Source_snapshot'] and not actual['qualified_impact_bridge']['all_three_groups_same_compiled_binary_claim'];assert actual['actual_accepted_selected_invocations']==5 and actual['actual_failed_prior_invocations']==12
 assert not O.exists();O.mkdir();prepared=read(actual['prepared']);seven=read(prepared['coherent_draft']);p3=read(prepared['carried03_prepared']);p2=read(p3['prior_prepared']);p0=read(p2['original_prepared']);original=read(p0['draft']);links=read(p0['semantic_link_table']);current={e['path']:e for e in read(actual['complete_compiler_plan'])['entries']};assert len(current)==4556
 newfixtures={read(p3['fixture_proofs'][group])['fixture']['path'] for group in ['warmup','multiplier_predictor','exterior']};rows={};excluded=[];historical={};historical_authorities={};resolved_historical=[]
 def add(v,purpose):
  path=Path(v['path']);path=path if path.is_absolute() else R/path;name=path.name.lower();text=path.as_posix()
  reason=None
  if path.suffix.lower() in ['.zip','.exe','.dll','.obj','.a','.map','.rlib','.rmeta']:reason='Binary/archive/object/map, outside finite Source evidence'
  elif 'source-objects' in text or 'archiveTree' in text:reason='Whole historical compiler object tree retained by authenticated ledger only'
  elif 'frozen-environment' in name:reason='Frozen environment values deliberately not duplicated'
  elif name.endswith(('.observation.json','.unit-output.json')) or name=='unit-output.json':reason='Whole raw Native output already losslessly retained in selected fixture'
  elif name.endswith('fixture.json') and v['path'] not in newfixtures:reason='Old protected P1/Surface/P4/history fixture already public53/54'
  if reason:excluded.append(dict(reference=v,reason=reason));return
  # Frozen leaf contexts may name a canonical Source version later replaced
  # by another accepted stage. Resolve only an exact retained literal-chain
  # version, without pretending that version remains live.
  if path.exists() and ref(path)['sha256']==v['sha256']:
   p=checked(v)
  else:
   relative=path.relative_to(R).as_posix() if path.is_relative_to(R) else None
   candidates=[w for (n,sha,size),w in historical.items() if n==relative and sha==v['sha256'] and size==v.get('bytes',size)]
   assert len(candidates)==1, 'Exact retained historical context '+v['path']
   p=checked(candidates[0]);authority=historical_authorities.get((relative,v['sha256'],v.get('bytes',ref(p)['bytes'])));resolved_historical.append(dict(requested_reference=v,exact_archived_whole=candidates[0],Source_snapshot_authority=authority,qualification='Same bytes/size; exact accepted literal-chain or explicit accepted Source snapshot historical path/row, never a live-current assertion.'))
  value=ref(p);assert p.is_file() and value['bytes']<32*1024*1024
  if p.suffix.lower()=='.json':
   x=json.loads(p.read_bytes());assert not isinstance(x,dict) or 'full_explicit_environment' not in x
  key=value['path'];arc=('selected-historical-context/'+value['sha256']+'/'+relative) if 'source-objects' in p.as_posix() else key if p.is_relative_to(R) else 'external-metadata/'+value['sha256']+'/'+p.name
  if key in rows:assert rows[key]['source']==value;rows[key]['purposes']=sorted(set(rows[key]['purposes']+[purpose]))
  else:rows[key]=dict(source=value,archive_path=arc,purposes=[purpose])
 def file(name,purpose):add(ref(D/name),purpose)
 def refs(value,purpose):
  # Traverse selected in-memory fields only; never open arbitrary referenced documents.
  if isinstance(value,dict):
   if 'path' in value and 'sha256' in value:add(value,purpose)
   else:
    for item in value.values():refs(item,purpose)
  elif isinstance(value,list):
   for item in value:refs(item,purpose)
 for v in [actual_ref,ref(Path(__file__)),actual['author_Source'],actual['prepared'],actual['application'],actual['complete_compiler_plan'],prepared['selected_Source_ledger']]:add(v,'Accepted qualified actual55 and final53/4556 custody')
 documents=[original,read(p2['correction']),read(p3['correction']),read(actual['diagnostic_draft']),read(actual['math_draft']),seven]+[read(stage['draft']) for stage in actual['correction_stages']]
 for doc in documents:
  for row in doc['files']:
   for key in ['before','proposed']:
    v=row.get(key)
    if v is not None:historical[(row['canonical_path'],v['sha256'],v['bytes'])]=v
 # A finite set of already accepted actual Source snapshots is the only
 # additional historical lookup authority. Do not scan runtime directories.
 snapshot_reviews=[
  ('Root-source-successful-log-layout-actual-review-49/review.json','58a4af24ebf043ce5bc6654818f5e161d08d7914ffb6d471998eaba4d73eac51','ordered_cases','actual_receipt'),
  ('Root-source-gap-batch-actual-review-53/review.json','bbac4d29c940910b1f30d9f75811a1ca916521b37b6bce0903e67d26f006a940','ordered_successful_groups','actual_receipt'),
  ('Root-Source-P4-history-actual-review-54/review.json','027391ad8d8b5f4bb2940390dfe774006f37c11623f38df161db9876ece34719','groups','actual_Source_receipt'),
 ]
 for name,sha,rows_key,receipt_key in snapshot_reviews:
  review_ref=ref(checked(dict(path=(D/name).as_posix(),sha256=sha)));review=read(review_ref)
  assert review['accepted'] and not review['findings']
  for result in review[rows_key]:
   receipt_ref=result[receipt_key];receipt=read(receipt_ref);assert receipt['exit_code']==0 and receipt['source_bytes_match_before_and_after']
   snapshot_ref=ref(checked(receipt['source_snapshot']));snapshot=read(snapshot_ref)
   entries=snapshot['files'];assert len(entries)==len({v['historical_path'] for v in entries})
   for entry in entries:
    n=entry['historical_path'];archive=entry['archive'];size=entry['size_bytes'];key=(n,archive['sha256'],size)
    candidate=dict(path=archive['path'],sha256=archive['sha256'],bytes=size)
    if key not in historical:
     historical[key]=candidate
     historical_authorities[key]=dict(accepted_actual_review=review_ref,actual_Source_receipt=receipt_ref,source_snapshot=snapshot_ref,exact_historical_path=n,exact_snapshot_file_row=entry)
 for doc in documents:
  refs(doc['files'],'All successive selected Source before/proposed/literal forward/inverse/parse evidence')
  for key in ['author_Source','prior_complete_compiler_Source_plan','complete_proposed_compiler_Source_plan','literal_shared_joins','actual_Constant_ctor_and_primary_supplement','actual_binary_imports','Root_same_operand_CRT_diagnosis','independent_leaf_pairs','Native_authorities','Native_authority','concrete_same_owner_contexts','concrete_current_contexts','concrete_contexts','whole_crate_API_census','actual_failed_55_10']:
   if key in doc:refs(doc[key],'Exact production/observer/primary/math/semantic join scope')
 for item in actual['selected_Source_files']:
  name=item['canonical_path'];value=ref(R/name);assert (value['sha256'],value['bytes'])==(current[name]['final_sha256'],current[name]['final_bytes'])==(item['final']['sha256'],item['final']['bytes']);add(value,'Current final53 selected canonical Source whole')
 for prep,label in [(prepared,'06 category orchestration'),(p3,'03 observer/path retries'),(p2,'02 initial contextual fixes'),(p0,'Original38 production/test join')]:
  for key in ['coherent_draft','draft','correction','joint_correction_peer','joint_independent_peer','prior_application','initial_application','prior_prepared','original_prepared','prior_compiler_plan','complete_compiler_plan','guard_Source','application_Source','launch_Source','actual_checker_Source','environment_guard','record_command_Source','helper_full_deltas','semantic_link_table','author_Source','correction_leaf_peers','semantic_peers','inherited_guard_dependencies']:
   if key in prep:refs(prep[key],label+' explicit helper/peer/plan references')
  if 'helper_full_deltas' in prep:refs(read(prep['helper_full_deltas'])['files'],label+' full helper forward/inverse deltas')
 for pair in links['leaf_semantic_pairs']:
  add(pair['peer'],'Exact independent original leaf semantic peer');drafts=pair['draft'] if isinstance(pair['draft'],list) else [pair['draft']]
  for dr in drafts:
   add(dr,'Original accepted Native/Source owner/constructor/readset leaf');leaf=read(dr)
   for key in ['author_Source','observer_author_Source','constructor_container_order_ledger','crate_API_caller_census','consumed_owner_input_observation_ledger','crate_caller_privacy_census','omitted_ctor_and_observed_member_ledger','owner_field_readset','field_readset','primary_ingress','schema_producer_bridge','primary_operand_ledger','same_owner_observations','same_owner_contexts','concrete_same_owner_contexts','source_contexts','Source_owner_contexts','concrete_current_contexts','concrete_contexts','caller_order_correction','literal_ingress_bridge','Native_authorities','Native_authority']:
    if key in leaf:refs(leaf[key],'Bounded genuine Native/member/constructor/caller/input lineage')
 refs(links.get('whole_Source_reviews'),'Actual production whole reviews without relabelled draft scope')
 refs(actual['math_independent_peer'],'Full UCRT safe-wrapper/Cargo/ABI independent peer');refs(actual['math_import_provenance'],'Actual Native/Source binary import provenance');refs(actual['same_operand_CRT_diagnosis'],'Actual same-operand CRT raw-bit diagnosis');progress=actual['Exterior_prior05_qualified_progress'];refs(progress['independent_progress_review'],'Independent code-derived prior137 inference, never direct milestones');progress_doc=read(progress['independent_progress_review'])
 for key in ['executed_Source_contexts','actual_receipt','actual_guard','Source_contexts','source_contexts','authenticated_Source_wholes','actual_Source_receipt','actual_stdout','actual_stderr','actual_fixture','actual_protected_fixtures','reviewed_draft','author_Source']:refs(progress_doc.get(key),'Prior137 exact ordered-call/unique-failure context')
 for result in actual['groups']:
  for key in ['actual_Source_receipt','external_fixture','fixture_projection','complete_compiler_plan','launch_Source']:add(result[key],'Actual historical passed warmup02/multiplier03 and exact whole fixture')
  refs(result['logs'],'Whole actual Source stdout/stderr');refs(result['fixture_before_after_guards'],'Actual before/after seven-fixture custody')
 add(actual['Exterior_external_fixture'],'Whole exact179 Native expected records with declared170 admission');add(actual['Exterior_fixture_projection'],'Lossless Native/input/Source-ingress/scope inverse')
 for result in actual['Exterior_remaining_categories']:
  add(result['actual_Source_receipt'],'Actual selected category successful direct milestone at its recorded stage');refs(result['logs'],'Complete selected category stdout/stderr');refs(result['fixture_before_after_guards'],'Actual4556/seven-fixture/category command guards');add(result['complete_compiler_plan'],'Actual category compiler plan');add(result['launch_Source'],'Actual selected category launcher, including independent Surface10')
 for group in ['warmup','multiplier_predictor','exterior']:
  proof=read(p3['fixture_proofs'][group]);native_ref=proof.get('actual_Native_group_run',proof.get('actual_Native_receipt'));assert native_ref;add(native_ref,'Actual original-core whole-function Native selected group');native=read(native_ref);assert native['accepted'] and not native['findings'] and native['exit_code']==0
  for key in ['actual_build','reviewed_manifest','new_driver_draft','new_driver_peer','independent_leaves','retry_independent_peers','Native_before','Native_after','actual_child_modules','stdout','stderr','author_Source']:refs(native.get(key),'Actual Native build/driver/peer/PID-three-DLL/custody/log evidence')
  ready=read(native['reviewed_manifest'])
  for key in ['caller_Sources','common_header','named_inputs','input_files','new_driver_draft','new_driver_peer','build_Source','run_Source','author_Source','helper_full_deltas','root_helper_Source_deltas']:refs(ready.get(key),'Selected exact original-core Native caller/input/recipe scopes')
  for key in ['exact_Native_named_inputs','actual_named_inputs','Source_primary_input','exact_Source_primary_input_projection','primary_only_Source_ingress_authority','Source_primary_transport','Native_raw_input_single_field_inverse','authentic_original_Source_ingress','original_Source_raw_transport','author_Source']:refs(proof.get(key),'Named primary input-only/complete lossless fixture authority')
 for rr in actual['preserved_failed_Source_attempts']:
  add(rr,'Preserved actual Source compile/setup/provider-math/schedule-boundary failure');run=read(rr);refs(run['stdout'],'Full historical failure stdout');refs(run['stderr'],'Full historical failure stderr')
 for stage in actual['correction_stages']:
  for key in ['application','independent_peer','draft','prior_compiler_plan','complete_compiler_plan','author_Source']:add(stage[key],'Exact later Source correction/application/peer/plan/Root runner')
  app=read(stage['application'])
  for key in ['before','after','protected_before','qualification','preserved_failed_beam']:refs(app.get(key),'Bounded actual application metadata')
 for stop in actual['metadata_only_preflight_stops']:add(stop['log'],'Preserved metadata-only preflight stop, not a scientific invocation')
 for name in ['Exterior-independent-category-launch-Peer-55-06-02/manifest.json','Exterior-path-spelling-helper-Peer-55-06-03/manifest.json','launch-Constant-Exterior-category-Root-55-06-02.py','launch-Constant-Exterior-category-Root-55-06-03.py','run-Setup-cold-weather-Root-55-10.py','run-Setup-cold-weather-Root-55-10-02.py']:
  file(name,'Original immutable helper and bounded metadata-only successor provenance')
 nf=ref(D/'original-core-gap-batch-run-Root-06-exterior/receipt.json');add(nf,'Preserved original Native first-calendar-phase failure');native=read(nf)
 for key in ['stdout','stderr','Exterior_progress','partial_checkpoint']:refs(native.get(key),'Preserved Native failed-attempt logs/passive progress')
 for name in ['genuine-solar-gain-producers-draft-Outer-11/draft.json','Peer-Exterior-calendar-review-Audit-11/review.json','Root-Weather-UCRT-application-55-05/receipt.json','Root-Weather-UCRT-application-55-05/actual.json','run-Weather-UCRT-Root-55-05.py']:
  file(name,'Exact calendar/UCRT application/failure/launch scope')
 for resolution in resolved_historical:
  authority=resolution['Source_snapshot_authority']
  if authority:
   add(authority['accepted_actual_review'],'Accepted prior Source snapshot authority for an exact finite stale-context resolution')
   add(authority['actual_Source_receipt'],'Actual successful command binding the exact snapshot ledger used for a selected historical context')
 bridge=save(O/'qualified-impact-bridge.json',actual['qualified_impact_bridge']);add(bridge,'Separate actual stages and precise unchanged-body/readset carries')
 total=sum(r['source']['bytes'] for r in rows.values());assert total<145*1024*1024
 whitelist=save(O/'finite-whitelist.json',dict(schema='src06-qualified-final55-finite-whitelist.v2',entries=sorted(rows.values(),key=lambda v:v['source']['path']),uncompressed_bytes=total,excluded_references=excluded,exact_historical_context_resolutions=resolved_historical,exclusions=['No recursive source-object/compiler archive trees, old ZIPs, provider/core/binary/object/map or full environment values','No duplicate whole Native output: original outputs are losslessly in three whole new fixtures','No duplicate old protected P1/Surface/P4/history fixtures already public53/54, including surface.fixture.json','No unexecuted cadence/final15/SUR03/SUR05/handoff evidence, same-binary or direct historical137 milestone claim'],author_Source=ref(Path(__file__))))
 archive=O/'evidence.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for row in sorted(rows.values(),key=lambda v:v['archive_path']):
   info=zipfile.ZipInfo(row['archive_path'],date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,checked(row['source']).read_bytes())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and set(z.namelist())=={r['archive_path'] for r in rows.values()}
  for row in rows.values():b=z.read(row['archive_path']);assert len(b)==row['source']['bytes'] and hashlib.sha256(b).hexdigest()==row['source']['sha256']
 suggestions=save(O/'curated-doc-suggestions.json',dict(policy='Root owns concise current UTF8 card facts/docs. No chronology dump or gate promotion.',facts=['Warmup:69 genuine persistent RecordKeeping/Check calls,45,072 strict state observations on actual55-02. Full Surface-manager cadence is a separate obligation.','Multiplier2:21 genuine getter-created persistent Predict/Correct/history calls,17,893 strict state/return observations on actual55-03. Production finite multiplier admission remains unchanged.','Exterior:170 admitted record checks completed across ordered checked prefix137 on failed55-05 plus direct successful internal_gains06(9),surface_internal_gains10(6),beam_producer11(18); all179 Native records retained,9 exploratory shading records excluded. No single successful full170 invocation or unsupported raw-bit denominator is claimed.'],snapshot_qualification='Historical warmup02/multiplier03 and Exterior prefix05 are carried by explicit exact-body/readset bridges. The three direct remaining categories execute on their actual06/10/11 snapshots. No all-group same snapshot/binary claim.',remaining='Final same-production fifteen-case output/ancillary closure and passive full Surface cadence comparison remain separate.',gates='A14/54 B14/64 unchanged.',evidence_link='evidence/SRC-06-canonical-warmup-multiplier-exterior-55/summary.json'))
 template=save(O/'template.json',dict(schema='src06-qualified55-publication-template.v3',status='READY_PRIVATE_ROOT_PUBLICATION_ONLY',public_directory='energyplus_porting_plan/evidence/SRC-06-canonical-warmup-multiplier-exterior-55',base_HEAD=actual['base_HEAD'],actual_review=actual_ref,complete_compiler_plan=actual['complete_compiler_plan'],finite_archive=ref(archive),finite_whitelist=whitelist,curated_doc_suggestions=suggestions,summary=dict(accepted=True,findings=[],compiler_inputs=4556,Rust_sources=4542,selected_Source_files=53,existing=35,new=18,total_admitted_record_units=260,record_unit_qualification=actual['record_unit_qualification'],known_strict_raw_fields_warmup_and_multiplier=62965,Exterior_admitted_records=170,Exterior_ordered_inferred_prefix_records=137,Exterior_direct_new_milestone_records=33,Exterior_Native_retained_records=179,Exterior_excluded_records=9,Exterior_raw_bit_denominator_unclaimed=True,actual_groups=actual['groups'],Exterior_prior05_qualified_progress=progress,Exterior_remaining_categories=actual['Exterior_remaining_categories'],qualified_impact_bridge=bridge,all_seven_external_fixtures_stable=True,all_three_same_Source_snapshot=False,all_three_same_compiled_binary_claim=False,actual_accepted_selected_invocations=5,preserved_Source_failures=actual['preserved_failed_Source_attempts'],preserved_Source_failure_count=12,metadata_only_preflight_stops=actual['metadata_only_preflight_stops'],correction_stages=actual['correction_stages'],preserved_Native_calendar_failure=nf,gate_changes=0,private_cache_state_observed=False),publication_contract='Root alone verifies final4556 current inputs, selected53 raw staged bytes and archive CRC/SHA/sizes, publishes finite evidence, updates compact docs, runs docsQA and commits/pushes. Only ignored private artifacts are prepared here; Root final staged-index/Git transport check is a separate actual proof.',author_Source=ref(Path(__file__))))
 manifest=save(O/'manifest.json',dict(schema='src06-qualified55-private-publication.v3',status='READY_PRIVATE_NO_PUBLICATION',template=template,archive=ref(archive),finite_whitelist=whitelist,finite_entries=len(rows),uncompressed_bytes=total,all_ZIP_CRC_SHA_size_verified=True,actual_review=actual_ref,curated_doc_suggestions=suggestions,canonical_Source_docs_Git_Cargo_or_Native_mutation=False,author_Source=ref(Path(__file__))))
 print(json.dumps(dict(manifest=manifest,template=template,archive=ref(archive),whitelist=whitelist,entries=len(rows),uncompressed_bytes=total)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--actual',required=True);p.add_argument('--sha256',required=True);main(p.parse_args())

"""Private exact coherent Source55 union. Never apply or execute scientific code."""
from pathlib import Path
import copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'source-Exterior-warmup-multiplier-coherent-Outer-55'
HEAD='0fd99a35c748b0f6969ce9eedc084f45fc59c0bb'
def ref(p):
 p=p.resolve();b=p.read_bytes();return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def checked(v):
 p=Path(v['path']);p=p if p.is_absolute() else R/p;a=ref(p);assert (a['sha256'],a['bytes'])==(v['sha256'],v['bytes']),(v,a);return p
def load(p):return json.loads(p.read_bytes())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode());return ref(p)
def rows(d):return next(v for v in d.values() if isinstance(v,list) and v and isinstance(v[0],dict) and 'proposed' in v[0])
def cp(r):return r.get('canonical_path',r.get('canonical_future_path'))
def apply(a,diff):
 if not diff:return a
 old=a.decode().splitlines(True);patch=diff.decode().splitlines(True);at=2;cursor=0;out=[]
 while at<len(patch):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch[at]);assert m
  first=int(m[1]);length=int(m[2] or '1');start=first-1 if length else first;assert start>=cursor
  out.extend(old[cursor:start]);cursor=start;at+=1;removed=added=0
  while at<len(patch) and not patch[at].startswith('@@ '):
   line=patch[at];at+=1;assert line[0] in ' +-';payload=line[1:]
   if line[0] in ' -':assert old[cursor]==payload,(cursor,old[cursor],payload);cursor+=1;removed+=1
   if line[0] in ' +':out.append(payload);added+=1
  assert removed==length and added==int(m[4] or '1')
 out.extend(old[cursor:]);return ''.join(out).encode()
def patch_bytes(a,b,path):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile=path,tofile=path)).encode()
def main():
 assert not O.exists()
 head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip();assert head==HEAD
 assert not subprocess.run(['git','status','--porcelain'],capture_output=True,text=True,check=True).stdout
 parent_path=D/'source-Propane-P4-history-coherent-draft-Peer-01/complete-proposed-compiler-Source-plan.json'
 assert ref(parent_path)['sha256']=='2afc056257d345a5a0c93f380312faef089c46e48d4bd65cc66ec72926da154f'
 parent=load(parent_path);assert (parent['compiler_inputs'],parent['Rust_sources'])==(4538,4525)
 actual_path=D/'Root-Source-P4-history-actual-review-54/review.json';assert ref(actual_path)['sha256']=='027391ad8d8b5f4bb2940390dfe774006f37c11623f38df161db9876ece34719'
 actual=load(actual_path);assert actual['accepted'] and not actual['findings']
 snapshot_ref=actual['groups'][0]['recorded_source_snapshot'];snapshot=load(checked(snapshot_ref))
 archived={r['historical_path']:r for r in snapshot['files']};pm={r['path']:r for r in parent['entries']};assert set(archived)==set(pm) and len(pm)==4538
 readback=[]
 for name,row in sorted(pm.items()):
  b=(R/name).read_bytes();h=hashlib.sha256(b).hexdigest();assert (h,len(b))==(row['final_sha256'],row['final_bytes'])
  assert checked(row['source']).read_bytes()==b
  ar=archived[name];p=R/ar['archive']['path'];assert p.read_bytes()==b and hashlib.sha256(b).hexdigest()==ar['archive']['sha256'] and len(b)==ar['size_bytes']
  readback.append({'path':name,'sha256':h,'bytes':len(b),'parent_archive_live_whole_exact':True})
 rust_now=set(subprocess.run(['rg','--files','crates','-g','*.rs'],capture_output=True,text=True,check=True).stdout.replace('\\','/').splitlines())
 assert rust_now=={p for p in pm if p.endswith('.rs')}
 slugs=['source-weather-owner-cohort-draft-Outer-02','source-cold-exterior-convection-draft-Outer-01','source-cold-exterior-cohort-draft-Outer-02',
 'source-absorption-cohort-draft-Outer-02','source-sky-opaque-cohort-draft-Outer-03','source-exterior-closed-draft-Outer-02',
 'source-site-atmosphere-cold-owner-draft-Outer-02','source-general-shadow-shared-Figure-draft-Outer-03','source-IHG-beam-owner-observer-draft-Outer-08',
 'source-Exterior-group-draft-Outer-02','source-real-class-allocation-draft-Peer-01','source-warmup-complete-draft-Audit-02','source-multiplier-predictor-draft-Peer-02']
 drafts={};history={};chosen={}
 for slug in slugs:
  path=D/slug/'draft.json';d=load(path);drafts[slug]=(path,d)
  for row in rows(d):
   path=cp(row)
   if slug=='source-exterior-closed-draft-Outer-02' and 'weather_day/' in path:continue
   b=checked(row['proposed']).read_bytes();history.setdefault(path,[]).append({'leaf':ref(D/slug/'draft.json'),'proposed':row['proposed']});chosen[path]=b
 assert len(chosen)==38
 joins=[]
 # Both reviewed production modules are needed. Removing the other module
 # declaration restores either complete accepted solar hub byte-for-byte.
 solar='crates/ep_runtime/src/heat_balance/radiation/ordinary/solar_timestep.rs'
 opaque=checked(next(r for r in rows(drafts['source-exterior-closed-draft-Outer-02'][1]) if cp(r)==solar)['proposed']).read_bytes()
 shadow=chosen[solar];assert opaque.replace(b'mod opaque_exterior;\n',b'',1)==shadow.replace(b'mod general_shadow;\n',b'',1)==(R/solar).read_bytes()
 assert shadow.count(b'mod distribution;\n')==1
 chosen[solar]=shadow.replace(b'mod distribution;\n',b'mod distribution;\nmod opaque_exterior;\n',1)
 assert chosen[solar].replace(b'mod opaque_exterior;\n',b'',1)==shadow
 assert chosen[solar].replace(b'mod general_shadow;\n',b'',1)==opaque
 joins.append({'canonical_path':solar,'kind':'two independent module declarations only','inverse_to_each_entire_accepted_leaf':True})
 # Multiplier already includes the full reviewed warmup dispatch. Compose only
 # the reviewed Exterior module and dispatch on that exact current proposal.
 hub='crates/ep_runtime/src/heat_balance/gap_batch_cohort.rs';old_hub=chosen[hub]
 assert old_hub.count(b'mod surface;')==1
 pending=b'"exterior"=>Err(invalid("Source Exterior adapter literal join pending").into()),';assert old_hub.count(pending)==1
 chosen[hub]=old_hub.replace(b'mod surface;',b'mod surface;\nmod exterior;',1).replace(pending,b'"exterior"=>exterior::run(&fixture),',1)
 assert chosen[hub].replace(b'mod surface;\nmod exterior;',b'mod surface;',1).replace(b'"exterior"=>exterior::run(&fixture),',pending,1)==old_hub
 group_hub=checked(next(r for r in rows(drafts['source-Exterior-group-draft-Outer-02'][1]) if cp(r)==hub)['proposed']).read_bytes()
 assert chosen[hub].replace(b'|"warmup"|"multiplier_predictor"',b'',1).replace(b'        "warmup"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_warmup_cohort(&fixture),\n',b'',1).replace(b'        "multiplier_predictor"=>super::ordinary_equipment::OrdinaryEquipment::run_native_gap_multiplier_predictor_cohort(&fixture),\n',b'',1)==group_hub
 joins.append({'canonical_path':hub,'kind':'accepted multiplier+warmup hub plus exact Exterior module/dispatch','whole_inverse_to_multiplier':True,'whole_inverse_to_Exterior_group':True})
 # Successive accepted cfg supersets and the reviewed clock/call split are
 # preserved wholesale, rather than rebuilding any observer/math body.
 for name,items in history.items():
  if len(items)>1 and name not in (solar,hub):joins.append({'canonical_path':name,'kind':'whole latest accepted successive leaf or reviewed cfg clock/call split','prior_leaves':items,'final_whole':items[-1]['proposed']})
 existing=sum(p in pm for p in chosen);new=len(chosen)-existing;assert (existing,new)==(22,16)
 peers=[]
 for path in ['Root-Weather-Exterior-scope-independent-review-03/review.json','Root-cold-InitExt-independent-review-01/review.json',
 'Root-cold-absorption-independent-review-02/review.json','Root-sky-opaque-independent-review-03/review.json',
 'Peer-site-shadow-production-review-Audit-01/site-review.json','Peer-site-shadow-production-review-Audit-01/shadow-review.json',
 'Peer-Exterior-owner-observer-review-Audit-08/review.json','Root-Exterior-factory-observer-semantic-review-08/review.json','Root-Exterior-primary-ingress-independent-review-02/review.json',
 'Root-real-class-allocation-independent-review-01/review.json','Peer-Source-warmup-complete-review-Outer-02/review.json',
 'Root-multiplier-Exterior-group-independent-review-02/multiplier-review.json','Root-multiplier-Exterior-group-independent-review-02/Exterior-group-review.json']:
  p=D/path;q=load(p);assert q['accepted'] and q['findings']==[];peers.append(ref(p))
 old_four=[]
 prep=load(checked(actual['prepared']))
 for name in ['P4_fixture_proof','history_fixture_proof']:
  proof=load(checked(prep[name]));old_four.append({'proof':prep[name],'fixture':proof.get('fixture',proof.get('runtime_fixture'))})
 # The two earlier fixtures are protected by the inherited actual54 guard.
 guard=load(checked(actual['groups'][0]['fixture_before_after_guards'][0]));external=[]
 def find_fixture_refs(v):
  if isinstance(v,dict):
   if {'path','sha256','bytes'}<=v.keys() and v['path'].endswith('/fixture.json'):external.append(v)
   else:
    for x in v.values():find_fixture_refs(x)
  elif isinstance(v,list):
   for x in v:find_fixture_refs(x)
 external.extend(guard['all_four_fixtures'].values())
 warm=drafts['source-warmup-complete-draft-Audit-02'][1];mult=drafts['source-multiplier-predictor-draft-Peer-02'][1];exproof=load(D/'source-Exterior-runtime-fixture-Outer-01/proof.json')
 external += [warm['runtime_fixture'],mult['fixture'],exproof['fixture']]
 unique={r['path']:r for r in external}
 assert len(unique)==7,(len(unique),list(unique))
 for row in unique.values():checked(row)
 # Validate all bytes in memory before creating any frozen output.
 prepared=[]
 for name,b in sorted(chosen.items()):
  before=(R/name).read_bytes() if name in pm else b''
  if name in pm:
   git=subprocess.run(['git','show',HEAD+':'+name],capture_output=True,check=True).stdout;assert git==before,(name,'selected Git/live mismatch')
  else:assert not (R/name).exists()
  f=patch_bytes(before,b,name);i=patch_bytes(b,before,name);assert apply(before,f)==b and apply(b,i)==before
  run=subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert run.returncode==0,(name,run.stderr)
  prepared.append((name,before,b,f,i,run.stdout,run.stderr))
 O.mkdir();files=[]
 for name,a,b,f,i,out,err in prepared:
  paths=[]
  for folder,suffix,data in [('before','',a),('proposed','',b),('diffs','.forward.diff',f),('diffs','.inverse.diff',i),('parse','.stdout.rs',out),('parse','.stderr.txt',err)]:
   p=O/folder/(name+suffix);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);paths.append(ref(p))
  files.append({'canonical_path':name,'before_absent':name not in pm,'before':paths[0],'proposed':paths[1],'forward_diff':paths[2],'inverse_diff':paths[3],
   'Source_only_parse':{'exit_code':0,'stdout':paths[4],'stderr':paths[5],'syntax_only':True},'accepted_leaf_lineage':history[name],
   'join':next((j for j in joins if j['canonical_path']==name),None)})
 final=copy.deepcopy(pm)
 for row in files:
  p=row['proposed'];final[row['canonical_path']]={'path':row['canonical_path'],'final_sha256':p['sha256'],'final_bytes':p['bytes'],'source':p,'origin':'coherent55 exact peer-reviewed leaf/explicit literal join'}
 assert len(final)==4554 and sum(p.endswith('.rs') for p in final)==4541
 plan={'schema':'src06-complete-coherent-Source55-compiler-plan.v1','base_HEAD':HEAD,'prior_complete_compiler_Source_plan':ref(parent_path),
  'actual54_parent_review':ref(actual_path),'actual54_recorded_Source_snapshot':snapshot_ref,'compiler_inputs':4554,'inputs':4554,'Rust_sources':4541,
  'selected':38,'existing':22,'new':16,'unchanged_parent_rows':4516,'entries':[final[p] for p in sorted(final)],
  'scope':'Fresh current55 metadata. Only entries are carried from actual54; no previous stage claims copied. Source byte plan only, no compilation or equivalence claim.'}
 planref=save(O/'complete-proposed-compiler-Source-plan.json',plan)
 readref=save(O/'actual54-full4538-parent-readback.json',{'schema':'src06-actual54-whole-parent-readback.v1','base_HEAD':HEAD,'parent_plan':ref(parent_path),'actual_review':ref(actual_path),'recorded_snapshot':snapshot_ref,'compiler_inputs':4538,'Rust_sources':4525,'entries':readback})
 needles=['native_gap_external_convection_cases','native_gap_absorption_cases','native_gap_sky_opaque_cases','run_native_gap_solar_clock','source_figure_solar_beam_at_timestep','allocate_native_warmup_cohort_arrays','run_native_gap_warmup_cohort','run_native_gap_multiplier_predictor_cohort','prepare_gain_clock','invoke_actual_gains','prepare_actual_surface_gains','prepare_actual_beam']
 census=[]
 for name,row in sorted(final.items()):
  if not name.endswith('.rs'):continue
  text=checked(row['source']).read_text(encoding='utf-8')
  hits=[{'line':n,'text':line} for n,line in enumerate(text.splitlines(),1) if any(token in line for token in needles)]
  if hits:census.append({'canonical_path':name,'whole_Source':row['source'],'hits':hits})
 censusref=save(O/'whole4541-Rust-API-census.json',{'schema':'src06-full-final-Rust-spelling-caller-census.v1','Rust_sources':4541,'needles':needles,'paths':census,'qualification':'Full final Rust scan of concrete added/changed shared calls. Static spelling/caller proof, not a Rust typecheck.'})
 result={'schema':'src06-coherent-Exterior-warmup-multiplier-Source55.v1','status':'HELD_PEER_COVERED_ROOT_COMPOSITION_REVIEW_AND_CONTEXTUAL_EXECUTION_PENDING','base_HEAD':HEAD,'files':files,
  'compiler_inputs':4554,'Rust_sources':4541,'selected':38,'existing':22,'new':16,'literal_applications':76,'fresh_Source_only_syntax_parses':38,
  'accepted54_actual_review':ref(actual_path),'actual_parent_snapshot':snapshot_ref,'prior_complete_compiler_Source_plan':ref(parent_path),'complete_proposed_compiler_Source_plan':planref,
  'full4538_parent_readback':readref,'whole4541_Rust_API_census':censusref,'accepted_leaf_drafts':[ref(p) for p,d in drafts.values()],
  'independent_leaf_peers':peers,'literal_shared_joins':joins,'external_fixture_before_after_protection':list(unique.values()),
  'new_group_fixtures':[{'group':'warmup','fixture':warm['runtime_fixture'],'projection':warm['runtime_fixture_projection'],'full_calls':69,'Source_expected_state_binary64_fields':45072},
   {'group':'multiplier_predictor','fixture':mult['fixture'],'projection':mult['fixture_projection'],'qualification':'Native full43 state observations plus5 real return comparisons; counts from exact accepted Root peer and fixture projection.'},
   {'group':'exterior','fixture':exproof['fixture'],'projection':ref(D/'source-Exterior-runtime-fixture-Outer-01/proof.json'),'admitted_call_records':170,'full_Native_records_retained':179,'outside_CON01_shading_records':9}],
  'authorship':'Outer authored Exterior/factory/observer and literal composition. Root/Res independent accepted leaf semantics are carried with their exact scopes; Outer warmup review is independent of Res source. This union is author-verified composition, not labelled an independent full join review.',
  'validation_scope':['One Root canonical application then exactly three selected existing process-main scientific invocations: warmup, multiplier_predictor, exterior. No old P1/Surface/P4/history/2336/471/59/P2 rerun.','Seven external runtime fixtures preserved whole; no generated Rust expected constant or production loading.','All production formulas and accepted leaf Source wholes remain exact, apart from explicitly invertible module/dispatch joins. Real class allocator changes are genuine reviewed production changes; no fake allocations/readiness/default answers.','Exterior170 is admitted call-record coverage, not every Native owner bit nor179/three-beam equivalence. Paired18absorption/15solar records are36/30method calls; Weather101phase checks are47records.','Actual final contextual compilation, numerical results and current finite contracts/card status remain Root-owned/pending. No gates/policies/production finite admission changed.'],
  'private_author_precheck':{'preserved_Source':ref(D/'assemble-Source-Exterior-warmup-multiplier-Outer-55-first-precheck.py'),'finding':'A first author-only precheck selected /fixture.json names and missed the genuine surface.fixture.json, stopping before output creation. The final assembler uses actual54 guard.all_four_fixtures directly; no Source or scientific bytes changed.'},
  'canonical_Cargo_Native_execution':False,'author_Source':ref(Path(__file__))}
 print(json.dumps({'manifest':save(O/'manifest.json',result),'plan':planref,'selected':38,'compiler_inputs':4554,'Rust_sources':4541}))
if __name__=='__main__':main()

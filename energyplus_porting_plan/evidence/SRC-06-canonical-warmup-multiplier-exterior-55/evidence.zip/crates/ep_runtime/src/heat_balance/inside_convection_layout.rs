//! Validated source-order zone/space/opaque-surface associations.

use ep_model::{SpaceId, SurfaceId, SurfaceType, TypedModel, ZoneId};
use std::collections::BTreeSet;

/// One actual contiguous heat-transfer traversal group, including empty spaces.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InsideConvectionGroup {
    /// Owning zone, in the real zone array order.
    pub zone_id: ZoneId,
    /// Actual Zone.spaceIndexes member.
    pub space_id: SpaceId,
    /// Heat-transfer surface IDs in that space's actual traversal order.
    pub surfaces: Vec<SurfaceId>,
}

/// An actual surface's independent retained association owners.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct InsideConvectionAssociation {
    /// Actual surface ID.
    pub surface_id: SurfaceId,
    /// Actual surface Zone owner.
    pub zone_id: ZoneId,
    /// Actual surface spaceNum owner.
    pub space_id: SpaceId,
}

/// Duplicate, missing, stale or inconsistent actual owner associations.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct InsideConvectionAssociationUnavailable;

/// Validated IDs and order, shared by CTF history and inside convection.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InsideConvectionLayout {
    zones: Vec<ZoneId>,
    spaces: Vec<(SpaceId, ZoneId)>,
    surfaces: Vec<InsideConvectionAssociation>,
    groups: Vec<InsideConvectionGroup>,
}

impl InsideConvectionLayout {
    /// Validate explicit actual array order and Zone.spaceIndexes traversal.
    /// A harness supplies identities and associations, never calculated outputs.
    pub fn new(
        zones: Vec<ZoneId>,
        spaces: Vec<(SpaceId, ZoneId)>,
        surfaces: Vec<InsideConvectionAssociation>,
        groups: Vec<InsideConvectionGroup>,
    ) -> Result<Self, InsideConvectionAssociationUnavailable> {
        let zone_set = zones.iter().copied().collect::<BTreeSet<_>>();
        let space_set = spaces.iter().map(|r| r.0).collect::<BTreeSet<_>>();
        let surface_set = surfaces
            .iter()
            .map(|r| r.surface_id)
            .collect::<BTreeSet<_>>();
        if zone_set.len() != zones.len()
            || space_set.len() != spaces.len()
            || surface_set.len() != surfaces.len()
            || spaces.iter().any(|r| !zone_set.contains(&r.1))
        {
            return Err(InsideConvectionAssociationUnavailable);
        }
        let mut visited_spaces = BTreeSet::new();
        let mut visited_surfaces = BTreeSet::new();
        let mut previous_zone_index = 0;
        for group in &groups {
            let zi = zones
                .iter()
                .position(|id| *id == group.zone_id)
                .ok_or(InsideConvectionAssociationUnavailable)?;
            if zi < previous_zone_index
                || !spaces.contains(&(group.space_id, group.zone_id))
                || !visited_spaces.insert(group.space_id)
            {
                return Err(InsideConvectionAssociationUnavailable);
            }
            previous_zone_index = zi;
            for &id in &group.surfaces {
                if !visited_surfaces.insert(id)
                    || !surfaces.contains(&InsideConvectionAssociation {
                        surface_id: id,
                        zone_id: group.zone_id,
                        space_id: group.space_id,
                    })
                {
                    return Err(InsideConvectionAssociationUnavailable);
                }
            }
        }
        if visited_spaces != space_set || visited_surfaces != surface_set {
            return Err(InsideConvectionAssociationUnavailable);
        }
        Ok(Self {
            zones,
            spaces,
            surfaces,
            groups,
        })
    }

    /// Use the actual typed Zone.spaces order and Native opaque base-class order.
    pub fn from_typed_model(
        model: &TypedModel,
    ) -> Result<Self, InsideConvectionAssociationUnavailable> {
        let mut groups = Vec::new();
        for zone in &model.zones {
            for &space_id in &zone.spaces {
                let mut ids = Vec::new();
                for class in [SurfaceType::Wall, SurfaceType::Floor, SurfaceType::Roof] {
                    for surface in &model.surfaces {
                        if surface.space == space_id
                            && (surface.surface_type == class
                                || (class == SurfaceType::Roof
                                    && surface.surface_type == SurfaceType::Ceiling))
                        {
                            ids.push(surface.id);
                        }
                    }
                }
                groups.push(InsideConvectionGroup {
                    zone_id: zone.id,
                    space_id,
                    surfaces: ids,
                });
            }
        }
        Self::new(
            model.zones.iter().map(|r| r.id).collect(),
            model.spaces.iter().map(|r| (r.id, r.zone)).collect(),
            model
                .surfaces
                .iter()
                .map(|r| InsideConvectionAssociation {
                    surface_id: r.id,
                    zone_id: r.zone,
                    space_id: r.space,
                })
                .collect(),
            groups,
        )
    }

    /// Actual zone array IDs, including zones with no spaces.
    #[must_use]
    pub fn zones(&self) -> &[ZoneId] {
        &self.zones
    }
    /// Actual space array IDs and owning zones.
    #[must_use]
    pub fn spaces(&self) -> &[(SpaceId, ZoneId)] {
        &self.spaces
    }
    /// Actual surface array IDs and associations.
    #[must_use]
    pub fn surfaces(&self) -> &[InsideConvectionAssociation] {
        &self.surfaces
    }
    /// Real Zone.spaceIndexes followed by the heat-transfer traversal.
    #[must_use]
    pub fn groups(&self) -> &[InsideConvectionGroup] {
        &self.groups
    }
}

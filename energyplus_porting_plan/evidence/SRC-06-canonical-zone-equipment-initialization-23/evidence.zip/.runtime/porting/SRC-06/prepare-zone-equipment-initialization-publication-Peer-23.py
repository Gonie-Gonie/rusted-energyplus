"""Prepare minimal held publication23 only; no publisher/main/Cargo execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'zone-equipment-initialization-publication-prepared-Peer-23'
OLD = D / 'publish-component-availability-checkpoint-Peer-22.py'
NEW = D / 'publish-zone-equipment-initialization-checkpoint-Peer-23.py'

def ref(p):
    b = p.read_bytes(); return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def checked(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', row.get('size_bytes', got['bytes'])), row
    return p
def write(p, obj): p.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())

assert not O.exists() and not NEW.exists()
parent_ref = ref(OLD)
assert parent_ref['sha256'] == '2f384571fef963e31e0989c5cf001dd3cd1b6e7a6c49b1f929b7113b9ba6eaac'
producer_ref = ref(D / 'source-zone-equipment-initialization-held-Peer-23-02/manifest.json')
assert producer_ref['sha256'] == '2885f377e5978641e8343f455776a45598a5f28b0950f93a28b94066071ef9e3'
producer = json.loads(checked(producer_ref).read_bytes())
application_ref = ref(D / 'Root-zone-equipment-initialization-application-23/receipt.json')
assert application_ref['sha256'] == '9bf8fbc727f758e5e96fcb0a23fdebdb4407492162e16fe77e94cf9cc908e785'
application = json.loads(checked(application_ref).read_bytes())
assert application['accepted'] and not application['findings']
assert application['producer'] == producer_ref
application_source_ref = ref(checked(application['author_Source']))
assert application_source_ref['sha256'] == 'f837c6549bceb592c0007e911a3e19bb5d74357a03ea92e01585bba499130adc'
peer_ref = ref(D / 'Audit-zone-equipment-initialization-Source-review-23-02/review.json')
assert peer_ref['sha256'] == 'f43bc345d8667188f9e7cae29c7405267460e0d9129165defbdf88499f6b5a32'
peer = json.loads(checked(peer_ref).read_bytes())
assert peer['accepted'] and not peer['findings']
old = OLD.read_bytes().decode()
text = old
replacements = [
    ('checkpoint22', 'checkpoint23'),
    ('component-availability-publication-prepared-Peer-22', 'zone-equipment-initialization-publication-prepared-Peer-23'),
    ('SRC-06-canonical-component-availability-22', 'SRC-06-canonical-zone-equipment-initialization-23'),
    ('component-availability-publication-readback-Peer-22', 'zone-equipment-initialization-publication-readback-Peer-23'),
    ('50bcffc134ee4c60bedb77ce2ea8ba3cc83737f3', 'c5a6242d20a2c55e33948b5a11fb6ebae39dbe20'),
    ("len(producer['files']) == 1 and producer['existing_Source_files'] == 1 and producer['new_Source_files'] == 0", "len(producer['files']) == 5 and producer['existing_Source_files'] == 4 and producer['new_Source_files'] == 1"),
    ('4490', '4491'), ('4477', '4478'),
    ('Root-source-component-availability-actual-review-22', 'Root-source-zone-equipment-initialization-actual-review-23'),
    ('selected1_final_sources_exact', 'selected5_final_sources_exact'),
    ('canonical-source-component-availability-B-NOLIMIT-24H-Root-22', 'canonical-source-zone-equipment-initialization-B-NOLIMIT-24H-Root-23'),
    ('canonical-source-component-availability-A-24H-Root-22', 'canonical-source-zone-equipment-initialization-A-24H-Root-23'),
    ('canonical22-finite', 'canonical23-finite'),
    ('1 coherent component availability Source', '5 coherent zone equipment initialization Sources'),
    ('src06-canonical-component-availability.v1', 'src06-canonical-zone-equipment-initialization.v1'),
    ('Genuine Source component availability lifecycle', 'Genuine Source zone equipment initialization'),
    ('positive component-availability Native state equivalence', 'positive zone equipment initialization Native state equivalence'),
    ('canonical_component_availability_22', 'canonical_zone_equipment_initialization_23'),
    ('accepted21', 'accepted22'), ('equal21', 'equal22'),
    ('[Source 설비 가용성 경로 검증]', '[Source 구역 설비 초기화 검증]'),
]

for before, after in replacements:
    assert before in text, before
    text = text.replace(before, after)
assert 'equal21' not in text and 'accepted21' not in text
assert 'Root-source-component-availability-actual-review-22' not in text
assert 'canonical_component_availability_22' not in text
ast.parse(text)
assert '\ufffd' not in text
NEW.write_bytes(text.encode())

inputs = {}
def add(row):
    p = checked(row); got = ref(p)
    assert p.suffix.lower() != '.zip'
    assert not any(token in got['path'] for token in ['controlled-air-native', 'source-controlled-zone-numerical-draft', 'source-CalcMoreNodeInfo-draft'])
    assert got['path'] not in inputs or inputs[got['path']] == got
    inputs[got['path']] = got

add(producer_ref)
for key in ['complete_final_compiler_Source_plan', 'whole_crates_API_inventory', 'integration_contract', 'Native_literal_extents', 'EPVector_correction_proof', 'author_Source', 'sealer_Source']:
    add(producer[key])
for row in producer['Native_wholes']: add(row)
for row in producer['unchanged_contexts']: add(row['whole'])
for row in producer['files']:
    for key in ['before', 'proposed', 'literal_inverse', 'forward_diff', 'inverse_diff']: add(row[key])
    for key in ['stdout', 'stderr']: add(row['Source_only_parse'][key])
previous = ref(R / 'energyplus_porting_plan/evidence/SRC-06-canonical-component-availability-22/summary.json')
add(previous); add(peer_ref); add(ref(Path(__file__)))
add(application_ref); add(application_source_ref)
correction = json.loads(checked(producer['EPVector_correction_proof']).read_bytes())
add(producer['rejected_predecessor'])
for row in correction['changed_Source_wholes']:
    add(row['forward_diff']); add(row['inverse_diff'])
docs = {
    'CHECKLIST.md': '구역 설비 초기화 경로를 연결했다. 실제 B·A24 실행과 남은 경계는 요약 자료에 기록한다.',
    'STATE_CONTRACTS.md': '최초·환경·시간 단계 초기화는 기존 수요·크기 산정·설비 구성·물리 Node 상태를 공유한다. EPVector 할당의 실제 영 초기화와 할당 여부를 보존한다.',
    'cards/SRC-06.md': '실제 B의 미완료 경계는 `{{actual_B_frontier}}`이다. 내부 Native 상태 일치와 B 전체 완료를 주장하지 않는다.',
}

assert len(set(docs.values())) == 3
for value in docs.values():
    assert '?' not in value and '\ufffd' not in value
    assert value.encode('utf-8').decode('utf-8') == value
template = {
    'schema': 'src06-held-canonical23-publication-template.v1',
    'status': 'HELD_FOR_ROOT_REVIEW_ACTUAL_AND_PEER_HASHES_REQUIRED',
    'base_HEAD': producer['base_HEAD'], 'producer': producer_ref, 'complete_plan': producer['complete_final_compiler_Source_plan'],
    'previous_checkpoint': previous, 'publisher_Source': ref(NEW), 'publisher_parent_Source': parent_ref,
    'expected_actual_review_path': '.runtime/porting/SRC-06/Root-source-zone-equipment-initialization-actual-review-23/review.json',
    'Root_application': application_ref, 'Root_application_Source': application_source_ref,
    'accepted_independent_peer': peer_ref,
    'pending_Root_custody': {'actual_review_sha256': 'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source': 'REQUIRED_FROM_ACCEPTED_actual.author_Source',
        'launcher_Source': '.runtime/porting/SRC-06/launch-zone-equipment-initialization-Root-23.py (authenticated from accepted actual.launcher_Source at publish)',
        'B_CLI': '.runtime/porting/SRC-06/canonical-source-zone-equipment-initialization-B-NOLIMIT-24H-command-Root-23/receipt.json',
        'A24_CLI': '.runtime/porting/SRC-06/canonical-source-zone-equipment-initialization-A-24H-command-Root-23/receipt.json'},
    'Root_custody_at_publish': 'Accepted actual.application -> pinned application23 receipt and its corrected02 author_Source; actual.author_Source -> checker; actual.launcher_Source -> launcher. All four directly byte-checked and archived, following accepted22 algorithm. Pinned corrected application23 and its author script are already finite archive inputs; no prior Root implementation substituted.',
    'summary_template': {'A': '14/54', 'B': '14/64', 'changed_Rust_sources': 5, 'existing_Rust_sources': 4, 'new_Rust_sources': 1,
        'new_test_functions': 0, 'actual_test_bodies_executed': 0,
        'focused_validation_policy': 'Two actual CLI runs B then A24. No unrelated test-profile rerun or habitual alltargets check.',
        'scope': 'Genuine complete finite controlled InitZoneEquipment one-time, environment and timestep paths with actual sequencing demand/sizing allocation and same physical Node writes. Corrected EPVector allocation is zero-filled, including allocated-empty; same existing reset/report f64 writes and configuration aliases/order retained. Source23-01 was rejected before application for incorrect generic-array inference; authoritative corrected23-02 is the sole selected inventory.',
        'full_B_or_finite15_completion_claim': False, 'Native_harness_runtime_or_unit_equivalence_claim': False, 'gate_changes': False, 'policy_changes': False},
    'doc_appends': docs, 'finite_archive_inputs': [row for _, row in sorted(inputs.items())],
    'finite_archive_input_count': len(inputs), 'finite_archive_input_bytes': sum(row['bytes'] for row in inputs.values()),
    'publisher_executed': False, 'canonical_docs_mutations': False, 'Cargo_tests_Native_executed': False, 'gate_changes': False,
}
O.mkdir(); template_path = O / 'publication-template.json'; write(template_path, template)
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal>', 'exec'), ns)
diffs = {}
for kind, a, b in [('forward', old.encode(), text.encode()), ('inverse', text.encode(), old.encode())]:
    delta = ''.join(difflib.unified_diff(a.decode().splitlines(keepends=True), b.decode().splitlines(keepends=True), fromfile=OLD.name, tofile=NEW.name)).encode()
    assert ns['apply_literal'](a, delta) == b
    p = O / (kind + '.diff'); p.write_bytes(delta); diffs[kind] = ref(p)
bridge_path = O / 'publisher-parent-bridge.json'
write(bridge_path, {'parent': parent_ref, 'successor': ref(NEW), 'literal_applications': 2, 'changes': diffs,
    'scope': 'Checkpoint/path/five-source4491/proof22 labels, base commit and UTF8 link-title metadata only. Complete accepted22 archive/docs/SRC06-key algorithm unchanged.',
    'UTF8_Korean_appends_validated': True, 'publisher_executed': False, 'public_or_main_mutations': False})
print(json.dumps({'template': ref(template_path), 'publisher': ref(NEW), 'parent_bridge': ref(bridge_path)}))

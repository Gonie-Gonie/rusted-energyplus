"""Unsealed whole InitZoneEquipment successor; no main/Cargo/test execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'source-zone-equipment-initialization-draft-Peer-23-02'

def ref(p):
    b = p.read_bytes(); return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def check(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', got['bytes']), row
    return p
def put(name, b):
    p = O / name; assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b); return ref(p)
def doc(name, obj): return put(name, (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())
def swap(s, old, new):
    assert s.count(old) == 1, old[:120]
    return s.replace(old, new)

parent_ref = ref(D / 'source-component-availability-held-Peer-22/manifest.json')
assert parent_ref['sha256'] == '529c9857848d73f4177ac3d38571962bb78375029fc99044607470a7bf49af2a'
parent = json.loads(check(parent_ref).read_bytes())
plan = json.loads(check(parent['complete_final_compiler_Source_plan']).read_bytes())
entries = {row['path']: row for row in plan['entries']}
paths = [P + x for x in ['ordinary_equipment.rs', 'ordinary_equipment/management.rs', 'ordinary_equipment/source_equipment_initialization.rs',
    'ordinary_air_heat_balance/predictor_corrector/demand.rs', 'ordinary_air_heat_balance/predictor_corrector/lifecycle/demand.rs']]
before = {p: check(entries[p]['source']).read_bytes() if p in entries else b'' for p in paths}
assert sum(p not in entries for p in paths) == 1
assert all(b == (R / p).read_bytes() for p, b in before.items() if p in entries)
texts = {p: b.decode() for p, b in before.items()}
texts[paths[0]] = swap(texts[paths[0]], 'mod source_equipment_types;\n', 'mod source_equipment_types;\nmod source_equipment_initialization;\n')
p = paths[1]; a = texts[p].index('    fn initialize_source_zone_equipment('); z = texts[p].index('    fn simulate_source_zone_equipment(', a)
texts[p] = texts[p][:a] + '''    fn initialize_source_zone_equipment(
        &mut self,
        first_hvac_iteration: bool,
        o: &mut SourceHvacOwners<'_, '_>,
    ) -> Result<(), Error> {
        if o.equipment.init_equipment_one_time_flag {
            o.equipment.init_equipment_one_time_flag = false;
            let zones = usize::try_from(o.globals.num_of_zones)
                .map_err(|_| Error::Unavailable("actual ZoneEqSizing NumOfZones211"))?;
            o.sizing.zone_equipment_sizing = Some(vec![SourceZoneEquipmentSizing::default(); zones]);
            for number in 1..=o.globals.num_of_zones {
                let config = o.equipment.zone_config.as_deref()
                    .and_then(|rows| rows.get(at(number).ok()?))
                    .ok_or(Error::Unavailable("actual ZoneEquipConfig214"))?;
                if !config.is_controlled {
                    continue;
                }
                if config.equipment_list_index == 0 {
                    continue;
                }
                let count = o.equipment.equipment_lists.as_deref()
                    .and_then(|rows| config.equipment_list_index.checked_sub(1).and_then(|at| rows.get(at)))
                    .ok_or(Error::Unavailable("actual controlled ZoneEquipList221"))?
                    .number_of_equipment_types;
                let native_count = i32::try_from(count)
                    .map_err(|_| Error::Unavailable("actual ZoneEquipCount221 integer domain"))?;
                let sensible = o.controller.demand.zones.as_mut()
                    .and_then(|rows| rows.get_mut(at(number).ok()?))
                    .ok_or(Error::Unavailable("actual ZoneSysEnergyDemand222"))?;
                sensible.base.num_zone_equipment = native_count;
                sensible.sequenced_output_required = Some(vec![0.0; count]);
                sensible.sequenced_output_to_heating_sp = Some(vec![0.0; count]);
                sensible.sequenced_output_to_cooling_sp = Some(vec![0.0; count]);
                let moisture = o.controller.demand.zone_moisture.as_mut()
                    .and_then(|rows| rows.get_mut(at(number).ok()?))
                    .ok_or(Error::Unavailable("actual ZoneSysMoistureDemand227"))?;
                moisture.base.num_zone_equipment = native_count;
                moisture.sequenced_output_required = Some(vec![0.0; count]);
                moisture.sequenced_output_to_humid_sp = Some(vec![0.0; count]);
                moisture.sequenced_output_to_dehumid_sp = Some(vec![0.0; count]);
                let sizing = o.sizing.zone_equipment_sizing.as_mut()
                    .and_then(|rows| rows.get_mut(at(number).ok()?))
                    .ok_or(Error::Unavailable("actual ZoneEqSizing232"))?;
                // Native232 allocation followed by explicit233 whole-array =0.
                // Demand EPVector allocations separately follow their genuine zero-fill API.
                sizing.sizing__method = Some(vec![0; 35]); // HVAC::NumOfSizingTypes
                if o.space_controls.simulation || o.space_controls.sizing {
                    let zone = o.zones.zones.as_deref()
                        .and_then(|rows| rows.get(at(number).ok()?))
                        .ok_or(Error::Unavailable("actual controlled Zone spaceIndexes235"))?;
                    for &space in &zone.space_indexes {
                        let sensible = o.controller.demand.spaces.as_mut()
                            .and_then(|rows| rows.get_mut(at(space).ok()?))
                            .ok_or(Error::Unavailable("actual spaceSysEnergyDemand236"))?;
                        sensible.base.num_zone_equipment = native_count;
                        sensible.sequenced_output_required = Some(vec![0.0; count]);
                        sensible.sequenced_output_to_heating_sp = Some(vec![0.0; count]);
                        sensible.sequenced_output_to_cooling_sp = Some(vec![0.0; count]);
                        let moisture = o.controller.demand.space_moisture.as_mut()
                            .and_then(|rows| rows.get_mut(at(space).ok()?))
                            .ok_or(Error::Unavailable("actual spaceSysMoistureDemand241"))?;
                        moisture.base.num_zone_equipment = native_count;
                        moisture.sequenced_output_required = Some(vec![0.0; count]);
                        moisture.sequenced_output_to_humid_sp = Some(vec![0.0; count]);
                        moisture.sequenced_output_to_dehumid_sp = Some(vec![0.0; count]);
                    }
                }
            }
        }
        if o.equipment.init_equipment_environment_flag && o.clock.begin_envrn_flag {
            if let Some(rows) = o.equipment.equipment_availability.as_mut() {
                rows.fill(0);
            }
            if let Some(rows) = self.ancillary.availability.zone_components.as_mut() {
                for number in 1..=14 {
                    let row = rows.get_mut(number - 1)
                        .ok_or(Error::Unavailable("actual same ZoneComp type257"))?;
                    if let Some(managers) = row.managers.as_mut() {
                        for number in 1..=row.total_components {
                            let manager = managers.get_mut(at(number)?)
                                .ok_or(Error::Unavailable("actual ZoneCompAvailMgrs260"))?;
                            manager.status = 0;
                            manager.start_time = 0;
                            manager.stop_time = 0;
                        }
                    }
                }
            }
            o.equipment.begin_source_equipment_environment(false, o.environment, o.control, o.contaminants)?;
            if o.space_controls.simulation {
                o.equipment.begin_source_equipment_environment(true, o.environment, o.control, o.contaminants)?;
            }
            o.equipment.init_equipment_environment_flag = false;
        }
        if !o.clock.begin_envrn_flag {
            o.equipment.init_equipment_environment_flag = true;
        }
        o.equipment.initialize_source_equipment_timestep(false, first_hvac_iteration, o.control)?;
        if o.space_controls.simulation {
            o.equipment.initialize_source_equipment_timestep(true, first_hvac_iteration, o.control)?;
        }
        if o.hvac.number_of_primary_air_systems > 0 {
            return Err(Error::Unavailable("actual InitZoneEquipment AirLoopFlow308"));
        }
        Ok(())
    }
''' + texts[p][z:]
texts[paths[2]] = '''//! Genuine DataZoneEquipment Config environment/timestep physical Node writes.
use super::{EquipmentConfig, OrdinaryEquipment, SourceNodeData};
use crate::heat_balance::ordinary_heat_balance_initialization::SourceContaminantArrays;
use crate::heat_balance::selected_heat_balance_input::{HeatBalanceInputError as Error, SelectedHeatBalanceInputState};
use crate::psychrometrics::energyplus_psy_h_fn_tdb_w;
use crate::weather::day::WeatherEnvironmentState;

fn node_index(ordinal: usize, nodes: &[SourceNodeData]) -> Result<usize, Error> {
    ordinal.checked_sub(1).filter(|&at| at < nodes.len())
        .ok_or(Error::Unavailable("actual Config physical Node positive ordinal"))
}
fn begin_environment_node(
    nodes: &mut [SourceNodeData], ordinal: usize, environment: &WeatherEnvironmentState,
    control: &SelectedHeatBalanceInputState, contaminants: &SourceContaminantArrays,
) -> Result<(), Error> {
    let at = node_index(ordinal, nodes)?;
    let node = &mut nodes[at];
    node.temperature = 20.0;
    node.mass_flow_rate = 0.0;
    node.quality = 1.0;
    node.pressure = environment.current_weather.out_baro_press;
    node.humidity_ratio = environment.current_weather.out_hum_rat;
    node.enthalpy = energyplus_psy_h_fn_tdb_w(node.temperature, node.humidity_ratio);
    if control.carbon_dioxide_simulation {
        node.carbon_dioxide = contaminants.outdoor_co2;
    }
    if control.generic_contaminant_simulation {
        node.generic_contaminant = contaminants.outdoor_gc;
    }
    Ok(())
}
impl EquipmentConfig {
    fn begin_source_environment(
        &self, nodes: &mut [SourceNodeData], environment: &WeatherEnvironmentState,
        control: &SelectedHeatBalanceInputState, contaminants: &SourceContaminantArrays,
    ) -> Result<(), Error> {
        begin_environment_node(nodes, self.zone_node, environment, control, contaminants)?;
        if let Some(inlets) = &self.inlet_node_numbers {
            for &ordinal in inlets {
                begin_environment_node(nodes, ordinal, environment, control, contaminants)?;
            }
        }
        if let Some(exhausts) = &self.exhaust_node_numbers {
            for &ordinal in exhausts {
                begin_environment_node(nodes, ordinal, environment, control, contaminants)?;
            }
        }
        if self.return_nodes > 0 {
            if let Some(returns) = &self.return_node_numbers {
                for &ordinal in returns {
                    begin_environment_node(nodes, ordinal, environment, control, contaminants)?;
                }
            }
        }
        Ok(())
    }
    fn initialize_source_timestep(
        &mut self, nodes: &mut [SourceNodeData], first_hvac_iteration: bool,
        control: &SelectedHeatBalanceInputState,
    ) -> Result<(), Error> {
        // Native2305 binds the actual zone Node even when First=false or
        // the real exhaust allocation is empty; check it before ExcessZoneExh.
        let zone_at = node_index(self.zone_node, nodes)?;
        self.excess_zone_exhaust = 0.0;
        if first_hvac_iteration {
            if let Some(exhausts) = &self.exhaust_node_numbers {
                for &ordinal in exhausts {
                    let at = node_index(ordinal, nodes)?;
                    // Each RHS is the current same Node field immediately
                    // before its real write. Aliased ordinals are not cloned.
                    nodes[at].temperature = nodes[zone_at].temperature;
                    nodes[at].humidity_ratio = nodes[zone_at].humidity_ratio;
                    nodes[at].enthalpy = nodes[zone_at].enthalpy;
                    nodes[at].pressure = nodes[zone_at].pressure;
                    nodes[at].quality = nodes[zone_at].quality;
                    nodes[at].mass_flow_rate = 0.0;
                    nodes[at].mass_flow_rate_max_available = 0.0;
                    nodes[at].mass_flow_rate_min_available = 0.0;
                    if control.carbon_dioxide_simulation {
                        nodes[at].carbon_dioxide = nodes[zone_at].carbon_dioxide;
                    }
                    if control.generic_contaminant_simulation {
                        nodes[at].generic_contaminant = nodes[zone_at].generic_contaminant;
                    }
                }
            }
        }
        Ok(())
    }
}
impl OrdinaryEquipment {
    pub(crate) fn begin_source_equipment_environment(
        &mut self, space: bool, environment: &WeatherEnvironmentState,
        control: &SelectedHeatBalanceInputState, contaminants: &SourceContaminantArrays,
    ) -> Result<(), Error> {
        let configs = if space { &self.space_config } else { &self.zone_config };
        if let Some(configs) = configs {
            for config in configs {
                if !config.is_controlled { continue; }
                let nodes = self.nodes.physical.as_deref_mut()
                    .ok_or(Error::Unavailable("actual Config beginEnvirnInit physical allocation2236"))?;
                config.begin_source_environment(nodes, environment, control, contaminants)?;
            }
        }
        Ok(())
    }
    pub(crate) fn initialize_source_equipment_timestep(
        &mut self, space: bool, first_hvac_iteration: bool, control: &SelectedHeatBalanceInputState,
    ) -> Result<(), Error> {
        let configs = if space { &mut self.space_config } else { &mut self.zone_config };
        if let Some(configs) = configs {
            for config in configs {
                if !config.is_controlled { continue; }
                let nodes = self.nodes.physical.as_deref_mut()
                    .ok_or(Error::Unavailable("actual Config hvacTimeStepInit physical allocation2305"))?;
                config.initialize_source_timestep(nodes, first_hvac_iteration, control)?;
            }
        }
        Ok(())
    }
}
'''
p = paths[3]
for name in ['sequenced_output_required', 'sequenced_output_to_heating_sp', 'sequenced_output_to_cooling_sp', 'sequenced_output_to_humid_sp', 'sequenced_output_to_dehumid_sp']:
    old_type = f'pub(crate) {name}: Vec<f64>,'
    expected = 2 if name == 'sequenced_output_required' else 1
    assert texts[p].count(old_type) == expected
    texts[p] = texts[p].replace(old_type, f'pub(crate) {name}: Option<Vec<f64>>,')
texts[p] = swap(texts[p], '//! Genuine ZoneEnergyDemand/HeatBalance AirReport allocated owners.', '''//! Genuine ZoneEnergyDemand/HeatBalance AirReport allocated owners.
// Sequenced EPVector arrays preserve None allocation vs Some allocation.
// Their real allocate() performs value-initialization and an explicit T{} fill.''')
p = paths[4]
assert texts[p].count('if !self.sequenced_output_required.is_empty() {') == 2
texts[p] = texts[p].replace('if !self.sequenced_output_required.is_empty() {', 'if self.sequenced_output_required.is_some() {')
for name in ['sequenced_output_required', 'sequenced_output_to_heating_sp', 'sequenced_output_to_cooling_sp', 'sequenced_output_to_humid_sp', 'sequenced_output_to_dehumid_sp']:
    pattern = r'(\.' + name + r'\n\s*)\.get_mut\(number\)'
    texts[p], count = re.subn(pattern, r'\1.as_mut()\n                    .and_then(|rows| rows.get_mut(number))', texts[p])
    assert count == (3 if name == 'sequenced_output_required' else (2 if name in ['sequenced_output_to_heating_sp', 'sequenced_output_to_cooling_sp'] else 1)), (name, count)

assert not O.exists(); O.mkdir()
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal>', 'exec'), ns)
files = []
for i, p in enumerate(paths, 1):
    old, new = before[p], texts[p].encode()
    f = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p)).encode()
    inv = ''.join(difflib.unified_diff(new.decode().splitlines(keepends=True), old.decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p)).encode()
    assert ns['apply_literal'](old, f) == new and ns['apply_literal'](new, inv) == old
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and not parsed.stderr
    files.append({'canonical_path': p, 'before_absent': p not in entries, 'parent22': entries[p]['source'] if p in entries else None,
        'before': put('before/' + p, old), 'proposed': put('proposed/' + p, new), 'forward_diff': put(f'diffs/{i:02d}-forward.diff', f), 'inverse_diff': put(f'diffs/{i:02d}-inverse.diff', inv),
        'both_literal_applications_exact': True, 'Source_only_parse': {'exit_code': 0, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})
native, extents = [], []
for p, ranges in {
    'src/EnergyPlus/ZoneEquipmentManager.cc': [(142, 316)],
    'src/EnergyPlus/ZoneEquipmentManager.hh': [(271, 285)],
    'src/EnergyPlus/DataZoneEquipment.cc': [(2234, 2327)],
    'src/EnergyPlus/DataZoneEquipment.hh': [(398, 521)],
    'src/EnergyPlus/DataSizing.hh': [(708, 765), (1362, 1370)],
    'src/EnergyPlus/DataHVACGlobals.hh': [(94, 101)],
    'src/EnergyPlus/DataZoneEnergyDemands.hh': [(62, 144)],
    'src/EnergyPlus/DataZoneEnergyDemands.cc': [(57, 97), (330, 352)],
    'src/EnergyPlus/DataLoopNode.hh': [(439, 500)],
    'src/EnergyPlus/Psychrometrics.hh': [(648, 666)],
    'src/EnergyPlus/EPVector.hh': [(56, 155)],
}.items():
    b = subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N)
    assert b == (N / p).read_bytes()
    native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, b)})
    for first, last in ranges:
        literal = b''.join(b.splitlines(keepends=True)[first-1:last])
        extents.append({'native_path': p, 'first': first, 'last': last, 'utf8_sha256': hashlib.sha256(literal).hexdigest(), 'literal': literal.decode()})
contexts = []
for p in [P + x for x in ['ordinary_equipment/source_nodes.rs', 'ordinary_equipment/source_controlled_equipment.rs', 'selected_sizing.rs',
    'ordinary_hvac_manager/owners.rs', 'ordinary_heat_balance_initialization/state.rs', 'selected_heat_balance_input.rs', 'selected_heat_balance_space_controls.rs']]:
    b = check(entries[p]['source']).read_bytes()
    contexts.append({'canonical_path': p, 'parent22': entries[p]['source'], 'frozen': put('context/' + p, b)})
draft = {'status': 'UNSEALED_SOURCE_ONLY_NOT_COMPILED_OR_EXECUTED', 'parent22_producer': parent_ref, 'parent22_plan': parent['complete_final_compiler_Source_plan'],
    'files': files, 'existing_Source_files': 4, 'new_Source_files': 1, 'literal_applications': 10, 'Source_only_parses': 5,
    'Native_commit': PIN, 'Native_wholes': native, 'Native_literal_extents': doc('Native-literal-extents.json', extents), 'unchanged_contexts': contexts,
    'scope': ['Whole Native InitZoneEquipment199–316 finite controlled one-time/environment/timestep path; positive AirLoopFlow308 remains genuine first unrepresented owner.',
        'One-time flag false before sizing allocation; actual EquipList NumOfEquipTypes supplies same real demand NumZoneEquipment and six distinct genuine zero-filled EPVector arrays. SizingMethod35 zero comes from actual explicitNative233 write.',
        'Same six demand arrays are Option<Vec<f64>>: None=unallocated, Some(vec0)=actual EPVector allocate zero fill, including allocated empty. Existing reset/reporter writes remain literal f64 values; no duplicate value cache.',
        'Same configuration/physical Node owns environment zone→inlet→exhaust→return traversal and six literal writes plus actual optional contaminant values; no whole-row replacement or typedNode projection.',
        'Every controlled configuration timestep validates actual ZoneNode before ExcessZoneExh0 even First=false/exhaustempty. ActualFirst exhaust copies current sameNode fields in order, preserving aliases and untouched fields.',
        'Space demand allocation uses simulation||sizing and actual zone.spaceIndexes; environment/timestep SpaceConfig children use simulation only. No inferred false flags or ownercounts.'],
    'allocation_qualification': 'Exact DataZoneEnergyDemands.hh95-97/134-136 declares EPVector<Real64>, whose allocate98-103 sets allocation then resize and explicit T{} fill; Some(vec0) is real Native initialization. Actual finite count is retained nonnegative cardinality checked within i32; negative corrupted Native counts are not certified.',
    'no_positive_internal_Native_pair_or_full_B_claim': True, 'main_mutations': 0, 'Cargo_Native_or_tests_executed': False, 'new_tests': 0,
    'author_Source': ref(Path(__file__))}
print(json.dumps(doc('draft.json', draft)))

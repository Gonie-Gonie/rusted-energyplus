"""Seal cohesive InitZoneEquipment Sources on exact committed/actual22."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
HEAD = 'c5a6242d20a2c55e33948b5a11fb6ebae39dbe20'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'source-zone-equipment-initialization-held-Peer-23-02'

def ref(p):
    b = p.read_bytes(); return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def check(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', got['bytes']), row
    return p
def load(row): return json.loads(check(row).read_bytes())
def put(name, b):
    p = O / name; assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b); return ref(p)
def doc(name, obj): return put(name, (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())
def git(p): return subprocess.check_output(['git', 'show', HEAD + ':' + p], cwd=R)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == HEAD
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=R, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
root_ref = ref(D / 'Root-source-component-availability-actual-review-22/review.json')
assert root_ref['sha256'] == '4bc5bb47687afbb5bc29334ce8ea52662be31d31542b1459e057bd191eb4eb05'
root = load(root_ref); assert root['accepted'] and not root['findings']
assert root['B_frontier'] == 'GetHeatBalanceInput: actual controlled ZoneEquipList count223'
B_ref, A_ref = root['actual_B'], root['actual_A24']; B, A = load(B_ref), load(A_ref)
assert B['exit_code'] == 6 and A['exit_code'] == 0 and B['launch_error'] is None and A['launch_error'] is None
assert B['source_bytes_match_before_and_after'] and A['source_bytes_match_before_and_after']
assert B['source_snapshot'] == A['source_snapshot']
snapshot_ref = B['source_snapshot']; snapshot = load(snapshot_ref)
observed = {row['historical_path']: row for row in snapshot['files']}
assert len(observed) == len(snapshot['files']) == 4490 and sum(p.endswith('.rs') for p in observed) == 4477
draft_ref = ref(D / 'source-zone-equipment-initialization-draft-Peer-23-02/draft.json')
assert draft_ref['sha256'] == 'c47229e1b28135ec52b1c7c7d7453d81f8ed7d7a45cb7d6f30183c00f31f1f9f'
draft = load(draft_ref); parent = load(draft['parent22_producer']); parent_plan = load(draft['parent22_plan'])
parents = {row['path']: row for row in parent_plan['entries']}; assert set(parents) == set(observed)
for p, row in parents.items():
    b = check(row['source']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == row['final_sha256'] and len(b) == row['final_bytes']
    assert b == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes(), p
paths = set((R / 'crates').rglob('*.rs')) | set((R / 'crates').rglob('Cargo.toml'))
for p in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml']:
    if (R / p).is_file(): paths.add(R / p)
assert {p.relative_to(R).as_posix() for p in paths} == set(observed)
assert P + 'source_output_registration/report_diagnostics.rs' not in observed
assert not (R / (P + 'source_output_registration/report_diagnostics.rs')).exists()
assert len(draft['files']) == 5 and draft['existing_Source_files'] == 4 and draft['new_Source_files'] == 1
assert not O.exists(); O.mkdir()
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal>', 'exec'), ns)
files, texts = [], {}
for i, row in enumerate(draft['files'], 1):
    p = row['canonical_path']; old, new = check(row['before']).read_bytes(), check(row['proposed']).read_bytes()
    if row['before_absent']:
        assert old == b'' and p not in observed and not (R / p).exists()
        assert subprocess.run(['git', 'cat-file', '-e', HEAD + ':' + p], cwd=R, capture_output=True).returncode != 0
    else:
        assert old == check(row['parent22']).read_bytes() == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes() == git(p)
    f, inv = check(row['forward_diff']).read_bytes(), check(row['inverse_diff']).read_bytes()
    assert ns['apply_literal'](old, f) == new and ns['apply_literal'](new, inv) == old
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and not parsed.stderr
    added = ''.join(line[1:] for line in f.decode().splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
    assert not re.search(r'\.(?:unwrap|expect)\s*\(|\b(?:panic|todo|unimplemented|unreachable)!|#\[test\]|\.runtime[/\\]', added)
    texts[p] = new.decode()
    files.append({'canonical_path': p, 'before_absent': row['before_absent'], 'before': put('before/' + p, old), 'proposed': put('proposed/' + p, new),
        'literal_inverse': put('literal-inverse/' + p, old), 'forward_diff': put(f'diffs/{i:02d}-forward.diff', f), 'inverse_diff': put(f'diffs/{i:02d}-inverse.diff', inv),
        'actual22_archive': observed[p]['archive'] if p in observed else None, 'committed22_Git_and_actual22_and_live_before_whole_equal': not row['before_absent'],
        'Source_only_parse': {'exit_code': 0, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})
selected = {row['canonical_path']: row for row in files}
entries, hits = [], []
patterns = ['sequenced_output_required', 'sequenced_output_to_heating_sp', 'sequenced_output_to_cooling_sp', 'sequenced_output_to_humid_sp', 'sequenced_output_to_dehumid_sp',
    'initialize_source_zone_equipment(', 'begin_source_equipment_environment(', 'initialize_source_equipment_timestep(', 'SourceZoneAirOwners {', 'SourceHvacOwners {']
for p in sorted(set(observed) | set(selected)):
    source = selected[p]['proposed'] if p in selected else observed[p]['archive']; b = check(source).read_bytes()
    entries.append({'path': p, 'final_sha256': source['sha256'], 'final_bytes': len(b), 'source': {**source, 'bytes': len(b)},
        'origin': 'selected23 genuine equipment initialization Source' if p in selected else 'whole exact actual22 archived parent'})
    if p.endswith('.rs'):
        for number, line in enumerate(b.decode().splitlines(), 1):
            found = [pattern for pattern in patterns if pattern in line]
            if found: hits.append({'path': p, 'line': number, 'literal': line, 'patterns': found})
assert len(entries) == 4491 and sum(row['path'].endswith('.rs') for row in entries) == 4478
array_hit_paths = {row['path'] for row in hits if any(p.startswith('sequenced_') for p in row['patterns'])}
assert array_hit_paths == {P + x for x in ['ordinary_equipment/management.rs', 'ordinary_air_heat_balance/predictor_corrector/demand.rs', 'ordinary_air_heat_balance/predictor_corrector/lifecycle/demand.rs']}
assert sum('SourceZoneAirOwners {' in row['patterns'] for row in hits) == 1
assert sum('SourceHvacOwners {' in row['patterns'] for row in hits) == 2
plan_ref = doc('complete-final-compiler-Source-plan.json', {'base_HEAD': HEAD, 'parent_actual_snapshot': snapshot_ref, 'inputs': 4491, 'Rust_sources': 4478,
    'entries': entries, 'Root_full_rehash_required': True})
api_ref = doc('whole-crates-concrete-API-inventory.json', {'before_inputs': 4490, 'before_Rust': 4477, 'final_inputs': 4491, 'final_Rust': 4478,
    'all4490_parent_and4491_final_wholes_rehashed': True, 'includes_all_crates_runtime_and_tests': True, 'occurrences': hits,
    'six_same_sequenced_arrays_all_uses': sorted(array_hit_paths), 'direct_init_call': 'manage_source_zone_equipment -> initialize_source_zone_equipment',
    'new_owner_or_duplicated_Node_state': False, 'no_test_constructor_adapters_required': True})
contexts = []
for row in draft['unchanged_contexts']:
    p = row['canonical_path']; b = check(row['frozen']).read_bytes()
    assert p not in selected and b == check(observed[p]['archive']).read_bytes() == git(p) == (R / p).read_bytes()
    contexts.append({'canonical_path': p, 'whole': put('context/' + p, b), 'actual22_archive': observed[p]['archive'], 'committed22_Git_and_actual22_and_live_whole_equal': True})
native, native_bytes = [], {}
for row in draft['Native_wholes']:
    p = row['Native_path']; b = check(row['whole']).read_bytes()
    assert b == subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N) == (N / p).read_bytes()
    native_bytes[p] = b; native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, b)})
p = 'src/EnergyPlus/DataContaminantBalance.hh'; b = subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N)
assert b == (N / p).read_bytes()
native_bytes[p] = b; native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, b)})
extents = load(draft['Native_literal_extents'])
for row in extents:
    b = b''.join(native_bytes[row['native_path']].splitlines(keepends=True)[row['first']-1:row['last']])
    assert b.decode() == row['literal'] and hashlib.sha256(b).hexdigest() == row['utf8_sha256']
for p, first, last in [('src/EnergyPlus/DataZoneEquipment.hh', 305, 390)]:
    b = b''.join(native_bytes[p].splitlines(keepends=True)[first-1:last])
    extents.append({'native_path': p, 'first': first, 'last': last, 'utf8_sha256': hashlib.sha256(b).hexdigest(), 'literal': b.decode()})
management = texts[P + 'ordinary_equipment/management.rs']
before_management = check(next(row for row in files if row['canonical_path'] == P + 'ordinary_equipment/management.rs')['before']).read_bytes().decode()
assert management.split('    fn simulate_source_zone_equipment(', 1)[1] == before_management.split('    fn simulate_source_zone_equipment(', 1)[1]
assert management.count('Some(vec![0.0; count])') == 12
types = texts[P + 'ordinary_air_heat_balance/predictor_corrector/demand.rs']
assert types.count('Option<Vec<f64>>') == 6
writers = texts[P + 'ordinary_air_heat_balance/predictor_corrector/lifecycle/demand.rs']
assert writers.count(')? = 0.0;') == 6 and 'Some(self.' not in writers
assert writers.count('if self.sequenced_output_required.is_some()') == 2
rejected_ref = ref(D / 'source-zone-equipment-initialization-held-Peer-23/manifest.json')
assert rejected_ref['sha256'] == '9dcdca12a98af6724a5fc469b472bca13496a1cc4b7e947cea9a75aa9abdb829'
rejected = load(rejected_ref)
prior = {row['canonical_path']: row for row in rejected['files']}
corrections, preserved = [], []
for row in files:
    p = row['canonical_path']; old = check(prior[p]['proposed']).read_bytes(); new = check(row['proposed']).read_bytes()
    if old == new:
        preserved.append(p); continue
    forward = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile=p, tofile=p)).encode()
    inverse = ''.join(difflib.unified_diff(new.decode().splitlines(keepends=True), old.decode().splitlines(keepends=True), fromfile=p, tofile=p)).encode()
    assert ns['apply_literal'](old, forward) == new and ns['apply_literal'](new, inverse) == old
    corrections.append({'canonical_path': p, 'rejected_before': prior[p]['proposed'], 'corrected_after': row['proposed'], 'whole_inverse_exact': True,
        'forward_diff': put('correction/' + p + '.forward.diff', forward), 'inverse_diff': put('correction/' + p + '.inverse.diff', inverse)})
assert len(corrections) == 3 and len(preserved) == 2
correction_ref = doc('EPVector-correction-proof.json', {'rejected_predecessor': rejected_ref, 'rejected_predecessor_never_applied': True,
    'current_clean_parent_before_wholes_verified': True,
    'finding': 'Author inferred Objexx semantics from allocate call without authenticating actual six field types. Independent peer found EPVector<Real64> declarations, whose allocate explicitly fills T{}.',
    'authoritative_fields': 'DataZoneEnergyDemands.hh95-97/134-136 exact EPVector<Real64>; EPVector.hh98-103 allocate,129-132 allocated,154 ctor flagfalse.',
    'correction': 'Same six fields now Option<Vec<f64>>, unallocated None/default; real count-sized Some(vec0) at Native allocation; unchanged f64 reset/reportwrites. Some(empty) preserves allocation for count0.',
    'negative_count_domain': 'Native count field is int but authoritative finite writer is nonnegative cardinality. Source usize cardinality is checked to i32 before NumZoneEquipment write; negative corrupted Native count and huge unsigned allocation behavior are not certified or clamped.',
    'changed_Source_wholes': corrections, 'unchanged_Source_wholes': preserved, 'additional_literal_applications': 6,
    'discarded_claims': 'No unwritten-cell or generic Objexx policy claim belongs to corrected producer. Rejected01 remains immutable for correction history; no compiled/executed23 predecessor is claimed.'})
contract_ref = doc('integration-contract.json', {'scope': draft['scope'],
    'one_time_order': ['flagfalse', 'actual NumZones class-default sizing allocation', 'actual controlled+EquipListIndex guards', 'actual list.NumOfEquipTypes',
        'zone sensible NumZoneEquipment then3 zero-filled EPVector arrays', 'zone moisture NumZoneEquipment then3 zero-filled EPVector arrays', 'actual sizing SizingMethod35 allocation+explicitzero',
        'only simulation||sizing actual spaces: sensible thenmoisture eachNumZoneEquipment+3zero-filled EPVector arrays'],
    'environment_order': ['actual init_environment&&BeginEnvrn', 'same ZoneEquipAvail NoAction', 'same14 component manager status/start/stop resets',
        'actual controlled zone configs Node methods', 'simulation-only controlled space configs Node methods', 'environmentflagfalse', 'if!BeginEnvrn flagtrue'],
    'Node_environment': ['zone actual Node thenwholeordered inlet thenexhaust thenreturnonlyifNumReturn>0', 'Temp20', 'Mass0', 'Quality1', 'PressactualOutBaro',
        'HumactualOutW', 'normalH(actualTemp,actualHum)', 'actualCO2 flag→sameOutdoorCO2', 'actualGC flag→sameOutdoorGC'],
    'Node_timestep': ['bind/checkactualZoneNode evenFirstfalse/exhaustempty', 'sameConfig.ExcessZoneExh0', 'ifFirst actualwholeexhaustarray',
        'copy currentzoneTemp/Hum/H/Press/Quality inthatorder', 'exhaustMass/maxAvail/minAvail0', 'actualoptionalCO2/GCcopy'],
    'allocation_policy': draft['allocation_qualification'],
    'same_array_writers': 'Existing environment reset allocated guard becomes Option::is_some; exactoldf64 write order and values preserved. Same Option allocation marker tracks EPVector allocated status including allocated-empty; no inner unwritten-cell state or extra readiness/cache fields.',
    'alias_policy': 'Physical Node allocation never cloned. Timestep each RHS reads current original Node field before matching destination write, so aliased Node ordinals retain genuine behavior.',
    'limits': ['Actual22 B stops before newly ported positive sequencing; Source-only until Root actual23. No internal Native pair, positive exhaust/contaminant/space execution, fullB or Node setup/reset execution claimed.',
        'Positive actual AirLoopFlow308 remains first unrepresented owner. Source simulate_source_zone_equipment body and its existing boundaries are byte-identical to parent22.',
        'No Source18/20 activation or new tests; real Node20/1 literals come only from pinned Native initialization, not observed answer injection.']})
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
manifest = {'schema': 'src06-held-cohesive-zone-equipment-initialization.v1', 'status': 'HELD Source only; compilation/actual23 pending', 'base_HEAD': HEAD,
    'actual22_review': root_ref, 'actual22_snapshot': snapshot_ref, 'actual22_B': B_ref, 'actual22_A24': A_ref, 'actual22_complete_plan': draft['parent22_plan'],
    'parent22_producer': draft['parent22_producer'], 'files': files, 'existing_Source_files': 4, 'new_Source_files': 1, 'literal_applications': 10, 'Source_only_parses': 5,
    'complete_final_compiler_Source_plan': plan_ref, 'whole_crates_API_inventory': api_ref, 'Native_commit': PIN,
    'Native_wholes': [{**ref(N / row['Native_path']), 'whole_equals_git': True} for row in native], 'frozen_Native_wholes': native,
    'Native_literal_extents': doc('Native-literal-extents.json', extents), 'unchanged_contexts': contexts, 'integration_contract': contract_ref,
    'rejected_predecessor': rejected_ref, 'EPVector_correction_proof': correction_ref, 'unsealed_author_draft': draft_ref, 'author_Source': draft['author_Source'], 'sealer_Source': ref(Path(__file__)),
    'new_test_bodies': 0, 'Cargo_Native_or_tests_executed': False, 'main_mutations': 0, 'FP_tolerance_or_gate_changes': False, 'full_B_or_positive_Node_execution_claim': False}
print(json.dumps(doc('manifest.json', manifest)))

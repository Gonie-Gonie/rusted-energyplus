"""Publish actual bounded checks243-267, without claiming downstream kickoff."""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

root = Path.cwd()
base = root/'.runtime/porting/SRC-06'
out = root/'energyplus_porting_plan/evidence/SRC-06-ordinary-run-prefix-checks'
assert not out.exists()
assembly_path = base/'ordinary-run-prefix-checks-assembly-01/manifest.json'
review_path = root/sys.argv[1]
review_sha = sys.argv[2]
assembly_sha = sys.argv[3]
def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}
def load(path): return json.loads(path.read_bytes())
def write(path,value): path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value: yield value
        else:
            for child in value.values(): yield from walk(child)
    elif isinstance(value,list):
        for child in value: yield from walk(child)
assert ref(assembly_path)['sha256']==assembly_sha
assert ref(review_path)['sha256']==review_sha and load(review_path)['accepted'] is True
assert any(row['sha256']==assembly_sha for row in walk(load(review_path)))
assembly=load(assembly_path)
held_path=root/assembly['accepted_packet']['path']
assert ref(held_path)['sha256']=='de79109617de0c431b5842a86baea65b5aa386b94e59fd5bec236f9eabbfc127'
artifacts,historical,archives={},{},{}
for row in assembly['files']:
    for key in ['before','after','accepted_proposal']:
        value=row[key]; archives[value['sha256']]=root/value['path']
def add(path):
    value=ref(path); artifacts[value['path']]=value; return value
def checked(row):
    path=root/row['path']
    if not path.is_file() or ref(path)['sha256']!=row['sha256']:
        path=archives[row['sha256']]
        historical[row['path']+row['sha256']]={'historical_reference':row,'exact_archive':ref(path),
            'qualification':'Immutable complete historical bytes; not relabeled current.'}
    actual=ref(path)
    assert actual['sha256']==row['sha256'] and actual['size_bytes']==row.get('size_bytes',actual['size_bytes'])
    return path
for path in [assembly_path,held_path,root/assembly['independent_Source_review']['path'],review_path,
             root/assembly['apply']['path']]:
    add(path)
    for row in walk(load(path)): add(checked(row))
for row in assembly['files']: assert ref(root/row['canonical']['path'])==row['canonical']
add(base/'run-ci-force-time-step-Root-01.ps1')
qa,tests,snapshot=[],[],None
expected_commands={
    'fmt':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','fmt','--all','--','--check'],
    'quality':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1'],
    'clippy':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','clippy','--workspace','--all-targets','--','-D','warnings'],
    'input-output-tests':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','test','-p','ep_run','--lib','--','actual_fatal_prefix_survives_runtime_failure_and_summary','raw_equipment_admission'],
    'cli-tests':['C:/Users/GonieGonie/.cargo/bin/cargo.exe','test','-p','ep_run','--test','arbitrary_run','one_zone_runtime_writes_stable_output_layout'],
    'ci-timestep-tests':['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','.runtime/porting/SRC-06/run-ci-force-time-step-Root-01.ps1'],
}
for suffix in ['fmt','quality','clippy','input-output-tests','cli-tests','ci-timestep-tests']:
    path=base/f'ordinary-run-prefix-checks-{suffix}-01/receipt.json'
    value=load(path)
    assert value['command']==expected_commands[suffix]
    assert value['exit_code']==0 and value['launch_error'] is None and value['source_bytes_match_before_and_after'] is True
    if snapshot is None: snapshot=value['source_snapshot']
    assert snapshot==value['source_snapshot']
    qa.append({'receipt':ref(path),'command':value['command'],'exit_code':0})
    add(path)
    for key in ['stdout','stderr','source_snapshot']: add(checked(value[key]))
    if 'tests' in suffix:
        groups=[tuple(map(int,row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',checked(value['stdout']).read_text(encoding='utf8'))]
        assert groups and all(row[1]==row[2]==0 for row in groups)
        tests.append({'scope':suffix,'passed':sum(row[0] for row in groups),'failed':0,'ignored':0})
assert [row['passed'] for row in tests]==[2,1,1]
add(Path(__file__))
out.mkdir()
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(artifacts): z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(artifacts)
    for name in z.namelist(): assert hashlib.sha256(z.read(name)).hexdigest()==artifacts[name]['sha256']
write(out/'manifest.json',{'schema':'src06-pre-kickoff-checks-evidence.v1','Source_snapshot':snapshot,
    'assembly':ref(assembly_path),'artifacts':list(artifacts.values()),'historical_references':list(historical.values()),
    'archive':ref(archive),'archive_member_count':len(artifacts),
    'archive_scope':'Five complete actual before/after/direct diffs and held-to-formatter deltas; genuine finite literal Original ranges including two complete sizing helper enclosures and the no-work closure; independent Source/application review and six actual QA receipts/logs/Source indexes. Prior full startup evidence and whole-workspace/Native objects are referenced rather than recursively bundled.',
    'gates_updated':False})
write(out/'summary.json',{'schema':'src06-pre-kickoff-checks-summary.v1',
    'status':'Actual ordinary RunSimulation243-267 checks and zero-domain sizing adjustments connected; kickoff/Setup pending',
    'Source_snapshot':snapshot,'behavior':[
        'The existing reached213-241 caller continues directly through actual warning243, Available249, supported false DoPure251, real retained invalid-branch257 fatal and three DisplayString operations261/264/267.',
        'Available is the real caller local: constructorNone, Some(true) only after249, retained on later error. It does not represent weather selection, numerical readiness or Setup completion.',
        'ManageSystemSizingAdjustments262 consumes the same actual sizing count and DoSystemSizing. Its complete body is enclosed by the actual false predicate; no numerical/report body is substituted.',
        'ManageSystemVentilationAdjustments265 consumes the sole actual HVAC NumPrimaryAirSys constructor0. Both complete effectful bodies are enclosed by its two zero-iteration loops; NumAirLoops/raw counts are not reused for this distinct field.',
        'Real backend callbacks, console guards, writes and flushes execute in actual DisplayString order. The existing output/fatal body verifies all three console lines, actual Available and no kickoff write.',
    ],'QA':qa,'tests':{'selections':tests,'passed':4,'failed':0,'ignored':0,'new_bodies':0,'new_binaries':0},
    'validation_scope':'One fmt/source-quality/all-target workspace Clippy run and existing raw/output2, actual normalCLI1 and CI_FORCE_TIME_STEP=Y CLI1. Prior prefix4 and earlier initialization20 successes are not recounted. No new test body/bin, workspace-test repetition or Native execution.',
    'limitations':[
        'Positive sizing/primary-air-system/pure-load/tabular bodies remain explicitly unavailable; no fabricated tabular or sizing owner is introduced.',
        'The actual Branch invalid fatal is Source-reviewed; the supported public zero-branch producer cannot induce it, and no fake setter/test fixture was added.',
        'KickOff268, ResetEnvironmentCounter270 and SetupSimulation272 are outside this actual connected prefix. Full weather/HB/Surface/HVAC numerical execution remains incomplete.',
        'Whole ordinary235456 mismatches/2754 unavailable and DesignDay nine strict failures/eight UNPAIRED unchanged. No tolerance or Native numerical gate changed.',
        'SRC06 four gates remain unverified; A14/54 B14/64 unchanged.',
    ],'independent_Source_review':assembly['independent_Source_review'],'independent_application_review':ref(review_path),
    'manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False})
plan_path=root/'energyplus_porting_plan/plan.json'
plan=load(plan_path); task=next(row for row in plan['tasks'] if row['id']=='SRC-06')
assert all(task[key]=='미확인' for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_run_prefix_checks' not in task
task['actual_selected_ordinary_run_prefix_checks']=ref(out/'summary.json');write(plan_path,plan)
card=root/'energyplus_porting_plan/cards/SRC-06.md';text=card.read_text(encoding='utf8')
assert text.count('아래 19개 요약')==1;text=text.replace('아래 19개 요약','아래 20개 요약')
needle='\n기존 Weather03·absent site/station';assert text.count(needle)==1
text=text.replace(needle,'| 실제 kickoff 직전 검사 / sizing 조정의 비활성 경로 | [요약](../evidence/SRC-06-ordinary-run-prefix-checks/summary.json) · [색인](../evidence/SRC-06-ordinary-run-prefix-checks/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-run-prefix-checks/evidence.zip) | 실제243–267의 Available·Branch fatal·DisplayString과 두 실제 비활성 sizing 조정 함수. Kickoff268/Reset270/Setup272·양의 sizing 수치 완료는 아님. |\n'+needle)
needle='\n## 이력과 증거 보존';assert text.count(needle)==1
text=text.replace(needle,'\n## 실제 kickoff 직전 검사 단위의 QA\n\nSource `'+snapshot['sha256']+'`에서 fmt·source-quality·all-target workspace Clippy와 기존 입력/출력 2개·일반 CLI 1개·실제 `CI_FORCE_TIME_STEP=Y` CLI 1개, **4 passed / 0 failed / 0 ignored**를 확인했다. 기존 본문에서 세 실제 진행 문자열 순서와249 Available·kickoff 미대입을 검사했다. 새 테스트 본문·binary·전체 workspace 반복·새 Native 실행은 없다. 앞 단위의 성공을 중복 합산하지 않으며 실제 양의 sizing/Branch fatal 실행은 이 테스트의 PASS에 넣지 않는다. 모든 gate와 A/B 완료 수는 그대로다.\n'+needle)
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'archive_members':len(artifacts),'archive_bytes':archive.stat().st_size,'tests':tests},ensure_ascii=False))

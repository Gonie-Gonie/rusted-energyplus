"""Finite Source-only RunSimulation243-267 continuation on actual ac15758c."""
import difflib
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[3]
UNIT = ROOT / '.runtime/porting/SRC-06/ordinary-run-prefix-checks-prep-01'
ORIGINAL = ROOT / '.reference/energyplus-src/26.1.0'
COMMIT = '6f2e40d10250a105b49966baa24d843711e61048'
HEAD = 'ac15758ce02caaebe3e63ec371306e776f08e869'
PARENT = ROOT / '.runtime/porting/SRC-06/ordinary-run-prefix-assembly-01/manifest.json'

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8', newline='\n')
    return ref(path)

def replace(text, before, after):
    assert text.count(before) == 1, (before[:100], text.count(before))
    return text.replace(before, after)

assert subprocess.run(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], capture_output=True, check=True, text=True).stdout.strip() == HEAD
assert not (UNIT / 'manifest.json').exists(), 'sealed packet exists'
files = []
def emit(path, text):
    canonical = ROOT / path
    actual = canonical.read_bytes()
    assert b'\r\n' not in actual
    before = UNIT / 'before' / path
    before.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(actual)
    proposal = write(UNIT / 'proposed' / path, text)
    complete_diff = write(UNIT / 'diffs' / (str(len(files)).zfill(2) + '.diff'), ''.join(
        difflib.unified_diff(actual.decode().splitlines(True), text.splitlines(True),
            fromfile='ac15758c/' + path, tofile='held/' + path)))
    files.append({'canonical_path': path, 'actual_base': ref(canonical), 'before': ref(before),
        'proposal': proposal, 'complete_diff': complete_diff})

path = 'crates/ep_runtime/src/heat_balance/source_initialization/run_prefix.rs'
text = replace((ROOT / path).read_text(encoding='utf-8'),
    '//! Reached RunSimulation213-241 prefix, before the sole weather owner moves.',
    '//! Reached RunSimulation213-267 prefix, before the sole weather owner moves.')
text = replace(text, '    /// Run actual213-241 on the same reached owners after both real init guards.',
    '    /// Run actual213-267 on the same reached owners after both real init guards.')
text = replace(text, '''        self.heat_balance_space_controls.current = self.heat_balance_space_controls.simulation;
        Ok(())''', '''        self.heat_balance_space_controls.current = self.heat_balance_space_controls.simulation;

        // Actual243-247 consumes input switches, not calculation-ready flags.
        if (globals.do_zone_sizing || globals.do_system_sizing || globals.do_plant_sizing)
            && !(weather.global.do_des_day_sim
                || (weather.global.do_weath_sim && startup.run_periods_in_input))
        {
            backend.show_warning_error("ManageSimulation: Input file has requested Sizing Calculations but no Simulations are requested (in SimulationControl object). Succeeding warnings/errors may be confusing.")
                .map_err(|e| failure("RunSimulation warning245", e))?;
        }
        // Retain the real249 caller local, including a later actual fatal.
        self.source_run_available = Some(true);
        if globals.do_pure_load_calc {
            // Real GetProjectData1187 requires Zone/SystemSizing for true;
            // the selected234 domain rejects those switches before this point.
            // Do not fabricate its unported WriteTabularFiles254 owner/route.
            return Err(SourceInitializationError::Association(
                "positive DoPureLoadCalc251 requires the sizing/tabular caller",
            ));
        }
        if self.selected_branches.invalid_branch_definitions {
            return match backend.show_fatal_error("Preceding error(s) in Branch Input cause termination.") {
                Ok(never) => match never {},
                Err(stop) => Err(failure("BranchInput fatal258", stop)),
            };
        }
        backend.display_string("Adjusting Air System Sizing")
            .map_err(|e| failure("DisplayString261", e))?;
        self.selected_sizing_manager.manage_system_sizing_adjustments(globals)
            .map_err(|e| failure("ManageSystemSizingAdjustments262", e))?;
        backend.display_string("Adjusting Standard 62.1 Ventilation Sizing")
            .map_err(|e| failure("DisplayString264", e))?;
        self.selected_sizing_manager.manage_system_ventilation_adjustments(&startup.hvac_globals)
            .map_err(|e| failure("ManageSystemVentilationAdjustments265", e))?;
        backend.display_string("Initializing Simulation")
            .map_err(|e| failure("DisplayString267", e))?;
        // Stop before actual KickOffSimulation268, ResetEnvironmentCounter270
        // and SetupSimulation272. No completion/readiness flag substitutes.
        Ok(())''')
emit(path, text)

path = 'crates/ep_runtime/src/heat_balance/selected_simulation_startup.rs'
text = replace((ROOT / path).read_text(encoding='utf-8'),
    '''pub(crate) struct SelectedHvacGlobals {
    pub(crate) time_step_sys: f64,''',
    '''pub(crate) struct SelectedHvacGlobals {
    /// DataHVACGlobals507 constructor; not DataSizing/NumAirLoops or a raw recount.
    pub(crate) number_of_primary_air_systems: i32,
    pub(crate) time_step_sys: f64,''')
text = replace(text, '''impl Default for SelectedHvacGlobals {
    fn default() -> Self {
        Self {
            time_step_sys: 0.0,''', '''impl Default for SelectedHvacGlobals {
    fn default() -> Self {
        Self {
            number_of_primary_air_systems: 0,
            time_step_sys: 0.0,''')
emit(path, text)

path = 'crates/ep_runtime/src/heat_balance/selected_sizing.rs'
text = replace((ROOT / path).read_text(encoding='utf-8'),
    'use super::selected_heat_balance_globals::SelectedHeatBalanceGlobals;',
    'use super::selected_heat_balance_globals::SelectedHeatBalanceGlobals;\nuse super::selected_simulation_startup::SelectedHvacGlobals;')
text += '''
impl SelectedSizingManager {
    /// Actual770-1207 has only a reference alias outside this literal predicate.
    /// The unentered positive body performs zone equipment and sizing/report work.
    pub(crate) fn manage_system_sizing_adjustments(
        &self,
        globals: &SelectedHeatBalanceGlobals,
    ) -> Result<(), SelectedSizingError> {
        if self.number_of_system_sizing_input > 0 && globals.do_system_sizing {
            return Err(SelectedSizingError::Unavailable(
                "positive ManageSystemSizingAdjustments body",
            ));
        }
        Ok(())
    }

    /// Actual1209-2023 has four reference aliases and two NumPrimaryAirSys loops.
    /// Count0 executes no numeric, equipment or predefined-table write at all.
    pub(crate) fn manage_system_ventilation_adjustments(
        &self,
        hvac: &SelectedHvacGlobals,
    ) -> Result<(), SelectedSizingError> {
        if hvac.number_of_primary_air_systems != 0 {
            return Err(SelectedSizingError::Unavailable(
                "nonzero ManageSystemVentilationAdjustments primary-air-system domain",
            ));
        }
        Ok(())
    }
}
'''
emit(path, text)

path = 'crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs'
text = replace((ROOT / path).read_text(encoding='utf-8'),
    '''    pub setup_simulation_registry_prepared: bool,
    /// Sole actual raw/schema input owner,''',
    '''    pub setup_simulation_registry_prepared: bool,
    /// Actual RunSimulation249 local, None before that assignment is reached.
    /// Retained across a later error; this is not weather/Setup readiness.
    pub source_run_available: Option<bool>,
    /// Sole actual raw/schema input owner,''')
emit(path, text)

path = 'crates/ep_run/src/ctf_initialization_outputs.rs'
text = replace((ROOT / path).read_text(encoding='utf-8'),
    '''        success.initialize_source_run_prefix(&ep_model::ReportInputs::default())?;
        assert!(success.reports.setup_simulation_registry_prepared);''',
    '''        success.initialize_source_run_prefix(&ep_model::ReportInputs::default())?;
        assert_eq!(success.reports.source_run_available, Some(true));
        let expected_progress = [
            "Adjusting Air System Sizing",
            "Adjusting Standard 62.1 Ventilation Sizing",
            "Initializing Simulation",
        ];
        let progress = String::from_utf8(success.console.clone())?;
        let reached_progress = progress.lines()
            .filter(|line| expected_progress.contains(line)).collect::<Vec<_>>();
        assert_eq!(reached_progress, expected_progress.to_vec());
        assert!(!success.state.kickoff_simulation);
        assert!(success.reports.setup_simulation_registry_prepared);''')
emit(path, text)

ranges = []
for name, lo, hi in [
    ('SimulationManager.cc', 232, 272), ('SimulationManager.cc', 1181, 1193),
    ('SizingManager.cc', 770, 1207), ('SizingManager.cc', 1209, 2023),
    ('SizingManager.cc', 3484, 3512), ('DataSizing.hh', 1238, 1250),
    ('DataHVACGlobals.hh', 491, 511), ('SimAirServingZones.cc', 185, 207),
    ('SimAirServingZones.cc', 383, 410), ('BranchInputManager.hh', 300, 318),
]:
    relative = 'src/EnergyPlus/' + name
    source = ORIGINAL / relative
    actual = source.read_bytes()
    git = subprocess.run(['git', '-C', str(ORIGINAL), 'show', COMMIT + ':' + relative], capture_output=True, check=True).stdout
    assert actual == git, relative
    literal = UNIT / 'Original' / (name + '.' + str(lo) + '-' + str(hi) + '.txt')
    literal.parent.mkdir(parents=True, exist_ok=True)
    literal.write_bytes(b''.join(actual.splitlines(keepends=True)[lo - 1:hi]))
    ranges.append({'Original_path': relative, 'first_line': lo, 'last_line': hi,
        'full_Original_source': ref(source), 'literal': ref(literal)})

# Finite lexical enclosure proof only: omitted positive numerical bodies are not
# claimed implemented. Strip comments/literals without changing line positions.
source = (ORIGINAL / 'src/EnergyPlus/SizingManager.cc').read_text(encoding='utf-8')
stripped = re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',
    lambda m: ''.join('\n' if c == '\n' else ' ' for c in m.group()), source, flags=re.S)
lines = stripped.splitlines()
closure = []
for first, last, expected in [
    (770, 1207, [781, 783, 1207]),
    (1209, 2023, [1211, 1212, 1213, 1214, 1219, 1455, 2023]),
]:
    depth = 0
    outer = []
    for number in range(first, last + 1):
        line = lines[number - 1]
        if depth == 1 and line.strip():
            outer.append(number)
        depth += line.count('{') - line.count('}')
    assert depth == 0
    assert outer == expected, outer
    closure.append({'first_line': first, 'last_line': last,
        'all_outer_depth_nonempty_line_numbers': outer,
        'outer_lines': [(n, source.splitlines()[n - 1]) for n in outer]})
closure_ref = write(UNIT / 'selected-no-work-closure.json', json.dumps({
    'schema': 'src06-run-prefix-selected-adjustment-enclosure-proof.v1',
    'Original_commit': COMMIT, 'complete_functions': closure,
    'numeric_or_report_body_computed': False,
    'NumPrimaryAirSys_authority': 'sole DataHVACGlobals constructor507; GetAirPathData389 has not been called',
    'NumAirLoops_is_not_NumPrimaryAirSys': True,
}, indent=2) + '\n')

readme = '''# Held RunSimulation checks before kickoff

Five focused proposals extend the already consumed actual213-241 prefix to267 on clean commit ac15758c. No new entrypoint or callback is required: the existing ep_run caller still invokes the same method before the sole initialized weather owner moves. No KickOffSimulation268, ResetEnvironmentCounter270, SetupSimulation272, HB allocation, phase or Space/global copy is added.

The exact243 warning condition consumes actual input sizing switches, real weather run flags and the sole startup RunPeriodsInInput. Real backend warning failures retain their prior counters/output. The actual249 local Available is retained as source_run_available, initially None and assigned Some(true) only at its reached line; it is neither a readiness flag nor a replacement weather selection. BranchInput257 reads the actual existing invalid_branch_definitions and invokes genuine ShowFatalError258 with its exact message. The actual typed fatal stop and Available prefix remain retained. The three literal DisplayString261/264/267 operations use the existing real backend in exact order, including callbacks, console guards and write/flush errors.

The selected ManageSizing234 domain already rejects Zone/System/Plant/HVAC sizing switches. GetProjectData1187-1189 can set DoPureLoadCalc only when Zone/SystemSizing is true and simulation flags are false, so a successful selected234 reaches251 false. The true251 sizing/tabular route is explicitly unavailable at that boundary, before any fabricated WriteTabularFiles owner or completion. It is not silently treated as the supported false branch. Existing positive sizing exclusion remains unchanged.

ManageSystemSizingAdjustments770-1207 has one reference alias and its complete effectful body under NumSysSizInput>0 && DoSystemSizing. The implementation consumes the sole existing sizing count and same actual globals. ManageSystemVentilationAdjustments1209-2023 has four reference aliases and precisely two NumPrimaryAirSys loops (1219,1455), including all eight predefined-table reports. Its actual constructor0 field is added to the existing sole HVAC owner; it is not derived from the distinct SizingManager.NumAirLoops or from raw object counts. The genuine GetAirPathData389 writer is not reached before this supported no-sizing boundary. No equipment call, numeric operation or report entry runs in either admitted empty body. Nonzero primary-air-system or active system-sizing branches stop explicitly; positive numerical bodies remain unported. selected-no-work-closure.json records the complete Git-pinned function enclosures, not numerical execution or parity.

One existing ep_run fatal-prefix test body is extended to check all three actual progress strings in order, reached Available and absence of a kickoff write. Its existing guard/error/file/reentry assertions are preserved. No new test functions/binaries or synthetic Native fixtures are introduced. A malformed positive Branch cannot reach257 through the current selected zero-branch public producer without failing earlier, so this packet does not add a fake setter or claim that fatal branch was executed. It is retained and reviewed directly against Source. No tests, compiler, Cargo, engine, canonical edits or gates were executed/changed by this preparation.
'''
readme_ref = write(UNIT / 'README.md', readme)
manifest = {'schema': 'src06-run-prefix-checks-Source-preparation.v1',
    'status': 'HELD Source-only, no canonical application or execution',
    'actual_HEAD': HEAD, 'actual_parent_assembly': ref(PARENT),
    'files': files, 'Original_commit': COMMIT, 'Original_ranges': ranges,
    'selected_no_work_closure': closure_ref,
    'existing_reached_sizing_and_Project_domains': [
        ref(ROOT / 'crates/ep_runtime/src/heat_balance/selected_sizing.rs'),
        ref(ROOT / 'crates/ep_runtime/src/heat_balance/selected_project_data/getter.rs')],
    'actual_backend': ref(ROOT / 'crates/ep_runtime/src/heat_balance/error_backend.rs'),
    'same_early_caller': ref(ROOT / 'crates/ep_run/src/pipeline.rs'),
    'author': ref(pathlib.Path(__file__)), 'README': readme_ref,
    'first_Original_line': 243, 'last_Original_line': 267,
    'KickOff_ResetEnvironmentCounter_Setup_or_full_RunSimulation_claim': False,
    'existing_test_bodies_extended': 1, 'new_test_functions_or_binaries': 0,
    'canonical_Cargo_Native_or_targets_executed': False, 'gates_PASS': False}
for row in files:
    before = (ROOT / row['before']['path']).read_text(encoding='utf-8')
    after = (ROOT / row['proposal']['path']).read_text(encoding='utf-8')
    expected = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='ac15758c/' + row['canonical_path'], tofile='held/' + row['canonical_path']))
    assert (ROOT / row['complete_diff']['path']).read_text(encoding='utf-8') == expected
manifest_path = UNIT / 'manifest.json'
write(manifest_path, json.dumps(manifest, indent=2) + '\n')
print(json.dumps(ref(manifest_path)))

use super::super::error_backend::{SourceErrorState, SourceErrorTracking};
use super::super::surface_manager::ctf_layer_preprocessing::{
    CtfLayerContext, CtfLayerFailure, CtfLayerInput, try_preprocess_ctf_layers,
};
use super::*;
use ep_model::MaterialId;

fn state() -> SourceErrorState {
    SourceErrorState {
        output_error_header: false,
        version_string: "actual authored version".into(),
        idd_version_string: "actual authored IDD".into(),
        doing_input_processing: false,
        print_console_output: true,
        kickoff_simulation: false,
        developer_flag: false,
        warmup_flag: false,
        doing_sizing: false,
        tracking: SourceErrorTracking {
            ask_for_surfaces_report: false,
            total_multiplied_windows: 0,
            total_coincident_vertices: 0,
            total_degenerate_surfaces: 0,
            total_receiving_non_convex_surfaces: 0,
            total_casting_non_convex_surfaces: 0,
            match_counts: [0; 20],
            abort_processing: false,
            total_severe_errors: 0,
            total_severe_errors_during_warmup: 0,
            total_severe_errors_during_sizing: 0,
            last_severe_error: "prior".into(),
            total_warning_errors: 0,
            total_warning_errors_during_warmup: 0,
            total_warning_errors_during_sizing: 0,
        },
    }
}

fn backend<'a>(
    state: &'a mut SourceErrorState,
    error: &'a mut Vec<u8>,
    console: &'a mut Vec<u8>,
) -> SourceErrorBackend<'a> {
    SourceErrorBackend {
        state,
        error_stream: Some(error),
        console,
        out_unit1: None,
        out_unit2: None,
        f_message: None,
        message_callback: None,
        error_callback: None,
        sqlite: None,
    }
}

#[test]
fn round_three_preserves_fixed_threshold_nudges_zero_and_padded_exponents()
-> Result<(), CtfSourceDiagnosticStop> {
    for (input, expected) in [
        (0.001, "1.000E-003"),
        (0.0004, "4.000E-004"),
        (0.0, "0.000"),
        (-0.0, "0.000"),
        (1.2345, "1.235"),
        (-1.2345, "-1.235"),
    ] {
        assert_eq!(source_round_three(input)?, expected);
    }
    let threshold = f64::from_bits(0x3fb9999999999999);
    assert_eq!(source_round_three(threshold)?, "0.100");
    assert_eq!(
        source_round_three(f64::from_bits(threshold.to_bits() - 1))?,
        "1.000E-001"
    );
    assert_eq!(source_next_float(-0.0).to_bits(), (-0.0_f64).to_bits());
    assert_eq!(source_next_float(f64::MIN).to_bits(), f64::MIN.to_bits());
    assert_eq!(source_next_float(f64::MAX).to_bits(), f64::MAX.to_bits());
    Ok(())
}

#[test]
fn real_loading_calls_reach_backend_and_return_error_flag_only_after_continue()
-> Result<(), Box<dyn std::error::Error>> {
    let mut state = state();
    let mut error = Vec::new();
    let mut console = Vec::new();
    let input = CtfLayerInput {
        material_id: MaterialId(4),
        thickness: 0.0,
        conductivity: 0.0,
        density: 0.0,
        specific_heat: 0.0,
        resistance: -0.0,
        resistance_only: true,
    };
    let result = {
        let mut actual = backend(&mut state, &mut error, &mut console);
        try_preprocess_ctf_layers(
            &[input],
            CtfLayerContext {
                is_used_ctf: true,
                errors_found: false,
                source_sink_present: false,
                solution_dimensions: 1,
            },
            |call| emit_ctf_loading_diagnostic(&mut actual, &["ORIGINAL MATERIAL"], call),
        )
    };
    assert!(
        matches!(result, Ok(value) if value.errors_found && value.after_load.is_some()
        && value.after_merge.is_none() && value.after_conversion.is_none())
    );
    assert_eq!(state.tracking.total_severe_errors, 1);
    assert_eq!(
        state.tracking.last_severe_error,
        "InitConductionTransferFunctions: Material=ORIGINAL MATERIALR Value below lowest allowed value"
    );
    assert!(String::from_utf8(error)?.ends_with(
        "   **   ~~~   ** Lowest allowed value=[1.000E-003], Material R Value=[0.000].\n"
    ));
    assert!(console.is_empty());
    Ok(())
}

#[test]
fn missing_reached_material_name_keeps_the_earlier_real_severe_prefix()
-> Result<(), Box<dyn std::error::Error>> {
    let mut state = state();
    let mut error = Vec::new();
    let mut console = Vec::new();
    let input = CtfLayerInput {
        material_id: MaterialId(4),
        thickness: 4.0,
        conductivity: 1.0,
        density: 1.0,
        specific_heat: 1.0,
        resistance: 4.0,
        resistance_only: false,
    };
    let result = {
        let mut actual = backend(&mut state, &mut error, &mut console);
        try_preprocess_ctf_layers(
            &[input],
            CtfLayerContext {
                is_used_ctf: true,
                errors_found: false,
                source_sink_present: false,
                solution_dimensions: 1,
            },
            |call| emit_ctf_loading_diagnostic(&mut actual, &[], call),
        )
    };
    assert!(matches!(
        result,
        Err(CtfLayerFailure::Diagnostic(
            CtfSourceDiagnosticStop::Unavailable(
                CtfSourceDiagnosticUnavailable::OriginalLayerName(1)
            )
        ))
    ));
    assert_eq!(state.tracking.total_severe_errors, 1);
    assert_eq!(
        String::from_utf8(error)?,
        "   ** Severe  ** InitConductionTransferFunctions: Material too thick for CTF calculation\n"
    );
    Ok(())
}

#[test]
fn caller_fatal_dispatch_runs_backend_and_cannot_return_success()
-> Result<(), Box<dyn std::error::Error>> {
    let mut state = state();
    let mut error = Vec::new();
    let mut console = Vec::new();
    {
        let mut actual = backend(&mut state, &mut error, &mut console);
        let result = emit_ctf_caller_diagnostic(
            &mut actual,
            &CtfCallerDiagnostic {
                level: CtfCallerDiagnosticLevel::Fatal,
                message: "selected fatal".into(),
            },
        );
        assert!(matches!(
            result,
            Err(CtfSourceDiagnosticStop::Fatal(SourceFatalStop::Fatal(_)))
        ));
    }
    assert_eq!(console, b"**FATAL:selected fatal\n");
    assert!(String::from_utf8(error)?.contains("Reference severe error count=0"));
    assert_eq!(state.tracking.total_severe_errors, 0);
    Ok(())
}

//! Fixed input-only selected calls; every stop retains the same caller's owners.
#![recursion_limit = "256"]
#[path = "../../ep_runtime/examples/clk02_probe_support/digest.rs"]
mod digest;

use ep_model::Terrain;
use ep_runtime::heat_balance::convection::surface_environment::{
    SurfaceOutdoorEnvironmentError, SurfaceOutdoorEnvironmentParameters,
    SurfaceOutdoorEnvironmentRow, SurfaceOutdoorWeather, check_surface_out_bulb_temperatures,
    set_surface_out_bulb_temperatures, set_surface_wind_directions, set_surface_wind_speeds,
};
use ep_runtime::heat_balance::error_backend::{
    SourceErrorBackend, SourceErrorBackendFailure, SourceErrorLevel, SourceErrorState,
    SourceErrorTracking, SourceFatalStop,
};
use serde_json::{Value, json};
use std::cell::RefCell;
use std::collections::BTreeSet;
use std::io::{self, Write};
use std::rc::Rc;

type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
const INPUT_SHA256: &str = "0d1264f8802347055e90635a4ae5e754280c7fcfa8fef35595f1db6589511734";
const INPUT_SIZE: usize = 102723;
const UNAVAILABLE: [&str; 9] = [
    "Native fresh EnergyPlusData/InitConstantState constructor and absent-object getter calls",
    "Native ErrorsFound and CurrentDateTime owners absent from the selected Rust types",
    "Native ostream good/bad/fail flags and exception text; Rust typed IO cause retained separately",
    "Native streambuf write-attempt count versus Rust Write fragmentation",
    "Objexx/EPVector allocation implementation versus Vec allocation",
    "Native inner call/row trace without callbacks; only actual public-call boundaries retained",
    "ordinary manager/Raw admission/physical handoff, SQLite and optional output/fMessagePtr effects",
    "generated nonfinite arithmetic and unrepresented FP exception environment never counted as PASS",
    "Native initial environmental weather constructor values before the first declared weather write",
];

fn require(ok: bool, message: &str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(message.to_owned().into())
    }
}
fn keys(v: &Value, names: &[&str]) -> Result<()> {
    require(
        v.as_object().is_some_and(|o| {
            o.len() == names.len() && names.iter().all(|name| o.contains_key(*name))
        }),
        "exact literal input object required",
    )
}
fn rows(v: &Value) -> Result<&[Value]> {
    v.as_array()
        .map(Vec::as_slice)
        .ok_or_else(|| "array input required".into())
}
fn text(v: &Value) -> Result<&str> {
    v.as_str().ok_or_else(|| "string input required".into())
}
fn boolean(v: &Value) -> Result<bool> {
    v.as_bool().ok_or_else(|| "boolean input required".into())
}
fn counter(v: &Value) -> Result<i32> {
    let n = v.as_i64().ok_or("bounded signed input counter required")?;
    require(
        (0..=1_000_000).contains(&n),
        "defined bounded counter domain required",
    )?;
    Ok(i32::try_from(n)?)
}
fn real(v: &Value, nan_allowed: bool) -> Result<f64> {
    keys(v, &["bits"])?;
    let bits = text(&v["bits"])?;
    require(
        bits.len() == 16
            && bits
                .bytes()
                .all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c)),
        "canonical sixteen lowercase hex digits required",
    )?;
    let raw = u64::from_str_radix(bits, 16)?;
    let number = f64::from_bits(raw);
    require(
        number.is_finite() || (nan_allowed && number.is_nan() && raw & 0x0008_0000_0000_0000 != 0),
        "finite or explicitly allowed quiet NaN literal required",
    )?;
    Ok(number)
}
fn scalar(v: f64) -> Value {
    let class = if v.is_nan() {
        "nan"
    } else if v.is_infinite() {
        if v.is_sign_negative() {
            "negative_infinity"
        } else {
            "positive_infinity"
        }
    } else if v == 0.0 {
        if v.is_sign_negative() {
            "negative_zero"
        } else {
            "positive_zero"
        }
    } else {
        "finite"
    };
    json!({"value":if v.is_finite() { Some(v) } else { None },
        "value_bits":format!("{:016x}",v.to_bits()),"value_class":class})
}

// A real Rust Write sink. Partial bytes and the real typed IO failure are retained;
// Native ostream exception/fragmentation state is explicitly unrepresented.
struct ErrorSink {
    bytes: Vec<u8>,
    limit: Option<usize>,
    appended: usize,
    attempts: usize,
    failed: bool,
}
impl Write for ErrorSink {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.attempts += 1;
        let available = self
            .limit
            .map_or(bytes.len(), |limit| limit.saturating_sub(self.appended));
        if available == 0 && !bytes.is_empty() {
            self.failed = true;
            return Err(io::Error::new(
                io::ErrorKind::BrokenPipe,
                "declared cold-guard error byte budget exhausted",
            ));
        }
        let accepted = bytes.len().min(available);
        self.bytes.extend_from_slice(&bytes[..accepted]);
        self.appended += accepted;
        Ok(accepted)
    }
    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}
struct Fixture {
    names: Vec<String>,
    rows: Vec<SurfaceOutdoorEnvironmentRow>,
    parameters: SurfaceOutdoorEnvironmentParameters,
    weather: SurfaceOutdoorWeather,
    weather_assigned: bool,
    state: SourceErrorState,
    error: ErrorSink,
    error_present: bool,
    console: Vec<u8>,
    eio: Vec<u8>,
    callbacks: Rc<RefCell<Vec<Value>>>,
    stopped: bool,
}
impl Fixture {
    fn new(v: &Value) -> Result<(Self, Value)> {
        keys(
            v,
            &[
                "site_parameters",
                "backend_flags",
                "backend_state",
                "streams",
                "surfaces",
            ],
        )?;
        let p = &v["site_parameters"];
        keys(
            p,
            &[
                "Terrain_source_label",
                "SiteWindExp",
                "SiteWindBLHeight",
                "SiteTempGradient_override",
                "WeatherFileTempModCoeff_override",
                "WeatherFileWindModCoeff_override",
            ],
        )?;
        text(&p["Terrain_source_label"])?;
        // Constructor operands precede the selected absent-object producers.
        // Literal incoming site wind owners are assigned before either call.
        let mut parameters =
            SurfaceOutdoorEnvironmentParameters::for_building_terrain(Terrain::Suburbs);
        parameters.site_wind_exponent = real(&p["SiteWindExp"], false)?;
        parameters.site_wind_boundary_layer_height_m = real(&p["SiteWindBLHeight"], false)?;
        require(
            parameters.site_wind_exponent >= 0.0
                && parameters.site_wind_boundary_layer_height_m > 0.0,
            "nonnegative wind exponent and positive boundary layer required",
        )?;
        let b = &v["backend_flags"];
        keys(
            b,
            &[
                "WarmupFlag",
                "DoingSizing",
                "KickOffSimulation",
                "DoingInputProcessing",
                "printConsoleOutput",
                "DeveloperFlag",
            ],
        )?;
        let t = &v["backend_state"];
        keys(
            t,
            &[
                "TotalSevereErrors",
                "TotalWarningErrors",
                "TotalSevereErrorsDuringWarmup",
                "TotalWarningErrorsDuringWarmup",
                "TotalSevereErrorsDuringSizing",
                "TotalWarningErrorsDuringSizing",
                "AbortProcessing",
                "LastSevereError",
                "MatchCounts",
                "outputErrorHeader",
                "VerStringVar",
                "IDDVerString",
            ],
        )?;
        let counts = rows(&t["MatchCounts"])?;
        require(
            counts.len() == 20,
            "all twenty literal match counters required",
        )?;
        let mut match_counts = [0; 20];
        for (owner, value) in match_counts.iter_mut().zip(counts) {
            *owner = counter(value)?;
        }
        let state = SourceErrorState {
            output_error_header: boolean(&t["outputErrorHeader"])?,
            version_string: text(&t["VerStringVar"])?.into(),
            idd_version_string: text(&t["IDDVerString"])?.into(),
            doing_input_processing: boolean(&b["DoingInputProcessing"])?,
            print_console_output: boolean(&b["printConsoleOutput"])?,
            kickoff_simulation: boolean(&b["KickOffSimulation"])?,
            developer_flag: boolean(&b["DeveloperFlag"])?,
            warmup_flag: boolean(&b["WarmupFlag"])?,
            doing_sizing: boolean(&b["DoingSizing"])?,
            tracking: SourceErrorTracking {
                ask_for_plant_check_on_abort: false,
                ask_for_surfaces_report: false,
                total_multiplied_windows: 0,
                total_coincident_vertices: 0,
                total_degenerate_surfaces: 0,
                total_receiving_non_convex_surfaces: 0,
                total_casting_non_convex_surfaces: 0,
                match_counts,
                abort_processing: boolean(&t["AbortProcessing"])?,
                total_severe_errors: counter(&t["TotalSevereErrors"])?,
                total_warning_errors: counter(&t["TotalWarningErrors"])?,
                total_severe_errors_during_warmup: counter(&t["TotalSevereErrorsDuringWarmup"])?,
                total_warning_errors_during_warmup: counter(&t["TotalWarningErrorsDuringWarmup"])?,
                total_severe_errors_during_sizing: counter(&t["TotalSevereErrorsDuringSizing"])?,
                total_warning_errors_during_sizing: counter(&t["TotalWarningErrorsDuringSizing"])?,
                last_severe_error: text(&t["LastSevereError"])?.into(),
            },
        };
        let streams = &v["streams"];
        keys(
            streams,
            &[
                "error_present",
                "error_seed",
                "eio_seed",
                "console_seed",
                "error_byte_budget_after_seed",
            ],
        )?;
        let error_present = boolean(&streams["error_present"])?;
        let seed = text(&streams["error_seed"])?;
        let limit = if streams["error_byte_budget_after_seed"].is_null() {
            None
        } else {
            Some(usize::try_from(counter(
                &streams["error_byte_budget_after_seed"],
            )?)?)
        };
        require(
            error_present || (seed.is_empty() && limit.is_none()),
            "absent error sink has no seed or budget",
        )?;
        let mut names = Vec::new();
        let mut owned = Vec::new();
        let mut unique = BTreeSet::new();
        for (i, r) in rows(&v["surfaces"])?.iter().enumerate() {
            keys(
                r,
                &[
                    "actual_surface_index",
                    "Name",
                    "Centroid_z",
                    "ExtWind",
                    "SurfOutDryBulbTemp",
                    "SurfOutWetBulbTemp",
                    "SurfOutWindSpeed",
                    "SurfOutWindDir",
                ],
            )?;
            require(
                r["actual_surface_index"].as_u64() == Some(u64::try_from(i + 1)?),
                "complete contiguous input index/order required",
            )?;
            let name = text(&r["Name"])?;
            require(
                !name.is_empty() && unique.insert(name.to_owned()),
                "unique nonempty surface names required",
            )?;
            names.push(name.into());
            owned.push(SurfaceOutdoorEnvironmentRow {
                centroid_height_m: real(&r["Centroid_z"], false)?,
                wind_exposed: boolean(&r["ExtWind"])?,
                dry_bulb_c: real(&r["SurfOutDryBulbTemp"], true)?,
                wet_bulb_c: real(&r["SurfOutWetBulbTemp"], true)?,
                wind_speed_m_per_s: real(&r["SurfOutWindSpeed"], true)?,
                wind_direction_deg: real(&r["SurfOutWindDir"], true)?,
            });
        }
        // This input-only lane admits absent site/station objects. Both real
        // producers append to this caller's seeded EIO before literal overrides.
        let mut eio = text(&streams["eio_seed"])?.as_bytes().to_vec();
        parameters.initialize_absent_site_height_variation(&mut eio)?;
        parameters.initialize_absent_weather_station(&mut eio)?;
        let actual_defaults = parameter_snapshot(parameters);
        for (name, owner) in [
            (
                "SiteTempGradient_override",
                &mut parameters.site_temperature_gradient_k_per_m,
            ),
            (
                "WeatherFileTempModCoeff_override",
                &mut parameters.weather_file_temperature_modifier_c,
            ),
            (
                "WeatherFileWindModCoeff_override",
                &mut parameters.weather_file_wind_modifier,
            ),
        ] {
            if !p[name].is_null() {
                *owner = real(&p[name], false)?;
            }
        }
        Ok((
            Self {
                names,
                rows: owned,
                parameters,
                weather: SurfaceOutdoorWeather {
                    dry_bulb_c: 0.0,
                    wet_bulb_c: 0.0,
                    wind_speed_m_per_s: 0.0,
                    wind_direction_deg: 0.0,
                },
                weather_assigned: false,
                state,
                error: ErrorSink {
                    bytes: seed.as_bytes().to_vec(),
                    limit,
                    appended: 0,
                    attempts: 0,
                    failed: false,
                },
                error_present,
                console: text(&streams["console_seed"])?.as_bytes().to_vec(),
                eio,
                callbacks: Rc::new(RefCell::new(Vec::new())),
                stopped: false,
            },
            Value::Object(actual_defaults),
        ))
    }
    fn snapshot(&self) -> Value {
        let s = &self.state;
        let t = &s.tracking;
        let arrays = |get: fn(&SurfaceOutdoorEnvironmentRow) -> f64| {
            json!({"container":"Vec<SurfaceOutdoorEnvironmentRow>",
            "allocated":true,"size":self.rows.len(),"rows":self.rows.iter().enumerate().map(|(i,r)|
                json!({"actual_array_index":i+1,"value":scalar(get(r))})).collect::<Vec<_>>()})
        };
        json!({"owner":{"TotSurfaces":self.rows.len(),"Surface":{"allocated":true,"size":self.rows.len(),
            "rows":self.rows.iter().zip(&self.names).enumerate().map(|(i,(r,name))|json!({"actual_surface_index":i+1,
                "Name":name,"Centroid_z":scalar(r.centroid_height_m),"ExtWind":r.wind_exposed})).collect::<Vec<_>>()},
            "SurfOutDryBulbTemp":arrays(|r|r.dry_bulb_c),"SurfOutWetBulbTemp":arrays(|r|r.wet_bulb_c),
            "SurfOutWindSpeed":arrays(|r|r.wind_speed_m_per_s),"SurfOutWindDir":arrays(|r|r.wind_direction_deg),
            "environment":environment_snapshot(self.parameters,self.weather),"weather_operands_assigned":self.weather_assigned,
            "backend":{"TotalWarningErrors":t.total_warning_errors,"TotalSevereErrors":t.total_severe_errors,
                "TotalWarningErrorsDuringWarmup":t.total_warning_errors_during_warmup,"TotalSevereErrorsDuringWarmup":t.total_severe_errors_during_warmup,
                "TotalWarningErrorsDuringSizing":t.total_warning_errors_during_sizing,"TotalSevereErrorsDuringSizing":t.total_severe_errors_during_sizing,
                "LastSevereError":t.last_severe_error,"AbortProcessing":t.abort_processing,"MatchCounts":t.match_counts,
                "outputErrorHeader":s.output_error_header,"DoingInputProcessing":s.doing_input_processing,"printConsoleOutput":s.print_console_output,
                "DeveloperFlag":s.developer_flag,"errorCallback_present":true,"messageCallback_present":true,"fMessagePtr_present":false,"sqlite_present":false,
                "VerStringVar":s.version_string,"IDDVerString":s.idd_version_string},
            "backend_flags":{"WarmupFlag":s.warmup_flag,"DoingSizing":s.doing_sizing,"KickOffSimulation":s.kickoff_simulation}},
            "error_stream":self.error_present.then(||String::from_utf8_lossy(&self.error.bytes)),"error_stream_present":self.error_present,
            "error_stream_bytes":self.error_present.then_some(&self.error.bytes),"declared_error_stream_budget":self.error.limit,
            "actual_Rust_error_stream_write_attempts":self.error.attempts,"actual_error_stream_bytes_after_seed":self.error.appended,
            "actual_Rust_error_sink_failed":self.error.failed,"stream_text_projection":"UTF-8 lossy diagnostic view; complete raw byte arrays authoritative",
            "eio":String::from_utf8_lossy(&self.eio),"console":String::from_utf8_lossy(&self.console),
            "eio_bytes":self.eio,"console_bytes":self.console,"callbacks":&*self.callbacks.borrow(),"actual_callback_count":self.callbacks.borrow().len()})
    }
    fn guard(&mut self) -> std::result::Result<(), SurfaceOutdoorEnvironmentError> {
        let events = Rc::clone(&self.callbacks);
        let mut error_callback = move |_: &mut SourceErrorState,
                                       level: SourceErrorLevel,
                                       message: &str| {
            let mut v = events.borrow_mut();
            let ordinal = v.len() + 1;
            v.push(json!({"actual_ordinal":ordinal,"kind":"errorCallback","level":level as i32,"message":message}));
        };
        let events = Rc::clone(&self.callbacks);
        let mut message_callback = move |_: &mut SourceErrorState, message: &str| {
            let mut v = events.borrow_mut();
            let ordinal = v.len() + 1;
            v.push(json!({"actual_ordinal":ordinal,"kind":"messageCallback","level":null,"message":message}));
        };
        let mut backend = SourceErrorBackend {
            state: &mut self.state,
            error_stream: if self.error_present {
                Some(&mut self.error as &mut dyn Write)
            } else {
                None
            },
            console: &mut self.console,
            out_unit1: None,
            out_unit2: None,
            f_message: None,
            message_callback: Some(&mut message_callback),
            error_callback: Some(&mut error_callback),
            sqlite: None,
        };
        check_surface_out_bulb_temperatures(
            self.rows
                .iter()
                .zip(&self.names)
                .map(|(r, name)| (r, name.as_str())),
            &mut backend,
        )
    }
}
fn parameter_snapshot(p: SurfaceOutdoorEnvironmentParameters) -> serde_json::Map<String, Value> {
    serde_json::Map::from_iter([
        (
            "SiteTempGradient".into(),
            scalar(p.site_temperature_gradient_k_per_m),
        ),
        (
            "WeatherFileTempModCoeff".into(),
            scalar(p.weather_file_temperature_modifier_c),
        ),
        ("SiteWindExp".into(), scalar(p.site_wind_exponent)),
        (
            "SiteWindBLHeight".into(),
            scalar(p.site_wind_boundary_layer_height_m),
        ),
        (
            "WeatherFileWindModCoeff".into(),
            scalar(p.weather_file_wind_modifier),
        ),
    ])
}
fn environment_snapshot(p: SurfaceOutdoorEnvironmentParameters, w: SurfaceOutdoorWeather) -> Value {
    let mut map = parameter_snapshot(p);
    for (key, owner) in [
        ("OutDryBulbTemp", w.dry_bulb_c),
        ("OutWetBulbTemp", w.wet_bulb_c),
        ("WindSpeed", w.wind_speed_m_per_s),
        ("WindDir", w.wind_direction_deg),
    ] {
        map.insert(key.into(), scalar(owner));
    }
    Value::Object(map)
}
fn backend_failure(e: &SourceErrorBackendFailure) -> Value {
    match e {
        SourceErrorBackendFailure::Effect { operation, source } => {
            json!({"kind":"Rust_backend_IO_error","operation":operation,
            "io_kind":format!("{:?}",source.kind()),"raw_os_error":source.raw_os_error(),"message":source.to_string()})
        }
        SourceErrorBackendFailure::UndefinedCounterIncrement { counter } => {
            json!({"kind":"undefined_counter_increment","counter":counter})
        }
    }
}
fn stopped_cause(e: &SurfaceOutdoorEnvironmentError) -> Value {
    match e {
        SurfaceOutdoorEnvironmentError::Backend(e)
        | SurfaceOutdoorEnvironmentError::Fatal(SourceFatalStop::Backend(e)) => backend_failure(e),
        SurfaceOutdoorEnvironmentError::Fatal(SourceFatalStop::Fatal(e)) => {
            json!({"kind":"Rust_source_fatal","message":e.message})
        }
        SurfaceOutdoorEnvironmentError::Format(e) => {
            json!({"kind":"selected_format_unavailable","message":e})
        }
        SurfaceOutdoorEnvironmentError::Unavailable(e) => {
            json!({"kind":"selected_prerequisite_unavailable","message":e})
        }
    }
}
fn evaluate(item: &Value) -> Result<Value> {
    keys(
        item,
        &[
            "case_id",
            "purpose",
            "admission_lane",
            "initial",
            "operations",
        ],
    )?;
    text(&item["case_id"])?;
    text(&item["purpose"])?;
    let lane = text(&item["admission_lane"])?;
    require(
        matches!(
            lane,
            "manager-sequence-direct" | "incoming-array-cold-check-direct"
        ),
        "selected direct lane required",
    )?;
    let (mut f, defaults) = Fixture::new(&item["initial"])?;
    let prepared = f.snapshot();
    let mut calls = Vec::new();
    let mut boundaries = Vec::new();
    let mut unreached = Vec::new();
    let mut ids = BTreeSet::new();
    for op in rows(&item["operations"])? {
        keys(op, &["operation_id", "weather", "sequence"])?;
        let id = text(&op["operation_id"])?;
        require(ids.insert(id), "unique operation ID required")?;
        let sequence = rows(&op["sequence"])?;
        let expected = if lane == "manager-sequence-direct" {
            vec!["bulbs", "check", "wind_speed", "wind_direction"]
        } else {
            vec!["check"]
        };
        require(
            sequence.iter().map(text).collect::<Result<Vec<_>>>()? == expected,
            "exact admitted stage order required",
        )?;
        if f.stopped {
            unreached.push(op.clone());
            continue;
        }
        let w = &op["weather"];
        keys(
            w,
            &["OutDryBulbTemp", "OutWetBulbTemp", "WindSpeed", "WindDir"],
        )?;
        let before = f.snapshot();
        f.weather = SurfaceOutdoorWeather {
            dry_bulb_c: real(&w["OutDryBulbTemp"], true)?,
            wet_bulb_c: real(&w["OutWetBulbTemp"], true)?,
            wind_speed_m_per_s: real(&w["WindSpeed"], false)?,
            wind_direction_deg: real(&w["WindDir"], false)?,
        };
        f.weather_assigned = true;
        boundaries.push(json!({"literal_operation":op,"before_declared_weather_writes":before,"after_declared_weather_writes":f.snapshot()}));
        for stage in expected {
            if f.stopped {
                unreached.push(json!({"operation_id":id,"unreached_stage":stage}));
                continue;
            }
            let before = f.snapshot();
            let (api, result) = match stage {
                "bulbs" => {
                    set_surface_out_bulb_temperatures(f.parameters, f.weather, &mut f.rows);
                    ("set_surface_out_bulb_temperatures", Ok(()))
                }
                "check" => ("check_surface_out_bulb_temperatures", f.guard()),
                "wind_speed" => {
                    set_surface_wind_speeds(
                        f.parameters,
                        f.weather.wind_speed_m_per_s,
                        &mut f.rows,
                    );
                    ("set_surface_wind_speeds", Ok(()))
                }
                "wind_direction" => {
                    set_surface_wind_directions(f.weather.wind_direction_deg, &mut f.rows);
                    ("set_surface_wind_directions", Ok(()))
                }
                _ => return Err("unadmitted stage".into()),
            };
            f.stopped = result.is_err();
            calls.push(json!({"operation_id":id,"actual_call_ordinal":calls.len()+1,"stage":stage,"api":api,
                "actual_source_invoked":true,"actual_source_return_observed":result.is_ok(),"source_exception":result.as_ref().err().map(stopped_cause),
                "before":before,"after":f.snapshot()}));
        }
    }
    require(!ids.is_empty(), "full nonempty operation list required")?;
    Ok(
        json!({"case_id":item["case_id"],"literal_input":item,"Native_fresh_constructor_state":{"available":false,"counted_as_PASS":false},
        "actual_Rust_default_producer":{"api":"SurfaceOutdoorEnvironmentParameters::initialize_absent_weather_station","terrain":"Suburbs","actual_return":defaults},
        "prepared_state":prepared,"declared_weather_boundaries":boundaries,"actual_calls":calls,"unreached_operations_or_stages":unreached,
        "final":f.snapshot(),"actual_source_call_count":calls.len(),"actual_source_stopped":f.stopped,
        "unavailable_families":UNAVAILABLE,"ordinary_production_handoff_verified":false,"numerical_PASS_claimed":false}),
    )
}
fn run() -> Result<()> {
    let args = std::env::args_os().collect::<Vec<_>>();
    require(
        args.len() == 2,
        "usage: src05_surface_cold_guard_main <fixed-input-only-request.json>",
    )?;
    let bytes = std::fs::read(&args[1])?;
    require(
        bytes.len() == INPUT_SIZE && digest::sha256(&bytes) == INPUT_SHA256,
        "exact accepted input-only request bytes required",
    )?;
    let request: Value = serde_json::from_slice(&bytes)?;
    keys(
        &request,
        &[
            "schema",
            "expected_values_supplied",
            "ordinary_production_prestate_supplied",
            "cases",
        ],
    )?;
    require(
        request["schema"] == "src05-surface-cold-guard-direct-request.v1"
            && request["expected_values_supplied"] == false
            && request["ordinary_production_prestate_supplied"] == false,
        "unadmitted request schema or expected answer input",
    )?;
    let mut ids = BTreeSet::new();
    let mut cases = Vec::new();
    for item in rows(&request["cases"])? {
        require(
            ids.insert(text(&item["case_id"])?),
            "unique case ID required",
        )?;
        cases.push(evaluate(item)?);
    }
    require(cases.len() == 29, "all twenty-nine frozen cases required")?;
    require(
        std::fs::read(&args[1])? == bytes,
        "literal input changed during the selected calls",
    )?;
    let result = json!({"schema":"src05-surface-cold-guard-Rust-direct-results.v1","input":{"sha256":INPUT_SHA256,"size_bytes":bytes.len()},
        "cases":cases,"requested_case_count":29,"recorded_case_count":cases.len(),"expected_values_supplied":false,
        "scientific_PASS_claimed":false,"whole_SRC05_or_ordinary_PASS_claimed":false,"gates_updated":false});
    serde_json::to_writer(io::stdout().lock(), &result)?;
    println!();
    Ok(())
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("{error}");
            std::process::ExitCode::from(2)
        }
    }
}

"""Apply only the three reviewed and executed thermal weather Sources."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';WORK=BASE/'ordinary-provider-assembly-Root-67/workspace';OUT=BASE/'reviewed-thermal-weather-promotion-Root-04'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 b=(base/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert not OUT.exists() and not git('status','--porcelain=v1','-z')
head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip() and head.startswith('2fffe68f')
packet=BASE/'ordinary-thermal-resilience-weather-held-Reviewer-03/manifest.json';m=json.loads(packet.read_bytes());selected={row['canonical_path'] for row in m['files']};assert len(selected)==3
peer=BASE/'Audit-ordinary-provider-union67-Source-and-frontier-review-01/review.json';assert ref(peer)['sha256']=='2fa798c3621c514ad0dd9cfe20102e19d457786e31ea64466667ff051f74814b'
actual=[];snapshots=[]
for folder,exit_code in [('provider-assembly-through-primary-A-24H-command-67',6),('provider-assembly-all-target-check-67',0)]:
 p=WORK/'.runtime/porting/SRC-06'/folder/'receipt.json';r=json.loads(p.read_bytes());assert r['exit_code']==exit_code and r['source_bytes_match_before_and_after'];actual.append(ref(p));snapshots.append(read(r['source_snapshot'],WORK))
assert snapshots[0]==snapshots[1];index=json.loads(snapshots[0]);assert len(index['files'])==4413 and not index['bytes_normalized']
differences=set()
for row in index['files']:
 path=row['historical_path'];b=read(row['archive'],WORK);assert (WORK/path).read_bytes()==b;a=(ROOT/path).read_bytes() if(ROOT/path).exists() else b''
 if a!=b:differences.add(path)
assert differences==selected|{'crates/ep_run/src/pipeline.rs'}
pipeline=ref(ROOT/'crates/ep_run/src/pipeline.rs');assert git('show',head+':'+pipeline['path'])==read(pipeline)
OUT.mkdir();changes=[]
for row in m['files']:
 path=row['canonical_path'];p=ROOT/path;a=p.read_bytes() if p.exists() else b'';b=read(row['proposed']);assert (WORK/path).read_bytes()==b and b'\r\n'not in b and a.count(b'#[test]')==b.count(b'#[test]')
 exists=bool(git('ls-tree',head,'--',path));assert exists==p.exists()
 if exists:assert git('show',head+':'+path)==a
 before=OUT/'before'/path;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(a);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);changes.append(dict(path=path,before=ref(before),before_Git_exists=exists,after=ref(p)))
for row in index['files']:
 path=row['historical_path']
 if path!=pipeline['path']:assert (ROOT/path).read_bytes()==read(row['archive'],WORK)
assert read(pipeline)==git('show',head+':'+pipeline['path'])
v=dict(schema='src06-canonical-reviewed-thermal-weather-promotion.v1',status='Three exact reviewed Sources applied; commit/push pending',base_HEAD=head,packet=ref(packet),parent_assembly=ref(BASE/'ordinary-provider-assembly-Root-67/manifest.json'),independent_actual_peer=ref(peer),actual_commands=actual,changes=changes,compiler_inputs=4413,changed=3,new=1,existing=2,canonical_pipeline_unchanged=pipeline,new_test_bodies=0,full_suite_rerun=False,pipeline_activation=False,whole_Native_numeric_PASS=False,gate_changes=False,A='14/54',B='14/64',author_Source=ref(Path(__file__).resolve()))
p=OUT/'promotion.json';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

"""Publish actual primary completion and the unresolved exact output mismatch."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';WORK=BASE/'ordinary-provider-assembly-Root-67/workspace';PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-thermal-weather-04'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 b=(base/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
assert not PUBLIC.exists()
promotion=BASE/'reviewed-thermal-weather-promotion-Root-04/promotion.json';p=json.loads(promotion.read_bytes());assert ref(promotion)['sha256']=='0ad8805290f445348bca95cf8be5fbf1394052e82a27154384d0ce67190f60e5'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==p['base_HEAD']
for row in p['changes']:read(row['after']);read(row['before'])
read(p['canonical_pipeline_unchanged'])
payload={}
def add(q):
 q=q.resolve();b=q.read_bytes();key=q.relative_to(ROOT).as_posix();assert key not in payload or payload[key]==b;payload[key]=b;return ref(q)
def add_ref(r,base=ROOT):read(r,base);return add(base/r['path'])
add(promotion);add_ref(p['author_Source']);add(Path(__file__).resolve());add_ref(p['packet']);add_ref(p['parent_assembly']);add_ref(p['independent_actual_peer'])
actual=[]
for row in p['actual_commands']:
 r=json.loads(read(row));actual.append(add_ref(row))
 for key in ['stdout','stderr','source_snapshot']:add_ref(r[key],WORK)
comp=BASE/'ordinary-reported-artifact-comparison-Fix-67-01/comparison.json';c=json.loads(comp.read_bytes());assert ref(comp)['sha256']=='b588f76002198828e2954be25d84c4a5f3a87cc9a12176fa4bd9466279253721';add(comp)
comparison_peer=BASE/'Root-ordinary-reported-artifact-comparison-review-67-01/review.json';cp=json.loads(comparison_peer.read_bytes());assert ref(comparison_peer)['sha256']=='cf24a4e130b21e3e73d5281e55818fd018dbafec64e0a7949858b8cea5dc9d1a';add(comparison_peer);add_ref(cp['author_Source'])
for row in cp['artifacts']:add_ref(row)
for key in ['source_input','source_staged_input','native_version_stdout','post_command_native_exe_and_DLL_inventory','structure_and_footer_proof','reported_value_summary','all_uncapped_mismatches','author_Source']:add_ref(c[key])
for key in ['native_actual_receipt','native_actual_version_receipt']:
 r=json.loads(read(c[key]));assert r['exit_code']==0 and r['source_bytes_match_before_and_after'];add_ref(c[key])
 for role in ['stdout','stderr','source_snapshot']:add_ref(r[role])
thermal_peer=BASE/'Audit-ordinary-thermal-resilience-weather-Source-review-01/review.json';add(thermal_peer)
o=BASE/'through-primary-diagnostic-A-24H-Root-67/output'
for name in ['diagnostics.json','run-summary.json','eplusrs.ctf.log','eplusrs.eio','clock-calls.json','clk03-weather-day-production-trace.json']:add(o/name)
PUBLIC.mkdir();z=PUBLIC/'evidence.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for key,b in sorted(payload.items()):
  item=zipfile.ZipInfo(key,date_time=(2026,10,17,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(item,b)
with zipfile.ZipFile(z) as archive:
 assert archive.testzip() is None and set(archive.namelist())==set(payload)
 for key,b in payload.items():assert archive.read(key)==b
v=dict(schema='src06-canonical-thermal-weather.v1',status='Thermal weather Source integrated; actual primary completes its one-day traversal; endrun/export and exact reported numerical parity unfinished',Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,promotion=ref(promotion),changed_Rust_files=3,new_Rust_files=1,existing_Rust_files=2,new_test_bodies=0,actual_commands=actual,independent_Source_and_actual_peer=p['independent_actual_peer'],thermal_literal_Source_peer=ref(thermal_peer),reported_artifact_comparison=ref(comp),independent_reported_artifact_readback=ref(comparison_peer),evidence_archive=ref(z),archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for k,b in sorted(payload.items())],scope=['Native thermal weather5870-6386 uses the same Zone resilience, live Air.ZTAV and thermostat setpoints. All-zone PierceSET/PMV resets and36 hour-bin additions preserve Native branch/operand/update order.','Actual People0 skips only the People loop; NumOcc is neither synthesized nor reset. Positive People/SET/period domains stop at their actual first unsupported operation.','The actual genuine Source A-24H now returns from Primary after96 quarter-hour ESO timestamps and24 hourly MTR timestamps, with20 warmup days. It then exits6 at the explicit endrun566-620/export boundary.','The identical changed runtime Source passed whole workspace/all-target compilation in the held diagnostic assembly. Canonical dispatcher is unchanged; no new tests or repeated full suite.'],reported_numeric_observation=c['summary'],numeric_limit='ESO3536 of5280 reported decimal values parse to unequal binary64 values in40 series; maximum absolute difference7.429434845107608e-11. MTR72 reported values match. These are reported outputs, not internal raw-state observations; no tolerance was introduced, no cause is inferred, and numerical parity is not certified.',remaining=['Genuine endrun, physical file closes and completed result exporter; canonical production dispatcher activation.','Diagnose the observed reported-value differences under verified Native/Rust arithmetic and execution conditions; full same-input/state A/B numeric coverage.','Remaining positive input/owner/error domains and all four card gates.'],coverage_limit='Existing clock/day observers still report zero for the genuine Source route; physical ESO/MTR/LOG/EIO and the retained caller chain establish this bounded execution progress.',reconstruction='Canonical Git holds the three changed LF Sources. Compact archive contains actual receipts, exact compiled input hash censuses, physical output pairs, full uncapped mismatch ledger and independent reviews; no new complete offline replay claim.',pipeline_activation=False,canonical_pipeline=p['canonical_pipeline_unchanged'],completed_Source_run_or_export=False,whole_Native_numeric_PASS=False,full_suite_rerun=False,gate_changes=False,A='14/54',B='14/64',retained_whole_old_comparison=dict(mismatches=235456,required_unavailable_or_unpaired=2754),author_Source=ref(Path(__file__).resolve()))
q=PUBLIC/'summary.json';q.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
relative='evidence/SRC-06-canonical-thermal-weather-04/summary.json';paragraph='실제 구역 상태·온도·냉난방 설정점을 사용하는 열적 복원력 기상 누적 계산을 적용했습니다. 같은 재실 상태를 보존하고 원본 분기·연산·갱신 순서를 유지합니다. 변경 Source를 포함한 진단 조합의 전체 타깃 컴파일이 통과했고 새 테스트나 전체 테스트 반복은 없습니다. 실제 Source A-24H는 20일 워밍업과 15분 기록 96개·시간별 기록 24개를 생성한 뒤 Primary에서 반환했습니다. 전체 실행은 종료 보고·결과 내보내기 경계에서 exit6이며 기본 파이프라인은 아직 전환하지 않았습니다. 같은 입력의 원본26.1.0 실행은 성공했고 출력 사전·시간축은 일치합니다. ESO 5,280개 값 중 3,536개는 보고된 십진수를 binary64로 해석했을 때 다르며 최대 절대 차이는 7.429434845107608e-11입니다. MTR 72개 보고 값은 같습니다. 내부 원시 상태·FP 환경 동등성을 뜻하지 않으며 허용오차를 추가하지 않았습니다. 원인 검토와 수치 동등성 검증은 남아 있습니다. A14/54·B14/64와 기존 전체 FAIL을 유지합니다.'
for name in ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']:
 q=ROOT/'energyplus_porting_plan'/name;s=q.read_text(encoding='utf8');assert 'canonical-thermal-weather-04' not in s;link='../'+relative if name.startswith('cards/') else relative;s+='\n\n[열적 복원력 계산과 실제 본 실행·원본 출력 대조](%s). %s\n'%(link,paragraph);q.write_text(s,encoding='utf8',newline='\n')
q=ROOT/'energyplus_porting_plan/plan.json';before=json.loads(q.read_bytes());after=json.loads(q.read_bytes());task=next(x for x in after['tasks'] if x['id']=='SRC-06');key='canonical_thermal_weather_04';assert key not in task;task[key]=dict(path=(PUBLIC/'summary.json').relative_to(ROOT).as_posix(),sha256=ref(PUBLIC/'summary.json')['sha256'],size_bytes=(PUBLIC/'summary.json').stat().st_size);check=json.loads(json.dumps(after));del next(x for x in check['tasks'] if x['id']=='SRC-06')[key];assert check==before;q.write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(ref(PUBLIC/'summary.json')));print(json.dumps(ref(z)));print('archive_entries',len(payload))

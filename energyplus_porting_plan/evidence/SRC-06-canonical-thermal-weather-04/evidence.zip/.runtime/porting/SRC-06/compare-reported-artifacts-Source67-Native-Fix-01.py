﻿"""Read-only reported decimal ESO/MTR comparison; structural proofs precede key-based pairing."""
from pathlib import Path
import collections,csv,hashlib,json,math,re,struct,subprocess
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'.runtime/porting/SRC-06';O=B/'ordinary-reported-artifact-comparison-Fix-67-01';S=B/'through-primary-diagnostic-A-24H-Root-67/output';N=B/'native-installed-A-24H-Root-67/output';W=B/'ordinary-provider-assembly-Root-67/workspace';assert not O.exists();O.mkdir()
def ref(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(path=p.relative_to(ROOT).as_posix(),sha256=h.hexdigest(),bytes=p.stat().st_size)
def put(n,v):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(v);return p
def jp(n,v):return put(n,(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8'))
def read_receipt(path,sha,exit):
 p=Path(path);assert ref(p)['sha256']==sha;r=json.loads(p.read_text(encoding='utf-8'));assert r['exit_code']==exit and r['launch_error']is None and r['source_bytes_match_before_and_after']
 return r
SR=W/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-67/receipt.json';NR=B/'native-installed-A-24H-command-Root-67/receipt.json';VR=B/'native-installed-version-Root-67/receipt.json'
sr=read_receipt(SR,'7288060c57884a7a8332d1a9f7d765283d24262947bec342a1550cee9badf4a0',6);nr=read_receipt(NR,'66dce9a44c5aa366719a44dec194656aeac174e88f17b05599c4248abd2b20b4',0);vr=read_receipt(VR,'caf4530dbb186fed594184cc880172aaee5084351c98629fda6f3bfe315a7191',0)
for receipt,base in [(sr,W),(nr,ROOT),(vr,ROOT)]:
 for name in ['stdout','stderr']:assert ref(base/receipt[name]['path'])['sha256']==receipt[name]['sha256']
version=ROOT/vr['stdout']['path'];assert version.read_text(encoding='utf-8').strip()=='EnergyPlus, Version 26.1.0-6f2e40d102'
s_cmd=sr['command'];n_cmd=nr['command'];source_idf=Path(s_cmd[s_cmd.index('--')+2]);native_idf=Path(n_cmd[-1]);source_weather=Path(s_cmd[s_cmd.index('--weather')+1]);native_weather=Path(n_cmd[n_cmd.index('--weather')+1]);assert source_idf.resolve()==native_idf.resolve() and source_weather.resolve()==native_weather.resolve();assert source_idf.read_bytes()==(S/'input/original.idf').read_bytes()
g=subprocess.check_output(['git','show',nr['repository_before']['head']+':'+source_idf.relative_to(ROOT).as_posix()],cwd=ROOT);assert g==source_idf.read_bytes()
installed=ROOT/'.runtime/energyplus/26.1.0';assert Path(n_cmd[0]).resolve()==(installed/'energyplus.exe').resolve();inventory=B/'native-installed-post-command-file-versions-Fix-67-01.json';iv=json.loads(inventory.read_text(encoding='utf-8-sig'));assert len(iv['rows'])==57
for f in iv['rows']:
 p=Path(f['path']);assert ref(p)['sha256']==f['sha256'] and p.stat().st_size==f['bytes']
assert nr['repository_before']==nr['repository_after'] and nr['repository_before']['worktree_clean']
assert '--oracle-baseline'not in s_cmd and '--compare-oracle'not in s_cmd

def parse(path):
 lines=Path(path).read_text(encoding='utf-8').splitlines();assert lines.count('End of Data Dictionary')==1;end=lines.index('End of Data Dictionary');assert lines[0].startswith('Program Version,');dd={};order=[]
 for number,line in enumerate(lines[1:end],2):
  cells=next(csv.reader([line],strict=True));rid=int(cells[0]);count=int(cells[1]);assert rid not in dd and count>=1;dd[rid]=dict(line=line,cells=cells,count=count,line_number=number);order.append(rid)
 assert {1,2,3,4,5,6}<=set(dd)
 envs=[];frames=[];frame=None;seen_frames=set();record_map={};record_order=[];footer=[];env_index=0;numeric_ids=collections.Counter();controls=[];ended=False
 for lineno in range(end+1,len(lines)):
  line=lines[lineno]
  if line=='End of Data':ended=True;footer=lines[lineno:];break
  cells=next(csv.reader([line],strict=True));assert cells and cells[0].isdigit();rid=int(cells[0]);assert rid in dd
  if rid==1:
   assert len(cells)==dd[rid]['count']+1;env_index+=1;frame=None;envs.append(dict(ordinal=env_index,cells=cells,line=line,line_number=lineno+1));controls.append(line)
  elif 2<=rid<=6:
   assert env_index>0 and len(cells)==dd[rid]['count']+1;key=(env_index,rid,tuple(cells[1:]));assert key not in seen_frames;seen_frames.add(key);frame=dict(ordinal=len(frames)+1,environment_ordinal=env_index,timestamp_id=rid,cells=cells,line=line,line_number=lineno+1,key=key,report_ids=[],data_line_numbers=[]);frames.append(frame);controls.append(line)
  else:
   assert frame is not None and len(cells)==dd[rid]['count']+1 and rid not in frame['report_ids'];frame['report_ids'].append(rid);frame['data_line_numbers'].append(lineno+1);numeric_ids[rid]+=1
   for column,text in enumerate(cells[1:],1):
    value=float(text);assert math.isfinite(value);key=(frame['key'],rid,column);assert key not in record_map;record_map[key]=dict(text=text,value=value,line=lineno+1,frame=frame['ordinal'],rid=rid,column=column);record_order.append(key)
 reported=None
 if ended:
  assert len(footer)==2 and re.fullmatch(r' Number of Records Written=\s*\d+',footer[1]);reported=int(footer[1].split('=')[1]);assert reported==sum(numeric_ids.values())
 else:assert not footer
 return dict(lines=lines,version=lines[0],dd=dd,dd_order=order,dd_lines=lines[1:end],envs=envs,frames=frames,controls=controls,records=record_map,record_order=record_order,numeric_ids=numeric_ids,footer=footer,reported=reported,ended=ended)

def bits(v):return struct.pack('>d',v).hex()
ledger=[];summaries=[];structure=[]
for stream in ['eso','mtr']:
 sp=S/f'eplusrs.{stream}';np=N/f'energyplusout.{stream}';s=parse(sp);n=parse(np)
 # Full structure is proved before values are paired. No positional zip assumption.
 assert s['dd_lines']==n['dd_lines'] and s['dd_order']==n['dd_order'];assert s['controls']==n['controls'];assert len(s['envs'])==len(n['envs']) and len(s['frames'])==len(n['frames']);assert s['record_order']==n['record_order'] and set(s['records'])==set(n['records']);assert s['numeric_ids']==n['numeric_ids'];assert not s['ended'] and n['ended']
 assert s['version']=='Program Version,rusted-energyplus 0.1.0';assert n['version'].startswith('Program Version,EnergyPlus, Version 26.1.0-6f2e40d102, YMD=')
 fs=[]
 for i,sf in enumerate(s['frames']):
  nf=n['frames'][i];assert sf['key']==nf['key'] and sf['line']==nf['line'] and sf['report_ids']==nf['report_ids'];assert len(sf['data_line_numbers'])==len(nf['data_line_numbers']);assert sf['report_ids']==s['frames'][0]['report_ids']
  fs.append(dict(frame=sf['ordinal'],environment=sf['environment_ordinal'],timestamp=sf['line'],source_line=sf['line_number'],native_line=nf['line_number'],report_ID_order=sf['report_ids'],numeric_rows=len(sf['report_ids'])))
 counts=dict(total=len(s['records']),binary64_unequal=0,text_unequal=0,text_only_unequal=0,bits_only_unequal=0,numeric_equal_signed_zero_unequal=0);series={};max_abs=0.0;max_rel=0.0;max_abs_where=None;max_rel_where=None
 for key in s['record_order']:
  sv=s['records'][key];nv=n['records'][key];a=sv['value'];b=nv['value'];sb=bits(a);nb=bits(b);bu=sb!=nb;tu=sv['text']!=nv['text'];absdiff=abs(a-b);denom=max(abs(a),abs(b));relative=absdiff/denom if denom else 0.0
  rid=sv['rid'];stat=series.setdefault(rid,dict(id=rid,dictionary=s['dd'][rid]['line'],values=0,binary64_unequal=0,text_unequal=0,max_abs_difference=0.0,max_symmetric_relative_difference=0.0));stat['values']+=1
  if bu:counts['binary64_unequal']+=1;stat['binary64_unequal']+=1
  if tu:counts['text_unequal']+=1;stat['text_unequal']+=1
  if tu and not bu:counts['text_only_unequal']+=1
  if bu and not tu:counts['bits_only_unequal']+=1
  if bu and a==b:assert a==0.0;counts['numeric_equal_signed_zero_unequal']+=1
  stat['max_abs_difference']=max(stat['max_abs_difference'],absdiff);stat['max_symmetric_relative_difference']=max(stat['max_symmetric_relative_difference'],relative)
  where=dict(frame=sv['frame'],id=rid,column=sv['column'])
  if absdiff>max_abs:max_abs=absdiff;max_abs_where=where
  if relative>max_rel:max_rel=relative;max_rel_where=where
  if bu or tu:ledger.append(dict(stream=stream,frame=sv['frame'],id=rid,column=sv['column'],s=sv['text'],n=nv['text'],sb=sb,nb=nb,bu=bu,tu=tu,abs=absdiff,rel=relative,sl=sv['line'],nl=nv['line']))
 structure.append(dict(stream=stream,source=ref(sp),native=ref(np),version_source=s['version'],version_native=n['version'],dictionary_other_than_version_exact=True,dictionary_ID_order=s['dd_order'],dictionary_rows=len(s['dd']),environments=s['envs'],timestamp_frames=fs,full_control_rows_exact=True,full_record_keys_and_order_exact_before_pairing=True,numeric_record_count=sum(s['numeric_ids'].values()),scalar_count=len(s['records']),per_ID_records=dict(sorted(s['numeric_ids'].items())),Source_footer=dict(present=False,lines=[],status='Unfinished: actual Source exits6 at endrun566 entry; no End of Data or record-count finalization.'),Native_footer=dict(present=True,lines=n['footer'],reported_record_count=n['reported'],count_matches_numeric_rows=True),whole_file_equality_claimed=False))
 summaries.append(dict(stream=stream,counts=counts,series=sorted(series.values(),key=lambda x:x['id']),series_with_binary64_mismatch=sum(x['binary64_unequal']>0for x in series.values()),max_abs_difference=max_abs,max_abs_where=max_abs_where,max_symmetric_relative_difference=max_rel,max_relative_where=max_rel_where,relative_definition='abs(Source-Native)/max(abs(Source),abs(Native));0whenboth0; descriptiveonly/no tolerance',status='REPORTED_DECIMAL_BINARY64_MISMATCH'if counts['binary64_unequal']else'PAIRED_REPORTED_VALUES_BINARY64_EXACT_ONLY_NOT_A_GATE'))
assert summaries[0]['counts']['total']==5280 and summaries[1]['counts']['total']==72
assert summaries[0]['counts']['binary64_unequal']==3536 and summaries[0]['series_with_binary64_mismatch']==40
mismatch=put('all-uncapped-mismatches.jsonl',b''.join((json.dumps(x,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')for x in ledger));structural=jp('full-structural-alignment-and-footer-proof.json',structure);numeric=jp('per-series-reported-value-summary.json',summaries)
report=dict(schema='SRC-06-readonly-Source67-vs-actual-installed-Native-reported-artifacts.v1',status='DESCRIPTIVE_REPORTED_VALUE_MISMATCH_WITH_UNFINISHED_SOURCE_FOOTERS',source_actual_receipt=ref(SR),native_actual_receipt=ref(NR),native_actual_version_receipt=ref(VR),native_version_stdout=ref(version),source_assembly=ref(B/'ordinary-provider-assembly-Root-67/manifest.json'),source_input=ref(source_idf),source_staged_input=ref(S/'input/original.idf'),input_Git_revision=nr['repository_before']['head'],input_current_equals_Git_and_staged=True,weather=ref(source_weather),input_custody_scope='Commands use identical originalIDF/weather paths; Source stagedIDF bytes equal current Git/native command HEAD. Shared weather hash is current post-command observation; no separate Native loaded-file hash instrumentation.',post_command_native_exe_and_DLL_inventory=ref(inventory),native_module_scope='57 executable/DLL files observed beside installed exe after commands with hashes/Win32versions. No loaded-module certificate or rawstate/FP environment equality claim.',structure_and_footer_proof=ref(structural),reported_value_summary=ref(numeric),all_uncapped_mismatches=ref(mismatch),ledger_entries=len(ledger),ledger_keys=dict(s='Source reporteddecimal text',n='Native reporteddecimal text',sb='bigendian hex of Pythonparsed binary64 Source reporteddecimal',nb='same Native',bu='parsedbinary64unequal',tu='literaltextunequal',abs='descriptiveabsolutedifference',rel='symmetricrelative descriptiveonly',sl='Source physical line',nl='Native physical line',frame='matching timestamp frame in structural proof; no positional zip assumption'),summary=[{k:v for k,v in q.items()if k!='series'}for q in summaries],first_mismatch=ledger[0]if ledger else None,limits=['Binary64 comparisons describe parsed reporteddecimal outputs, not independently observed internal live rawstate bits.','Exact dictionaries/IDs/environment/timestamp/counts/key-order/row-shapes proved before key-based pairing; full mismatch ledger has no caps.','Native run exits0 and has final footers; Source67 exits6 after genuinePrimary at unresolvedendrun and has no final footers. No completedSource/wholefile/reportingprotocol equivalence.','No tolerances or tolerancePASS, numericalgate, FPenvironment/loadedmodule equivalence, new tests or fixture answers; no gate updates.','This new actualNative comparison applies only to actual67 artifacts and does not alter63–66 historical failures/claims.','Comparator executes no Cargo/Native/target; writes ignored comparison artifacts only and leaves canonical Source untouched.'],author_Source=ref(Path(__file__).resolve()))
p=jp('comparison.json',report);print(json.dumps(ref(p)))

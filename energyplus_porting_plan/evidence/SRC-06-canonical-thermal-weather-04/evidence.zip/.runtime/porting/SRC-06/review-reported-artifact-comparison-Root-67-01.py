"""Independent exact row/control alignment and full reported mismatch readback."""
from pathlib import Path
import json,hashlib,struct,math
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-ordinary-reported-artifact-comparison-review-67-01';assert not OUT.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 p=ROOT/r['path'];b=p.read_bytes();assert ref(p)['sha256']==r['sha256'] and len(b)==r.get('bytes',len(b));return b
p=BASE/'ordinary-reported-artifact-comparison-Fix-67-01/comparison.json';m=json.loads(p.read_bytes());assert ref(p)['sha256']=='b588f76002198828e2954be25d84c4a5f3a87cc9a12176fa4bd9466279253721'
for key in ['source_actual_receipt','native_actual_receipt','native_actual_version_receipt','native_version_stdout','source_assembly','source_input','source_staged_input','weather','post_command_native_exe_and_DLL_inventory','structure_and_footer_proof','reported_value_summary','all_uncapped_mismatches','author_Source']:read(m[key])
assert read(m['source_input'])==read(m['source_staged_input']) and b'26.1.0-6f2e40d102' in read(m['native_version_stdout'])
assert json.loads(read(m['source_actual_receipt']))['exit_code']==6 and json.loads(read(m['native_actual_receipt']))['exit_code']==0
bits=lambda v:struct.pack('>d',v).hex();expected=[];proof=[];artifacts=[]
for stream,total,frames in [('eso',5280,96),('mtr',72,24)]:
 sp=BASE/f'through-primary-diagnostic-A-24H-Root-67/output/eplusrs.{stream}';np=BASE/f'native-installed-A-24H-Root-67/output/energyplusout.{stream}'
 s=sp.read_text().splitlines();n=np.read_text().splitlines();ds=s.index('End of Data Dictionary');dn=n.index('End of Data Dictionary');assert ds==dn and s[1:ds]==n[1:dn]
 assert n[-2]=='End of Data' and int(n[-1].split('=')[1])==total and not any('End of Data'==x for x in s[ds+1:])
 a=s[ds+1:];b=n[dn+1:-2];assert len(a)==len(b)
 # Establish full row IDs/control/timestamps and column shape before pairing.
 for x,y in zip(a,b):
  xx=x.split(',');yy=y.split(',');assert xx[0]==yy[0] and len(xx)==len(yy)
  if int(xx[0])<=6:assert x==y
 count=0;frame=0;maxabs=0.0;maxrel=0.0;series=set()
 for offset,(x,y) in enumerate(zip(a,b),ds+2):
  xx=x.split(',');yy=y.split(',');ident=int(xx[0])
  if ident==2:frame+=1
  if ident<=6:continue
  for col in range(1,len(xx)):
   sv=float(xx[col]);nv=float(yy[col]);assert math.isfinite(sv) and math.isfinite(nv);count+=1
   if bits(sv)!=bits(nv) or xx[col]!=yy[col]:
    absdiff=abs(sv-nv);reldiff=absdiff/max(abs(sv),abs(nv)) if sv or nv else 0.0;maxabs=max(maxabs,absdiff);maxrel=max(maxrel,reldiff);series.add(ident)
    expected.append(dict(stream=stream,frame=frame,id=ident,column=col,s=xx[col],n=yy[col],sb=bits(sv),nb=bits(nv),bu=bits(sv)!=bits(nv),tu=xx[col]!=yy[col],abs=absdiff,rel=reldiff,sl=offset,nl=offset))
 assert count==total and frame==frames
 proof.append(dict(stream=stream,numeric_values=count,frames=frame,mismatch_series=len(series),max_abs_difference=maxabs,max_relative_difference=maxrel,full_row_and_control_alignment=True));artifacts.extend([ref(sp),ref(np)])
ledger=[json.loads(line) for line in read(m['all_uncapped_mismatches']).splitlines()];assert expected==ledger and len(expected)==3536 and expected[0]==m['first_mismatch']
assert proof[0]['max_abs_difference']==m['summary'][0]['max_abs_difference'] and proof[0]['max_relative_difference']==m['summary'][0]['max_symmetric_relative_difference']
OUT.mkdir();v=dict(schema='src06-independent-reported-artifact-comparison-review.v1',status='ACCEPTED_DESCRIPTIVE_MISMATCH_READBACK_ONLY',comparison=ref(p),artifacts=artifacts,independent_alignment_and_counts=proof,all3536_uncapped_mismatch_rows_recomputed_exactly=True,Source_footer_unfinished=True,Native_footer_complete=True,limitations=['Reported decimal values parsed to binary64 are not Native internal raw-state observations.','57 executable/DLL hashes and weather hash are post-command observations; no loaded-module or FP environment equality certificate.','ESO3536/5280 values unequal, MTR72/72 values equal; exact-bit numerical parity remains unverified. No tolerance PASS or gate change.'],canonical_changed=False,new_test_bodies=0,Cargo_or_Native_executed=False,author_Source=ref(Path(__file__).resolve()));q=OUT/'review.json';q.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(q)))

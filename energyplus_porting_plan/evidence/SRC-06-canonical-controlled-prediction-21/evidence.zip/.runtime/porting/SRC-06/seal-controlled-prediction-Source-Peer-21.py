"""Seal four genuine predictor Sources on exact committed/actual19 custody."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
HEAD = '80e68ac8b55fd21ff1c754849cbd34b23fafa45b'
P = 'crates/ep_runtime/src/heat_balance/'
O = D / 'source-controlled-prediction-held-Peer-21'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def check(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', got['bytes']), row
    return p
def load(row): return json.loads(check(row).read_bytes())
def put(name, data):
    p = O / name; assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
    return ref(p)
def doc(name, value): return put(name, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())
def git(p): return subprocess.check_output(['git', 'show', HEAD + ':' + p], cwd=R)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == HEAD
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=R, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
root_ref = ref(D / 'Root-source-thermostat-current-actual-review-19/review.json')
assert root_ref['sha256'] == '0f2c5abf5ed98916ca0bf78316c9a431ec9294be470026342e2452eb7db5632d'
root = load(root_ref); assert root['accepted'] and not root['findings']
assert root['B_frontier'] == 'GetHeatBalanceInput: positive controlled predicted load6862'
B_ref, A_ref = root['actual_B'], root['actual_A24']
B, A = load(B_ref), load(A_ref)
assert B_ref['sha256'] == '9f5a3b94540715a48f0637c2ad65bfd71f0d56006e23c0c481fecbd922be29c1'
assert B['exit_code'] == 6 and A['exit_code'] == 0
assert B['source_bytes_match_before_and_after'] and A['source_bytes_match_before_and_after']
assert B['launch_error'] is None and A['launch_error'] is None
assert B['source_snapshot']['sha256'] == A['source_snapshot']['sha256'] == 'cfe34ba687aff231e21c1103e415f63a1f171b1c8973fd41f7fa57ff57815306'
snapshot_ref = B['source_snapshot']; snapshot = load(snapshot_ref)
observed = {row['historical_path']: row for row in snapshot['files']}
assert len(observed) == len(snapshot['files']) == 4490
assert sum(p.endswith('.rs') for p in observed) == 4477
draft_ref = ref(D / 'source-controlled-prediction-draft-Peer-21-02/draft.json')
assert draft_ref['sha256'] == '480ca1b0ee2aa0f0a12814adc4f2a42bf0d26681287f459da2afedde69c6c806'
draft = load(draft_ref); parent = load(draft['parent19_producer']); plan = load(draft['parent19_plan'])
old_entries = {row['path']: row for row in plan['entries']}
assert set(old_entries) == set(observed)
for p, row in old_entries.items():
    b = check(row['source']).read_bytes()
    assert len(b) == row['final_bytes'] and hashlib.sha256(b).hexdigest() == row['final_sha256']
    assert b == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes(), p
paths = set((R / 'crates').rglob('*.rs')) | set((R / 'crates').rglob('Cargo.toml'))
for p in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml']:
    if (R / p).is_file(): paths.add(R / p)
assert {p.relative_to(R).as_posix() for p in paths} == set(observed)
assert P + 'source_output_registration/report_diagnostics.rs' not in observed
assert not (R / (P + 'source_output_registration/report_diagnostics.rs')).exists()
assert draft['Source_files'] == 4 and not draft['new_Source_files']
assert not O.exists(); O.mkdir()
node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[node], type_ignores=[]), '<own-literal-apply>', 'exec'), ns)
files, text = [], {}
for i, row in enumerate(draft['files'], 1):
    p = row['canonical_path']; old = check(row['before']).read_bytes(); new = check(row['proposed']).read_bytes()
    assert old == check(row['parent19']).read_bytes() == check(observed[p]['archive']).read_bytes() == (R / p).read_bytes() == git(p)
    f, inv = check(row['forward_diff']).read_bytes(), check(row['inverse_diff']).read_bytes()
    assert ns['apply_literal'](old, f) == new and ns['apply_literal'](new, inv) == old
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and not parsed.stderr
    text[p] = new.decode()
    added = ''.join(line[1:] for line in f.decode().splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
    assert not re.search(r'\.(?:unwrap|expect)\s*\(|\b(?:panic|unreachable|unimplemented|todo)!|#\[test\]|\.runtime[/\\]', added)
    files.append({'canonical_path': p, 'before_absent': False, 'before': put('before/' + p, old), 'proposed': put('proposed/' + p, new),
        'literal_inverse': put('literal-inverse/' + p, old), 'forward_diff': put(f'diffs/{i:02d}-forward.diff', f), 'inverse_diff': put(f'diffs/{i:02d}-inverse.diff', inv),
        'actual19_archive': observed[p]['archive'], 'committed19_Git_and_actual19_and_live_before_whole_equal': True,
        'Source_only_parse': {'exit_code': 0, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})
selected = {row['canonical_path']: row for row in files}
final_entries, hits = [], []
patterns = ['SourceZoneAirOwners {', 'SourceHvacOwners {', 'SourceZoneAirNodeMut', 'source_zone_air_node_mut(', 'calculate_source_predicted_sensible(', 'update_source_temperatures(']
for p in sorted(observed):
    source = selected[p]['proposed'] if p in selected else observed[p]['archive']
    b = check(source).read_bytes()
    final_entries.append({'path': p, 'final_sha256': source['sha256'], 'final_bytes': len(b), 'source': {**source, 'bytes': len(b)},
        'origin': 'selected21 genuine predictor Source' if p in selected else 'whole exact actual19 archived parent'})
    if p.endswith('.rs'):
        for number, line in enumerate(b.decode().splitlines(), 1):
            found = [pattern for pattern in patterns if pattern in line]
            if found: hits.append({'path': p, 'line': number, 'literal': line, 'patterns': found})
assert sum('SourceZoneAirOwners {' in row['patterns'] for row in hits) == 1
assert sum('SourceHvacOwners {' in row['patterns'] for row in hits) == 2
assert sum('update_source_temperatures(' in row['patterns'] for row in hits) == 2
assert sum('calculate_source_predicted_sensible(' in row['patterns'] for row in hits) == 2
assert sum('SourceZoneAirNodeMut' in row['patterns'] for row in hits) == 3
assert sum('source_zone_air_node_mut(' in row['patterns'] for row in hits) == 5
plan_ref = doc('complete-final-compiler-Source-plan.json', {'base_HEAD': HEAD, 'parent_actual_snapshot': snapshot_ref, 'inputs': 4490, 'Rust_sources': 4477,
    'entries': final_entries, 'Root_full_rehash_required': True})
api_ref = doc('whole-crates-concrete-API-inventory.json', {'Rust_sources': 4477, 'all4490_before_and_final_wholes_rehashed': True, 'includes_all_crates_runtime_and_tests': True,
    'occurrences': hits, 'actual_constructor_counts': {'SourceZoneAirOwners': 1, 'SourceHvacOwners': 2}, 'changed_tests': 0,
    'mutable_equipment': 'Same SourceHvacOwners.equipment temporary reborrow into the sole existing SourceZoneAirOwners literal; all private owner members audited against real definitions.',
    'same_Node_fields': 'NodeOwner.physical actual row refs; no diagnostic NodeStateStore/typedID projection/new owner or payload copy.'})
contexts = []
for row in draft['unchanged_contexts']:
    p = row['canonical_path']; b = check(row['frozen']).read_bytes()
    assert p not in selected and b == check(observed[p]['archive']).read_bytes() == git(p) == (R / p).read_bytes()
    contexts.append({'canonical_path': p, 'whole': put('context/' + p, b), 'actual19_archive': observed[p]['archive'], 'committed19_Git_and_actual19_and_live_whole_equal': True})
native, native_bytes, extents = [], {}, []
extra = {'src/EnergyPlus/DataHeatBalance.hh': [(641, 658)], 'src/EnergyPlus/DataZoneEnergyDemands.hh': [(62, 80)]}
for row in draft['Native_wholes']:
    p = row['Native_path']; b = check(row['whole']).read_bytes()
    assert b == subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N) == (N / p).read_bytes()
    native_bytes[p] = b; native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, b)})
for p in extra:
    b = subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N)
    assert b == (N / p).read_bytes()
    native_bytes[p] = b; native.append({'Native_path': p, 'revision': PIN, 'whole': put('Original-Git/' + p, b)})
draft_extents = load(draft['Native_extents'])
for row in draft_extents:
    p, a, z = row['Native_path'], row['first'], row['last']
    b = b''.join(native_bytes[p].splitlines(keepends=True)[a-1:z])
    assert b.decode() == row['literal'] and hashlib.sha256(b).hexdigest() == row['utf8_sha256']
    extents.append({'Native_path': p, 'first': a, 'last': z, 'strict_extent': put(f'Native/{Path(p).name}-{a}-{z}.txt', b)})
for p, ranges in extra.items():
    for a, z in ranges:
        b = b''.join(native_bytes[p].splitlines(keepends=True)[a-1:z])
        extents.append({'Native_path': p, 'first': a, 'last': z, 'strict_extent': put(f'Native/{Path(p).name}-{a}-{z}.txt', b)})
# Existing interpolation is reused whole; bind the exact std::array overload.
p = 'src/EnergyPlus/ZoneTempPredictorCorrector.cc'; a, z = 4704, 4738
b = b''.join(native_bytes[p].splitlines(keepends=True)[a-1:z])
extents.append({'Native_path': p, 'first': a, 'last': z, 'strict_extent': put(f'Native/{Path(p).name}-{a}-{z}.txt', b)})
contract_ref = doc('integration-contract.json', {'scope': draft['semantics'], 'true_parent19_frontier': root['B_frontier'],
    'branch_table': {'Uncontrolled0': 'actual zero locals and late physical setpoint/flags/reporting', 'SingleHeat1': 'ThirdOrder scalar heat then samecool; total<=0 deadband',
        'SingleCool2': 'ThirdOrder scalar cool; literal heating-local RAF division; actual ITE/BeginSim; sameheat; total>=0 deadband',
        'SingleHeatCool3': 'two separate scalar loads; actual ITE; inversion diagnostic bound; positive/negative/equality sign branches',
        'DualHeatCool4': 'separate lo/hi loads; actual ITE; inversion diagnostic bound; exact sign cases/real Node deadband max(lo) then min(hi)',
        'default': 'Native no-op retains actual initialized procedure locals'},
    'exact_suffix_order': ['StageNum actual demand read even NumStage0', 'actual NumStage/StageZoneLogic positive typed operation if reached', 'same physical Node.TempSetPoint',
        'Setback(ZoneSetPoint>setPointLast)', 'HB.setPointLast', 'same fan zoneTstatSetpts.setpt', 'DeadBandOrSetback', 'CurDeadBandOrSetback',
        'existing real demand reporter reads correction then writes 3 rates, Zone/List multiplier and 3 requirements, actual controlled equipment sequences'],
    'rollback_order': ['Node.Temp=XMAT0', 'TempTstatAir=XMAT0', 'Node.HumRat=WPrev0', 'Node.Enthalpy=normalH(XMAT0,WPrev0)',
        'actual system-count interpolation predicate', 'existing interpolation', 'actual working-history copies'],
    'RAFN': 'Actual Native3170 local0; only positive writer3205 is behind retained Source3193 actual RoomAFN boundary. No input-absence inference or forced1.',
    'math_reuse': 'Existing down_interpolate/normalH/normalCp and report_source_predicted_sensible retained. Public predicted_system_load DTO has different eager validation/read timing and cannot represent same-owner Native mutation; its constraints are not transplanted.',
    'deferred18_and20': 'No MoreNodeInfo, inlet sum or controlled corrector body copied. Same mutable equipment reborrow/normalH import is necessary for this genuine rollback/setpoint producer; future20 extends this same SourceZoneAirNodeMut borrowed view with actual mass field.',
    'execution_limits': draft['limits'], 'new_tests': 0})
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=R)
manifest = {'schema': 'src06-held-cohesive-controlled-prediction.v1', 'status': 'HELD Source only; compilation/actual21 pending', 'base_HEAD': HEAD,
    'actual19_review': root_ref, 'actual19_snapshot': snapshot_ref, 'actual19_B': B_ref, 'actual19_A24': A_ref,
    'parent19_producer': draft['parent19_producer'], 'parent19_complete_plan': draft['parent19_plan'], 'actual19_complete_plan': draft['parent19_plan'], 'files': files, 'existing_Source_files': 4, 'new_Source_files': 0,
    'literal_applications': 8, 'Source_only_parses': 4, 'complete_final_compiler_Source_plan': plan_ref, 'whole_crates_API_inventory': api_ref,
    'Native_commit': PIN, 'Native_wholes': [{**ref(N / row['Native_path']), 'whole_equals_git': True} for row in native],
    'Native_literal_extents': doc('Native-literal-extents.json', [{'native_path': row['Native_path'], 'first': row['first'], 'last': row['last'], 'utf8_sha256': row['strict_extent']['sha256'], 'literal': check(row['strict_extent']).read_bytes().decode('utf-8')} for row in extents]),
    'frozen_Native_wholes': native, 'frozen_Native_extents': extents, 'unchanged_contexts': contexts, 'integration_contract': contract_ref,
    'unsealed_author_draft': draft_ref, 'draft01_retained': ref(D / 'source-controlled-prediction-draft-Peer-21/draft.json'),
    'preseal_API_naming_qualification': 'Unsealed draft02 aligns four required borrowed physical fields with future20 SourceZoneAirNodeMut/source_zone_air_node_mut names; no arithmetic/owner change or rejected sealed variant.',
    'author_Source': draft['author_Source'], 'sealer_Source': ref(Path(__file__)), 'new_test_bodies': 0, 'Cargo_Native_or_tests_executed': False,
    'main_mutations': 0, 'FP_tolerance_or_gate_changes': False, 'full_B_or_positive_Node_execution_claim': False}
print(json.dumps(doc('manifest.json', manifest)))

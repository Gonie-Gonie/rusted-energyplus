"""Draft only: genuine positive controlled prediction on the exact held19 parent."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
O = D / 'source-controlled-prediction-draft-Peer-21-02'
P = 'crates/ep_runtime/src/heat_balance/'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'

def ref(path):
    b = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
def check(row):
    p = R / row['path']; got = ref(p)
    assert got['sha256'] == row['sha256'] and got['bytes'] == row.get('bytes', got['bytes'])
    return p
def put(name, data):
    p = O / name; assert not p.exists()
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
    return ref(p)
def doc(name, value): return put(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())
def swap(s, old, new):
    assert s.count(old) == 1, old[:120]
    return s.replace(old, new)

assert not O.exists(); O.mkdir()
producer = ref(D / 'source-thermostat-current-held-Outer-19/manifest.json')
assert producer['sha256'] == 'b654dd0c88a5f8a27aa2d885c385a543021b1420c4dbd36a94627e17ad280283'
m = json.loads(check(producer).read_bytes())
plan = json.loads(check(m['complete_final_compiler_Source_plan']).read_bytes())
entries = {row['path']: row for row in plan['entries']}
assert len(entries) == 4490 and sum(p.endswith('.rs') for p in entries) == 4477
paths = [P + p for p in ['ordinary_equipment.rs', 'ordinary_air_heat_balance/predictor_corrector.rs', 'ordinary_hvac_manager/owners.rs', 'ordinary_air_heat_balance/predictor_corrector/lifecycle/prediction.rs']]
before = {}
for p in paths:
    b = check(entries[p]['source']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == entries[p]['final_sha256'] and len(b) == entries[p]['final_bytes']
    before[p] = b
    put('before/' + p, b)
texts = {p: b.decode() for p, b in before.items()}

p = paths[0]
texts[p] = swap(texts[p], '/// A borrow of actual Config storage, never a flags projection or snapshot.', '''/// Temporary disjoint references into the sole actual DataLoopNode.Node row.
/// Prediction rollback and setpoint handoff mutate this same physical owner.
pub(crate) struct SourceZoneAirNodeMut<'a> {
    pub(crate) temperature: &'a mut f64,
    pub(crate) humidity_ratio: &'a mut f64,
    pub(crate) enthalpy: &'a mut f64,
    pub(crate) temperature_setpoint: &'a mut f64,
}

/// A borrow of actual Config storage, never a flags projection or snapshot.''')
texts[p] = swap(texts[p], '    /// Actual VerifyControlledZoneForThermostat5702 exact-name search.', '''    pub(crate) fn source_zone_air_node_mut(
        &mut self,
        ordinal: i32,
    ) -> Result<SourceZoneAirNodeMut<'_>, super::selected_heat_balance_input::HeatBalanceInputError> {
        use super::selected_heat_balance_input::HeatBalanceInputError as E;
        let at = ordinal.checked_sub(1).and_then(|n| usize::try_from(n).ok())
            .ok_or(E::Unavailable("actual prediction Node positive ordinal"))?;
        let row = self.nodes.physical.as_deref_mut().and_then(|rows| rows.get_mut(at))
            .ok_or(E::Unavailable("actual prediction same physical Node allocation"))?;
        Ok(SourceZoneAirNodeMut {
            temperature: &mut row.temperature,
            humidity_ratio: &mut row.humidity_ratio,
            enthalpy: &mut row.enthalpy,
            temperature_setpoint: &mut row.temperature_setpoint,
        })
    }
    /// Actual VerifyControlledZoneForThermostat5702 exact-name search.''')
p = paths[1]
texts[p] = swap(texts[p], '    energyplus_psy_hg_air_fn_w_tdb, energyplus_psy_rho_air_fn_pb_tdb_w,', '    energyplus_psy_h_fn_tdb_w, energyplus_psy_hg_air_fn_w_tdb, energyplus_psy_rho_air_fn_pb_tdb_w,')
texts[p] = swap(texts[p], "pub(crate) equipment: &'a crate::heat_balance::ordinary_equipment::OrdinaryEquipment,", "pub(crate) equipment: &'a mut crate::heat_balance::ordinary_equipment::OrdinaryEquipment,")
p = paths[2]
texts[p] = swap(texts[p], '            equipment: self.equipment,', '            equipment: &mut *self.equipment,')
p = paths[3]
texts[p] = swap(texts[p], '//! Genuine uncontrolled ThirdOrder prediction and four-slot down-interpolation.', '//! Genuine zone-only ThirdOrder prediction, physical rollback and setpoint handoff.')
texts[p] = swap(texts[p], '''        owners: &SourceZoneAirOwners<'_, '_>,
    ) -> Result<(), Error> {
        if shorten {
            if zone(owners, number)?.system_zone_node_number > 0 {
                return Err(Error::Unavailable("positive Zone air-node rollback6779"));
            }''', '''        owners: &mut SourceZoneAirOwners<'_, '_>,
    ) -> Result<(), Error> {
        if shorten {
            let node_number = zone(owners, number)?.system_zone_node_number;
            if node_number > 0 {
                let node = owners.equipment.source_zone_air_node_mut(node_number)?;
                *node.temperature = self.xmat[0];
                *owners.fan.temp_tstat_air.as_mut()
                    .and_then(|rows| rows.get_mut(index(number).ok()?))
                    .ok_or(Error::Unavailable("actual rollback TempTstatAir6783"))? = self.xmat[0];
                *node.humidity_ratio = self.w_prev_zone_ts[0];
                *node.enthalpy = energyplus_psy_h_fn_tdb_w(self.xmat[0], self.w_prev_zone_ts[0]);
            }''')
texts[p] = swap(texts[p], '''            / owners.hvac.time_step_sys_seconds;
        self.calculate_source_zone_sums(false, number, controller, owners)?;''', '''            / owners.hvac.time_step_sys_seconds;
        // Actual Native3170 local. Its positive RoomAFN writer3205 remains
        // behind the genuine unrepresented RoomAir operation below.
        let rafn_fraction = 0.0;
        self.calculate_source_zone_sums(false, number, controller, owners)?;''')
texts[p] = swap(texts[p], '        self.calculate_source_predicted_sensible(number, controller, owners)?;', '        self.calculate_source_predicted_sensible(rafn_fraction, number, controller, owners)?;')
start = texts[p].index('    fn calculate_source_predicted_sensible(')
end = texts[p].index('    fn calculate_source_predicted_humidity(', start)
old = texts[p][start:end]
new = '''    fn calculate_source_predicted_sensible(
        &mut self,
        rafn_fraction: f64,
        number: i32,
        controller: &mut SourceZoneAirPredictorCorrector,
        owners: &mut SourceZoneAirOwners<'_, '_>,
    ) -> Result<(), Error> {
        let setpoints = owners.fan.thermostat.zone_tstat_setpoints.as_ref()
            .and_then(|rows| rows.get(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted zoneTstatSetpts6841"))?;
        let mut deadband_or_setback = false;
        let mut zone_setpoint = 0.0;
        let mut total_load = 0.0;
        let mut heating_load = 0.0;
        let mut cooling_load = 0.0;
        let node_number = zone(owners, number)?.system_zone_node_number;
        let kind = *owners.fan.thermostat.temp_control_type.as_ref()
            .and_then(|rows| rows.get(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted TempControlType6856"))?;
        match kind {
            0 => {} // Native Uncontrolled retains its actual zero procedure locals.
            1 => {
                if owners.control.zone_air_solution != SelectedZoneAirSolution::ThirdOrder {
                    return Err(Error::Unavailable("non-ThirdOrder predicted SingleHeat6870"));
                }
                heating_load = self.temp_dep_load * setpoints.setpt - self.temp_ind_load;
                if rafn_fraction > 0.0 {
                    heating_load /= rafn_fraction;
                }
                total_load = heating_load;
                zone_setpoint = setpoints.setpt;
                cooling_load = heating_load;
                if total_load <= 0.0 {
                    deadband_or_setback = true;
                }
            }
            2 => {
                if owners.control.zone_air_solution != SelectedZoneAirSolution::ThirdOrder {
                    return Err(Error::Unavailable("non-ThirdOrder predicted SingleCool6908"));
                }
                cooling_load = self.temp_dep_load * setpoints.setpt - self.temp_ind_load;
                if rafn_fraction > 0.0 {
                    // Literal Native6927 intentionally divides the heating local.
                    heating_load /= rafn_fraction;
                }
                let zone = zone(owners, number)?;
                if zone.has_adjusted_return_temperature_by_ite && !owners.clock.begin_sim_flag {
                    cooling_load = self.temp_dep_load * zone.adjusted_return_temperature_by_ite
                        - self.temp_ind_load;
                }
                total_load = cooling_load;
                zone_setpoint = setpoints.setpt;
                heating_load = cooling_load;
                if total_load >= 0.0 {
                    deadband_or_setback = true;
                }
            }
            3 => {
                if owners.control.zone_air_solution != SelectedZoneAirSolution::ThirdOrder {
                    return Err(Error::Unavailable("non-ThirdOrder predicted SingleHeatCool6949"));
                }
                heating_load = self.temp_dep_load * setpoints.setpt - self.temp_ind_load;
                cooling_load = self.temp_dep_load * setpoints.setpt - self.temp_ind_load;
                zone_setpoint = setpoints.setpt;
                if rafn_fraction > 0.0 {
                    heating_load /= rafn_fraction;
                }
                if rafn_fraction > 0.0 {
                    cooling_load /= rafn_fraction;
                }
                let zone = zone(owners, number)?;
                if zone.has_adjusted_return_temperature_by_ite && !owners.clock.begin_sim_flag {
                    cooling_load = self.temp_dep_load * zone.adjusted_return_temperature_by_ite
                        - self.temp_ind_load;
                }
                if heating_load > cooling_load {
                    return Err(Error::Unavailable("actual SingleHeatCool load inversion severe6995"));
                }
                if heating_load > 0.0 && cooling_load > 0.0 {
                    total_load = heating_load;
                } else if heating_load < 0.0 && cooling_load < 0.0 {
                    total_load = cooling_load;
                } else if heating_load <= 0.0 && cooling_load >= 0.0 {
                    total_load = 0.0;
                    if node_number > 0 {
                        zone_setpoint = *owners.equipment.source_zone_air_node_mut(node_number)?.temperature;
                        zone_setpoint = cpp_max(zone_setpoint, setpoints.setpt_lo);
                        zone_setpoint = cpp_min(zone_setpoint, setpoints.setpt_hi);
                    }
                    deadband_or_setback = true;
                } else {
                    return Err(Error::Unavailable("actual SingleHeatCool unanticipated-load severe7021"));
                }
            }
            4 => {
                if owners.control.zone_air_solution != SelectedZoneAirSolution::ThirdOrder {
                    return Err(Error::Unavailable("non-ThirdOrder predicted DualHeatCool7041"));
                }
                heating_load = self.temp_dep_load * setpoints.setpt_lo - self.temp_ind_load;
                cooling_load = self.temp_dep_load * setpoints.setpt_hi - self.temp_ind_load;
                if rafn_fraction > 0.0 {
                    heating_load /= rafn_fraction;
                }
                if rafn_fraction > 0.0 {
                    cooling_load /= rafn_fraction;
                }
                let zone = zone(owners, number)?;
                if zone.has_adjusted_return_temperature_by_ite && !owners.clock.begin_sim_flag {
                    cooling_load = self.temp_dep_load * zone.adjusted_return_temperature_by_ite
                        - self.temp_ind_load;
                }
                if heating_load > cooling_load {
                    return Err(Error::Unavailable("actual DualHeatCool load inversion severe7083"));
                }
                if heating_load > 0.0 && cooling_load > 0.0 {
                    total_load = heating_load;
                    zone_setpoint = setpoints.setpt_lo;
                } else if heating_load < 0.0 && cooling_load < 0.0 {
                    total_load = cooling_load;
                    zone_setpoint = setpoints.setpt_hi;
                } else if heating_load <= 0.0 && cooling_load >= 0.0 {
                    total_load = 0.0;
                    if node_number > 0 {
                        zone_setpoint = *owners.equipment.source_zone_air_node_mut(node_number)?.temperature;
                        zone_setpoint = cpp_max(zone_setpoint, setpoints.setpt_lo);
                        zone_setpoint = cpp_min(zone_setpoint, setpoints.setpt_hi);
                    }
                    deadband_or_setback = true;
                } else {
                    return Err(Error::Unavailable("actual DualHeatCool unanticipated-load severe7113"));
                }
            }
            _ => {} // Literal Native default performs no load/setpoint writes.
        }
        let _stage_number = controller.demand.zones.as_ref()
            .and_then(|rows| rows.get(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted ZoneSysEnergyDemand StageNum7141"))?
            .base.stage_num;
        if controller.flags.number_stage_zones > 0 {
            let staged = *controller.controls.stage_zone_logic.as_ref()
                .and_then(|rows| rows.get(index(number).ok()?))
                .ok_or(Error::Unavailable("actual StageZoneLogic7145"))?;
            if staged {
                return Err(Error::Unavailable("positive staged predicted load StageNum7146"));
            }
        }
        if node_number > 0 {
            *owners.equipment.source_zone_air_node_mut(node_number)?.temperature_setpoint = zone_setpoint;
        }
        *controller.demand.setback.as_mut()
            .and_then(|rows| rows.get_mut(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted Setback7228"))? = zone_setpoint > self.set_point_last;
        self.set_point_last = zone_setpoint;
        owners.fan.thermostat.zone_tstat_setpoints.as_mut()
            .and_then(|rows| rows.get_mut(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted Zone setpoint7231"))?.setpt = zone_setpoint;
        *controller.demand.deadband_or_setback.as_mut()
            .and_then(|rows| rows.get_mut(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted DeadBand7232"))? = deadband_or_setback;
        *controller.demand.current_deadband_or_setback.as_mut()
            .and_then(|rows| rows.get_mut(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted CurDeadBand7233"))? = deadband_or_setback;
        let zone = zone(owners, number)?;
        let correction = value(&owners.fan.thermostat.load_correction_factor, index(number)?)?;
        controller.demand.zones.as_mut()
            .and_then(|rows| rows.get_mut(index(number).ok()?))
            .ok_or(Error::Unavailable("actual predicted ZoneSysEnergyDemand7240"))?
            .report_source_predicted_sensible(total_load, heating_load, cooling_load, correction,
                zone.multiplier, zone.list_multiplier, zone.is_controlled)?;
        Ok(())
    }
'''
texts[p] = swap(texts[p], old, new)

apply_node = next(x for x in ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_bytes()).body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}; exec(compile(ast.Module(body=[apply_node], type_ignores=[]), '<own-literal>', 'exec'), ns)
rows = []
for i, p in enumerate(paths, 1):
    old, new = before[p], texts[p].encode()
    proposed = put('proposed/' + p, new)
    f = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p)).encode()
    inv = ''.join(difflib.unified_diff(new.decode().splitlines(keepends=True), old.decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p)).encode()
    assert ns['apply_literal'](old, f) == new and ns['apply_literal'](new, inv) == old
    parsed = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parsed.returncode == 0 and not parsed.stderr
    rows.append({'canonical_path': p, 'parent19': entries[p]['source'], 'before': ref(O / 'before' / p), 'proposed': proposed,
        'forward_diff': put(f'diffs/{i:02d}-forward.diff', f), 'inverse_diff': put(f'diffs/{i:02d}-inverse.diff', inv), 'two_literal_applications': True,
        'parse': {'exit_code': parsed.returncode, 'stdout': put(f'parse/{i:02d}.stdout', parsed.stdout), 'stderr': put(f'parse/{i:02d}.stderr', parsed.stderr)}})
wholes, extents = [], []
for p, ranges in {
    'src/EnergyPlus/ZoneTempPredictorCorrector.cc': [(3146, 3258), (6768, 6833), (6835, 7243)],
    'src/EnergyPlus/Psychrometrics.hh': [(648, 666), (679, 716)],
    'src/EnergyPlus/DataLoopNode.hh': [(356, 434), (439, 500)],
    'src/EnergyPlus/DataHVACGlobals.hh': [(112, 121)],
    'src/EnergyPlus/DataZoneEnergyDemands.cc': [(316, 362)],
}.items():
    data = subprocess.check_output(['git', 'show', PIN + ':' + p], cwd=N)
    assert data == (N / p).read_bytes()
    whole = put('Original-Git/' + p, data); wholes.append({'Native_path': p, 'whole': whole, 'pinned_revision': PIN})
    for a, b in ranges:
        literal = b''.join(data.splitlines(keepends=True)[a-1:b])
        extents.append({'Native_path': p, 'first': a, 'last': b, 'utf8_sha256': hashlib.sha256(literal).hexdigest(), 'literal': literal.decode()})
contexts = [P + p for p in ['ordinary_air_heat_balance/predictor_corrector/lifecycle/demand.rs', 'ordinary_air_heat_balance/predictor_corrector/demand.rs',
    'ordinary_air_heat_balance/predictor_corrector/lifecycle/controls.rs', 'ordinary_air_heat_balance/predictor_corrector/sums.rs',
    'ordinary_air_heat_balance/predictor_corrector/temperature.rs', 'ordinary_air_heat_balance/predictor_corrector/humidity.rs',
    'ordinary_equipment/source_nodes.rs', 'selected_heat_balance_input/zone/storage.rs', 'zone_predictor_corrector.rs', 'predicted_system_load.rs']]
contexts += ['crates/ep_runtime/src/psychrometrics.rs', 'crates/ep_runtime/src/psychrometrics/cp_cache.rs', 'crates/ep_runtime/src/weather_day/context.rs']
context_rows = []
for p in contexts:
    b = check(entries[p]['source']).read_bytes(); context_rows.append({'canonical_path': p, 'parent19': entries[p]['source'], 'frozen': put('context/' + p, b)})
draft = {'status': 'UNSEALED_DRAFT_NOT_COMPILED_OR_EXECUTED', 'parent19_producer': producer, 'parent19_plan': m['complete_final_compiler_Source_plan'],
    'files': rows, 'Source_files': 4, 'new_Source_files': 0, 'Native_commit': PIN, 'Native_wholes': wholes, 'Native_extents': doc('Native-extents.json', extents), 'unchanged_contexts': context_rows,
    'semantics': ['Literal Native3170 RAFN local0, only positive writer stays behind existing typed RoomAFN3193 boundary; no input-absence proxy.',
        'Same physical Node four borrowed fields; actual shortened-step Temp,TempTstatAir,HumRat,H rollback before interpolation. Actual working histories and numerical cache calls retained.',
        'ThirdOrder modes1/2/3/4 branch arithmetic/ITE/RAF ordering including literal SingleCool6927 heating-local division; no new formula facade, eager finite/range checking or epsilon fallback.',
        'Heating/cooling/deadband sign cases preserve equality, max(lo) then min(hi) using real Node.Temp only when selected. Native diagnostics/nonThirdOrder/positive staged rows stay typed at actual first unrepresented operation.',
        'Actual Node.TempSetPoint then Setback/setPointLast/fan scalar/deadband flags before same existing report_source_predicted_sensible correction/multiplier/sequence writes. Predicted humidity unchanged.',
        'No20 inlet/corrector or18 MoreNode implementation included.'],
    'limits': ['Await exact committed19 HEAD/actual19 accepted review before final seal; no compilation, Native execution, internal controlled-unit equivalence or fullB claim.',
        'Existing predicted_system_load.rs public DTO performs eager finite/range validation, node/scaling reads and separate owner projection, so it cannot replace same-owner Native procedure. Existing literal histories, normal psychrometric H/Cp and real demand reporter are reused.'],
    'main_mutations': 0, 'Cargo_Native_or_tests_executed': False, 'new_tests': 0, 'author_Source': ref(Path(__file__))}
print(json.dumps(doc('draft.json', draft)))

"""Prepare held publication21 only; no canonical/public writes or execution."""
from pathlib import Path
import ast,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
OUT=D/'controlled-prediction-publication-prepared-Outer-21'
old=D/'publish-thermostat-current-checkpoint-Outer-19-02.py'
new=D/'publish-controlled-prediction-checkpoint-Outer-21.py'
producer_path=D/'source-controlled-prediction-held-Peer-21/manifest.json'
assert not OUT.exists() and not new.exists()
def ref(p):
 data=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def write(p,value):p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
assert ref(old)['sha256']=='0ae6c3df5a9ac2387a0f0b40057fd9f0814abfd5c47c22b088882b375d46d336'
assert ref(producer_path)['sha256']=='c9bef4b49d4c26bfd32a4a517e632a84ef43d95f51a6fe8919cbe90836c1c186'
p=json.loads(producer_path.read_bytes())
text=old.read_bytes().decode('utf8')
replacements={
 'checkpoint19':'checkpoint21',
 'thermostat-current-publication-prepared-Outer-19-02':'controlled-prediction-publication-prepared-Outer-21',
 'SRC-06-canonical-thermostat-current-19':'SRC-06-canonical-controlled-prediction-21',
 'thermostat-current-publication-readback-Outer-19':'controlled-prediction-publication-readback-Outer-21',
 'd33979a3ef658a3ff3966ebf71010a107b639ce7':'80e68ac8b55fd21ff1c754849cbd34b23fafa45b',
 "len(producer['files']) == 12 and producer['existing_Source_files'] == 11 and producer['new_Source_files'] == 1":"len(producer['files']) == 4 and producer['existing_Source_files'] == 4 and producer['new_Source_files'] == 0",
 'Root-source-thermostat-current-actual-review-19':'Root-source-controlled-prediction-actual-review-21',
 'selected12_final_sources_exact':'selected4_final_sources_exact',
 'canonical-source-thermostat-current-B-NOLIMIT-24H-Root-19':'canonical-source-controlled-prediction-B-NOLIMIT-24H-Root-21',
 'canonical-source-thermostat-current-A-24H-Root-19':'canonical-source-controlled-prediction-A-24H-Root-21',
 'canonical19-finite':'canonical21-finite',
 '12 coherent Thermostat environment/current Sources':'4 coherent controlled predicted-load Sources',
 'src06-canonical-thermostat-current.v1':'src06-canonical-controlled-prediction.v1',
 'Genuine Source environment/current control path':'Genuine Source controlled predicted-load path',
 'positive thermostat Native numerical equivalence':'positive controlled predicted-load Native numerical equivalence',
 'canonical_thermostat_current_19':'canonical_controlled_prediction_21',
 '[Source 온도 설정값 경로 검증]':'[Source 제어 부하 예측 검증]',
 'accepted17':'accepted19',
 'equal17':'equal19',
 'two_owned_path_bridges':'two_owned_path_bridges',
}
for before,after in replacements.items():
 assert before in text,before
 text=text.replace(before,after)
before='''    assert ref(application_path)==template['Root_application']
    assert actual['author_Source']==template['Root_actual_checker_Source']
    assert application['author_Source']==template['Root_application_Source']
    for path in [application_path,checked(actual['author_Source']),checked(application['author_Source']),
                 checked(template['Root_launcher_Source'])]:add(path)
'''
after='''    assert application['base_HEAD']==head
    for row in [template['producer'],ref(peer_path),template['complete_plan']]:
        assert contains(application,row)
    for path in [application_path,checked(actual['author_Source']),checked(application['author_Source']),
                 checked(actual['launcher_Source'])]:add(path)
'''
assert text.count(before)==1;text=text.replace(before,after)
# The unchanged two-owned-field comparison predicate includes no equal17 token.
text=text.replace('whole_JSON_equal17_after_exactly_two_owned_path_field_bridges','whole_JSON_equal19_after_exactly_two_owned_path_field_bridges')
text=text.replace('full_runtime_equal17_after_two_owned_path_bridges','full_runtime_equal19_after_two_owned_path_bridges')
assert 'Root_application_Source' not in text and "template['Root_launcher_Source']" not in text
assert 'equal17' not in text and 'accepted17' not in text
ast.parse(text);new.write_bytes(text.encode('utf8'))
inputs={}
def add(row):
 path=R/row['path'];actual=ref(path);assert actual['sha256']==row['sha256'];assert path.suffix!='.zip'
 assert 'controlled-air-native' not in actual['path'];inputs[actual['path']]=actual
add(ref(producer_path))
for key in ['complete_final_compiler_Source_plan','whole_crates_API_inventory','integration_contract','Native_literal_extents','author_Source','sealer_Source']:
 add(p[key])
for row in p['Native_wholes']:add(row)
for row in p['unchanged_contexts']:add(row['whole'])
for row in p['files']:
 for key in ['before','proposed','literal_inverse','forward_diff','inverse_diff']:add(row[key])
 for key in ['stdout','stderr']:add(row['Source_only_parse'][key])
previous=ref(R/'energyplus_porting_plan/evidence/SRC-06-canonical-thermostat-current-19/summary.json');add(previous)
add(ref(Path(__file__)))
docs={
 'CHECKLIST.md':'제어 부하 예측과 실제 Node 설정값 갱신을 연결했습니다. B·A24 CLI 결과와 남은 경계는 공개 요약에 기록합니다.',
 'STATE_CONTRACTS.md':'예측은 같은 Node·온도 제어·수요 소유자를 사용합니다. 단계 단축 시 상태 복원과 부하·설정값 대입 순서를 보존합니다.',
 'cards/SRC-06.md':'실제 B 미완료 경계는 `{{actual_B_frontier}}`입니다. 내부 수치의 Native 검증과 전체 B 완료는 별도 과제로 남습니다.'}
assert len(set(docs.values()))==3
for value in docs.values():assert '?' not in value and '\ufffd' not in value and sum('\uac00'<=ch<='\ud7a3' for ch in value)>10
value={'schema':'src06-held-canonical21-publication-template.v1','status':'HELD_FOR_ROOT_REVIEW_ACTUAL_AND_PEER_HASHES_REQUIRED',
 'base_HEAD':p['base_HEAD'],'producer':ref(producer_path),'complete_plan':p['complete_final_compiler_Source_plan'],
 'previous_checkpoint':previous,'publisher_Source':ref(new),'publisher_parent_Source':ref(old),
 'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-controlled-prediction-actual-review-21/review.json',
 'Root_custody_at_publish':'Accepted actual.application -> application receipt and its author_Source; actual.author_Source -> checker; actual.launcher_Source -> launcher. All four directly byte-checked and archived; no current WIP alias or prior checkpoint Root source substituted.',
 'summary_template':{'A':'14/54','B':'14/64','changed_Rust_sources':4,'existing_Rust_sources':4,'new_Rust_sources':0,
  'new_test_functions':0,'actual_test_bodies_executed':0,'focused_validation_policy':'Two actual CLI runs B then A24. No unrelated test-profile rerun or habitual alltargets check.',
  'scope':'Genuine same-owner controlled predicted-load branches, live physical Node setpoint update and shortened-step Node/history rollback; exact existing demand reporting and ordered flags/multiplier/sequence writes. Controlled corrector/sums and MoreNode remain separate held work.',
  'full_B_or_finite15_completion_claim':False,'Native_harness_runtime_or_unit_equivalence_claim':False,'gate_changes':False,'policy_changes':False},
 'doc_appends':docs,'finite_archive_inputs':[row for _,row in sorted(inputs.items())],
 'finite_archive_input_count':len(inputs),'finite_archive_input_bytes':sum(row['bytes'] for row in inputs.values()),
 'publisher_executed':False,'canonical_docs_mutations':False,'Cargo_tests_Native_executed':False,'gate_changes':False}
OUT.mkdir();template=OUT/'publication-template.json';write(template,value)
helper=(D/'author-source-air-loops-Reviewer-01.py').read_text(encoding='utf8');node=next(n for n in ast.parse(helper).body if isinstance(n,ast.FunctionDef) and n.name=='apply_literal')
ns={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<literal-applier>','exec'),ns)
proof={}
for kind,left,right in [('forward',old.read_bytes(),new.read_bytes()),('inverse',new.read_bytes(),old.read_bytes())]:
 delta=''.join(difflib.unified_diff(left.decode().splitlines(True),right.decode().splitlines(True),fromfile=old.name,tofile=new.name,n=3)).encode()
 assert ns['apply_literal'](left,delta)==right
 path=OUT/(kind+'.diff');path.write_bytes(delta);proof[kind]=ref(path)
record=OUT/'publisher-parent-bridge.json';write(record,{'parent':ref(old),'successor':ref(new),'literal_applications':2,'changes':proof,
 'scope':'Checkpoint/path/count/proof19 metadata plus dynamic accepted Root-source custody only; archive/docs/plan algorithm unchanged.',
 'UTF8_Korean_appends_validated':True,'publisher_executed':False,'public_or_main_mutations':False})
print(json.dumps({'template':ref(template),'publisher':ref(new),'parent_bridge':ref(record)}))

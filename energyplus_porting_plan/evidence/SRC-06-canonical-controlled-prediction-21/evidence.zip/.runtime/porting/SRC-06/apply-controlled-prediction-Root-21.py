from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-controlled-prediction-application-21';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-controlled-prediction-held-Peer-21/manifest.json');assert mr['sha256']=='c9bef4b49d4c26bfd32a4a517e632a84ef43d95f51a6fe8919cbe90836c1c186';m=json.loads(checked(mr))
pr=ref(R/sys.argv[1]);assert pr['sha256']==sys.argv[2];peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet']==mr
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='80e68ac8b55fd21ff1c754849cbd34b23fafa45b' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
assert m['new_test_bodies']==0 and not m['Cargo_Native_or_tests_executed'] and not m['FP_tolerance_or_gate_changes']
parents={v['historical_path']:v for v in json.loads(checked(m['actual19_snapshot']))['files']}
inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4490 and set(parents)==inventory
for n,v in parents.items():assert(R/n).read_bytes()==checked(v['archive']) and(R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a,b=checked(f['before']),checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a
 if f['before_absent']:assert not(R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and(R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==4 and len(new)==0 and tests==0
native=R/'.reference/energyplus-src/26.1.0';rev=m['Native_commit'];assert rev=='6f2e40d10250a105b49966baa24d843711e61048';wholes={}
for v in m['Native_wholes']:
 b=checked(v);n=Path(v['path']).relative_to('.reference/energyplus-src/26.1.0').as_posix();assert b==subprocess.check_output(['git','show',rev+':'+n],cwd=native);wholes[n]=b
extents=json.loads(checked(m['Native_literal_extents']));assert len(wholes)==7 and len(extents)==12
for v in extents:
 b=b''.join(wholes[v['native_path']].splitlines(keepends=True)[v['first']-1:v['last']]);assert b.decode('utf8')==v['literal'] and hashlib.sha256(b).hexdigest()==v['utf8_sha256']
for k in ['actual19_review','actual19_complete_plan','actual19_B','actual19_A24','whole_crates_API_inventory','integration_contract','parent19_producer']:checked(m[k])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4490 and sum(n.endswith('.rs') for n in rows)==4477
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'];assert b==(checked(selected[n]['proposed']) if n in selected else(R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert(R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4490,final_inputs=4490,final_Rust_sources=4477,selected_Rust=4,new_Rust=0,literal_applications=8,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read all four Source diffs and entire new prediction body plus pinned Native modes0-4/actual RAFN constructor/ITE/stage read/deadband/late flags and rollback references. Same physical Node borrow, unchanged real demand reporter/cache/history, Native arithmetic and ordered writes; independent four-Source peer accepted before application. No unrelated test rerun, numeric shortcut, production oracle data, tolerance/gate change or positive Node reporting/fullB completion claim',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

"""Root-only guarded20-file application; no Git/Cargo/tests."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3]
def read(r):
 b=(ROOT/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');a=p.parse_args();assert a.apply
M=json.loads((ROOT/'.runtime/porting/SRC-06/canonical-source75-report-core-prepared-Reviewer-08/manifest.json').read_bytes())
assert subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip()==M['base_HEAD']
plan=json.loads(read(M['complete_compiler_Source_plan']))
for r in plan['files']:
 p=ROOT/r['path']
 if r['before_absent']:assert not p.exists()
 else:
  b=p.read_bytes();assert len(b)==r['before_bytes'] and hashlib.sha256(b).hexdigest()==r['before_sha256']
values=[]
for r in M['files']:
 b=read(r['proposed']);assert b==read(r['actual75']);values.append((ROOT/r['canonical_path'],b))
for p,b in values:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for r in plan['files']:
 b=(ROOT/r['path']).read_bytes();assert len(b)==r['planned_bytes'] and hashlib.sha256(b).hexdigest()==r['planned_sha256']
print(json.dumps(dict(applied_paths=len(values),compiler_inputs_verified=len(plan['files']),Git_mutated=False,Cargo_or_tests_executed=False)))

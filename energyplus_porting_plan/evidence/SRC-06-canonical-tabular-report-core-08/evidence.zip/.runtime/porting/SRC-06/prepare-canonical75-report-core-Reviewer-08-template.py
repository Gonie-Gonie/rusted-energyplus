"""Guarded preparation only, to run after Root75 actual review and comparison.
No canonical write occurs here. A separate Root-only --apply script is emitted.
"""
from pathlib import Path
import argparse,ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
OUT=D/'canonical-source75-report-core-prepared-Reviewer-08'
HEAD='da272c921d1bd4ff162f248dcf1fbf8685baf104'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r,base=ROOT):
 b=(base/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def load(p):return json.loads(p.read_bytes())
def git(*a):return subprocess.run(['git',*a],cwd=ROOT,capture_output=True)
def paths(w):
 p=subprocess.run(['rg','--files','--hidden','--no-ignore','-g','*.rs','-g','Cargo.toml','crates'],cwd=w,capture_output=True,check=True)
 return {n.replace('\\','/') for n in p.stdout.decode().splitlines()}|{n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'] if (w/n).is_file()}
def accepted(p):
 j=load(p);assert j.get('accepted') is True and not j.get('findings',[]);return j
ap=argparse.ArgumentParser();ap.add_argument('--prepare-after-actual75',action='store_true');ap.add_argument('--actual-review',required=True);ap.add_argument('--actual-comparison-review',required=True);args=ap.parse_args()
assert args.prepare_after_actual75,'Template must not run before actual75 accepted review'
assert git('rev-parse','HEAD').stdout.decode().strip()==HEAD and git('status','--porcelain').stdout==b''
mp=D/'ordinary-provider-assembly-Root-75/manifest.json';assert ref(mp)['sha256']=='e3255f1c535e9f7c866714e3fa4d54bb0899dbb1f7d629f812f6072d6f8fe698';M=load(mp);W=ROOT/M['workspace']
reviewp=ROOT/args.actual_review;comparisonp=ROOT/args.actual_comparison_review;accepted(reviewp);accepted(comparisonp)
checkp=W/'.runtime/porting/SRC-06/provider-assembly-all-targets-command-75/receipt.json'
clip=W/'.runtime/porting/SRC-06/provider-assembly-through-primary-A-24H-command-75/receipt.json'
check=load(checkp);cli=load(clip)
assert check['exit_code']==0 and cli['exit_code']==6
assert check['source_bytes_match_before_and_after'] and cli['source_bytes_match_before_and_after'] and check['source_snapshot']==cli['source_snapshot']
assert Path(check['cwd']).resolve()==W.resolve()==Path(cli['cwd']).resolve()
errorp=D/'through-primary-diagnostic-A-24H-Root-75/output/eplusrs.err'
assert b'actual WriteTabularReports5235 WriteComponentSizing entry' in errorp.read_bytes()
snapshot=load(W/cli['source_snapshot']['path']);index={r['historical_path']:r for r in snapshot['files']}
actual=paths(W);assert set(index)==actual
for n,r in index.items():assert read(r['archive'],W)==(W/n).read_bytes()
names=['ordinary-tabular-toc-held-Audit-01','ordinary-tabular-toc-caller-held-Audit-01','ordinary-veri-sum-held-Audit-04','ordinary-veri-sum-caller-held-Audit-01','ordinary-demand-summary-held-Audit-01','ordinary-demand-summary-caller-held-Audit-01','ordinary-source-energy-summary-held-Reviewer-02','ordinary-source-energy-caller-held-Audit-01']
packetps=[D/n/'manifest.json' for n in names];packets=[load(p) for p in packetps]
selected={r['canonical_path'] for p in packets for r in p['files']};assert len(selected)==20
dp=D/'ordinary-report-binary64-diagnostic-held-Reviewer-01/manifest.json';diagnostic=load(dp);excluded={r['canonical_path'] for r in diagnostic['files']};assert len(excluded)==9 and not selected&excluded
beforepaths=paths(ROOT);new={n for n in selected if not(ROOT/n).exists()};planned=beforepaths|new
assert len(beforepaths)==4440 and len(new)==10 and len(planned)==4450 and sum(n.endswith('.rs') for n in planned)==4437
assert actual-planned=={n for n in excluded if not(ROOT/n).exists()} and len(actual-planned)==1
tr=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(x for x in tr.body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
values={};patches={};gits=[]
for n in sorted(selected):
 a=(ROOT/n).read_bytes() if (ROOT/n).exists() else b'';z=(W/n).read_bytes();q=git('show',f'{HEAD}:{n}')
 assert (q.returncode==128 and n in new) or(q.returncode==0 and q.stdout==a)
 assert a!=z and a.count(b'#[test]')==z.count(b'#[test]')
 f=ns['diff'](a,z,n,'before','proposed');iv=ns['diff'](z,a,n,'proposed','before')
 assert ns['apply_literal'](a,f)==z and ns['apply_literal'](z,iv)==a
 values[n]=(a,z);patches[n]=(f,iv);gits.append(dict(path=n,revision=HEAD,exit_code=q.returncode))
plan=[];differences=[]
for n in sorted(planned):
 a=(ROOT/n).read_bytes() if (ROOT/n).exists() else None;z=values[n][1] if n in selected else a;assert z is not None
 exact=z==(W/n).read_bytes()
 if not exact:differences.append(n)
 plan.append(dict(path=n,before_absent=a is None,before_sha256=hashlib.sha256(a).hexdigest() if a is not None else None,before_bytes=len(a) if a is not None else None,planned_sha256=hashlib.sha256(z).hexdigest(),planned_bytes=len(z),actual75_sha256=hashlib.sha256((W/n).read_bytes()).hexdigest(),planned_exact_actual75=exact,selected_for_write=n in selected))
assert set(differences)=={n for n in excluded if(ROOT/n).exists()} and len(differences)==8
assert not OUT.exists();OUT.mkdir(parents=True)
def write(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,o):return write(n,(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode())
rows=[]
for i,n in enumerate(sorted(selected),1):
 rows.append(dict(canonical_path=n,before_absent=n in new,before=write('before/'+n,values[n][0]),literal_inverse=write('literal-inverse/'+n,values[n][0]),proposed=write('proposed/'+n,values[n][1]),complete_forward_diff=write(f'diffs/{i:02}.diff',patches[n][0]),complete_inverse_diff=write(f'diffs/{i:02}.inverse.diff',patches[n][1]),actual75=ref(W/n)))
planref=meta('complete-compiler-Source-plan.json',dict(schema='selective-canonical75-compiler-input-plan.v1',base_HEAD=HEAD,files=plan))
applyp=D/'apply-canonical75-report-core-prepared-Reviewer-08.py';assert not applyp.exists()
applyp.write_text('''"""Root-only guarded20-file application; no Git/Cargo/tests."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3]
def read(r):
 b=(ROOT/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');a=p.parse_args();assert a.apply
M=json.loads((ROOT/'.runtime/porting/SRC-06/canonical-source75-report-core-prepared-Reviewer-08/manifest.json').read_bytes())
assert subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip()==M['base_HEAD']
plan=json.loads(read(M['complete_compiler_Source_plan']))
for r in plan['files']:
 p=ROOT/r['path']
 if r['before_absent']:assert not p.exists()
 else:
  b=p.read_bytes();assert len(b)==r['before_bytes'] and hashlib.sha256(b).hexdigest()==r['before_sha256']
values=[]
for r in M['files']:
 b=read(r['proposed']);assert b==read(r['actual75']);values.append((ROOT/r['canonical_path'],b))
for p,b in values:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for r in plan['files']:
 b=(ROOT/r['path']).read_bytes();assert len(b)==r['planned_bytes'] and hashlib.sha256(b).hexdigest()==r['planned_sha256']
print(json.dumps(dict(applied_paths=len(values),compiler_inputs_verified=len(plan['files']),Git_mutated=False,Cargo_or_tests_executed=False)))
''',encoding='utf8',newline='\n')
result=meta('manifest.json',dict(schema='selective-canonical75-report-core-prepared.v1',status='PREPARED_ONLY_ROOT_APPLICATION_AND_CANONICAL_ALLTARGETS_CHECK_PENDING',base_HEAD=HEAD,actual75=ref(mp),actual75_check=ref(checkp),actual75_CLI=ref(clip),actual75_frontier=ref(errorp),actual75_independent_review=ref(reviewp),actual75_report_comparison_review=ref(comparisonp),packets=[ref(p) for p in packetps],files=rows,complete_compiler_Source_plan=planref,apply_script=ref(applyp),readonly_Git=gits,counts=dict(selected_paths=20,new_Rust=10,existing_Rust=10,literal_applications=40,canonical_before_inputs=4440,planned_inputs=4450,planned_Rust=4437,planned_inputs_exact_actual75=4442),excluded_diagnostic_paths=sorted(excluded),existing_diagnostic_paths_whole_canonical_unchanged=sorted(differences),absent_diagnostic_path=sorted(actual-planned),four_report_leaf_and_caller_excluded=True,canonical_pipeline_whole_unchanged=True,readonly_predefined_observer_not_promoted=True,new_test_bodies=0,normalizations=0,reviewer_applied_canonical=False,Cargo_Native_tests_executed=False,Git_mutated=False,numerical_gate_claim=False,qualifications=['Exact TOC/VeriSum/Demand/SourceEnergy leaf+caller union20 only, whole actual75 proposal bytes.','All9 binary64 diagnostic paths including pipeline enable and readonly snapshot remain excluded; normal pipeline behavior unchanged.','Actual75 stops5235; this is not a completed Source endrun or compatibility/numerical PASS.','Root canonical all-targets check required after guarded application. No new tests or repeated full-suite requirement added.'],author_Source=ref(Path(__file__))))
print(json.dumps(result))

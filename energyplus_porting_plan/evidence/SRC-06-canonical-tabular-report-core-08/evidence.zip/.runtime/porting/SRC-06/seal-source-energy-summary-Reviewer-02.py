"""Seal four finite Source paths; no canonical/Cargo/Native execution."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06';OUT=D/'ordinary-source-energy-summary-held-Reviewer-02';DRAFT=D/'ordinary-source-energy-draft-Reviewer-01';NROOT=ROOT/'.reference/energyplus-src/26.1.0'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(r):
 b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['bytes'];return b
def auth(name,h):
 p=D/name;assert ref(p)['sha256']==h;return p,json.loads(p.read_bytes())
def write(n,b):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def meta(n,r):return write(n,(json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode())
head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip();assert head=='da272c921d1bd4ff162f248dcf1fbf8685baf104'
native_pin='6f2e40d10250a105b49966baa24d843711e61048'
assert subprocess.run(['git','rev-parse','HEAD'],cwd=NROOT,capture_output=True,check=True).stdout.decode().strip()==native_pin
vp,V=auth('ordinary-veri-sum-held-Audit-04/manifest.json','d60b1bd039988b799e523c8fbea38f9985dce25f590dbc72e91415af865dbdf9')
peerp,peer=auth('Fix-ordinary-veri-sum-correction-Source-review-01/review.json','30d8f7f21dab9a5f2cd4855e58dd681bf880fe2258c69d5c976a99aa8e8e3b5c')
assert not peer.get('findings',[]) and (peer.get('accepted') is True or str(peer.get('decision',peer.get('verdict',''))).startswith('ACCEPTED'))
up,U=auth('ordinary-provider-assembly-Root-73/manifest.json','dcff2d9a8e92a939de178a4e53e7a0aa35adf14222726ee3fbe8e42ec2a49d39');W=ROOT/U['workspace']
ur,UR=auth('Reviewer-ordinary-provider-union73-Source-review-01/review.json','d5449d7ef46d5b6751ef515b49da60a3d4483674d6657963c1adc4c80c62b483');assert UR['accepted']
H='crates/ep_runtime/src/heat_balance/';main=H+'ordinary_tabular_reports.rs';beps=H+'ordinary_tabular_reports/beps_report.rs';energy=H+'ordinary_tabular_reports/source_energy_summary.rs';cols=H+'ordinary_tabular_reports/source_energy_summary/columns.rs'
vrows={r['canonical_path']:r for r in V['files']};parent={main:read(vrows[main]['proposed']),beps:read(vrows[beps]['proposed']),energy:b'',cols:b''}
old=parent[beps].decode();start=old.index('    fn determine_source_building_floor_area(');end=old.index('\n    }\n}',start)+len('\n    }');block=old[start:end]
body_start=block.index('        self.input_state.building_gross_floor_area');body=block[body_start:]
assert body.count('o.globals')==1 and body.count('let zone = o\n                .zones\n                .zones')==1
shared_body=body.replace('o.globals','globals').replace('let zone = o\n                .zones\n                .zones','let zone = zones\n                .zones')
wrapper=block[:body_start]+'        self.determine_source_building_floor_area_from_owners(o.globals, o.zones)\n    }'
shared='''

    // One actual DetermineBuildingFloorArea18104-18169 body, shared callers.
    pub(super) fn determine_source_building_floor_area_from_owners(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
        zones: &SelectedZoneInputOwners,
    ) -> Result<(), Error> {
'''+shared_body
newblock=wrapper+shared
newbeps=old[:start]+newblock+old[end:];assert newbeps.replace(newblock,block,1)==old
# The existing appended RealToStr forwarding function stays byte-exact.
marker='// Same accepted Actual RealToStr18578-18624 kernel shared with VeriSum.'
assert old[old.index(marker):]==newbeps[newbeps.index(marker):]
proposal={main:parent[main]+b'\nmod source_energy_summary;\n',beps:newbeps.encode(),energy:(DRAFT/'source_energy_summary.rs').read_bytes(),cols:(DRAFT/'source_energy_summary/columns.rs').read_bytes()}
for n,b in proposal.items():
 q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=b,capture_output=True);assert q.returncode==0,(n,q.stderr.decode())
 assert b.count(b'#[test]')==parent[n].count(b'#[test]')
tr=ast.parse((D/'author-source-air-loops-Reviewer-01.py').read_bytes());ns={'re':re,'difflib':difflib}
for name in ['diff','apply_literal']:
 f=next(x for x in tr.body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
assert not OUT.exists();OUT.mkdir(parents=True);files=[];apps=0;gits=[]
for i,(n,z) in enumerate(proposal.items(),1):
 cp=ROOT/n;a=cp.read_bytes() if cp.exists() else b'';p=parent[n];g=subprocess.run(['git','show',f'{head}:{n}'],cwd=ROOT,capture_output=True)
 assert (cp.exists() and g.returncode==0 and g.stdout==a) or (not cp.exists() and g.returncode==128)
 row=dict(canonical_path=n,canonical_before=ref(cp) if cp.exists() else None,canonical_absent_observed=not cp.exists(),Git_base_authentication=dict(revision=head,exit_code=g.returncode),parent_proposed=vrows[n]['proposed'] if n in vrows else None,parent_absent_observed=not bool(p),before=write('before/'+n,a),literal_inverse=write('literal-inverse/'+n,a),parent_before=write('parent-before/'+n,p),literal_parent_inverse=write('literal-parent-inverse/'+n,p),proposed=write('proposed/'+n,z))
 for before,fwd,inv in [(a,'complete_forward_diff','complete_inverse_diff'),(p,'parent_forward_diff','parent_inverse_diff')]:
  fb=ns['diff'](before,z,n,fwd+'-before',fwd+'-after');ib=ns['diff'](z,before,n,inv+'-before',inv+'-after');assert ns['apply_literal'](before,fb)==z and ns['apply_literal'](z,ib)==before;apps+=2
  row[fwd]=write(f'diffs/{i:02}-{fwd}.diff',fb);row[inv]=write(f'diffs/{i:02}-{inv}.diff',ib)
 files.append(row);gits.append(dict(path=n,revision=head,exit_code=g.returncode))
authorities=[]
for source,lo,hi in [('OutputReportTabular.cc',9926,10321),('OutputReportTabular.cc',18104,18169),('OutputReportTabular.cc',18578,18624),('OutputReportTabular.cc',5227,5235),('OutputReportTabular.cc',3962,4084),('OutputReportTabular.cc',1805,1820),('OutputReportTabular.hh',1170,1204),('DataGlobalConstants.hh',64,83)]:
 p=NROOT/'src/EnergyPlus'/source;b=p.read_bytes();lines=b.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines);literal=b''.join(lines[lo-1:hi]);authorities.append(dict(source=ref(p),first_line=lo,last_line=hi,literal_excerpt=write(f'Original/{source}-{lo}-{hi}.txt',literal)))
native=(NROOT/'src/EnergyPlus/OutputReportTabular.cc').read_bytes().splitlines();declarations=[]
for name,lo,hi in [('ENERGY_KWH',10072,10084),('ENERGY_GJ',10117,10129),('AREA_KWH',10174,10186),('AREA_MJ',10219,10231),('END_USE_ROWS',10051,10064)]:
 values=[]
 for line in native[lo-1:hi]:
  m=re.search(rb'= "([^"]+)";',line);assert m;values.append(m[1].decode('ascii'))
 text=proposal[cols].decode();at=text.index('const '+name+':');body_at=text.index('= [',at)+3;end=text.index('];',body_at);actual=re.findall(r'b"([^"]*)"',text[body_at:end]);assert actual==values
 declarations.append(dict(name=name,first_line=lo,last_line=hi,values=values))
mapping=[]
for line in native[9974:9988]:
 m=re.search(rb'collapsedEndUse\((\d+), jEndUse\) = ort->gatherEndUseBySourceBEPS\((\d+), jEndUse\)',line);assert m;mapping.append(int(m[2]))
assert mapping==[1,2,6,8,9,10,11,12,13,14,3,4,5,7]
readonly=[]
for n in [H+'ordinary_tabular_reports/state.rs',H+'ordinary_tabular_reports/source_demand.rs',H+'ordinary_tabular_reports/beps.rs',H+'ordinary_tabular_reports/style_passes.rs',H+'ordinary_tabular_reports/writers/table.rs',H+'radiation/ordinary/solar_timestep/array.rs']:
 readonly.append(ref(W/n))
api=meta('API.json',dict(entry='SourceTabularReports::write_source_energy_end_use_summary(&mut self,&mut SourceBepsReportOwners)->Result<(),HeatBalanceInputError>',same_borrowed_bundle=True,new_retained_owners=0,new_constructor_fields=0,shared_floor_helper='pub(super) determine_source_building_floor_area_from_owners(&mut self,&SelectedHeatBalanceGlobals,&SelectedZoneInputOwners)->Result<(),Error>',shared_floor_proof='Existing BEPS private wrapper delegates at its original location; one identical original body changes only the two borrowed owner access bindings. Existing VeriSum RealToStr wrapper whole suffix is unchanged.',actual_caller='Native5234 after Demand5233, before ComponentSizing5235. Caller not included.',tables=['Source Energy End Use Components Summary','Source Energy End Use Components Per Conditioned Floor Area','Source Energy End Use Components Per Total Floor Area'],positive_boundaries=['IP10016/10020 actual first getSpecificUnitDivider after headers/floor/collapse','formatReals=false actual existing unrounded formatter boundary after body operands','SQLite10151/10258/10300 after preceding real tabular writes','JSON10161/10268/10310 on actual same results option'],finite_scope='Finite supported default/JtoKWH unit styles; actual persistent gathered source arrays, same live zones/globals and three complete finite tabular outputs. No IP factor/format/sink default is guessed.'))
checks=meta('checks.json',dict(full_Source_files=4,new_Source_files=2,changed_parents=2,literal_applications=apps,Git=gits,new_Source_rustfmt_stdin_parse=4,no_Rustc_Cargo_or_simulation=True,entire_BEPS_parent_restored_after_factor_inverse=True,old_RealToStr_forwarder_whole_suffix_unchanged=True,Native_column_and_row_declarations=declarations,source_resource_permutation=mapping,numeric_scratch_allocations_in_order=['useVal(14,15)','collapsedTotal(14)','collapsedEndUse(14,14)','collapsedSub(actualMaxNumSubcategories,14,14)'],order='guard→four allocations→headers/text→same floor helper once→each actual style:source collapse→unit conversion→string/width/body allocations→useVal→labels→first table→conditioned normalized→gross normalized',operator_qualification='Preserve /= (large / adjust). Default values divide first by1e6, then first report cells by1000; normalized cells retain MJ/actual converted area. No direct1e9/168 shortcut or report-value copyback.',preexisting_producer_refs=readonly,no_test_bodies_added=True))
assert apps==16
result=meta('manifest.json',dict(schema='src06-ordinary-source-energy-summary-held.v1',status='HELD genuine three SourceEnergy tables; independent peer and actual5234 caller still required',base_HEAD=head,Original_version='26.1.0',Original_commit=native_pin,files=files,Original_authority=authorities,dependencies=[ref(vp),ref(peerp),ref(up),ref(ur)],read_only_existing_producer_refs=readonly,API=api,checks=checks,author_Source=ref(Path(__file__)),retained_partial_author01=dict(Source=ref(D/'seal-source-energy-summary-Reviewer-01.py'),path='.runtime/porting/SRC-06/ordinary-source-energy-summary-held-Reviewer-01',manifest_exists=False,failure='Column declaration verifier matched ]; in the Rust array element type before reaching its initializer; failed after four Source/16 diff applications/eight strict Native excerpts, before manifest/API/checks. No Source bytes changed in correction.'),scope='Four Source paths only; no Demand state/Date/FillRowHead, endrun parent, pipeline, schedule, physics or report-core-owner modifications.',qualifications=['Actual gathered source arrays use existing Source native constructor/reset/Zone-timestep producer lineage, not absent-input zero inference or copied BEPS report answers.','Four genuine local numeric allocations are represented; the otherwise unused collapsedSub allocation is preserved. Numeric cells are unset until actual Native writes, with no new retained numeric owner.','All source-resource and field labels are actual pinned declarations. IP/SQL/RF/unformatted positive operations retain explicit first-unavailable boundaries and preceding persistent/file effects.','Inherited formatter finite domain and physical write-failure continuation limitations remain; no generic exception parity or all-unit-style claim.','Shared floor factor does not alter any arithmetic, predicate, loop order or original BEPS call site. The VeriSum04 parent/source peer is directly bound; all other siblings remain byte-exact.','No actual CLI, Native, Rustc, Cargo, tests, canonical/Git mutation, full-run result, or numerical gate is claimed.'],canonical_mutations=0,Git_mutated=False,Cargo_Native_or_tests_executed=False,new_test_bodies=0,numerical_PASS_or_gate_claim=False))
print(json.dumps(result))

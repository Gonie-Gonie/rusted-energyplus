from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-actual-tabular74-comparison-review-01';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
def walk(v):
    if isinstance(v,dict):
        if 'path' in v and 'sha256' in v:checked(v)
        for x in v.values():walk(x)
    elif isinstance(v,list):
        for x in v:walk(x)
mp=BASE/'Audit-actual-tabular-five-format-comparison-74-01/comparison.json';assert ref(mp)['sha256']=='0cadc43d4f5fdc0e4952d57ad181414712387ebef2fbd0327fe2f681f2d55f53'
m=json.loads(mp.read_bytes());walk(m);total=exact=unequal=0
for f in m['physical_formats']:
    s=checked(f['Source']).splitlines(keepends=True);n=checked(f['Native']).splitlines(keepends=True)
    assert len(s)==f['Source_physical_lines'] and len(n)==f['Native_complete_physical_lines'] and len(n)>=len(s)
    mismatches={i+1:(a,b) for i,(a,b) in enumerate(zip(s,n)) if a!=b}
    assert len(mismatches)==f['raw_mismatching_prefix_lines']==len(f['mismatches'])
    assert set(mismatches)=={x['line'] for x in f['mismatches']}
    for r in f['mismatches']:
        a,b=mismatches[r['line']];assert a==checked(r['Source_complete_raw'])==bytes.fromhex(r['Source_raw_hex']);assert b==checked(r['Native_complete_raw'])==bytes.fromhex(r['Native_raw_hex'])
    total+=len(s);unequal+=len(mismatches);exact+=len(s)-len(mismatches)
assert (total,exact,unequal)==(3895,3880,15)
for r in m['Source73_unchanged_whole_outputs']:assert checked(r['Source74'])==checked(r['Source73'])
d=json.loads(checked(m['predefined_snapshot_delta']));walk(d)
s=json.loads(checked(d['Source74']));p=json.loads(checked(d['Source73']))
assert s['registry']==p['registry'] and s['timing']==p['timing'] and s['schema']==p['schema']
assert s['table']['num_table_entry']==732 and p['table']['num_table_entry']==726
assert s['table']['size_table_entry']==p['table']['size_table_entry']==800
sr=s['table']['allocated_rows_in_original_order'];pr=p['table']['allocated_rows_in_original_order'];assert len(sr)==len(pr)==800
assert [i for i,(a,b) in enumerate(zip(sr,pr)) if a!=b]==list(range(726,732))
for r in d['only_six_actual_appended_entries']:
    i=r['ordinal']-1;assert sr[i]==r['after74'] and pr[i]==r['before73']
assert [x['index_column'] for x in sr[726:732]]==[895,896,897,895,896,897]
assert [x['object_name'] for x in sr[726:732]]==['ZONE ONE']*3+['Totals']*3
OUT.mkdir();p=OUT/'review.json';p.write_text(json.dumps(dict(accepted=True,comparison=ref(mp),raw_prefix_lines_independently_compared=total,exact=exact,unequal_metadata_lines=unequal,full_mismatch_bytes_and_hex_verified=True,unchanged73_outputs=len(m['Source73_unchanged_whole_outputs']),independently_verified_six_entry_delta=True,whole_run_complete=False,numerical_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve())),indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(p)))

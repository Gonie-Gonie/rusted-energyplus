from pathlib import Path
import ast,json,hashlib,difflib,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8');R=Path.cwd();B=R/'.runtime/porting/SRC-06';O=B/'ordinary-source-energy-caller-held-Audit-01';assert not O.exists()
tree=ast.parse((B/'seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<custody>','exec'),ns);ref=ns['ref'];row=ns['row']
tree=ast.parse((B/'seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pns={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<diff>','exec'),pns)
c='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/endrun_prefix.rs';parent=B/'ordinary-demand-summary-caller-held-Audit-01/proposed'/c
old=parent.read_text(encoding='utf8');removed='            return Err(unavailable("actual WriteTabularReports5234 WriteSourceEnergyEndUseSummary entry"));';assert old.count(removed)==1
added='''            session.tabular.write_source_energy_end_use_summary(
                &mut crate::heat_balance::ordinary_tabular_reports::SourceBepsReportOwners {
                    registration: &reports.output_registration,
                    zones: required(
                        reports.selected_zone_input.as_ref(),
                        "actual same Zones before SourceEnergy5234",
                    )?,
                    globals,
                    facility: required(
                        reports.facility_electric_service.as_ref(),
                        "actual same FacilityElectricService before SourceEnergy5234",
                    )?,
                    water: &session.hvac.ancillary.water.data,
                    hvac: &required(
                        reports.selected_simulation_startup.as_ref(),
                        "actual same HVAC globals before SourceEnergy5234",
                    )?.hvac_globals,
                    predefined_summary: &session.comfort_summary,
                    registry: &mut reports.registry,
                    table: &mut reports.table,
                    schedules: required(
                        reports.selected_schedule_manager.as_ref(),
                        "actual same schedules before SourceEnergy5234",
                    )?,
                    results: &reports.source_results_framework,
                    sqlite: &reports.source_sqlite,
                    writer: crate::heat_balance::ordinary_tabular_reports::SourceTabularWriterOwners {
                        monetary: &reports.cost_estimate_monetary,
                        flags: SourceDiagnosticFlags {
                            kickoff: &globals.kickoff_simulation,
                            developer: &project.system.developer_flag,
                            warmup: &weather.state.global.warmup_flag,
                            doing_sizing: &globals.doing_sizing,
                        },
                        backend: &mut *backend,
                    },
                },
            ).map_err(hb_input_error)?;
            return Err(unavailable("actual WriteTabularReports5235 WriteComponentSizing entry"));'''
new=old.replace(removed,added,1);assert new.replace(added,removed,1)==old
peer=B/'Audit-ordinary-source-energy-summary-Source-review-01/review.json';assert ref(peer)['sha256']=='f617671586f162e20166fcd34829bc52e217ad165b07bd304ffcf751fe16f236';pr=json.loads(peer.read_bytes());assert pr['accepted'] and not pr['findings']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();assert head=='da272c921d1bd4ff162f248dcf1fbf8685baf104';assert subprocess.check_output(['git','show',head+':'+c],cwd=R)==(R/c).read_bytes()
proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=new.encode(),capture_output=True);assert proc.returncode==0,proc.stderr
assert old.count('#[test]')==new.count('#[test]') and added.count('backend: &mut *backend')==1
O.mkdir();row(c,new.encode(),parent);v=ns['rows'][0]
for a,k,b in [(v['before'],'complete_forward_diff',v['proposed']),(v['proposed'],'complete_inverse_diff',v['before']),(v['parent_before'],'parent_forward_diff',v['proposed']),(v['proposed'],'parent_inverse_diff',v['parent_before'])]:assert pns['apply_diff']((R/a['path']).read_bytes(),(R/v[k]['path']).read_bytes())==(R/b['path']).read_bytes()
original=[];nroot=R/'.reference/energyplus-src/26.1.0';pin='6f2e40d10250a105b49966baa24d843711e61048'
for a,b in [(5212,5241),(9941,9975)]:
 p=nroot/'src/EnergyPlus/OutputReportTabular.cc';ls=p.read_bytes().splitlines(True);assert 1<=a<=b<=len(ls);q=O/'Original'/f'OutputReportTabular.cc-{a}-{b}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(ls[a-1:b]));original.append({'source':ref(p),'first_line':a,'last_line':b,'literal_excerpt':ref(q)})
assert subprocess.check_output(['git','-C',str(nroot),'show',pin+':src/EnergyPlus/OutputReportTabular.cc'])==p.read_bytes()
deps=[ref(B/name) for name in ['ordinary-demand-summary-caller-held-Audit-01/manifest.json','ordinary-demand-summary-held-Audit-01/manifest.json','Fix-ordinary-demand-summary-Source-review-01/review.json','ordinary-source-energy-summary-held-Reviewer-02/manifest.json','Audit-ordinary-source-energy-summary-Source-review-01/review.json']]
m={'schema':'src06-tabular5234-same-owner-caller-held.v1','status':'HELD caller-only to independently accepted SourceEnergy02; Root peer/compiler/runtime pending','base_HEAD':head,'Original_commit':pin,'files':ns['rows'],'Original_authority':original,'dependencies':deps,'literal_applications':4,'whole_parent_recoveries':1,'Source_parse_only_exit':0,'current_Git_and_worktree_bytes_equal':True,'actual_call_order':'Existing full5212-5233 prefix unchanged; call same session.tabular SourceEnergy5234 with a new short SourceBepsReportOwners borrow over the same actual fields, then retain typed5235 ComponentSizing boundary. False WriteTabularFiles path5278 unchanged.','owner_mapping':{'registration':'reports.output_registration','zones':'reports.selected_zone_input','globals':'same earlier globals borrow','facility':'reports.facility_electric_service','water':'session.hvac.ancillary.water.data','hvac':'reports.selected_simulation_startup.hvac_globals','predefined_summary':'session.comfort_summary','registry':'reports.registry','table':'reports.table','schedules':'reports.selected_schedule_manager','results':'reports.source_results_framework','sqlite':'reports.source_sqlite','writer':'same reports.cost_estimate_monetary + actual globals/project/weather diagnostic flag references + &mut *backend'},'parent_Demand_caller_peer_pending_explicit':True,'no_flags_cloned_or_reset':True,'Cargo_Native_or_Git_mutations':False,'new_test_bodies':0,'canonical_mutations':0,'numerical_or_whole_run_claim':False,'author_Source':ref(Path(__file__).resolve())}
(O/'manifest.json').write_bytes((json.dumps(m,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

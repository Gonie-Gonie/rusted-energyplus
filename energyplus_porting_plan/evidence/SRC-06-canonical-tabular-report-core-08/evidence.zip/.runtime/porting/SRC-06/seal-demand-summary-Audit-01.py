from pathlib import Path
import ast,json,hashlib,difflib,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8');R=Path.cwd();D=R/'.runtime/porting/SRC-06/ordinary-demand-summary-draft-Audit-01';O=R/'.runtime/porting/SRC-06/ordinary-demand-summary-held-Audit-01';assert not O.exists()
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<custody>','exec'),ns);ref=ns['ref'];row=ns['row']
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pure={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<diff>','exec'),pure);apply=pure['apply_diff']
def auth(d):
 p=R/d['path'];assert ref(p)==d,d;return p
parents=json.loads((D/'parents.json').read_bytes());recover=[]
loop='''            let mut current = Vec::new();
            for row in &mut row_temp {
                if row.is_empty() {
                    *row = current.clone();
                } else {
                    current = row.clone();
                }
            }
'''
for c,d in parents.items():
 old=auth(d).read_text(encoding='utf8');new=(D/'proposed'/c).read_text(encoding='utf8');s=new
 if c.endswith('/state.rs'):
  for a in ['    // Native OutputReportTabular.hh1398 default std::string; no retained writer in this module.\n    pub(super) footnote: Vec<u8>,\n','            footnote: Vec::new(),\n']:
   assert s.count(a)==1;s=s.replace(a,'',1)
 elif c.endswith('/remaining.rs'):
  a='pub(super) fn source_date_to_string(coded_date: i32)';assert s.count(a)==1;s=s.replace(a,a.replace('pub(super) ',''),1)
 elif c.endswith('/subcategories.rs'):
  a='            super::super::writers::source_fill_row_head(&mut row_temp);\n';assert s.count(a)==1;s=s.replace(a,loop,1)
 else:assert s.startswith(old);s=s[:len(old)]
 assert s==old,c;recover.append({'canonical_path':c,'whole_parent':d,'exact_whole_parent_recovered':True})
O.mkdir()
for p in sorted((D/'proposed').rglob('*.rs')):
 c=p.relative_to(D/'proposed').as_posix();row(c,p.read_bytes(),auth(parents[c]) if c in parents else None)
assert len(ns['rows'])==7
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();git=[];parses=[];applications=0
for v in ns['rows']:
 for a,k,b in [(v['before'],'complete_forward_diff',v['proposed']),(v['proposed'],'complete_inverse_diff',v['before']),(v['parent_before'],'parent_forward_diff',v['proposed']),(v['proposed'],'parent_inverse_diff',v['parent_before'])]:assert apply(auth(a).read_bytes(),auth(v[k]).read_bytes())==auth(b).read_bytes();applications+=1
 c=v['canonical_path'];proc=subprocess.run(['git','show',head+':'+c],cwd=R,capture_output=True)
 if v['canonical_absent_observed']:assert proc.returncode!=0;git.append({'canonical_path':c,'commit':head,'absent':True})
 else:assert proc.returncode==0 and proc.stdout==auth(v['before']).read_bytes(),c;git.append({'canonical_path':c,'commit':head,'current_Git_whole_equal':True,'before':v['before'],'overlay_parent':v['parent_proposed']})
 proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=auth(v['proposed']).read_bytes(),capture_output=True);assert proc.returncode==0,proc.stderr;parses.append({'Source':v['proposed'],'exit':0,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest()})
N=R/'.reference/energyplus-src/26.1.0';original=[]
for name,a,b in [('OutputReportTabular.cc',10323,10820),('OutputReportTabular.cc',18650,18684),('OutputReportTabular.cc',18171,18183),('OutputReportTabular.cc',4165,4225),('OutputReportTabular.cc',5198,5241),('OutputReportTabular.hh',1388,1402),('General.cc',1004,1039),('OutputReportPredefined.hh',1640,1695),('OutputReportPredefined.cc',1766,1915)]:
 p=N/'src/EnergyPlus'/name;ls=p.read_bytes().splitlines(True);assert 1<=a<=b<=len(ls),(name,a,b,len(ls));q=O/'Original'/f'{name}-{a}-{b}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(ls[a-1:b]));original.append({'source':ref(p),'first_line':a,'last_line':b,'literal_excerpt':ref(q)})
W=R/'.runtime/porting/SRC-06/ordinary-provider-assembly-Root-73/workspace';actual=[]
for c in ['crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/source_demand.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/beps.rs','crates/ep_runtime/src/heat_balance/source_output_registration.rs','crates/ep_runtime/src/heat_balance/ctf_reports.rs','crates/ep_runtime/src/heat_balance/predefined_tables.rs']:
 actual.append(ref(W/c))
source=(D/'proposed/crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/demand_summary.rs').read_text(encoding='utf8');normalized=re.sub(r'\s+','',source).replace(',]',']');assert 'gather_demand_end_use_sub.read([subasusize,end_use,source])' in normalized and 'gather_demand_ind_end_use_sub.read([subasusize,end_use,source])' in normalized
observations=json.loads((D/'Native-author-observations.json').read_bytes());assert observations['no_DetermineBuildingFloorArea_in_Demand']
api={'entry':'SourceTabularReports::write_source_demand_end_use_summary(&mut self,&mut SourceDemandReportOwners)->Result<(),HeatBalanceInputError>','owners':'Same actual OutputRegistration/category/maxSub state, Registry/table, Results/SQLite and writer monetary/short live flags/backend; retained TAB gatherDemand/individualPeak/timeStamp/needOtherRowLEED45/footnote remain sole receiver fields. No floor-area call or duplicate scientific owner.','body':'Actual10323-10820 full finite formatted nonIP route: eight numeric scratch allocations, 14resource collapse/order/units operations, End Uses +End Uses By Subcategory physical tables, real DateToString peak entries, unconditional actual text-row/slice temporaries, full post-style LEED residual and13resource demand PreDef writes.','positive_boundaries':'Actual IP getSpecificUnitMultiplier10407/10410 first operation after genuine collapsed totals/timestamps and local conversion reset; true SQL/JSON children stop at original calls after previous physical effects/temp transformations. Existing RealToStr/predefined representation and OS/typed diagnostic domains retained.','3D_indices':'Both actual producer SourceDemand indices and Native4190/4217 are [subcategory,end_use,resource]; both new collapsed reads use that order and destinations [subcategory,end_use,display_resource]. No square-dimension inference.','ctor':'One same TAB raw-byte footnote, Native.hh1398 std::string defaultempty. Full Native direct-field census found only two reads10600/10721; BEPS principal-heat footnote is a distinct local. No default is seeded at reporting time.','immutable_text_borrow_bridge':'At each actual WriteTable argument position a short local copy of immutable footnote bytes resolves Rust &mutTAB aliasing; this is neither a retained mirror nor a flag/value snapshot. Native has no intervening retained footnote writer, and selected writer paths do not mutate that field. No clock/count/scientific owner is cloned.','shared_kernels':'Existing Remaining DateToString only gains visibility; existing BEPS inline FillRowHead becomes the same shared writer helper, and exact call expansion restores its whole old body. RealToStr is the accepted BEPS/VeriSum wrapper; no duplicate numerical formatter.','important_order':['Native permutation [1,2,6,8,9,10,11,12,13,14,3,4,5,7].','Demand individual peaks deliberately use only 1/ipElectricityConversion, retaining no powerConversion multiplication for other resources.','BEPS needOtherRowLEED45 live flags are read after the LAST style; no default false or recomputation from the new report.','LEED residual negative values clamp only with actual <0 condition; zero/negative-zero and exact sum/subtraction order preserved.','All final PreDef calls use existing default2 precision and actual named IDs.','Actual temporary rowHead copy→FillRowHead→colon/subcategory append→column/body slices→SQL→JSON→explicit three deallocations retained.'],'caller':'Leaf only; must attach after accepted VeriSum5232 at real5233 and preserve5234 SourceEnergy next.','Source_only':True,'new_test_bodies':0,'numerical_or_whole_run_or_gate_claim':False}
(O/'API.json').write_bytes((json.dumps(api,indent=2)+'\n').encode());checks={'applications':applications,'whole_parent_recoveries':recover,'read_only_Git':git,'Source_parse_only':parses,'actual_producer_refs':actual,'Native_3D_and_LEED_order_author_observations':ref(D/'Native-author-observations.json'),'common_FillRowHead_full_expansion_restores_BEPS_parent':True,'Source_new_test_bodies':0,'Cargo_or_Native_executed':False}
(O/'checks.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode());deps=[ref(R/'.runtime/porting/SRC-06'/name) for name in ['ordinary-veri-sum-held-Audit-04/manifest.json','Fix-ordinary-veri-sum-correction-Source-review-01/review.json','ordinary-beps-report-held-Audit-04/manifest.json','Fix-ordinary-beps-report-correction-Source-review-01/review.json','ordinary-tabular-writers-held-Audit-01/manifest.json','Fix-ordinary-tabular-writers-Source-review-02/review.json','ordinary-remaining-final-suffix-held-Reviewer-01/manifest.json','ordinary-provider-assembly-Root-73/manifest.json']]
m={'schema':'src06-coherent-selected-demand-summary-held.v1','status':'HELD complete selected literal Demand report; independent full Source/Native peer/compiler/caller required','base_HEAD':head,'Original_commit':'6f2e40d10250a105b49966baa24d843711e61048','files':ns['rows'],'Original_authority':original,'dependencies':deps,'actual_API_dependencies':actual,'API':ref(O/'API.json'),'checks':ref(O/'checks.json'),'author_Source':ref(Path(__file__).resolve()),'canonical_mutations':0,'Cargo_Native_or_Git_mutations':False,'new_test_bodies':0,'numerical_gate_claim':False}
(O/'manifest.json').write_bytes((json.dumps(m,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

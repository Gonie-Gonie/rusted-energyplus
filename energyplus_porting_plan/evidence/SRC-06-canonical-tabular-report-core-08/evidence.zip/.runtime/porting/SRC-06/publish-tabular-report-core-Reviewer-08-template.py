"""Guarded publication08 template; do not execute before Root canonical PASS."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];D=ROOT/'.runtime/porting/SRC-06'
PUBLIC=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-tabular-report-core-08'
READY=D/'canonical-tabular-publication-template-Reviewer-08'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r,base=ROOT):
 p=base/r['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return p
def load(p):return json.loads(p.read_bytes())
def require_accepted(p):
 j=load(p);assert j.get('accepted') is True and not j.get('findings',[]);return j
def main(args):
 assert args.publish and not PUBLIC.exists()
 cp=ROOT/args.canonical_receipt;assert ref(cp)['sha256']==args.canonical_receipt_sha;check=load(cp)
 assert check['exit_code']==0 and check['launch_error'] is None and check['source_bytes_match_before_and_after']
 assert 'check' in check['command'] and '--all-targets' in check['command'] and '--workspace' in check['command']
 prepared=D/'canonical-source75-report-core-prepared-Reviewer-08/manifest.json';assert ref(prepared)['sha256']=='a7814e50dc55e7d3cc7b901271f529922cd43123800492b4b388aeb16f5d3079';M=load(prepared)
 head=subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip();assert head==M['base_HEAD']
 plan=load(checked(M['complete_compiler_Source_plan']));planned={r['path']:r for r in plan['files']}
 observed={r['historical_path']:r for r in load(checked(check['source_snapshot']))['files']}
 assert set(observed)==set(planned) and len(observed)==M['counts']['planned_inputs'] and sum(n.endswith('.rs') for n in observed)==M['counts']['planned_Rust']
 for n,r in observed.items():
  b=(ROOT/n).read_bytes();assert b==checked(r['archive']).read_bytes() and len(b)==planned[n]['planned_bytes'] and hashlib.sha256(b).hexdigest()==planned[n]['planned_sha256']
 for r in M['files']:assert (ROOT/r['canonical_path']).read_bytes()==checked(r['proposed']).read_bytes()
 promotion=D/'Root-canonical75-report-core-review-01/review.json';assert ref(promotion)['sha256']=='4fc77520b2331d23032de6dbc965274e382c53570348ede6c1cac431cc7f69fa';require_accepted(promotion)
 actual=checked(M['actual75_independent_review']);assert ref(actual)['sha256']=='d88e233dbc4a9a500b0750f9838015b1206fc262e468e5e99662d8886f843524';A=require_accepted(actual)
 comparison=checked(M['actual75_report_comparison_review']);assert ref(comparison)['sha256']=='6f030ec533893376355b07b80071310c2b8850620857978dc17769df1c7c1a1b';C=require_accepted(comparison)
 assert C['raw_prefix_lines']==sum(f['Source_lines'] for f in C['physical_formats'])
 assert C['exact_raw_prefix_lines']==sum(f['exact_lines'] for f in C['physical_formats'])
 assert C['unequal_raw_prefix_lines']==len(C['all_uncapped_raw_mismatches'])==sum(f['unequal_lines'] for f in C['physical_formats'])
 assert C['raw_prefix_lines']==6680 and C['exact_raw_prefix_lines']==6663 and C['unequal_raw_prefix_lines']==17 and len(C['HTML_named_table_comments'])==25
 assert C['active_entries74']==732 and C['active_entries75']==914
 prior=ROOT/'energyplus_porting_plan/evidence/SRC-06-canonical-beps-report-core-07/summary.json';assert ref(prior)['sha256']=='bf6241a32a8c5b1f2ec7dfce55555cb3e668c56315c7a50759e4ba3fc0f8307d';priorv=load(prior)
 p74=D/'Root-actual-tabular74-comparison-review-01/review.json';assert ref(p74)['sha256']=='4cb902101690740d5aac1917d822d4115ea1eb89dd07c47c6de8bfd3e94f832f';P74=require_accepted(p74)
 oldplanp=ROOT/'energyplus_porting_plan/plan.json';oldplan=load(oldplanp)
 docnames=['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md'];before={n:(ROOT/'energyplus_porting_plan'/n).read_bytes() for n in docnames}
 for b in before.values():assert '\ufffd' not in b.decode('utf8','strict')
 payload={}
 def add(p):
  p=p.resolve();k=p.relative_to(ROOT).as_posix();b=p.read_bytes();assert k not in payload or payload[k]==b;payload[k]=b;return ref(p)
 def addref(r,base=ROOT):return add(checked(r,base))
 def receipt(r):
  p=checked(r);v=load(p);add(p)
  for k in ['stdout','stderr','source_snapshot']:addref(v[k],Path(v['cwd']))
  return v
 for p in [Path(__file__),prepared,promotion,actual,comparison,prior,p74]:add(p)
 for v in [load(promotion),A,C,P74]:
  for k in ['reviewer_Source','author_Source']:
   if k in v:addref(v[k])
 for k in ['complete_compiler_Source_plan','apply_script','author_Source','actual75']:addref(M[k])
 for r in M['files']:
  for k in ['before','literal_inverse','proposed','complete_forward_diff','complete_inverse_diff']:addref(r[k])
  add(ROOT/r['canonical_path'])
 for r in M['packets']:
  addref(r);v=load(checked(r))
  for a in v.get('Original_authority',[]):addref(a['literal_excerpt'])
  if 'author_Source' in v:addref(v['author_Source'])
 U=load(checked(M['actual75']));U74=load(checked(U['parent']))
 peers=U['independent_reviews']+U74['independent_reviews']+[ref(D/'Reviewer-ordinary-tabular-toc-Source-review-01/review.json'),ref(D/'Root-ordinary-tabular-toc-caller-Source-review-01/review.json')]
 for r in peers:addref(r)
 for k in ['actual_check','actual_CLI']:receipt(A[k])
 receipt(ref(cp));receipt(C['Native_actual_receipt'])
 priorNative=load(checked(C['Native_prior_custody']));addref(C['Native_prior_custody'])
 if 'Native_version_receipt' in priorNative:receipt(priorNative['Native_version_receipt'])
 for k in ['Root_Source_preflight','original_IDF','weather','predefined_snapshot75','predefined_snapshot74']:addref(C[k])
 for f in C['physical_formats']:addref(f['Source']);addref(f['Native'])
 for r in C['physics_whole_equal74']:addref(r['Source75']);addref(r['Source74'])
 # Preserve the unaccepted first observer attempt without laundering its claim.
 addref(A['initial_comparison_attempt']);attempt=load(checked(A['initial_comparison_attempt']))
 if 'author_Source' in attempt:addref(attempt['author_Source'])
 addref(P74['comparison'])
 out=D/'through-primary-diagnostic-A-24H-Root-75/output'
 for n in ['diagnostics.json','run-summary.json','eplusrs.err','eplusrs.ctf.log']:add(out/n)
 # Earlier27 and raw diagnostics are scoped historical observations only.
 old27=priorv['prior_existing27_receipt'];addref(old27)
 raw=priorv['raw_reporting_observation'];addref(raw['independent_all55']);addref(raw['Root_six_series']);addref(raw['all576_pairs'])
 assert not READY.exists();READY.mkdir(parents=True)
 (READY/'plan-before.json').write_bytes(oldplanp.read_bytes())
 for n,b in before.items():
  p=READY/'docs-before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 PUBLIC.mkdir(parents=True);z=PUBLIC/'evidence.zip'
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as arc:
  for k,b in sorted(payload.items()):
   info=zipfile.ZipInfo(k,date_time=(2026,10,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;arc.writestr(info,b)
 with zipfile.ZipFile(z) as arc:
  assert arc.testzip() is None and len(arc.namelist())==len(payload)
  for k,b in payload.items():assert arc.read(k)==b
 counts=M['counts'];s=PUBLIC/'summary.json'
 summary=dict(schema='src06-canonical-tabular-report-core.v1',status='Canonical TOC/VeriSum/Demand/SourceEnergy core integrated; actual held Source75 writes25 named tables then stops true5235 ComponentSizing',Original_version='26.1.0',Original_commit='6f2e40d10250a105b49966baa24d843711e61048',base_HEAD=head,prepared_selective_promotion=ref(prepared),independent_promotion_review=ref(promotion),changed_Rust_files=len(M['files']),new_Rust_files=sum(r['before_absent'] for r in M['files']),existing_Rust_files=sum(not r['before_absent'] for r in M['files']),compiler_inputs=len(observed),Rust_sources=sum(n.endswith('.rs') for n in observed),literal_applications=counts['literal_applications'],canonical_inputs_exact_actual75=counts['planned_inputs_exact_actual75'],canonical_check=ref(cp),actual_Source75_check=A['actual_check'],actual_Source75_CLI=A['actual_CLI'],actual_Source_and_frontier_review=ref(actual),finite_five_format_comparison=ref(comparison),actual_named_tables=len(C['HTML_named_table_comments']),all_raw_prefix_lines=C['raw_prefix_lines'],exact_raw_prefix_lines=C['exact_raw_prefix_lines'],all_explicit_version_clock_difference_lines=C['unequal_raw_prefix_lines'],active_predefined_entries_before=C['active_entries74'],active_predefined_entries_after=C['active_entries75'],allocated_capacity_before=800,allocated_capacity_after=1600,appended_LEED_entries=C['active_entries75']-C['active_entries74'],all_allocated_row_deltas_retained=len(C['all_allocated_row_deltas']),retained_unaccepted_comparison_attempt=A['initial_comparison_attempt'],retained_attempt_qualification=A['initial_attempt_qualification'],Source74_precedent=ref(p74),Source74_comparison=P74['comparison'],all_diagnostic_paths_excluded=M['excluded_diagnostic_paths'],canonical_pipeline_whole_unchanged=True,readonly_predefined_snapshot_excluded=True,four_report_5235_5238_packets_excluded=True,prior_existing27_receipt=old27,prior_existing27_scope='Historical canonical06 existing27 PASS only; no new tests or full-suite rerun in this report-core checkpoint.',new_test_bodies=0,full_suite_rerun=False,completed_Source_run_or_export=False,whole_Native_numeric_PASS=False,pipeline_activation=False,gate_changes=False,A=priorv['A'],B=priorv['B'],retained_whole_old_comparison=priorv['retained_whole_old_comparison'],previous_checkpoint=ref(prior),raw_reporting_observation=raw,numeric_observation='ESO/MTR/EIO/rawsidecar remain whole-equal Source74. Prior5280 roundtrips and upstream3536 unequal parsed ESO observations remain scoped to their actual commands; FP cause is unassigned. Reported-table equality does not establish Native internal binary64 equality.',remaining=['Actual5235 ComponentSizing and subsequent reports/close/endrun/export remain outside this canonical20 checkpoint.','Default dispatcher activation, whole numerical parity and remaining A/B domains.'],reconstruction='Exact20 Sources/before/proposals/inverses, complete4450-input hash plan and declared finite command/output observations. No full offline simulation replay claim.',evidence_archive=ref(z),archive_files=[dict(path=k,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for k,b in sorted(payload.items())],author_Source=ref(Path(__file__)))
 assert summary['A']=='14/54' and summary['B']=='14/64' and summary['changed_Rust_files']==20
 s.write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
 relative='evidence/SRC-06-canonical-tabular-report-core-08/summary.json'
 paragraph='실제 TOC·Verification Summary·Demand·Source Energy 보고서 경로의 Rust 파일 20개(신규 10개, 기존 10개)를 같은 상태 소유자에 연결했습니다. 격리 Source75 실행은 이름 있는 표 25개를 작성한 뒤 실제 Component Sizing 진입 5235에서 exit6으로 중단됩니다. 같은 입력의 Native 최종 보고서와 다섯 출력 형식의 앞부분 6,680줄을 비교해 6,663줄이 바이트 단위로 같았으며, 버전·실제 시각 차이 17줄은 원문과 전체 hex로 보존했습니다. Predefined 항목은 732개에서 914개로 늘었고, 실제 할당 공간 1,600개 전체의 변경 내역도 보존했습니다. 첫 비교 시도의 시각 분류·할당 꼬리 관찰 오류는 미승인 이력으로 남기고 수정된 비교만 승인했습니다. Canonical all-targets 검사는 통과했으며 새 테스트나 전체 테스트 반복은 없었습니다. 이전 27개 테스트 증거는 이전 검증 범위로만 유지합니다. 진단 경로 9개·읽기 전용 snapshot·기본 pipeline·미컴파일 후속 네 보고서는 이번 적용에서 제외했습니다. 기존 ESO 수치 차이와 원인 미확정 상태, A14/54·B14/64 및 전체 FAIL은 유지하며 전체 실행·수치 동등성·내보내기 완료를 뜻하지 않습니다.'
 for n in docnames:
  p=ROOT/'energyplus_porting_plan'/n;assert p.read_bytes()==before[n];link='../'+relative if n.startswith('cards/') else relative
  p.write_bytes(before[n]+('\n\n[Tabular 보고서 핵심 단계 검증]('+link+'). '+paragraph+'\n').encode('utf8'))
 after=json.loads(json.dumps(oldplan));task=next(t for t in after['tasks'] if t['id']=='SRC-06');key='canonical_tabular_report_core_08';assert key not in task
 task[key]=dict(path=s.relative_to(ROOT).as_posix(),sha256=ref(s)['sha256'],size_bytes=s.stat().st_size)
 restored=json.loads(json.dumps(after));del next(t for t in restored['tasks'] if t['id']=='SRC-06')[key];assert restored==oldplan
 assert oldplanp.read_bytes()==(READY/'plan-before.json').read_bytes();oldplanp.write_bytes((json.dumps(after,ensure_ascii=False,indent=2)+'\n').encode())
 readback=dict(summary=ref(s),archive=ref(z),archive_entries=len(payload),canonical_check=ref(cp),base_HEAD=head,plan_before=ref(READY/'plan-before.json'),publisher=ref(Path(__file__)),Git_mutated=False,Cargo_tests_Native_executed=False)
 p=READY/'publication-readback.json';assert not p.exists();p.write_bytes((json.dumps(readback,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps(readback))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--canonical-receipt',required=True);p.add_argument('--canonical-receipt-sha',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

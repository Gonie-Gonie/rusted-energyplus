from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.runtime/porting/SRC-06';OUT=BASE/'Root-ordinary-provider-union75-actual-review-01';assert not OUT.exists()
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
    b=(ROOT/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r.get('bytes',len(b));return b
mp=BASE/'ordinary-provider-assembly-Root-75/manifest.json';m=json.loads(mp.read_bytes());assert ref(mp)['sha256']=='e3255f1c535e9f7c866714e3fa4d54bb0899dbb1f7d629f812f6072d6f8fe698'
W=ROOT/m['workspace'];census=json.loads(checked(m['compiler_Source_census']))
for r in census['files']:
    b=(W/r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['assembled75_sha256'] and len(b)==r['bytes75']
pre=BASE/'Root-ordinary-provider-union75-preflight-01/review.json';assert json.loads(pre.read_bytes())['accepted_for_compile']
cp=BASE/'Root-actual-tabular75-five-format-comparison-02/comparison.json';comparison=json.loads(cp.read_bytes());assert ref(cp)['sha256']=='6f030ec533893376355b07b80071310c2b8850620857978dc17769df1c7c1a1b' and comparison['accepted'] and not comparison['findings']
check=json.loads(checked(comparison['actual_Source_check']));cli=json.loads(checked(comparison['actual_Source_CLI']));assert check['exit_code']==0 and cli['exit_code']==6 and cli['source_bytes_match_before_and_after'] and check['source_snapshot']==cli['source_snapshot']
s=json.loads(checked(comparison['predefined_snapshot75']));p=json.loads(checked(comparison['predefined_snapshot74']));sr=s['table']['allocated_rows_in_original_order'];pr=p['table']['allocated_rows_in_original_order']
assert s['table']['num_table_entry']==914 and p['table']['num_table_entry']==732 and s['table']['size_table_entry']==1600 and p['table']['size_table_entry']==800
assert sr[:732]==pr[:732] and s['registry']==p['registry'] and len(sr)==1600 and len(pr)==800
assert all(x['index_column']>0 for x in sr[732:914]) and all(x['index_column']==0 for x in sr[914:])
assert len(comparison['HTML_named_table_comments'])==25
OUT.mkdir();result=dict(accepted=True,manifest=ref(mp),preflight=ref(pre),actual_check=comparison['actual_Source_check'],actual_CLI=comparison['actual_Source_CLI'],comparison=ref(cp),compiler_inputs_rechecked=4451,actual_expected_boundary='WriteTabularReports5235 WriteComponentSizing',five_formats_raw_prefix_lines=6680,exact_lines=6663,unequal_version_clock_lines=17,complete_named_tables=25,predefined_active732_to914=True,predefined_capacity800_to1600=True,all_prior732_entries_unchanged=True,new_active_LEED_entries=182,findings=[],initial_comparison_attempt=ref(BASE/'Root-actual-tabular75-five-format-comparison-01/comparison.json'),initial_attempt_qualification='Unaccepted Root observer attempt retained. Its clock classifier omitted leading indentation and its zip loop omitted newly allocated rows; corrected02 keeps full raw byte comparison and all1600 allocated rows. No Source change or Source numerical finding.',canonical_changes=0,whole_run_complete=False,numerical_gate_PASS=False,reviewer_Source=ref(Path(__file__).resolve()))
q=OUT/'review.json';q.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(ref(q)))

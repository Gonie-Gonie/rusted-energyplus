from pathlib import Path
import ast,json,hashlib,difflib,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8')
R=Path.cwd();D=R/'.runtime/porting/SRC-06/ordinary-tabular-toc-draft-Audit-01';O=R/'.runtime/porting/SRC-06/ordinary-tabular-toc-held-Audit-01';assert not O.exists()
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<custody>','exec'),ns);ref=ns['ref'];row=ns['row']
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pure={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<diff>','exec'),pure);apply=pure['apply_diff']
def auth(d):
 p=R/d['path'];assert ref(p)==d,d;return p
parents=json.loads((D/'parents.json').read_bytes());recoveries=[]
for c,d in parents.items():
 old=auth(d).read_bytes();new=(D/'proposed'/c).read_bytes();assert new.startswith(old),c
 addition=new[len(old):];assert addition and new[:-len(addition)]==old
 recoveries.append({'canonical_path':c,'whole_parent':d,'append_only_bytes':len(addition),'exact_whole_parent_recovered':True})
O.mkdir()
for p in sorted((D/'proposed').rglob('*.rs')):
 c=p.relative_to(D/'proposed').as_posix();row(c,p.read_bytes(),auth(parents[c]) if c in parents else None)
assert len(ns['rows'])==5
applications=0;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();git=[];parses=[]
for v in ns['rows']:
 for a,k,b in [(v['before'],'complete_forward_diff',v['proposed']),(v['proposed'],'complete_inverse_diff',v['before']),(v['parent_before'],'parent_forward_diff',v['proposed']),(v['proposed'],'parent_inverse_diff',v['parent_before'])]:
  assert apply(auth(a).read_bytes(),auth(v[k]).read_bytes())==auth(b).read_bytes();applications+=1
 c=v['canonical_path'];proc=subprocess.run(['git','show',head+':'+c],cwd=R,capture_output=True)
 if v['canonical_absent_observed']:assert proc.returncode!=0;git.append({'canonical_path':c,'commit':head,'absent':True})
 else:
  assert proc.returncode==0 and proc.stdout==auth(v['before']).read_bytes(),c
  git.append({'canonical_path':c,'commit':head,'actual_current_and_Git_whole_equal':True,'Source':v['before'],'overlay_parent':v['parent_proposed']})
 proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=auth(v['proposed']).read_bytes(),capture_output=True);assert proc.returncode==0,proc.stderr;parses.append({'Source':v['proposed'],'exit':0,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest()})
N=R/'.reference/energyplus-src/26.1.0';original=[]
for name,a,b in [('OutputReportTabular.cc',3211,3407),('OutputReportTabular.cc',5198,5295),('OutputReportTabular.cc',17818,17867),('OutputReportTabular.cc',18768,18780),('OutputReportTabularAnnual.cc',1238,1253),('OutputReportTabular.hh',100,127),('CostEstimateManager.cc',110,170),('CostEstimateManager.hh',160,170),('EconomicLifeCycleCost.cc',150,185),('EconomicLifeCycleCost.hh',450,460)]:
 p=N/'src/EnergyPlus'/name;lines=p.read_bytes().splitlines(True);assert 1<=a<=b<=len(lines);q=O/'Original'/f'{name}-{a}-{b}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(lines[a-1:b]));original.append({'source':ref(p),'first_line':a,'last_line':b,'literal_excerpt':ref(q)})
api={'entry':'SourceTabularReports::write_source_table_of_contents(&mut self,&SourceTabularTocOwners)->Result<(),HeatBalanceInputError>','borrowed_owners':['same registry','same EconomicLifeCycleCost.parameters_present through &bool accessor','same CostEstimateManager.do_cost_estimate through &bool accessor','actual WeatherGlobal.DoWeathSim','same WeatherOwner report-period counts','same schedules for positive binned Name read'],'actual_effects':'Native life-cycle AddTOCEntry before styles; HTML ordinal stream inserts all eleven ordinary links/selected predefined links in Source order, genuine weather monthly/bin/annual guards, retained TOC section grouping/isWritten writes immediately after each entry, report-period summary link and ordered child boundaries. No close/flush/report execution is inserted.','positive_boundaries':['MonthlyInput.numTables3318 first unavailable record field','Binned unitNames/LookupSItoIP3339 or3345 after real positive header and curTable calculation','AnnualTable.m_name1251 on genuine positive retained annual vector','ReportPeriod title3402 on actual positive per-category count, after ReportingPeriodSummary link'],'pure_anchor':'A narrow forwarding function calls the exact already accepted writer bytes::anchor; no duplicate implementation.','unchanged':'Four whole Source parents recovered by removing only appended module/accessor/forwarder chunks; actual AddTOCEntry body and all existing report science unchanged.','caller':'Leaf only; Root must attach at actual5231 after reviewed BEPS5230 and retain5232 VeriSum next. Later CloseOutputTabularFile is actual SimulationManager602, outside this callee.','new_test_bodies':0,'numerical_or_whole_run_claim':False}
(O/'API.json').write_bytes((json.dumps(api,indent=2)+'\n').encode())
refs=[]
for c in ['crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/table_of_contents.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/state.rs','crates/ep_runtime/src/heat_balance/predefined_tables.rs','crates/ep_runtime/src/heat_balance/selected_schedule_manager.rs','crates/ep_runtime/src/weather_day/context.rs','crates/ep_runtime/src/heat_balance/ordinary_life_cycle_cost/input.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/summary.rs']:
 refs.append(ref(R/c))
checks={'applications':applications,'whole_parent_recoveries':recoveries,'read_only_Git':git,'Source_parse_only':parses,'actual_API_and_producer_refs':refs,'streams_not_cloned':True,'flag_values_not_copied':True,'TOC_entry_section_reference_retained_by_disjoint_fields_and_ranges':True}
(O/'checks.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode())
deps=[ref(R/'.runtime/porting/SRC-06'/name) for name in ['ordinary-beps-report-held-Audit-04/manifest.json','ordinary-tabular-writers-held-Audit-01/manifest.json','Fix-ordinary-tabular-writers-Source-review-02/review.json','ordinary-provider-assembly-Root-71/manifest.json']]
m={'schema':'src06-literal-tabular-toc-held.v1','status':'HELD complete retained zero-monthly/bin/annual/report-period TOC route; genuine positive record boundaries explicit; independent peer/caller required','base_HEAD':head,'files':ns['rows'],'Original_authority':original,'dependencies':deps,'API':ref(O/'API.json'),'checks':ref(O/'checks.json'),'author_Source':ref(Path(__file__).resolve()),'BEPS_body_semantics_not_self_accepted':True,'canonical_mutations':0,'Cargo_Native_or_Git_mutations':False,'new_test_bodies':0,'numerical_gate_claim':False}
(O/'manifest.json').write_bytes((json.dumps(m,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

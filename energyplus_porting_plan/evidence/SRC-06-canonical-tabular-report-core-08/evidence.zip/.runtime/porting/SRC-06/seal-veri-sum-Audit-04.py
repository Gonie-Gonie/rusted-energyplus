from pathlib import Path
import ast,json,hashlib,difflib,re,subprocess,sys
sys.stdout.reconfigure(encoding='utf8');R=Path.cwd();P=R/'.runtime/porting/SRC-06/ordinary-veri-sum-held-Audit-03';O=R/'.runtime/porting/SRC-06/ordinary-veri-sum-held-Audit-04';assert not O.exists();m=json.loads((P/'manifest.json').read_bytes())
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-pollution-Audit-01.py').read_text(encoding='utf8'));ns={'Path':Path,'json':json,'hashlib':hashlib,'difflib':difflib,'R':R,'O':O,'rows':[]};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'ref','row'}],type_ignores=[]),'<custody>','exec'),ns);ref=ns['ref'];row=ns['row']
tree=ast.parse((R/'.runtime/porting/SRC-06/seal-primary-owner-storage-Audit-01.py').read_text(encoding='utf8'));pure={'re':re};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='apply_diff'],type_ignores=[]),'<diff>','exec'),pure);apply=pure['apply_diff']
def auth(d):
 p=R/d['path'];assert ref(p)==d,d;return p
reject=R/'.runtime/porting/SRC-06/Fix-ordinary-veri-sum-Source-review-02/review.json';assert ref(reject)['sha256']=='3469c36848afacf8284c87a604ec2d30f4cbb9fc5426d865a2320a175549d29a'
O.mkdir();changed=[];unchanged=[]
for v in m['files']:
 c=v['canonical_path'];old=auth(v['proposed']).read_bytes();new=old
 if c.endswith('/veri_sum/spaces.rs'):
  pairs=[('''            for &space_number in &z.space_indexes {
                let space = o''','''            for &space_number in &z.space_indexes {
                let space_at = index(space_number)?;
                let space = o'''),('.and_then(|r| r.get(index(space_number)?))','.and_then(|r| r.get(space_at))'),('''                let enclosure = o
                    .radiation''','''                let enclosure_at = index(space.solar_enclosure_num)?;
                let enclosure = o
                    .radiation'''),('.and_then(|r| r.get(index(space.solar_enclosure_num)?))','.and_then(|r| r.get(enclosure_at))')]
  for a,b in pairs:
   assert new.count(a.encode())==1;new=new.replace(a.encode(),b.encode(),1)
  reverse=new
  for a,b in reversed(pairs):assert reverse.count(b.encode())==1;reverse=reverse.replace(b.encode(),a.encode(),1)
  assert reverse==old;changed.append(c)
 else:unchanged.append(c)
 row(c,new,auth(v['parent_proposed']) if v['parent_proposed'] else None);out=ns['rows'][-1];out['direct_parent_proposed']=v['proposed']
 for key,a,b in [('direct03_forward_diff',old,new),('direct03_inverse_diff',new,old)]:
  q=O/'direct03-diffs'/(str(len(ns['rows'])).zfill(2)+('.inverse.diff' if 'inverse' in key else '.diff'));q.parent.mkdir(exist_ok=True);q.write_bytes(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+c,tofile='b/'+c)).encode());out[key]=ref(q);assert apply(a,q.read_bytes())==b
assert len(changed)==1 and len(unchanged)==9
applications=0;head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip();git=[];parses=[]
for v in ns['rows']:
 for a,k,b in [(v['before'],'complete_forward_diff',v['proposed']),(v['proposed'],'complete_inverse_diff',v['before']),(v['parent_before'],'parent_forward_diff',v['proposed']),(v['proposed'],'parent_inverse_diff',v['parent_before'])]:assert apply(auth(a).read_bytes(),auth(v[k]).read_bytes())==auth(b).read_bytes();applications+=1
 c=v['canonical_path'];proc=subprocess.run(['git','show',head+':'+c],cwd=R,capture_output=True);finite=None
 if v['canonical_absent_observed']:assert proc.returncode!=0;git.append({'canonical_path':c,'commit':head,'absent':True})
 else:
  current=auth(v['before']).read_bytes()
  if proc.returncode!=0 or proc.stdout!=current:
   allowed={'crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/beps_report.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/state.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports/writers.rs','crates/ep_runtime/src/heat_balance/ordinary_tabular_reports.rs'};assert c in allowed,c
   actual=R/'.runtime/porting/SRC-06/ordinary-provider-assembly-Root-72/workspace'/c;assert actual.read_bytes()==current,c;finite={'exact_Root72_current_WIP':ref(actual),'qualification':'Root-authored canonical17 Source72 promotion WIP; separate Git absence/blob, no clean assertion.'}
  if proc.returncode==0:q=O/'Git-before'/c;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(proc.stdout);gref=ref(q)
  else:gref=None
  git.append({'canonical_path':c,'commit':head,'Git_absent':proc.returncode!=0,'Git_before':gref,'current':v['before'],'finite_WIP_bridge':finite})
 proc=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=auth(v['proposed']).read_bytes(),capture_output=True);assert proc.returncode==0,proc.stderr;parses.append({'Source':v['proposed'],'exit':0,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest()})
for v in m['Original_authority']:
 lines=auth(v['source']).read_bytes().splitlines(True);a=v['first_line'];b=v['last_line'];assert 1<=a<=b<=len(lines) and b''.join(lines[a-1:b])==auth(v['literal_excerpt']).read_bytes()
api=json.loads(auth(m['API']).read_bytes());api['correction04']='Only two failed Result-in-Option closures now compute named Result indices at actual curSpace12159 and EnclSolInfo.Name12166 operations. No early enclosure index hoist, other9 whole Sources unchanged03, no numerical/operator/owner/order change.'
(O/'API.json').write_bytes((json.dumps(api,indent=2)+'\n').encode());checks={'literal_applications':applications,'direct03_applications':20,'changed_Source_paths':changed,'unchanged_whole_Source_paths':unchanged,'two_actual_row_index_corrections':True,'read_only_Git':git,'Source_parse_only':parses,'Original_ranges_unchanged':12,'inherited_five_whole_parent_recoveries':m['checks'],'Source03_preserved_immutable':True}
(O/'checks.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode());out=dict(m);out.update({'schema':'src06-coherent-selected-verification-summary-held.v2','status':'HELD narrow two-row Result/Option API successor; independent correction peer/compiler/runtime required','base_HEAD':head,'files':ns['rows'],'dependencies':[ref(P/'manifest.json'),ref(reject)]+m['dependencies'],'direct_rejection':ref(reject),'API':ref(O/'API.json'),'checks':ref(O/'checks.json'),'author_Source':ref(Path(__file__).resolve()),'original_owner_parent_policy':'Original parent_proposed retained for first-time integration; direct_parent_proposed/diffs authenticate only the narrow03 correction.'})
(O/'manifest.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(ref(O/'manifest.json')))

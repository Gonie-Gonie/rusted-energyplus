"""Connect reviewed InputProcessor storage to the actual ordinary run caller."""
from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
manifest_path = base / 'ordinary-input-processor-prep-02/manifest.json'
assert hashlib.sha256(manifest_path.read_bytes()).hexdigest() == '8c77ec0549a59c15cd1a3bde9487afaba6f7b64078ac4b04d21d7df933c7578c'
manifest = json.loads(manifest_path.read_bytes())
review = json.loads((base / 'Native-ordinary-input-processor-review-01/review.json').read_bytes())
assert review['accepted'] is True

def replace(path, old, new):
    data = path.read_text(encoding='utf8')
    assert data.count(old) == 1, (str(path), old)
    path.write_bytes(data.replace(old, new).encode())

for row in manifest['files']:
    data = (root / row['proposed']['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['proposed']['sha256']
    assert len(data) == row['proposed']['size_bytes']
    target = root / row['canonical_path']
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

path = root / 'crates/ep_runtime/src/heat_balance/selected_input_processor.rs'
replace(path, 'pub(crate) struct SourceInputProcessorShortCut {\n    pub(crate) current_module_object: String,\n    pub(crate) alpha_args: Vec<String>,\n    pub(crate) numeric_args: Vec<f64>,\n    pub(crate) alpha_field_names: Vec<String>,\n    pub(crate) numeric_field_names: Vec<String>,\n    pub(crate) alpha_field_blanks: Vec<bool>,\n    pub(crate) numeric_field_blanks: Vec<bool>,\n}', '''pub struct SourceInputProcessorShortCut {
    /// Current getter's actual object-family name.
    pub current_module_object: String,
    /// Shared alpha arguments, initially empty strings.
    pub alpha_args: Vec<String>,
    /// Shared numeric arguments, initially positive zero.
    pub numeric_args: Vec<f64>,
    /// Shared alpha field names, initially empty strings.
    pub alpha_field_names: Vec<String>,
    /// Shared numeric field names, initially empty strings.
    pub numeric_field_names: Vec<String>,
    /// Shared alpha blank flags, initially false.
    pub alpha_field_blanks: Vec<bool>,
    /// Shared numeric blank flags, initially false.
    pub numeric_field_blanks: Vec<bool>,
}''')
replace(path, '    /// Actual initializeMaps/getMaxSchemaArgs-dependent shared array allocation.\n    pub(crate) fn allocate_from_input(', '''    /// Actual initializeMaps/getMaxSchemaArgs-dependent shared array allocation.
    ///
    /// # Errors
    /// Returns an explicit unavailable definition or size boundary before writes.
    pub fn allocate_from_input(''')

replace(root / 'crates/ep_runtime/src/heat_balance/mod.rs', 'pub mod report_scan;\n', 'pub mod report_scan;\npub mod selected_input_processor;\n')
replace(root / 'crates/ep_run/src/lib.rs', 'mod ordinary_equipment_input;\n', 'mod ordinary_equipment_input;\nmod ordinary_input_processor;\n')
context = root / 'crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs'
replace(context, '    pub setup_simulation_registry_prepared: bool,\n', '''    pub setup_simulation_registry_prepared: bool,
    /// Sole actual raw/schema input owner, retained across runtime success and failure.
    /// Legacy callers that supply no raw projection retain None.
    pub selected_input_processor: Option<super::selected_input_processor::SelectedInputProcessor>,
    /// Sole shared input arrays allocated before the ordinary runtime getters.
    pub input_processor_shortcut: super::selected_input_processor::SourceInputProcessorShortCut,
''')
replace(context, '/// Distinct actual initialization failures, retaining the original backend errors.\n', '''impl CtfInitializationReports {
    /// Move the actual admitted input owner and allocate its shared arrays.
    /// This is the selected InputProcessor.cc315-320 boundary, before runtime.
    /// Later definition queries retain their presence mutations without reallocating.
    ///
    /// # Errors
    /// Retains the moved input and previous arrays if schema/count lookup fails.
    pub fn initialize_input_processor(
        &mut self,
        input: super::selected_input_processor::SelectedInputProcessor,
    ) -> Result<(), super::selected_input_processor::SelectedInputUnavailable> {
        self.selected_input_processor = Some(input);
        let input = self.selected_input_processor.as_ref()
            .ok_or(super::selected_input_processor::SelectedInputUnavailable::Association)?;
        self.input_processor_shortcut.allocate_from_input(input)
    }
}

/// Distinct actual initialization failures, retaining the original backend errors.
''')
pipeline = root / 'crates/ep_run/src/pipeline.rs'
replace(pipeline, '        let runtime_inputs = match ep_runtime::psychrometrics::production_trace::in_phase(', '        let mut runtime_inputs = match ep_runtime::psychrometrics::production_trace::in_phase(')
replace(pipeline, '                            &runtime_inputs,\n', '                            &mut runtime_inputs,\n')
replace(pipeline, '    ordinary_warmup_reporting: Option<ep_runtime::HeatBalanceOrdinaryWarmupReportInputs>,\n', '''    ordinary_warmup_reporting: Option<ep_runtime::HeatBalanceOrdinaryWarmupReportInputs>,
    selected_input_processor: Option<
        ep_runtime::heat_balance::selected_input_processor::SelectedInputProcessor,
    >,
''')
replace(pipeline, '        ordinary_warmup_reporting: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility\n', '''        selected_input_processor: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility {
            Some(crate::ordinary_input_processor::resolve(raw_model)?)
        } else {
            None
        },
        ordinary_warmup_reporting: if runtime_class == RuntimeClass::OneZoneHeatBalanceCompatibility
''')
replace(pipeline, '    runtime_inputs: &PreparedRuntimeInputs,\n', '    runtime_inputs: &mut PreparedRuntimeInputs,\n')
replace(pipeline, '            let mut initialization = ctf_outputs.context();\n', '''            let mut initialization = ctf_outputs.context();
            if let Some(input) = runtime_inputs.selected_input_processor.take() {
                initialization.reports.initialize_input_processor(input)
                    .map_err(|error| error.to_string())?;
            }
''')
raw = root / 'crates/ep_run/src/ordinary_equipment_input.rs'
replace(raw, '        super::design_day_projection::verify_admitted_design_day_projection()?;\n', '''        super::design_day_projection::verify_admitted_design_day_projection()?;
        crate::ordinary_input_processor::tests::verify_shared_input_boundary()?;
''')
path = root / 'crates/ep_run/src/ordinary_input_processor.rs'
with path.open('ab') as stream:
    stream.write(b'\n#[cfg(test)]\n#[path = "ordinary_input_processor_tests.rs"]\npub(crate) mod tests;\n')
print('Applied three reviewed modules and genuine pipeline/report storage integration.')

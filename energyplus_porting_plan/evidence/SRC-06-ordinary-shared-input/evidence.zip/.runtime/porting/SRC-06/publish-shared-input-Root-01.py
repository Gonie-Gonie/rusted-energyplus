"""Publish actual shared input storage integration and bounded actual QA."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess
import zipfile

root=Path.cwd()
base=root/'.runtime/porting/SRC-06'
out=root/'energyplus_porting_plan/evidence/SRC-06-ordinary-shared-input'
assert not out.exists()

def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}

def load(path):return json.loads(path.read_bytes())
def write(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())

artifacts={}
historical=[]
historical_dir=base/'ordinary-shared-input-historical-01'
historical_dir.mkdir(exist_ok=False)
assembly_path=base/'ordinary-shared-input-assembly-02/manifest.json'
assert ref(assembly_path)['sha256']=='45da744cd89ee7193cbdd52c6ae81f065f4e7dfbf5c4ec6e83812d6677d46e1c'
assembly=load(assembly_path)

def add(path):
    row=ref(path)
    assert row['size_bytes']<12*1024*1024
    artifacts[row['path']]=row

def checked(row):
    path=root/row['path']
    actual=ref(path)
    if actual['sha256']!=row['sha256']:
        # Exact earlier admission Source: only its existing test body was extended.
        assert row['path']=='crates/ep_run/src/ordinary_equipment_input.rs'
        assert row['sha256']=='1e3e60923ce397b30730d6a689f3632e3806f43a71bdad1723a8ea1ed21bb553'
        before=assembly['files'][1]['before']
        assert before['sha256']==row['sha256']
        path=historical_dir/'ordinary_equipment_input.rs'
        if not path.exists():path.write_bytes((root/before['path']).read_bytes())
        historical_row={'historical_reference':row,'archive':ref(path),'qualification':'Exact parent admission bytes; final canonical diff adds one call in its existing test body only.'}
        if historical_row not in historical:historical.append(historical_row)
        actual=ref(path)
    assert actual['sha256']==row['sha256'] and actual['size_bytes']==row.get('size_bytes',actual['size_bytes'])
    return path

def gather(value):
    if isinstance(value,dict):
        if 'path' in value and 'sha256' in value:add(checked(value))
        else:
            for item in value.values():gather(item)
    elif isinstance(value,list):
        for item in value:gather(item)

add(assembly_path);gather(assembly)
for version,pin in [('01','cf362e8e50384936e84f33d8016d585ca10b65287b5ec8edf326ed48b0963e9e'),('02','8c77ec0549a59c15cd1a3bde9487afaba6f7b64078ac4b04d21d7df933c7578c')]:
    path=base/f'ordinary-input-processor-prep-{version}/manifest.json'
    assert ref(path)['sha256']==pin
    add(path);gather(load(path))
review=base/'Owner-ordinary-shared-input-assembly-review-01/review.json'
assert load(review)['accepted'] is True
add(review);gather(load(review))
parent_review=base/'Native-ordinary-input-processor-review-01/review.json'
assert load(parent_review)['accepted'] is True
add(parent_review);gather(load(parent_review))

qa=[]
for name,argv in [
 ('fmt',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','fmt','--all','--','--check']),
 ('source-quality',['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1']),
 ('clippy',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','clippy','--workspace','--all-targets','--','-D','warnings']),
 ('workspace',['C:/Users/GonieGonie/.cargo/bin/cargo.exe','test','--workspace']),
]:
    path=base/f'ordinary-shared-input-{name}-01/receipt.json'
    value=load(path)
    assert value['command']==argv and value['exit_code']==0 and value['launch_error'] is None
    assert value['source_bytes_match_before_and_after'] is True
    qa.append(ref(path));add(path)
    for key in ['source_snapshot','stdout','stderr']:gather(value[key])
source=load(checked(qa[-1]))['source_snapshot']
assert all(load(checked(row))['source_snapshot']==source for row in qa)
stdout=checked(load(checked(qa[-1]))['stdout']).read_text(encoding='utf8')
groups=[tuple(map(int,values))for values in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
assert len(groups)==18 and tuple(map(sum,zip(*groups)))==(4974,0,2)
assert 'test ordinary_equipment_input::tests::raw_equipment_admission_preserves_empty_presence_and_rejects_positive_or_field_branches ... ok' in stdout

for row in assembly['files']:
    assert ref(root/row['canonical']['path'])==row['canonical']
    before=(root/row['before']['path']).read_bytes()
    after=(root/row['after']['path']).read_bytes()
    diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='HEAD/'+row['canonical']['path'],tofile=row['canonical']['path'])).encode()
    assert diff==(root/row['complete_diff']['path']).read_bytes()
    assert row['test_bodies_before']==row['test_bodies_after']
for name in ['seal-shared-input-Root-01.py','seal-shared-input-Root-02.py']:
    add(base/name)
add(Path(__file__))
assert sum(row['size_bytes']for row in artifacts.values())<20*1024*1024
out.mkdir()
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as zipped:
    for name in sorted(artifacts):zipped.write(root/name,name)
with zipfile.ZipFile(archive)as zipped:
    assert zipped.testzip() is None and set(zipped.namelist())==set(artifacts)
    for name in zipped.namelist():
        data=zipped.read(name)
        assert hashlib.sha256(data).hexdigest()==artifacts[name]['sha256'] and len(data)==artifacts[name]['size_bytes']
write(out/'manifest.json',{
 'schema':'src06-shared-input-evidence.v1','Source_snapshot':source,
 'assembly':ref(assembly_path),'artifacts':list(artifacts.values()),
 'historical_references':historical,'archive':ref(archive),
 'archive_member_count':len(artifacts),'gates_updated':False,
})
summary={
 'schema':'src06-shared-input-summary.v1',
 'status':'Actual ordinary shared input storage initialized; full startup/Setup port incomplete',
 'Source_snapshot':source,'QA':qa,
 'tests':{'workspace_groups':18,'passed':4974,'failed':0,'ignored':2,'new_bodies':0,'new_binaries':0},
 'behavior':['Same admitted raw family presence and literal JSON field sizes retained',
             'Actual count queries do not mutate; known absent definition queries insert null',
             'Actual schema traversal retains independent alpha/numeric maxima and extensible counts',
             'Owned input moved once into retained reports before runtime; six shared arrays initialized in Source order',
             'Later getter null insertion does not reallocate scratch; size failure retains moved input and old arrays'],
 'limitations':['Finite60 schema metadata is not positive admission; unrepresented present families stop explicitly',
                'ScheduleManager/ManageSizing/full RunSimulation/Setup and ordinary dispatcher remain subsequent integration work',
                'No Native numerical comparison or full parser/input parity claim',
                'SRC-06 gates and A14/54 B14/64 unchanged'],
 'validation_scope':'One all-target workspace Clippy and one whole-workspace test run; the extended regression is included and was not separately rerun.',
 'independent_Source_reviews':[ref(parent_review),ref(review)],
 'manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False,
}
write(out/'summary.json',summary)
plan_path=root/'energyplus_porting_plan/plan.json'
plan=load(plan_path)
task=next(row for row in plan['tasks']if row['id']=='SRC-06')
assert all(task[key]=='미확인'for key in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_shared_input' not in task
task['actual_selected_ordinary_shared_input']=ref(out/'summary.json')
write(plan_path,plan)
card=root/'energyplus_porting_plan/cards/SRC-06.md'
text=card.read_text(encoding='utf8')
text+='''
## 공통 입력 저장소의 실제 실행 연결

ordinary 입력 준비 단계에서 실제 raw family 존재와 JSON 필드 크기를 보존하고,
실행 직전에 `Option::take`로 단일 입력 owner를 보고 저장소에 옮긴다. 원본
InputProcessor315–320 순서로 공통 alpha/numeric 배열 여섯 개를 실제 스키마
최대값으로 할당한다. 문자열은 빈 값, 숫자는 +0.0, blank flag는 false로 시작한다.
개수 조회는 입력 존재를 바꾸지 않고, 정의 조회는 알려진 미존재 family를 null로
삽입한다. 이후 null 삽입이 이미 할당한 공통 배열을 다시 늘리지는 않는다.

기존 raw admission 회귀 한 본문을 확장해 대소문자 조회, 확장 필드 크기,
empty/absent/null 구분, 공통 배열 초기값과 크기 실패 후 owner 보존을 검증했다.
테스트 본문과 바이너리 수는 그대로다. 최종 Source `'''+source['sha256']+'''`에서
fmt, source-quality, workspace 전체 target Clippy(-D warnings), 전체 테스트 한 번이
통과했다: 18개 그룹, 4,974 passed/0 failed/기존 ignored 2개. 해당 회귀를 별도로
중복 실행하지 않았다.

[공통 입력 검증 요약](../evidence/SRC-06-ordinary-shared-input/summary.json),
[실제 파일 색인](../evidence/SRC-06-ordinary-shared-input/manifest.json),
[전체 검증 기록](../evidence/SRC-06-ordinary-shared-input/evidence.zip)에 변경 전체와
원본 구간, 독립 Source 검토 및 실제 QA를 보존했다. 선택한 60개 스키마 정의는
조회 metadata이며 positive 입력 허용 범위를 넓히지 않는다. 아직 지원하지 않는
존재 family는 명시적으로 중단한다. 스케줄·사이징·전체 RunSimulation/Setup은
후속 연결 대상이며 전체 parser 또는 Native 수치 동등성을 주장하지 않는다.
SRC-06 gate와 A14/54, B14/64 상태는 유지한다.
'''
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'members':len(artifacts),'archive_bytes':archive.stat().st_size},ensure_ascii=False))

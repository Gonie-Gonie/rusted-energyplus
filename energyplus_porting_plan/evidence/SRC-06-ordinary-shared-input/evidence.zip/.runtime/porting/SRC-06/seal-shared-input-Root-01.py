"""Freeze finite actual caller integration for independent Source review."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

root=Path.cwd()
base=root/'.runtime/porting/SRC-06'
out=base/'ordinary-shared-input-assembly-01'
out.mkdir(exist_ok=False)

def ref(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)}

def write(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

paths=[
 'crates/ep_run/src/lib.rs',
 'crates/ep_run/src/ordinary_equipment_input.rs',
 'crates/ep_run/src/ordinary_input_processor.rs',
 'crates/ep_run/src/ordinary_input_processor/schema.rs',
 'crates/ep_run/src/ordinary_input_processor_tests.rs',
 'crates/ep_run/src/pipeline.rs',
 'crates/ep_runtime/src/heat_balance/mod.rs',
 'crates/ep_runtime/src/heat_balance/ctf_initialization_context.rs',
 'crates/ep_runtime/src/heat_balance/selected_input_processor.rs',
]
rows=[]
for index,name in enumerate(paths):
    before_process=subprocess.run(['git','show','HEAD:'+name],cwd=root,capture_output=True)
    if before_process.returncode:
        assert b'does not exist in' in before_process.stderr
        before=b''
    else:before=before_process.stdout
    after=(root/name).read_bytes()
    before_path=out/f'{index:02d}.before';before_path.write_bytes(before)
    after_path=out/f'{index:02d}.after';after_path.write_bytes(after)
    diff=out/f'{index:02d}.diff'
    diff.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='HEAD/'+name,tofile=name)).encode())
    assert before.count(b'#[test]')==after.count(b'#[test]')
    rows.append({'canonical':ref(root/name),'before':ref(before_path),'after':ref(after_path),'complete_diff':ref(diff),'test_bodies_before':before.count(b'#[test]'),'test_bodies_after':after.count(b'#[test]')})
parent=base/'ordinary-input-processor-prep-02/manifest.json'
parent_rows=json.loads(parent.read_bytes())['files']
parent_deltas=[]
for index,row in enumerate(parent_rows):
    before=(root/row['proposed']['path']).read_bytes()
    after=(root/row['canonical_path']).read_bytes()
    diff=out/f'parent-IP02-{index:02d}.diff'
    diff.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=row['proposed']['path'],tofile=row['canonical_path'])).encode())
    parent_deltas.append({'parent':row['proposed'],'canonical':ref(root/row['canonical_path']),'complete_diff':ref(diff)})
value={
 'schema':'src06-shared-input-actual-caller-assembly.v1',
 'status':'canonical Source assembled; QA in progress; full RunSimulation/Setup not activated',
 'baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'parent_preparation':ref(parent),
 'independent_parent_review':ref(base/'Native-ordinary-input-processor-review-01/review.json'),
 'files':rows,'parent_deltas':parent_deltas,
 'scope':['Actual admitted raw family/field-size projection at ordinary runtime preparation',
          'Owned input moved using Option::take into retained reports before runtime call',
          'Real InputProcessor315-320 shared arrays allocated from complete present-schema maxima',
          'Same sole scratch owner retained; public visibility/documentation permits genuine caller inspection',
          'Existing raw-admission test body extended; no new test bodies or binaries'],
 'limitations':['Selected finite60 schema closure; unrepresented present families stop explicitly',
                'No ScheduleManager, ManageSizing, full RunSimulation/Setup or ordinary dispatcher activation',
                'No Native numerical comparison or whole input/parser parity claim',
                'All SRC-06 gates and A14/54 B14/64 unchanged'],
 'authoring_history':['apply-shared-input-Root-01.py partially applied then stopped at overly broad context anchor; no compile/test ran on partial source',
                     'apply-shared-input-Root-02.py completed uniquely anchored caller edits; both immutable scripts retained'],
 'author_scripts':[ref(base/'apply-shared-input-Root-01.py'),ref(base/'apply-shared-input-Root-02.py'),ref(Path(__file__))],
 'gates_updated':False,
}
write(out/'manifest.json',value)
print(json.dumps(ref(out/'manifest.json')))

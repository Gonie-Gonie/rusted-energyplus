"""Successor01: identify new paths from HEAD tree, not Git's diagnostic wording."""
from pathlib import Path

parent=Path(__file__).with_name('seal-shared-input-Root-01.py')
source=parent.read_text(encoding='utf8')
old="out=base/'ordinary-shared-input-assembly-01'"
assert source.count(old)==1
source=source.replace(old,"out=base/'ordinary-shared-input-assembly-02'")
old="assert b'does not exist in' in before_process.stderr"
assert source.count(old)==1
source=source.replace(old,"assert name not in subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=root,text=True).splitlines()")
exec(compile(source,str(parent),'exec'))

"""Complete01 after its overly broad context anchor stopped before caller edits."""
from pathlib import Path

root = Path.cwd()

def replace(path, old, new):
    data = path.read_text(encoding='utf8')
    assert data.count(old) == 1, (str(path), old)
    path.write_bytes(data.replace(old, new).encode())

replace(root / 'crates/ep_run/src/pipeline.rs',
    '            let mut initialization = ctf_outputs.context();\n            let simulation = if let Some(reporting) = runtime_inputs.ordinary_warmup_reporting {',
    '''            let mut initialization = ctf_outputs.context();
            if let Some(input) = runtime_inputs.selected_input_processor.take() {
                initialization.reports.initialize_input_processor(input)
                    .map_err(|error| error.to_string())?;
            }
            let simulation = if let Some(reporting) = runtime_inputs.ordinary_warmup_reporting {''')
replace(root / 'crates/ep_run/src/ordinary_equipment_input.rs',
    '        super::design_day_projection::verify_admitted_design_day_projection()?;\n',
    '''        super::design_day_projection::verify_admitted_design_day_projection()?;
        crate::ordinary_input_processor::tests::verify_shared_input_boundary()?;
''')
path = root / 'crates/ep_run/src/ordinary_input_processor.rs'
assert '#[cfg(test)]' not in path.read_text(encoding='utf8')
with path.open('ab') as stream:
    stream.write(b'\n#[cfg(test)]\n#[path = "ordinary_input_processor_tests.rs"]\npub(crate) mod tests;\n')
print('Completed bounded context caller edits;01 partial anchor stop retained.')

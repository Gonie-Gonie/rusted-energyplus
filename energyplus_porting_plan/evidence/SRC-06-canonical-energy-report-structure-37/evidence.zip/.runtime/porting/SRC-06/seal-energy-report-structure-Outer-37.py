"""Seal exact accepted37-02 Sources on actual committed35; never apply/Cargo."""
from pathlib import Path
import argparse,copy,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
I=D/'source-energy-report-structure-draft-Outer-37-02';O=D/'source-energy-report-structure-held-Outer-37'
HEAD='e9f9a5a24d4faf68d7dc0a6cdd19e9bebc3cfcd9'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))
def contains(v,r):
 if isinstance(v,dict):return (v.get('path'),v.get('sha256'))==(r['path'],r['sha256']) or any(contains(x,r) for x in v.values())
 return isinstance(v,list) and any(contains(x,r) for x in v)
def main(a):
 assert not O.exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
 dr=ref(I/'draft.json');assert dr['sha256']=='c5ceb31ff711dc67ad757d909df9b0e037f7a3e7ee5d727dbaab8345b27661e8';m=json.loads(checked(dr).read_bytes())
 peerr=dict(path=a.peer,sha256=a.peer_sha);peer=json.loads(checked(peerr).read_bytes());peerr=ref(checked(peerr));assert peer['accepted'] and not peer.get('findings',[]) and contains(peer,dr)
 pp=D/'source-startup-connection-validation-report-held-Audit-35/complete-final-compiler-Source-plan.json';pr=ref(pp);assert pr['sha256']=='5a98c187ae7221137fb64654019110e4e170389e2d32e0bca0f592b49e62eedf';parent=json.loads(pp.read_bytes())
 ar=ref(D/'Root-source-startup-connection-validation-report-actual-review-35/review.json');assert ar['sha256']=='9dcd1e19b8c26adbc37cab859532dd96edde6b5bbfd9ebbe4465b4eb04979990';actual=json.loads(checked(ar).read_bytes());assert actual['accepted'] and not actual.get('findings',[]) and actual['complete_compiler_plan']==pr
 command=json.loads(checked(actual['actual_B']).read_bytes());snapshot=command['source_snapshot'];checked(snapshot)
 observed={r['historical_path']:r for r in json.loads(checked(snapshot).read_bytes())['files']}
 entries=parent['entries'];index={r['path']:r for r in entries};assert len(index)==len(observed)==4504 and parent['Rust_sources']==4491 and set(index)==set(observed)
 logical=json.loads(checked(m['logical35_parent_plan']).read_bytes());li={r['path']:r for r in logical['entries']};assert set(li)==set(index)
 for path,row in index.items():
  b=checked(row['source']).read_bytes();assert (len(b),hashlib.sha256(b).hexdigest())==(row['final_bytes'],row['final_sha256']);assert (R/path).read_bytes()==b,path
  assert (row['final_sha256'],row['final_bytes'])==(li[path]['final_sha256'],li[path]['final_bytes'])==(observed[path]['archive']['sha256'],observed[path]['size_bytes'])
 files=[];selected={}
 for i,row in enumerate(m['files'],1):
  path=row['canonical_path'];b=checked(row['before']).read_bytes();z=checked(row['proposed']).read_bytes();absent=row['before_absent']
  if absent:assert path not in index and not (R/path).exists() and not b
  else:assert (R/path).read_bytes()==b==checked(index[path]['source']).read_bytes()==subprocess.check_output(['git','show',f'{HEAD}:{path}'],cwd=R)
  out=dict(canonical_path=path,before_absent=absent)
  for key,sub in [('before','before'),('proposed','proposed'),('literal_inverse','literal-inverse')]:out[key]=save(O/sub/path,checked(row[key]).read_bytes())
  for key,tag in [('forward_diff','forward'),('inverse_diff','inverse')]:out[key]=save(O/'diffs'/f'{i:02}.{tag}.diff',checked(row[key]).read_bytes())
  q=row['Source_only_parse'];assert q['exit_code']==0;checked(q['stdout']);checked(q['stderr']);out['Source_only_parse']=q;out['whole_independently_accepted37_02_proposal_exact']=True
  assert checked(out['proposed']).read_bytes()==z and checked(out['literal_inverse']).read_bytes()==b
  files.append(out);selected[path]=out['proposed']
 final=copy.deepcopy(entries)
 for row in final:
  if row['path'] in selected:
   v=selected[row['path']];row.update(final_sha256=v['sha256'],final_bytes=v['bytes'],source=v,origin='Source37 accepted exact energy structure production child')
 for row in files:
  if row['before_absent']:
   v=row['proposed'];final.append(dict(path=row['canonical_path'],final_sha256=v['sha256'],final_bytes=v['bytes'],source=v,origin='Source37 actual Native connection/metered metadata/equipment structure child'))
 final.sort(key=lambda r:r['path']);assert len(final)==4507 and sum(r['path'].endswith('.rs') for r in final)==4494
 proposed=json.loads(checked(m['complete_proposed_compiler_Source_plan']).read_bytes());di={r['path']:r for r in proposed['entries']};assert set(di)=={r['path'] for r in final}
 for row in final:
  assert (row['final_sha256'],row['final_bytes'])==(di[row['path']]['final_sha256'],di[row['path']]['final_bytes'])
  if row['path'] not in selected:assert row==index[row['path']]
 plan=write(O/'complete-final-compiler-Source-plan.json',dict(schema='src06-complete-Source37-compiler-input-plan.v1',base_HEAD=HEAD,actual35_parent_review=ar,actual35_parent_snapshot=snapshot,prior_plan=pr,inputs=4507,Rust_sources=4494,selected_existing=6,selected_new=3,entries=final))
 authorities=m['Native_authorities']
 for a in authorities:
  checked(a['whole'])
  for e in a['extents']:checked(e['source'])
 for c in m['concrete_same_owner_contexts']:checked(c['whole']);assert (R/c['canonical_path']).read_bytes()==checked(c['whole']).read_bytes()
 pat=re.compile(rb'create_source_energy_report_structure\(|create_source_zone_equipment_energy_report_structure\(|get_source_component_data\(|is_source_parent_object\(|get_source_number_metered_variables\(|get_source_metered_variables\(|SourceMeterData|SourceMeteredVariable|SourceSystemReportOwners\s*\{');rows=[]
 for row in final:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  for line,t in enumerate(checked(row['source']).read_bytes().splitlines(),1):
   if pat.search(t):rows.append(dict(path=row['path'],line=line,text=t.decode('utf-8')))
 cr=write(O/'whole-crates-final-API-census.json',dict(complete_plan=plan,whole_crates=True,Rust_sources=4494,fixture_bodies_excluded=True,rows=rows))
 result=dict(schema='src06-held-energy-report-structure-Source37.v1',status='HELD full Source peer accepted; Root independent application and actual engine pending',base_HEAD=HEAD,accepted35_actual_review=ar,actual_parent_snapshot=snapshot,parent_producer=ref(D/'source-startup-connection-validation-report-held-Audit-35/manifest.json'),prior_complete_compiler_Source_plan=pr,complete_final_compiler_Source_plan=plan,original_draft=dr,independent_full_semantic_peer=peerr,compiler_inputs=4507,Rust_sources=4494,files=files,Source_files=9,existing_Source_files=6,new_Source_files=3,literal_applications=18,Source_only_parses=9,full4504_parent_readback=dict(inputs=4504,Rust_sources=4491,all_archived_and_live_wholes_exact=True,all_actual_snapshot_entries_exact=True,all_logical35_whole_operands_exact_actual_parent=True,all_unselected_parent_entries_whole_preserved=True,selected6_committed35_Git_wholes_exact=True,known_unselected_Git_comment_CR_bridge_unchanged=True),whole4494_Rust_API_census=cr,Native_commit=m['Native_commit'],Native_authorities=authorities,concrete_same_owner_contexts=m['concrete_same_owner_contexts'],integration_contract=m['contract'],import_finding_correction=m['import_correction'],original_import_draft_preserved=m['original_rejected_import_draft'],all_parent_cohort_test_main_feature_Cargo_inputs_unchanged=True,new_test_bodies=0,actual_test_bodies_executed=0,author_Source=ref(Path(__file__)),canonical_Source_Cargo_Native_tests_or_publication_mutations=False)
 out=O/'manifest.json';write(out,result);print(json.dumps(ref(out)));print(json.dumps(plan))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--peer',required=True);ap.add_argument('--peer-sha',required=True);main(ap.parse_args())

"""Prepare prospective37 on exact logical combined35. No apply/Cargo/final seal."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
O=D/'source-energy-report-structure-draft-Outer-37';N=R/'.reference/energyplus-src/26.1.0'
PIN='6f2e40d10250a105b49966baa24d843711e61048'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def save(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
def write(p,v):return save(p,(json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'))
def main():
 assert not (O/'draft.json').exists()
 logical=D/'source-startup-connection-validation-report-draft-Audit-35/draft.json'
 assert ref(logical)['sha256']=='ceb65bce1f146d94f749c66073f724eb3b6a8375e23d71277d61c83cce225601'
 lm=json.loads(logical.read_bytes());pr=lm['complete_proposed_compiler_Source_plan'];parent=json.loads(checked(pr).read_bytes())
 entries=parent['entries'];index={r['path']:r for r in entries};assert len(index)==4504 and parent['Rust_sources']==4491
 def before(path):return checked(index[path]['source']).read_bytes()
 proposals={}
 def replace(path,old,new):
  b=proposals.get(path,(before(path),before(path)))[1];a=old.encode();z=new.encode();assert b.count(a)==1,(path,old[:100]);proposals[path]=(before(path),b.replace(a,z,1))
 nodes='crates/ep_runtime/src/heat_balance/startup_integrity/nodes.rs'
 replace(nodes,'mod registration;\n','mod registration;\nmod component_data;\n')
 op='crates/ep_runtime/src/heat_balance/source_output_registration.rs'
 replace(op,'mod meters;\n','mod meters;\nmod metered_variables;\npub(crate) use metered_variables::{SourceMeterData, SourceMeteredVariable, SourceMeterHeatOrCool};\n')
 eq='crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'
 replace(eq,'mod source_equipment_types;\n','mod source_equipment_types;\nmod source_energy_report;\n')
 types='crates/ep_runtime/src/heat_balance/ordinary_equipment/source_equipment_types.rs'
 replace(types,'use std::convert::Infallible;\n','use std::convert::Infallible;\nuse crate::heat_balance::source_output_registration::SourceMeterData;\n')
 replace(types,'pub(super) metered_variables: Option<Vec<Infallible>>,','pub(super) metered_variables: Option<Vec<SourceMeterData>>,')
 init='crates/ep_runtime/src/heat_balance/ordinary_system_reports/initialization.rs'
 old=before(init).decode();start=old.index('    /// Actual SimulationManager333 call;');stop=old.index('    pub(crate) fn initialize_source_energy_reports(',start)
 new='''    /// Actual SimulationManager333 call; the flag write precedes all loops.
    pub(crate) fn create_source_energy_report_structure(
        &mut self,
        globals: &SelectedHeatBalanceGlobals,
        hvac: &SelectedHvacGlobals,
        equipment: &mut OrdinaryEquipment,
        branch: &crate::heat_balance::startup_integrity::SourceBranchNodeConnections,
        registration: &SourceOutputRegistration,
    ) -> Result<(), Error> {
        self.vent_report_structure_created = true;
        if hvac.number_of_primary_air_systems > 0 {
            return Err(Error::Unavailable(
                "actual CreateEnergyReportStructure2246 PrimaryAirSystems.NumBranches",
            ));
        }
        // Both actual primary-system outer loops have zero rows here.
        equipment.create_source_zone_equipment_energy_report_structure(
            globals.num_of_zones, branch, registration,
        )?;
        let total = hvac.number_plant_loops.checked_add(hvac.number_condenser_loops)
            .ok_or(Error::Unavailable("undefined plant plus condenser loop count2747"))?;
        if total > 0 {
            return Err(Error::Unavailable(
                "actual CreateEnergyReportStructure2755/2758 live VentRepPlant/VentRepCond row",
            ));
        }
        // Both real outer plant loops2747/2877 have zero actual rows.
        Ok(())
    }

'''
 replace(init,old[start:stop],new)
 host='crates/ep_runtime/src/heat_balance/ordinary_source_simulation/prelude_host.rs'
 old=before(host).decode();start=old.index('    fn create_energy_report_structure(&mut self)');stop=old.index('    fn produce_rdd_mdd(&mut self)',start)
 new='''    fn create_energy_report_structure(&mut self) -> Result<(), RuntimeError> {
        let session = required(
            self.session.as_mut(), "actual SystemReports before energy structure",
        )?;
        let globals = required(
            self.reports.selected_heat_balance_globals.as_ref(),
            "actual globals before energy structure",
        )?;
        let hvac = &required(
            self.reports.selected_simulation_startup.as_ref(),
            "actual HVAC globals before energy structure",
        )?.hvac_globals;
        let equipment = required(
            self.reports.source_zone_equipment.as_mut(),
            "actual zone equipment before energy structure",
        )?;
        let ancillary = &mut session.hvac.ancillary;
        ancillary.system_reports.create_source_energy_report_structure(
            globals, hvac, equipment, &ancillary.branch_node_connections,
            &self.reports.output_registration,
        ).map_err(hb_input_error)
    }
'''
 replace(host,old[start:stop],new)
 for path in [
  'crates/ep_runtime/src/heat_balance/startup_integrity/nodes/component_data.rs',
  'crates/ep_runtime/src/heat_balance/source_output_registration/metered_variables.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_energy_report.rs',
 ]:
  assert path not in index;proposals[path]=(b'',(O/'proposed'/path).read_bytes())
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal apply>','exec'),ns)
 files=[]
 for i,(path,(b,a)) in enumerate(proposals.items(),1):
  orig=path if b else '/dev/null';fd=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile=orig,tofile=path)).encode();iv=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile=path,tofile=orig)).encode()
  assert ns['apply'](b,fd)==a and ns['apply'](a,iv)==b
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=a,capture_output=True);assert q.returncode==0,(path,q.stderr)
  files.append(dict(canonical_path=path,before_absent=not b,before=save(O/'before'/path,b),proposed=save(O/'proposed'/path,a),literal_inverse=save(O/'literal-inverse'/path,b),forward_diff=save(O/'diffs'/f'{i:02}.forward.diff',fd),inverse_diff=save(O/'diffs'/f'{i:02}.inverse.diff',iv),Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))))
 final=copy.deepcopy(entries);selected={x['canonical_path']:x['proposed'] for x in files}
 for row in final:
  if row['path'] in selected:
   r=selected[row['path']];row.update(final_sha256=r['sha256'],final_bytes=r['bytes'],source=r,origin='Prospective37 genuine energy report structure')
 for path in proposals:
  if path not in index:
   r=selected[path];final.append(dict(path=path,final_sha256=r['sha256'],final_bytes=r['bytes'],source=r,origin='Prospective37 actual Native per-call child/retained metered metadata'))
 final.sort(key=lambda r:r['path']);assert len(final)==4507 and sum(r['path'].endswith('.rs') for r in final)==4494
 plan=write(O/'complete-proposed-compiler-Source-plan.json',dict(schema='src06-prospective-Source37-compiler-input-plan.v1',logical_parent35=ref(logical),logical_parent_plan=pr,inputs=4507,Rust_sources=4494,selected_existing=6,selected_new=3,entries=final))
 # Exact complete logical compiler input archive authentication; current main
 # may contain Root's already applied35, so this is not a false all-live claim.
 for row in entries:
  b=checked(row['source']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['final_sha256'] and len(b)==row['final_bytes']
 contexts=[]
 for path in [
  'crates/ep_runtime/src/heat_balance/ordinary_system_reports.rs',
  'crates/ep_runtime/src/heat_balance/startup_integrity/nodes/registration.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_controlled_equipment.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_purchased_air/registration.rs',
  'crates/ep_runtime/src/heat_balance/source_output_registration/bound_real.rs',
  'crates/ep_runtime/src/heat_balance/source_output_registration/general_real.rs',
  'crates/ep_runtime/src/heat_balance/source_output_registration/meters.rs',
  'crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/remaining.rs',
 ]:contexts.append(dict(canonical_path=path,whole=save(O/'contexts'/path,before(path))))
 spans={
  'src/EnergyPlus/SystemReports.cc':[(2194,2246),(2496,2736),(2747,2758),(2877,2895)],
  'src/EnergyPlus/BranchNodeConnections.cc':[(1476,1506),(1600,1625),(1655,1781)],
  'src/EnergyPlus/OutputProcessor.cc':[(4306,4413)],
  'src/EnergyPlus/OutputProcessor.hh':[(169,241),(589,613)],
  'src/EnergyPlus/DataZoneEquipment.hh':[(385,448)],
  'src/EnergyPlus/DataGlobalConstants.hh':[(550,558)],
 }
 authorities=[]
 for name,ss in spans.items():
  p=N/name;b=p.read_bytes();assert b==subprocess.check_output(['git','-C',str(N),'show',f'{PIN}:{name}']);lines=b.decode().splitlines(keepends=True);xs=[]
  for a,z in ss:xs.append(dict(first=a,last=z,source=save(O/'Native'/f'{p.stem}-{a}-{z}.txt',''.join(lines[a-1:z]).encode())))
  authorities.append(dict(whole=ref(p),Native_path=name,pinned_Git=PIN,extents=xs))
 pat=re.compile(rb'create_source_energy_report_structure\(|create_source_zone_equipment_energy_report_structure\(|get_source_component_data\(|is_source_parent_object\(|get_source_number_metered_variables\(|get_source_metered_variables\(|SourceMeterData|SourceMeteredVariable|SourceSystemReportOwners\s*\{')
 census=[]
 for row in final:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  b=checked(row['source']).read_bytes()
  for line,t in enumerate(b.splitlines(),1):
   if pat.search(t):census.append(dict(path=row['path'],line=line,text=t.decode('utf-8')))
 cr=write(O/'whole-crates-logical-final-API-census.json',dict(complete_plan=plan,whole_crates=True,Rust_sources=4494,fixture_bodies_excluded=True,rows=census))
 draft=dict(schema='src06-prospective-energy-report-structure-draft37.v1',status='FROZEN_SOURCE_FOR_INDEPENDENT_PEER_LOGICAL35_PARENT_FINAL_ACTUAL_COMMIT_PENDING',logical35_parent=ref(logical),logical35_parent_plan=pr,complete_proposed_compiler_Source_plan=plan,files=files,Source_files=9,existing_Source_files=6,new_Source_files=3,literal_applications=18,Source_only_parses=9,new_test_bodies=0,Native_commit=PIN,Native_authorities=authorities,concrete_same_owner_contexts=contexts,whole4494_Rust_API_census=cr,prior_full_readonly_map=ref(D/'prospective-system-report-equipment-readonly-plan-Outer-35/plan.json'),contextual_API_map=ref(D/'prospective-system-report-equipment-context-Outer-37/plan.json'),contract=dict(owners='SAME retained Branch registry, same OutputRegistration/meters and same EquipmentList/EquipData; only actual per-call Native output arrays/local metadata copies, no copied registry/equipment owner or scalar cache.',creation='Real flag2244 then primary guards, controlled parallel-zone loops2496/2663 on real borrowed List readers, live GetComponentData/OP metered getters and real EquipmentData writes, then existing actual plant zero/positive boundary and genuine routine return.',metadata='Full nine explicit MeteredVar base ctor defaults, None means actual enum Invalid; derived HeatOrCool/currentReading explicit; base-only assignment preserves derived fields. Existing Source end-use subset explicit ordinals match pinned Native EndUseCat; HeatingCoils33/CoolingCoils22 are distinct from Heating0/Cooling1.',branch='GetComponentData Parent OR over all exact matching rows, six deallocate/count/allocate/fill/refill outputs in Native order. IsParentObject first exact matching row and break, then real CompSets fallback; positive unrepresented CompSets stops at actual ParentObjectType1617.',boundaries='Actual unrepresented type mapping at2505, CompSets1617, true parent GetNumChildren2570 and positive retained second-pass child2665 remain honest typed children. Positive primary/plant original boundaries retained. No all-SystemReports/InitEnergyReports/fullB or diagnostic completion claim.',caller='Only Create333 caller takes direct real globals/HVAC plus mutable actual Equipment and immutable actual Branch/OP; removes only its unused generic owner-view construction. Other two SourceSystemReportOwners constructors and all existing reports/readers unchanged.',validation='Syntax/literal/owner/API only. Root alone may compile/actual B/A after accepted final parent. No new tests/FP/cache/tolerance/math/policy/gate changes.'),all_logical4504_parent_wholes_authenticated=True,all_unselected_logical_parent_entries_preserved=True,final_actual35_committed_parent_pending=True,author_Source=ref(Path(__file__)),canonical_Source_Cargo_Native_tests_or_publication_mutations=False)
 out=O/'draft.json';write(out,draft);print(json.dumps(ref(out)));print(json.dumps(plan))
if __name__=='__main__':main()

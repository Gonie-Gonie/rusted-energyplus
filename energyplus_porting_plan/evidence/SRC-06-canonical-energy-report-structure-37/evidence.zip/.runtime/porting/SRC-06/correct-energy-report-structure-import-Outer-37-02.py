"""Immutable import-only successor; preserves frozen37-01 and all semantics."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re,shutil,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
I=D/'source-energy-report-structure-draft-Outer-37';O=D/'source-energy-report-structure-draft-Outer-37-02'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(r):
 p=R/r['path'];v=ref(p);assert v['sha256']==r['sha256'] and v['bytes']==r.get('bytes',v['bytes']);return p
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=True,indent=2)+'\n').encode('utf-8'));return ref(p)
def main():
 assert not O.exists();original=ref(I/'draft.json');assert original['sha256']=='de3e2a7eea485e0207279f1a014cbdd1da6421944ea1980dc520e13cdf8cb862'
 old=json.loads(checked(original).read_bytes());shutil.copytree(I,O)
 path='crates/ep_runtime/src/heat_balance/source_output_registration/metered_variables.rs';p=O/'proposed'/path
 b=p.read_bytes();a=b'use super::{SourceMeterEndUse, SourceMeterGroup, SourceMeterResource, SourceOutputRegistration, SourceOutputUnits, SourceOutputVariableType, TimeStepKind};'
 z=b'use super::bound_real::SourceOutputVariableType;\nuse super::{SourceMeterEndUse, SourceMeterGroup, SourceMeterResource, SourceOutputRegistration, SourceOutputUnits, TimeStepKind};'
 assert b.count(a)==1;after=b.replace(a,z,1);assert after.replace(z,a,1)==b;p.write_bytes(after)
 oldprefix=I.relative_to(R).as_posix()+'/'
 newprefix=O.relative_to(R).as_posix()+'/'
 def rebound(v):
  if isinstance(v,dict):
   out={k:rebound(x) for k,x in v.items()}
   if isinstance(v.get('path'),str) and v['path'].startswith(oldprefix) and 'sha256' in v:
    out.update(ref(R/(newprefix+v['path'][len(oldprefix):])))
   return out
  if isinstance(v,list):return [rebound(x) for x in v]
  return v
 m=rebound(old)
 for row in m['files']:
  canonical=row['canonical_path'];before=checked(row['before']).read_bytes();proposed=checked(row['proposed']).read_bytes()
  orig=canonical if before else '/dev/null'
  for key,left,right,fr,to in [('forward_diff',before,proposed,orig,canonical),('inverse_diff',proposed,before,canonical,orig)]:
   q=R/row[key]['path'];q.write_bytes(''.join(difflib.unified_diff(left.decode().splitlines(True),right.decode().splitlines(True),fromfile=fr,tofile=to)).encode());row[key]=ref(q)
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=proposed,capture_output=True);assert q.returncode==0,q.stderr
  for key,data in [('stdout',q.stdout),('stderr',q.stderr)]:
   out=R/row['Source_only_parse'][key]['path'];out.write_bytes(data);row['Source_only_parse'][key]=ref(out)
 tree=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<literal apply>','exec'),ns)
 for row in m['files']:
  before=checked(row['before']).read_bytes();after=checked(row['proposed']).read_bytes();assert ns['apply'](before,checked(row['forward_diff']).read_bytes())==after and ns['apply'](after,checked(row['inverse_diff']).read_bytes())==before
 plan=rebound(json.loads(checked(old['complete_proposed_compiler_Source_plan']).read_bytes()));selected={r['canonical_path']:r['proposed'] for r in m['files']}
 for row in plan['entries']:
  if row['path'] in selected:
   v=selected[row['path']];row.update(final_sha256=v['sha256'],final_bytes=v['bytes'],source=v)
 planref=write(O/'complete-proposed-compiler-Source-plan.json',plan)
 pat=re.compile(rb'create_source_energy_report_structure\(|create_source_zone_equipment_energy_report_structure\(|get_source_component_data\(|is_source_parent_object\(|get_source_number_metered_variables\(|get_source_metered_variables\(|SourceMeterData|SourceMeteredVariable|SourceSystemReportOwners\s*\{')
 rows=[]
 for row in plan['entries']:
  if not row['path'].endswith('.rs') or '/fixtures/' in row['path']:continue
  for line,t in enumerate(checked(row['source']).read_bytes().splitlines(),1):
   if pat.search(t):rows.append(dict(path=row['path'],line=line,text=t.decode('utf-8')))
 cr=write(O/'whole-crates-logical-final-API-census.json',dict(complete_plan=planref,whole_crates=True,Rust_sources=4494,fixture_bodies_excluded=True,rows=rows))
 proof=write(O/'import-correction.json',dict(original_draft=original,reason='Concrete API check found SourceOutputVariableType is defined in sibling bound_real and is not reexported by OP root. Source-only syntax parses did not certify contextual imports.',canonical_path=path,original=ref(I/'proposed'/path),corrected=ref(p),before_literal=a.decode(),after_literal=z.decode(),removing_only_import_correction_restores_original_whole=True,other_eight_proposals_whole_identical=True,Native_math_owner_order_metadata_unchanged=True,author_Source=ref(Path(__file__))))
 for row in m['files']:
  oldrow=next(x for x in old['files'] if x['canonical_path']==row['canonical_path'])
  if row['canonical_path']!=path:assert checked(row['proposed']).read_bytes()==checked(oldrow['proposed']).read_bytes()
 m.update(status='FROZEN_SOURCE37_02_IMPORT_CORRECTED_FOR_FULL_INDEPENDENT_PEER_FINAL35_PARENT_PENDING',original_rejected_import_draft=original,import_correction=proof,complete_proposed_compiler_Source_plan=planref,whole4494_Rust_API_census=cr,original_author_Source=old['author_Source'],author_Source=ref(Path(__file__)))
 dr=write(O/'draft.json',m);print(json.dumps(dr));print(json.dumps(planref))
if __name__=='__main__':main()

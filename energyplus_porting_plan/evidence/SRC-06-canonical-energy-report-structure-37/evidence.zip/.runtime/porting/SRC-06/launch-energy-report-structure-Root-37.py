from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={'B': ('canonical-source-startup-connection-validation-report-B-NOLIMIT-24H-command-Root-35/receipt.json', 'b95c0618923b60dd66bf2f692675acef15c5f749bc6f5db4a88b0c2aa847281e'), 'A24': ('canonical-source-startup-connection-validation-report-A-24H-command-Root-35/receipt.json', '4202c121f0216e19c6a51a9be091c1476dd275b55bdf3929c467562323eef66c')}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-energy-report-structure-'+case+'-command-Root-37'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-energy-report-structure-'+case+'-Root-37/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

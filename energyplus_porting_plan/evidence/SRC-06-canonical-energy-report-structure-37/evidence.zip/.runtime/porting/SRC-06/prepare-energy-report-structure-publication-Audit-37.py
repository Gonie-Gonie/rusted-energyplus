from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';OLD=D/'publish-startup-connection-validation-report-checkpoint-Audit-35.py';NEW=D/'publish-energy-report-structure-checkpoint-Audit-37.py'
O=D/'energy-report-structure-publication-prepared-Audit-37'
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def auth(x):
 p=R/x['path'];v=ref(p);assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size_bytes',v['bytes']));return p
mp=D/'source-energy-report-structure-held-Outer-37/manifest.json';m=json.loads(mp.read_bytes());peer=json.loads(auth(m['independent_full_semantic_peer']).read_bytes());assert peer['accepted'] and not peer['findings']
dp=auth(m['original_draft']);draft=json.loads(dp.read_bytes());assert ref(dp)['sha256']=='c5ceb31ff711dc67ad757d909df9b0e037f7a3e7ee5d727dbaab8345b27661e8'
assert not NEW.exists() and not O.exists();before=OLD.read_text(encoding='utf8');s=before
s=s.replace('engine35','engine37').replace('final five-file','final nine-file').replace('startup-connection-validation-report','energy-report-structure').replace('Audit-35','Audit-37').replace('ACTUAL35','ACTUAL37')
s=s.replace('energy-report-structure-35','energy-report-structure-37')
s=s.replace("len(producer['files'])==5 and producer['existing_Source_files']==4 and producer['new_Source_files']==1","len(producer['files'])==9 and producer['existing_Source_files']==6 and producer['new_Source_files']==3")
s=s.replace('(4504,4491)','(4507,4494)').replace('same4504_archived_inputs_exact_final_plan','same4507_archived_inputs_exact_final_plan').replace('len(observed)==4504','len(observed)==4507').replace('selected5_final_sources_exact','selected9_final_sources_exact')
s=s.replace('equal34','equal35').replace('accepted34_full5352_proof','accepted35_full5352_proof').replace('accepted34_proof','accepted35_proof').replace('Accepted34 A24 proof transfer','Accepted35 A24 proof transfer')
s=s.replace('Root-35/output','Root-37/output').replace('src06-canonical35-finite','src06-canonical37-finite')
s=s.replace('Four existing and one new production Sources','Six existing and three new production Sources').replace('The parent34 A24 proof is separately attributed; no cohort or new Native rerun by35.','The parent35 A24 proof is separately attributed; no cohort or new Native rerun by37.')
s=s.replace("status='Genuine Source startup connection validation and reporting; actual B result recorded'","status='Genuine Source energy report structure on actual connected equipment and metered-variable owners; actual B result recorded'")
s=s.replace('[Source35 startup connection validation/report]','[Source37 energy report structure]')
s=s.replace('canonical_startup_connection_validation_report_35','canonical_energy_report_structure_37').replace('actual_test_bodies_executed_by35','actual_test_bodies_executed_by37')
assert 'selected5' not in s and "'new_Source_files']==1" not in s and 'equal34' not in s and 'len(observed)==4504' not in s
ast.parse(s);NEW.write_bytes(s.encode());O.mkdir()
for name,a,b in [('publisher-forward.diff',before,s),('publisher-inverse.diff',s,before)]:
 (O/name).write_bytes(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='accepted35-publisher' if name.startswith('publisher-forward') else 'Source37-publisher',tofile='Source37-publisher' if name.startswith('publisher-forward') else 'accepted35-publisher')).encode())
finite={}
def add(row):p=auth(row);finite[ref(p)['path']]=ref(p)
assert m['full4504_parent_readback']['inputs']==4504 and m['full4504_parent_readback']['all_archived_and_live_wholes_exact']
assert isinstance(m['integration_contract'],dict) and m['all_parent_cohort_test_main_feature_Cargo_inputs_unchanged']
for key in ['complete_final_compiler_Source_plan','independent_full_semantic_peer','original_draft','author_Source','accepted35_actual_review','whole4494_Rust_API_census']:
 add(m[key])
for row in [ref(mp),ref(Path(__file__)),ref(OLD),ref(O/'publisher-forward.diff'),ref(O/'publisher-inverse.diff'),draft['author_Source'],draft['original_author_Source'],draft['import_correction'],draft['original_rejected_import_draft']]:add(row)
for key in ('prior_full_readonly_map','contextual_API_map'):
 if key in draft:add(draft[key])
for row in m['files']:
 for k in ('before','proposed','literal_inverse','forward_diff','inverse_diff'):
  if row.get(k):add(row[k])
 for k in ('stdout','stderr'):add(row['Source_only_parse'][k])
for row in m['Native_authorities']:
 add(row['whole'])
 for e in row['extents']:add(e['source'])
for row in m['concrete_same_owner_contexts']:add(row['whole'])
prior=json.loads((R/'energyplus_porting_plan/plan.json').read_bytes());task=next(x for x in prior['tasks'] if x['id']=='SRC-06');previous=task['canonical_startup_connection_validation_report_35'];add(previous)
t={'schema':'src06-energy-report-structure-publication-template.v1','status':'WAITING_FOR_ROOT_ACTUAL37_AND_FULL_READ',
 'base_HEAD':m['base_HEAD'],'publisher_Source':ref(NEW),'producer':ref(mp),'complete_plan':m['complete_final_compiler_Source_plan'],
 'independent_peer':m['independent_full_semantic_peer'],'accepted_parent_review':m['accepted35_actual_review'],'accepted_parent_plan':m['prior_complete_compiler_Source_plan'],
 'expected_actual_review_path':'.runtime/porting/SRC-06/Root-source-energy-report-structure-actual-review-37/review.json','previous_engine_checkpoint':previous,'finite_archive_inputs':list(finite.values()),
 'summary_template':{'A':'14/54','B':'14/64','gate_changes':False,'policy_changes':False,'selected_existing_production_Sources':6,'new_production_Source_files':3,'selected_production_Sources':9,
  'corrected02_full_semantic_review_used':True,'actual_Branch_OutputRegistration_Equipment_owners':True,'new_test_bodies':0,'actual_test_bodies_executed':0,
  'scope':'Controlled energy report structure creation uses the same actual equipment lists, connection registry, OutputProcessor metered-variable metadata and retained EquipmentData. Native temporary allocation/copy/write order is preserved. Positive unrepresented parent/child/system/diagnostic branches remain explicit boundaries.',
  'qualification':'Actual B frontier and any retained-Native BND comparison are recorded only from accepted Root37 execution, not inferred from Source35. A24 original5352 proof is transferred only after current-run strict equal35 checks. No scientific/math/tolerance changes or new tests; existing full Native cohort is unchanged and not rerun.'},
 'doc_appends':{
 'cards/SRC-06.md':'제어 구역 장비 목록과 실제 연결·계량변수 조회 결과로 에너지 보고 구조를 만들도록 연결했다. 같은 EquipmentData에 기록하며 미구현 부모·자식·다른 계통은 실제 연산 경계로 남긴다. B 실행 결과: `{{actual_B_result}}`. A24의 기존 5,352개 보고값 증거를 이어받고 새 테스트나 계산식 변경은 없다.',
 'CHECKLIST.md':'에너지 보고 구조 생성 경로를 기존 파일 6개와 새 파일 3개로 연결했다. 실제 B/A24 한 쌍을 확인하며, 추가 테스트나 별도 Native 실행은 없다. 게이트 수는 그대로다.',
 'STATE_CONTRACTS.md':'GetComponentData와 계량변수 조회는 같은 Branch·OutputRegistration·장비 소유자를 빌린다. Native의 임시 배열 초기화·복사·EquipmentData 기록 순서를 유지하며, 보고용 대체 소유자나 계산값 캐시는 추가하지 않는다.'}}
for text in t['doc_appends'].values():assert '\ufffd' not in text and '?' not in text
q=O/'publication-template.json';q.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode());print(json.dumps({'publisher':ref(NEW),'template':ref(q)}))

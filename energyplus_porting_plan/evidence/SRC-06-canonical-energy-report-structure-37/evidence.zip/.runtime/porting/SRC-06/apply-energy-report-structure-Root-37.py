from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-energy-report-structure-application-37';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-energy-report-structure-held-Outer-37/manifest.json');assert mr['sha256']=='2d5d6b30eab50a8eed168b12eabcc7ef3f072e5d22610cb303b1e44b86b0c99a';m=json.loads(checked(mr));pr=m['independent_full_semantic_peer'];assert pr['sha256']=='62224d168f09366e6a4f93dba16207dc2ac35ea4f34effe343c5d2f79be9f60b';peer=json.loads(checked(pr));assert peer['accepted'] and not peer['findings'] and peer['reviewed_draft']==m['original_draft'];peerfiles={v['canonical_path']:v for v in peer['files']};draft=json.loads(checked(m['original_draft']));draftfiles={v['canonical_path']:v for v in draft['files']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='e9f9a5a24d4faf68d7dc0a6cdd19e9bebc3cfcd9' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4504 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(draftfiles[n]['proposed'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==9 and len(new)==3 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==6 and extent_count==12
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted35_actual_review','parent_producer','prior_complete_compiler_Source_plan','full4504_parent_readback','whole4494_Rust_API_census','original_draft']:checked(m[k])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4507 and sum(n.endswith('.rs') for n in rows)==4494
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
assert m['integration_contract']==draft['contract'] and m['all_parent_cohort_test_main_feature_Cargo_inputs_unchanged']
correction=json.loads(checked(m['import_finding_correction']));checked(m['original_import_draft_preserved']);assert checked(correction['corrected']).count(correction['after_literal'].encode())==1 and checked(correction['corrected']).replace(correction['after_literal'].encode(),correction['before_literal'].encode(),1)==checked(correction['original'])
equipment=selected['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs'];assert checked(equipment['before']).rsplit(b'#[cfg(test)]',1)[-1]==checked(equipment['proposed']).rsplit(b'#[cfg(test)]',1)[-1]
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_peer=pr,peer_scope='Full independent nine Source corrected02 semantics and exact proposal wholes; Root independently authenticates committed35 parent4504 and complete4507/4494 compiler join.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4504,final_inputs=4507,final_Rust_sources=4494,selected_Rust=9,new_Rust=3,literal_applications=18,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root read six existing forward diffs and all three new complete bodies01, then exact02 import correction; pinned Native full GetComponentData/IsParent/CompSets fallback, controlled Create2496-2736 and normal zero-primary/plant suffix, OP4306-4413 metadata/full9base+derived defaults and all relevant enum/owner contexts. Actual six child output arrays deallocate/count/allocate/fill/refill in order, parent OR versus first matching row distinction retained; same OP variables use exact key and zero-based indices, resource first meter and first valid endUse/group. Same EquipData outlet/inlet/parent/meter writes and derived-preserving base assignment, distinct HeatingCoils33/CoolingCoils22 classification and real retained second-pass NumSub preserved. Only real mutable Equipment plus same Branch/OP passed at actual Create caller. Local Native ErrorsFound is not invented; trueparent child stops before consume. No new physical state/scalar cache, formulas, tests, tolerance or gate change. Full unchanged cohort and equipment loader suffix retained. Actual B/A37 pending.',author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))

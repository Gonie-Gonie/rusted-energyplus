"""Root-only six missing limit-duration Source/Native runs; no implicit execution."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, sys
R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'

def ref(p):
    p = p.resolve()
    with p.open('rb') as f:
        h = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(), sha256=h, bytes=p.stat().st_size)

def checked(v):
    p = (R / v['path']).resolve()
    assert p.is_relative_to(R)
    q = ref(p)
    assert q['sha256'] == v['sha256'] and q['bytes'] == v.get('bytes', q['bytes']), v
    return p

def argument(v):
    p, h = v.rsplit('#', 1)
    return ref(checked(dict(path=p, sha256=h)))

def full_code(plan):
    assert plan['status'] == 'READY_ROOT_EXECUTION_ONLY' and plan['base_HEAD']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == plan['base_HEAD']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
    app = json.loads(checked(plan['Source43_application']).read_bytes())
    assert app['accepted'] and not app['findings'] and app['base_HEAD'] == plan['application_base_HEAD']
    assert app['complete_compiler_plan'] == plan['complete_compiler_plan']
    code = json.loads(checked(plan['complete_compiler_plan']).read_bytes())
    assert (code['inputs'], code['Rust_sources']) == (4517, 4504)
    inventory = {p.relative_to(R).as_posix() for p in (R/'crates').rglob('*.rs')} | {p.relative_to(R).as_posix() for p in (R/'crates').rglob('Cargo.toml')} | {'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
    assert inventory == {v['path'] for v in code['entries']}
    for v in code['entries']:
        q = ref(R / v['path'])
        assert (q['sha256'], q['bytes']) == (v['final_sha256'], v['final_bytes']), v['path']
    return code

def main(a):
    assert a.execute, 'Root explicit --execute required'
    pr = argument(a.plan)
    plan = json.loads(checked(pr).read_bytes())
    assert ref(Path(__file__)) == plan['launch_Source']
    assert re.fullmatch(r'Root-[0-9]+(?:-[A-Za-z0-9]+)*', a.run_label)
    code = full_code(plan)
    case = next(v for v in plan['cases'] if v['case'] == a.case)
    assert case['duration'] in ('72H', 'ANNUAL') and case['Native_baseline']['status'] == 'MISSING_REQUIRES_GENUINE_FRESH_ENGINE'
    for k in ('input','metadata','weather'):
        checked(case[k])
    for k in ('input','metadata'):
        assert subprocess.check_output(['git','show',plan['base_HEAD']+':'+case[k]['path']],cwd=R) == checked(case[k]).read_bytes()
    meta = json.loads(checked(case['metadata']).read_bytes())
    assert (meta['id'],meta['scope'],meta['duration'],meta['limit_variant']) == (a.case,'B',case['duration'],case['limit_variant'])
    assert meta['expected_zone_steps_excluding_warmup'] == case['expected_zone_steps_excluding_warmup']
    assert meta['input']['sha256'] == case['input']['sha256'] and meta['weather']['sha256'] == case['weather']['sha256']
    pins_before = [ref(checked(v)) for v in plan['installed_runtime_pins']]
    kind = 'source' if a.engine == 'Source' else 'native-installed'
    stem = f'{kind}-limit-duration-{a.case}'
    out = D / f'{stem}-{a.run_label}/output'
    receipt = D / f'{stem}-command-{a.run_label}'
    custody = D / f'{stem}-custody-{a.run_label}'
    assert not out.parent.exists() and not receipt.exists() and not custody.exists()
    env = dict(os.environ)
    source24 = None
    if a.engine == 'Source':
        focused = json.loads(checked(plan['accepted_Source43_focused59']).read_bytes())
        assert focused['accepted'] and not focused['findings'] and focused['application'] == plan['Source43_application']
        assert focused['complete_compiler_plan'] == plan['complete_compiler_plan'] and focused['Source_cases_bit_exact'] == 59
        rp = D / f"canonical-source-hard-sized-purchased-air-B-{case['limit_variant']}-24H-command-Root-43/receipt.json"
        source24 = ref(rp)
        parent = json.loads(checked(source24).read_bytes())
        assert parent['schema'] == 'recorded-porting-command.v1' and parent['exit_code'] == 0 and parent['launch_error'] is None and parent['source_bytes_match_before_and_after']
        assert parent['source_snapshot'] == focused['actual_snapshot']
        cmd = list(parent['command'])
        assert cmd[:2] == ['cargo','run'] and cmd[cmd.index('--bin')+1] == 'eplus-rs'
        assert '--features' not in cmd[:cmd.index('--')] and not {'test','--all-targets','--oracle-baseline','--compare-oracle','--hours'} & set(cmd)
        assert cmd[cmd.index('--porting-scope')+1] == 'B'
        at = [i for i,v in enumerate(cmd) if v.lower().endswith('.idf')]
        assert len(at) == 1
        assert Path(cmd[at[0]]).resolve() == (R/'energyplus_porting_plan/cases'/f"B-{case['limit_variant']}-24H/input.idf").resolve()
        cmd[at[0]] = checked(case['input']).as_posix()
        cmd[cmd.index('--weather')+1] = checked(case['weather']).as_posix()
        cmd[cmd.index('--output-dir')+1] = out.as_posix()
        target = (D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
        assert target.is_dir()
        env['CARGO_TARGET_DIR'] = str(target)
        env['CARGO_INCREMENTAL'] = '0'
        for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','RUSTUP_TOOLCHAIN','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_HOME'):
            assert env.get(k) is None, k
        assert Path(env['CARGO_TARGET_DIR']).resolve() == target and env['CARGO_INCREMENTAL'] == '0'
    else:
        cmd = [checked(plan['installed_executable']).as_posix(),'--idd',checked(plan['explicit_IDD']).as_posix(),'--weather',checked(case['weather']).as_posix(),'--output-directory',out.as_posix(),'--output-prefix','energyplus',checked(case['input']).as_posix()]
    print(f'Root-only {a.engine} {a.case}: actual mode input, full duration, no comparison or gate update', flush=True)
    rc = subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',receipt.relative_to(R).as_posix(),'--',*cmd],cwd=R,env=env)
    pins_after = [ref(checked(v)) for v in plan['installed_runtime_pins']]
    assert pins_before == pins_after
    full_code(plan)
    for k in ('input','metadata','weather'):
        checked(case[k])
    rr = ref(receipt/'receipt.json')
    run = json.loads(checked(rr).read_bytes())
    assert run['exit_code'] == rc and run['launch_error'] is None and run['source_bytes_match_before_and_after']
    result = dict(schema='src06-limit-duration-actual-command-custody.v1',engine=a.engine,case=a.case,input_plan=pr,launcher_Source=ref(Path(__file__)),command_receipt=rr,exit_code=rc,Source43_application=plan['Source43_application'],complete_compiler_plan=plan['complete_compiler_plan'],full4517_inputs_equal_before_and_after=True,parent_same_mode_actual24_Source_receipt=source24,installed_runtime_before=pins_before,installed_runtime_after=pins_after,installed_runtime_bytes_exact_before_and_after=True,case_input=case['input'],case_metadata=case['metadata'],weather=case['weather'],explicit_IDD=plan['explicit_IDD'],expected_zone_steps_excluding_warmup=case['expected_zone_steps_excluding_warmup'],comparison_executed=False,module_loading_claim=False,qualification='Only this real recorded command establishes its engine outcome. Current installed runtime59 file pins are custody, not a loaded-module trace or fabricated historical API-baseline hashes. Source receives only its own actual input/IDD/weather, never Native outputs. Fresh artifacts, successful620 and strict reported-value comparison require separate actual checks.')
    custody.mkdir()
    p = custody/'custody.json'
    p.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(ref(p)))
    return rc

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--plan',required=True)
    p.add_argument('--engine',choices=['Source','Native'],required=True)
    p.add_argument('--case',choices=[f'B-{m}-{d}' for m in ('FLOW','CAPACITY','BOTH') for d in ('72H','ANNUAL')],required=True)
    p.add_argument('--run-label',required=True)
    p.add_argument('--execute',action='store_true')
    raise SystemExit(main(p.parse_args()))

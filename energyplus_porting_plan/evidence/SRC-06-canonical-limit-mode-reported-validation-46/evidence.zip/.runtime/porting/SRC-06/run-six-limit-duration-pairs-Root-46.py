from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def spec(p):
 v=ref(p);return v['path']+'#'+v['sha256']
def load(p):return json.loads(p.read_bytes())
def run(args):
 p=subprocess.run([sys.executable,*args],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf8',errors='strict')
 if p.returncode:
  print(p.stdout[-10000:],flush=True);raise SystemExit(p.returncode)
def actual(p):
 r=load(p);assert r['exit_code']==0 and r['launch_error']is None and r['source_bytes_match_before_and_after'];assert r['source_snapshot']==plan['actual_Source43_compiler_snapshot'];return r
planp=D/'limit-duration-launch-READY-Outer-after43/plan.json';assert ref(planp)['sha256']=='6e5789c75393cccb003ae6e204135a68c57e4cd4309d1dd9835091994419510c';plan=load(planp)
launcher=D/'launch-source-native-limit-durations-Outer-after43.py';comparer=D/'compare-completed-limit-cases-Outer-after43.py'
assert ref(launcher)['sha256']=='97cf234a299e28d679d0326542cec3823b7fefd08344038263080be5b5ca8e11'
assert ref(comparer)['sha256']=='91b1abfb84b559584851de2b602f3bd46bd5214630283335544fbf82db6f7e64'
assert plan['base_HEAD']=='9d7f3b884f1ccf4073928ef222b824f645dcf9f3'
env=dict(os.environ);env['PATH']='C:/msys64/mingw64/bin;C:/Users/GonieGonie/.cargo/bin;'+env['PATH']
cases=[f'B-{m}-{d}'for m in('FLOW','CAPACITY','BOTH')for d in('72H','ANNUAL')];done=[]
for case in cases:
 meta=next(v for v in plan['cases']if v['case']==case)
 refs={}
 for engine,side in[('Source','source'),('Native','native-installed')]:
  rp=D/f'{side}-limit-duration-{case}-command-Root-46/receipt.json';assert not rp.parent.exists()
  print(f'{case}: starting {engine} full case',flush=True)
  run([str(launcher),'--plan',spec(planp),'--engine',engine,'--case',case,'--run-label','Root-46','--execute'])
  r=actual(rp);refs[engine]=ref(rp)
  if engine=='Source':
   s=load(D/f'{side}-limit-duration-{case}-Root-46/output/run-summary.json');rt=s['rust_runtime'];assert s['status']=='success'and s['exit_code']==0 and rt['execution']=='actual Source ManageSimulation successful through620'and rt['native_environment_hour_scope']==meta['full_case_hours']
   core=[]
   for line in(R/r['stdout']['path']).read_bytes().splitlines():
    try:v=json.loads(line)
    except(ValueError,UnicodeDecodeError):continue
    if isinstance(v,dict)and v.get('reason')=='compiler-artifact'and v['target']['name']in('ep_runtime','ep_run','eplus-rs'):core.append(v)
   assert len(core)==3 and all(v['fresh']and not v['features']for v in core)
  print(f'{case}: {engine} actual0, stable4517 inputs; '+refs[engine]['sha256'],flush=True)
 cp=D/f'completed-{case}-reported-Root-46';assert not cp.exists()
 custody=D/f'native-installed-limit-duration-{case}-custody-Root-46/custody.json'
 run([str(comparer),'--plan',spec(planp),'--case',case,'--source-receipt',spec(R/refs['Source']['path']),'--native-authority',spec(R/refs['Native']['path']),'--native-custody',spec(custody),'--output',str(cp),'--execute'])
 p=cp/'comparison.json';c=load(p);tot=c['totals'];assert c['accepted']and tot['passed']and tot['series']==102 and tot['samples']==meta['expected_zone_steps_excluding_warmup']*102 and tot['tolerance_failures']==tot['rmse_failures']==0
 done.append(dict(case=case,Source_receipt=refs['Source'],Native_receipt=refs['Native'],comparison=ref(p),metrics=tot))
 print(case+': strict comparison '+json.dumps(tot),flush=True)
O=D/'Root-six-limit-duration-pairs-driver-46';assert not O.exists();O.mkdir();p=O/'receipt.json';p.write_bytes((json.dumps(dict(accepted=True,findings=[],author_Source=ref(Path(__file__)),plan=ref(planp),cases=done,Source_commands=6,Native_commands=6,test_bodies=0,no_policy_changes=True),indent=2)+'\n').encode('utf8'));print(json.dumps(ref(p)),flush=True)

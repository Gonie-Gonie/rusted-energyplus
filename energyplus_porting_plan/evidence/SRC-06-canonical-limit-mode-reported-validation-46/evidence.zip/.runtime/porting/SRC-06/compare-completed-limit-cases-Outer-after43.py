"""Root-only strict comparisons: explicit actual API24 or real CLI Native authority."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys
R = Path(__file__).resolve().parents[3]

def checked(v):
    p = (R / v['path']).resolve()
    assert p.is_relative_to(R)
    with p.open('rb') as f:
        h = hashlib.file_digest(f,'sha256').hexdigest()
    assert h == v['sha256'] and p.stat().st_size == v.get('bytes',p.stat().st_size)
    return p

def argument(v):
    p,h = v.rsplit('#',1)
    return dict(path=(R/p).resolve().relative_to(R).as_posix(),sha256=h)

def main(a):
    assert a.execute, 'Root explicit --execute required; comparison only, no engine'
    pr = argument(a.plan)
    plan = json.loads(checked(pr).read_bytes())
    me = plan['compare_adapter_Source']
    assert checked(me) == Path(__file__).resolve()
    case = next(c for c in plan['cases'] if c['case'] == a.case)
    for k in ('input','metadata','weather'):
        checked(case[k])
    checked(plan['unchanged_output_policy'])
    sr = argument(a.source_receipt)
    source = json.loads(checked(sr).read_bytes())
    assert source['schema'] == 'recorded-porting-command.v1' and source['exit_code'] == 0 and source['launch_error'] is None and source['source_bytes_match_before_and_after']
    assert source['source_snapshot'] == plan['actual_Source43_compiler_snapshot']
    assert any(Path(v).resolve() == checked(case['input']) for v in source['command'] if v.lower().endswith('.idf'))
    if case['duration'] == '24H':
        assert a.native_authority is None and a.native_custody is None
        baseline = case['Native_baseline']
        assert baseline['kind'] == 'actual CON01 read-only API-observer engine summary, not recorded CLI receipt'
        nr = baseline['execution_summary']
        checked(nr)
        for k,v in baseline['physical_files'].items():
            if v is None:
                assert not (R/baseline['output_dir']/('eplusout.'+k)).exists()
            else:
                checked(v)
        tool = checked(plan['strict_API24_custody_adapter'])
    else:
        assert a.native_authority and a.native_custody
        nr = argument(a.native_authority)
        native = json.loads(checked(nr).read_bytes())
        assert native['schema'] == 'recorded-porting-command.v1' and native['exit_code'] == 0 and native['launch_error'] is None and native['source_bytes_match_before_and_after']
        assert any(Path(v).resolve() == checked(case['input']) for v in native['command'] if v.lower().endswith('.idf'))
        c = json.loads(checked(argument(a.native_custody)).read_bytes())
        assert c['schema'] == 'src06-limit-duration-actual-command-custody.v1' and c['engine'] == 'Native' and c['case'] == a.case and c['exit_code'] == 0
        assert c['command_receipt']['path'] == nr['path'] and c['command_receipt']['sha256'] == nr['sha256']
        assert c['installed_runtime_bytes_exact_before_and_after'] and c['installed_runtime_before'] == c['installed_runtime_after'] == plan['installed_runtime_pins']
        assert c['case_input'] == case['input'] and c['weather'] == case['weather'] and c['explicit_IDD'] == plan['explicit_IDD']
        tool = checked(plan['strict_public_Regular_reported_comparer'])
    return subprocess.call([sys.executable,str(tool),'--case',a.case,'--source-receipt',str(checked(sr)),'--source-receipt-sha256',sr['sha256'],'--native-receipt',str(checked(nr)),'--native-receipt-sha256',nr['sha256'],'--output',str((R/a.output).resolve())],cwd=R)

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--plan',required=True)
    p.add_argument('--case',choices=[f'B-{m}-{d}' for m in ('FLOW','CAPACITY','BOTH') for d in ('24H','72H','ANNUAL')],required=True)
    p.add_argument('--source-receipt',required=True)
    p.add_argument('--native-authority')
    p.add_argument('--native-custody')
    p.add_argument('--output',required=True)
    p.add_argument('--execute',action='store_true')
    raise SystemExit(main(p.parse_args()))

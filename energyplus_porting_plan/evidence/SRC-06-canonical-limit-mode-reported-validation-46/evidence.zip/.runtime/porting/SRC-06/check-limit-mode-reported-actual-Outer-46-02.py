"""Root-only nine-case existing-result aggregate; no engine, Cargo or huge exports."""
from pathlib import Path
import argparse, hashlib, json, subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
KNOWN={
 'B-FLOW-24H':('69d39a7afb0185640a1ba4cc7473bfb2eb0829d80867311cc24fb330f5fa9d0d','43fc7c851985b830d5cc20d7e652b772cf458e43b96fb8d54df103de557c75d1'),
 'B-CAPACITY-24H':('9da0259a8871f7bcb730fdbb8c5f7a158fa801eb69460850642b36a037450dd9','dfcec4ecca0901677214d9d96fd7b84617b615fd798a373100992d3aae29fc1a'),
 'B-BOTH-24H':('fd1fc80e435c905ef13da1e6a492389242760a02f518c685dfe5ec0548966d18','40cfb8fdfaa484b74370baa841bc812a19c33aac33762371401a7950fb7f8cfc')}

def ref(p):
    p=p.resolve()
    with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)
def checked(v):
    p=(R/v['path']).resolve();assert p.is_relative_to(R);q=ref(p)
    assert q['sha256']==v['sha256']and q['bytes']==v.get('bytes',q['bytes']),v
    return p
def load(v):return json.loads(checked(v).read_bytes())
def argument(s):
    p,h=s.rsplit('#',1);return ref(checked(dict(path=p,sha256=h)))
def option(c,k):assert c.count(k)==1;return c[c.index(k)+1]
def core(run,fresh=None):
    out={}
    for line in checked(run['stdout']).read_bytes().splitlines():
        try:v=json.loads(line)
        except(ValueError,UnicodeDecodeError):continue
        if not isinstance(v,dict)or v.get('reason')!='compiler-artifact'or v['target']['name']not in('ep_runtime','ep_run','eplus-rs'):continue
        name=v['target']['name'];assert name not in out
        if fresh is not None:assert v['fresh']is fresh
        v.pop('fresh');out[name]=v
    assert len(out)==3
    return out

def main(a):
    O=D/'Root-limit-mode-reported-actual-review-46';assert not O.exists()
    lp=argument(a.plan);plan=load(lp);assert plan['status']=='READY_ROOT_EXECUTION_ONLY'and plan['base_HEAD']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==plan['base_HEAD']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
    originalp=D/'limit-duration-launch-WAIT-Outer-after43/plan.json';original=load(dict(path=originalp.relative_to(R).as_posix(),sha256='53014634337bae51915d98d32fee3c1e5f7437d0fa6928a0ee540c36398b34c5'))
    assert plan['cases']==original['cases']and plan['complete_compiler_plan']==original['complete_compiler_plan']and plan['Source43_application']==original['Source43_application']
    code=load(plan['complete_compiler_plan']);assert(code['inputs'],code['Rust_sources'])==(4517,4504)
    rows={v['path']:v for v in code['entries']}
    inventory={p.relative_to(R).as_posix()for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix()for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'}
    assert inventory==rows.keys()
    for p,v in rows.items():
        b=checked(v['source']).read_bytes();q=ref(R/p)
        assert(hashlib.sha256(b).hexdigest(),len(b))==(v['final_sha256'],v['final_bytes'])==(q['sha256'],q['bytes'])
    snapshot=load(plan['actual_Source43_compiler_snapshot']);sr={v['historical_path']:v for v in snapshot['files']};assert sr.keys()==rows.keys()
    for p,v in sr.items():assert(v['archive']['sha256'],v['size_bytes'])==(rows[p]['final_sha256'],rows[p]['final_bytes']);checked(v['archive'])
    policy=checked(plan['unchanged_output_policy']);assert policy.read_bytes()==subprocess.check_output(['git','show','2fffe68fb9131c80efcd3232de3a81d5290045c6:energyplus_porting_plan/contracts/output-tolerances.json'],cwd=R)
    for v in plan['installed_runtime_pins']:checked(v)
    files={};cases=[]
    def add(v):
        p=checked(v);r=ref(p)
        assert p.suffix.lower()not in('.zip','.exe','.dll','.a')and r['bytes']<64*1024*1024
        if r['path']in files:assert files[r['path']]==r
        files[r['path']]=r
    for v in(lp,ref(originalp),plan['Source43_application'],plan['complete_compiler_plan'],plan['accepted_Source43_focused59'],plan['launch_Source'],plan['compare_adapter_Source'],plan['strict_public_Regular_reported_comparer'],original['strict_API24_custody_adapter'],original['strict_API24_adapter_proof'],plan['unchanged_output_policy']):add(v)
    for case in plan['cases']:
        name=case['case'];mode=case['limit_variant'];duration=case['duration'];hours=case['full_case_hours'];steps=case['expected_zone_steps_excluding_warmup']
        meta=load(case['metadata']);assert(meta['id'],meta['scope'],meta['duration'],meta['limit_variant'])==(name,'B',duration,mode)
        for k in('input','metadata','weather'):checked(case[k])
        if duration=='24H':
            cp=D/f'completed-{name}-reported-Root-43/comparison.json';assert ref(cp)['sha256']==KNOWN[name][0]
            sp=D/f'canonical-source-hard-sized-purchased-air-{name}-command-Root-43/receipt.json';assert ref(sp)['sha256']==KNOWN[name][1]
            nr=case['Native_baseline']['execution_summary'];native=load(nr);assert native['energyplus_exit_code']==0 and native['reference_checks_passed']and not native['errors']
            assert native['input']==meta['input']and native['weather']==meta['weather']
            for v in case['Native_baseline']['physical_files'].values():
                if v is not None:add(v)
            native_kind='historical actual read-only API-observer engine summary; not a recorded CLI receipt'
            native_custody=[]
        else:
            sp=D/f'source-limit-duration-{name}-command-{a.run_label}/receipt.json'
            np=D/f'native-installed-limit-duration-{name}-command-{a.run_label}/receipt.json';nr=ref(np);native=load(nr)
            assert native['schema']=='recorded-porting-command.v1'and native['exit_code']==0 and native['launch_error']is None and native['source_bytes_match_before_and_after']
            assert Path(native['command'][0]).resolve()==checked(plan['installed_executable'])and Path(option(native['command'],'--idd')).resolve()==checked(plan['explicit_IDD'])
            assert Path(option(native['command'],'--weather')).resolve()==checked(case['weather'])and option(native['command'],'--output-prefix')=='energyplus'
            assert any(Path(x).resolve()==checked(case['input'])for x in native['command']if x.lower().endswith('.idf'))
            cp=D/f'completed-{name}-reported-{a.run_label}/comparison.json';native_custody=[]
            for side,engine in(('source','Source'),('native-installed','Native')):
                cpath=D/f'{side}-limit-duration-{name}-custody-{a.run_label}/custody.json';cr=ref(cpath);c=load(cr)
                assert(c['schema'],c['engine'],c['case'],c['exit_code'])==('src06-limit-duration-actual-command-custody.v1',engine,name,0)
                rr=ref(sp)if side=='source'else nr;assert c['command_receipt']==rr and c['input_plan']==lp and c['launcher_Source']==plan['launch_Source']
                assert c['full4517_inputs_equal_before_and_after']and c['installed_runtime_bytes_exact_before_and_after']and c['installed_runtime_before']==c['installed_runtime_after']==plan['installed_runtime_pins']
                assert c['case_input']==case['input']and c['case_metadata']==case['metadata']and c['weather']==case['weather']and c['explicit_IDD']==plan['explicit_IDD']
                add(cr);native_custody.append(cr)
            native_kind='actual recorded installedNative CLI receipt0, explicit IDD, exact59 runtime file pins before/after'
            for k in('stdout','stderr','source_snapshot'):add(native[k])
        source=load(ref(sp));assert source['schema']=='recorded-porting-command.v1'and source['exit_code']==0 and source['launch_error']is None and source['source_bytes_match_before_and_after']
        assert source['source_snapshot']==plan['actual_Source43_compiler_snapshot']
        cmd=source['command'];assert cmd[:2]==['cargo','run']and option(cmd,'--porting-scope')=='B'and not{'--hours','--features','--oracle-baseline','--compare-oracle','test'}&set(cmd)
        assert Path(option(cmd,'--weather')).resolve()==checked(case['weather'])and any(Path(x).resolve()==checked(case['input'])for x in cmd if x.lower().endswith('.idf'))
        assert Path(source['launch_environment_selected']['CARGO_TARGET_DIR']).resolve()==(D/'ordinary-provider-assembly-Root-55/workspace/.runtime/cargo-test-fresh').resolve()
        if duration!='24H':
            parent=load(ref(D/f'canonical-source-hard-sized-purchased-air-B-{mode}-24H-command-Root-43/receipt.json'));assert core(source,True)==core(parent)
            assert "env['CARGO_INCREMENTAL'] = '0'"in checked(plan['launch_Source']).read_text(encoding='utf-8')
        comparison=load(ref(cp));totals=comparison['totals'];assert comparison['case']==name and comparison['accepted']and comparison['profile']=='B'and comparison['policy']==plan['unchanged_output_policy']and comparison['Source_receipt']==ref(sp)
        native_key='Native_authority'if duration=='24H'else'Native_receipt';assert comparison[native_key]==ref(checked(nr))
        assert comparison['author_Source']==(original['strict_API24_custody_adapter']if duration=='24H'else plan['strict_public_Regular_reported_comparer'])
        summaryp=Path(option(cmd,'--output-dir'))/'run-summary.json';summary=load(ref(summaryp));runtime=summary['rust_runtime']
        assert summary['exit_code']==0 and summary['status']=='success'and runtime['schema']=='rusted-energyplus.source-runtime.v1'and runtime['execution']=='actual Source ManageSimulation successful through620'
        assert runtime['native_environment_hour_scope']==hours and runtime['native_environment_scope']==comparison['selected_Source_environment_scope']and runtime['native_options']['DoWeathSim']is True
        assert not{'result_store_json','selected_outputs_csv','meters_csv'}&summary['artifacts'].keys()
        diagp=summaryp.with_name('diagnostics.json');diag=load(ref(diagp));assert not[v for v in diag['diagnostics']if v['severity']=='error']
        series=[v for stream in comparison['streams']for v in stream['series']]
        assert len(series)==totals['series']==meta['object_counts']['output:variable']==102
        assert all(v['frequency']=='TimeStep'and v['samples']==steps and v['passed']and v['rmse_limit_met']and v['tolerance_failures']==0 for v in series)
        assert totals['samples']==sum(v['samples']for v in series)==steps*102
        for key in('raw_operand_unequal','parsed_binary64_unequal'):assert totals[key]==sum(v[key]for v in series)
        assert totals['passed']and totals['tolerance_failures']==totals['rmse_failures']==0
        for stream in comparison['streams']:
            if stream.get('deleted_empty'):assert stream['stream']=='mtr'and stream['records']==0 and not stream['series'];continue
            for key in('Source','Native'):checked(stream[key])
        for v in comparison['type_authorities']:add(v)
        for v in(ref(sp),nr,ref(cp),ref(summaryp),ref(diagp),case['input'],case['metadata'],comparison['all_uncapped_tolerance_failures']):add(v)
        for k in('stdout','stderr','source_snapshot'):add(source[k])
        per_unit={}
        for v in series:
            u=v['units']
            if u not in per_unit or v['max_abs_delta']>per_unit[u]['max_abs_delta']:per_unit[u]={k:v[k]for k in('key','name','units','max_abs_delta','rmse_delta','policy')}
        cases.append(dict(case=name,Source_receipt=ref(sp),Native_authority=nr,Native_authority_kind=native_kind,comparison=ref(cp),Source_summary=ref(summaryp),case_input=case['input'],case_metadata=case['metadata'],weather=case['weather'],duration_hours=hours,metrics=totals,maximum_absolute_deltas_by_actual_unit=per_unit,actual_duration_custodies=native_custody,Source620_completed=True,Native_completed=True,strict_full_reported_comparison_pass=True,own_JSON_CSV_verified=False,ancillary_IO_verified=False))
    assert len(cases)==9
    totals=dict(case_series=sum(c['metrics']['series']for c in cases),reported_scalar_samples=sum(c['metrics']['samples']for c in cases),raw_operand_unequal=sum(c['metrics']['raw_operand_unequal']for c in cases),parsed_binary64_unequal=sum(c['metrics']['parsed_binary64_unequal']for c in cases),tolerance_failures=0,rmse_failures=0,all_nine_strict_comparisons_pass=True)
    assert(totals['case_series'],totals['reported_scalar_samples'])==(918,10839744)
    result=dict(schema='src06-nine-limit-mode-reported-actual-validation46.v1',accepted=True,findings=[],base_HEAD=plan['base_HEAD'],author_Source=ref(Path(__file__)),launch_input_plan=lp,initial_WAIT_input_plan=ref(originalp),Source43_application=plan['Source43_application'],complete_compiler_plan=plan['complete_compiler_plan'],actual_Source43_compiler_snapshot=plan['actual_Source43_compiler_snapshot'],all4517_current_and_recorded_Source_compiler_inputs_exact=True,Rust_sources=4504,duration_three_core_artifacts_fresh_true_equal_same_mode24=True,cases=cases,totals=totals,unchanged_original_policy=plan['unchanged_output_policy'],true_historical_API24_baselines_reused=3,fresh_duration_Source_commands=6,fresh_duration_Native_commands=6,no_NoLimit_or_Native24_rerun=True,own_export_scope=dict(verified_cases=[],unverified_cases=[c['case']for c in cases],qualification='No limit-mode JSON/CSV own-value readback is claimed. No large result JSON/CSV body was loaded or included.'),ancillary_IO_scope=dict(overall_IO_PASS=False,verified_cases=[],qualification='Ancillary transport, ERR/END/finalization and all other physical artifacts remain separate.'),separate_scope_qualifications=['Source43 one-body59-case Sizer scientific proof is separate and is not rerun or appropriated by this operational aggregate.','Earlier NoLimit45 and A regression remain separate; no aggregate full15 case or64-card completion/gate claim.','Raw/binary64 differences are preserved by per-case/per-unit metrics; no cross-unit global maximum or causality claim.'],publication_artifacts=list(files.values()),new_test_bodies=0,actual_test_bodies_executed=0,policy_changes=0,gate_changes=0,checker_Cargo_Source_Native_commands_executed=False,canonical_mutations=0)
    O.mkdir();p=O/'review.json';p.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));print(json.dumps(dict(review=ref(p),totals=totals)))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--run-label',default='Root-46');main(p.parse_args())

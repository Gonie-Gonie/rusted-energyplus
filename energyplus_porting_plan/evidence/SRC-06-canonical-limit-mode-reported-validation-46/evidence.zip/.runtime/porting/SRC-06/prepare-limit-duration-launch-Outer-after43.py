"""Private WAIT/READY preparation; no Cargo, tests, comparisons or engine calls."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, re, subprocess
R=Path(__file__).resolve().parents[3]
D=R/'.runtime/porting/SRC-06'
H='728bceba565cd960077f161c93865c6a4730c99a'

def ref(p):
    p=p.resolve()
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=p.stat().st_size)

def checked(v):
    p=(R/v['path']).resolve();q=ref(p)
    assert p.is_relative_to(R) and q['sha256']==v['sha256'] and q['bytes']==v.get('bytes',q['bytes']),v
    return p

def main(a):
    O=D/('limit-duration-launch-READY-Outer-after43' if a.final_head else 'limit-duration-launch-WAIT-Outer-after43')
    assert not O.exists()
    appp=D/'Root-hard-sized-purchased-air-cohort-application-43/receipt.json'
    assert ref(appp)['sha256']=='3ce67870fba913b8698076eb11f010635e55ce4c23c7410fb37c0892c63d8dc5'
    app=json.loads(appp.read_bytes());assert app['accepted'] and not app['findings'] and app['base_HEAD']==H
    producer=json.loads(checked(app['producer']).read_bytes())
    planref=app['complete_compiler_plan'];assert planref['sha256']=='0e375beed2838380d857e424b6215c937d8a2b163945647e44a18eaf91280958'
    code=json.loads(checked(planref).read_bytes());assert (code['inputs'],code['Rust_sources'])==(4517,4504)
    for v in code['entries']:
        b=checked(v['source']).read_bytes();q=ref(R/v['path'])
        assert (hashlib.sha256(b).hexdigest(),len(b))==(v['final_sha256'],v['final_bytes'])
        assert (q['sha256'],q['bytes'])==(v['final_sha256'],v['final_bytes']),v['path']
    fp=D/'Root-source-hard-size-cohort-actual-review-43/review.json';f=json.loads(fp.read_bytes())
    assert f['accepted'] and not f['findings'] and f['application']==ref(appp) and f['Source_cases_bit_exact']==59 and f['complete_compiler_plan']==planref
    priorp=D/'nolimit-duration-launch-prepared-Outer-after44/plan.json';prior=json.loads(priorp.read_bytes())
    for v in prior['installed_runtime_pins']:checked(v)
    tool=R/'tools/porting/check_completed_reported_streams.py'
    assert ref(tool)['sha256']=='dfd48ccfbbe1d88b4d70bbf4634eb3963679659442e2d8cacf929abb02f7186e'
    public=tool.read_bytes().decode()
    # Only historical API custody/path handling and report labels differ. All
    # numerical, identity, clock, physical-line and tolerance functions stay exact.
    api_branch='''    if not source and r.get("schema_version") == "con01-reference-summary.v1":
        require(r["case_id"] == case["id"], "API Native case differs")
        require(r["energyplus_exit_code"] == 0 and r["reference_checks_passed"] is True and not r["errors"], "API Native execution failed")
        require(r["energyplus_commit"] == "6f2e40d10250a105b49966baa24d843711e61048", "API Native pin differs")
        require(r["reference_kind"] == "read-only EnergyPlus API observer trace", "not genuine API observer authority")
        require(r["observer_policy"] == "variable requests/getters and callbacks; no actuators, HVAC override or physical-state setters", "API observer policy differs")
        require(r["input"] == case["input"] and r["weather"] == case["weather"], "API input/weather authority differs")
        project_ref(r["input"]); project_ref(r["weather"])
        command = r["run_command"]
        require(command[0] == "EnergyPlusAPI.runtime.run_energyplus", "not actual API engine command")
        require(normalized_path(option(command, "-w")) == normalized_path(project_ref(case["weather"])), "API weather differs")
        require(normalized_path(project_ref(case["input"])) in [normalized_path(x) for x in command], "API actual input differs")
        output = Path(option(command, "-d")).resolve()
        require(output == (ROOT / ".runtime/porting/CON-01/reference" / case["id"]).resolve(), "API retained output path differs")
        return r, output
'''
    anchor='    require(r["schema"] == "recorded-porting-command.v1", "unrecognized receipt")\n'
    assert public.count(anchor)==1
    assert (O/'strict-API24-comparer.py').resolve().parents[4] == R
    private=public.replace('ROOT = Path(__file__).resolve().parents[2]','ROOT = Path(__file__).resolve().parents[4]',1).replace(anchor,api_branch+anchor,1)
    old='    source_rdd_path, native_rdd_path = source_dir / "eplusrs.rdd", native_dir / "energyplusout.rdd"\n    source_mdd_path, native_mdd_path = source_dir / "eplusrs.mdd", native_dir / "energyplusout.mdd"'
    new='    native_prefix = "eplus" if native_receipt.get("schema_version") == "con01-reference-summary.v1" else "energyplus"\n    source_rdd_path, native_rdd_path = source_dir / "eplusrs.rdd", native_dir / (native_prefix + "out.rdd")\n    source_mdd_path, native_mdd_path = source_dir / "eplusrs.mdd", native_dir / (native_prefix + "out.mdd")'
    assert private.count(old)==1;private=private.replace(old,new,1)
    old='native_dir / f"energyplusout.{kind}"';new='native_dir / f"{native_prefix}out.{kind}"'
    assert private.count(old)==1;private=private.replace(old,new,1)
    old='"Source_receipt": ref(args.source_receipt), "Native_receipt": ref(args.native_receipt),'
    new='"Source_receipt": ref(args.source_receipt), "Native_authority": ref(args.native_receipt),\n              "Native_authority_kind": "actual CON01 API-observer engine summary (not CLI receipt)" if native_prefix == "eplus" else "actual recorded installedNative CLI receipt",'
    assert private.count(old)==1;private=private.replace(old,new,1)
    pa,pb=ast.parse(public),ast.parse(private)
    fa={n.name:ast.dump(n,include_attributes=False)for n in pa.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    fb={n.name:ast.dump(n,include_attributes=False)for n in pb.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    assert fa.keys()==fb.keys() and {k for k in fa if fa[k]!=fb[k]}=={'receipt','main'}
    for k in ('completed_stream','PhysicalLines','paired','available_variables'):
        x=next(n for n in pa.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==k)
        y=next(n for n in pb.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==k)
        assert ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False)
    # Existing finite input parser is read as source only; no preparation main is run.
    prep=R/'tools/porting/prepare_con01.py';tree=ast.parse(prep.read_bytes())
    ns={'re':re};functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('parse_idf','only')]
    exec(compile(ast.Module(body=functions,type_ignores=[]),'<existing-finite-IDF-reader-only>','exec'),ns)
    matrixp=R/'energyplus_porting_plan/evidence/CON-01/execution-matrix.json';matrix=json.loads(matrixp.read_bytes())
    cases=[]
    for mode,limit in [('FLOW','LimitFlowRate'),('CAPACITY','LimitCapacity'),('BOTH','LimitFlowRateAndCapacity')]:
        for duration,hours,steps in [('24H',24,96),('72H',72,288),('ANNUAL',8760,35040)]:
            case=f'B-{mode}-{duration}';mp=R/'energyplus_porting_plan/cases'/case/'metadata.json';meta=json.loads(mp.read_bytes())
            ip=checked(meta['input']);wp=checked(meta['weather'])
            assert (meta['id'],meta['scope'],meta['duration'],meta['limit_variant'])==(case,'B',duration,mode)
            assert meta['expected_zone_steps_excluding_warmup']==steps and meta['expected_settings']['timesteps_per_hour']==4
            for p in (mp,ip):assert subprocess.check_output(['git','show',H+':'+p.relative_to(R).as_posix()],cwd=R)==p.read_bytes()
            objects=ns['parse_idf'](ip.read_bytes());ideal=ns['only'](objects,'ZoneHVAC:IdealLoadsAirSystem')
            assert ideal[10]==ideal[13]==limit and meta['expected_settings']['ideal_loads'][0]['heating_limit']==meta['expected_settings']['ideal_loads'][0]['cooling_limit']==limit
            mr=next(v for v in matrix['cases']if v['case_id']==case)
            if duration=='24H':
                assert mr['reference_status']=='checks_passed' and mr['summary']
                sp=checked(mr['summary']);s=json.loads(sp.read_bytes());out=R/'.runtime/porting/CON-01/reference'/case
                assert s['energyplus_exit_code']==0 and s['reference_checks_passed'] and not s['errors'] and s['case_id']==case
                assert s['input']==meta['input'] and s['weather']==meta['weather'] and s['zone_steps_excluding_warmup']==steps
                assert s['energyplus_commit']=='6f2e40d10250a105b49966baa24d843711e61048'
                assert Path(s['run_command'][s['run_command'].index('-d')+1]).resolve()==out.resolve()
                physical={ext:ref(out/('eplusout.'+ext)) if (out/('eplusout.'+ext)).exists() else None for ext in ('eso','mtr','rdd','mdd','end','err')}
                assert all(physical[k] is not None for k in ('eso','rdd','mdd','end','err')) and physical['mtr'] is None
                baseline=dict(status='GENUINE_RETAINED_API_ENGINE0_REQUIRES_NEW_STRICT_COMPARISON',kind='actual CON01 read-only API-observer engine summary, not recorded CLI receipt',execution_summary=mr['summary'],output_dir=out.relative_to(R).as_posix(),physical_files=physical,physical_output_prefix='eplusout',historical_qualification='Real historical API engine0/input/weather/version/API-library hashes and retained output path; current physical files are frozen now. No unrecorded historical IDD/INI hash, recorded CLI receipt or numerical Source comparison is fabricated. Original evidence gate_status remains unreviewed.')
            else:
                assert mr['reference_status']=='not_run' and mr['summary'] is None
                baseline=dict(status='MISSING_REQUIRES_GENUINE_FRESH_ENGINE',original_CON01_row=mr,qualification='No retained genuine exact-mode duration engine output/receipt found in bounded CON01/SRC06 registry. Fresh installedNative is required, never NoLimit/A/24 substitution.')
            cases.append(dict(case=case,duration=duration,scope='B',limit_variant=mode,full_case_hours=hours,expected_zone_steps_excluding_warmup=steps,input=ref(ip),metadata=ref(mp),weather=ref(wp),run_periods=meta['expected_settings']['run_periods'],zone_timesteps_per_hour=4,expected_weather_environments=meta['expected_weather_environments'],actual_IDF_limits=dict(heating_limit_field10=ideal[10],cooling_limit_field13=ideal[13],max_heating_flow_field11=ideal[11],max_sensible_heating_capacity_field12=ideal[12],max_cooling_flow_field14=ideal[14],max_total_cooling_capacity_field15=ideal[15]),Native_baseline=baseline))
    bridge=None
    if a.final_head:
        assert re.fullmatch('[0-9a-f]{40}',a.final_head) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a.final_head
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
        subprocess.check_call(['git','merge-base','--is-ancestor',H,a.final_head],cwd=R)
        changed=subprocess.check_output(['git','diff','--name-only',H,a.final_head],cwd=R,text=True).splitlines()
        selected={v['canonical_path'] for v in producer['files']}
        # Actual publication doc names/prefix are explicitly frozen below before READY.
        allowed=set(selected)|set(a.allowed_noncompiler)
        assert set(changed)<=allowed and selected<=set(changed),(changed,sorted(set(changed)-allowed))
        for p in a.allowed_noncompiler:assert not p.startswith(('crates/','.cargo/')) and p not in {'Cargo.toml','Cargo.lock','rust-toolchain.toml'}
        bridge=dict(application_base_HEAD=H,actual_clean43_HEAD=a.final_head,exact_changed_paths=changed,allowed_noncompiler_paths=a.allowed_noncompiler,all4517_compiler_wholes_remain_exact=True,qualification='Root supplies exact published43 noncompiler paths for this strict finite ancestry bridge. No blanket waiver or Source-byte normalization.')
    else:
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H
    launch=D/'launch-source-native-limit-durations-Outer-after43.py';compare=D/'compare-completed-limit-cases-Outer-after43.py'
    for p in (launch,compare):ast.parse(p.read_bytes())
    O.mkdir()
    def save(name,b):
        p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return ref(p)
    api=save('strict-API24-comparer.py',private.encode('utf-8'))
    forward=''.join(difflib.unified_diff(public.splitlines(keepends=True),private.splitlines(keepends=True),fromfile='canonical-public-Regular',tofile='private-explicit-API24-custody'))
    inverse=''.join(difflib.unified_diff(private.splitlines(keepends=True),public.splitlines(keepends=True),fromfile='private-explicit-API24-custody',tofile='canonical-public-Regular'))
    proof=dict(public_whole=ref(tool),private_API24_whole=api,public_before=save('comparer-public-before.py',public.encode('utf-8')),forward_diff=save('comparer-forward.diff',forward.encode('utf-8')),inverse_diff=save('comparer-inverse.diff',inverse.encode('utf-8')),function_AST_changes_only=['receipt','main'],all_other_functions_AST_whole_equal=True,completed_stream_PhysicalLines_paired_available_variables_AST_whole_equal=True,only_main_changes='Private ROOT path; actual API summary custody branch; genuine eplusout vs energyplusout prefix path; truthful Native_authority/kind output label. All ordered dictionary/clock/footer/numeric/atol/RMSE acceptance code retained.',fake_CLI_receipt_created=False,production_Native_answers_or_injection=False)
    proofref=save('strict-API24-adapter-proof.json',(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    result=dict(schema='src06-limit-mode-duration-Root-only-launch-comparison-plan.v1',status='READY_ROOT_EXECUTION_ONLY' if a.final_head else 'WAIT_ACTUAL43_COMMIT_NO_ENGINE_AUTHORIZED_BY_PREPARATION',base_HEAD=a.final_head,application_base_HEAD=H,actual43_commit_bridge=bridge,author_Source=ref(Path(__file__)),Source43_application=ref(appp),complete_compiler_plan=planref,accepted_Source43_focused59=ref(fp),actual_Source43_compiler_snapshot=f['actual_snapshot'],all4517_archive_and_live_inputs_exact=True,Rust_sources=4504,launch_Source=ref(launch),compare_adapter_Source=ref(compare),cases=cases,existing_Native24_count=3,missing_Native_duration_count=6,original_CON01_matrix=ref(matrixp),calendar_contract=prior['calendar_contract'],finite_IDF_reader_Source=ref(prep),prior_installed_runtime_custody_plan=ref(priorp),installed_runtime_pins=prior['installed_runtime_pins'],installed_executable=prior['installed_executable'],explicit_IDD=prior['explicit_IDD'],installed_schema=prior['installed_schema'],installed_runtime_DLL_scope=prior['installed_runtime_DLL_scope'],historical_Native_binary_qualification=prior['historical_Native_binary_qualification'],strict_public_Regular_reported_comparer=ref(tool),strict_API24_custody_adapter=api,strict_API24_adapter_proof=proofref,unchanged_output_policy=prior['unchanged_output_policy'],Source24_receipt_recipe='Exact same-mode canonical-source-hard-sized-purchased-air-B-{MODE}-24H-command-Root-43/receipt.json0 must exist before Source72/annual; same compiled snapshot, normal features, canonical target, incremental0. No new NoLimit run.',comparison_scope='All nine exact-mode outputs: three retained true Native API24 authorities via explicit private custody adapter, six future real installedNative command receipts via unchanged canonical public Regular comparer. Complete physical ordered IDs/dictionaries/raw clocks/full scalars/footers and original per-row atol/sequential RMSE in bounded memory; no expected values or Native outputs are passed to production.',own_export_qualification='JSON/CSV result values and all ancillary streams are unverified by this launcher/comparer; no annual JSON-tree loads.',no_commands_executed_by_preparation=True,new_test_bodies=0,Cargo_or_engine_calls=0,policy_or_gate_changes=False)
    p=O/'plan.json';p.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(dict(plan=ref(p),launcher=ref(launch),compare=ref(compare),API24_adapter=api,proof=proofref,cases=9,missing_Native_runs=6,prepared_only=True)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--final-head');p.add_argument('--allowed-noncompiler',action='append',default=[]);main(p.parse_args())

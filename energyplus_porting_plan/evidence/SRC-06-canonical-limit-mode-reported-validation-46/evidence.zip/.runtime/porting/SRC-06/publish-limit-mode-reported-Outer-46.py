"""Root-only nine-limit reported-value evidence publication; no engine or code edit."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
PUBLIC=R/'energyplus_porting_plan/evidence/SRC-06-canonical-limit-mode-reported-validation-46'
BACK=D/'limit-mode-reported-publication-readback-Outer-46'
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
    p=(R/v['path']).resolve();assert p.is_relative_to(R);q=ref(p)
    assert q['sha256']==v['sha256']and q['bytes']==v.get('bytes',q['bytes']);return p
def load(v):return json.loads(checked(v).read_bytes())
def write(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def main(a):
    assert a.publish and not PUBLIC.exists()and not BACK.exists()
    tr=dict(path=a.template,sha256=a.template_sha);t=load(tr);assert t['status']=='READY_ROOT_ACTUAL_NINE_CASE_AGGREGATE_ACCEPTED'
    assert t['publisher_Source']==ref(Path(__file__))
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==t['base_HEAD']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
    ar=dict(path=t['expected_actual_review_path'],sha256=a.actual_sha);actual=load(ar);ar=ref(checked(ar))
    assert actual['accepted']and not actual['findings']and ar==t['accepted_actual_review']and actual['author_Source']==t['actual_checker_Source']and actual['base_HEAD']==t['base_HEAD']
    assert actual['all4517_current_and_recorded_Source_compiler_inputs_exact']and actual['Rust_sources']==4504 and actual['duration_three_core_artifacts_fresh_true_equal_same_mode24']
    assert actual['totals']['all_nine_strict_comparisons_pass']and actual['totals']['tolerance_failures']==actual['totals']['rmse_failures']==0
    expected={f'B-{m}-{d}'for m in('FLOW','CAPACITY','BOTH')for d in('24H','72H','ANNUAL')}
    assert {c['case']for c in actual['cases']}==expected and len(actual['cases'])==9
    assert actual['own_export_scope']['verified_cases']==[]and set(actual['own_export_scope']['unverified_cases'])==expected and actual['ancillary_IO_scope']['overall_IO_PASS']is False
    assert actual['new_test_bodies']==actual['actual_test_bodies_executed']==actual['policy_changes']==actual['gate_changes']==0
    for c in actual['cases']:assert c['Source620_completed']and c['Native_completed']and c['strict_full_reported_comparison_pass']and not c['own_JSON_CSV_verified']and not c['ancillary_IO_verified']
    compiler=load(actual['complete_compiler_plan']);assert(compiler['inputs'],compiler['Rust_sources'])==(4517,4504)
    for v in compiler['entries']:
        b=(R/v['path']).read_bytes();assert(hashlib.sha256(b).hexdigest(),len(b))==(v['final_sha256'],v['final_bytes'])
    base=R/'energyplus_porting_plan';docs={n:(base/n).read_bytes()for n in('CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md')}
    pp=base/'plan.json';before=pp.read_bytes();old=json.loads(before)
    for n,b in docs.items():assert b==subprocess.check_output(['git','show',t['base_HEAD']+':energyplus_porting_plan/'+n],cwd=R)
    assert before==subprocess.check_output(['git','show',t['base_HEAD']+':energyplus_porting_plan/plan.json'],cwd=R)
    files={}
    def add(v):
        p=checked(v);r=ref(p)
        assert p.suffix.lower()not in('.zip','.exe','.dll','.a')and r['bytes']<64*1024*1024
        assert p.name not in('source-reported-results.json','source-eso.csv','source-mtr.csv')
        assert not('ANNUAL'in r['path']and p.suffix.lower()in('.eso','.mtr','.csv'))
        if r['path']in files:assert files[r['path']][1]==r
        files[r['path']]=(p,r)
    for v in t['finite_archive_inputs']+actual['publication_artifacts']+[ar,actual['author_Source'],ref(Path(__file__)),ref(checked(tr))]:add(v)
    PUBLIC.mkdir(parents=True);BACK.mkdir();(BACK/'plan-before.json').write_bytes(before)
    for n,b in docs.items():q=BACK/'docs-before'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    archive=PUBLIC/'evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for n,(p,r)in sorted(files.items()):assert ref(p)==r;z.write(p,arcname=n)
    with zipfile.ZipFile(archive)as z:
        assert z.testzip()is None and set(z.namelist())==set(files)
        for n,(_,r)in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==r['sha256']
    mp=PUBLIC/'manifest.json';write(mp,dict(schema='src06-nine-limit-mode-reported-finite-evidence46.v1',archive=ref(archive),entries=[r for _,(_,r)in sorted(files.items())],scope='Nine strict full-value comparison reports; genuine original API24 summaries and their small physical ESO/RDD/MDD/ERR/END, future actual Source/Native command/custody/log/snapshot metadata, source-scope/policy/adapter proof. No Source result JSON/CSV bodies, annual physical streams, runtime binaries, full Source archive trees or recursive ZIP bundles.'))
    summary=dict(t['summary_template']);summary.update(schema='src06-canonical-limit-mode-reported-validation46.v1',status='Nine completed Source620/matching true Native limit-mode cases; unchanged-policy reported-value comparisons passed',Root_actual_aggregate=ar,base_HEAD=t['base_HEAD'],complete_compiler_plan=actual['complete_compiler_plan'],cases=actual['cases'],totals=actual['totals'],own_export_scope=actual['own_export_scope'],ancillary_IO_scope=actual['ancillary_IO_scope'],separate_scope_qualifications=actual['separate_scope_qualifications'],true_historical_API24_baselines_reused=3,fresh_duration_Source_commands=6,fresh_duration_Native_commands=6,archive=ref(archive),archive_manifest=ref(mp),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
    sp=PUBLIC/'summary.json';write(sp,summary);relative='evidence/SRC-06-canonical-limit-mode-reported-validation-46/summary.json'
    for n,b in docs.items():
        link='../'+relative if n.startswith('cards/')else relative
        append='\n\n[Source46 limit-mode reported validation]('+link+'). '+t['doc_appends'][n]+'\n'
        assert '\ufffd'not in append and(base/n).read_bytes()==b
        (base/n).write_bytes(b+append.encode('utf-8'))
    new=json.loads(before);task=next(v for v in new['tasks']if v['id']=='SRC-06');key='canonical_limit_mode_reported_validation_46';assert key not in task
    task[key]=dict(path=sp.relative_to(R).as_posix(),sha256=ref(sp)['sha256'],size_bytes=sp.stat().st_size)
    inv=json.loads(json.dumps(new));del next(v for v in inv['tasks']if v['id']=='SRC-06')[key];assert inv==old;write(pp,new)
    result=dict(status='PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK',summary=ref(sp),archive=ref(archive),archive_manifest=ref(mp),archive_entries=len(files),base_HEAD=t['base_HEAD'],publisher_Source=ref(Path(__file__)),plan_before=ref(BACK/'plan-before.json'),production_compiler_inputs_changed=0,public_validation_tool_changed=False,new_tests=0,Cargo_Native_Source_commands_executed_by_publisher=False,gate_changes=False,Git_mutated=False)
    q=BACK/'publication-readback.json';write(q,result);print(json.dumps(ref(q)))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--template',required=True);p.add_argument('--template-sha',required=True);p.add_argument('--actual-sha',required=True);p.add_argument('--publish',action='store_true');main(p.parse_args())

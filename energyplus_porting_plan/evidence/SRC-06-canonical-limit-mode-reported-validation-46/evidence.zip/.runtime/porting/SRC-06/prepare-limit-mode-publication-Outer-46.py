"""Private nine-limit WAIT/READY publication metadata; never invokes publisher."""
from pathlib import Path
import argparse,ast,hashlib,json,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06'
KNOWN={
 'B-FLOW-24H':'69d39a7afb0185640a1ba4cc7473bfb2eb0829d80867311cc24fb330f5fa9d0d',
 'B-CAPACITY-24H':'9da0259a8871f7bcb730fdbb8c5f7a158fa801eb69460850642b36a037450dd9',
 'B-BOTH-24H':'fd1fc80e435c905ef13da1e6a492389242760a02f518c685dfe5ec0548966d18'}
def ref(p):
    b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
    p=(R/v['path']).resolve();assert p.is_relative_to(R);q=ref(p)
    assert q['sha256']==v['sha256']and q['bytes']==v.get('bytes',q['bytes']);return p
def main(a):
    O=D/('limit-mode-publication-READY-Outer-46'if a.actual else'limit-mode-publication-WAIT-Outer-46');assert not O.exists()
    lp=D/'limit-duration-launch-WAIT-Outer-after43/plan.json';assert ref(lp)['sha256']=='53014634337bae51915d98d32fee3c1e5f7437d0fa6928a0ee540c36398b34c5'
    launch=json.loads(lp.read_bytes());files={}
    def add(v):
        p=checked(v);q=ref(p);assert p.suffix.lower()not in('.zip','.exe','.dll','.a')and q['bytes']<64*1024*1024
        if q['path']in files:assert files[q['path']]==q
        files[q['path']]=q
    for v in(ref(lp),launch['Source43_application'],launch['complete_compiler_plan'],launch['accepted_Source43_focused59'],launch['launch_Source'],launch['compare_adapter_Source'],launch['strict_public_Regular_reported_comparer'],launch['strict_API24_custody_adapter'],launch['strict_API24_adapter_proof'],launch['unchanged_output_policy'],launch['author_Source'],launch['calendar_contract']):add(v)
    proof=json.loads(checked(launch['strict_API24_adapter_proof']).read_bytes())
    for k in('public_before','forward_diff','inverse_diff'):add(proof[k])
    known=[];future=[]
    for case in launch['cases']:
        if case['duration']=='24H':
            cp=D/f"completed-{case['case']}-reported-Root-43/comparison.json";assert ref(cp)['sha256']==KNOWN[case['case']]
            c=json.loads(cp.read_bytes());assert c['accepted']and c['totals']['passed']and c['totals']['tolerance_failures']==c['totals']['rmse_failures']==0
            known.append(dict(case=case['case'],comparison=ref(cp),totals=c['totals'],Source_receipt=c['Source_receipt'],Native_authority=c['Native_authority']))
            for v in(ref(cp),c['Source_receipt'],c['Native_authority'],c['all_uncapped_tolerance_failures']):add(v)
        else:
            future.append(dict(case=case['case'],Source_receipt=None,Native_authority=None,comparison=None,status='NOT_YET_EXECUTED_OR_INFERRED_BY_THIS_PREPARATION'))
    checker=D/'check-limit-mode-reported-actual-Outer-46.py';publisher=D/'publish-limit-mode-reported-Outer-46.py'
    for p in(checker,publisher,Path(__file__)):ast.parse(p.read_bytes());add(ref(p))
    t=dict(schema='src06-nine-limit-mode-reported-publication-template46.v1',status='WAITING_SIX_ACTUAL_DURATION_PAIRS_AND_ROOT_AGGREGATE',base_HEAD=None,historical_application_base_HEAD=launch['application_base_HEAD'],publisher_Source=ref(publisher),actual_checker_Source=ref(checker),expected_actual_review_path='.runtime/porting/SRC-06/Root-limit-mode-reported-actual-review-46/review.json',known_actual24=known,future_duration_inputs_pending=future,finite_archive_inputs=list(files.values()),summary_template=dict(A='14/54',B='14/64',gate_changes=False,policy_changes=False,new_production_Sources=0,production_Source_changed=False,validation_tool_changed=False,new_test_bodies=0,actual_test_bodies_executed=0,Source43_4517_inputs_4504_Rust_preserved=True,reported_scope_cases=9,existing_true_Native_API24_baselines_reused=3,fresh_duration_Source_CLI_invocations=6,fresh_duration_Native_CLI_invocations=6,Source59_scientific_cohort_separate=True,NoLimit45_and_A_regression_separate=True,qualification='Only FLOW/CAPACITY/BOTH24/72/annual physical reported values. Actual decimal/binary64 differences remain preserved per real unit and are checked against original named atols and sequential RMSE. No cross-unit global maximum, causality, own JSON/CSV, ancillary IO, full15 or64-card completion claim. No Native24 or NoLimit engine is rerun for this validation; no numerical/tolerance/cache logic changes.'),doc_appends={
    'cards/SRC-06.md':'\uc720\ub7c9\u00b7\uc6a9\ub7c9\u00b7\ub3d9\uc2dc \uc81c\ud55c B\uc758 24\uc2dc\uac04\u00b772\uc2dc\uac04\u00b7\uc5f0\uac04 9\uac1c \ucf00\uc774\uc2a4\ub97c \uac01\uac01 \uac19\uc740 Native \uae30\uc900\uacfc \uc804\uccb4 \ube44\uad50\ud588\ub2e4. \uae30\uc874 \ud5c8\uc6a9\uc624\ucc28\uc640 RMSE \uc870\uac74\uc744 \ubaa8\ub450 \ud1b5\uacfc\ud588\uc73c\uba70 \uc6d0\uc2dc\uac12\u00b7\ube44\ud2b8 \ucc28\uc774\ub294 \ubcf4\uace0\uc11c\uc5d0 \ub0a8\uacbc\ub2e4.',
    'CHECKLIST.md':'\uae30\uc874 Native API 24\uc2dc\uac04 \uae30\uc900 3\uac74\uc744 \ucd9c\ucc98 \uadf8\ub300\ub85c \uc7ac\uc0ac\uc6a9\ud558\uace0, \ub204\ub77d\ub41c 72\uc2dc\uac04\u00b7\uc5f0\uac04 6\uac74\ub9cc \uc0c8\ub85c \uc2e4\ud589\ud588\ub2e4. \ub3d9\uc77c\ud55c Source43 \ube4c\ub4dc\ub97c \uc720\uc9c0\ud588\uc73c\uba70 \uc0c8 \ud14c\uc2a4\ud2b8\uc640 \uac8c\uc774\ud2b8 \ubcc0\uacbd\uc740 \uc5c6\ub2e4.',
    'STATE_CONTRACTS.md':'\uc774 \uac80\uc99d\uc740 \uc81c\ud55c \ubaa8\ub4dc 9\uac1c\uc758 \ubcf4\uace0\uac12\uc5d0 \ud55c\uc815\ud55c\ub2e4. \uc790\uccb4 JSON/CSV\uc640 \ubd80\uac00 IO\ub294 \ubbf8\uac80\uc99d\uc73c\ub85c \ub0a8\uae30\uba70, Source59 \uc218\uce58 \ucf54\ud638\ud2b8\u00b7\ubb34\uc81c\ud55c B\u00b7A \ud68c\uadc0 \uc99d\uac70\uc640 \uad6c\ubd84\ud55c\ub2e4. \uc5f0\uac04 \ub300\ud615 \uacb0\uacfc\uc640 \uc2e4\ud589 \ubc14\uc774\ub108\ub9ac\ub97c ZIP\uc5d0 \ub123\uc9c0 \uc54a\ub294\ub2e4.'})
    if a.actual:
        path,sha=a.actual.rsplit('#',1);ar=ref(checked(dict(path=path,sha256=sha)));actual=json.loads(checked(ar).read_bytes())
        assert actual['accepted']and not actual['findings']and actual['totals']['all_nine_strict_comparisons_pass']and actual['author_Source']==t['actual_checker_Source']
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==actual['base_HEAD']
        t['base_HEAD']=actual['base_HEAD'];t['accepted_actual_review']=ar;t['status']='READY_ROOT_ACTUAL_NINE_CASE_AGGREGATE_ACCEPTED'
        # Preserve the original WAIT's future descriptions as explicitly historical.
        t['future_duration_inputs_pending_at_WAIT']=t.pop('future_duration_inputs_pending')
    O.mkdir();p=O/'publication-template.json';p.write_bytes((json.dumps(t,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));print(json.dumps(dict(template=ref(p),publisher=t['publisher_Source'],checker=t['actual_checker_Source'],fixed_archive_inputs=len(files),published=False)))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--actual');main(p.parse_args())

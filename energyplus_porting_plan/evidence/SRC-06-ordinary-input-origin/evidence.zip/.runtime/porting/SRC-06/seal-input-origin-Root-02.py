"""Seal test-input-only successor, preserving prior failed run and production."""
from pathlib import Path
import difflib
import hashlib
import json
import re

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-input-origin-assembly-02'
assert not out.exists()
out.mkdir()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

parent_path = base / 'ordinary-input-origin-assembly-01/manifest.json'
parent = json.loads(parent_path.read_bytes())
assert ref(parent_path)['sha256'] == 'aea51862e954312555d4ca6446666c2cf54100406a31cd5a7c5deed25bcd428c'
fix_path = base / 'ordinary-input-origin-fixture-fix-01.json'
fix = json.loads(fix_path.read_bytes())
files = []
changed = []
for index, row in enumerate(parent['files']):
    path = row['canonical']['path']
    before = (root / row['before']['path']).read_bytes()
    old_after = (root / row['after']['path']).read_bytes()
    assert hashlib.sha256(old_after).hexdigest() == row['after']['sha256']
    after = (root / path).read_bytes()
    assert old_after.split(b'#[cfg(test)]', 1)[0] == after.split(b'#[cfg(test)]', 1)[0]
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after))
    after_path = out / f'{index:02}.after'; after_path.write_bytes(after)
    diff_path = out / f'{index:02}.diff'
    diff_path.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='HEAD/'+path,tofile=path)).encode())
    if old_after != after:
        expected = next(r for r in fix['changes'] if r['path'] == path)
        assert hashlib.sha256(old_after).hexdigest() == expected['before_sha256']
        assert hashlib.sha256(after).hexdigest() == expected['after_sha256']
        delta_path = out / f'{index:02}.parent.diff'
        delta_path.write_bytes(expected['complete_parent_diff'].encode())
        changed.append({'canonical_path':path,'complete_parent_diff':ref(delta_path)})
    files.append({'canonical':ref(root/path),'before':row['before'],'after':ref(after_path),'complete_diff':ref(diff_path),
                  'test_bodies_before':row['test_bodies_before'],'test_bodies_after':row['test_bodies_after']})
assert len(changed) == 2
manifest = {**parent, 'files':files, 'parent_assembly':ref(parent_path),
            'Root_authors':[*parent['Root_authors'],ref(base/'fix-input-origin-fixtures-Root-01.py'),ref(Path(__file__))],
            'fixture_only_successor':{'record':ref(fix_path),'changes':changed,'production_bytes_unchanged_from_01':True,
                'qualification':'BOM test now includes its IDF Version in converted JSON; admission test now includes its converted Zone in staged IDF. Prior failed RawModel test run is retained.'}}
(out/'manifest.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(ref(out/'manifest.json')))

"""Publish actual input-origin prerequisite and scoped, nonduplicated QA."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root=Path.cwd();base=root/'.runtime/porting/SRC-06'
out=root/'energyplus_porting_plan/evidence/SRC-06-ordinary-input-origin'
assert not out.exists()
def ref(path):
    d=path.read_bytes();return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(d).hexdigest(),'size_bytes':len(d)}
def load(path):return json.loads(path.read_bytes())
def write(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
assembly_path=base/'ordinary-input-origin-assembly-02/manifest.json'
assert ref(assembly_path)['sha256']=='107bb0525b154bcb0a3b421c09942e32fc22884754af6590a713c352c9f1ecc4'
assembly=load(assembly_path)
parent_path=base/'ordinary-input-origin-assembly-01/manifest.json'
review_path=base/'Native-ordinary-input-origin-review-02/review.json'
review=load(review_path);assert review['accepted'] is True
rows=[]
def collect(value):
    if isinstance(value,dict):
        if 'path'in value and 'sha256'in value:rows.append(value)
        else:
            for v in value.values():collect(v)
    elif isinstance(value,list):
        for v in value:collect(v)
for p in [assembly_path,parent_path,review_path]:collect(load(p))
archives={}
for r in rows:
    p=root/r['path']
    if p.exists() and ref(p)['sha256']==r['sha256']:archives.setdefault(r['sha256'],p)
artifacts={};historical=[]
def add(path):
    r=ref(path);assert r['size_bytes']<12*1024*1024;artifacts[r['path']]=r
def checked(row):
    p=root/row['path'];actual=ref(p)
    if actual['sha256']!=row['sha256']:
        assert row['path']in ['crates/ep_raw_model/src/idf_order.rs','crates/ep_run/src/ordinary_equipment_input.rs','crates/ep_run/src/ordinary_equipment_input/fields.rs']
        p=archives[row['sha256']];actual=ref(p)
        is_baseline=any(r['before']['sha256']==row['sha256']for r in assembly['files'])
        resolution={'historical_reference':row,'exact_archive':actual,'qualification':'Exact pre-integration baseline for the two consumed metadata proposals.'if is_baseline else 'Assembly01 bytes before two test input pairs were corrected; production unchanged.'}
        if resolution not in historical:historical.append(resolution)
    assert actual['sha256']==row['sha256'] and actual['size_bytes']==row.get('size_bytes',actual['size_bytes'])
    return p
for p in [assembly_path,parent_path,review_path]:add(p)
for r in rows:add(checked(r))
for r in assembly['files']:assert ref(root/r['canonical']['path'])==r['canonical']
qa=[];tests=[];current_source=None;old_source=None
commands=[
 ('fmt-02',['fmt','--all','--','--check'],True),
 ('raw-tests-02',['test','-p','ep_raw_model','--lib'],True),
 ('compiler-tests-01',['test','-p','ep_compiler','--lib','report_inputs'],True),
 ('admission-tests-01',['test','-p','ep_run','--lib','raw_equipment_admission'],True),
 ('quality-01',None,False),
 ('clippy-01',['clippy','--workspace','--all-targets','--','-D','warnings'],False),
 ('fmt-01',['fmt','--all','--','--check'],False),
]
for name,args,current in commands:
    p=base/f'ordinary-input-origin-{name}/receipt.json';v=load(p)
    argv=['C:/Users/GonieGonie/.cargo/bin/cargo.exe',*args]if args else ['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/quality/source-quality-gate.ps1']
    assert v['command']==argv and v['exit_code']==0 and v['launch_error']is None and v['source_bytes_match_before_and_after']is True
    if current:
        if current_source is None:current_source=v['source_snapshot']
        assert current_source==v['source_snapshot']
    else:
        if old_source is None:old_source=v['source_snapshot']
        assert old_source==v['source_snapshot']
    qa.append({'receipt':ref(p),'final_Source':current,'qualification':'Final assembly02'if current else 'Assembly01; assembly02 changes only two test input literals. All five production prefixes and other three complete files are byte-exact.'})
    add(p)
    for key in ['source_snapshot','stdout','stderr']:add(checked(v[key]))
    if 'tests-'in name:
        stdout=checked(v['stdout']).read_text(encoding='utf8')
        groups=[tuple(map(int,g))for g in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
        assert groups and sum(g[0]for g in groups)>0 and all(g[1]==g[2]==0 for g in groups)
        tests.append({'scope':name,'passed':sum(g[0]for g in groups),'failed':0,'ignored':0})
assert tests[0]['passed']==16 and tests[-1]['passed']==1 and current_source!=old_source
failure_path=base/'ordinary-input-origin-raw-tests-01/receipt.json';failure=load(failure_path)
assert failure['exit_code']==101 and failure['source_snapshot']==old_source and failure['source_bytes_match_before_and_after']is True
add(failure_path)
for key in ['source_snapshot','stdout','stderr']:add(checked(failure[key]))
add(Path(__file__))
out.mkdir();archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
    for n in sorted(artifacts):z.write(root/n,n)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and set(z.namelist())==set(artifacts)
    for n in z.namelist():assert hashlib.sha256(z.read(n)).hexdigest()==artifacts[n]['sha256']
write(out/'manifest.json',{'schema':'src06-input-origin-evidence.v1','Source_snapshot':current_source,'assembly':ref(assembly_path),'artifacts':list(artifacts.values()),'historical_references':historical,'archive':ref(archive),'archive_member_count':len(artifacts),'archive_scope':'Five active files, their two consumed metadata proposals, literal ranges, review and actual QA. The referenced full GetProjectData preparation remains HELD; transitive unused proposals are not an archive or activation claim.','gates_updated':False})
total=sum(r['passed']for r in tests)
write(out/'summary.json',{'schema':'src06-input-origin-summary.v1','status':'Actual loader input format and IDF project field metadata retained; full GetProjectData/startup not activated','Source_snapshot':current_source,'prior_QA_Source_snapshot':old_source,'QA':qa,'tests':{'selections':tests,'passed':total,'failed':0,'ignored':0,'new_bodies':0,'new_binaries':0},'behavior':assembly['behavior'],'independent_Source_review':ref(review_path),'historical_failed_QA':{'receipt':ref(failure_path),'exit_code':101,'passed':15,'failed':1,'qualification':'New strict Version target exposed an inconsistent old BOM test pair. Corrected the converted Version counterpart and the new admission fixture Zone counterpart; production unchanged.'},'limitations':['IDF parser overlay covers finite named/unnamed families; no complete parser/InputProcessor parity claim','Missing IDF report field metadata remains an explicit compiler boundary','No full GetProjectData, RunSimulation, Setup or Native numerical comparison activation','SRC-06 four gates and A14/54 B14/64 unchanged'],'validation_scope':'Final fmt and focused RawModel package/compiler report/admission tests. Workspace all-target Clippy and source quality passed on assembly01; only two test input literals changed afterward, with full production-byte proof and independent review. These two expensive static checks and whole-workspace tests were not repeated.','manifest':ref(out/'manifest.json'),'archive':ref(archive),'gates_updated':False})
plan_path=root/'energyplus_porting_plan/plan.json';plan=load(plan_path)
task=next(t for t in plan['tasks']if t['id']=='SRC-06')
assert all(task[k]=='미확인'for k in ['scope_review','unit_gate','integration_gate','production_gate'])
assert 'actual_selected_ordinary_input_origin'not in task
task['actual_selected_ordinary_input_origin']=ref(out/'summary.json');write(plan_path,plan)
card=root/'energyplus_porting_plan/cards/SRC-06.md';text=card.read_text(encoding='utf8')
assert '아래 15개 요약' in text
text=text.replace('아래 15개 요약','아래 16개 요약').replace('## 최신 보고 입력 단위의 실제 QA','## 공통 보고 입력 단위의 실제 QA')
needle='\n기존 Weather03·absent site/station'
assert text.count(needle)==1
text=text.replace(needle,'\n| 실제 입력 형식 / IDF 필드 개수 | [요약](../evidence/SRC-06-ordinary-input-origin/summary.json) · [색인](../evidence/SRC-06-ordinary-input-origin/manifest.json) · [ZIP](../evidence/SRC-06-ordinary-input-origin/evidence.zip) | 전체 입력 형식을 family order와 독립 보존; 프로젝트 네 family의 실제 IDF field count, IDF 전용 NumAlpha·빈 필드와 실패 시 원상 보존. 전체 GetProjectData/startup 활성화는 아님. |\n'+needle)
text+='\n## 실제 입력 형식 단위의 QA\n\n최종 Source `'+current_source['sha256']+'`에서 fmt와 RawModel 전체 16개·compiler report '+str(tests[1]['passed'])+'개·raw admission 1개 테스트, 합계 **'+str(total)+' passed / 0 failed / 0 ignored**를 확인했다. 새 테스트 본문·binary는 없다. all-target Clippy와 source-quality는 직전 assembly01에서 통과했고, 이후에는 두 테스트 입력 쌍의 누락 객체만 고쳤다. 다섯 파일의 production bytes가 동일함을 검토해 두 정적 검사와 전체 workspace 테스트는 반복하지 않았다. 과거 RawModel 15 passed/1 failed(exit101) 기록은 별도 Source로 보존했다. IDF `Output:VariableDictionary;`의 실제 NumAlpha0과 epJSON의 min_fields1을 구분하며 기본 alpha 값 REGULAR는 둘 다 보존한다. 모든 gate와 A/B 완료 수는 그대로다.\n'
card.write_bytes(text.encode())
print(json.dumps({'summary':ref(out/'summary.json'),'archive_members':len(artifacts),'archive_bytes':archive.stat().st_size,'tests':tests},ensure_ascii=False))

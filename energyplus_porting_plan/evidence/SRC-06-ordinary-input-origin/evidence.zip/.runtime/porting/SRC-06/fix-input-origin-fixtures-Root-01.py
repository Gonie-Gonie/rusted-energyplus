"""Fix two inconsistent test input pairs without changing production bytes."""
from pathlib import Path
import difflib
import hashlib
import json

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
parent = json.loads((base / 'ordinary-input-origin-assembly-01/manifest.json').read_bytes())
changes = []
for path, old, new in [
    ('crates/ep_raw_model/src/idf_order.rs',
     '        let epjson = r#"{\n            "RunPeriodControl:SpecialDays": {\n                "\\"Zulu Definition\\"":',
     '        let epjson = r#"{\n            "Version":{"Version 1":{"version_identifier":"26.1"}},\n            "RunPeriodControl:SpecialDays": {\n                "\\"Zulu Definition\\"":'),
    ('crates/ep_run/src/ordinary_equipment_input.rs',
     'Version,26.1;Timestep,4;HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;',
     'Version,26.1;Timestep,4;HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;Zone,z;'),
]:
    target = root / path
    before = target.read_bytes()
    row = next(r for r in parent['files'] if r['canonical']['path'] == path)
    assert hashlib.sha256(before).hexdigest() == row['canonical']['sha256']
    text = before.decode()
    assert text.count(old) == 1, path
    assert text.index(old) > text.index('#[cfg(test)]'), path
    after = text.replace(old, new).encode()
    target.write_bytes(after)
    changes.append({'path': path, 'before_sha256': hashlib.sha256(before).hexdigest(),
                    'after_sha256': hashlib.sha256(after).hexdigest(),
                    'complete_parent_diff': ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='assembly01/' + path, tofile=path))})
(base / 'ordinary-input-origin-fixture-fix-01.json').write_bytes((json.dumps({'changes':changes,'production_bytes_unchanged':True},indent=2)+'\n').encode())
print('Fixed existing BOM test Version counterpart and new admission test Zone counterpart; production unchanged.')

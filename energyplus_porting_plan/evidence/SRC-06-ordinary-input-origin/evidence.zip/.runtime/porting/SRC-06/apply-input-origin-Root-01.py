"""Retain actual input format and IDF project metadata, with existing regressions."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-input-origin-assembly-01'
assert not out.exists()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == '5ecb16f69cf0ece3799b764aeb221d908b9de5f0'

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

paths = [
    'crates/ep_raw_model/src/lib.rs',
    'crates/ep_raw_model/src/idf_order.rs',
    'crates/ep_compiler/src/compiler/report_inputs.rs',
    'crates/ep_run/src/ordinary_equipment_input/fields.rs',
    'crates/ep_run/src/ordinary_equipment_input.rs',
]
before = {p: (root / p).read_bytes() for p in paths}
prep_path = base / 'ordinary-project-data-prep-01/manifest.json'
assert ref(prep_path)['sha256'] == 'a367592439d4b77583e086c98b5a223518004ef61a4708e861a7d1cccca66a5d'
prep = json.loads(prep_path.read_bytes())
proposed = {p: d.decode() for p, d in before.items()}
used = []
for p in [paths[1], paths[3]]:
    row = next(r for r in prep['files'] if r['canonical_path'] == p)
    assert ref(root / p)['sha256'] == row['base']['sha256']
    assert ref(root / row['proposal']['path']) == row['proposal']
    proposed[p] = (root / row['proposal']['path']).read_text(encoding='utf8')
    used.append(row)

def replace(path, old, new):
    assert proposed[path].count(old) == 1, (path, old[:100])
    proposed[path] = proposed[path].replace(old, new)

replace(paths[0], '/// Raw epJSON model before defaults, validation, typed conversion, or reference resolution.', '''#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
enum SourceInputFormat {
    #[default]
    EpJson,
    Idf,
}

/// Raw epJSON model before defaults, validation, typed conversion, or reference resolution.''')
replace(paths[0], '    idf_declaration_order: BTreeMap<ObjectType, Vec<ObjectName>>,', '''    idf_declaration_order: BTreeMap<ObjectType, Vec<ObjectName>>,
    source_input_format: SourceInputFormat,''')
replace(paths[0], '            idf_declaration_order: BTreeMap::new(),', '''            idf_declaration_order: BTreeMap::new(),
            source_input_format: SourceInputFormat::EpJson,''')
replace(paths[0], '    /// Returns the total object instance count.', '''    /// Whether the actual source was epJSON rather than staged IDF.
    /// Successful IDF recovery retains this independently of per-family targets.
    #[must_use]
    pub fn is_epjson(&self) -> bool {
        self.source_input_format == SourceInputFormat::EpJson
    }

    /// Returns the total object instance count.''')
replace(paths[1], 'use crate::{FieldName, RawModel, RawValue};', 'use crate::{FieldName, RawModel, RawValue, SourceInputFormat};')
replace(paths[1], '    model.idf_declaration_order = overlay;\n    Ok(())', '''    model.idf_declaration_order = overlay;
    model.source_input_format = SourceInputFormat::Idf;
    Ok(())''')
replace(paths[1], '    use crate::{FieldName, RawValue, parse_epjson_str_with_idf_order};', '''    use crate::{
        FieldName, RawModel, RawValue, IDF_ORDER_TARGETS, apply_idf_declaration_order,
        parse_epjson_str, parse_epjson_str_with_idf_order,
    };''')
replace(paths[1], '        let raw = parse_epjson_str_with_idf_order(&epjson, &idf)?;', '''        assert!(RawModel::default().is_epjson());
        assert!(RawModel::new(None, Default::default()).is_epjson());
        let mut plain = parse_epjson_str(&epjson)?;
        assert!(plain.is_epjson());
        let before_failure = plain.clone();
        assert!(apply_idf_declaration_order(&mut plain, "", IDF_ORDER_TARGETS).is_err());
        assert_eq!(plain, before_failure);
        let mut raw = parse_epjson_str_with_idf_order(&epjson, &idf)?;
        assert!(!raw.is_epjson());
        let before_failure = raw.clone();
        assert!(apply_idf_declaration_order(&mut raw, "", IDF_ORDER_TARGETS).is_err());
        assert_eq!(raw, before_failure);''')
replace(paths[1], '            let rows = raw.ordered_instances(family)?;', '''            assert!(!raw.is_epjson());
            let rows = raw.ordered_instances(family)?;''')
replace(paths[2], '            let is_epjson = !self.raw_model.has_idf_declaration_order(object_type);', '            let is_epjson = self.raw_model.is_epjson();')
replace(paths[2], '                                max_fields = value.max(min_fields)', '                                max_fields = value')
replace(paths[2], '''        assert!(rows[0].alpha_blank[1]);
        Ok(())''', '''        assert!(rows[0].alpha_blank[1]);

        // Source findMaxFields applies schema min_fields only to epJSON.
        let empty_idf = parse_epjson_str_with_idf_order(
            r#"{"Output:VariableDictionary":{"Output:VariableDictionary 1":{}}}"#,
            "Output:VariableDictionary;",
        )?;
        let empty_idf_model = compile_raw_model(&empty_idf).model.ok_or("IDF report unavailable")?;
        assert_eq!(empty_idf_model.report_inputs.objects[0].num_alphas, 0);
        assert_eq!(empty_idf_model.report_inputs.objects[0].alphas[0], "REGULAR");
        assert!(!empty_idf_model.report_inputs.objects[0].is_epjson);
        let mut empty_json = parse_epjson_str(
            r#"{"Output:VariableDictionary":{"Output:VariableDictionary 1":{}}}"#,
        )?;
        let empty_json_model = compile_raw_model(&empty_json).model.ok_or("epJSON report unavailable")?;
        assert_eq!(empty_json_model.report_inputs.objects[0].num_alphas, 1);
        assert!(empty_json_model.report_inputs.objects[0].is_epjson);
        // A real IDF source with no per-family overlay is still IDF; missing
        // physical field metadata keeps the existing explicit compiler stop.
        ep_raw_model::apply_idf_declaration_order(&mut empty_json, "Output:VariableDictionary;", &[])?;
        assert!(!empty_json.has_idf_declaration_order("Output:VariableDictionary"));
        assert!(!empty_json.is_epjson());
        let missing = compile_raw_model(&empty_json);
        assert!(missing.has_errors());
        assert!(missing.report.diagnostics.iter().any(|d| d.code == "MissingIdfReportFieldCount"));
        Ok(())''')
replace(paths[4], '        let base = r#""Version"', '''        let converted = r#"{
            "Version":{"Version 1":{"version_identifier":"26.1"}},
            "Timestep":{"Timestep 1":{"number_of_timesteps_per_hour":4}},
            "HeatBalanceAlgorithm":{"HeatBalanceAlgorithm 1":{"algorithm":"ConductionTransferFunction"}},
            "SimulationControl":{"SimulationControl 1":{"run_simulation_for_weather_file_run_periods":"Yes"}},
            "Building":{"b":{"solar_distribution":"MinimalShadowing"}},"Zone":{"z":{}}
        }"#;
        let mut converted = ep_raw_model::parse_epjson_str_with_idf_order(converted,
            "Version,26.1;Timestep,4;HeatBalanceAlgorithm,ConductionTransferFunction;SimulationControl,No,No,No,No,Yes;")?;
        assert!(resolve(&converted).is_ok());
        let metadata = converted.objects.get_mut(&ObjectType("Version".into()))
            .and_then(|rows| rows.get_mut(&ep_raw_model::ObjectName("Version 1".into())))
            .ok_or("actual Version object missing")?;
        metadata.fields.insert(FieldName("idf_max_fields".into()), RawValue::Number("-1".into()));
        assert!(resolve(&converted).is_err());
        let base = r#""Version"''')

out.mkdir()
for index, p in enumerate(paths):
    (out / f'{index:02}.before').write_bytes(before[p])
    (root / p).write_bytes(proposed[p].encode())
write(out / 'application.json', {'baseline_head': subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
      'files': [{'canonical_path': p, 'before': ref(out / f'{i:02}.before')} for i, p in enumerate(paths)],
      'project_preparation': ref(prep_path), 'consumed_project_files': used, 'Root_author': ref(Path(__file__))})
print('Applied actual source format and two project-metadata prerequisites; not formatted or tested yet.')

"""Seal actual input-origin integration before focused QA."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

root = Path.cwd()
base = root / '.runtime/porting/SRC-06'
out = base / 'ordinary-input-origin-assembly-01'
assert not (out / 'manifest.json').exists()

def ref(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)}

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

application = json.loads((out / 'application.json').read_bytes())
files = []
for index, row in enumerate(application['files']):
    target = root / row['canonical_path']
    before = (root / row['before']['path']).read_bytes()
    assert hashlib.sha256(before).hexdigest() == row['before']['sha256']
    assert before == subprocess.check_output(['git', 'show', 'HEAD:' + row['canonical_path']], cwd=root)
    after = target.read_bytes()
    assert len(re.findall(rb'#\[test\]', before)) == len(re.findall(rb'#\[test\]', after))
    after_path = out / f'{index:02}.after'
    after_path.write_bytes(after)
    diff_path = out / f'{index:02}.diff'
    diff_path.write_bytes(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
        fromfile='HEAD/' + row['canonical_path'], tofile=row['canonical_path'])).encode())
    files.append({'canonical': ref(target), 'before': row['before'], 'after': ref(after_path), 'complete_diff': ref(diff_path),
                  'test_bodies_before': len(re.findall(rb'#\[test\]', before)), 'test_bodies_after': len(re.findall(rb'#\[test\]', after))})
pin = '6f2e40d10250a105b49966baa24d843711e61048'
original = []
for index, (path, start, end) in enumerate([
    ('src/EnergyPlus/CommandLineInterface.cc', 365, 389),
    ('src/EnergyPlus/InputProcessing/InputProcessor.cc', 746, 792),
    ('src/EnergyPlus/InputProcessing/IdfParser.cc', 267, 312),
]):
    data = subprocess.check_output(['git', '-C', str(root / '.reference/energyplus-src/26.1.0'), 'show', pin + ':' + path])
    literal = b''.join(data.splitlines(keepends=True)[start - 1:end])
    literal_path = out / f'Original-{index:02}.literal'
    literal_path.write_bytes(literal)
    original.append({'commit': pin, 'historical_path': path, 'start': start, 'end': end, 'literal': ref(literal_path)})
write(out / 'manifest.json', {
    'schema': 'src06-input-origin-canonical-assembly.v1', 'baseline_head': application['baseline_head'],
    'files': files, 'application': ref(out / 'application.json'), 'project_preparation': application['project_preparation'],
    'consumed_project_files': application['consumed_project_files'], 'Original_ranges': original,
    'Root_authors': [application['Root_author'], ref(Path(__file__))],
    'behavior': ['Whole-model input format retained separately from finite per-family declaration order',
                 'Only successful atomic IDF recovery changes mode; failed recovery preserves all model bytes/state',
                 'Four project unnamed family identities and physical field counts recovered from actual staged IDF',
                 'IDF report NumAlphas does not acquire epJSON-only schema min_fields',
                 'Existing missing-IDF-field-metadata compiler stop retained; metadata grammar remains finite'],
    'new_test_bodies': 0, 'new_binaries': 0, 'full_project_data_or_startup_activated': False, 'gates_updated': False,
})
print(json.dumps(ref(out / 'manifest.json')))

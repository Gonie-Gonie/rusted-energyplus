from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';mode=sys.argv[1]
parents={
 'B':('canonical-source-controlled-air-balance-B-NOLIMIT-24H-command-Root-29/receipt.json','fea32185b51470d44a0a3af5649671fae08ba9e6e371699caa11e76fdd075190'),
 'A24':('canonical-source-controlled-air-balance-A-24H-command-Root-29/receipt.json','c83171f35ef0bc8078ba825355f6353d29245ea5cd2857e4b7a5a20ca113cea1'),
}
name,sha=parents[mode];p=D/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;cmd=json.loads(p.read_bytes())['command'];case='B-NOLIMIT-24H' if mode=='B' else 'A-24H';receipt='canonical-source-hvac-controlled-node-lifecycle-'+case+'-command-Root-30'
assert cmd[cmd.index('--porting-scope')+1]==('B' if mode=='B' else 'A') and Path(cmd[cmd.index('--weather')+1]).is_file()
assert str((R/'energyplus_porting_plan/cases'/case/'input.idf').resolve()).lower() in [str(Path(v).resolve()).lower() for v in cmd if v.lower().endswith('.idf')]
cmd[cmd.index('--output-dir')+1]=(D/('canonical-source-hvac-controlled-node-lifecycle-'+case+'-Root-30/output')).as_posix();assert not(D/receipt).exists()
raise SystemExit(subprocess.call([sys.executable,'tools/porting/record_command.py','--output-dir',(D/receipt).relative_to(R).as_posix(),'--',*cmd],cwd=R))

"""Root-only checkpoint28 publisher: exactly two actual CLI receipts, no tests.

Requires the accepted independent Source peer and Root actual review hashes.
No action occurs without --publish. This script never runs Cargo or Native.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess, zipfile

R = Path(__file__).resolve().parents[3]
D = R/'.runtime/porting/SRC-06'
READY = D/'zone-equipment-output-publication-prepared-Peer-28'
PUBLIC = R/'energyplus_porting_plan/evidence/SRC-06-canonical-zone-equipment-output-28'
BACK = D/'zone-equipment-output-publication-readback-Peer-28'

def ref(path):
    data = path.read_bytes()
    return {'path':path.relative_to(R).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}

def checked(row):
    p = (R/row['path']).resolve(); p.relative_to(R)
    actual = ref(p)
    assert actual['sha256'] == row['sha256']
    assert actual['bytes'] == row.get('bytes',row.get('size_bytes',actual['bytes']))
    return p

def load(path):
    return json.loads(path.read_bytes())

def accepted(path,sha):
    assert ref(path)['sha256'] == sha
    value = load(path)
    assert value['accepted'] is True and not value['findings']
    return value

def contains(value,row):
    if isinstance(value,dict):
        return (value.get('path'),value.get('sha256'))==(row['path'],row['sha256']) or any(contains(v,row) for v in value.values())
    return isinstance(value,list) and any(contains(v,row) for v in value)

def write_json(path,value):
    path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf8'))

def main(args):
    assert args.publish and not PUBLIC.exists() and not BACK.exists()
    template_path = READY/'publication-template.json'
    template = load(template_path)
    head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
    assert head == template['base_HEAD'] == 'd8fc400e4371114a98ed55fa4306aff01509c1ed'
    assert ref(Path(__file__)) == template['publisher_Source']
    producer = load(checked(template['producer']))
    plan = load(checked(template['complete_plan']))
    assert (plan['inputs'],plan['Rust_sources']) == (4502,4489)
    assert len(producer['files']) == 3 and producer['existing_Source_files'] == 3 and producer['new_Source_files'] == 0
    peer_path = (R/args.peer_path).resolve(); peer_path.relative_to(R)
    peer = accepted(peer_path,args.peer_sha)
    assert ref(peer_path) == template['accepted_independent_peer']
    assert contains(peer,producer['original_draft02'])
    assert producer['all3_proposals_whole_unchanged_from_reviewed_draft02'] is True
    actual_path = D/'Root-source-zone-equipment-output-actual-review-28/review.json'
    actual = accepted(actual_path,args.actual_sha)
    for row in [template['producer'],ref(peer_path),template['complete_plan']]:
        assert contains(actual,row),row['path']
    for key in ['same4502_archived_inputs_exact_final_plan','selected3_final_sources_exact',
                'whole_JSON_equal27_after_exactly_two_owned_path_field_bridges',
                'full_runtime_equal27_after_two_owned_path_bridges']:
        assert actual[key] is True,key
    assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0
    assert actual['policy_changes'] == actual['gate_changes'] == 0
    assert actual['transferred_reported_series']==58 and actual['transferred_JSON_CSV_scalar_roundtrips']==5352
    assert actual['B_runtime_or_fallback_results'] is False
    runs = [load(checked(actual[key])) for key in ['actual_B','actual_A24']]
    assert [run['exit_code'] for run in runs] == [6,0]
    for run,scope in zip(runs,['B','A']):
        assert run['launch_error'] is None and run['source_bytes_match_before_and_after'] is True
        assert Path(run['cwd']).resolve() == R
        command = run['command']
        assert command[command.index('--porting-scope')+1] == scope
        assert not {'--oracle-baseline','--compare-oracle','test','--all-targets'} & set(command)
    assert runs[0]['source_snapshot'] == runs[1]['source_snapshot']
    observed = {row['historical_path']:row for row in load(checked(runs[0]['source_snapshot']))['files']}
    index = {row['path']:row for row in plan['entries']}
    assert len(index) == len(observed) == 4502 and set(index)==set(observed)
    for name,row in index.items():
        assert (row['final_sha256'],row['final_bytes']) == (observed[name]['archive']['sha256'],observed[name]['size_bytes'])
    for row in producer['files']:
        name = row['canonical_path']
        assert (R/name).read_bytes() == checked(row['proposed']).read_bytes() == checked(observed[name]['archive']).read_bytes()
    roots = ['canonical-source-zone-equipment-output-B-NOLIMIT-24H-Root-28','canonical-source-zone-equipment-output-A-24H-Root-28']
    reports = []
    for name in roots:
        summary_path = D/name/'output/run-summary.json'
        diagnostic_path = D/name/'output/diagnostics.json'
        assert contains(actual,ref(summary_path)) and contains(actual,ref(diagnostic_path))
        reports.append((load(summary_path),load(diagnostic_path)))
    bs,bd = reports[0]; asum,ad = reports[1]
    errors = [row['message'] for row in bd['diagnostics'] if row['code']=='RuntimeConvergenceFailure']
    assert bs['exit_code']==6 and bs['rust_runtime'] is None and errors==[actual['B_frontier']]
    assert asum['exit_code']==0 and asum['rust_runtime'] is not None
    assert not any(row['code']=='RuntimeConvergenceFailure' for row in ad['diagnostics'])

    base = R/'energyplus_porting_plan'
    names = ['CHECKLIST.md','STATE_CONTRACTS.md','cards/SRC-06.md']
    docs = {name:(base/name).read_bytes() for name in names}
    plan_path = base/'plan.json'; old_plan = plan_path.read_bytes(); old_value = json.loads(old_plan)
    for name,data in docs.items():
        assert data == subprocess.check_output(['git','show',head+':energyplus_porting_plan/'+name],cwd=R)
        assert '\ufffd' not in data.decode('utf8','strict')
    assert old_plan == subprocess.check_output(['git','show',head+':energyplus_porting_plan/plan.json'],cwd=R)
    previous = load(checked(template['previous_checkpoint']))
    assert (previous['A'],previous['B'])==('14/54','14/64')
    files = {}
    def add(path):
        path = path.resolve(); path.relative_to(R); row=ref(path)
        assert path.suffix.lower()!='.zip'
        assert row['path'] not in files or files[row['path']]['ref']==row
        files[row['path']]={'path':path,'ref':row}
    for row in template['finite_archive_inputs']:add(checked(row))
    for path in [Path(__file__),template_path,peer_path,actual_path]:add(path)
    application_path=checked(actual['application'])
    application=load(application_path)
    assert application['accepted'] is True and not application['findings']
    assert application['base_HEAD']==head
    for row in [template['producer'],ref(peer_path),template['complete_plan']]:
        assert contains(application,row)
    for path in [application_path,checked(actual['author_Source']),checked(application['author_Source']),
                 checked(actual['launcher_Source'])]:add(path)
    for key,run in zip(['actual_B','actual_A24'],runs):
        add(checked(actual[key]))
        for field in ['stdout','stderr','source_snapshot']:add(checked(run[field]))
    for row in actual['publication_artifacts']:add(checked(row))
    for row in producer['files']:add(R/row['canonical_path'])
    PUBLIC.mkdir(parents=True); BACK.mkdir()
    (BACK/'plan-before.json').write_bytes(old_plan)
    for name,data in docs.items():
        path=BACK/'docs-before'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    archive=PUBLIC/'evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as stream:
        for name,item in sorted(files.items()):
            assert ref(item['path'])==item['ref'];stream.write(item['path'],arcname=name)
    with zipfile.ZipFile(archive) as stream:
        assert stream.testzip() is None and set(stream.namelist())==set(files)
        for name,item in files.items():assert hashlib.sha256(stream.read(name)).hexdigest()==item['ref']['sha256']
    inventory=PUBLIC/'manifest.json'
    write_json(inventory,{'schema':'src06-canonical28-finite-evidence-archive.v1','archive':ref(archive),
                         'entries':[item['ref'] for name,item in sorted(files.items())],
                         'scope':'3 coherent post-component output/demand/availability Sources, Native authority, accepted peer and actual B/A24. No checkpoint28 test execution. No historical ZIP recursion, annual JSON/CSV or transitive rebuild claim.'})
    summary=dict(template['summary_template'])
    summary.update(schema='src06-canonical-zone-equipment-output.v1',status='Genuine Source zone-equipment output and demand update; B incomplete at actual frontier',
                   producer=template['producer'],independent_peer=ref(peer_path),complete_compiler_plan=template['complete_plan'],
                   canonical_B_CLI=actual['actual_B'],canonical_A24_CLI=actual['actual_A24'],Root_actual_review=ref(actual_path),
                   actual_B_incomplete_boundary=errors[0],actual_B_completed=False,canonical_A24_completed_Source_run=True,
                   accepted_A24_proof_transfer={'accepted27_proof':actual['accepted27_full5352_proof'],
                       'series':actual['transferred_reported_series'],'samples':actual['transferred_JSON_CSV_scalar_roundtrips'],
                       'physical_files_whole_equal27':len(actual['whole_physical_streams_equal27']),
                       'CSV_files_whole_equal27':len(actual['whole_CSV_equal27']),
                       'scope':'Proof transfer from accepted27; no new Native/72H/annual run or internal-state equivalence claim.'},
                   B_Node_lifecycle_observation=actual['B_Node_lifecycle_observation'],
                   actual_scope_qualification='Only the accepted Root actual aggregate establishes executed paths and proof transfer; Source peer alone establishes neither internal numerical Native state equivalence nor positive Node execution.',
                   archive=ref(archive),archive_manifest=ref(inventory),archive_entries=len(files),publisher_Source=ref(Path(__file__)))
    summary_path=PUBLIC/'summary.json';write_json(summary_path,summary)
    relative='evidence/SRC-06-canonical-zone-equipment-output-28/summary.json'
    for name,data in docs.items():
        link='../'+relative if name.startswith('cards/') else relative
        text=template['doc_appends'][name].replace('{{actual_B_frontier}}',actual['B_frontier'])
        append='\n\n[Source 장비 출력·수요 갱신 검증]('+link+'). '+text+'\n'
        assert '\ufffd' not in append and '{{' not in append and (base/name).read_bytes()==data
        (base/name).write_bytes(data+append.encode('utf8'))
    after=json.loads(old_plan);task=next(row for row in after['tasks'] if row['id']=='SRC-06')
    key='canonical_zone_equipment_output_28';assert key not in task
    task[key]={'path':summary_path.relative_to(R).as_posix(),'sha256':ref(summary_path)['sha256'],'size_bytes':summary_path.stat().st_size}
    inverse=json.loads(json.dumps(after));del next(row for row in inverse['tasks'] if row['id']=='SRC-06')[key]
    assert inverse==old_value and plan_path.read_bytes()==old_plan
    write_json(plan_path,after)
    result={'status':'PUBLISHED_PENDING_ROOT_DOCS_QA_AND_READBACK','summary':ref(summary_path),'archive':ref(archive),
            'archive_manifest':ref(inventory),'archive_entries':len(files),'base_HEAD':head,'publisher':ref(Path(__file__)),
            'plan_before':ref(BACK/'plan-before.json'),'Git_mutated':False,'Cargo_tests_Native_executed':False,'gate_changes':False}
    readback=BACK/'publication-readback.json';write_json(readback,result);print(json.dumps(ref(readback)))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--peer-path',required=True)
    parser.add_argument('--peer-sha',required=True)
    parser.add_argument('--actual-sha',required=True)
    parser.add_argument('--publish',action='store_true')
    main(parser.parse_args())

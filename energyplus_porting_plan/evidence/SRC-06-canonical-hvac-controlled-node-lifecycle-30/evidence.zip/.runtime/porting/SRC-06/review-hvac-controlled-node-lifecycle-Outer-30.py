"""Independent prospective30 Source semantics and actual Objexx initialization authority."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';N=R/'.reference/energyplus-src/26.1.0'
O=D/'Outer-hvac-controlled-node-lifecycle-Source-review-30'
COMMIT='6f2e40d10250a105b49966baa24d843711e61048';BASE='d8fc400e4371114a98ed55fa4306aff01509c1ed'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=sha(b),bytes=len(b))
def checked(r):
 b=(R/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r.get('bytes',len(b)),r['path'];return b
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);return ref(p)
def main():
 assert not O.exists()
 pr=ref(D/'source-hvac-controlled-node-lifecycle-draft-Root-30/draft.json');assert pr['sha256']=='a2af942daa694be1d8b6c89d36c0646498b1dfd83c193875df96c8b4e2b028b5'
 m=json.loads(checked(pr));checked(m['author_Source']);assert len(m['files'])==3 and m['new_tests']==m['new_sources']==0
 t=ast.parse((D/'review-canonical-source82-activation-Audit-01.py').read_text(encoding='utf-8'));f=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply');ns={'re':re};exec(compile(ast.Module(body=[f],type_ignores=[]),'<literal>','exec'),ns)
 files=[];texts={}
 for i,row in enumerate(m['files'],1):
  p=row['canonical_path'];before=checked(row['before']);after=checked(row['proposed'])
  assert before==subprocess.check_output(['git','show',BASE+':'+p],cwd=R)==(R/p).read_bytes()
  assert ns['apply'](before,checked(row['forward_diff']))==after and ns['apply'](after,checked(row['inverse_diff']))==before
  added='\n'.join(x[1:] for x in checked(row['forward_diff']).decode().splitlines() if x.startswith('+') and not x.startswith('+++'))
  assert not re.search(r'\.(unwrap|expect)\s*\(|\b(panic|todo|unimplemented|unreachable)!|#\[(test|ignore)',added)
  q=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=after,capture_output=True);assert q.returncode==0
  files.append(dict(canonical_path=p,before=row['before'],proposed=row['proposed'],whole_selected_before_Git_d8fc_and_current_exact=True,literal_forward_inverse_exact=True,fresh_Source_only_parse=dict(exit_code=0,stdout=save(O/'parse'/f'{i:02}.stdout',q.stdout),stderr=save(O/'parse'/f'{i:02}.stderr',q.stderr))))
  texts[p]=after.decode()
 paths={
  'src/EnergyPlus/SimAirServingZones.cc':[(1928,1950),(2127,2140),(2309,2426)],
  'src/EnergyPlus/HVACManager.cc':[(1760,1790),(3017,3047)],
  'src/EnergyPlus/DataConvergParams.hh':[(95,125)],
  'src/EnergyPlus/DataLoopNode.hh':[(95,104),(439,500)],
  'third_party/ObjexxFCL/src/ObjexxFCL/Array1D.hh':[(925,945),(1380,1408),(1419,1439)],
  'third_party/ObjexxFCL/src/ObjexxFCL/Array.hh':[(1540,1568),(2050,2079)],
  'third_party/ObjexxFCL/src/ObjexxFCL/AlignedAllocator.hh':[(45,85)],
  'third_party/ObjexxFCL/src/ObjexxFCL/TypeTraits.hh':[(50,110)],
 }
 native=[]
 for i,(p,spans) in enumerate(paths.items(),1):
  b=(N/p).read_bytes();assert b==subprocess.check_output(['git','show',COMMIT+':'+p],cwd=N)
  w=save(O/'Native'/f'{i:02}-{Path(p).name}',b);lines=b.splitlines(keepends=True);es=[]
  for a,z in spans:es.append(dict(first=a,last=z,source=save(O/'Native'/f'{i:02}-{a}-{z}.txt',b''.join(lines[a-1:z]))))
  native.append(dict(Native_path=p,whole=w,extents=es))
 # This binds retained successful Native build custody, not a newly executed compiler.
 br=ref(D/'controlled-air-native-build-Root-21/native-build.json');assert br['sha256']=='9ff0df8f49b91b5318a8bdc410c951be21378ae81ad2252f6efc05af50f858e3'
 build=json.loads(checked(br));assert build['accepted'] and build['Native_bytes_match_before_and_after']
 before_ref=build['Native_before'];before=json.loads(checked(before_ref))
 registry_ref=before['live_compile_registry'];registry=checked(registry_ref);assert sha(registry)=='c5b5d41281d232afdd4922fe533278418c702e2a92b9b57731a0796fa57ecc11'
 commands=json.loads(registry);assert len(commands)==795
 wanted=[c for c in commands if Path(c['file']).name in ('HVACManager.cc','SimAirServingZones.cc')];assert len(wanted)==2
 for c in wanted:
  assert 'OBJEXXFCL_ARRAY_INIT' not in c['command'] and '@' not in c['command']
  for flag in ['-DOBJEXXFCL_ALIGN=64','-std=c++20','-ffp-contract=off','-O0','-DNDEBUG','-UNDEBUG','-include']:assert flag in c['command']
 pch=R/'.runtime/ep261-gcc13-o0/src/EnergyPlus/CMakeFiles/energypluslib.dir/cmake_pch.hxx';pch_bytes=pch.read_bytes()
 assert b'#define OBJEXXFCL' not in pch_bytes and b'Array1D.hh' in pch_bytes
 macro_cmd=['rg','-n',r'^\s*#\s*(define|undef)\s+OBJEXXFCL_ARRAY_INIT(_DEBUG)?\b',str(N/'src'),str(N/'third_party'),'--glob','*.{hh,h,hpp,cc,cpp,hxx,cxx}']
 mc=subprocess.run(macro_cmd,capture_output=True);assert mc.returncode==1 and not mc.stdout and not mc.stderr
 contexts=[]
 for p in ['crates/ep_runtime/src/heat_balance/selected_project_data.rs','crates/ep_runtime/src/heat_balance/ordinary_equipment/source_nodes.rs','crates/ep_runtime/src/heat_balance/ordinary_hvac_manager/owners.rs']:
  b=(R/p).read_bytes();assert b==subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
  contexts.append(dict(canonical_path=p,whole=save(O/'Source_context'/Path(p).name,b),Git_d8fc_exact=True))
 project=checked(contexts[0]['whole']).decode();assert 'humidity_ratio: [Option<f64>; 10]' in project and 'mass_flow_rate: [Option<f64>; 10]' in project and 'temperature: [Option<f64>; 10]' in project
 patterns=['reset_source_hvac_node_setpoints','source_node_mass_flow','update_source_zone_inlet_convergence','inlet_node_number(','return_node_number(','return_node_air_loop_number(']
 census=[];allrust=subprocess.check_output(['rg','--files','crates','-g','*.rs'],cwd=R,text=True).splitlines()
 for p in allrust:
  cp=Path(p).as_posix();b=texts[cp].encode() if cp in texts else (R/p).read_bytes();s=b.decode()
  hits=[dict(line=i,text=x) for i,x in enumerate(s.splitlines(),1) if any(a in x for a in patterns)]
  if hits:census.append(dict(path=cp,sha256=sha(b),bytes=len(b),hits=hits))
 result=dict(schema='src06-independent-prospective30-HVAC-node-lifecycle-review.v1',accepted=True,findings=[],reviewed_packet=pr,
  scope='Full three prospective Source30 bodies; no final29 parent/complete compiler-plan join or actual30 execution claim.',files=files,literal_applications=6,fresh_Source_only_parses=3,
  Native_commit=COMMIT,Native_wholes=native,Native_whole_count=len(native),strict_Native_extents=sum(len(x['extents']) for x in native),
  compiler_macro_authority=dict(accepted_actual_build=br,Native_before=before_ref,actual_compile_registry=registry_ref,registry_rows=795,two_actual_commands=wanted,registry_whole_copy=save(O/'compiler/compile_commands.json',registry),forced_PCH=save(O/'compiler/cmake_pch.hxx',pch_bytes),macro_definition_census=dict(command=macro_cmd,exit_code=1,stdout=save(O/'compiler/macro.stdout',mc.stdout),stderr=save(O/'compiler/macro.stderr',mc.stderr)),conclusion='Actual retained commands do not define either OBJEXXFCL_ARRAY_INIT macro; forced PCH has no definition and bounded full Native src/third_party header/C++ definition census is empty. No compiler/preprocessor was executed.'),
  Source_contexts=contexts,whole_crates_API_census=dict(Rust_files=len(allrust),patterns=patterns,files=census),
  semantic_proof=[
   'InitAirLoops allocates same convergence owner for all actual zones, then real count/NodeNum from stored Config inlet arrays, calls ConnectReturnNodes, and clears existing one-time flag only after success. No fabricated Node ordinal or duplicate Config.',
   'ConnectReturnNodes honors actual equipment-input-filled predicate and controlled-zone/return counts. Without return paths its initialized airLoopNum remains zero, so matching inlet writes are skipped. Positive ReturnAirPath stops at actual first read; positive primary-airloop stops at actual AirToZoneNodeInfo predicate. Actual controlled ReturnNodeAirLoopNum zero skips DesSupply; positive stops at that actual lookup.',
   'Same physical Node reset runs under existing !ZoneSizing&&!SysSizing/my_setpoint_init. Native NumNodes>0 guards full Node array five-field writes and same five DefaultNodeValues writes, exact -999 sentinel and order; successful flag and DoSetPointTest transitions remain Native.',
   'Convergence uses actual retained NodeNum, writes humidity then mass then temperature, captures each old ten-slot array before overwriting its first cell, and shifts indices1..9 from old0..8. All new values read the same NodeOwner physical rows; Node mass access is narrow scalar borrow, no new owner.',
   'Field-disjoint Project and Equipment borrows remain real borrowed owners. First mutable Node view is last used at humidity read before immutable mass getter; a fresh real mutable Node view reads temperature. No SourceHvacOwners constructor/API change or test struct literal introduced.',
   'Array1D allocate->dimension_real->size_real/Array.resize->raw Aligned allocate_zero->initialize performs placement new T with no parentheses under retained macro context. allocate_zero is operator-new even for zero size, not memset. DataConverg NodeNum has real initializer0; its three std::array<Real64,10> histories have no initializer. Source arrays of None preserve safe symbolic unknowns until real writes; shifts retain unknown state. No native unknown raw bits, undefined-read equivalence, fabricated numeric zeros, or downstream diagnostic numerical parity is claimed.'
  ],validation='Root final29/30 selected-source compiler join and appropriate actual CLI validation pending. Source-only syntax parses are not Rust typechecking. No new tests, Cargo, Native compiler/engine, canonical edits, publication or commits.',author_Source=ref(Path(__file__)))
 print(json.dumps(save(O/'review.json',(json.dumps(result,ensure_ascii=True,indent=2)+'\n').encode())))
if __name__=='__main__':main()

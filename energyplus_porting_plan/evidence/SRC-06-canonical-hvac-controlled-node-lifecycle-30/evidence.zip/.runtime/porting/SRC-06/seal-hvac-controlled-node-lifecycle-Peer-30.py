"""Root-authorized Source30 compiler join; execute only after actual29+commit."""
import argparse
import ast
import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
OUT = D / 'source-hvac-controlled-node-lifecycle-held-Peer-30'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def auth(row):
    p = R / row['path']
    assert ref(p)['sha256'] == row['sha256'], row
    if 'bytes' in row:
        assert ref(p)['bytes'] == row['bytes'], row
    return p

def load(path, sha):
    p = R / path
    assert ref(p)['sha256'] == sha
    return p, json.loads(p.read_bytes())

def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], check=True, capture_output=True).stdout

def save(name, data):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_bytes(data)
    return ref(p)

def dump(name, data):
    return save(name, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())

def authenticate_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            auth(value)
        for child in value.values():
            authenticate_refs(child)
    elif isinstance(value, list):
        for child in value:
            authenticate_refs(child)

a = argparse.ArgumentParser()
a.add_argument('--base-head', required=True)
a.add_argument('--actual29-review', required=True)
a.add_argument('--actual29-sha', required=True)
a.add_argument('--seal', action='store_true')
a = a.parse_args()
assert a.seal and re.fullmatch('[0-9a-f]{40}', a.base_head)
assert git(R, 'rev-parse', 'HEAD').decode().strip() == a.base_head
assert git(R, 'rev-parse', 'origin/main').decode().strip() == a.base_head
assert not git(R, 'status', '--porcelain=v1', '-uno').strip()
assert not OUT.exists()
dp, draft = load('.runtime/porting/SRC-06/source-hvac-controlled-node-lifecycle-draft-Root-30-02/draft.json', 'ce6e5b2c48cd9d8479e25d6e0df0421c8b7dbe3d94ed2676f5416fba7d3a3a12')
ep, extension = load('.runtime/porting/SRC-06/Peer-hvac-return-air-extension-Source-review-30-02/review.json', '9546e538bcdf8b2b855c52947a2586b9524db36f3b7dccca898a9fee709680c1')
assert extension['accepted'] and not extension['findings'] and extension['reviewed_packet'] == ref(dp)
pp = auth(draft['original_three_Source_peer'])
peer = json.loads(pp.read_bytes())
assert peer['accepted'] and not peer['findings']
assert peer['reviewed_packet'] == draft['original_three_Source_draft']
assert extension['original_three_Source_peer'] == ref(pp)
ap, actual = load(a.actual29_review, a.actual29_sha)
assert actual['accepted'] and not actual['findings']
parent_path = auth(actual['producer'])
parent = json.loads(parent_path.read_bytes())
plan_path = auth(actual['complete_compiler_plan'])
plan = json.loads(plan_path.read_bytes())
assert plan['inputs'] == 4503 and plan['Rust_sources'] == 4490
assert actual['actual_test_bodies_executed'] == actual['new_test_bodies'] == 0
receipts = {}
for label, key, code in [('B-NOLIMIT-24H', 'actual_B', 6), ('A-24H', 'actual_A24', 0)]:
    p = auth(actual[key])
    run = json.loads(p.read_bytes())
    assert run['exit_code'] == code and run['source_bytes_match_before_and_after']
    receipts[label] = {'receipt': ref(p), 'exit_code': code, 'snapshot': run['source_snapshot']}
assert receipts['B-NOLIMIT-24H']['snapshot'] == receipts['A-24H']['snapshot']
snapshot_path = auth(receipts['B-NOLIMIT-24H']['snapshot'])
snapshot = json.loads(snapshot_path.read_bytes())
archives = {row['historical_path']: row['archive'] for row in snapshot['files']}
entries = {row['path']: copy.deepcopy(row) for row in plan['entries']}
assert len(entries) == len(archives) == 4503 and set(entries) == set(archives)
readback = []
for name, entry in entries.items():
    b = auth(archives[name]).read_bytes()
    assert b == auth(entry['source']).read_bytes() == (R / name).read_bytes(), name
    assert (hashlib.sha256(b).hexdigest(), len(b)) == (entry['final_sha256'], entry['final_bytes']), name
    readback.append({'path': name, 'actual_archive': archives[name], 'actual_sha256': entry['final_sha256'], 'actual_bytes': len(b), 'whole_live_equal_actual_and_plan': True})
t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
original = json.loads(auth(draft['original_three_Source_draft']).read_bytes())
original_rows = {row['canonical_path']: row for row in original['files']}
files = []
logical = {}
for i, row in enumerate(draft['files'], 1):
    name = row['canonical_path']
    before = auth(row['before']).read_bytes()
    new = auth(row['proposed']).read_bytes()
    assert before == auth(archives[name]).read_bytes() == (R / name).read_bytes() == git(R, 'show', a.base_head + ':' + name)
    if i <= 3:
        for key in ['before', 'proposed', 'forward_diff', 'inverse_diff']:
            assert auth(row[key]).read_bytes() == auth(original_rows[name][key]).read_bytes()
    else:
        assert row['proposed'] == extension['files'][0]['proposed']
    assert ns['apply_literal'](before, auth(row['forward_diff']).read_bytes()) == new
    assert ns['apply_literal'](new, auth(row['inverse_diff']).read_bytes()) == before
    parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=new, capture_output=True, cwd=R)
    assert parse.returncode == 0, (name, parse.stderr)
    proposed = save('proposed/' + name, new)
    files.append({'canonical_path': name, 'before_absent': False, 'before': save('before/' + name, before), 'actual_parent_archive': archives[name], 'proposed': proposed, 'literal_origin_whole': row['proposed'], 'literal_inverse': save('literal-inverse/' + name, before), 'forward_diff': save(f'diffs/{i:02}-forward.diff', auth(row['forward_diff']).read_bytes()), 'inverse_diff': save(f'diffs/{i:02}-inverse.diff', auth(row['inverse_diff']).read_bytes()), 'before_whole_Git_exact_at_base': True, 'Source_only_parse': {'exit_code': 0, 'stdout': save(f'parse/{i:02}.stdout', parse.stdout), 'stderr': save(f'parse/{i:02}.stderr', parse.stderr)}})
    entries[name] = {'path': name, 'final_sha256': proposed['sha256'], 'final_bytes': proposed['bytes'], 'source': proposed, 'origin': 'Whole reviewed Source30 draft02 proposal; no semantic rewrite'}
    logical[name] = new.decode()
assert len(files) == 4 and len(entries) == 4503 and sum(x.endswith('.rs') for x in entries) == 4490
assert 'crates/ep_runtime/src/heat_balance/source_output_registration/report_diagnostics.rs' not in entries
for name in entries:
    if name.endswith('pipeline.json'):
        assert entries[name] == next(row for row in plan['entries'] if row['path'] == name)
terms = peer['whole_crates_API_census']['patterns']
api = []
for name, row in sorted(entries.items()):
    if not name.endswith('.rs'):
        continue
    text = logical.get(name)
    if text is None:
        text = auth(row['source']).read_text(encoding='utf-8')
    found = [term for term in terms if term in text]
    if found:
        api.append({'path': name, 'terms': found})
assert {row['path'] for row in api} == {row['path'] for row in peer['whole_crates_API_census']['files']}
native_sources = {}
for evidence in [peer, extension]:
    for row in evidence['Native_wholes']:
        name = row['Native_path']
        b = auth(row['whole']).read_bytes()
        assert b == git(N, 'show', PIN + ':' + name) == (N / name).read_bytes()
        item = native_sources.setdefault(name, {'bytes': b, 'ranges': {}})
        assert item['bytes'] == b
        for e in row['extents']:
            first, last = e['first'], e['last']
            value = b''.join(b.splitlines(keepends=True)[first - 1:last])
            assert value == auth(e['source']).read_bytes()
            item['ranges'][first, last] = value
native = []
for name, row in sorted(native_sources.items()):
    native.append({'Native_path': name, 'whole': save('Native/' + name, row['bytes']), 'pinned_Git_exact': True, 'extents': [{'first': first, 'last': last, 'source': save('Native-extents/' + Path(name).name + f'.{first}-{last}.txt', value)} for (first, last), value in sorted(row['ranges'].items())]})
context_sources = {}
for row in peer['Source_contexts'] + extension['concrete_Source_contexts']:
    name = row['canonical_path']
    b = auth(row['whole']).read_bytes()
    assert b == auth(archives[name]).read_bytes() == (R / name).read_bytes() == git(R, 'show', a.base_head + ':' + name)
    if name in context_sources:
        assert context_sources[name] == b
    context_sources[name] = b
contexts = [{'canonical_path': name, 'whole': save('Source-context/' + name, b), 'actual_parent_archive': archives[name], 'current_and_Git_exact': True} for name, b in sorted(context_sources.items())]
authenticate_refs(peer['compiler_macro_authority'])
final_plan = dump('complete-final-compiler-Source-plan.json', {'schema': 'src06-complete-Source30-compiler-input-plan.v1', 'base_HEAD': a.base_head, 'actual29_parent_snapshot': ref(snapshot_path), 'prior_plan': ref(plan_path), 'inputs': 4503, 'Rust_sources': 4490, 'entries': [entries[name] for name in sorted(entries)], 'selected4_exact_draft02': True, 'quarantined_diagnostic_child_absent': True, 'Root_full_readback_required': True})
manifest = {'schema': 'src06-held-coherent-controlled-HVAC-node-lifecycle.v1', 'status': 'HELD Source30 on clean committed actual29; no Source30 runtime claim', 'base_HEAD': a.base_head, 'accepted29_actual_review': ref(ap), 'parent_producer': ref(parent_path), 'actual_parent_receipts': receipts, 'actual_parent_snapshot': ref(snapshot_path), 'prior_complete_compiler_Source_plan': ref(plan_path), 'complete_final_compiler_Source_plan': final_plan, 'compiler_inputs': 4503, 'Rust_sources': 4490, 'original_draft02': ref(dp), 'independent_semantic_peers': {'original_three': ref(pp), 'fourth_and_identity': ref(ep)}, 'semantic_peer_scope': 'Original three full semantic peer plus independent fourth Source and original-three whole identity; final full compiler join is this author preparation and requires Root independent readback.', 'files': files, 'existing_Source_files': 4, 'new_Source_files': 0, 'selected_Source_files': 4, 'literal_applications': 8, 'Source_only_parses': 4, 'all4_proposals_whole_unchanged_from_reviewed_draft02': True, 'full4503_parent_readback': dump('actual29-parent-full-readback.json', readback), 'whole4490_Rust_API_census': dump('API-census.json', {'Rust_sources_examined': 4490, 'all_crates_runtime_tests_included': True, 'hits': api, 'new_tests': 0}), 'Native_commit': PIN, 'Native_authorities': native, 'compiler_macro_authority': peer['compiler_macro_authority'], 'concrete_same_owner_contexts': contexts, 'operation_order': {'original_three': peer['semantic_proof'], 'fourth': extension['semantic_proof']}, 'scope': draft['scope'], 'unknown_history_qualification': draft['unknown_history_qualification'], 'remaining_scope': 'Positive fan/warning/airloop/return-path operations remain truthful boundaries. Existing unknown convergence histories preserve symbolic None; no undefined native scalar-read numerical equivalence claimed. No fullB/all12 or positive Node/internal-state Native equivalence claim.', 'validation_policy': 'Root owns actual production B then appropriate A24 transfer; no new tests, repeated cohort, whole-suite, Cargo/Native/main mutation by author.', 'new_test_bodies': 0, 'Cargo_main_tests_or_Native_mutations': False, 'author_Source': ref(Path(__file__))}
print(json.dumps(dump('manifest.json', manifest)))

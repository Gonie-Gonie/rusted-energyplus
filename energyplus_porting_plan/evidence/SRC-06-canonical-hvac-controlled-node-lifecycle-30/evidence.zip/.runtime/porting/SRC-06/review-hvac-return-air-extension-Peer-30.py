"""Independent fourth-Source peer plus exact accepted-three-Source bridge."""
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
N = R / '.reference/energyplus-src/26.1.0'
PIN = '6f2e40d10250a105b49966baa24d843711e61048'
BASE = 'd8fc400e4371114a98ed55fa4306aff01509c1ed'
OUT = D / 'Peer-hvac-return-air-extension-Source-review-30-02'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def auth(r):
    p = R / r['path']
    assert ref(p) == r
    return p

def save(name, b):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_bytes(b)
    return ref(p)

def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], check=True, capture_output=True).stdout

assert not OUT.exists()
dp = D / 'source-hvac-controlled-node-lifecycle-draft-Root-30-02/draft.json'
assert ref(dp)['sha256'] == 'ce6e5b2c48cd9d8479e25d6e0df0421c8b7dbe3d94ed2676f5416fba7d3a3a12'
draft = json.loads(dp.read_bytes())
old_path = auth(draft['original_three_Source_draft'])
old = json.loads(old_path.read_bytes())
peer_path = auth(draft['original_three_Source_peer'])
peer = json.loads(peer_path.read_bytes())
assert peer['accepted'] and not peer['findings'] and peer['reviewed_packet'] == ref(old_path)
old_rows = {x['canonical_path']: x for x in old['files']}
peer_rows = {x['canonical_path']: x for x in peer['files']}
bridge = []
for row in draft['files'][:3]:
    name = row['canonical_path']
    prior = old_rows[name]
    for key in ['before', 'proposed', 'forward_diff', 'inverse_diff']:
        assert auth(row[key]).read_bytes() == auth(prior[key]).read_bytes()
    assert auth(row['proposed']).read_bytes() == auth(peer_rows[name]['proposed']).read_bytes()
    assert auth(row['before']).read_bytes() == (R / name).read_bytes() == git(R, 'show', BASE + ':' + name)
    bridge.append({'canonical_path': name, 'original_reviewed_proposed': prior['proposed'], 'successor_proposed': row['proposed'], 'before_proposed_both_diffs_whole_unchanged': True})
assert len(bridge) == 3
row = draft['files'][3]
name = row['canonical_path']
assert name == 'crates/ep_runtime/src/heat_balance/ordinary_equipment/heat_to_return_air.rs'
before = auth(row['before']).read_bytes()
proposed = auth(row['proposed']).read_bytes()
assert before == (R / name).read_bytes() == git(R, 'show', BASE + ':' + name)
tree = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
assert ns['apply_literal'](before, auth(row['forward_diff']).read_bytes()) == proposed
assert ns['apply_literal'](proposed, auth(row['inverse_diff']).read_bytes()) == before
parse = subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=proposed, capture_output=True, cwd=R)
assert parse.returncode == 0, parse.stderr
native_name = 'src/EnergyPlus/HVACManager.cc'
b = (N / native_name).read_bytes()
assert b == git(N, 'show', PIN + ':' + native_name)
native = {'Native_path': native_name, 'whole': save('Native/' + native_name, b), 'pinned_Git_exact': True, 'extents': [{'first': 2884, 'last': 3015, 'source': save('Native-extents/HVACManager.cc.2884-3015.txt', b''.join(b.splitlines(keepends=True)[2883:3015]))}]}
contexts = []
for name in ['crates/ep_runtime/src/heat_balance/ordinary_equipment.rs', 'crates/ep_runtime/src/heat_balance/ordinary_equipment/source_controlled_equipment.rs', 'crates/ep_runtime/src/heat_balance/selected_heat_balance_input/zone/storage.rs']:
    b = (R / name).read_bytes()
    assert b == git(R, 'show', BASE + ':' + name)
    contexts.append({'canonical_path': name, 'whole': save('Source-context/' + name, b), 'current_and_Git_d8fc_exact': True})
report = {
    'schema': 'src06-independent-bounded-Source30-return-air-extension-review.v1', 'accepted': True, 'findings': [],
    'reviewed_packet': ref(dp), 'original_three_Source_peer': ref(peer_path), 'original_three_Source_draft': ref(old_path),
    'scope': 'Independent whole fourth heat_to_return_air Source; exact identity of original three accepted Sources. Original three semantics/compiler macro authority remain the explicitly named independent prior peer, not re-reviewed here.',
    'three_Source_literal_identity': bridge,
    'files': [{'canonical_path': row['canonical_path'], 'before': row['before'], 'proposed': row['proposed'], 'forward_diff': row['forward_diff'], 'inverse_diff': row['inverse_diff'], 'whole_before_current_and_Git_exact': True, 'two_literal_applications': True, 'fresh_Source_only_parse': {'exit_code': 0, 'stdout': save('parse/04.stdout', parse.stdout), 'stderr': save('parse/04.stderr', parse.stderr)}}],
    'Native_commit': PIN, 'Native_wholes': [native], 'concrete_Source_contexts': contexts,
    'semantic_proof': [
        'Real AirLoopsSimOnce false returns immediately; existing NumPrimaryAirSys and MyOneTimeFlag owners and positive AirLoopControlInfo boundaries remain whole unchanged.',
        'First one-time per-zone traversal preserves Native lack of IsControlled filtering, actual NumInletNodes and ordered same InletNodeAirLoopNum values. airLoopFound is actual localfalse and becomes true only for actual positive airloop. Original count equality and write-only-true ZonalSystemOnly behavior remain.',
        'Warning traversal skips only actual uncontrolled Config. CyclingFan localfalse remains genuine until a positive airloop reaches the exact missing cycFanSched operation; zero/nonpositive values do not fabricate schedule/fan state. ZonalSystemOnly || CyclingFan predicate precedes unchanged actual Zone/warning operand boundary; one-time flag clears only after this succeeds.',
        'Final traversal binds actual Config and Zone before IsControlled, writes NoHeatToReturnAir=true and only traverses inlet array when !ZonalSystemOnly. Positive airloop stops before actual fanOp read; nonpositive values leave true. No invented continuous fan, warning suppression or duplicate Node/Zone/cache introduced.',
        'All three previous blanket positive-inlet stops are replaced only by actual ordered stored array reads. No pointer/count normalization, typed diagnostic-node projection, new owner, math or constructor change.',
        'Error text line suffixes retain historical selected labels; exact current pinned Native authorities are SetHeatToReturnAirFlag2884-3015, with new reads2926/2943/3005. This is no line-number-based numerical or coverage assertion.',
    ],
    'qualification': 'Prospective Source30 only. Actual29 frontier, committed parent and full compiler inventory join remain pending. No Source30 execution/fullB/positive-airloop/warning completion or Native unknown-history numerical equivalence claim.',
    'new_tests': 0, 'main_Cargo_Native_tests_or_production_mutations': False, 'author_Source': ref(Path(__file__)),
}
print(json.dumps(save('review.json', (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())))

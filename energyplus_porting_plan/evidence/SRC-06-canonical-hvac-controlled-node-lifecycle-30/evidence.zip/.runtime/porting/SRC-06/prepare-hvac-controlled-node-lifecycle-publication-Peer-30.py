"""Prepare Source30 publisher only after final sealer; never publish here."""
import ast
import difflib
import hashlib
import json
import re
from pathlib import Path

R = Path(__file__).resolve().parents[3]
D = R / '.runtime/porting/SRC-06'
OLD = D / 'publish-zone-equipment-output-checkpoint-Peer-28.py'
NEW = D / 'publish-hvac-controlled-node-lifecycle-checkpoint-Peer-30.py'
OUT = D / 'hvac-controlled-node-lifecycle-publication-prepared-Peer-30'

def ref(p):
    b = p.read_bytes()
    return {'path': p.relative_to(R).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

def checked(row):
    p = R / row['path']
    assert ref(p)['sha256'] == row['sha256']
    if 'bytes' in row:
        assert ref(p)['bytes'] == row['bytes']
    return p

assert ref(OLD)['sha256'] == 'e35daa1a3beb4a70feb5a369b75877f1a4d4d32d170e77bbdcf7d32ea2ce01c4'
assert not NEW.exists() and not OUT.exists()
source = OLD.read_text(encoding='utf-8')
body = source
def replace(before, after, count=1):
    global body
    assert body.count(before) == count, (before, body.count(before), count)
    body = body.replace(before, after)

replace('checkpoint28', 'checkpoint30', 2)
replace('zone-equipment-output', 'hvac-controlled-node-lifecycle', 8)
replace('Peer-28', 'Peer-30', 2)
replace('Root-28', 'Root-30', 2)
replace('SRC-06-canonical-hvac-controlled-node-lifecycle-28', 'SRC-06-canonical-hvac-controlled-node-lifecycle-30', 2)
replace("assert head == template['base_HEAD'] == 'd8fc400e4371114a98ed55fa4306aff01509c1ed'", "assert head == template['base_HEAD']")
replace('(4502,4489)', '(4503,4490)')
replace("len(producer['files']) == 3 and producer['existing_Source_files'] == 3", "len(producer['files']) == 4 and producer['existing_Source_files'] == 4")
replace("    assert contains(peer,producer['original_draft02'])\n    assert producer['all3_proposals_whole_unchanged_from_reviewed_draft02'] is True", "    assert contains(peer,producer['original_draft02'])\n    assert producer['independent_semantic_peers']['fourth_and_identity'] == ref(peer_path)\n    original_peer_path = checked(template['accepted_original_three_peer'])\n    original_peer = accepted(original_peer_path,template['accepted_original_three_peer']['sha256'])\n    assert peer['original_three_Source_peer'] == ref(original_peer_path) == producer['independent_semantic_peers']['original_three']\n    assert producer['all4_proposals_whole_unchanged_from_reviewed_draft02'] is True")
replace('Root-source-hvac-controlled-node-lifecycle-actual-review-28', 'Root-source-hvac-controlled-node-lifecycle-actual-review-30')
replace("[template['producer'],ref(peer_path),template['complete_plan']]", "[template['producer'],ref(peer_path),ref(original_peer_path),template['complete_plan']]", 2)
replace('same4502_archived_inputs_exact_final_plan', 'same4503_archived_inputs_exact_final_plan')
replace('selected3_final_sources_exact', 'selected4_final_sources_exact')
replace('whole_JSON_equal27_after_exactly_two_owned_path_field_bridges', 'whole_JSON_equal29_after_exactly_two_owned_path_field_bridges')
replace('full_runtime_equal27_after_two_owned_path_bridges', 'full_runtime_equal29_after_two_owned_path_bridges')
replace('len(index) == len(observed) == 4502', 'len(index) == len(observed) == 4503')
replace('[Path(__file__),template_path,peer_path,actual_path]', '[Path(__file__),template_path,peer_path,original_peer_path,actual_path]')
replace('src06-canonical28-finite-evidence-archive.v1', 'src06-canonical30-finite-evidence-archive.v1')
replace('3 coherent post-component output/demand/availability Sources, Native authority, accepted peer and actual B/A24.', '4 coherent HVAC physical-Node lifecycle/return-air flag Sources, Native authority, two explicitly scoped semantic peers and actual B/A24.')
replace("status='Genuine Source zone-equipment output and demand update; B incomplete at actual frontier'", "status='Genuine Source controlled HVAC Node lifecycle; B incomplete at actual frontier'")
replace("producer=template['producer'],independent_peer=ref(peer_path),complete_compiler_plan=template['complete_plan']", "producer=template['producer'],independent_semantic_peers=producer['independent_semantic_peers'],complete_compiler_plan=template['complete_plan']")
for before, after in [('accepted27_proof', 'accepted29_proof'), ('accepted27_full5352_proof', 'accepted29_full5352_proof'), ('physical_files_whole_equal27', 'physical_files_whole_equal29'), ('whole_physical_streams_equal27', 'whole_physical_streams_equal29'), ('CSV_files_whole_equal27', 'CSV_files_whole_equal29'), ('whole_CSV_equal27', 'whole_CSV_equal29'), ('Proof transfer from accepted27;', 'Proof transfer from accepted29;')]:
    replace(before, after)
replace('Source 장비 출력·수요 갱신 검증', 'Source HVAC Node 생명주기 검증')
replace("key='canonical_zone_equipment_output_28'", "key='canonical_hvac_controlled_node_lifecycle_30'")
ast.parse(body)
# All transformations are checked above before any output. Final producer is
# intentionally absent until actual29+committed HEAD permit the Source sealer.
producer_path = D / 'source-hvac-controlled-node-lifecycle-held-Peer-30/manifest.json'
producer = json.loads(producer_path.read_bytes())
assert (producer['compiler_inputs'], producer['Rust_sources']) == (4503, 4490)
assert producer['all4_proposals_whole_unchanged_from_reviewed_draft02']
peer_path = checked(producer['independent_semantic_peers']['fourth_and_identity'])
original_peer_path = checked(producer['independent_semantic_peers']['original_three'])
peer = json.loads(peer_path.read_bytes())
original_peer = json.loads(original_peer_path.read_bytes())
assert peer['accepted'] and not peer['findings'] and original_peer['accepted'] and not original_peer['findings']
previous = R / 'energyplus_porting_plan/evidence/SRC-06-canonical-controlled-air-balance-29/summary.json'
assert json.loads(previous.read_bytes())['A'] == '14/54'
NEW.write_text(body, encoding='utf-8', newline='\n')
OUT.mkdir()
finite = {}
def add(p):
    row = ref(p)
    assert p.suffix.lower() != '.zip'
    if row['path'] in finite:
        assert finite[row['path']] == row
    finite[row['path']] = row

for p in [producer_path, peer_path, original_peer_path, checked(producer['complete_final_compiler_Source_plan']), checked(producer['full4503_parent_readback']), checked(producer['whole4490_Rust_API_census']), checked(producer['original_draft02']), checked(producer['author_Source']), checked(producer['accepted29_actual_review']), previous, OLD, NEW, Path(__file__)]:
    add(p)
for evidence in [peer, original_peer]:
    add(checked(evidence['author_Source']))
for row in producer['files']:
    for key in ['before', 'proposed', 'literal_inverse', 'forward_diff', 'inverse_diff']:
        add(checked(row[key]))
    for key in ['stdout', 'stderr']:
        add(checked(row['Source_only_parse'][key]))
for row in producer['Native_authorities']:
    add(checked(row['whole']))
    for extent in row['extents']:
        add(checked(extent['source']))
for row in producer['concrete_same_owner_contexts']:
    add(checked(row['whole']))
macro = producer['compiler_macro_authority']
for key in ['accepted_actual_build', 'Native_before', 'registry_whole_copy', 'forced_PCH']:
    add(checked(macro[key]))
for key in ['stdout', 'stderr']:
    add(checked(macro['macro_definition_census'][key]))
template = {
    'schema': 'src06-held-canonical30-publication-template.v1', 'status': 'HELD_FOR_ROOT_ACTUAL30_AND_FULL_READ',
    'base_HEAD': producer['base_HEAD'], 'producer': ref(producer_path), 'complete_plan': producer['complete_final_compiler_Source_plan'],
    'accepted_independent_peer': ref(peer_path), 'accepted_original_three_peer': ref(original_peer_path),
    'semantic_peer_scope': producer['semantic_peer_scope'], 'accepted29_actual_review': producer['accepted29_actual_review'],
    'previous_checkpoint': ref(previous), 'publisher_Source': ref(NEW), 'publisher_parent_Source': ref(OLD),
    'expected_actual_review_path': '.runtime/porting/SRC-06/Root-source-hvac-controlled-node-lifecycle-actual-review-30/review.json',
    'pending_Root_custody': {
        'application': '.runtime/porting/SRC-06/Root-hvac-controlled-node-lifecycle-application-30/receipt.json',
        'actual_review_sha256': 'REQUIRED_AT_PUBLISH_VIA_ACTUAL_SHA_ARGUMENT',
        'actual_checker_Source': '.runtime/porting/SRC-06/check-source-hvac-controlled-node-lifecycle-actual-Root-30.py',
        'launcher_Source': '.runtime/porting/SRC-06/launch-hvac-controlled-node-lifecycle-Root-30.py',
        'B_CLI': '.runtime/porting/SRC-06/canonical-source-hvac-controlled-node-lifecycle-B-NOLIMIT-24H-command-Root-30/receipt.json',
        'A24_CLI': '.runtime/porting/SRC-06/canonical-source-hvac-controlled-node-lifecycle-A-24H-command-Root-30/receipt.json',
    },
    'Root_custody_at_publish': 'Byte-authenticate actual aggregate/application, both scoped semantic peers, their author Sources, launcher and both actual CLI receipts/artifacts. No assumed frontier or positive execution claim from static Source.',
    'summary_template': {
        'A': '14/54', 'B': '14/64', 'changed_Rust_sources': 4, 'existing_Rust_sources': 4, 'new_Rust_sources': 0,
        'new_test_functions': 0, 'actual_test_bodies_executed': 0,
        'focused_validation_policy': 'Actual production B then appropriate A24 only. No unrelated test/profile, repeated cohort, new test or alltargets.',
        'scope': producer['scope'], 'unknown_history_qualification': producer['unknown_history_qualification'],
        'full_B_or_finite15_completion_claim': False, 'Native_harness_runtime_or_unit_equivalence_claim': False, 'gate_changes': False, 'policy_changes': False,
    },
    'doc_appends': {
        'CHECKLIST.md': '기존 물리 Node와 Config를 사용하는 HVAC 초기화·이력·설정값 경로와 반환공기 열 플래그를 연결했습니다. 실제 B 경계와 A24 회귀 결과는 연결된 증거에 기록합니다.',
        'STATE_CONTRACTS.md': 'Node 번호와 반환공기 연결은 실제 보유 배열에서 읽으며, Node 설정값과 수렴 이력은 같은 소유자에 Native 순서로 씁니다. 초기화되지 않은 이력은 미정 상태로 유지하며 임의의 수치로 채우지 않습니다.',
        'cards/SRC-06.md': 'HVAC Node 생명주기 묶음의 실제 실행 결과를 기록합니다. B의 실제 경계는 `{{actual_B_frontier}}`이며, 전체 B나 미정 Native 이력의 수치 동등성 완료를 주장하지 않습니다.',
    },
    'finite_archive_inputs': [row for _, row in sorted(finite.items())], 'finite_archive_input_count': len(finite), 'finite_archive_input_bytes': sum(row['bytes'] for row in finite.values()),
    'publisher_executed': False, 'canonical_docs_mutations': False, 'Cargo_tests_Native_executed': False, 'gate_changes': False,
}
template_path = OUT / 'publication-template.json'
template_path.write_text(json.dumps(template, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
t = ast.parse((D / 'seal-compact-annual-daygroup-helper-Peer-01.py').read_text(encoding='utf-8'))
fn = next(x for x in t.body if isinstance(x, ast.FunctionDef) and x.name == 'apply_literal')
ns = {'re': re}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<literal>', 'exec'), ns)
diffs = {}
for name, before, after in [('forward', source.encode(), body.encode()), ('inverse', body.encode(), source.encode())]:
    delta = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=OLD.name, tofile=NEW.name)).encode()
    assert ns['apply_literal'](before, delta) == after
    p = OUT / (name + '.diff')
    p.write_bytes(delta)
    diffs[name] = ref(p)
proof = {'parent': ref(OLD), 'successor': ref(NEW), 'literal_applications': 2, 'diffs': diffs, 'template': ref(template_path), 'scope': 'Accepted28 two-CLI/no-test publication engine with Source30 exact4old counts, explicit split-peer guards, actual29 proof transfer and corresponding paths/scope/docs. No execution.', 'publisher_executed': False, 'canonical_mutations': False}
bridge_path = OUT / 'publisher-parent-bridge.json'
bridge_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'publisher': ref(NEW), 'template': ref(template_path), 'bridge': ref(bridge_path)}))

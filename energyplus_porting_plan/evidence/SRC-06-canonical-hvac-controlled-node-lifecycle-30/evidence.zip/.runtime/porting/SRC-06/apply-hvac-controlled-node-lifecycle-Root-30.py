from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[3];D=R/'.runtime/porting/SRC-06';O=D/'Root-hvac-controlled-node-lifecycle-application-30';assert not O.exists()
def ref(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def checked(v):
 p=(R/v['path']).resolve();assert p.is_relative_to(R);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==v['sha256'] and len(b)==v.get('bytes',len(b));return b
mr=ref(D/'source-hvac-controlled-node-lifecycle-held-Peer-30/manifest.json');assert mr['sha256']=='670e7cb7d4e886d61e4eed7a28df63fa36eb6406dde5747c056dba61d6bf59ab';m=json.loads(checked(mr));prs=m['independent_semantic_peers'];assert prs['original_three']['sha256']=='cf51135e42742a864745b0057a9e9c79ce6ed08a2fb8124b8fa6f60377a7b9ab' and prs['fourth_and_identity']['sha256']=='9546e538bcdf8b2b855c52947a2586b9524db36f3b7dccca898a9fee709680c1'
oldpeer=json.loads(checked(prs['original_three']));extension=json.loads(checked(prs['fourth_and_identity']));draft=json.loads(checked(m['original_draft02']))
assert all(v['accepted'] and not v['findings'] for v in [oldpeer,extension]);assert extension['reviewed_packet']==m['original_draft02'];assert extension['original_three_Source_peer']==prs['original_three'] and extension['original_three_Source_draft']==oldpeer['reviewed_packet']==draft['original_three_Source_draft']
peerfiles={v['canonical_path']:v for v in oldpeer['files']+extension['files']};assert len(peerfiles)==4
for v in extension['three_Source_literal_identity']:assert checked(v['original_reviewed_proposed'])==checked(v['successor_proposed'])==checked(peerfiles[v['canonical_path']]['proposed'])
def allrefs(v):
 if isinstance(v,dict):
  if 'path' in v and 'sha256' in v:checked(v)
  else:
   for item in v.values():allrefs(item)
 elif isinstance(v,list):
  for item in v:allrefs(item)
allrefs(m['compiler_macro_authority'])
macros=m['compiler_macro_authority'];registry=json.loads(checked(macros['actual_compile_registry']));assert len(registry)==macros['registry_rows']==795
for command in macros['two_actual_commands']:assert command in registry

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==m['base_HEAD']=='13c00eb921f81b9f154718d2f74218885c3b8f99' and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
parents={v['historical_path']:v for v in json.loads(checked(m['actual_parent_snapshot']))['files']};inventory={p.relative_to(R).as_posix() for p in(R/'crates').rglob('*.rs')}|{p.relative_to(R).as_posix() for p in(R/'crates').rglob('Cargo.toml')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'};assert len(inventory)==4503 and set(parents)==inventory
for n,v in parents.items():assert (R/n).read_bytes()==checked(v['archive']) and (R/n).stat().st_size==v['size_bytes'],n
t=ast.parse((D/'review-meter-final-predefined-Root-01.py').read_text(encoding='utf8'));exec(compile(ast.Module(body=[next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='apply')],type_ignores=[]),'<literal>','exec'))
selected={};new=set();tests=0
for f in m['files']:
 n=f['canonical_path'];assert n not in selected;a=b'' if f['before'] is None else checked(f['before']);b=checked(f['proposed']);assert checked(f['literal_inverse'])==a and apply(a,checked(f['forward_diff']))==b and apply(b,checked(f['inverse_diff']))==a and b==checked(f['literal_origin_whole'])==checked(peerfiles[n]['proposed'])
 if f['before_absent']:assert not (R/n).exists() and a==b'';new.add(n)
 else:assert a==(R/n).read_bytes()==checked(parents[n]['archive'])==subprocess.check_output(['git','show',head+':'+n],cwd=R) and (R/n).stat().st_nlink==1
 assert f['Source_only_parse']['exit_code']==0;checked(f['Source_only_parse']['stdout']);checked(f['Source_only_parse']['stderr']);tests+=b.count(b'#[test]')-a.count(b'#[test]');selected[n]=f
assert len(selected)==4 and len(new)==0 and tests==0 and set(selected)==set(peerfiles)
extent_count=0
for v in m['Native_authorities']:
 b=checked(v['whole']);assert b==subprocess.check_output(['git','show',m['Native_commit']+':'+v['Native_path']],cwd=R/'.reference/energyplus-src/26.1.0')
 for e in v['extents']:assert b''.join(b.splitlines(keepends=True)[e['first']-1:e['last']])==checked(e['source']);extent_count+=1
assert len(m['Native_authorities'])==8 and extent_count==16
for v in m['concrete_same_owner_contexts']:assert (R/v['canonical_path']).read_bytes()==checked(v['whole'])==checked(parents[v['canonical_path']]['archive'])==subprocess.check_output(['git','show',head+':'+v['canonical_path']],cwd=R)
for k in ['accepted29_actual_review','parent_producer','prior_complete_compiler_Source_plan','full4503_parent_readback','whole4490_Rust_API_census','original_draft02']:checked(m[k])
plan=json.loads(checked(m['complete_final_compiler_Source_plan']));rows={v['path']:v for v in plan['entries']};assert set(rows)==inventory|new and len(rows)==4503 and sum(n.endswith('.rs') for n in rows)==4490
for n,v in rows.items():
 b=checked(v['source']);assert hashlib.sha256(b).hexdigest()==v['final_sha256'] and len(b)==v['final_bytes'] and b==(checked(selected[n]['proposed']) if n in selected else (R/n).read_bytes()),n
O.mkdir()
for n,f in selected.items():
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(checked(f['proposed']))
for n,v in rows.items():assert (R/n).read_bytes()==checked(v['source']),n
result=dict(accepted=True,findings=[],base_HEAD=head,producer=mr,independent_semantic_peers=prs,peer_scope='Full original3 Source semantic peer and independent fourth Source/unchanged3 identity peer; neither relabelled a whole4 peer. Root authenticates final4503 compiler/base join independently.',complete_compiler_plan=m['complete_final_compiler_Source_plan'],selected=selected,original_parent_inputs=4503,final_inputs=4503,final_Rust_sources=4490,selected_Rust=4,new_Rust=0,literal_applications=8,new_test_bodies=0,all_parent_archive_live_equal=True,selected_existing_Git_whole_equal=True,all_final_plan_inputs_readback_exact=True,Cargo_Native_or_tests_executed=False,semantic_review='Root authored/read original3 Source bodies and fourth extension, full Native InitAirLoops1931-1949/2131-2139/ConnectReturnNodes2309-2400, HVAC1769-1784/3017-3047/2884-3015, physical Node/default and convergence constructors/Objexx allocation. Real borrowed Config IDs/return-airloop ordinals, no-path traversal, ordered same-Node humidity/flow/temperature histories, full physical/default setpoint resets, and actual heat-to-return flags over each real inlet. Native unknown diagnostic-history slots stay symbolic None, shifted without inventing numbers. Actual Native build/795 commands/PCH/macro authority authenticated; no initialized-bit equivalence for unknown histories. Positive airloop/fan/warning/return-path operations remain true boundaries. No new state owner/cache, numerical solver, forced flags/counts, tests, Native production answers or fullB completion claim. Actual B/A30 pending.',compiler_macro_authority_authenticated=True,author_Source=ref(Path(__file__).resolve()))
p=O/'receipt.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(ref(p)))
